/* Uygulama başlatıcı: üst bar ve sol menü ikonları, hakkında penceresi, kullanıcı menüsü */
(function () {
  'use strict';
  var MQ = window.MQ;
  function init() {
    var rails = document.querySelectorAll('.rail a');
    for (var i = 0; i < rails.length; i++) {
      var a = rails[i], label = a.textContent;
      a.innerHTML = MQ.icon(a.getAttribute('data-ic')) + '<span>' + MQ.esc(label) + '</span>';
      a.addEventListener('click', function () { document.getElementById('rail').classList.remove('open'); });
    }
    document.getElementById('hdrHelp').innerHTML = MQ.icon('help');
    document.getElementById('hdrInfo').innerHTML = MQ.icon('info');
    document.getElementById('hdrUser').innerHTML = MQ.icon('user');
    document.getElementById('hdrHelp').onclick = function () { MQ.openHelp('console'); };
    document.getElementById('hdrInfo').onclick = function () {
      MQ.modal({ title: 'IBM MQ Console — Eğitim Simülasyonu', help: 'simulation', primary: false, cancel: 'Kapat', size: 'sm',
        body: '<dl class="kv"><dt>Simüle edilen sürüm</dt><dd>IBM MQ 9.4.0.26 LTS (mqweb Console)</dd><dt>Amaç</dt><dd>IBM MQ bileşenlerini Türkçe açıklamalarla öğretmek</dd><dt>Bağlantı</dt><dd>Yok — tüm veriler tarayıcıda simüle edilir</dd><dt>Açıklama sayısı</dt><dd>' + Object.keys(MQ.HELP).length + ' konu</dd></dl>' +
          '<p class="muted">IBM ve IBM MQ, International Business Machines Corporation\'ın ticari markalarıdır. Bu uygulama IBM tarafından geliştirilmemiştir ve IBM ile bağlantılı değildir; yalnızca eğitim amaçlıdır.</p>' });
    };
    var userBtn = document.getElementById('hdrUser');
    userBtn.setAttribute('data-menu', 'usermenu');
    MQ._menus.usermenu = [];
    userBtn.addEventListener('click', function () {
      MQ._menus.usermenu = [
        { label: 'Kullanıcı: ' + MQ.state.user.name + ' (' + MQ.state.user.role + ')', fn: function () { MQ.openHelp('mqwebroles'); } },
        { label: 'Ayarlar', fn: function () { MQ.go('#/settings'); } },
        { label: 'Oturumu kapat (simülasyon)', fn: function () { MQ.toast('info', 'Simülasyon', 'Bu eğitim konsolunda oturum kavramı yoktur. Gerçek MQ Console\'da oturum mqweb (Liberty) tarafından yönetilir.'); } }
      ];
    }, true);
    MQ.start();
    if (window.console && Object.keys(MQ._missingHelp).length) console.warn('Eksik açıklamalar:', Object.keys(MQ._missingHelp));
  }
  // dispatch her çağrıldığında _menus sıfırlandığı için kullanıcı menüsünü tıklamada yeniden kaydediyoruz
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
