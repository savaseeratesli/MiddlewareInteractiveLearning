/* Yönetim işlemlerinin görsel simülasyonu. Hiçbir işlem gerçek bir IBM MQ sistemine gönderilmez;
   yalnızca tarayıcıdaki simülasyon verisi güncellenir ve eşdeğer MQSC / komut satırı çıktısı gösterilir. */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc, F = MQ.F;
  var A = MQ.act = {};
  var Q = function (s) { return "'" + String(s).replace(/'/g, "''") + "'"; };

  MQ.addEvent = function (qm, type, cat, object, reason, sev, detail) { qm.events.unshift({ time: MQ.now(), type: type, cat: cat, object: object, reason: reason, sev: sev, detail: detail }); };
  MQ.addErr = function (qm, code, sev, text, exp, act) { qm.errlog.unshift({ time: MQ.now(), code: code, sev: sev, text: text, exp: exp || '', act: act || '' }); };
  function done(title, msg, code, kind) { MQ.save(); MQ.refresh(); MQ.toast(kind || '', title, msg, code); }
  function exists(qm, n) { return MQ.findQ(qm, n); }
  function hostPort(conname) { var m = /^([^(]+)\((\d+)\)/.exec(conname || ''); return m ? { host: m[1].trim(), port: parseInt(m[2], 10) } : { host: (conname || '').trim(), port: 1414 }; }
  function qmByHost(conname) { var hp = hostPort(conname); return MQ.state.qmgrs.filter(function (q) { return q.host === hp.host; })[0]; }

  /* ================================================== QUEUE MANAGER */
  A.createQm = function () {
    MQ.modal({
      title: 'Queue manager oluştur', label: 'crtmqm', help: 'crtmqm', primary: 'Oluştur', size: 'lg',
      body: '<div class="notice">' + I('info') + '<div class="grow">Gerçek ortamda queue manager\'lar <code>crtmqm</code> komutu ile oluşturulur ve <code>strmqm</code> ile başlatılır. Burada yalnızca simüle edilir.</div></div>' +
        '<div class="frow">' + F.text({ name: 'name', label: 'Queue manager adı', help: 'qmname', placeholder: 'ör. QMAPP01', maxlength: 48 }) + F.text({ name: 'port', label: 'Listener portu', help: 'lstr.port', value: '1417', type: 'number' }) + '</div>' +
        F.text({ name: 'descr', label: 'Açıklama (-c)', help: 'qm.descr' }) +
        F.check({ name: 'dlq', label: 'SYSTEM.DEAD.LETTER.QUEUE\'yu dead-letter queue olarak ata (-u)', help: 'dlq', value: true }) +
        F.check({ name: 'def', label: 'Varsayılan queue manager yap (-q)', help: 'defaultqm', value: false }) +
        F.sec('Recovery log', 'logtype') +
        F.radio({ name: 'log', label: 'Log tipi', help: 'logtype', options: [['c', 'Circular (-lc)'], ['l', 'Linear (-ll)']], value: 'c' }) +
        '<div class="frow3">' + F.text({ name: 'lp', label: 'Primary log dosyası (-lp)', help: 'log.files', value: '3', type: 'number' }) + F.text({ name: 'ls', label: 'Secondary log dosyası (-ls)', help: 'log.files', value: '2', type: 'number' }) + F.text({ name: 'lf', label: 'Log dosya sayfası (-lf)', help: 'log.files', value: '4096', type: 'number' }) + '</div>' +
        F.check({ name: 'start', label: 'Oluşturduktan sonra başlat (strmqm)', help: 'qmstatus', value: true }) + F.preview('Eşdeğer komutlar', 'crtmqm'),
      onInput: function (f, v) {
        MQ.setPreview(f, 'crtmqm' + (v.descr ? ' -c "' + v.descr + '"' : '') + (v.dlq ? ' -u SYSTEM.DEAD.LETTER.QUEUE' : '') + (v.def ? ' -q' : '') + (v.log === 'l' ? ' -ll' : ' -lc') + ' -lp ' + v.lp + ' -ls ' + v.ls + ' -lf ' + v.lf + (v.port ? ' -p ' + v.port : '') + ' ' + (v.name || '<QMNAME>') + (v.start ? '\nstrmqm ' + (v.name || '<QMNAME>') : '') + '\n\n# Doğrulama:\ndspmq -m ' + (v.name || '<QMNAME>') + ' -o all');
      },
      onSubmit: function (f, v) {
        var err = MQ.validName(v.name); if (err) return MQ.invalid(f, 'name', err);
        if (MQ.qm(v.name)) return MQ.invalid(f, 'name', 'AMQ8110E: IBM MQ queue manager already exists.');
        var lp = parseInt(v.lp, 10), ls = parseInt(v.ls, 10), lf = parseInt(v.lf, 10);
        if (lp < 2 || lp > 510) return MQ.invalid(f, 'lp', 'Primary log dosyası sayısı 2 - 510 arasında olmalıdır.');
        if (lp + ls > 511) return MQ.invalid(f, 'ls', 'Primary + secondary toplamı 511\'i geçemez.');
        if (lf < 64 || lf > 65535) return MQ.invalid(f, 'lf', 'Log dosya sayfası 64 - 65535 arasında olmalıdır.');
        var port = parseInt(v.port, 10);
        var base = MQ.clone(MQ.state.qmgrs.filter(function (x) { return x.name === 'QMTEST01'; })[0] || MQ.state.qmgrs[0]);
        var qm = MQ.seed().qmgrs.filter(function (x) { return x.name === 'QMTEST01'; })[0];
        qm.name = v.name; qm.platform = 'Unix'; qm.os = 'Linux x86-64 (Red Hat Enterprise Linux 9.4)'; qm.host = 'localhost'; qm.ip = '127.0.0.1'; qm.port = port || 1414;
        qm.instPath = '/opt/mqm'; qm.dataPath = '/var/mqm/qmgrs/' + v.name; qm.logPath = '/var/mqm/log/' + v.name + '/active/';
        qm.created = MQ.now(); qm.logType = v.log === 'l' ? 'LINEAR' : 'CIRCULAR'; qm.logPrimary = lp; qm.logSecondary = ls; qm.logFilePages = lf; qm.ha = 'Yok';
        qm.attrs.DESCR = v.descr; qm.attrs.DEADQ = v.dlq ? 'SYSTEM.DEAD.LETTER.QUEUE' : '';
        qm.queues = qm.queues.filter(function (q) { return q.system; }); qm.queues.forEach(function (q) { q.curdepth = 0; q.messages = null; });
        qm.channels = []; qm.conns = []; qm.events = []; qm.authrec = [{ profile: 'self', objtype: 'QMGR', principal: '', group: 'mqm', auth: 'ALLADM ALLMQI', note: '' }];
        qm.listeners = port ? [{ name: 'SYSTEM.LISTENER.TCP.1', status: 'Stopped', trptype: 'TCP', port: port, ipaddr: '', control: 'QMGR', backlog: 0, descr: 'crtmqm -p ile oluşturuldu', pid: '', started: '' }] : [];
        qm.errlog = [{ time: MQ.now(), code: 'AMQ8001I', sev: 'I', text: "IBM MQ queue manager '" + v.name + "' created.", exp: 'crtmqm başarıyla tamamlandı.', act: '' }];
        qm.status = 'Ended immediately'; qm.started = ''; qm.cpu = 0; qm.mem = 0; qm.storageMB = 64; qm.isDefault = false;
        if (v.def) MQ.state.qmgrs.forEach(function (x) { x.isDefault = false; }), qm.isDefault = true;
        MQ.state.qmgrs.push(qm);
        if (v.start) startQmCore(qm);
        MQ.save(); MQ.go('#/manage'); MQ.refresh();
        MQ.toast('', 'Queue manager oluşturuldu (simülasyon)', 'IBM MQ queue manager \'' + E(v.name) + '\' created.' + (v.start ? '<br>IBM MQ queue manager \'' + E(v.name) + '\' started using V9.4.0.26.' : ''), f.querySelector('[data-preview]').textContent.split('\n\n')[0]);
      }
    });
  };
  function startQmCore(qm) {
    qm.status = 'Running'; qm.started = MQ.now(); qm.cpu = qm.cpu || 0.8; qm.mem = qm.mem || 6.5;
    qm.listeners.forEach(function (l) { if (l.control === 'QMGR') { l.status = 'Running'; l.pid = 30000 + Math.floor(Math.random() * 9000); l.started = MQ.now(); } });
    qm.services.forEach(function (s) { if (s.control === 'QMGR' && s.servtype === 'SERVER') s.status = 'Running'; });
    MQ.addErr(qm, 'AMQ8003I', 'I', "IBM MQ queue manager '" + qm.name + "' started using V" + qm.version + '.', 'Queue manager başlatıldı.', '');
    /* Bu QM'e bağlanmaya çalışan RETRYING kanallar bir sonraki denemede bağlanır */
    MQ.state.qmgrs.forEach(function (o) { if (o === qm) return; o.channels.forEach(function (c) { if (c.status === 'Retrying' && hostPort(c.conname).host === qm.host) setTimeout(function () { A.startChannel(o, c, true); }, 1500); }); });
    MQ.addEvent(qm, 'Queue Manager Active', 'Start/Stop', qm.name, 'MQRC_Q_MGR_ACTIVE (2222)', 'Info', 'Queue manager başlatıldı.');
  }
  A.startQm = function (qm) {
    MQ.confirm({ title: qm.name + ' başlatılsın mı?', help: 'qmstatus', danger: false, primary: 'Başlat', body: '<p>Queue manager başlatılır; CONTROL(QMGR) olan listener ve service\'ler otomatik başlar, SCHINIT(QMGR) ise channel initiator devreye girer.</p><pre class="preview-box">strmqm ' + E(qm.name) + '</pre>',
      onOk: function () { startQmCore(qm); done('Queue manager başlatıldı (simülasyon)', 'AMQ8003I: IBM MQ queue manager \'' + E(qm.name) + '\' started using V' + E(qm.version) + '.', 'strmqm ' + qm.name); } });
  };
  A.stopQm = function (qm) {
    MQ.modal({ title: qm.name + ' durdurulsun mu?', label: 'endmqm', help: 'endmqm', primary: 'Durdur', danger: true, size: 'sm',
      body: F.radio({ name: 'mode', label: 'Kapatma modu', help: 'endmqm', options: [['', 'Controlled (varsayılan)'], ['-w', 'Wait (-w)'], ['-i', 'Immediate (-i)'], ['-p', 'Preemptive (-p)']], value: '' }) +
        '<div class="notice warn">' + I('warning') + '<div class="grow">Bağlı uygulamalar (' + qm.conns.length + ' bağlantı) MQRC_Q_MGR_QUIESCING / MQRC_CONNECTION_BROKEN alır. Diğer queue manager\'lardan bu QM\'e gelen kanallar RETRYING durumuna geçer.</div></div>' + F.preview('Eşdeğer komut', 'endmqm'),
      onInput: function (f, v) { MQ.setPreview(f, 'endmqm ' + (v.mode ? v.mode + ' ' : '') + qm.name); },
      onSubmit: function (f, v) {
        qm.status = v.mode === '-i' ? 'Ended immediately' : v.mode === '-p' ? 'Ended preemptively' : 'Ended normally';
        qm.listeners.forEach(function (l) { l.status = 'Stopped'; l.pid = ''; });
        qm.channels.forEach(function (c) { if (c.status === 'Running' || c.status === 'Retrying') c.status = 'Inactive'; c.inst = null; });
        qm.services.forEach(function (s) { if (s.status === 'Running') s.status = 'Stopped'; });
        qm.conns = []; qm.cpu = 0; qm.mem = 0;
        MQ.state.qmgrs.forEach(function (o) { if (o === qm) return; o.channels.forEach(function (c) { if (c.status === 'Running' && hostPort(c.conname).host === qm.host && ['SDR', 'SVR', 'CLUSSDR'].indexOf(c.chltype) >= 0) { c.status = 'Retrying'; c.st = Object.assign(c.st || {}, { retries: 'Short retry 1/' + c.shortrty }); MQ.addErr(o, 'AMQ9202E', 'E', "Remote host '" + c.conname + "' not available, retry later.", "Channel '" + c.name + "' karşı tarafa bağlanamadı.", 'Karşı queue manager\'ın ve listener\'ın çalıştığını kontrol edin.'); } }); });
        MQ.addErr(qm, 'AMQ8004I', 'I', "IBM MQ queue manager '" + qm.name + "' ended.", '', '');
        done('Queue manager durduruldu (simülasyon)', 'Quiesce request accepted. The queue manager will stop when all outstanding work is complete.', f.querySelector('[data-preview]').textContent, 'warn');
      } });
  };
  A.deleteQm = function (qm) {
    if (MQ.isUp(qm) || qm.status === 'Running elsewhere') { MQ.toast('err', 'Queue manager silinemez', 'AMQ8027E: IBM MQ queue manager running. Önce endmqm ile durdurun.', 'dltmqm ' + qm.name); return; }
    MQ.modal({ title: qm.name + ' silinsin mi?', help: 'dltmqm', primary: 'Kalıcı olarak sil', danger: true, size: 'sm',
      body: '<p>Bu işlem queue manager\'ı, tüm kuyruklarını, mesajlarını ve log dosyalarını <b>geri alınamaz şekilde</b> siler (simülasyonda yalnızca listeden kaldırılır).</p>' + F.text({ name: 'confirm', label: 'Onaylamak için queue manager adını yazın', placeholder: qm.name }) + '<pre class="preview-box">dltmqm ' + E(qm.name) + '</pre>',
      onSubmit: function (f, v) { if (v.confirm !== qm.name) return MQ.invalid(f, 'confirm', 'Ad eşleşmiyor.'); MQ.state.qmgrs.splice(MQ.state.qmgrs.indexOf(qm), 1); MQ.save(); MQ.go('#/manage'); MQ.refresh(); MQ.toast('', 'Queue manager silindi (simülasyon)', 'IBM MQ queue manager \'' + E(qm.name) + '\' deleted.', 'dltmqm ' + qm.name); } });
  };
  A.addRemoteQm = function () {
    MQ.modal({ title: 'Remote queue manager ekle', help: 'remoteqm', primary: 'Ekle',
      body: '<div class="frow">' + F.text({ name: 'name', label: 'Queue manager adı', help: 'qmname' }) + F.text({ name: 'host', label: 'Host', help: 'ch.conname', placeholder: 'mq.ornek.local' }) + F.text({ name: 'port', label: 'Port', help: 'lstr.port', value: '1414', type: 'number' }) + F.text({ name: 'channel', label: 'SVRCONN channel', help: 'svrconn', value: 'CONSOLE.SVRCONN' }) + '</div>' + F.select({ name: 'tls', label: 'CipherSpec', help: 'ch.sslciph', options: MQ.CIPHERS.map(function (c) { return c.name; }), value: 'ANY_TLS12_OR_HIGHER' }),
      onSubmit: function (f, v) { var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e); if (!v.host) return MQ.invalid(f, 'host', 'Host zorunludur.'); MQ.state.remoteQmgrs.push({ name: v.name, status: 'Connected', platform: 'Unix', version: '9.4.0', cmdlevel: 940, host: v.host, port: parseInt(v.port, 10), channel: v.channel, tls: v.tls }); done('Remote queue manager eklendi (simülasyon)', 'Console artık bu QM\'e CCDT üzerinden bağlanır.'); } });
  };

  /* ================================================== QUEUES */
  var QCARDS = [
    ['QLOCAL', 'Local', 'Mesajları fiziksel olarak saklayan kuyruk.', 'qlocal'],
    ['QREMOTE', 'Remote', 'Başka bir QM\'deki kuyruğun yerel tanımı.', 'qremote'],
    ['QALIAS', 'Alias', 'Mevcut bir kuyruk veya topic için takma ad.', 'qalias'],
    ['QMODEL', 'Model', 'Dinamik kuyruklar için şablon.', 'qmodel'],
    ['XMITQ', 'Transmission', 'Uzak QM\'e gidecek mesajların bekleme kuyruğu (USAGE XMITQ).', 'xmitq'],
    ['DLQ', 'Dead letter', 'Teslim edilemeyen mesajların kuyruğu.', 'dlq'],
    ['INITQ', 'Initiation', 'Trigger mesajlarının yazıldığı kuyruk.', 'initq'],
    ['CLUSTER', 'Cluster', 'Cluster\'a duyurulan local queue.', 'clusterq']
  ];
  A.createQueue = function (qm, like) {
    var type = like ? (like.usage === 'XMITQ' ? 'XMITQ' : like.type) : 'QLOCAL';
    var xmitqs = qm.queues.filter(function (q) { return q.usage === 'XMITQ'; }).map(function (q) { return q.name; });
    function fields(t) {
      var L = like || {}, s = '';
      s += '<div class="frow">' + F.text({ name: 'name', label: 'Queue name', attr: 'QUEUE', help: 'qname', placeholder: t === 'XMITQ' ? 'Hedef QM adı, ör. QMREMOTE01' : 'ör. APP.SIPARIS.IN', maxlength: 48 }) + F.text({ name: 'descr', label: 'Description', attr: 'DESCR', help: 'q.descr', value: L.descr || '' }) + '</div>';
      if (t === 'QREMOTE') {
        s += '<div class="frow3">' + F.text({ name: 'rname', label: 'Remote queue', attr: 'RNAME', help: 'qremote.rname', value: L.rname || '', hint: 'Boş bırakılırsa queue manager alias olur.' }) + F.text({ name: 'rqmname', label: 'Remote queue manager', attr: 'RQMNAME', help: 'qremote.rqmname', value: L.rqmname || '' }) +
          F.select({ name: 'xmitq', label: 'Transmission queue', attr: 'XMITQ', help: 'qremote.xmitq', options: [['', '(boş - RQMNAME ile aynı adlı xmitq)']].concat(xmitqs), value: L.xmitq || '' }) + '</div>';
        s += '<div class="frow">' + F.select({ name: 'defpsist', label: 'Default persistence', attr: 'DEFPSIST', help: 'q.defpsist', options: ['NO', 'YES'], value: L.defpsist || 'YES' }) + F.select({ name: 'put', label: 'Put', attr: 'PUT', help: 'q.put', options: ['ENABLED', 'DISABLED'] }) + '</div>';
        return s;
      }
      if (t === 'QALIAS') {
        s += '<div class="frow">' + F.text({ name: 'target', label: 'Target', attr: 'TARGET', help: 'qalias.target', value: L.target || '' }) + F.select({ name: 'targtype', label: 'Target type', attr: 'TARGTYPE', help: 'qalias.targtype', options: ['QUEUE', 'TOPIC'], value: L.targtype || 'QUEUE' }) +
          F.select({ name: 'put', label: 'Put', attr: 'PUT', help: 'q.put', options: ['ENABLED', 'DISABLED'] }) + F.select({ name: 'get', label: 'Get', attr: 'GET', help: 'q.get', options: ['ENABLED', 'DISABLED'] }) + '</div>';
        return s;
      }
      s += '<div class="frow3">' + F.text({ name: 'maxdepth', label: 'Max queue depth', attr: 'MAXDEPTH', help: 'maxdepth', value: L.maxdepth || (t === 'XMITQ' || t === 'DLQ' ? 50000 : 5000), type: 'number' }) +
        F.text({ name: 'maxmsgl', label: 'Max message length', attr: 'MAXMSGL', help: 'q.maxmsgl', value: L.maxmsgl || 4194304, type: 'number' }) +
        F.select({ name: 'defpsist', label: 'Default persistence', attr: 'DEFPSIST', help: 'q.defpsist', options: ['NO', 'YES'], value: L.defpsist || (t === 'XMITQ' || t === 'DLQ' ? 'YES' : 'NO') }) + '</div>';
      if (t === 'QMODEL') s += F.select({ name: 'deftype', label: 'Definition type', attr: 'DEFTYPE', help: 'qmodel.deftype', options: ['TEMPDYN', 'PERMDYN'], value: L.deftype || 'TEMPDYN' });
      s += '<div class="frow3">' + F.text({ name: 'defprty', label: 'Default priority', attr: 'DEFPRTY', help: 'q.defprty', value: L.defprty || 0, type: 'number', min: 0, max: 9 }) + F.select({ name: 'share', label: 'Shareability', attr: 'SHARE', help: 'q.share', options: ['SHARE', 'NOSHARE'], value: L.share || 'SHARE' }) + F.select({ name: 'msgdlvsq', label: 'Delivery sequence', attr: 'MSGDLVSQ', help: 'q.msgdlvsq', options: ['PRIORITY', 'FIFO'] }) + '</div>';
      if (t === 'QLOCAL' || t === 'CLUSTER' || t === 'QMODEL') {
        s += F.sec('Backout (poison message)', 'backout') + '<div class="frow">' + F.text({ name: 'bothresh', label: 'Backout threshold', attr: 'BOTHRESH', help: 'backout', value: L.bothresh || 0, type: 'number' }) + F.text({ name: 'boqname', label: 'Backout requeue queue', attr: 'BOQNAME', help: 'q.boqname', value: L.boqname || '' }) + '</div>';
      }
      if (t === 'CLUSTER') s += F.sec('Cluster', 'clusterq') + '<div class="frow">' + F.text({ name: 'cluster', label: 'Cluster', attr: 'CLUSTER', help: 'q.cluster', value: qm.cluster ? qm.cluster.name : '' }) + F.select({ name: 'defbind', label: 'Default bind', attr: 'DEFBIND', help: 'q.defbind', options: ['NOTFIXED', 'OPEN', 'GROUP'] }) + '</div>';
      if (t !== 'DLQ' && t !== 'INITQ') {
        s += F.sec('Triggering', 'triggering') + F.check({ name: 'trigger', label: 'Triggering etkin (TRIGGER)', help: 'q.trigger', value: t === 'XMITQ' || !!L.trigger }) +
          '<div class="frow">' + F.select({ name: 'trigtype', label: 'Trigger type', attr: 'TRIGTYPE', help: 'q.trigtype', options: ['FIRST', 'EVERY', 'DEPTH', 'NONE'], value: L.trigtype || 'FIRST' }) + F.text({ name: 'initq', label: 'Initiation queue', attr: 'INITQ', help: 'initq', value: t === 'XMITQ' ? 'SYSTEM.CHANNEL.INITQ' : (L.initq || '') }) +
          F.text({ name: 'trigdata', label: 'Trigger data', attr: 'TRIGDATA', help: 'q.trigdata', value: L.trigdata || '', hint: t === 'XMITQ' ? 'Transmission queue için: başlatılacak sender channel adı.' : '' }) + (t !== 'XMITQ' ? F.text({ name: 'process', label: 'Process', attr: 'PROCESS', help: 'process', value: L.process || '' }) : '') + '</div>';
      }
      if (t === 'DLQ') s += F.check({ name: 'setdeadq', label: 'Bu kuyruğu queue manager\'ın dead-letter queue\'su yap (ALTER QMGR DEADQ)', help: 'qm.deadq', value: true });
      s += F.sec('Events', 'perfevents') + '<div class="frow">' + F.text({ name: 'qdepthhi', label: 'Queue depth high (%)', attr: 'QDEPTHHI', help: 'qdepthhi', value: L.qdepthhi || 80, type: 'number' }) + F.select({ name: 'qdphiev', label: 'High depth events', attr: 'QDPHIEV', help: 'qdepthhi', options: ['DISABLED', 'ENABLED'], value: L.qdphiev || 'DISABLED' }) + '</div>';
      return s;
    }
    function mqsc(t, v) {
      var verb = { QLOCAL: 'QLOCAL', XMITQ: 'QLOCAL', DLQ: 'QLOCAL', INITQ: 'QLOCAL', CLUSTER: 'QLOCAL', QREMOTE: 'QREMOTE', QALIAS: 'QALIAS', QMODEL: 'QMODEL' }[t];
      var p = ['DEFINE ' + verb + '(' + Q(v.name || '<ad>') + ')'];
      if (like) p.push('LIKE(' + Q(like.name) + ')');
      if (v.descr) p.push('DESCR(' + Q(v.descr) + ')');
      if (t === 'QREMOTE') { if (v.rname) p.push('RNAME(' + Q(v.rname) + ')'); p.push('RQMNAME(' + Q(v.rqmname || '') + ')'); if (v.xmitq) p.push('XMITQ(' + Q(v.xmitq) + ')'); p.push('DEFPSIST(' + v.defpsist + ')'); }
      else if (t === 'QALIAS') { p.push('TARGET(' + Q(v.target || '') + ')'); if (v.targtype !== 'QUEUE') p.push('TARGTYPE(' + v.targtype + ')'); if (v.put === 'DISABLED') p.push('PUT(DISABLED)'); if (v.get === 'DISABLED') p.push('GET(DISABLED)'); }
      else {
        if (t === 'XMITQ') p.push('USAGE(XMITQ)');
        if (t === 'QMODEL') p.push('DEFTYPE(' + v.deftype + ')');
        p.push('MAXDEPTH(' + v.maxdepth + ')'); if (+v.maxmsgl !== 4194304) p.push('MAXMSGL(' + v.maxmsgl + ')'); p.push('DEFPSIST(' + v.defpsist + ')');
        if (+v.defprty) p.push('DEFPRTY(' + v.defprty + ')'); if (v.share === 'NOSHARE') p.push('NOSHARE'); if (v.msgdlvsq === 'FIFO') p.push('MSGDLVSQ(FIFO)');
        if (+v.bothresh) p.push('BOTHRESH(' + v.bothresh + ')'); if (v.boqname) p.push('BOQNAME(' + Q(v.boqname) + ')');
        if (t === 'CLUSTER') { p.push('CLUSTER(' + Q(v.cluster) + ')'); p.push('DEFBIND(' + v.defbind + ')'); }
        if (v.trigger) { p.push('TRIGGER TRIGTYPE(' + v.trigtype + ')'); if (v.initq) p.push('INITQ(' + Q(v.initq) + ')'); if (v.trigdata) p.push('TRIGDATA(' + Q(v.trigdata) + ')'); if (v.process) p.push('PROCESS(' + Q(v.process) + ')'); }
        if (v.qdphiev === 'ENABLED') p.push('QDEPTHHI(' + v.qdepthhi + ') QDPHIEV(ENABLED)');
      }
      var out = p.join(' +\n       ');
      if (t === 'DLQ' && v.setdeadq) out += '\nALTER QMGR DEADQ(' + Q(v.name || '<ad>') + ')';
      return out;
    }
    var f = MQ.modal({
      title: like ? 'Kuyruk oluştur (LIKE ' + like.name + ')' : 'Kuyruk oluştur', label: qm.name, help: 'qtype', primary: 'Oluştur', size: 'lg',
      body: '<div class="type-grid">' + QCARDS.map(function (c) { return '<button type="button" class="type-card' + (c[0] === type ? ' sel' : '') + '" data-qt="' + c[0] + '"><b>' + c[1] + '</b><span>' + c[2] + '</span>' + H(c[3]) + '</button>'; }).join('') + '</div><input type="hidden" name="qtype" value="' + type + '"><div id="qfields">' + fields(type) + '</div>' + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, mqsc(v.qtype, v)); },
      onOpen: function (f) {
        f.querySelector('.type-grid').addEventListener('click', function (e) {
          if (e.target.closest('.hq')) return;
          var b = e.target.closest('[data-qt]'); if (!b) return;
          var cs = f.querySelectorAll('[data-qt]'); for (var i = 0; i < cs.length; i++) cs[i].classList.toggle('sel', cs[i] === b);
          f.querySelector('[name=qtype]').value = b.getAttribute('data-qt');
          var nm = f.querySelector('[name=name]').value;
          f.querySelector('#qfields').innerHTML = fields(b.getAttribute('data-qt'));
          f.querySelector('[name=name]').value = nm;
          MQ.setPreview(f, mqsc(b.getAttribute('data-qt'), MQ.vals(f)));
        });
      },
      onSubmit: function (f, v) {
        var t = v.qtype, err = MQ.validName(v.name); if (err) return MQ.invalid(f, 'name', err);
        if (exists(qm, v.name)) return MQ.invalid(f, 'name', 'AMQ8150E: IBM MQ object already exists. (Var olanı değiştirmek için REPLACE kullanılır.)');
        if (/^SYSTEM\./.test(v.name)) return MQ.invalid(f, 'name', 'SYSTEM. ile başlayan adlar IBM MQ\'ya ayrılmıştır; kendi nesneleriniz için kullanmayın.');
        if (t === 'QREMOTE' && !v.rqmname) return MQ.invalid(f, 'rqmname', 'RQMNAME zorunludur (MQRC_UNKNOWN_REMOTE_Q_MGR 2087 alırsınız).');
        if (t === 'QALIAS' && !v.target) return MQ.invalid(f, 'target', 'TARGET zorunludur.');
        var md = parseInt(v.maxdepth, 10); if (v.maxdepth !== undefined && (isNaN(md) || md < 0 || md > 999999999)) return MQ.invalid(f, 'maxdepth', 'MAXDEPTH 0 - 999999999 arasında olmalıdır.');
        var ml = parseInt(v.maxmsgl, 10); if (v.maxmsgl !== undefined && (isNaN(ml) || ml < 0 || ml > 104857600)) return MQ.invalid(f, 'maxmsgl', 'MAXMSGL en fazla 104857600 (100 MB) olabilir.');
        var dp = parseInt(v.defprty, 10); if (v.defprty !== undefined && (dp < 0 || dp > 9)) return MQ.invalid(f, 'defprty', 'DEFPRTY 0 - 9 arasında olmalıdır.');
        if (v.trigger && t !== 'XMITQ' && !v.initq) return MQ.invalid(f, 'initq', 'Triggering için INITQ gereklidir; aksi halde trigger mesajı üretilemez.');
        var base = like ? MQ.clone(like) : MQ.clone(MQ.findQ(qm, 'SYSTEM.DEFAULT.LOCAL.QUEUE') || {});
        var nq = Object.assign(base, { name: v.name, system: false, descr: v.descr || '', curdepth: 0, ipprocs: 0, opprocs: 0, messages: null, lput: '', lget: '', msgage: 0, created: MQ.now(), altered: MQ.now(), role: undefined });
        nq.type = { QLOCAL: 'QLOCAL', XMITQ: 'QLOCAL', DLQ: 'QLOCAL', INITQ: 'QLOCAL', CLUSTER: 'QLOCAL', QREMOTE: 'QREMOTE', QALIAS: 'QALIAS', QMODEL: 'QMODEL' }[t];
        nq.usage = t === 'XMITQ' ? 'XMITQ' : 'NORMAL';
        ['rname', 'rqmname', 'xmitq', 'target', 'targtype', 'deftype', 'defpsist', 'share', 'msgdlvsq', 'boqname', 'trigtype', 'initq', 'trigdata', 'process', 'qdphiev', 'cluster', 'defbind', 'put', 'get'].forEach(function (k) { if (v[k] !== undefined) nq[k] = v[k]; });
        ['maxdepth', 'maxmsgl', 'defprty', 'bothresh', 'qdepthhi'].forEach(function (k) { if (v[k] !== undefined) nq[k] = parseInt(v[k], 10) || 0; });
        nq.trigger = !!v.trigger; if (t === 'INITQ') nq.role = 'initq';
        if (t !== 'CLUSTER' && !like) nq.cluster = '';
        qm.queues.push(nq);
        if (t === 'DLQ' && v.setdeadq) qm.attrs.DEADQ = v.name;
        MQ.addEvent(qm, 'Config Create', 'Configuration', v.name, 'MQRC_CONFIG_CREATE_OBJECT (2367)', 'Info', 'DEFINE ' + nq.type);
        var cmd = f.querySelector('[data-preview]').textContent;
        MQ.save(); MQ.go(MQ.qLink(qm.name, v.name)); MQ.refresh();
        MQ.toast('', 'Kuyruk oluşturuldu (simülasyon)', 'AMQ8006I: IBM MQ queue created.' + (t === 'CLUSTER' ? '<br>Kuyruk, full repository\'ler aracılığıyla cluster üyelerine duyurulur.' : ''), cmd);
      }
    });
  };
  A.deleteQueue = function (qm, q) {
    var loc = q.type === 'QLOCAL';
    if (loc && (q.ipprocs || q.opprocs)) { MQ.toast('err', 'Kuyruk silinemedi', 'AMQ8148E: IBM MQ object in use. Kuyruk ' + (q.ipprocs + q.opprocs) + ' uygulama handle\'ı tarafından açık (IPPROCS=' + q.ipprocs + ', OPPROCS=' + q.opprocs + ').', 'DELETE QLOCAL(' + Q(q.name) + ')'); return; }
    if (q.name === qm.attrs.DEADQ) { MQ.toast('err', 'Kuyruk silinemedi', 'Bu kuyruk queue manager\'ın DEADQ değeri olarak tanımlı. Önce ALTER QMGR DEADQ ile değiştirin.'); return; }
    if (q.usage === 'XMITQ' && qm.channels.some(function (c) { return c.xmitq === q.name && c.status === 'Running'; })) { MQ.toast('err', 'Kuyruk silinemedi', 'AMQ8148E: IBM MQ object in use. Çalışan bir channel bu transmission queue\'yu kullanıyor.'); return; }
    MQ.modal({ title: q.name + ' silinsin mi?', label: qm.name, help: 'deleteq', primary: 'Sil', danger: true, size: 'sm',
      body: (q.system ? '<div class="notice err">' + I('error') + '<div class="grow"><b>Bu bir sistem kuyruğu.</b> Sistem kuyruklarını silmek queue manager\'ın düzgün çalışmasını bozabilir.</div></div>' : '') +
        (loc && q.curdepth ? F.radio({ name: 'purge', label: 'Kuyrukta ' + MQ.fmt(q.curdepth) + ' mesaj var', help: 'deleteq', options: [['NOPURGE', 'NOPURGE (mesaj varsa silme)'], ['PURGE', 'PURGE (mesajlarla birlikte sil)']], value: 'NOPURGE' }) : '') + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DELETE ' + q.type + '(' + Q(q.name) + ')' + (v.purge === 'PURGE' ? ' PURGE' : '')); },
      onSubmit: function (f, v) {
        if (loc && q.curdepth && v.purge !== 'PURGE') { MQ.toast('err', 'Kuyruk silinemedi', 'AMQ8143E: IBM MQ queue not empty. PURGE seçeneğini kullanın veya önce kuyruğu boşaltın.', 'DELETE QLOCAL(' + Q(q.name) + ')'); return false; }
        qm.queues.splice(qm.queues.indexOf(q), 1);
        MQ.addEvent(qm, 'Config Delete', 'Configuration', q.name, 'MQRC_CONFIG_DELETE_OBJECT (2369)', 'Info', 'DELETE ' + q.type);
        var cmd = f.querySelector('[data-preview]').textContent;
        MQ.save(); MQ.go('#/qm/' + MQ.enc(qm.name) + '/queues'); MQ.refresh(); MQ.toast('', 'Kuyruk silindi (simülasyon)', 'AMQ8007I: IBM MQ queue deleted.', cmd);
      } });
  };

  /* ---------- mesaj teslimi (kuyruk çözümleme) */
  function deliver(qm, qname, msg, trail) {
    var q = MQ.findQ(qm, qname);
    var dlq = function (code, rc) {
      var d = MQ.findQ(qm, qm.attrs.DEADQ);
      if (!d) { trail.push('⚠ ' + qm.name + ' üzerinde DEADQ tanımlı değil: channel durur (mesaj teslim edilemez).'); return false; }
      var m = MQ.clone(msg); m.format = 'MQDEAD'; m.dlh = { reason: code + ' (' + rc + ')', destq: qname, destqmgr: qm.name, putapplname: 'amqrmppa' };
      m.body = '[MQDLH] Reason=' + code + ' (' + rc + ')\n        DestQName=' + qname + '\n        DestQMgrName=' + qm.name + '\n[Orijinal veri]\n' + msg.body; m.size = m.body.length;
      MQ.ensureMsgs(qm, d); d.messages.push(m); d.curdepth++; d.lput = MQ.now();
      trail.push('↳ ' + qm.name + ': ' + rc + ' nedeniyle mesaj dead-letter queue\'ya (' + d.name + ') yazıldı.');
      return true;
    };
    if (!q) return dlq('2085', 'MQRC_UNKNOWN_OBJECT_NAME');
    if (q.type === 'QALIAS') return deliver(qm, q.target, msg, trail);
    if (q.type !== 'QLOCAL') return dlq('2085', 'MQRC_UNKNOWN_OBJECT_NAME');
    if (q.put === 'DISABLED') return dlq('2051', 'MQRC_PUT_INHIBITED');
    if (q.curdepth >= q.maxdepth) return dlq('2053', 'MQRC_Q_FULL');
    MQ.ensureMsgs(qm, q); q.messages.push(msg); q.curdepth++; q.lput = MQ.now();
    trail.push('✓ ' + qm.name + ' / ' + q.name + ' kuyruğuna teslim edildi (yeni derinlik: ' + q.curdepth + ').');
    afterPut(qm, q, trail);
    return true;
  }
  function afterPut(qm, q, trail) {
    if (q.trigger && q.trigtype !== 'NONE' && q.initq && q.usage !== 'XMITQ') {
      var fire = q.trigtype === 'EVERY' || (q.trigtype === 'FIRST' && q.curdepth === 1 && q.ipprocs === 0) || (q.trigtype === 'DEPTH' && q.curdepth >= q.trigdpth);
      var iq = MQ.findQ(qm, q.initq);
      if (fire && iq) {
        trail.push('⚡ Trigger koşulu sağlandı (TRIGTYPE ' + q.trigtype + '): queue manager ' + q.initq + ' kuyruğuna bir trigger mesajı (MQTM) yazdı.');
        if (iq.ipprocs > 0 && q.process) {
          var proc = qm.processes.filter(function (p) { return p.name === q.process; })[0];
          trail.push('⚡ Trigger monitor (runmqtrm) MQTM\'yi okudu ve ' + q.process + ' tanımındaki uygulamayı başlattı: ' + (proc ? proc.applicid : '?'));
          setTimeout(function () { var n = q.curdepth; q.curdepth = 0; q.messages = []; q.lget = MQ.now(); MQ.save(); MQ.redrawTables(); MQ.toast('info', 'Tetiklenen uygulama çalıştı (simülasyon)', E(proc ? proc.applicid : q.process) + ' ' + E(q.name) + ' kuyruğundaki ' + n + ' mesajı işledi ve kapandı.'); if (/\/queue\//.test(location.hash)) MQ.refresh(); }, 2500);
        } else trail.push('⚠ Initiation queue\'yu dinleyen trigger monitor yok (IPPROCS=0); uygulama başlatılamaz.');
      }
    }
    if (MQ.pct(q.curdepth, q.maxdepth) >= q.qdepthhi && q.qdphiev === 'ENABLED' && qm.attrs.PERFMEV === 'ENABLED') { MQ.addEvent(qm, 'Queue Depth High', 'Performance', q.name, 'MQRC_Q_DEPTH_HIGH (2224)', 'Warning', 'Derinlik QDEPTHHI eşiğini aştı.'); trail.push('📈 QDEPTHHI aşıldı: SYSTEM.ADMIN.PERFM.EVENT kuyruğuna performance event yazıldı.'); }
  }
  function transmit(qm, xq, trail) {
    var ch = qm.channels.filter(function (c) { return c.xmitq === xq.name && (c.chltype === 'SDR' || c.chltype === 'SVR'); })[0];
    if (!ch) { trail.push('⚠ ' + xq.name + ' transmission queue\'sunu kullanan sender/server channel yok; mesaj bekliyor.'); return; }
    if (ch.status !== 'Running') {
      if (xq.trigger && ch.status === 'Inactive') { trail.push('⚡ Transmission queue tetiklendi (SYSTEM.CHANNEL.INITQ): channel initiator ' + ch.name + ' kanalını başlatmayı deniyor.'); setTimeout(function () { A.startChannel(qm, ch, true); }, 600); return; }
      trail.push('⏸ Channel ' + ch.name + ' ' + ch.status.toUpperCase() + ' durumunda; mesaj ' + xq.name + ' kuyruğunda bekliyor.'); return;
    }
    trail.push('→ Channel ' + ch.name + ' (Running) mesajı ' + ch.conname + ' adresine iletiyor…');
    setTimeout(function () { drain(qm, ch); MQ.save(); MQ.redrawTables(); }, 1200);
  }
  function drain(qm, ch) {
    var xq = MQ.findQ(qm, ch.xmitq); if (!xq || !xq.curdepth) return;
    var tq = qmByHost(ch.conname), msgs = MQ.ensureMsgs(qm, xq).slice(), n = xq.curdepth, trail = [];
    if (tq && MQ.isUp(tq)) {
      msgs.forEach(function (m) {
        var dest = m.xqh || { rname: 'APP.GUNSONU.IN', rqmname: tq.name };
        var mm = MQ.clone(m); delete mm.xqh; mm.format = 'MQSTR'; if (mm.body.indexOf('[MQXQH]') === 0) mm.body = mm.body.split('\n').slice(3).join('\n'); mm.size = mm.body.length;
        deliver(tq, dest.rname, mm, trail);
      });
      var extra = n - msgs.length; if (extra > 0) { var tgq = MQ.findQ(tq, 'APP.GUNSONU.IN'); if (tgq) { tgq.curdepth += extra; tgq.lput = MQ.now(); } }
    }
    xq.curdepth = 0; xq.messages = []; xq.lget = MQ.now();
    ch.st = Object.assign(ch.st || {}, { msgs: ((ch.st && ch.st.msgs) || 0) + n, lstmsg: MQ.now() });
    MQ.toast('', ch.name + ': ' + n + ' mesaj iletildi (simülasyon)', E(xq.name) + ' boşaltıldı → ' + E(tq ? tq.name : ch.conname) + (trail.length ? '<br>' + trail.slice(0, 3).map(E).join('<br>') : ''));
    if (/\/queue\/|\/network/.test(location.hash)) MQ.refresh();
  }

  A.putMessage = function (qm, q) {
    if (q.type === 'QREMOTE' && !q.rname) { MQ.toast('info', 'Queue manager alias', E(q.name) + ' bir queue manager alias tanımıdır (RNAME boş). Doğrudan put edilmez; uygulamalar MQOD içinde ObjectQMgrName=' + E(q.name) + ' kullanır ve mesaj ' + E(q.rqmname) + '\'e yönlendirilir.'); return; }
    var ql = q.type === 'QCLUSTER' ? q.clusqmgr.split(',').map(function (s) { return s.trim(); }) : null;
    MQ.modal({ title: 'Mesaj koy (MQPUT)', label: qm.name + ' / ' + q.name, help: 'mqput', primary: 'Put', size: 'lg',
      body: '<div class="notice">' + I('info') + '<div class="grow">' + ({ QLOCAL: 'Mesaj doğrudan bu local queue\'ya yazılır.', QALIAS: 'Alias çözülür: mesaj hedef ' + (q.targtype === 'TOPIC' ? 'topic\'e yayınlanır (' + E(q.target) + ').' : 'kuyruğa (' + E(q.target) + ') yazılır.'), QREMOTE: 'Mesaj önce transmission queue\'ya (' + E(q.xmitq || q.rqmname) + ') yazılır, ardından channel ile ' + E(q.rqmname) + ' / ' + E(q.rname) + ' kuyruğuna iletilir.', QCLUSTER: 'Cluster workload algoritması hedef instance\'ı seçer: ' + E(q.clusqmgr) + '. Mesaj SYSTEM.CLUSTER.TRANSMIT.QUEUE üzerinden iletilir.' }[q.type] || '') + '</div></div>' +
        F.area({ name: 'body', label: 'Mesaj verisi (payload)', help: 'mqmd.format', value: '{\n  "islemId": "TRX-' + Date.now() + '",\n  "tutar": 150.00,\n  "paraBirimi": "TRY"\n}', rows: 6 }) +
        '<div class="frow3">' + F.select({ name: 'persist', label: 'Persistence', help: 'persistence', options: [['AS_Q_DEF', 'Kuyruk varsayılanı (' + q.defpsist + ')'], ['YES', 'Persistent'], ['NO', 'Not persistent']], value: 'AS_Q_DEF' }) +
        F.text({ name: 'priority', label: 'Priority (0-9, -1 = kuyruk varsayılanı)', help: 'priority', value: '-1', type: 'number' }) +
        F.text({ name: 'expiry', label: 'Expiry (1/10 saniye, -1 = sınırsız)', help: 'expiry', value: '-1', type: 'number' }) + '</div>' +
        '<div class="frow3">' + F.select({ name: 'format', label: 'Format', help: 'mqmd.format', options: ['MQSTR', 'MQHRF2', '(none)'], value: 'MQSTR' }) + F.text({ name: 'replytoq', label: 'Reply-to queue', help: 'mqmd.replyto', value: '' }) + F.text({ name: 'correlid', label: 'Correlation ID (hex, opsiyonel)', help: 'mqmd.correlid', value: '' }) + '</div>' +
        F.check({ name: 'syncpt', label: 'Syncpoint altında put et (MQPMO_SYNCPOINT) ve commit et', help: 'syncpoint', value: true }) +
        F.preview('Eşdeğer örnek program', 'amqsput'),
      onInput: function (f, v) { MQ.setPreview(f, (q.type === 'QCLUSTER' ? '# Cluster queue: uygulama QM\'e bağlanıp kuyruk adını açar\n' : '') + 'echo \'' + v.body.replace(/\n\s*/g, ' ').slice(0, 80) + '\' | /opt/mqm/samp/bin/amqsput ' + q.name + ' ' + qm.name + '\n\n# MQOPEN(' + q.name + ', MQOO_OUTPUT)\n# MQPUT(MQMD{Persistence=' + (v.persist === 'AS_Q_DEF' ? 'MQPER_PERSISTENCE_AS_Q_DEF' : v.persist === 'YES' ? 'MQPER_PERSISTENT' : 'MQPER_NOT_PERSISTENT') + ', Priority=' + (v.priority === '-1' ? 'MQPRI_PRIORITY_AS_Q_DEF' : v.priority) + ', Expiry=' + (v.expiry === '-1' ? 'MQEI_UNLIMITED' : v.expiry) + '}, MQPMO' + (v.syncpt ? '{MQPMO_SYNCPOINT}' : '{MQPMO_NO_SYNCPOINT}') + ')' + (v.syncpt ? '\n# MQCMIT' : '')); },
      onSubmit: function (f, v) {
        var pr = parseInt(v.priority, 10); if (pr < -1 || pr > 9) return MQ.invalid(f, 'priority', 'Priority 0-9 arasında olmalıdır (MQRC_PRIORITY_ERROR 2050).');
        var len = new Blob([v.body]).size;
        var fail = function (rc, msg) { MQ.toast('err', 'MQPUT başarısız: ' + rc, msg); return false; };
        if (q.put === 'DISABLED') return fail('MQRC_PUT_INHIBITED (2051)', E(q.name) + ' üzerinde PUT(DISABLED).');
        var trail = [];
        var msg = { msgid: MQ.msgId(qm.name), correlid: (v.correlid || '').toUpperCase().replace(/[^0-9A-F]/g, '').padEnd(48, '0').slice(0, 48), puttime: MQ.now(), putappl: 'IBM MQ Console', userid: MQ.state.user.name, format: v.format === '(none)' ? '' : v.format,
          persist: (v.persist === 'YES' || v.persist === 'AS_Q_DEF' && q.defpsist === 'YES') ? 'Persistent' : 'Not persistent', priority: pr === -1 ? q.defprty : pr, expiry: parseInt(v.expiry, 10), msgtype: v.replytoq ? 'Request' : 'Datagram', replytoq: v.replytoq, replytoqmgr: v.replytoq ? qm.name : '', encoding: 546, ccsid: 1208, backout: 0, body: v.body, size: len };
        if (q.type === 'QLOCAL') {
          if (len > Math.min(q.maxmsgl, qm.attrs.MAXMSGL)) return fail('MQRC_MSG_TOO_BIG_FOR_Q (2030)', 'Mesaj boyutu (' + len + ' bayt) kuyruğun MAXMSGL değerini aşıyor.');
          if (q.curdepth >= q.maxdepth) { MQ.addEvent(qm, 'Queue Full', 'Performance', q.name, 'MQRC_Q_FULL (2053)', 'Error', 'Console üzerinden yapılan put reddedildi.'); MQ.save(); return fail('MQRC_Q_FULL (2053)', 'Kuyruk MAXDEPTH (' + MQ.fmt(q.maxdepth) + ') değerine ulaştı. Doğrudan MQPUT yapan uygulama bu hatayı alır; mesaj DLQ\'ya gitmez. (DLQ\'ya yönlendirme yalnızca kanallar/MCA tarafından yapılır.)'); }
          deliver(qm, q.name, msg, trail);
        } else if (q.type === 'QALIAS') {
          if (q.targtype === 'TOPIC') { var t = qm.topics.filter(function (x) { return x.name === q.target; })[0]; if (!t) return fail('MQRC_UNKNOWN_ALIAS_BASE_Q (2082)', 'Hedef topic nesnesi bulunamadı.'); publishTo(qm, t.topicstr, msg, trail); }
          else { var tq = MQ.findQ(qm, q.target); if (!tq) return fail('MQRC_UNKNOWN_ALIAS_BASE_Q (2082)', 'Alias hedefi ' + E(q.target) + ' bulunamadı.'); if (tq.type === 'QLOCAL' && tq.curdepth >= tq.maxdepth) return fail('MQRC_Q_FULL (2053)', 'Hedef kuyruk dolu.'); if (tq.put === 'DISABLED') return fail('MQRC_PUT_INHIBITED (2051)', 'Hedef kuyrukta PUT(DISABLED).'); trail.push('Alias çözüldü: ' + q.name + ' → ' + tq.name); deliver(qm, tq.name, msg, trail); }
        } else if (q.type === 'QREMOTE') {
          var xn = q.xmitq || (MQ.findQ(qm, q.rqmname) ? q.rqmname : qm.attrs.DEFXMITQ);
          var xq = MQ.findQ(qm, xn);
          if (!xq || xq.usage !== 'XMITQ') return fail('MQRC_UNKNOWN_REMOTE_Q_MGR (2087)', 'Uzak queue manager için transmission queue bulunamadı (XMITQ, RQMNAME adlı kuyruk veya DEFXMITQ).');
          if (xq.curdepth >= xq.maxdepth) return fail('MQRC_Q_FULL (2053)', 'Transmission queue dolu.');
          var xm = MQ.clone(msg); xm.format = 'MQXMIT'; xm.xqh = { rname: q.rname, rqmname: q.rqmname }; xm.body = '[MQXQH] RemoteQName=' + q.rname + '\n        RemoteQMgrName=' + q.rqmname + '\n[MQMD + uygulama verisi]\n' + msg.body;
          MQ.ensureMsgs(qm, xq); xq.messages.push(xm); xq.curdepth++; xq.lput = MQ.now();
          trail.push('✓ Mesaj, iletim başlığı (MQXQH) eklenerek transmission queue ' + xq.name + ' kuyruğuna yazıldı.');
          transmit(qm, xq, trail);
        } else if (q.type === 'QCLUSTER') {
          MQ._clwl = (MQ._clwl || 0) + 1; var pick = ql[MQ._clwl % ql.length]; var tqm = MQ.qm(pick);
          trail.push('CLWL: ' + ql.length + ' uygun instance arasından ' + pick + ' seçildi (round-robin; CLWLPRTY/CLWLRANK eşit, DEFBIND(' + q.defbind + ')).');
          if (!tqm || !MQ.isUp(tqm)) trail.push('⚠ ' + pick + ' erişilemez: mesaj SYSTEM.CLUSTER.TRANSMIT.QUEUE\'da bekler.');
          else { trail.push('→ SYSTEM.CLUSTER.TRANSMIT.QUEUE → CLUSSDR TO.CLS.ODEME.' + pick); deliver(tqm, q.name, msg, trail); }
        }
        MQ.save(); MQ.refresh();
        MQ.toast('', 'Mesaj put edildi (simülasyon)', 'MQPUT tamamlandı (MQCC_OK).' + (trail.length ? '<br>' + trail.map(E).join('<br>') : ''), f.querySelector('[data-preview]').textContent.split('\n')[0]);
      } });
  };
  function topicMatch(sub, pub) {
    var s = sub.split('/'), p = pub.split('/');
    for (var i = 0; i < s.length; i++) { if (s[i] === '#') return true; if (i >= p.length) return false; if (s[i] !== '+' && s[i] !== p[i]) return false; }
    return s.length === p.length;
  }
  function publishTo(qm, topicstr, msg, trail) {
    var subs = qm.subs.filter(function (s) { return s.topicstr && topicMatch(s.topicstr, topicstr); });
    if (!subs.length) { trail.push('Topic "' + topicstr + '" için eşleşen abone yok; mesaj (retained değilse) atılır.'); return; }
    subs.forEach(function (s) {
      s.msgs = (s.msgs || 0) + 1; s.lastmsg = MQ.now();
      var dq = MQ.findQ(qm, s.dest);
      if (dq && dq.type === 'QLOCAL') deliver(qm, s.dest, MQ.clone(msg), trail);
      else if (dq && dq.type === 'QALIAS') deliver(qm, dq.target, MQ.clone(msg), trail);
      else trail.push('✓ ' + s.name + ' (' + (s.durable === 'YES' ? 'durable' : 'non-durable') + ') → managed queue ' + s.dest);
    });
    var t = qm.topics.filter(function (x) { return x.topicstr && topicstr.indexOf(x.topicstr) === 0; })[0]; if (t) t.msgs = (t.msgs || 0) + 1;
    trail.unshift('Publish: "' + topicstr + '" → ' + subs.length + ' aboneye kopya dağıtıldı.');
  }
  A.publish = function (qm, t) {
    MQ.modal({ title: 'Test mesajı yayınla', label: t.name + ' (' + t.topicstr + ')', help: 'pubsub', primary: 'Publish',
      body: F.text({ name: 'topicstr', label: 'Topic string', help: 'topicstring', value: t.topicstr }) + F.area({ name: 'body', label: 'Mesaj', help: 'mqmd.format', value: '{"musteriNo": 123456, "mesaj": "Test bildirimi"}', rows: 4 }) + F.check({ name: 'retain', label: 'Retained publication (MQPMO_RETAIN)', help: 'retained', value: false }) + F.preview('Eşdeğer örnek program', 'amqspub'),
      onInput: function (f, v) { MQ.setPreview(f, '/opt/mqm/samp/bin/amqspub \'' + v.topicstr + '\' ' + qm.name); },
      onSubmit: function (f, v) {
        if (t.pub !== 'ENABLED') { MQ.toast('err', 'MQPUT başarısız: MQRC_PUT_INHIBITED (2051)', 'Topic PUB(DISABLED).'); return false; }
        var trail = []; publishTo(qm, v.topicstr, { msgid: MQ.msgId(qm.name), correlid: '0'.repeat(48), puttime: MQ.now(), putappl: 'IBM MQ Console', userid: MQ.state.user.name, format: 'MQSTR', persist: t.defpsist === 'YES' ? 'Persistent' : 'Not persistent', priority: 0, expiry: -1, msgtype: 'Datagram', replytoq: '', replytoqmgr: '', encoding: 546, ccsid: 1208, backout: 0, body: v.body, size: v.body.length }, trail);
        if (v.retain) trail.push('Retained: son yayın SYSTEM.RETAINED.PUB.QUEUE\'da saklanır; yeni aboneler hemen alır.');
        done('Yayın yapıldı (simülasyon)', trail.map(E).join('<br>'));
      } });
  };
  A.getMessage = function (qm, q, specific) {
    var target = q.type === 'QALIAS' ? MQ.findQ(qm, q.target) : q;
    if (q.type === 'QALIAS' && q.targtype === 'TOPIC') { MQ.toast('err', 'MQOPEN başarısız', 'TARGTYPE(TOPIC) olan bir alias yalnızca yayın (output) için açılabilir. MQRC_OPTION_NOT_VALID_FOR_TYPE (2045)'); return; }
    if (!target || target.type !== 'QLOCAL') { MQ.toast('err', 'MQGET başarısız', 'Hedef local queue bulunamadı.'); return; }
    if (q.get === 'DISABLED' || target.get === 'DISABLED') { MQ.toast('err', 'MQGET başarısız: MQRC_GET_INHIBITED (2016)', E(q.name) + ' üzerinde GET(DISABLED).'); return; }
    var msgs = MQ.ensureMsgs(qm, target);
    if (!msgs.length) { MQ.toast('warn', 'MQGET: MQRC_NO_MSG_AVAILABLE (2033)', 'Kuyrukta alınacak mesaj yok.'); return; }
    var m = specific || (target.msgdlvsq === 'FIFO' ? msgs.slice().sort(function (a, b) { return a.puttime < b.puttime ? -1 : 1; })[0] : msgs.slice().sort(function (a, b) { return b.priority - a.priority || (a.puttime < b.puttime ? -1 : 1); })[0]);
    MQ.modal({ title: 'Mesaj al (destructive MQGET)', label: qm.name + ' / ' + q.name, help: 'mqget', primary: 'Get', size: 'lg',
      body: '<div class="notice warn">' + I('warning') + '<div class="grow">Destructive get mesajı kuyruktan <b>kalıcı olarak kaldırır</b>. Yalnızca okumak için Messages sekmesindeki browse görünümünü kullanın.' + H('browse') + '</div></div>' +
        '<dl class="kv"><dt>Message ID</dt><dd class="mono-sm">' + E(m.msgid) + '</dd><dt>Priority / Persistence' + H('priority') + '</dt><dd>' + m.priority + ' / ' + E(m.persist) + '</dd><dt>Backout count' + H('backout') + '</dt><dd>' + m.backout + ' (BOTHRESH=' + target.bothresh + ')</dd></dl>' +
        '<div class="preview-h">Veri</div><pre class="msg-body">' + E(m.body) + '</pre>' +
        F.radio({ name: 'outcome', label: 'İşlem sonucu (syncpoint altında get)', help: 'syncpoint', options: [['commit', 'Başarılı işle → MQCMIT'], ['backout', 'Uygulama hatası → MQBACK (rollback)']], value: 'commit' }) + F.preview('Eşdeğer', 'mqget'),
      onInput: function (f, v) { MQ.setPreview(f, '/opt/mqm/samp/bin/amqsget ' + q.name + ' ' + qm.name + '\n\n# MQGET(MQGMO{MQGMO_SYNCPOINT | MQGMO_WAIT}, ' + (target.msgdlvsq === 'FIFO' ? 'FIFO sırası' : 'öncelik sırası (MSGDLVSQ PRIORITY)') + ')\n# ' + (v.outcome === 'backout' ? 'MQBACK  → mesaj kuyruğa geri döner, BackoutCount +1' : 'MQCMIT  → mesaj kalıcı olarak silinir')); },
      onSubmit: function (f, v) {
        if (v.outcome === 'backout') {
          m.backout++;
          var moved = target.bothresh > 0 && m.backout >= target.bothresh && target.boqname && MQ.findQ(qm, target.boqname);
          if (moved) { msgs.splice(msgs.indexOf(m), 1); target.curdepth--; var bq = MQ.findQ(qm, target.boqname); MQ.ensureMsgs(qm, bq); bq.messages.push(m); bq.curdepth++; bq.lput = MQ.now(); }
          done(moved ? 'Mesaj backout kuyruğuna taşındı (simülasyon)' : 'İşlem geri alındı (MQBACK)', moved ? 'BackoutCount (' + m.backout + ') ≥ BOTHRESH (' + target.bothresh + '). Uygulama (ör. JMS/MDB) mesajı tekrar işlemek yerine ' + E(target.boqname) + ' kuyruğuna taşıdı. <b>Not:</b> Bu taşımayı queue manager değil, uygulama/istemci kütüphanesi yapar.' : 'Mesaj kuyrukta kaldı; BackoutCount = ' + m.backout + (target.bothresh ? ' / BOTHRESH ' + target.bothresh : ' (BOTHRESH tanımlı değil — poison mesaj sonsuz döngüye girebilir!)'), null, moved ? 'warn' : 'info');
          return;
        }
        msgs.splice(msgs.indexOf(m), 1); target.curdepth--; target.lget = MQ.now();
        done('Mesaj alındı (simülasyon)', 'MQGET + MQCMIT tamamlandı. Yeni derinlik: ' + target.curdepth, 'amqsget ' + q.name + ' ' + qm.name);
      } });
  };
  A.clearQueue = function (qm, q) {
    var open = q.ipprocs + q.opprocs;
    MQ.modal({ title: q.name + ' temizlensin mi?', label: qm.name, help: 'clearq', primary: 'Temizle', danger: true, size: 'sm',
      body: '<p>Kuyruktaki <b>' + MQ.fmt(q.curdepth) + '</b> mesaj kalıcı olarak silinecek.</p>' + (open ? '<div class="notice warn">' + I('warning') + '<div class="grow">Kuyruk şu anda ' + open + ' uygulama tarafından açık. <code>CLEAR QLOCAL</code> komutu bu durumda <b>AMQ8148E: IBM MQ object in use</b> hatası verir.</div></div>' + F.radio({ name: 'method', label: 'Yöntem', help: 'clearq', options: [['clear', 'CLEAR QLOCAL (başarısız olacak)'], ['get', 'Destructive MQGET döngüsü (amqsget / dmpmqmsg)']], value: 'get' }) : '<input type="hidden" name="method" value="clear">') + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, v.method === 'get' ? '# Kuyruk açıkken mesajları tek tek almak:\ndmpmqmsg -m ' + qm.name + ' -I ' + q.name + ' -f /tmp/' + q.name + '.bak   # (yedek + silme)' : 'CLEAR QLOCAL(' + Q(q.name) + ')'); },
      onSubmit: function (f, v) {
        if (v.method === 'clear' && open) { MQ.toast('err', 'Kuyruk temizlenemedi', 'AMQ8148E: IBM MQ object in use. (IPPROCS=' + q.ipprocs + ', OPPROCS=' + q.opprocs + ')', 'CLEAR QLOCAL(' + Q(q.name) + ')'); return false; }
        var n = q.curdepth; q.curdepth = 0; q.messages = []; q.lget = MQ.now(); q.msgage = 0;
        done('Kuyruk temizlendi (simülasyon)', v.method === 'get' ? n + ' mesaj destructive get ile alındı.' : 'AMQ8022I: IBM MQ queue cleared. (' + n + ' mesaj)', f.querySelector('[data-preview]').textContent);
      } });
  };
  A.msgDetail = function (qm, q, m) {
    var row = function (l, v, h) { return '<dt>' + l + H(h) + '</dt><dd class="mono-sm">' + E(v === '' || v === undefined ? '-' : v) + '</dd>'; };
    MQ.modal({ title: 'Mesaj ayrıntıları', label: q.name, help: 'mqmd', primary: 'Bu mesajı al (Get)', cancel: 'Kapat', size: 'lg',
      body: '<dl class="kv">' + row('MsgId', m.msgid, 'mqmd.msgid') + row('CorrelId', m.correlid, 'mqmd.correlid') + row('Format', m.format, 'mqmd.format') + row('Persistence', m.persist, 'persistence') + row('Priority', m.priority, 'priority') +
        row('Expiry', m.expiry === -1 ? 'MQEI_UNLIMITED (-1)' : m.expiry + ' (1/10 sn)', 'expiry') + row('MsgType', m.msgtype, 'mqmd.msgtype') + row('ReplyToQ / ReplyToQMgr', (m.replytoq || '-') + ' / ' + (m.replytoqmgr || '-'), 'mqmd.replyto') + row('PutApplName', m.putappl, 'mqmd.putappl') +
        row('UserIdentifier', m.userid, 'mqmd.userid') + row('PutDate / PutTime', m.puttime + ' (GMT)', 'mqmd.puttime') + row('Encoding / CodedCharSetId', m.encoding + ' / ' + m.ccsid, 'qm.ccsid') + row('BackoutCount', m.backout, 'backout') + row('Boyut', m.size + ' bayt', 'q.maxmsgl') + '</dl>' +
        (m.dlh ? '<div class="preview-h">Dead-letter header (MQDLH)' + H('mqdlh') + '</div><dl class="kv">' + row('Reason', m.dlh.reason, 'reasoncode') + row('DestQName', m.dlh.destq, 'mqdlh') + row('DestQMgrName', m.dlh.destqmgr, 'mqdlh') + row('PutApplName', m.dlh.putapplname, 'mqdlh') + '</dl>' : '') +
        '<div class="preview-h">Mesaj verisi</div><pre class="msg-body">' + E(m.body) + '</pre>',
      onSubmit: function () { setTimeout(function () { A.getMessage(qm, q, m); }, 10); } });
  };

  /* ================================================== CHANNELS */
  var CHT = [['SDR', 'Sender'], ['RCVR', 'Receiver'], ['SVR', 'Server'], ['RQSTR', 'Requester'], ['SVRCONN', 'Server-connection'], ['CLNTCONN', 'Client-connection'], ['CLUSSDR', 'Cluster-sender'], ['CLUSRCVR', 'Cluster-receiver']];
  A.createChannel = function (qm, type) {
    var xmitqs = qm.queues.filter(function (q) { return q.usage === 'XMITQ' && !q.system; }).map(function (q) { return q.name; });
    function fields(t) {
      var has = function (arr) { return arr.indexOf(t) >= 0; }, s = '';
      s += '<div class="frow">' + F.text({ name: 'name', label: 'Channel name (en fazla 20 karakter)', attr: 'CHANNEL', help: 'chname', maxlength: 20, placeholder: t === 'SDR' ? qm.name + '.HEDEFQM' : t === 'SVRCONN' ? 'APP.XYZ.SVRCONN' : '' }) + F.text({ name: 'descr', label: 'Description', attr: 'DESCR', help: 'ch.descr' }) + '</div>';
      if (has(['SDR', 'SVR', 'RQSTR', 'CLNTCONN', 'CLUSSDR', 'CLUSRCVR'])) s += F.text({ name: 'conname', label: 'Connection name', attr: 'CONNAME', help: 'ch.conname', placeholder: 'host(port) — ör. mqcore01.ornek.local(1414)', hint: t === 'CLUSRCVR' ? 'Bu QM\'in kendi adresi; diğer üyeler buna bağlanır.' : t === 'SVR' ? 'Boş bırakılırsa yalnızca requester tarafından başlatılabilir.' : 'Virgülle ayrılmış birden fazla adres verilebilir (multi-instance için).' });
      if (has(['SDR', 'SVR'])) s += F.select({ name: 'xmitq', label: 'Transmission queue', attr: 'XMITQ', help: 'ch.xmitq', options: [['', '(seçin)']].concat(xmitqs) });
      if (t === 'CLNTCONN') s += F.text({ name: 'qmname', label: 'Queue manager name', attr: 'QMNAME', help: 'ch.qmname', value: qm.name });
      if (has(['CLUSSDR', 'CLUSRCVR'])) s += F.text({ name: 'cluster', label: 'Cluster', attr: 'CLUSTER', help: 'q.cluster', value: qm.cluster ? qm.cluster.name : '' });
      s += F.sec('Güvenlik', 'tls') + '<div class="frow">' + F.select({ name: 'sslciph', label: 'SSL CipherSpec', attr: 'SSLCIPH', help: 'ch.sslciph', options: [['', '(TLS yok)']].concat(MQ.CIPHERS.filter(function (c) { return !/Devre/.test(c.type); }).map(function (c) { return c.name; })), value: 'ANY_TLS12_OR_HIGHER' }) +
        (has(['SVR', 'RCVR', 'RQSTR', 'SVRCONN', 'CLUSRCVR']) ? F.select({ name: 'sslcauth', label: 'SSL client auth', attr: 'SSLCAUTH', help: 'ch.sslcauth', options: ['REQUIRED', 'OPTIONAL'], value: t === 'SVRCONN' ? 'OPTIONAL' : 'REQUIRED' }) : '') +
        F.text({ name: 'sslpeer', label: 'SSL peer (DN filtresi)', attr: 'SSLPEER', help: 'ch.sslpeer', placeholder: 'CN=QMCORE01,O=Ornek Banka' }) +
        (t !== 'CLNTCONN' ? F.text({ name: 'mcauser', label: 'MCA user ID', attr: 'MCAUSER', help: 'ch.mcauser', placeholder: t === 'SVRCONN' ? 'Boş bırakıp CHLAUTH ile eşleme önerilir' : '' }) : '') + '</div>';
      s += F.sec('Gelişmiş', null) + '<div class="frow3">' + F.text({ name: 'hbint', label: 'Heartbeat (sn)', attr: 'HBINT', help: 'ch.hbint', value: 300, type: 'number' });
      if (has(['SDR', 'SVR', 'RCVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR'])) s += F.text({ name: 'batchsz', label: 'Batch size', attr: 'BATCHSZ', help: 'ch.batchsz', value: 50, type: 'number' });
      if (has(['SDR', 'SVR', 'SVRCONN', 'CLUSSDR', 'CLUSRCVR'])) s += F.text({ name: 'discint', label: 'Disconnect interval (sn)', attr: 'DISCINT', help: 'ch.discint', value: t === 'SVRCONN' ? 0 : 6000, type: 'number' });
      if (has(['SVRCONN', 'CLNTCONN'])) s += F.text({ name: 'sharecnv', label: 'Sharing conversations', attr: 'SHARECNV', help: 'ch.sharecnv', value: 10, type: 'number' });
      if (t === 'SVRCONN') s += F.text({ name: 'maxinst', label: 'Max instances', attr: 'MAXINST', help: 'ch.maxinst', value: 100, type: 'number' }) + F.text({ name: 'maxinstc', label: 'Max instances / client', attr: 'MAXINSTC', help: 'ch.maxinstc', value: 20, type: 'number' });
      return s + '</div>';
    }
    function mqsc(v) {
      var t = v.chltype, p = ['DEFINE CHANNEL(' + Q(v.name || '<ad>') + ') CHLTYPE(' + t + ') TRPTYPE(TCP)'];
      if (v.conname) p.push('CONNAME(' + Q(v.conname) + ')'); if (v.xmitq) p.push('XMITQ(' + Q(v.xmitq) + ')'); if (v.qmname) p.push('QMNAME(' + Q(v.qmname) + ')'); if (v.cluster) p.push('CLUSTER(' + Q(v.cluster) + ')');
      if (v.descr) p.push('DESCR(' + Q(v.descr) + ')'); if (v.sslciph) p.push('SSLCIPH(' + v.sslciph + ')'); if (v.sslcauth && v.sslciph) p.push('SSLCAUTH(' + v.sslcauth + ')'); if (v.sslpeer) p.push('SSLPEER(' + Q(v.sslpeer) + ')'); if (v.mcauser) p.push('MCAUSER(' + Q(v.mcauser) + ')');
      if (v.hbint && +v.hbint !== 300) p.push('HBINT(' + v.hbint + ')'); if (v.batchsz && +v.batchsz !== 50) p.push('BATCHSZ(' + v.batchsz + ')'); if (v.discint !== undefined && v.discint !== '' && +v.discint !== (t === 'SVRCONN' ? 0 : 6000)) p.push('DISCINT(' + v.discint + ')');
      if (v.sharecnv && +v.sharecnv !== 10) p.push('SHARECNV(' + v.sharecnv + ')'); if (v.maxinst) p.push('MAXINST(' + v.maxinst + ')'); if (v.maxinstc) p.push('MAXINSTC(' + v.maxinstc + ')');
      var s = p.join(' +\n       ');
      if (t === 'SVRCONN') s += '\n\n# Önerilen: kanala özel CHLAUTH kuralı\nSET CHLAUTH(' + Q(v.name || '<ad>') + ") TYPE(ADDRESSMAP) ADDRESS('10.0.0.*') USERSRC(CHANNEL) CHCKCLNT(REQUIRED)";
      if (t === 'SDR') s += '\n\n# Karşı QM\'de aynı adla bir RCVR channel tanımlanmalıdır:\n# DEFINE CHANNEL(' + Q(v.name || '<ad>') + ') CHLTYPE(RCVR) TRPTYPE(TCP)';
      return s;
    }
    var f = MQ.modal({ title: 'Channel oluştur', label: qm.name, help: 'channel', primary: 'Oluştur', size: 'lg',
      body: F.select({ name: 'chltype', label: 'Channel type', attr: 'CHLTYPE', help: 'chltype', options: CHT.map(function (c) { return [c[0], c[0] + ' — ' + c[1]]; }), value: type || 'SDR' }) + '<div id="chtypehelp" class="mb16"></div><div id="chfields">' + fields(type || 'SDR') + '</div>' + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, mqsc(v)); },
      onOpen: function (f) {
        var sel = f.querySelector('[name=chltype]');
        var th = function () { f.querySelector('#chtypehelp').innerHTML = '<span class="muted">Bu tür hakkında:</span> ' + H(MQ.chTypeHelp(sel.value)); };
        th();
        sel.addEventListener('change', function () { var n = f.querySelector('[name=name]').value; f.querySelector('#chfields').innerHTML = fields(sel.value); f.querySelector('[name=name]').value = n; th(); MQ.setPreview(f, mqsc(MQ.vals(f))); });
      },
      onSubmit: function (f, v) {
        var t = v.chltype, err = MQ.validName(v.name, 20); if (err) return MQ.invalid(f, 'name', err);
        if (MQ.findCh(qm, v.name)) return MQ.invalid(f, 'name', 'AMQ8150E: IBM MQ object already exists.');
        if (['SDR', 'RQSTR', 'CLNTCONN', 'CLUSSDR'].indexOf(t) >= 0 && !v.conname) return MQ.invalid(f, 'conname', 'Bu channel türü için CONNAME zorunludur.');
        if (v.conname && !/^[^()\s]+(\(\d{1,5}\))?(,[^()\s]+(\(\d{1,5}\))?)*$/.test(v.conname)) return MQ.invalid(f, 'conname', 'CONNAME biçimi: host(port) veya host1(port),host2(port)');
        if (t === 'SDR' && !v.xmitq) return MQ.invalid(f, 'xmitq', 'Sender channel için XMITQ zorunludur (AMQ8204E).');
        if ((t === 'CLUSSDR' || t === 'CLUSRCVR') && !v.cluster) return MQ.invalid(f, 'cluster', 'CLUSTER veya CLUSNL belirtilmelidir.');
        var c = { name: v.name, chltype: t, status: t === 'CLNTCONN' ? 'N/A' : 'Inactive', descr: v.descr || '', conname: v.conname || '', xmitq: v.xmitq || '', qmname: v.qmname || '', cluster: v.cluster || '', trptype: 'TCP', sslciph: v.sslciph || '', sslcauth: v.sslcauth || 'REQUIRED', sslpeer: v.sslpeer || '', certlabl: '', mcauser: v.mcauser || '',
          hbint: +v.hbint || 300, batchsz: +v.batchsz || 50, batchint: 0, batchhb: 0, discint: v.discint !== undefined ? +v.discint : 6000, sharecnv: +v.sharecnv || 10, maxinst: +v.maxinst || 999999999, maxinstc: +v.maxinstc || 999999999,
          mrrty: 10, mrtmr: 1000, shortrty: 10, shorttmr: 60, longrty: 999999999, longtmr: 1200, kaint: 'AUTO', npmspeed: 'FAST', mcatype: 'PROCESS', maxmsgl: 4194304, monchl: 'QMGR', statchl: 'QMGR', clwlprty: 0, clwlrank: 0, clwlwght: 50, netprty: 0, compmsg: 'NONE', comphdr: 'NONE', seqwrap: 999999999, convert: 'NO', usedlq: 'YES', defrecon: 'NO', altered: MQ.now(), inst: null, st: null };
        qm.channels.push(c);
        if (t === 'CLUSRCVR' && !qm.cluster) qm.cluster = { name: v.cluster, role: 'Partial repository' };
        MQ.addEvent(qm, 'Config Create', 'Configuration', v.name, 'MQRC_CONFIG_CREATE_OBJECT (2367)', 'Info', 'DEFINE CHANNEL CHLTYPE(' + t + ')');
        var cmd = f.querySelector('[data-preview]').textContent;
        MQ.save(); MQ.go(MQ.chLink(qm.name, v.name)); MQ.refresh();
        MQ.toast('', 'Channel oluşturuldu (simülasyon)', 'AMQ8014I: IBM MQ channel created.' + (t === 'SVRCONN' && !v.sslciph ? '<br><b>Uyarı:</b> TLS olmadan istemci parolaları ağda açık metin gider.' : ''), cmd.split('\n\n')[0]);
      } });
  };
  function reach(c) {
    var hp = hostPort(c.conname), tq = qmByHost(c.conname);
    if (!tq) return { ok: true, external: true };
    if (!MQ.isUp(tq)) return { ok: false, tq: tq, code: 'AMQ9202E', msg: "Remote host '" + c.conname + "' not available, retry later.", why: tq.name + ' çalışmıyor (' + tq.status + ').' };
    var l = tq.listeners.filter(function (x) { return x.port === hp.port && x.status === 'Running'; })[0];
    if (!l) return { ok: false, tq: tq, code: 'AMQ9202E', msg: "Remote host '" + c.conname + "' not available, retry later.", why: tq.name + ' üzerinde ' + hp.port + ' portunu dinleyen çalışan bir listener yok.' };
    var partnerType = { SDR: ['RCVR', 'RQSTR'], SVR: ['RCVR', 'RQSTR'], RQSTR: ['SDR', 'SVR'], CLUSSDR: ['CLUSRCVR'] }[c.chltype] || [];
    var partner = tq.channels.filter(function (x) { return x.name === c.name && partnerType.indexOf(x.chltype) >= 0; })[0];
    if (!partner && c.chltype !== 'CLUSSDR') return { ok: false, tq: tq, code: 'AMQ9520E', msg: "Channel not defined remotely.", why: tq.name + ' üzerinde ' + c.name + ' adında eşleşen bir channel yok.' };
    if (partner && partner.status === 'Stopped') return { ok: false, tq: tq, code: 'AMQ9533E', msg: "Channel '" + c.name + "' is not currently active.", why: 'Karşı taraftaki channel STOPPED durumda.' };
    if (partner && c.sslciph && partner.sslciph && c.sslciph !== partner.sslciph && c.sslciph.indexOf('ANY_') !== 0 && partner.sslciph.indexOf('ANY_') !== 0) return { ok: false, tq: tq, code: 'AMQ9631E', msg: 'The CipherSpec negotiated during the TLS handshake does not match the required CipherSpec.', why: 'SSLCIPH uyuşmuyor: ' + c.sslciph + ' ≠ ' + partner.sslciph };
    if (partner && !!c.sslciph !== !!partner.sslciph) return { ok: false, tq: tq, code: 'AMQ9639E', msg: 'Remote channel did not specify a CipherSpec.', why: 'Bir tarafta TLS tanımlı, diğerinde değil.' };
    return { ok: true, tq: tq, partner: partner };
  }
  A._reach = reach;
  A._publish = publishTo;
  A.startChannel = function (qm, c, silent) {
    var t = c.chltype, cmd = 'START CHANNEL(' + Q(c.name) + ')';
    if (['RCVR', 'SVRCONN', 'CLUSRCVR'].indexOf(t) >= 0 || (t === 'SVR' && !c.conname)) {
      c.status = c.inst && c.inst.length ? 'Running' : (t === 'CLUSRCVR' && c.st ? 'Running' : 'Inactive');
      done('Channel etkinleştirildi (simülasyon)', 'AMQ8018I: Start IBM MQ channel accepted.<br>' + t + ' channel\'lar karşı taraf bağlandığında çalışır; STOPPED durumundan çıkıp INACTIVE (bağlantı bekliyor) durumuna geçti.', cmd);
      return;
    }
    var r = reach(c);
    if (!r.ok) {
      c.status = t === 'RQSTR' ? 'Inactive' : 'Retrying';
      c.st = Object.assign(c.st || {}, { retries: 'Short retry 1/' + c.shortrty + ', sonraki deneme ' + c.shorttmr + ' sn', rqmname: r.tq ? r.tq.name : '' });
      MQ.addErr(qm, r.code, 'E', r.msg, "Channel '" + c.name + "': " + r.why, 'Karşı tarafı ve ağ erişimini kontrol edin.');
      MQ.addEvent(qm, 'Channel Stopped', 'Channel', c.name, 'MQRC_CHANNEL_STOPPED (2283)', 'Error', r.why);
      done('Channel başlatılamadı (simülasyon)', 'AMQ8018I: Start IBM MQ channel accepted.<br><b>' + E(r.code) + ':</b> ' + E(r.msg) + '<br>' + E(r.why) + (t !== 'RQSTR' ? '<br>Channel RETRYING durumuna geçti (SHORTRTY/SHORTTMR → LONGRTY/LONGTMR).' : ''), cmd, 'err');
      return;
    }
    c.status = 'Running';
    c.st = Object.assign(c.st || {}, { started: MQ.now(), retries: '', substate: 'MQGET', rqmname: r.tq ? r.tq.name : (c.conname || ''), conname: c.conname, msgs: (c.st && c.st.msgs) || 0 });
    if (r.partner) { r.partner.status = 'Running'; r.partner.st = Object.assign(r.partner.st || {}, { started: MQ.now(), substate: 'RECEIVE', rqmname: qm.name }); }
    if (t === 'RQSTR' && r.partner) { var px = MQ.findQ(r.tq, r.partner.xmitq); if (px && px.curdepth) setTimeout(function () { drain(r.tq, r.partner); MQ.save(); }, 900); }
    MQ.addErr(qm, 'AMQ9002I', 'I', "Channel '" + c.name + "' is starting.", '', '');
    MQ.addEvent(qm, 'Channel Started', 'Channel', c.name, 'MQRC_CHANNEL_STARTED (2282)', 'Info', 'Channel başlatıldı.');
    var xq = c.xmitq && MQ.findQ(qm, c.xmitq);
    if (xq && xq.curdepth) setTimeout(function () { drain(qm, c); MQ.save(); }, 900);
    if (silent) { MQ.save(); MQ.redrawTables(); MQ.toast('', c.name + ' başlatıldı', 'Channel RUNNING durumunda (simülasyon).'); return; }
    done('Channel başlatıldı (simülasyon)', 'AMQ8018I: Start IBM MQ channel accepted.<br>' + E(c.name) + ' → RUNNING' + (r.external ? ' (dış sistem simülasyonda erişilebilir kabul edildi)' : ' — karşı taraf: ' + E(r.tq.name)) + (xq && xq.curdepth ? '<br>' + xq.curdepth + ' bekleyen mesaj iletilecek…' : ''), cmd);
  };
  A.stopChannel = function (qm, c) {
    MQ.modal({ title: c.name + ' durdurulsun mu?', label: qm.name, help: 'stopchannel', primary: 'Durdur', danger: true,
      body: F.radio({ name: 'mode', label: 'MODE', help: 'stopchannel', options: [['QUIESCE', 'QUIESCE (mevcut batch tamamlanır)'], ['FORCE', 'FORCE'], ['TERMINATE', 'TERMINATE']], value: 'QUIESCE' }) +
        F.radio({ name: 'status', label: 'Sonuç durumu', help: 'chstopped', options: [['STOPPED', 'STOPPED (otomatik başlamaz)'], ['INACTIVE', 'INACTIVE (tetikleme/gelen bağlantı ile yeniden başlayabilir)']], value: 'STOPPED' }) +
        (c.chltype === 'SVRCONN' ? '<div class="notice warn">' + I('warning') + '<div class="grow">Bu SVRCONN\'u kullanan ' + (c.inst ? c.inst.length : 0) + ' istemci instance\'ı bağlantısını kaybeder (MQRC_CONNECTION_BROKEN 2009 / reconnect).</div></div>' : '') + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'STOP CHANNEL(' + Q(c.name) + ') MODE(' + v.mode + ') STATUS(' + v.status + ')'); },
      onSubmit: function (f, v) {
        c.status = v.status === 'STOPPED' ? 'Stopped' : 'Inactive'; if (c.inst) c.inst = null;
        MQ.state.qmgrs.forEach(function (o) { if (o === qm) return; o.channels.forEach(function (x) { if (x.name === c.name && x.status === 'Running') x.status = 'Inactive'; }); });
        MQ.addEvent(qm, 'Channel Stopped By User', 'Channel', c.name, 'MQRC_CHANNEL_STOPPED_BY_USER (2279)', 'Warning', 'MODE(' + v.mode + ') STATUS(' + v.status + ')');
        done('Channel durduruldu (simülasyon)', 'AMQ8019I: Stop IBM MQ channel accepted.', f.querySelector('[data-preview]').textContent, 'warn');
      } });
  };
  A.pingChannel = function (qm, c) {
    var cmd = 'PING CHANNEL(' + Q(c.name) + ')';
    if (c.status === 'Running') { MQ.toast('err', 'PING başarısız', "AMQ9514E: Channel '" + E(c.name) + "' is in use. Çalışan bir channel ping edilemez.", cmd); return; }
    var r = reach(c);
    if (r.ok) MQ.toast('', 'Ping başarılı (simülasyon)', 'AMQ8020I: Ping IBM MQ channel complete. Ağ yolu, listener ve karşı channel tanımı doğrulandı.', cmd);
    else MQ.toast('err', 'Ping başarısız', E(r.code) + ': ' + E(r.msg) + '<br>' + E(r.why), cmd);
  };
  A.resetChannel = function (qm, c) {
    MQ.modal({ title: 'Channel sıra numarasını sıfırla', label: c.name, help: 'resetchannel', primary: 'Reset', size: 'sm',
      body: '<p>Sender ve receiver arasındaki mesaj sıra numaraları uyuşmadığında (AMQ9526E: Message sequence number error) kullanılır.</p>' + F.text({ name: 'seq', label: 'Yeni sıra numarası (SEQNUM)', help: 'ch.seqwrap', value: '1', type: 'number' }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'RESET CHANNEL(' + Q(c.name) + ') SEQNUM(' + v.seq + ')'); },
      onSubmit: function (f, v) { c.st = Object.assign(c.st || {}, { curseqno: parseInt(v.seq, 10) }); done('Channel sıfırlandı (simülasyon)', 'AMQ8023I: IBM MQ channel reset.', f.querySelector('[data-preview]').textContent); } });
  };
  A.deleteChannel = function (qm, c) {
    if (c.status === 'Running') { MQ.toast('err', 'Channel silinemedi', "AMQ9514E: Channel '" + E(c.name) + "' is in use. Önce STOP CHANNEL ile durdurun."); return; }
    MQ.confirm({ title: c.name + ' silinsin mi?', help: 'channel', primary: 'Sil', body: '<pre class="preview-box">DELETE CHANNEL(' + E(Q(c.name)) + ')</pre>' + (c.chltype === 'CLUSRCVR' ? '<div class="notice warn">' + I('warning') + '<div class="grow">CLUSRCVR silmek bu QM\'i cluster\'dan koparır. Doğru yöntem önce RESET CLUSTER / SUSPEND QMGR adımlarıdır.</div></div>' : ''),
      onOk: function () { qm.channels.splice(qm.channels.indexOf(c), 1); MQ.save(); MQ.go('#/qm/' + MQ.enc(qm.name) + '/network/channels'); MQ.refresh(); MQ.toast('', 'Channel silindi (simülasyon)', 'AMQ8015I: IBM MQ channel deleted.', 'DELETE CHANNEL(' + Q(c.name) + ')'); } });
  };

  /* ================================================== LISTENERS */
  A.createListener = function (qm) {
    MQ.modal({ title: 'Listener oluştur', label: qm.name, help: 'listener', primary: 'Oluştur',
      body: '<div class="frow">' + F.text({ name: 'name', label: 'Listener name', attr: 'LISTENER', help: 'lstr.name', placeholder: 'LST.TCP.1418' }) + F.select({ name: 'trptype', label: 'Transport type', attr: 'TRPTYPE', help: 'lstr.trptype', options: ['TCP', 'LU62'] }) +
        F.text({ name: 'port', label: 'Port', attr: 'PORT', help: 'lstr.port', value: '1418', type: 'number' }) + F.text({ name: 'ipaddr', label: 'IP address', attr: 'IPADDR', help: 'lstr.ipaddr', placeholder: '(boş = tüm arayüzler)' }) +
        F.select({ name: 'control', label: 'Control', attr: 'CONTROL', help: 'lstr.control', options: ['QMGR', 'STARTONLY', 'MANUAL'] }) + F.text({ name: 'backlog', label: 'Backlog', attr: 'BACKLOG', help: 'lstr.backlog', value: '0', type: 'number' }) + '</div>' + F.text({ name: 'descr', label: 'Description', attr: 'DESCR', help: 'q.descr' }) + F.check({ name: 'start', label: 'Oluşturduktan sonra başlat', help: 'lstr.status', value: true }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE LISTENER(' + Q(v.name || '<ad>') + ') TRPTYPE(' + v.trptype + ') PORT(' + v.port + ')' + (v.ipaddr ? ' IPADDR(' + Q(v.ipaddr) + ')' : '') + ' CONTROL(' + v.control + ')' + (+v.backlog ? ' BACKLOG(' + v.backlog + ')' : '') + (v.descr ? ' DESCR(' + Q(v.descr) + ')' : '') + (v.start ? '\nSTART LISTENER(' + Q(v.name || '<ad>') + ')' : '')); },
      onSubmit: function (f, v) {
        var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e);
        if (qm.listeners.some(function (l) { return l.name === v.name; })) return MQ.invalid(f, 'name', 'AMQ8150E: IBM MQ object already exists.');
        var p = parseInt(v.port, 10); if (!(p >= 0 && p <= 65535)) return MQ.invalid(f, 'port', 'Port 0 - 65535 arasında olmalıdır.');
        var l = { name: v.name, status: 'Stopped', trptype: v.trptype, port: p, ipaddr: v.ipaddr, control: v.control, backlog: parseInt(v.backlog, 10) || 0, descr: v.descr, pid: '', started: '' };
        qm.listeners.push(l);
        var cmd = f.querySelector('[data-preview]').textContent;
        if (v.start) { setTimeout(function () { A.startListener(qm, l); }, 50); }
        MQ.save(); MQ.refresh(); MQ.toast('', 'Listener oluşturuldu (simülasyon)', 'AMQ8626I: IBM MQ listener created.', cmd.split('\n')[0]);
      } });
  };
  A.startListener = function (qm, l) {
    var cmd = 'START LISTENER(' + Q(l.name) + ')';
    var clash = qm.listeners.filter(function (x) { return x !== l && x.status === 'Running' && (x.port || 1414) === (l.port || 1414) && (!x.ipaddr || !l.ipaddr || x.ipaddr === l.ipaddr); })[0];
    if (clash) { MQ.addErr(qm, 'AMQ9218E', 'E', 'The TCP/IP listener program could not bind to port number ' + (l.port || 1414) + '.', 'Port zaten ' + clash.name + ' tarafından kullanılıyor.', 'Farklı bir port seçin veya diğer listener\'ı durdurun.'); MQ.save(); MQ.toast('err', 'Listener başlatılamadı', 'AMQ9218E: The TCP/IP listener program could not bind to port number ' + (l.port || 1414) + '. Port ' + E(clash.name) + ' tarafından kullanılıyor.', cmd); return; }
    l.status = 'Running'; l.pid = 20000 + Math.floor(Math.random() * 9999); l.started = MQ.now();
    var fixed = [];
    MQ.state.qmgrs.forEach(function (o) { o.channels.forEach(function (c) { if (c.status === 'Retrying' && hostPort(c.conname).host === qm.host && hostPort(c.conname).port === (l.port || 1414)) { fixed.push(o.name + ' / ' + c.name); setTimeout(function () { A.startChannel(o, c, true); }, 1500); } }); });
    done('Listener başlatıldı (simülasyon)', 'AMQ8021I: Request to start IBM MQ Listener accepted.' + (fixed.length ? '<br>Bu porta bağlanmaya çalışan RETRYING kanallar bir sonraki denemede bağlanacak: ' + fixed.map(E).join(', ') : ''), cmd);
  };
  A.stopListener = function (qm, l) {
    MQ.confirm({ title: l.name + ' durdurulsun mu?', help: 'listener', primary: 'Durdur', body: '<p>Yeni gelen bağlantılar (istemciler ve diğer QM\'lerin kanalları) reddedilir. Hâlihazırda kurulmuş bağlantılar etkilenmez.</p><pre class="preview-box">STOP LISTENER(' + E(Q(l.name)) + ')</pre>',
      onOk: function () { l.status = 'Stopped'; l.pid = ''; done('Listener durduruldu (simülasyon)', 'AMQ8706I: Request to stop IBM MQ Listener accepted.', 'STOP LISTENER(' + Q(l.name) + ')', 'warn'); } });
  };
  A.listenerDetail = function (qm, l) {
    MQ.modal({ title: l.name, label: 'DISPLAY LSSTATUS', help: 'listener', primary: false, cancel: 'Kapat',
      body: '<dl class="kv"><dt>Status' + H('lstr.status') + '</dt><dd>' + MQ.status(l.status) + '</dd><dt>Transport' + H('lstr.trptype') + '</dt><dd>' + E(l.trptype) + '</dd><dt>Port' + H('lstr.port') + '</dt><dd>' + (l.port || '0 (varsayılan 1414)') + '</dd><dt>IP address' + H('lstr.ipaddr') + '</dt><dd>' + E(l.ipaddr || '* (tüm arayüzler)') + '</dd><dt>Control' + H('lstr.control') + '</dt><dd>' + E(l.control) + '</dd><dt>Backlog' + H('lstr.backlog') + '</dt><dd>' + l.backlog + '</dd><dt>PID</dt><dd>' + (l.pid || '-') + '</dd><dt>Başlangıç</dt><dd>' + E(l.started || '-') + '</dd><dt>Queue manager</dt><dd>' + E(qm.name) + '</dd></dl>' +
        '<div class="preview-h">Komut satırı eşdeğeri</div><pre class="preview-box">runmqlsr -m ' + E(qm.name) + ' -t ' + E(l.trptype.toLowerCase()) + ' -p ' + (l.port || 1414) + (l.ipaddr ? ' -i ' + E(l.ipaddr) : '') + '\n\nDISPLAY LSSTATUS(' + E(Q(l.name)) + ') ALL</pre>' });
  };

  /* ================================================== TOPICS / SUBS */
  A.createTopic = function (qm) {
    MQ.modal({ title: 'Topic oluştur', label: qm.name, help: 'topic', primary: 'Oluştur',
      body: '<div class="frow">' + F.text({ name: 'name', label: 'Topic name', attr: 'TOPIC', help: 'topicname', placeholder: 'SIPARIS.TOPIC' }) + F.text({ name: 'topicstr', label: 'Topic string', attr: 'TOPICSTR', help: 'topicstring', placeholder: 'siparis/durum' }) + '</div>' + F.text({ name: 'descr', label: 'Description', attr: 'DESCR', help: 'q.descr' }) +
        '<div class="frow3">' + F.select({ name: 'pub', label: 'Publish', attr: 'PUB', help: 'topic.pub', options: ['ENABLED', 'DISABLED'] }) + F.select({ name: 'sub', label: 'Subscribe', attr: 'SUB', help: 'topic.pub', options: ['ENABLED', 'DISABLED'] }) + F.select({ name: 'dursub', label: 'Durable subscriptions', attr: 'DURSUB', help: 'durablesub', options: ['YES', 'NO'] }) +
        F.select({ name: 'defpsist', label: 'Default persistence', attr: 'DEFPSIST', help: 'q.defpsist', options: ['NO', 'YES'] }) + F.text({ name: 'cluster', label: 'Cluster', attr: 'CLUSTER', help: 'clustertopic' }) + F.select({ name: 'clroute', label: 'Cluster route', attr: 'CLROUTE', help: 'clustertopic', options: ['DIRECT', 'TOPICHOST'] }) + '</div>' + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE TOPIC(' + Q(v.name || '<ad>') + ') TOPICSTR(' + Q(v.topicstr || '') + ')' + (v.descr ? ' DESCR(' + Q(v.descr) + ')' : '') + (v.pub !== 'ENABLED' ? ' PUB(DISABLED)' : '') + (v.sub !== 'ENABLED' ? ' SUB(DISABLED)' : '') + (v.dursub === 'NO' ? ' DURSUB(NO)' : '') + (v.defpsist === 'YES' ? ' DEFPSIST(YES)' : '') + (v.cluster ? ' CLUSTER(' + Q(v.cluster) + ') CLROUTE(' + v.clroute + ')' : '')); },
      onSubmit: function (f, v) {
        var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e);
        if (qm.topics.some(function (t) { return t.name === v.name; })) return MQ.invalid(f, 'name', 'AMQ8150E: IBM MQ object already exists.');
        if (!v.topicstr) return MQ.invalid(f, 'topicstr', 'TOPICSTR zorunludur.');
        if (/[#+]/.test(v.topicstr)) return MQ.invalid(f, 'topicstr', 'Topic nesnesinin TOPICSTR değerinde joker karakter (#, +) kullanılamaz; jokerler aboneliklerde kullanılır.');
        if (qm.topics.some(function (t) { return t.topicstr === v.topicstr; })) return MQ.invalid(f, 'topicstr', 'Bu topic string için zaten bir topic nesnesi tanımlı.');
        qm.topics.push({ name: v.name, topicstr: v.topicstr, descr: v.descr, pub: v.pub, sub: v.sub, dursub: v.dursub, defpsist: v.defpsist, pubscope: 'ALL', subscope: 'ALL', cluster: v.cluster, clroute: v.clroute, pubs: 0, subs: 0, msgs: 0 });
        done('Topic oluşturuldu (simülasyon)', 'AMQ8690I: IBM MQ topic created.', f.querySelector('[data-preview]').textContent);
      } });
  };
  A.topicDetail = function (qm, t) {
    var subs = qm.subs.filter(function (s) { return t.topicstr && topicMatch(s.topicstr, t.topicstr) || s.topicobj === t.name; });
    MQ.modal({ title: t.name, label: 'Topic', help: 'topic', primary: false, cancel: 'Kapat', size: 'lg',
      body: '<dl class="kv"><dt>Topic string' + H('topicstring') + '</dt><dd class="mono-sm">' + E(t.topicstr || '(root)') + '</dd><dt>Açıklama</dt><dd>' + E(t.descr) + '</dd><dt>PUB / SUB' + H('topic.pub') + '</dt><dd>' + E(t.pub) + ' / ' + E(t.sub) + '</dd><dt>DURSUB' + H('durablesub') + '</dt><dd>' + E(t.dursub) + '</dd><dt>DEFPSIST' + H('q.defpsist') + '</dt><dd>' + E(t.defpsist) + '</dd><dt>PUBSCOPE / SUBSCOPE' + H('topic.scope') + '</dt><dd>' + E(t.pubscope) + ' / ' + E(t.subscope) + '</dd><dt>Cluster' + H('clustertopic') + '</dt><dd>' + E(t.cluster || '-') + (t.cluster ? ' (CLROUTE ' + E(t.clroute) + ')' : '') + '</dd><dt>Yayınlanan mesaj' + H('pubsubstats') + '</dt><dd>' + MQ.fmt(t.msgs || 0) + '</dd></dl>' +
        '<div class="preview-h">Bu topic\'e eşleşen abonelikler (DISPLAY TPSTATUS / SBSTATUS)</div>' + (subs.length ? '<ul>' + subs.map(function (s) { return '<li>' + E(s.name) + ' → <span class="mono-sm">' + E(s.dest) + '</span> (' + (s.durable === 'YES' ? 'durable' : 'non-durable') + ')</li>'; }).join('') + '</ul>' : '<p class="muted">Abone yok.</p>') +
        '<pre class="preview-box">DISPLAY TOPIC(' + E(Q(t.name)) + ') ALL\nDISPLAY TPSTATUS(' + E(Q(t.topicstr || '#')) + ') TYPE(SUB)</pre>' });
  };
  A.createSub = function (qm) {
    var dests = qm.queues.filter(function (q) { return !q.system && (q.type === 'QLOCAL' && q.usage !== 'XMITQ' || q.type === 'QALIAS' || q.type === 'QREMOTE'); }).map(function (q) { return q.name; });
    MQ.modal({ title: 'Subscription oluştur', label: qm.name, help: 'subscription', primary: 'Oluştur',
      body: '<div class="notice">' + I('info') + '<div class="grow">MQSC/Console ile tanımlanan abonelikler <b>yönetimsel (SUBTYPE ADMIN)</b> ve her zaman <b>durable</b>\'dır. Non-durable abonelikler yalnızca uygulamalar tarafından (MQSUB) oluşturulur.' + H('durablesub') + '</div></div>' +
        F.text({ name: 'name', label: 'Subscription name', attr: 'SUB', help: 'subname', placeholder: 'SUB.SIPARIS.RAPOR' }) +
        '<div class="frow">' + F.select({ name: 'topicobj', label: 'Topic object', attr: 'TOPICOBJ', help: 'topicname', options: [['', '(yok)']].concat(qm.topics.map(function (t) { return [t.name, t.name + ' (' + (t.topicstr || 'root') + ')']; })) }) + F.text({ name: 'topicstr', label: 'Topic string (joker: # ve +)', attr: 'TOPICSTR', help: 'topicstring', placeholder: 'bildirim/#' }) + '</div>' +
        '<div class="frow">' + F.select({ name: 'dest', label: 'Destination queue', attr: 'DEST', help: 'subdest', options: dests }) + F.text({ name: 'destqmgr', label: 'Destination QM', attr: 'DESTQMGR', help: 'subdest', value: qm.name }) + '</div>' +
        F.text({ name: 'selector', label: 'Selector (SQL92, opsiyonel)', attr: 'SELECTOR', help: 'selector', placeholder: "kanal = 'SMS'" }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE SUB(' + Q(v.name || '<ad>') + ')' + (v.topicobj ? ' TOPICOBJ(' + Q(v.topicobj) + ')' : '') + (v.topicstr ? ' TOPICSTR(' + Q(v.topicstr) + ')' : '') + ' DEST(' + Q(v.dest) + ')' + (v.destqmgr && v.destqmgr !== qm.name ? ' DESTQMGR(' + Q(v.destqmgr) + ')' : '') + (v.selector ? ' SELECTOR(' + Q(v.selector) + ')' : '')); },
      onSubmit: function (f, v) {
        if (!v.name) return MQ.invalid(f, 'name', 'Ad zorunludur.');
        if (qm.subs.some(function (s) { return s.name === v.name; })) return MQ.invalid(f, 'name', 'AMQ8150E: IBM MQ object already exists.');
        var t = qm.topics.filter(function (x) { return x.name === v.topicobj; })[0];
        var ts = [t && t.topicstr, v.topicstr].filter(Boolean).join('/');
        if (!ts) return MQ.invalid(f, 'topicstr', 'TOPICOBJ veya TOPICSTR belirtilmelidir.');
        if (t && t.sub === 'DISABLED') return MQ.invalid(f, 'topicobj', 'Topic SUB(DISABLED): MQRC_SUB_INHIBITED (2436).');
        qm.subs.push({ name: v.name, topicstr: ts, topicobj: v.topicobj, subtype: 'ADMIN', durable: 'YES', dest: v.dest, destqmgr: v.destqmgr, destclas: 'PROVIDED', selector: v.selector, expiry: 'UNLIMITED', created: MQ.now(), lastmsg: '', msgs: 0 });
        if (t) t.subs++;
        done('Subscription oluşturuldu (simülasyon)', 'AMQ8094I: IBM MQ subscription created. Tam topic string: ' + E(ts), f.querySelector('[data-preview]').textContent);
      } });
  };
  A.subDetail = function (qm, s) {
    MQ.modal({ title: s.name, label: 'Subscription', help: 'subscription', primary: false, cancel: 'Kapat',
      body: '<dl class="kv"><dt>Topic string' + H('topicstring') + '</dt><dd class="mono-sm">' + E(s.topicstr) + '</dd><dt>Topic object</dt><dd>' + E(s.topicobj || '-') + '</dd><dt>SUBTYPE' + H('subtype') + '</dt><dd>' + E(s.subtype) + '</dd><dt>Durable' + H('durablesub') + '</dt><dd>' + E(s.durable) + '</dd><dt>DEST / DESTQMGR' + H('subdest') + '</dt><dd class="mono-sm">' + E(s.dest) + ' / ' + E(s.destqmgr) + '</dd><dt>DESTCLAS' + H('subdest') + '</dt><dd>' + E(s.destclas) + '</dd><dt>Selector' + H('selector') + '</dt><dd>' + E(s.selector || '-') + '</dd><dt>Expiry</dt><dd>' + E(s.expiry) + '</dd><dt>Oluşturulma</dt><dd>' + E(s.created) + '</dd><dt>Son mesaj</dt><dd>' + E(s.lastmsg || '-') + '</dd><dt>Alınan mesaj</dt><dd>' + MQ.fmt(s.msgs || 0) + '</dd></dl><pre class="preview-box">DISPLAY SUB(' + E(Q(s.name)) + ') ALL\nDISPLAY SBSTATUS(' + E(Q(s.name)) + ')</pre>' });
  };
  A.deleteObj = function (qm, coll, obj, kind) {
    var cmd = 'DELETE ' + kind + '(' + Q(obj.name) + ')';
    MQ.confirm({ title: obj.name + ' silinsin mi?', primary: 'Sil', body: '<pre class="preview-box">' + E(cmd) + '</pre>',
      onOk: function () { qm[coll].splice(qm[coll].indexOf(obj), 1); done(kind + ' silindi (simülasyon)', 'Nesne silindi.', cmd); } });
  };

  /* ================================================== SECURITY */
  A.setChlauth = function (qm) {
    var chs = qm.channels.map(function (c) { return c.name; });
    function fields(t) {
      var s = '';
      if (t === 'BLOCKADDR') return F.text({ name: 'addrlist', label: 'Engellenecek adresler (ADDRLIST)', help: 'chlauth.blockaddr', placeholder: '192.168.99.*, 10.1.1.5' });
      if (t === 'BLOCKUSER') return F.text({ name: 'userlist', label: 'Engellenecek kullanıcılar (USERLIST)', help: 'chlauth.blockuser', value: '*MQADMIN' });
      if (t === 'ADDRESSMAP') s += F.text({ name: 'address', label: 'Adres (ADDRESS)', help: 'chlauth.addressmap', placeholder: '10.20.30.*' });
      if (t === 'SSLPEERMAP') s += F.text({ name: 'sslpeer', label: 'Sertifika DN (SSLPEER)', help: 'chlauth.sslpeermap', placeholder: 'CN=app1,OU=IT,O=Ornek' });
      if (t === 'USERMAP') s += F.text({ name: 'clntuser', label: 'İstemci kullanıcı (CLNTUSER)', help: 'chlauth.usermap' });
      if (t === 'QMGRMAP') s += F.text({ name: 'qmname', label: 'Uzak QM adı (QMNAME)', help: 'chlauth.qmgrmap', placeholder: 'QMCORE*' });
      s += '<div class="frow">' + F.select({ name: 'usersrc', label: 'USERSRC', help: 'chlauth.usersrc', options: ['MAP', 'NOACCESS', 'CHANNEL'] }) + F.text({ name: 'mcauser', label: 'MCAUSER (MAP için)', help: 'ch.mcauser' }) + '</div>';
      if (t !== 'QMGRMAP') s += F.select({ name: 'chckclnt', label: 'CHCKCLNT', help: 'connauth.chckclnt', options: ['ASQMGR', 'REQUIRED', 'REQDADM'] });
      return s;
    }
    function build(v) {
      var m = { BLOCKADDR: "ADDRLIST('" + (v.addrlist || '') + "')", BLOCKUSER: "USERLIST('" + (v.userlist || '') + "')", ADDRESSMAP: "ADDRESS('" + (v.address || '') + "')", SSLPEERMAP: "SSLPEER('" + (v.sslpeer || '') + "')", USERMAP: "CLNTUSER('" + (v.clntuser || '') + "')", QMGRMAP: "QMNAME('" + (v.qmname || '') + "')" }[v.type];
      return { profile: v.type === 'BLOCKADDR' ? '*' : v.profile, type: v.type, match: m, usersrc: /BLOCK/.test(v.type) ? '' : v.usersrc, mcauser: v.usersrc === 'MAP' ? v.mcauser : '', chckclnt: /BLOCK|QMGRMAP/.test(v.type) ? '' : v.chckclnt, warn: v.warn ? 'YES' : 'NO', descr: v.descr };
    }
    MQ.modal({ title: 'CHLAUTH kuralı ekle', label: qm.name, help: 'chlauth', primary: 'Kaydet', size: 'lg',
      body: '<div class="frow">' + F.select({ name: 'type', label: 'Kural tipi (TYPE)', help: 'chlauth.type', options: ['ADDRESSMAP', 'SSLPEERMAP', 'USERMAP', 'QMGRMAP', 'BLOCKUSER', 'BLOCKADDR'] }) + F.text({ name: 'profile', label: 'Channel profili (generic * kullanılabilir)', help: 'chlauth.profile', value: chs.filter(function (c) { return /SVRCONN/.test(c); })[0] || '*' }) + '</div><div id="chlf">' + fields('ADDRESSMAP') + '</div>' +
        F.text({ name: 'descr', label: 'Açıklama', help: 'q.descr' }) + F.check({ name: 'warn', label: 'WARN(YES) — engelleme yerine yalnızca uyar (test modu)', help: 'chlauth.warn' }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, MQ.chlauthCmd(build(v))); },
      onOpen: function (f) { var s = f.querySelector('[name=type]'); s.addEventListener('change', function () { f.querySelector('#chlf').innerHTML = fields(s.value); MQ.setPreview(f, MQ.chlauthCmd(build(MQ.vals(f)))); }); },
      onSubmit: function (f, v) {
        var r = build(v);
        if (!r.profile) return MQ.invalid(f, 'profile', 'Channel profili zorunludur.');
        if (r.usersrc === 'MAP' && !r.mcauser) return MQ.invalid(f, 'mcauser', 'USERSRC(MAP) için MCAUSER zorunludur.');
        if (/''\)$/.test(r.match)) { MQ.toast('err', 'Eksik alan', 'Eşleşme değeri boş olamaz.'); return false; }
        if (r.usersrc === 'MAP' && /^(mqm|root)$/i.test(r.mcauser)) MQ.toast('warn', 'Güvenlik uyarısı', 'Yönetici bir kimliğe (' + E(r.mcauser) + ') eşleme yapmak; istemcilere tam yetki verir ve *MQADMIN BLOCKUSER kuralı tarafından engellenir.');
        var ex = qm.chlauth.filter(function (x) { return x.profile === r.profile && x.type === r.type && x.match === r.match; })[0];
        if (ex) qm.chlauth[qm.chlauth.indexOf(ex)] = r; else qm.chlauth.push(r);
        done('CHLAUTH kuralı kaydedildi (simülasyon)', 'AMQ8877I: IBM MQ channel authentication record set. Kural anında etkindir (REFRESH gerekmez).', f.querySelector('[data-preview]').textContent);
      } });
  };
  var AUTHS = { QMGR: ['CONNECT', 'INQ', 'SET', 'SETALL', 'SETID', 'ALTUSR', 'DSP', 'CHG', 'CTRL', 'SYSTEM', 'ALLADM', 'ALLMQI', 'ALL'], QUEUE: ['PUT', 'GET', 'BROWSE', 'INQ', 'SET', 'PASSALL', 'PASSID', 'SETALL', 'SETID', 'DSP', 'CHG', 'CLR', 'DLT', 'CRT', 'ALLADM', 'ALLMQI', 'ALL'], TOPIC: ['PUB', 'SUB', 'RESUME', 'PASSALL', 'PASSID', 'SETALL', 'SETID', 'DSP', 'CHG', 'CLR', 'DLT', 'CRT', 'CTRL', 'ALL'], CHANNEL: ['DSP', 'CHG', 'DLT', 'CRT', 'CTRL', 'CTRLX', 'ALL'] };
  A.setAuthrec = function (qm, rec) {
    rec = rec || {};
    var cur = (rec.auth || '').split(' ');
    function boxes(ot) { return '<div class="flex wrap" style="gap:4px 16px">' + (AUTHS[ot] || AUTHS.QUEUE).map(function (a) { return '<label class="chk" style="margin:0"><input type="checkbox" name="a_' + a + '"' + (cur.indexOf(a) >= 0 ? ' checked' : '') + '> ' + a + '</label>'; }).join('') + '</div>'; }
    MQ.modal({ title: 'Yetki kaydı (SET AUTHREC)', label: qm.name, help: 'oam', primary: 'Kaydet', size: 'lg',
      body: '<div class="frow3">' + F.text({ name: 'profile', label: 'Profile (generic: *, **, ?)', help: 'authprofile', value: rec.profile || '' }) + F.select({ name: 'objtype', label: 'Object type', help: 'authobjtype', options: ['QUEUE', 'QMGR', 'TOPIC', 'CHANNEL'], value: rec.objtype || 'QUEUE' }) + F.text({ name: 'group', label: 'Group', help: 'oam', value: rec.group || '' }) + '</div>' +
        '<div class="field"><label class="lb">Yetkiler' + H('authlist') + '</label><div id="authboxes">' + boxes(rec.objtype || 'QUEUE') + '</div></div>' + F.preview(),
      onInput: function (f, v) { var a = Object.keys(v).filter(function (k) { return k.indexOf('a_') === 0 && v[k]; }).map(function (k) { return k.slice(2); }); MQ.setPreview(f, 'SET AUTHREC ' + (v.objtype === 'QMGR' ? '' : 'PROFILE(' + Q(v.profile || '<profil>') + ') ') + 'OBJTYPE(' + v.objtype + ') GROUP(' + Q(v.group || '<grup>') + ') AUTHADD(' + (a.join(',') || 'NONE') + ')\n\n# İşletim sistemi komutu eşdeğeri:\nsetmqaut -m ' + qm.name + (v.objtype === 'QMGR' ? '' : ' -n "' + (v.profile || '') + '"') + ' -t ' + (v.objtype === 'QMGR' ? 'qmgr' : v.objtype.toLowerCase()) + ' -g ' + (v.group || '<grup>') + ' ' + a.map(function (x) { return '+' + x.toLowerCase(); }).join(' ')); },
      onOpen: function (f) { f.querySelector('[name=objtype]').addEventListener('change', function (e) { cur = []; f.querySelector('#authboxes').innerHTML = boxes(e.target.value); }); },
      onSubmit: function (f, v) {
        if (v.objtype !== 'QMGR' && !v.profile) return MQ.invalid(f, 'profile', 'Profile zorunludur.');
        if (!v.group) return MQ.invalid(f, 'group', 'Grup zorunludur. (Unix\'ta yetkiler gruplara verilir.)');
        var a = Object.keys(v).filter(function (k) { return k.indexOf('a_') === 0 && v[k]; }).map(function (k) { return k.slice(2); });
        if (!a.length) { MQ.toast('err', 'Yetki seçilmedi', 'En az bir yetki seçin.'); return false; }
        var r = { profile: v.objtype === 'QMGR' ? 'self' : v.profile, objtype: v.objtype, principal: '', group: v.group, auth: a.join(' '), note: '' };
        var ex = qm.authrec.filter(function (x) { return x.profile === r.profile && x.objtype === r.objtype && x.group === r.group; })[0];
        if (ex) ex.auth = r.auth; else qm.authrec.push(r);
        done('Yetki kaydı güncellendi (simülasyon)', 'AMQ8862I: IBM MQ authority record set.' + (a.indexOf('ALL') >= 0 || a.indexOf('ALLADM') >= 0 ? '<br><b>Uyarı:</b> Geniş yetki verdiniz; en az yetki ilkesini gözden geçirin.' : ''), f.querySelector('[data-preview]').textContent.split('\n\n')[0]);
      } });
  };
  A.createAuthinfo = function (qm) {
    MQ.modal({ title: 'Authentication information oluştur', label: qm.name, help: 'authinfo', primary: 'Oluştur', size: 'lg',
      body: '<div class="frow">' + F.text({ name: 'name', label: 'Name', attr: 'AUTHINFO', help: 'authinfo' }) + F.select({ name: 'authtype', label: 'Auth type', attr: 'AUTHTYPE', help: 'authinfo.authtype', options: ['IDPWOS', 'IDPWLDAP', 'CRLLDAP', 'OCSP'] }) + '</div>' +
        '<div class="frow">' + F.text({ name: 'conname', label: 'LDAP sunucu(ları) (CONNAME)', attr: 'CONNAME', help: 'authinfo.idpwldap', placeholder: 'ldap1.ornek.local(636)' }) + F.text({ name: 'ocspurl', label: 'OCSP URL', attr: 'OCSPURL', help: 'authinfo.ocsp' }) +
        F.select({ name: 'chckclnt', label: 'CHCKCLNT', help: 'connauth.chckclnt', options: ['REQDADM', 'REQUIRED', 'OPTIONAL', 'NONE'] }) + F.select({ name: 'chcklocl', label: 'CHCKLOCL', help: 'connauth.chcklocl', options: ['OPTIONAL', 'REQUIRED', 'REQDADM', 'NONE'] }) + F.select({ name: 'adoptctx', label: 'ADOPTCTX', help: 'connauth.adoptctx', options: ['YES', 'NO'] }) + F.select({ name: 'secomm', label: 'SECCOMM (LDAP TLS)', help: 'authinfo.idpwldap', options: ['YES', 'NO', 'ANON'] }) + '</div>' + F.preview(),
      onInput: function (f, v) { var t = v.authtype; MQ.setPreview(f, 'DEFINE AUTHINFO(' + Q(v.name || '<ad>') + ') AUTHTYPE(' + t + ')' + (/IDPW/.test(t) ? ' CHCKCLNT(' + v.chckclnt + ') CHCKLOCL(' + v.chcklocl + ') ADOPTCTX(' + v.adoptctx + ')' : '') + (/LDAP/.test(t) ? ' CONNAME(' + Q(v.conname) + ') SECCOMM(' + v.secomm + ')' + (t === 'IDPWLDAP' ? " LDAPUSER('cn=mqbind,ou=svc,dc=ornek') LDAPPWD('********') BASEDNU('ou=users,dc=ornek') USRFIELD('uid') SHORTUSR('uid') AUTHORMD(SEARCHGRP)" : '') : '') + (t === 'OCSP' ? ' OCSPURL(' + Q(v.ocspurl) + ')' : '')); },
      onSubmit: function (f, v) { var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e); if (/LDAP/.test(v.authtype) && !v.conname) return MQ.invalid(f, 'conname', 'LDAP tipleri için CONNAME gerekir.'); if (v.authtype === 'OCSP' && !v.ocspurl) return MQ.invalid(f, 'ocspurl', 'OCSPURL gerekir.');
        qm.authinfo.push({ name: v.name, authtype: v.authtype, chckclnt: /IDPW/.test(v.authtype) ? v.chckclnt : '', chcklocl: /IDPW/.test(v.authtype) ? v.chcklocl : '', adoptctx: /IDPW/.test(v.authtype) ? v.adoptctx : '', failDelay: 1, conname: v.conname, ocspurl: v.ocspurl, descr: '' });
        done('AUTHINFO oluşturuldu (simülasyon)', 'AMQ8563I: IBM MQ authentication information object created.', f.querySelector('[data-preview]').textContent); } });
  };
  A.editConnauth = function (qm, ai) {
    if (!ai) { MQ.toast('warn', 'CONNAUTH tanımlı değil', 'Önce bir IDPWOS/IDPWLDAP AUTHINFO nesnesi seçin.'); return; }
    MQ.modal({ title: 'Connection authentication', label: ai.name, help: 'connauth', primary: 'Kaydet',
      body: '<div class="frow">' + F.select({ name: 'chckclnt', label: 'CHCKCLNT', help: 'connauth.chckclnt', options: ['REQDADM', 'REQUIRED', 'OPTIONAL', 'NONE'], value: ai.chckclnt }) + F.select({ name: 'chcklocl', label: 'CHCKLOCL', help: 'connauth.chcklocl', options: ['OPTIONAL', 'REQUIRED', 'REQDADM', 'NONE'], value: ai.chcklocl }) + F.select({ name: 'adoptctx', label: 'ADOPTCTX', help: 'connauth.adoptctx', options: ['YES', 'NO'], value: ai.adoptctx }) + F.text({ name: 'faildlay', label: 'FAILDLAY (sn)', help: 'connauth.faildlay', value: ai.failDelay, type: 'number' }) + '</div>' + F.check({ name: 'refresh', label: 'Kaydettikten sonra REFRESH SECURITY TYPE(CONNAUTH) çalıştır', help: 'refreshsec', value: true }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'ALTER AUTHINFO(' + Q(ai.name) + ') AUTHTYPE(' + ai.authtype + ') CHCKCLNT(' + v.chckclnt + ') CHCKLOCL(' + v.chcklocl + ') ADOPTCTX(' + v.adoptctx + ') FAILDLAY(' + v.faildlay + ')' + (v.refresh ? '\nREFRESH SECURITY TYPE(CONNAUTH)' : '')); },
      onSubmit: function (f, v) { ai.chckclnt = v.chckclnt; ai.chcklocl = v.chcklocl; ai.adoptctx = v.adoptctx; ai.failDelay = +v.faildlay; done('CONNAUTH güncellendi (simülasyon)', 'AMQ8567I: IBM MQ authentication information changed.' + (v.refresh ? '<br>AMQ8560I: IBM MQ security cache refreshed.' : '<br><b>Not:</b> REFRESH SECURITY TYPE(CONNAUTH) çalıştırılana kadar eski ayarlar geçerlidir!') + (v.chckclnt === 'NONE' || v.chckclnt === 'OPTIONAL' ? '<br><b>Uyarı:</b> İstemci bağlantılarında parola denetimi zayıflatıldı.' : ''), f.querySelector('[data-preview]').textContent, v.refresh ? '' : 'warn'); } });
  };
  A.refreshSecurity = function (qm, type) {
    MQ.modal({ title: 'REFRESH SECURITY', label: qm.name, help: 'refreshsec', primary: 'Çalıştır', size: 'sm',
      body: F.radio({ name: 'type', label: 'TYPE', help: 'refreshsec', options: [['AUTHSERV', 'AUTHSERV (OAM önbelleği)'], ['CONNAUTH', 'CONNAUTH'], ['SSL', 'SSL (key repository)']], value: type || 'AUTHSERV' }) + '<div class="notice warn" id="sslnote" style="display:none">' + I('warning') + '<div class="grow">TYPE(SSL), çalışan tüm TLS kanallarını kısa süreliğine yeniden başlatır.</div></div>' + F.preview(),
      onInput: function (f, v) { f.querySelector('#sslnote').style.display = v.type === 'SSL' ? '' : 'none'; MQ.setPreview(f, 'REFRESH SECURITY TYPE(' + v.type + ')'); },
      onSubmit: function (f, v) { MQ.toast('', 'Güvenlik önbelleği yenilendi (simülasyon)', 'AMQ8560I: IBM MQ security cache refreshed.', 'REFRESH SECURITY TYPE(' + v.type + ')'); } });
  };
  A.configureTls = function (qm, ch) {
    var chs = qm.channels.map(function (c) { return c.name; });
    MQ.modal({ title: 'TLS yapılandır', label: qm.name, help: 'tls', primary: 'Uygula', size: 'lg',
      body: F.sec('Queue manager', 'qm.sslkeyr') + '<div class="frow">' + F.text({ name: 'sslkeyr', label: 'Key repository (uzantısız)', attr: 'SSLKEYR', help: 'qm.sslkeyr', value: qm.attrs.SSLKEYR || qm.dataPath + '/ssl/key' }) + F.text({ name: 'certlabl', label: 'Certificate label', attr: 'CERTLABL', help: 'qm.certlabl', value: qm.attrs.CERTLABL || 'ibmwebspheremq' + qm.name.toLowerCase() }) + '</div>' +
        F.sec('Channel', 'ch.sslciph') + '<div class="frow">' + F.select({ name: 'channel', label: 'Channel', help: 'chname', options: chs, value: ch ? ch.name : chs[0] }) + F.select({ name: 'sslciph', label: 'CipherSpec', attr: 'SSLCIPH', help: 'ch.sslciph', options: [['', '(TLS kapalı)']].concat(MQ.CIPHERS.filter(function (c) { return !/Devre/.test(c.type); }).map(function (c) { return c.name; })), value: ch ? ch.sslciph : 'ANY_TLS12_OR_HIGHER' }) +
        F.select({ name: 'sslcauth', label: 'Client authentication', attr: 'SSLCAUTH', help: 'ch.sslcauth', options: ['REQUIRED', 'OPTIONAL'], value: ch ? ch.sslcauth : 'REQUIRED' }) + F.text({ name: 'sslpeer', label: 'SSLPEER', attr: 'SSLPEER', help: 'ch.sslpeer', value: ch ? ch.sslpeer : '' }) + '</div>' + F.preview('Gerekli adımlar (komut satırı + MQSC)', 'tls'),
      onInput: function (f, v) { MQ.setPreview(f, '# 1) Key repository oluştur (bir kez)\nrunmqakm -keydb -create -db ' + v.sslkeyr + '.kdb -pw ******** -type cms -stash\n\n# 2) CA sertifikalarını ekle ve QM sertifikasını içe aktar\nrunmqakm -cert -add -db ' + v.sslkeyr + '.kdb -stashed -label ornek-root-ca -file rootca.pem\nrunmqakm -cert -receive -db ' + v.sslkeyr + '.kdb -stashed -file ' + qm.name.toLowerCase() + '.crt\n\n# 3) MQSC\nALTER QMGR SSLKEYR(' + Q(v.sslkeyr) + ') CERTLABL(' + Q(v.certlabl) + ')\nALTER CHANNEL(' + Q(v.channel) + ') CHLTYPE(' + (MQ.findCh(qm, v.channel) || {}).chltype + ') SSLCIPH(' + (v.sslciph || "' '") + ') SSLCAUTH(' + v.sslcauth + ')' + (v.sslpeer ? ' SSLPEER(' + Q(v.sslpeer) + ')' : '') + '\nREFRESH SECURITY TYPE(SSL)'); },
      onSubmit: function (f, v) { qm.attrs.SSLKEYR = v.sslkeyr; qm.attrs.CERTLABL = v.certlabl; var c = MQ.findCh(qm, v.channel); if (c) { c.sslciph = v.sslciph; c.sslcauth = v.sslcauth; c.sslpeer = v.sslpeer; } done('TLS yapılandırıldı (simülasyon)', 'AMQ8005I: IBM MQ queue manager changed.<br>AMQ8016I: IBM MQ channel changed.<br>AMQ8560I: IBM MQ security cache refreshed.<br><b>Unutmayın:</b> Karşı taraftaki channel da uyumlu bir SSLCIPH kullanmalıdır.'); } });
  };
  A.certRequest = function (qm) {
    MQ.modal({ title: 'Sertifika isteği (CSR) oluştur', label: qm.name, help: 'certificate', primary: 'Komutu kopyala', size: 'lg',
      body: '<div class="frow">' + F.text({ name: 'label', label: 'Label', help: 'qm.certlabl', value: 'ibmwebspheremq' + qm.name.toLowerCase() }) + F.text({ name: 'dn', label: 'Subject DN', help: 'certificate', value: 'CN=' + qm.name + ',OU=MQ,O=Ornek Banka,C=TR' }) + F.select({ name: 'size', label: 'Anahtar boyutu', help: 'certificate', options: ['2048', '3072', '4096'] }) + F.select({ name: 'alg', label: 'İmza algoritması', help: 'certificate', options: ['SHA256WithRSA', 'SHA384WithRSA', 'SHA512WithRSA'] }) + '</div>' + F.preview('Komut', 'certificate'),
      onInput: function (f, v) { MQ.setPreview(f, 'runmqakm -certreq -create -db ' + qm.attrs.SSLKEYR + '.kdb -stashed \\\n  -label "' + v.label + '" -dn "' + v.dn + '" -size ' + v.size + ' -sig_alg ' + v.alg + ' \\\n  -san_dnsname ' + qm.host + ' -file ' + qm.name.toLowerCase() + '.csr'); },
      onSubmit: function (f) { var t = f.querySelector('[data-preview]').textContent; try { navigator.clipboard.writeText(t); } catch (e) { /* yok say */ } MQ.toast('', 'Komut panoya kopyalandı', 'CSR dosyasını kurumsal CA\'ya gönderin; imzalı sertifikayı runmqakm -cert -receive ile alın.'); } });
  };

  /* ================================================== OTHER OBJECTS */
  A.createProcess = function (qm) {
    MQ.modal({ title: 'Process definition oluştur', label: qm.name, help: 'process', primary: 'Oluştur',
      body: F.text({ name: 'name', label: 'Name', attr: 'PROCESS', help: 'process' }) + '<div class="frow">' + F.select({ name: 'appltype', label: 'Application type', attr: 'APPLTYPE', help: 'process.appltype', options: ['UNIX', 'WINDOWSNT', 'DEF', 'CICS', 'IMS', 'MVS'] }) + F.text({ name: 'applicid', label: 'Application ID (çalıştırılacak program)', attr: 'APPLICID', help: 'process.applicid', placeholder: '/opt/app/bin/worker' }) + F.text({ name: 'userdata', label: 'User data', attr: 'USERDATA', help: 'process.userdata' }) + F.text({ name: 'envrdata', label: 'Environment data', attr: 'ENVRDATA', help: 'process.userdata' }) + '</div>' + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE PROCESS(' + Q(v.name || '<ad>') + ') APPLTYPE(' + v.appltype + ') APPLICID(' + Q(v.applicid) + ')' + (v.userdata ? ' USERDATA(' + Q(v.userdata) + ')' : '') + (v.envrdata ? ' ENVRDATA(' + Q(v.envrdata) + ')' : '')); },
      onSubmit: function (f, v) { var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e); if (!v.applicid) return MQ.invalid(f, 'applicid', 'APPLICID zorunludur.'); qm.processes.push({ name: v.name, appltype: v.appltype, applicid: v.applicid, userdata: v.userdata, envrdata: v.envrdata, descr: '' }); done('Process oluşturuldu (simülasyon)', 'AMQ8010I: IBM MQ process created.', f.querySelector('[data-preview]').textContent); } });
  };
  A.createNamelist = function (qm) {
    MQ.modal({ title: 'Namelist oluştur', label: qm.name, help: 'namelist', primary: 'Oluştur',
      body: F.text({ name: 'name', label: 'Name', attr: 'NAMELIST', help: 'namelist' }) + F.text({ name: 'names', label: 'Adlar (virgülle)', attr: 'NAMES', help: 'namelist.names', placeholder: 'CLS.ODEME, CLS.RAPOR' }) + F.text({ name: 'descr', label: 'Description', attr: 'DESCR', help: 'q.descr' }) + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE NAMELIST(' + Q(v.name || '<ad>') + ') NAMES(' + (v.names ? v.names.split(',').map(function (s) { return Q(s.trim()); }).join(',') : '') + ')' + (v.descr ? ' DESCR(' + Q(v.descr) + ')' : '')); },
      onSubmit: function (f, v) { var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e); qm.namelists.push({ name: v.name, names: v.names ? v.names.split(',').map(function (s) { return s.trim(); }) : [], nltype: 'NONE', descr: v.descr }); done('Namelist oluşturuldu (simülasyon)', 'AMQ8550I: IBM MQ namelist created.', f.querySelector('[data-preview]').textContent); } });
  };
  A.createService = function (qm) {
    MQ.modal({ title: 'Service oluştur', label: qm.name, help: 'service', primary: 'Oluştur',
      body: '<div class="frow">' + F.text({ name: 'name', label: 'Name', attr: 'SERVICE', help: 'service' }) + F.select({ name: 'servtype', label: 'Service type', attr: 'SERVTYPE', help: 'service.servtype', options: ['SERVER', 'COMMAND'] }) + F.select({ name: 'control', label: 'Control', attr: 'CONTROL', help: 'lstr.control', options: ['MANUAL', 'QMGR', 'STARTONLY'] }) + F.text({ name: 'startcmd', label: 'Start command', attr: 'STARTCMD', help: 'service', value: '+MQ_INSTALL_PATH+/bin/runmqtrm' }) + F.text({ name: 'startarg', label: 'Start arguments', attr: 'STARTARG', help: 'service', value: '-m +QMNAME+ -q SYSTEM.DEFAULT.INITIATION.QUEUE' }) + F.text({ name: 'stdout', label: 'STDOUT dosyası', attr: 'STDOUT', help: 'service' }) + '</div>' + F.preview(),
      onInput: function (f, v) { MQ.setPreview(f, 'DEFINE SERVICE(' + Q(v.name || '<ad>') + ') SERVTYPE(' + v.servtype + ') CONTROL(' + v.control + ') +\n       STARTCMD(' + Q(v.startcmd) + ') STARTARG(' + Q(v.startarg) + ')' + (v.stdout ? ' STDOUT(' + Q(v.stdout) + ')' : '')); },
      onSubmit: function (f, v) { var e = MQ.validName(v.name); if (e) return MQ.invalid(f, 'name', e); if (!v.startcmd) return MQ.invalid(f, 'startcmd', 'STARTCMD zorunludur.'); qm.services.push({ name: v.name, servtype: v.servtype, control: v.control, status: 'Stopped', startcmd: v.startcmd, startarg: v.startarg, stopcmd: '', stdout: v.stdout, descr: '' }); done('Service oluşturuldu (simülasyon)', 'AMQ8730I: IBM MQ service created.', f.querySelector('[data-preview]').textContent); } });
  };
  A.connDetail = function (qm, c) {
    MQ.modal({ title: 'Bağlantı ayrıntıları', label: 'DISPLAY CONN', help: 'connection', primary: false, cancel: 'Kapat', size: 'lg',
      body: '<dl class="kv"><dt>CONN' + H('connid') + '</dt><dd class="mono-sm">' + E(c.connid) + '</dd><dt>APPLTAG' + H('appltag') + '</dt><dd>' + E(c.appltag) + '</dd><dt>APPLTYPE' + H('appltype') + '</dt><dd>' + E(c.appltype) + '</dd><dt>CHANNEL</dt><dd>' + E(c.channel || '-') + '</dd><dt>CONNAME</dt><dd>' + E(c.conname) + '</dd><dt>USERID</dt><dd>' + E(c.userid) + '</dd><dt>PID</dt><dd>' + c.pid + '</dd><dt>CONNOPTS</dt><dd class="mono-sm">' + (c.channel ? 'MQCNO_HANDLE_SHARE_BLOCK, MQCNO_SHARED_BINDING' : 'MQCNO_HANDLE_SHARE_BLOCK, MQCNO_STANDARD_BINDING') + '</dd><dt>Açık nesneler (TYPE(HANDLE))' + H('handle') + '</dt><dd>' + E(c.objects) + '</dd><dt>UOW' + H('uow') + '</dt><dd>' + E(c.uow) + '</dd><dt>İstemci sürümü' + H('clientver') + '</dt><dd>' + E(c.clientVer || '-') + '</dd></dl><pre class="preview-box">DISPLAY CONN(' + E(c.connid.slice(-16)) + ') TYPE(ALL) ALL</pre>' });
  };
  A.stopConn = function (qm, c) {
    MQ.confirm({ title: 'Bağlantı sonlandırılsın mı?', help: 'connection', primary: 'Sonlandır', body: '<p>Uygulama ' + E(c.appltag) + ' bir sonraki MQI çağrısında MQRC_CONNECTION_BROKEN (2009) alır. Açık transaction geri alınır.</p><pre class="preview-box">STOP CONN(' + E(c.connid.slice(-16)) + ')</pre>',
      onOk: function () { qm.conns.splice(qm.conns.indexOf(c), 1); done('Bağlantı sonlandırıldı (simülasyon)', 'AMQ8488I: IBM MQ connection stopped.', 'STOP CONN(' + c.connid.slice(-16) + ')', 'warn'); } });
  };
  A.errDetail = function (r) {
    MQ.modal({ title: r.code, label: 'AMQERR01.LOG', help: 'amqcode', primary: false, cancel: 'Kapat', size: 'lg',
      body: '<pre class="msg-body">' + E(r.time) + ' - Process(41213.1) User(mqm) Program(amqrmppa)\n                    Host(mqhost) Installation(Installation1)\n                    VRMF(9.4.0.26) QMgr(...)\n                    Time(' + E(r.time.replace(' ', 'T')) + '.000Z)\n\n' + E(r.code) + ': ' + E(r.text) + '\n\nEXPLANATION:\n' + E(r.exp || '-') + '\nACTION:\n' + E(r.act || '-') + '\n----- amqrmrsa.c : 938 --------------------------------------------------------</pre>' });
  };

  /* ================================================== FILES */
  function download(name, text, type) {
    try { var b = new Blob([text], { type: type || 'application/json' }); var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
    catch (e) { MQ.toast('err', 'İndirme başarısız', E(e.message)); }
  }
  A.downloadCcdt = function () {
    var qms = MQ.state.qmgrs.filter(MQ.isUp);
    var chOpts = function (qm) { return qm.channels.filter(function (c) { return c.chltype === 'SVRCONN' && c.name.indexOf('SYSTEM.') !== 0; }).map(function (c) { return c.name; }); };
    function json(v) {
      var qm = MQ.qm(v.qm) || qms[0], c = MQ.findCh(qm, v.channel) || {};
      var o = { channel: [{ name: v.channel, clientConnection: { connection: [{ host: qm.host, port: qm.port }].concat(v.host2 ? [{ host: v.host2.split('(')[0], port: parseInt((v.host2.split('(')[1] || '1414').replace(')', ''), 10) }] : []), queueManager: qm.name }, transmissionSecurity: c.sslciph ? { cipherSpecification: c.sslciph } : undefined, connectionManagement: { sharingConversations: c.sharecnv || 10, clientWeight: 1, affinity: 'preferred' }, type: 'clientConnection' }] };
      return JSON.stringify(o, null, 2);
    }
    MQ.modal({ title: 'Bağlantı dosyası (JSON CCDT)', help: 'ccdt', primary: 'ccdt.json indir', size: 'lg',
      body: '<div class="frow">' + F.select({ name: 'qm', label: 'Queue manager', help: 'qmname', options: qms.map(function (q) { return q.name; }) }) + F.select({ name: 'channel', label: 'SVRCONN channel', help: 'svrconn', options: chOpts(qms[0]) }) + '</div>' + F.text({ name: 'host2', label: 'Yedek adres (opsiyonel, multi-instance / HA için)', help: 'ccdt', placeholder: 'mqgw01-b.ornek.local(1414)' }) + F.preview('ccdt.json', 'ccdt') + '<p class="muted">Uygulama tarafında: <code>MQCCDTURL=file:///yol/ccdt.json</code></p>',
      onInput: function (f, v) { MQ.setPreview(f, json(v)); },
      onOpen: function (f) { f.querySelector('[name=qm]').addEventListener('change', function (e) { var sel = f.querySelector('[name=channel]'); sel.innerHTML = chOpts(MQ.qm(e.target.value)).map(function (c) { return '<option>' + E(c) + '</option>'; }).join(''); MQ.setPreview(f, json(MQ.vals(f))); }); },
      onSubmit: function (f, v) { download('ccdt.json', json(v)); MQ.toast('', 'ccdt.json indirildi', 'Bu dosya yalnızca bağlantı bilgisi içerir; parola içermez.'); } });
  };
  A.dmpmqcfg = function (qm) {
    var L = ['* dmpmqcfg -m ' + qm.name + ' -a   (simülasyon çıktısı, yalnızca kullanıcı nesneleri)', '* Script generated on ' + MQ.now(), '* Queue manager name: ' + qm.name, '* Queue manager platform: ' + qm.platform, '* Command level: ' + qm.cmdlevel, '*', "ALTER QMGR DESCR(" + Q(qm.attrs.DESCR) + ") DEADQ(" + Q(qm.attrs.DEADQ) + ") CHLAUTH(" + qm.attrs.CHLAUTH + ") CONNAUTH(" + Q(qm.attrs.CONNAUTH) + ") SSLKEYR(" + Q(qm.attrs.SSLKEYR) + ")"];
    qm.queues.filter(function (q) { return !q.system && q.type !== 'QCLUSTER'; }).forEach(function (q) {
      var s = 'DEFINE ' + q.type + '(' + Q(q.name) + ')';
      if (q.descr) s += ' DESCR(' + Q(q.descr) + ')';
      if (q.type === 'QLOCAL') s += (q.usage === 'XMITQ' ? ' USAGE(XMITQ)' : '') + ' MAXDEPTH(' + q.maxdepth + ') DEFPSIST(' + q.defpsist + ')' + (q.bothresh ? ' BOTHRESH(' + q.bothresh + ') BOQNAME(' + Q(q.boqname) + ')' : '') + (q.trigger ? ' TRIGGER TRIGTYPE(' + q.trigtype + ') INITQ(' + Q(q.initq) + ')' + (q.trigdata ? ' TRIGDATA(' + Q(q.trigdata) + ')' : '') + (q.process ? ' PROCESS(' + Q(q.process) + ')' : '') : '') + (q.cluster ? ' CLUSTER(' + Q(q.cluster) + ')' : '') + (q.get === 'DISABLED' ? ' GET(DISABLED)' : '') + (q.put === 'DISABLED' ? ' PUT(DISABLED)' : '');
      if (q.type === 'QREMOTE') s += ' RNAME(' + Q(q.rname) + ') RQMNAME(' + Q(q.rqmname) + ')' + (q.xmitq ? ' XMITQ(' + Q(q.xmitq) + ')' : '');
      if (q.type === 'QALIAS') s += ' TARGET(' + Q(q.target) + ') TARGTYPE(' + q.targtype + ')';
      if (q.type === 'QMODEL') s += ' DEFTYPE(' + q.deftype + ')';
      L.push(s + ' REPLACE');
    });
    qm.channels.filter(function (c) { return c.name.indexOf('SYSTEM.') !== 0 && !c.auto; }).forEach(function (c) { L.push('DEFINE CHANNEL(' + Q(c.name) + ') CHLTYPE(' + c.chltype + ') TRPTYPE(TCP)' + (c.conname ? ' CONNAME(' + Q(c.conname) + ')' : '') + (c.xmitq ? ' XMITQ(' + Q(c.xmitq) + ')' : '') + (c.cluster ? ' CLUSTER(' + Q(c.cluster) + ')' : '') + (c.sslciph ? ' SSLCIPH(' + c.sslciph + ')' : '') + (c.mcauser ? ' MCAUSER(' + Q(c.mcauser) + ')' : '') + ' REPLACE'); });
    qm.listeners.filter(function (l) { return l.name.indexOf('SYSTEM.') !== 0; }).forEach(function (l) { L.push('DEFINE LISTENER(' + Q(l.name) + ') TRPTYPE(' + l.trptype + ') PORT(' + l.port + ') CONTROL(' + l.control + ') REPLACE'); });
    qm.topics.filter(function (t) { return !t.system; }).forEach(function (t) { L.push('DEFINE TOPIC(' + Q(t.name) + ') TOPICSTR(' + Q(t.topicstr) + ')' + (t.cluster ? ' CLUSTER(' + Q(t.cluster) + ')' : '') + ' REPLACE'); });
    qm.subs.filter(function (s) { return s.subtype === 'ADMIN' && !s.system; }).forEach(function (s) { L.push('DEFINE SUB(' + Q(s.name) + ') TOPICSTR(' + Q(s.topicstr) + ') DEST(' + Q(s.dest) + ') REPLACE'); });
    qm.chlauth.forEach(function (r) { L.push(MQ.chlauthCmd(r)); });
    qm.authrec.forEach(function (r) { L.push('SET AUTHREC ' + (r.objtype === 'QMGR' ? '' : 'PROFILE(' + Q(r.profile) + ') ') + 'OBJTYPE(' + r.objtype + ') GROUP(' + Q(r.group) + ') AUTHADD(' + r.auth.split(' ').join(',') + ')'); });
    var txt = L.join('\n');
    MQ.modal({ title: 'Konfigürasyon dökümü (dmpmqcfg)', label: qm.name, help: 'dmpmqcfg', primary: qm.name + '.mqsc indir', size: 'lg', body: '<pre class="preview-box" style="max-height:420px;overflow:auto">' + E(txt) + '</pre>', onSubmit: function () { download(qm.name + '.mqsc', txt, 'text/plain'); } });
  };
})();
