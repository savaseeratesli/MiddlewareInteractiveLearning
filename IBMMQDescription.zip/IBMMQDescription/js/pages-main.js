/* Ana sayfa, Manage (queue manager listeleri), Gösterge paneli, Öğrenme kaynakları, Ayarlar, Application quick start */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc;

  /* ------------------------------------------------ ortak yardımcılar */
  MQ.isUp = function (qm) { return qm.status === 'Running'; };
  MQ.qTypeLabel = function (q) { return { QLOCAL: 'Local', QREMOTE: 'Remote', QALIAS: 'Alias', QMODEL: 'Model', QCLUSTER: 'Cluster' }[q.type] || q.type; };
  MQ.qRoles = function (qm, q) {
    var r = [];
    if (q.type !== 'QLOCAL') { if (q.type === 'QREMOTE' && !q.rname && q.rqmname) r.push('QM alias'); return r; }
    if (q.usage === 'XMITQ') r.push('Transmission');
    if (qm.attrs.DEADQ && q.name === qm.attrs.DEADQ) r.push('Dead letter');
    if (q.role === 'initq' || qm.queues.some(function (x) { return x.initq === q.name; })) r.push('Initiation');
    if (qm.queues.some(function (x) { return x.boqname === q.name; })) r.push('Backout');
    if (q.cluster) r.push('Cluster');
    if (q.name.indexOf('SYSTEM.MANAGED.') === 0) r.push('Managed');
    return r;
  };
  MQ.qTypeCell = function (qm, q) {
    var roles = MQ.qRoles(qm, q);
    var helpKey = { QLOCAL: 'qlocal', QREMOTE: 'qremote', QALIAS: 'qalias', QMODEL: 'qmodel', QCLUSTER: 'clusterq' }[q.type];
    return '<span class="flex">' + MQ.esc(MQ.qTypeLabel(q)) + roles.map(function (x) { return MQ.tag(x, x === 'Dead letter' ? 'red' : x === 'Transmission' ? 'purple' : x === 'Initiation' ? 'teal' : x === 'Cluster' ? 'blue' : 'gray'); }).join('') + H(helpKey) + '</span>';
  };
  MQ.depthState = function (q) {
    if (q.type !== 'QLOCAL') return 'n/a';
    if (q.curdepth >= q.maxdepth) return 'full';
    if (MQ.pct(q.curdepth, q.maxdepth) >= q.qdepthhi && q.curdepth > 0) return 'warn';
    return 'normal';
  };
  MQ.notRunning = function (qm) {
    return '<div class="content"><div class="notice warn">' + I('warning') + '<div class="grow"><b>Queue manager çalışmıyor (' + E(qm.status) + ')</b>' + H('qmstatus') + '<br>' +
      (qm.status === 'Running elsewhere' ? 'Bu bir multi-instance queue manager\'dır ve aktif instance başka bir sunucuda çalışmaktadır. Nesneleri yönetmek için aktif instance\'ın bulunduğu sunucudaki MQ Console\'u kullanın.' + H('multiinstance') :
        'Nesneleri görüntülemek ve yönetmek için önce queue manager\'ı başlatın. Gerçek ortamda bu işlem <code>strmqm ' + E(qm.name) + '</code> komutuna karşılık gelir.') +
      '</div>' + (qm.status !== 'Running elsewhere' ? '<button class="btn sm" data-do="' + MQ.fn(function () { MQ.act.startQm(qm); }) + '">Başlat' + I('play') + '</button>' : '') + '</div></div>';
  };

  /* ------------------------------------------------ HOME */
  function heroSvg() {
    function blk(x, y, n, c) {
      var s = '', cols = c || ['#a6c8ff', '#4589ff', '#0f62fe'];
      for (var i = n - 1; i >= 0; i--) {
        var cy = y + i * 12;
        s += '<polygon points="' + x + ',' + (cy - 16) + ' ' + (x + 30) + ',' + cy + ' ' + x + ',' + (cy + 16) + ' ' + (x - 30) + ',' + cy + '" fill="' + cols[0] + '"/>' +
          '<polygon points="' + (x - 30) + ',' + cy + ' ' + x + ',' + (cy + 16) + ' ' + x + ',' + (cy + 24) + ' ' + (x - 30) + ',' + (cy + 8) + '" fill="' + cols[1] + '"/>' +
          '<polygon points="' + x + ',' + (cy + 16) + ' ' + (x + 30) + ',' + cy + ' ' + (x + 30) + ',' + (cy + 8) + ' ' + x + ',' + (cy + 24) + '" fill="' + cols[2] + '"/>';
      }
      return s;
    }
    function bld(x, y) {
      return '<polygon points="' + x + ',' + (y - 14) + ' ' + (x + 24) + ',' + y + ' ' + x + ',' + (y + 14) + ' ' + (x - 24) + ',' + y + '" fill="#e0e0e0"/>' +
        '<polygon points="' + (x - 24) + ',' + y + ' ' + x + ',' + (y + 14) + ' ' + x + ',' + (y + 44) + ' ' + (x - 24) + ',' + (y + 30) + '" fill="#a8a8a8"/>' +
        '<polygon points="' + x + ',' + (y + 14) + ' ' + (x + 24) + ',' + y + ' ' + (x + 24) + ',' + (y + 30) + ' ' + x + ',' + (y + 44) + '" fill="#c6c6c6"/>' +
        '<path d="M' + (x - 18) + ' ' + (y + 12) + 'v12M' + (x - 10) + ' ' + (y + 16) + 'v12M' + (x + 8) + ' ' + (y + 16) + 'v12M' + (x + 16) + ' ' + (y + 12) + 'v12" stroke="#6f6f6f" stroke-width="2"/>';
    }
    var dot = 'fill="none" stroke="#8d8d8d" stroke-width="2" stroke-dasharray="1 6" stroke-linecap="round"';
    return '<svg viewBox="0 0 560 260" aria-hidden="true">' +
      '<path d="M70 70 C120 40, 160 40, 200 60" ' + dot + '/><path d="M70 100 C150 160, 220 170, 290 150" ' + dot + '/>' +
      '<path d="M130 210 C200 240, 260 200, 290 160" ' + dot + '/><path d="M320 140 C360 110, 360 80, 380 70" ' + dot + '/>' +
      '<path d="M410 60 C450 40, 470 40, 490 60" ' + dot + '/><path d="M400 170 C450 180, 480 140, 500 110" ' + dot + '/>' +
      blk(70, 60, 3) + bld(210, 40) + blk(130, 190, 1) + bld(300, 130) + blk(390, 60, 3) + blk(410, 160, 4) + bld(495, 70) +
      '<circle cx="40" cy="190" r="9" fill="#a8a8a8"/><rect x="33" y="200" width="14" height="40" fill="#8d8d8d"/>' +
      '<circle cx="520" cy="170" r="9" fill="#a8a8a8"/><rect x="513" y="180" width="14" height="40" fill="#8d8d8d"/><text x="512" y="150" style="fill:#4589ff;font-size:22px;font-weight:700">!</text>' +
      '</svg>';
  }
  MQ.route('/home', function () {
    var qs = MQ.state.qmgrs;
    var running = qs.filter(MQ.isUp).length, stopped = qs.length - running;
    var disc = MQ.state.remoteQmgrs.filter(function (r) { return r.status !== 'Connected'; }).length;
    return '<div class="hero"><div><h1>Başlayalım!' + H('console') + '</h1>' +
      '<p>IBM MQ Console\'a hoş geldiniz. Bu arayüz, IBM MQ yönetim konsolunun <b>eğitim amaçlı bir simülasyonudur</b>; gerçek bir queue manager\'a bağlanmaz ve hiçbir gerçek mesaj göndermez.</p>' +
      '<p>Gördüğünüz her menü, alan ve parametrenin yanındaki <span class="hq" style="display:inline-flex;cursor:default">?</span> simgesine tıklayarak o bileşenin ne işe yaradığını, ne zaman kullanılacağını ve yanlış yapılandırılırsa neler olabileceğini öğrenebilirsiniz.</p>' +
      '<p class="flex wrap"><a class="btn md" href="#/manage">Yönetmeye başla' + I('chevronR') + '</a> <a class="btn md tertiary" href="#/learn">Öğrenme yolunu aç' + I('book') + '</a></p></div>' +
      '<div>' + heroSvg() + '</div></div>' +
      '<div class="home-tiles">' +
      '<a class="ctile" href="#/manage">' + I('manage', 'ic') + '<h3>Manage</h3>' + H('qmgr') +
      '<div class="qm-counts"><b>Queue manager\'larınız (' + qs.length + ')</b>' +
      '<div>' + '<span class="st"><i class="ok"></i></span><span>Running</span><b style="margin:0">' + running + '</b></div>' +
      '<div><span class="st"><i class="stop"></i></span><span>Stopped / başka yerde</span><b style="margin:0">' + stopped + '</b></div>' +
      '<div><span class="st"><i class="off"></i></span><span>Disconnected (uzak)</span><b style="margin:0">' + disc + '</b></div></div></a>' +
      '<button class="ctile" data-do="' + MQ.fn(function () { MQ.act.createQm(); }) + '">' + I('qm', 'ic') + '<h3>Queue manager oluştur</h3>' + H('crtmqm') + '<p>Queue manager\'lar; kuyruk ve topic gibi mesajlaşma kaynaklarınızı barındıran MQ motorlarıdır.</p></button>' +
      '<a class="ctile" href="#/quickstart">' + I('quick', 'ic') + '<h3>Application quick start</h3>' + H('quickstart') + '<p>Uygulamanızın MQ ile konuşması için gereken adımları birkaç basit adımda öğrenin.</p></a>' +
      '<button class="ctile" data-do="' + MQ.fn(function () { MQ.act.downloadCcdt(); }) + '">' + I('plug', 'ic') + '<h3>Bağlantı dosyası indir</h3>' + H('ccdt') + '<p>Uygulamaların kullanması için bir bağlantı dosyası (JSON CCDT) üretin.</p></button>' +
      '<a class="ctile" href="#/learn">' + I('learn', 'ic') + '<h3>Öğrenme kaynakları</h3>' + H('learning') + '<p>Tüm IBM MQ kavramları, kategorilere ayrılmış Türkçe açıklamalarla.</p></a>' +
      '<a class="ctile" href="#/dashboard">' + I('dashboard', 'ic') + '<h3>Gösterge paneli</h3>' + H('dashboard') + '<p>Tüm queue manager\'ların sağlık, mesaj ve kaynak kullanımı özeti.</p></a>' +
      '<a class="ctile" href="#/mqsc">' + I('terminal', 'ic') + '<h3>MQSC konsolu</h3>' + H('mqsc') + '<p>DISPLAY, DEFINE, ALTER gibi MQSC komutlarını güvenli bir simülatörde deneyin.</p></a>' +
      '</div>';
  }, 'home');

  /* ------------------------------------------------ MANAGE */
  function manage(sub) {
    var side = MQ.sidenav([{ key: 'remote', label: 'Remote queue managers', href: '#/manage/remote' }, { key: 'local', label: 'Local queue managers', href: '#/manage' }], sub);
    var body;
    if (sub === 'local') {
      body = '<p style="margin-top:0">Burada, bu MQ Console instance\'ı ile aynı sistemde (co-located) bulunan tüm queue manager\'ları görüntüleyip yönetebilirsiniz.' + H('localqm') + '</p>' +
        MQ.table({
          id: 'qmlist', defaultSort: { key: 'name', dir: 'asc' }, info: function (n, t) { return t + ' queue manager\'dan ' + n + ' tanesi yüklendi'; },
          rows: function () { return MQ.state.qmgrs; },
          columns: [
            { key: 'name', label: 'Unique name', help: 'qmname', render: function (q) { return '<a href="' + MQ.qmLink(q.name) + '">' + E(q.name) + '</a>' + (q.isDefault ? ' ' + MQ.tag('Default', 'outline') : ''); } },
            { key: 'status', label: 'Status', help: 'qmstatus', render: function (q) { return MQ.status(q.status); } },
            { key: 'version', label: 'Version', help: 'mqversion' },
            { key: 'platform', label: 'Platform', help: 'platform' },
            { key: 'port', label: 'Listener port', help: 'lstr.port', num: true },
            { key: 'ha', label: 'Yüksek erişilebilirlik', help: 'ha' }
          ],
          create: { label: 'Create', fn: function () { MQ.act.createQm(); } },
          overflow: function (q) {
            var up = MQ.isUp(q);
            return [
              { label: 'Görüntüle', fn: function () { MQ.go(MQ.qmLink(q.name)); } },
              { label: 'Konfigürasyonu görüntüle', fn: function () { MQ.go('#/qm/' + MQ.enc(q.name) + '/config/properties'); }, disabled: !up },
              '-',
              { label: 'Başlat (strmqm)', fn: function () { MQ.act.startQm(q); }, disabled: up || q.status === 'Running elsewhere' },
              { label: 'Durdur (endmqm)', fn: function () { MQ.act.stopQm(q); }, disabled: !up },
              { label: 'Varsayılan QM yap', fn: function () { MQ.state.qmgrs.forEach(function (x) { x.isDefault = x === q; }); MQ.save(); MQ.refresh(); MQ.toast('', 'Varsayılan queue manager değiştirildi', E(q.name) + ' artık varsayılan (simülasyon). Gerçekte crtmqm -q veya mqs.ini (DefaultQueueManager) ile belirlenir.'); } },
              '-',
              { label: 'Sil (dltmqm)', danger: true, fn: function () { MQ.act.deleteQm(q); } }
            ];
          }
        });
    } else {
      body = '<p style="margin-top:0">Remote queue manager\'lar, MQ Console\'un bir istemci bağlantısı (CCDT) üzerinden yönettiği, başka sistemlerde çalışan queue manager\'lardır.' + H('remoteqm') + '</p>' +
        MQ.table({
          id: 'rqmlist', info: function (n, t) { return t + ' remote queue manager\'dan ' + n + ' tanesi yüklendi'; },
          rows: function () { return MQ.state.remoteQmgrs; },
          columns: [
            { key: 'name', label: 'Unique name', help: 'qmname' },
            { key: 'status', label: 'Status', help: 'remoteqm', render: function (q) { return MQ.status(q.status); } },
            { key: 'platform', label: 'Platform', help: 'platform' },
            { key: 'version', label: 'Version', help: 'mqversion' },
            { key: 'host', label: 'Host(port)', render: function (q) { return E(q.host + '(' + q.port + ')'); }, help: 'ch.conname' },
            { key: 'channel', label: 'Channel', help: 'svrconn' },
            { key: 'tls', label: 'CipherSpec', help: 'ch.sslciph' }
          ],
          create: { label: 'Add', fn: function () { MQ.act.addRemoteQm(); } },
          overflow: function (q) {
            return [
              { label: q.status === 'Connected' ? 'Bağlantıyı kes' : 'Bağlan', fn: function () { q.status = q.status === 'Connected' ? 'Disconnected' : 'Connected'; MQ.save(); MQ.redrawTable('rqmlist'); MQ.toast(q.status === 'Connected' ? '' : 'info', q.status === 'Connected' ? 'Bağlandı (simülasyon)' : 'Bağlantı kesildi', E(q.name) + ' - ' + E(q.channel)); } },
              { label: 'Kaldır', danger: true, fn: function () { MQ.state.remoteQmgrs.splice(MQ.state.remoteQmgrs.indexOf(q), 1); MQ.save(); MQ.redrawTable('rqmlist'); } }
            ];
          }
        });
    }
    return MQ.pageHead({ title: 'Manage', help: 'manage', tabs: [{ label: 'Queue managers', href: '#/manage', active: true }] }) +
      '<div class="content with-side">' + side + '<div>' + body + '</div></div>';
  }
  MQ.route('/manage', function () { return manage('local'); }, 'manage');
  MQ.route('/manage/remote', function () { return manage('remote'); }, 'manage');
  MQ.go = function (h) { location.hash = h; };

  /* ------------------------------------------------ DASHBOARD */
  MQ.route('/dashboard', function () {
    var S = MQ.state, qs = S.qmgrs, up = qs.filter(MQ.isUp);
    var conns = 0, chRun = 0, chTot = 0, chProb = 0, msgs = 0, full = 0, warn = 0, normal = 0, dlq = 0, inMB = 0, outMB = 0;
    up.forEach(function (qm) {
      conns += qm.conns.length; msgs += qm.stats.msgsLastHour; inMB += qm.stats.bytesIn; outMB += qm.stats.bytesOut;
      qm.channels.forEach(function (c) { if (c.chltype === 'CLNTCONN') return; chTot++; if (c.status === 'Running') chRun++; if (c.status === 'Retrying' || c.status === 'Stopped') chProb++; });
      qm.queues.forEach(function (q) { var s = MQ.depthState(q); if (s === 'full') full++; else if (s === 'warn') warn++; else if (s === 'normal') normal++; });
      var d = MQ.findQ(qm, qm.attrs.DEADQ); if (d) dlq += d.curdepth;
    });
    var versions = {}; qs.forEach(function (q) { versions[q.version] = (versions[q.version] || 0) + 1; });
    var labels = []; for (var i = 23; i >= 0; i--) labels.push(((11 - i + 24) % 24 < 10 ? '0' : '') + ((11 - i + 24) % 24) + ':00');
    var sum = function (k) { return labels.map(function (_, i) { return up.reduce(function (a, qm) { return a + qm.stats[k][i]; }, 0); }); };
    var tile = function (t, help, big, foot) { return '<div class="tile"><div class="tile-h">' + t + H(help) + '</div><div class="tile-big">' + big + '</div><div class="tile-foot">' + foot + '</div></div>'; };
    var health = function (qm) {
      if (!MQ.isUp(qm)) return MQ.status(qm.status === 'Running elsewhere' ? 'Running elsewhere' : 'Stopped');
      var bad = qm.channels.some(function (c) { return c.status === 'Retrying'; }) || qm.queues.some(function (q) { return MQ.depthState(q) === 'full'; });
      var w = qm.queues.some(function (q) { return MQ.depthState(q) === 'warn'; }) || qm.listeners.some(function (l) { return l.status === 'Stopped' && l.control !== 'MANUAL' && l.name.indexOf('SYSTEM') !== 0; }) || qm.listeners.some(function (l) { return l.status === 'Stopped' && /1415/.test(l.name); });
      return bad ? MQ.status('Error') : w ? MQ.status('Warning') : MQ.status('Normal');
    };
    var events = []; qs.forEach(function (qm) { qm.events.forEach(function (e) { events.push(Object.assign({ qm: qm.name }, e)); }); });
    events.sort(function (a, b) { return a.time < b.time ? 1 : -1; });
    return MQ.pageHead({ title: 'Gösterge paneli', icon: 'dashboard', help: 'dashboard', desc: 'Bu MQ Console instance\'ının yönettiği tüm queue manager\'ların genel durumu, sürüm bilgisi, mesaj istatistikleri ve sağlık göstergeleri.' }) +
      '<div class="content">' + MQ.updated() +
      '<div class="grid g4">' +
      tile('IBM MQ sürümü', 'mqversion', '9.4', Object.keys(versions).map(function (v) { return '<span>' + E(v) + ' <span class="muted">(' + versions[v] + ' QM)</span>' + (v.indexOf('9.4.0') === 0 || v.indexOf('9.3.0') === 0 ? ' ' + MQ.tag('LTS', 'teal') : '') + '</span>'; }).join('') + '<span class="muted">Console: 9.4.0.26 (mqweb)</span>') +
      tile('Aktif queue manager', 'qmstatus', up.length + ' <span style="font-size:24px" class="muted">/ ' + qs.length + '</span>', '<span>' + (qs.length - up.length) + ' çalışmıyor</span><a href="#/manage">Queue manager listesine git</a>') +
      tile('Mesajlar (son 1 saat)', 'msgflow', MQ.fmt(msgs), '<span>' + inMB.toFixed(2).replace('.', ',') + ' MB giriş</span><span>' + outMB.toFixed(2).replace('.', ',') + ' MB çıkış</span>') +
      tile('Aktif bağlantılar', 'connection', MQ.fmt(conns), '<span>' + chRun + ' / ' + chTot + ' channel running</span><span>' + chProb + ' sorunlu channel</span>') +
      '</div>' +
      '<div class="grid g3 mt24">' +
      '<div class="tile"><div class="tile-h">Kuyruk durumları' + H('qdepth.monitor') + '</div><div class="grid g3" style="gap:0">' +
      '<div class="mini-stat"><div class="num">' + full + '</div><div class="lbl"><span class="st"><i class="err"></i></span>Dolu</div></div>' +
      '<div class="mini-stat"><div class="num">' + warn + '</div><div class="lbl"><span class="st"><i class="warn"></i></span>Uyarı</div></div>' +
      '<div class="mini-stat"><div class="num">' + normal + '</div><div class="lbl"><span class="st"><i class="ok"></i></span>Normal</div></div></div>' +
      '<div class="tile-foot"><span>Dead letter queue\'larda toplam <b>' + dlq + '</b> mesaj' + H('dlq') + '</span></div></div>' +
      '<div class="tile"><div class="tile-h">Sistem kaynak kullanımı' + H('cpumem') + '</div><div class="flex wrap" style="justify-content:space-around;padding:0 8px 16px">' +
      up.map(function (qm) { return '<div style="text-align:center">' + MQ.donut({ value: qm.cpu, max: 100, label: 'CPU', size: 92 }) + '<div class="mono-sm">' + E(qm.name) + '</div></div>'; }).join('') +
      up.map(function (qm) { return '<div style="text-align:center">' + MQ.donut({ value: qm.mem, max: 100, label: 'Bellek', size: 92, color: '#a56eff' }) + '<div class="mono-sm">' + E(qm.name) + '</div></div>'; }).join('') + '</div></div>' +
      '<div class="tile"><div class="tile-h">Son olaylar' + H('qmevents') + '</div><ul class="tile-list">' + events.slice(0, 5).map(function (e) {
        return '<li>' + I(e.sev === 'Error' ? 'error' : e.sev === 'Warning' ? 'warning' : 'info') + '<div class="nm"><span class="sub">' + E(e.type) + ' · ' + E(e.object) + '</span><span class="sub2">' + E(e.qm) + ' · ' + E(e.time) + '</span></div></li>';
      }).join('') + '</ul></div></div>' +
      '<div class="grid g2 mt24">' +
      '<div class="tile"><div class="tile-h">Mesaj giriş / çıkış (son 24 saat, tüm QM\'ler)' + H('putrate') + '</div>' + MQ.lineChart({ labels: labels, series: [{ name: 'Put (giriş)', data: sum('puts') }, { name: 'Get (çıkış)', data: sum('gets') }], area: true, title: 'Mesaj giriş çıkış' }) + '</div>' +
      '<div class="tile"><div class="tile-h">Queue manager başına mesaj hacmi (saatlik put)' + H('qmstats') + '</div>' + MQ.barChart({ labels: labels, stacked: true, series: up.map(function (qm, i) { return { name: qm.name, data: qm.stats.puts, color: MQ.COLORS[i] }; }), title: 'QM başına mesaj' }) + '</div>' +
      '</div>' +
      '<h2 class="section-title">Queue manager sağlık durumu' + H('health') + '</h2>' +
      MQ.table({
        id: 'health', search: false, rows: function () { return qs; },
        columns: [
          { key: 'name', label: 'Queue manager', render: function (q) { return '<a href="' + MQ.qmLink(q.name) + '">' + E(q.name) + '</a>'; } },
          { key: 'h', label: 'Sağlık', sort: false, render: health },
          { key: 'version', label: 'Sürüm', help: 'mqversion' },
          { key: 'cpu', label: 'CPU %', num: true, render: function (q) { return MQ.isUp(q) ? q.cpu.toFixed(1) : '-'; } },
          { key: 'mem', label: 'Bellek %', num: true, render: function (q) { return MQ.isUp(q) ? q.mem.toFixed(1) : '-'; } },
          { key: 'ch', label: 'Channel (run/retry)', sort: false, render: function (q) { var r = q.channels.filter(function (c) { return c.status === 'Running'; }).length, t = q.channels.filter(function (c) { return c.status === 'Retrying'; }).length; return r + ' / ' + (t ? '<b style="color:var(--yellow)">' + t + '</b>' : 0); } },
          { key: 'dlq', label: 'DLQ derinliği', num: true, help: 'dlq', val: function (q) { var d = MQ.findQ(q, q.attrs.DEADQ); return d ? d.curdepth : 0; }, render: function (q) { var d = MQ.findQ(q, q.attrs.DEADQ); return d ? MQ.fmt(d.curdepth) : '-'; } },
          { key: 'ha', label: 'HA', help: 'ha' }
        ]
      }) + '</div>';
  }, 'dashboard');

  /* ------------------------------------------------ LEARN */
  var CATS = ['Temel kavramlar', 'Queue Manager', 'Queues', 'Queue özellikleri', 'Mesaj', 'Channels', 'Channel özellikleri', 'Listeners', 'Publish/Subscribe', 'Güvenlik', 'TLS/SSL', 'MQ Cluster', 'İzleme', 'MQ Objects', 'QM özellikleri', 'MQSC', 'Konsol'];
  var PATH = ['qmgr', 'qlocal', 'persistence', 'mqput', 'listener', 'channel', 'svrconn', 'qremote', 'xmitq', 'sender', 'receiver', 'dlq', 'qalias', 'qmodel', 'triggering', 'backout', 'topic', 'subscription', 'cluster', 'chlauth', 'connauth', 'oam', 'tls', 'monitoring', 'mqsc'];
  MQ.route('/learn', function () {
    var ui = MQ.learnUi || (MQ.learnUi = { cat: '', q: '' });
    var keys = Object.keys(MQ.HELP);
    var cats = CATS.filter(function (c) { return keys.some(function (k) { return MQ.HELP[k].c === c; }); });
    MQ.after(function () {
      var inp = document.getElementById('learnSearch');
      if (inp) inp.addEventListener('input', function () { ui.q = inp.value; renderCards(); });
      renderCards();
    });
    function renderCards() {
      var box = document.getElementById('learnCards'); if (!box) return;
      var q = ui.q.toLowerCase();
      var list = keys.filter(function (k) { var e = MQ.HELP[k]; return (!ui.cat || e.c === ui.cat) && (!q || (e.t + ' ' + (e.m || '') + ' ' + (e.w || '')).toLowerCase().indexOf(q) >= 0); });
      list.sort(function (a, b) { return MQ.HELP[a].t.localeCompare(MQ.HELP[b].t, 'tr'); });
      document.getElementById('learnCount').textContent = list.length + ' konu';
      box.innerHTML = list.map(function (k) { var e = MQ.HELP[k]; return '<button class="learn-card" data-help="' + E(k) + '"><b>' + E(e.t) + (e.m ? ' <span class="help-mqsc">' + E(e.m) + '</span>' : '') + '</b><span>' + E(e.c || '') + '</span><span>' + (e.w || '').replace(/<[^>]+>/g, '') + '</span></button>'; }).join('') || '<div class="empty">' + I('info') + 'Aramanızla eşleşen konu bulunamadı.</div>';
    }
    return MQ.pageHead({ title: 'Öğrenme kaynakları', icon: 'learn', help: 'learning', desc: 'Konsolda karşılaşacağınız tüm IBM MQ kavramları burada. Bir karta tıklayarak ayrıntılı Türkçe açıklamayı sağ panelde açın.' }) +
      '<div class="content">' +
      '<h2 class="section-title">Önerilen öğrenme yolu</h2>' +
      '<div class="chips">' + PATH.filter(function (k) { return MQ.HELP[k]; }).map(function (k, i) { return '<button class="chip" data-help="' + k + '">' + (i + 1) + '. ' + E(MQ.HELP[k].t) + '</button>'; }).join('') + '</div>' +
      '<h2 class="section-title">Bir mesajın yolculuğu' + H('msgflow') + '</h2>' + MQ.flowDiagram() +
      '<h2 class="section-title">Tüm konular <span class="muted" style="font-size:14px;margin-left:12px" id="learnCount"></span></h2>' +
      '<div class="props-search"><div class="search">' + I('search') + '<input id="learnSearch" placeholder="Konu ara (ör. BOTHRESH, cluster, TLS)" value="' + E(ui.q) + '"></div></div>' +
      '<div class="chips"><button class="chip ' + (!ui.cat ? 'on' : '') + '" data-do="' + MQ.fn(function () { ui.cat = ''; MQ.refresh(); }) + '">Tümü</button>' +
      cats.map(function (c) { return '<button class="chip ' + (ui.cat === c ? 'on' : '') + '" data-do="' + MQ.fn(function () { ui.cat = c; MQ.refresh(); }) + '">' + E(c) + '</button>'; }).join('') + '</div>' +
      '<div class="learn-grid" id="learnCards"></div></div>';
  }, 'learn');

  MQ.flowDiagram = function () {
    var box = function (x, y, w, h, t, s, help, col) {
      return '<g><rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="var(--layer2)" stroke="' + (col || 'var(--border-strong)') + '" stroke-width="1.5"/>' +
        '<text x="' + (x + w / 2) + '" y="' + (y + h / 2 - 3) + '" text-anchor="middle" style="font-size:13px;font-weight:600">' + t + '</text>' +
        '<text x="' + (x + w / 2) + '" y="' + (y + h / 2 + 14) + '" text-anchor="middle" style="font-size:11px;fill:var(--text2)">' + s + '</text>' +
        (help ? '<g data-help="' + help + '" style="cursor:pointer"><circle cx="' + (x + w - 10) + '" cy="' + (y + 10) + '" r="7" fill="var(--layer)" stroke="var(--link)"/><text x="' + (x + w - 10) + '" y="' + (y + 14) + '" text-anchor="middle" style="font-size:10px;fill:var(--link);font-weight:700">?</text></g>' : '') + '</g>';
    };
    var arr = function (x1, y1, x2, y2, t) { return '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="var(--link)" stroke-width="2" marker-end="url(#ah)"/>' + (t ? '<text x="' + ((x1 + x2) / 2) + '" y="' + (Math.min(y1, y2) - 6) + '" text-anchor="middle" style="font-size:11px;fill:var(--text2)">' + t + '</text>' : ''); };
    return '<div class="diagram"><svg viewBox="0 0 1000 250" role="img" aria-label="Mesaj akış diyagramı">' +
      '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="var(--link)"/></marker></defs>' +
      '<rect x="150" y="20" width="420" height="210" fill="none" stroke="var(--border-strong)" stroke-dasharray="4 4"/><text x="160" y="38" style="font-size:12px;fill:var(--text2)">QMGW01</text>' +
      '<rect x="700" y="20" width="290" height="210" fill="none" stroke="var(--border-strong)" stroke-dasharray="4 4"/><text x="710" y="38" style="font-size:12px;fill:var(--text2)">QMCORE01</text>' +
      box(10, 90, 120, 56, 'Uygulama', 'MQPUT', 'mqput') +
      box(170, 90, 130, 56, 'QR.CORE.HESAP', 'Remote queue', 'qremote') +
      box(320, 90, 110, 56, 'QMCORE01', 'Transmission q', 'xmitq', '#a56eff') +
      box(450, 90, 110, 56, 'QMGW01.QMCORE01', 'SDR channel', 'sender') +
      box(715, 90, 110, 56, 'QMGW01.QMCORE01', 'RCVR channel', 'receiver') +
      box(845, 90, 130, 56, 'APP.HESAP.IN', 'Local queue', 'qlocal') +
      box(845, 170, 130, 50, 'SYSTEM.DEAD...', 'Dead letter q', 'dlq', '#fa4d56') +
      box(450, 170, 110, 50, 'LST.TCP.1414', 'Listener (hedef)', 'listener') +
      arr(130, 118, 168, 118) + arr(300, 118, 318, 118) + arr(430, 118, 448, 118) + arr(560, 118, 713, 118, 'TCP/TLS · mqcore01(1414)') + arr(825, 118, 843, 118) +
      '<line x1="910" y1="146" x2="910" y2="168" stroke="#fa4d56" stroke-width="2" stroke-dasharray="4 3" marker-end="url(#ah)"/><text x="860" y="162" style="font-size:10px;fill:var(--text2)" text-anchor="end">teslim edilemezse</text>' +
      '</svg></div>';
  };

  /* ------------------------------------------------ SETTINGS */
  MQ.route('/settings', function () {
    return MQ.pageHead({ title: 'Ayarlar', icon: 'settings', help: 'settings' }) +
      '<div class="content" style="max-width:900px">' +
      '<div class="props-panel"><div class="props-sec"><h2>Görünüm</h2>' +
      MQ.prop('Tema', '', '<div class="radio-row"><label><input type="radio" name="theme" value="dark"' + (MQ.prefs.theme !== 'light' ? ' checked' : '') + ' data-do="' + MQ.fn(function () { MQ.prefs.theme = 'dark'; MQ.savePrefs(); }) + '"> Koyu (g100)</label><label><input type="radio" name="theme" value="light"' + (MQ.prefs.theme === 'light' ? ' checked' : '') + ' data-do="' + MQ.fn(function () { MQ.prefs.theme = 'light'; MQ.savePrefs(); }) + '"> Açık (white)</label></div>', 'theme') +
      MQ.prop('Açıklama (?) simgelerini göster', '', '<label class="toggle"><input type="checkbox" id="helpToggle"' + (MQ.prefs.help ? ' checked' : '') + '><span class="tr"></span><span>' + (MQ.prefs.help ? 'Açık' : 'Kapalı') + '</span></label>', 'helpicons') +
      '</div><div class="props-sec"><h2>Kullanıcı</h2>' +
      MQ.prop('Oturum açan kullanıcı', '', E(MQ.state.user.name), 'mqwebuser') +
      MQ.prop('Rol', '', MQ.tag(MQ.state.user.role, 'blue'), 'mqwebroles') +
      '</div><div class="props-sec"><h2>Simülasyon</h2>' +
      MQ.prop('Veri kaynağı', '', 'Tarayıcı belleği (localStorage). Gerçek IBM MQ bağlantısı yoktur.', 'simulation') +
      MQ.prop('Simülasyon verilerini sıfırla', '', '<button class="btn sm danger" data-do="' + MQ.fn(function () {
        MQ.confirm({ title: 'Simülasyon sıfırlansın mı?', body: '<p>Oluşturduğunuz tüm kuyruklar, kanallar, mesajlar ve değişiklikler silinir; örnek ortam ilk haline döner.</p>', primary: 'Sıfırla', onOk: function () { MQ.resetState(); MQ.toast('', 'Simülasyon sıfırlandı', 'Örnek veriler yeniden yüklendi.'); MQ.go('#/home'); } });
      }) + '">Sıfırla' + I('refresh') + '</button>', 'simulation') +
      '</div></div></div>';
  }, 'settings');
  document.addEventListener('change', function (e) {
    if (e.target.id === 'helpToggle') { MQ.prefs.help = e.target.checked; MQ.savePrefs(); MQ.refresh(); }
  });

  /* ------------------------------------------------ QUICK START */
  MQ.route('/quickstart', function () {
    var qm = MQ.state.qmgrs.filter(function (q) { return q.isDefault; })[0] || MQ.state.qmgrs[0];
    var step = function (t, help, body, code) { return '<li><h3>' + t + H(help) + '</h3><div class="muted">' + body + '</div>' + (code ? '<pre class="preview-box">' + E(code) + '</pre>' : '') + '</li>'; };
    return MQ.pageHead({ title: 'Application quick start', icon: 'quick', help: 'quickstart', crumbs: [['Home', '#/home']], desc: 'Bir istemci uygulamanın ' + E(qm.name) + ' queue manager\'ına güvenli şekilde bağlanıp mesaj gönderip alabilmesi için gereken tipik yapılandırma adımları.' }) +
      '<div class="content" style="max-width:1000px"><ol class="steps">' +
      step('Uygulama kuyruklarını oluşturun', 'qlocal', 'İstek ve yanıt için local queue\'lar tanımlayın. Kalıcı iş verisi için DEFPSIST(YES) ve poison mesajlar için backout kuyruğu önerilir.', "DEFINE QLOCAL('APP.SIPARIS.ISTEK') DEFPSIST(YES) MAXDEPTH(50000) +\n       BOTHRESH(3) BOQNAME('APP.SIPARIS.BACKOUT')\nDEFINE QLOCAL('APP.SIPARIS.BACKOUT') DEFPSIST(YES)\nDEFINE QLOCAL('APP.SIPARIS.YANIT')") +
      step('Bir server-connection channel tanımlayın', 'svrconn', 'İstemci uygulamalar ağ üzerinden SVRCONN tipindeki kanallarla bağlanır. TLS kullanımı önerilir.', "DEFINE CHANNEL('APP.SIPARIS.SVRCONN') CHLTYPE(SVRCONN) TRPTYPE(TCP) +\n       SSLCIPH(ANY_TLS12_OR_HIGHER) SSLCAUTH(OPTIONAL) MAXINST(100) MAXINSTC(20)") +
      step('Listener\'ın çalıştığından emin olun', 'listener', 'Uygulama, listener\'ın dinlediği port üzerinden bağlanır (örnekte ' + qm.port + ').', "DISPLAY LSSTATUS(*) PORT STATUS") +
      step('Channel authentication (CHLAUTH) kuralı ekleyin', 'chlauth', 'Hangi istemcinin hangi kimlikle çalışacağını belirleyin. Varsayılan kurallar yönetici (mqm) kimliklerini engeller.', "SET CHLAUTH('APP.SIPARIS.SVRCONN') TYPE(ADDRESSMAP) ADDRESS('10.20.50.*') +\n    USERSRC(CHANNEL) CHCKCLNT(REQUIRED) DESCR('Siparis uygulama sunuculari')") +
      step('Yetkileri (OAM) verin', 'oam', 'Uygulamanın kullanıcısına/grubuna yalnızca ihtiyaç duyduğu yetkileri verin (en az yetki ilkesi).', "SET AUTHREC OBJTYPE(QMGR) GROUP('siparisgrp') AUTHADD(CONNECT,INQ)\nSET AUTHREC PROFILE('APP.SIPARIS.**') OBJTYPE(QUEUE) GROUP('siparisgrp') +\n    AUTHADD(PUT,GET,BROWSE,INQ)") +
      step('Bağlantı dosyasını (CCDT) üretin', 'ccdt', 'Uygulama, bağlantı bilgisini kod içine gömmek yerine JSON CCDT dosyasından okuyabilir (MQCCDTURL ortam değişkeni).', 'export MQCCDTURL=file:///opt/app/config/ccdt.json\nexport MQSERVER=   # CCDT kullanılırken MQSERVER tanımlanmamalıdır') +
      step('Uygulamadan bağlanın ve test edin', 'mqput', 'Örnek programlar (amqsputc / amqsgetc) ile bağlantıyı doğrulayın.', 'export MQSAMP_USER_ID=siparisapp\n/opt/mqm/samp/bin/amqsputc APP.SIPARIS.ISTEK ' + qm.name + '\n/opt/mqm/samp/bin/amqsgetc APP.SIPARIS.ISTEK ' + qm.name) +
      '</ol><div class="flex mt24"><button class="btn" data-do="' + MQ.fn(function () { MQ.act.createQueue(qm); }) + '">Kuyruk oluştur' + I('add') + '</button><button class="btn secondary" data-do="' + MQ.fn(function () { MQ.act.createChannel(qm, 'SVRCONN'); }) + '">SVRCONN oluştur' + I('add') + '</button><button class="btn tertiary" data-do="' + MQ.fn(function () { MQ.act.downloadCcdt(); }) + '">CCDT üret' + I('download') + '</button></div></div>';
  }, 'home');
})();
