/* Queue manager sayfası: Overview, Queues, Events (pub/sub), Applications, MQ network, İzleme */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc;

  MQ.ago = function (sec) {
    if (!sec || sec < 60) return 'birkaç saniye önce';
    if (sec < 3600) return Math.round(sec / 60) + ' dakika önce';
    if (sec < 86400) return Math.round(sec / 3600) + ' saat önce';
    if (sec < 2592000) return Math.round(sec / 86400) + ' gün önce';
    return Math.round(sec / 2592000) + ' ay önce';
  };
  MQ.qmHead = function (qm, active) {
    var b = '#/qm/' + MQ.enc(qm.name) + '/';
    var tabs = [['overview', 'Genel Bakış'], ['queues', 'Queues'], ['events', 'Events'], ['applications', 'Applications'], ['network', 'MQ network'], ['monitoring', 'İzleme'], ['mqsc', 'MQSC']];
    return MQ.pageHead({
      crumbs: [['Manage', '#/manage']], title: 'Queue manager: ' + qm.name, icon: 'qm', help: 'qmgr',
      right: MQ.isUp(qm) ? '<a class="link-btn" href="' + b + 'config/properties">Konfigürasyonu görüntüle ' + I('wrench') + '</a>' + H('qmconfig') : '',
      tabs: tabs.map(function (t) { return { label: t[1], href: b + t[0], active: t[0] === active }; }),
      tabsRight: MQ.status(qm.status) + MQ.tag(qm.platform, 'blue') + MQ.tag(qm.version, 'teal') + H('mqversion')
    });
  };
  function getQm(p) { var qm = MQ.qm(p.qm); if (!qm) throw new Error('Queue manager bulunamadı: ' + p.qm); return qm; }
  function qmPage(tab, fn) {
    return function (p) {
      var qm = getQm(p);
      if (!MQ.isUp(qm)) return MQ.qmHead(qm, tab) + MQ.notRunning(qm);
      return MQ.qmHead(qm, tab) + fn(qm, p);
    };
  }
  var tile = function (t, help, big, foot) { return '<div class="tile"><div class="tile-h">' + t + H(help) + '</div><div class="tile-big">' + big + '</div><div class="tile-foot">' + foot + '</div></div>'; };
  MQ.userQueues = function (qm) { return qm.queues.filter(function (q) { return !q.system; }); };
  MQ.connectedQms = function (qm) {
    var m = {};
    qm.channels.forEach(function (c) { if (c.status === 'Running' && c.st && c.st.rqmname && ['SDR', 'RCVR', 'SVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR'].indexOf(c.chltype) >= 0) { (m[c.st.rqmname] = m[c.st.rqmname] || []).push(c); } });
    return m;
  };

  /* ================================================== OVERVIEW */
  MQ.route('/qm/:qm', function (p) { location.replace('#/qm/' + MQ.enc(p.qm) + '/overview'); return ''; }, 'manage');
  MQ.route('/qm/:qm/overview', qmPage('overview', function (qm) {
    var uq = MQ.userQueues(qm).filter(function (q) { return q.type === 'QLOCAL'; });
    var withMsg = uq.filter(function (q) { return q.curdepth > 0; }), open = uq.filter(function (q) { return q.ipprocs + q.opprocs > 0; });
    var active = uq.filter(function (q) { return q.curdepth > 0 || q.ipprocs + q.opprocs > 0; });
    var cq = MQ.connectedQms(qm), cqn = Object.keys(cq);
    var qmch = qm.channels.filter(function (c) { return ['SVRCONN', 'CLNTCONN'].indexOf(c.chltype) < 0; });
    var running = qmch.filter(function (c) { return c.status === 'Running'; }).length, problem = qmch.filter(function (c) { return c.status === 'Retrying' || c.status === 'Stopped'; }).length;
    var apps = {}; qm.conns.forEach(function (c) { if (c.appltype !== 'SYSTEM') apps[c.appltag] = 1; });
    var inst = qm.channels.reduce(function (a, c) { return a + (c.inst ? c.inst.length : 0); }, 0);
    var deep = uq.slice().sort(function (a, b) { return b.curdepth - a.curdepth; }).slice(0, 5);
    var oldest = uq.filter(function (q) { return q.curdepth > 0; }).sort(function (a, b) { return b.msgage - a.msgage; }).slice(0, 5);
    var recent = qm.conns.filter(function (c) { return c.appltype !== 'SYSTEM'; }).slice().sort(function (a, b) { return a.conntime < b.conntime ? 1 : -1; }).slice(0, 4);
    var mem = qm.mem, stor = Math.round(qm.storageMB);
    var b = '#/qm/' + MQ.enc(qm.name) + '/';
    return '<div class="content">' + MQ.updated() +
      '<div class="res-bar"><div><div class="lb">CPU<span>' + qm.cpu.toFixed(2).replace('.', ',') + '%</span>' + H('cpumem') + '</div><div class="meter"><i style="width:' + qm.cpu + '%"></i></div></div>' +
      '<div><div class="lb">Memory<span>' + mem.toFixed(2).replace('.', ',') + '%</span>' + H('cpumem') + '</div><div class="meter"><i style="width:' + mem + '%"></i></div></div>' +
      '<div><div class="lb">Storage<span>' + MQ.fmt(stor) + ' MB / ' + MQ.fmt(qm.diskMB) + ' MB</span>' + H('storage') + '</div><div class="meter"><i style="width:' + MQ.pct(stor, qm.diskMB) + '%"></i></div></div></div>' +
      '<div class="grid g4">' +
      tile('Aktif kuyruklar', 'activeq', active.length, '<a href="' + b + 'queues">' + withMsg.length + ' kuyrukta mesaj var</a><a href="' + b + 'queues">' + open.length + ' kuyruk iş için açık</a>') +
      tile('Bağlı queue manager\'lar', 'connectedqm', cqn.length, '<a href="' + b + 'network/channels">' + running + ' running channel</a><a href="' + b + 'network/channels">' + problem + ' sorunlu channel</a>') +
      tile('Bağlı uygulamalar', 'application', Object.keys(apps).length, '<a href="' + b + 'applications/instances">' + inst + ' running channel instance</a><a href="' + b + 'applications/connections">' + qm.conns.length + ' MQ bağlantısı</a>') +
      tile('Son 1 saatteki mesajlar', 'msgflow', MQ.fmt(qm.stats.msgsLastHour), '<span>' + String(qm.stats.bytesIn).replace('.', ',') + ' MB giriş</span><span>' + String(qm.stats.bytesOut).replace('.', ',') + ' MB çıkış</span>') +
      '</div><div class="grid g4 mt24">' +
      '<div class="tile"><div class="tile-h">En derin kuyruklar' + H('curdepth') + '</div><ul class="tile-list">' + deep.map(function (q) {
        return '<li>' + I('queue') + '<span class="nm"><a href="' + MQ.qLink(qm.name, q.name) + '">' + E(q.name) + '</a></span><span class="val">' + MQ.fmt(q.curdepth) + ' / ' + MQ.fmt(q.maxdepth) + '</span></li>';
      }).join('') + '</ul></div>' +
      '<div class="tile"><div class="tile-h">Bağlı queue manager\'lar' + H('connectedqm') + '</div>' + (cqn.length ? '<ul class="tile-list">' + cqn.map(function (n) {
        return '<li>' + I('qm') + '<div class="nm"><span class="sub">' + E(n) + '</span>' + cq[n].map(function (c) { return '<span class="sub2">' + E(c.chltype) + ': <a href="' + MQ.chLink(qm.name, c.name) + '">' + E(c.name) + '</a></span>'; }).join('') + '</div></li>';
      }).join('') + '</ul>' : '<div class="empty">' + I('info') + '<div>Bağlı queue manager yok<br>Queue manager\'ları bağladığınızda bağlantıları burada görünür.</div></div>') + '</div>' +
      '<div class="tile"><div class="tile-h">En son bağlananlar' + H('connection') + '</div><ul class="tile-list">' + recent.map(function (c) {
        return '<li>' + I('app') + '<div class="nm"><a href="' + b + 'applications/connections">' + E(c.appltag) + '</a><span class="sub">' + (c.channel ? 'Channel: ' + E(c.channel) : 'Yerel (bindings) bağlantı') + '</span><span class="sub2">Bağlandı: ' + E(c.conntime.slice(11)) + '</span></div></li>';
      }).join('') + '</ul></div>' +
      '<div class="tile"><div class="tile-h">En eski mesajlar' + H('msgage') + '</div><ul class="tile-list">' + oldest.map(function (q) {
        return '<li>' + I('queue') + '<span class="nm"><a href="' + MQ.qLink(qm.name, q.name) + '">' + E(q.name) + '</a></span><span class="val">' + MQ.ago(q.msgage) + '</span></li>';
      }).join('') + '</ul></div>' +
      '</div>' +
      '<h2 class="section-title">Queue manager bilgileri' + H('qmgr') + '</h2>' +
      '<div class="tile" style="padding:16px 24px"><dl class="kv">' +
      '<dt>Queue manager adı' + H('qmname') + '</dt><dd>' + E(qm.name) + (qm.isDefault ? ' ' + MQ.tag('Default queue manager', 'outline') + H('defaultqm') : '') + '</dd>' +
      '<dt>Açıklama' + H('qm.descr') + '</dt><dd>' + E(qm.attrs.DESCR) + '</dd>' +
      '<dt>Sürüm / Command level' + H('qm.cmdlevel') + '</dt><dd>' + E(qm.version) + ' / ' + qm.cmdlevel + '</dd>' +
      '<dt>Platform / İşletim sistemi' + H('platform') + '</dt><dd>' + E(qm.platform) + ' — ' + E(qm.os) + '</dd>' +
      '<dt>Host' + H('ch.conname') + '</dt><dd>' + E(qm.host) + ' (' + E(qm.ip) + '), listener port ' + qm.port + '</dd>' +
      '<dt>Installation' + H('installation') + '</dt><dd>' + E(qm.installation) + ' — ' + E(qm.instPath) + '</dd>' +
      '<dt>Veri dizini' + H('datapath') + '</dt><dd class="mono-sm">' + E(qm.dataPath) + '</dd>' +
      '<dt>Yüksek erişilebilirlik' + H('ha') + '</dt><dd>' + E(qm.ha) + '</dd>' +
      '<dt>Recovery log' + H('logtype') + '</dt><dd>' + E(qm.logType) + ' — ' + qm.logPrimary + ' primary + ' + qm.logSecondary + ' secondary × ' + MQ.fmt(qm.logFilePages) + ' sayfa (4 KB)</dd>' +
      '<dt>Başlatılma zamanı' + H('qmstatus') + '</dt><dd>' + E(qm.started) + '</dd>' +
      '<dt>Cluster' + H('cluster') + '</dt><dd>' + (qm.cluster ? E(qm.cluster.name) + ' — ' + E(qm.cluster.role) : '-') + '</dd>' +
      '</dl></div></div>';
  }), 'manage');

  /* ================================================== QUEUES */
  MQ.route('/qm/:qm/queues', qmPage('queues', function (qm) {
    var id = 'queues-' + qm.name;
    if (!MQ._tstate[id]) MQ._tstate[id] = { q: '', sort: null, page: 1, size: 20, flt: { 1: 'user' } };
    var loc = qm.queues.filter(function (q) { return q.type === 'QLOCAL'; });
    var cnt = function (s, sys) { return loc.filter(function (q) { return MQ.depthState(q) === s && !!q.system === sys; }).length; };
    var mini = function (cls, s, label, help) {
      return '<div class="tile"><div class="mini-stat"><div class="num">' + (cnt(s, false) + cnt(s, true)) + '</div><div class="lbl"><span class="st"><i class="' + cls + '"></i></span>' + label + H(help) + '</div></div>' +
        '<div class="tile-foot"><span>' + cnt(s, false) + ' kullanıcı tanımlı</span><span>' + cnt(s, true) + ' sistem kuyruğu</span></div></div>';
    };
    var notice = MQ.ui && MQ.ui.hideSysNotice ? '' : '<div class="notice mt24">' + I('info') + '<div class="grow"><b>Sistem kuyruklarını tabloda mı arıyorsunuz?</b> Tablo varsayılan olarak yalnızca kullanıcı tanımlı kuyrukları gösterir. "Kuyruklar" filtresinden <i>Sistem</i> veya <i>Tümü</i> seçin.' + H('systemq') + '</div><button class="x" data-do="' + MQ.fn(function () { MQ.ui = MQ.ui || {}; MQ.ui.hideSysNotice = true; MQ.refresh(); }) + '" aria-label="Kapat">' + I('close').replace('<svg', '<svg width="16" height="16"') + '</button></div>';
    return '<div class="content"><div class="grid g4" style="max-width:1100px;grid-template-columns:repeat(3,1fr)">' +
      mini('err', 'full', 'Queue depth full', 'qfull') + mini('warn', 'warn', 'Queue depth warning', 'qdepthhi') + mini('ok', 'normal', 'Queue depth normal', 'curdepth') + '</div>' + notice +
      '<div class="mt24">' + MQ.queueTable(qm, id) + '</div></div>';
  }), 'manage');

  MQ.queueTable = function (qm, id) {
    var TYPES = [['Local', 'Local'], ['Remote', 'Remote'], ['Alias', 'Alias'], ['Model', 'Model'], ['Cluster', 'Cluster'], ['Transmission', 'Transmission'], ['Dead letter', 'Dead letter'], ['Initiation', 'Initiation'], ['Backout', 'Backout']];
    return MQ.table({
      id: id, pageSize: 20, info: function (n, t) { return t + ' kuyruktan ' + n + ' tanesi gösteriliyor'; },
      rows: function () { return qm.queues; },
      filters: [
        { label: 'Tür', options: TYPES, fn: function (q, v) { return MQ.qTypeLabel(q) === v || MQ.qRoles(qm, q).indexOf(v) >= 0; } },
        { label: 'Kuyruklar', options: [['user', 'Kullanıcı tanımlı'], ['system', 'Sistem']], fn: function (q, v) { return v === 'system' ? q.system : !q.system; } }
      ],
      columns: [
        { key: 'name', label: 'Name', help: 'qname', render: function (q) { return '<a href="' + MQ.qLink(qm.name, q.name) + '">' + E(q.name) + '</a>'; } },
        { key: 'type', label: 'Type', help: 'qtype', val: function (q) { return MQ.qTypeLabel(q); }, render: function (q) { return MQ.qTypeCell(qm, q); } },
        { key: 'pct', label: 'Depth %', help: 'curdepth', num: true, val: function (q) { return q.type === 'QLOCAL' ? MQ.pct(q.curdepth, q.maxdepth) : -1; }, render: function (q) {
          if (q.type !== 'QLOCAL') return '<span class="dim">-</span>';
          var s = MQ.depthState(q), p = MQ.pct(q.curdepth, q.maxdepth);
          return (s === 'full' ? '<span class="st"><i class="err"></i>' : s === 'warn' ? '<span class="st"><i class="warn"></i>' : '<span>') + p + '%</span>';
        } },
        { key: 'maxdepth', label: 'Maximum depth', help: 'maxdepth', val: function (q) { return q.type === 'QLOCAL' ? q.curdepth : -1; }, render: function (q) { return q.type === 'QLOCAL' ? MQ.fmt(q.curdepth) + '/' + MQ.fmt(q.maxdepth) : (q.type === 'QMODEL' ? '<span class="dim">' + MQ.fmt(q.maxdepth) + ' (şablon)</span>' : '<span class="dim">-</span>'); } },
        { key: 'conns', label: 'Current connections', help: 'ipprocs', val: function (q) { return q.ipprocs + q.opprocs; }, render: function (q) { return q.type === 'QLOCAL' ? 'Input ' + q.ipprocs + ', Output ' + q.opprocs : '<span class="dim">-</span>'; } },
        { key: 'apps', label: 'Attached apps', help: 'application', val: function (q) { return MQ.attachedApps(qm, q).length; }, render: function (q) { var n = MQ.attachedApps(qm, q).length; return n ? n : '-'; } },
        { key: 'lput', label: 'Last put', help: 'lput', render: function (q) { return q.lput ? E(q.lput.slice(5, 16)) : '-'; } },
        { key: 'lget', label: 'Last get', help: 'lput', render: function (q) { return q.lget ? E(q.lget.slice(5, 16)) : '-'; } }
      ],
      create: { label: 'Create', fn: function () { MQ.act.createQueue(qm); } },
      overflow: function (q) { return MQ.queueMenu(qm, q); }
    });
  };
  MQ.attachedApps = function (qm, q) {
    var m = {}; qm.conns.forEach(function (c) { if (c.objects && c.objects.indexOf(q.name + ' ') === 0 || (c.objects && c.objects.indexOf(', ' + q.name + ' ') >= 0)) m[c.appltag] = 1; }); return Object.keys(m);
  };
  MQ.queueMenu = function (qm, q) {
    var loc = q.type === 'QLOCAL', a = MQ.act;
    var items = [{ label: 'Görüntüle', fn: function () { MQ.go(MQ.qLink(qm.name, q.name)); } }];
    if (loc) items.push({ label: 'Mesajlara göz at (Browse)', fn: function () { MQ.go(MQ.qLink(qm.name, q.name) + '/messages'); } });
    if (q.type !== 'QMODEL') items.push({ label: 'Mesaj koy (Put)', fn: function () { a.putMessage(qm, q); }, disabled: q.type === 'QCLUSTER' ? false : false });
    if (loc || q.type === 'QALIAS') items.push({ label: 'Mesaj al (Get)', fn: function () { a.getMessage(qm, q); } });
    if (loc) items.push({ label: 'Kuyruğu temizle (Clear)', fn: function () { a.clearQueue(qm, q); } });
    if (q.type !== 'QCLUSTER') { items.push('-'); items.push({ label: 'Özellikleri düzenle', fn: function () { MQ.go(MQ.qLink(qm.name, q.name) + '/properties'); MQ.ui = MQ.ui || {}; MQ.ui.editQ = q.name; } }); items.push({ label: 'Sil', danger: true, fn: function () { a.deleteQueue(qm, q); } }); }
    return items;
  };

  /* ================================================== EVENTS (Publish/Subscribe) */
  function eventsPage(sub) {
    return qmPage('events', function (qm) {
      var b = '#/qm/' + MQ.enc(qm.name) + '/events';
      var side = MQ.sidenav([{ key: 'overview', label: 'Genel Bakış', href: b }, { key: 'topics', label: 'Topics', href: b + '/topics' }, { key: 'subs', label: 'Subscriptions', href: b + '/subscriptions' }], sub);
      var body = '';
      var ut = qm.topics.filter(function (t) { return !t.system; }), us = qm.subs.filter(function (s) { return !s.system; });
      if (sub === 'overview') {
        var dur = us.filter(function (s) { return s.durable === 'YES'; }).length;
        body = '<div class="grid g3">' +
          tile('Topic nesneleri', 'topic', ut.length, '<a href="' + b + '/topics">' + ut.filter(function (t) { return t.cluster; }).length + ' cluster topic</a><span>' + ut.filter(function (t) { return t.pub === 'DISABLED'; }).length + ' yayına kapalı</span>') +
          tile('Subscriptions', 'subscription', us.length, '<a href="' + b + '/subscriptions">' + dur + ' durable</a><a href="' + b + '/subscriptions">' + (us.length - dur) + ' non-durable</a>') +
          tile('Pub/Sub motoru', 'qm.psmode', '<span style="font-size:32px">' + E(qm.attrs.PSMODE) + '</span>', '<span>PSMODE(' + E(qm.attrs.PSMODE) + ')</span><span>Yayınlanan mesaj: ' + MQ.fmt(ut.reduce(function (a, t) { return a + (t.msgs || 0); }, 0)) + '</span>') + '</div>' +
          '<div class="grid g2 mt24"><div class="tile"><div class="tile-h">Topic başına publisher / subscriber' + H('pubsubstats') + '</div>' +
          MQ.barChart({ labels: ut.map(function (t) { return t.name.replace('.TOPIC', ''); }), series: [{ name: 'Publisher', data: ut.map(function (t) { return t.pubs; }) }, { name: 'Subscriber', data: ut.map(function (t) { return t.subs; }) }], height: 200 }) + '</div>' +
          '<div class="tile"><div class="tile-h">Topic ağacı' + H('topicstring') + '</div><div style="padding:0 16px 16px" class="mono-sm">' + topicTree(qm) + '</div></div></div>';
      } else if (sub === 'topics') {
        body = MQ.table({
          id: 'topics-' + qm.name, rows: function () { return qm.topics; },
          columns: [
            { key: 'name', label: 'Topic name', help: 'topicname', render: function (t) { return '<a data-do="' + MQ.fn(function () { MQ.act.topicDetail(qm, t); }) + '" href="#">' + E(t.name) + '</a>'; } },
            { key: 'topicstr', label: 'Topic string', help: 'topicstring', render: function (t) { return '<span class="mono-sm">' + (t.topicstr ? E(t.topicstr) : '<span class="dim">(root)</span>') + '</span>'; } },
            { key: 'pub', label: 'Publish', help: 'topic.pub', render: function (t) { return MQ.status(t.pub === 'ENABLED' ? 'Enabled' : 'Disabled'); } },
            { key: 'sub', label: 'Subscribe', help: 'topic.pub', render: function (t) { return MQ.status(t.sub === 'ENABLED' ? 'Enabled' : 'Disabled'); } },
            { key: 'dursub', label: 'Durable sub', help: 'durablesub' },
            { key: 'cluster', label: 'Cluster', help: 'clustertopic', render: function (t) { return t.cluster ? E(t.cluster) + ' (' + E(t.clroute) + ')' : '-'; } },
            { key: 'pubs', label: 'Publishers', num: true, help: 'pubsubstats' },
            { key: 'subs', label: 'Subscribers', num: true, help: 'pubsubstats' }
          ],
          create: { label: 'Create', fn: function () { MQ.act.createTopic(qm); } },
          overflow: function (t) { return [{ label: 'Ayrıntılar', fn: function () { MQ.act.topicDetail(qm, t); } }, { label: 'Test mesajı yayınla', fn: function () { MQ.act.publish(qm, t); }, disabled: t.pub !== 'ENABLED' }, '-', { label: 'Sil', danger: true, disabled: !!t.system, fn: function () { MQ.act.deleteObj(qm, 'topics', t, 'TOPIC'); } }]; }
        });
      } else {
        body = MQ.table({
          id: 'subs-' + qm.name, rows: function () { return qm.subs; },
          columns: [
            { key: 'name', label: 'Subscription name', help: 'subname', render: function (s) { return '<a data-do="' + MQ.fn(function () { MQ.act.subDetail(qm, s); }) + '" href="#">' + E(s.name) + '</a>'; } },
            { key: 'topicstr', label: 'Topic string', help: 'topicstring', render: function (s) { return '<span class="mono-sm">' + E(s.topicstr) + '</span>'; } },
            { key: 'subtype', label: 'Type', help: 'subtype' },
            { key: 'durable', label: 'Durable', help: 'durablesub', render: function (s) { return s.durable === 'YES' ? MQ.tag('Durable', 'blue') : MQ.tag('Non-durable', 'gray'); } },
            { key: 'dest', label: 'Destination queue', help: 'subdest', render: function (s) { return '<span class="mono-sm">' + E(s.dest) + '</span>'; } },
            { key: 'destclas', label: 'Dest class', help: 'subdest' },
            { key: 'msgs', label: 'Mesaj', num: true, help: 'pubsubstats' },
            { key: 'lastmsg', label: 'Son mesaj' }
          ],
          create: { label: 'Create', fn: function () { MQ.act.createSub(qm); } },
          overflow: function (s) { return [{ label: 'Ayrıntılar', fn: function () { MQ.act.subDetail(qm, s); } }, '-', { label: 'Sil', danger: true, disabled: s.durable !== 'YES' || s.system ? 'Non-durable abonelikler uygulama bağlantısı kapanınca otomatik silinir' : false, fn: function () { MQ.act.deleteObj(qm, 'subs', s, 'SUB'); } }]; }
        });
      }
      return '<div class="content with-side">' + side + '<div>' + body + '</div></div>';
    });
  }
  function topicTree(qm) {
    var root = {}; qm.topics.concat(qm.subs.map(function (s) { return { topicstr: s.topicstr, sub: true }; })).forEach(function (t) {
      if (!t.topicstr) return; var n = root; t.topicstr.split('/').forEach(function (p) { n = n[p] = n[p] || {}; });
    });
    function walk(n, d) { return Object.keys(n).map(function (k) { return '<div style="padding:3px 0 3px ' + (d * 18) + 'px">' + (d ? '└ ' : '') + E(k) + '</div>' + walk(n[k], d + 1); }).join(''); }
    return '<div>/ <span class="dim">(SYSTEM.BASE.TOPIC)</span></div>' + walk(root, 1);
  }
  MQ.route('/qm/:qm/events', eventsPage('overview'), 'manage');
  MQ.route('/qm/:qm/events/topics', eventsPage('topics'), 'manage');
  MQ.route('/qm/:qm/events/subscriptions', eventsPage('subs'), 'manage');

  /* ================================================== APPLICATIONS */
  function appsPage(sub) {
    return qmPage('applications', function (qm) {
      var b = '#/qm/' + MQ.enc(qm.name) + '/applications';
      var side = MQ.sidenav([{ key: 'overview', label: 'Genel Bakış', href: b }, { key: 'apps', label: 'Connected applications', href: b + '/apps' }, { key: 'connections', label: 'Connections', href: b + '/connections' }, { key: 'channels', label: 'App channels', href: b + '/channels' }, { key: 'instances', label: 'App channel instances', href: b + '/instances' }], sub);
      var appCh = qm.channels.filter(function (c) { return c.chltype === 'SVRCONN' || c.chltype === 'CLNTCONN'; });
      var inst = []; appCh.forEach(function (c) { (c.inst || []).forEach(function (i) { inst.push(Object.assign({ channel: c.name }, i)); }); });
      var apps = {}; qm.conns.forEach(function (c) { var a = apps[c.appltag] = apps[c.appltag] || { name: c.appltag, type: c.appltype, conns: 0, channels: {}, users: {}, hosts: {} }; a.conns++; if (c.channel) a.channels[c.channel] = 1; a.users[c.userid] = 1; a.hosts[c.conname] = 1; });
      var appList = Object.keys(apps).map(function (k) { var a = apps[k]; return { name: a.name, type: a.type, conns: a.conns, channels: Object.keys(a.channels).join(', '), users: Object.keys(a.users).join(', '), hosts: Object.keys(a.hosts).length }; });
      var body;
      if (sub === 'overview') {
        var userApps = appList.filter(function (a) { return a.type !== 'SYSTEM'; });
        var remote = qm.conns.filter(function (c) { return c.channel && c.appltype !== 'SYSTEM'; }).length;
        var byCh = {}; inst.forEach(function (i) { byCh[i.channel] = (byCh[i.channel] || 0) + 1; });
        var vers = {}; inst.forEach(function (i) { vers[i.clientVer] = (vers[i.clientVer] || 0) + 1; });
        var prot = {}; appCh.forEach(function (c) { if (c.chltype !== 'SVRCONN') return; var p = /TLS_AES|TLS13/.test(c.sslciph) ? 'TLS 1.3' : c.sslciph ? 'TLS 1.2+' : 'TLS yok'; prot[p] = (prot[p] || 0) + 1; });
        body = '<div class="grid g3">' +
          tile('Bağlı uygulamalar', 'application', userApps.length, '<a href="' + b + '/instances">' + inst.length + ' uygulama instance\'ı</a><a href="' + b + '/connections">' + qm.conns.length + ' bağlantı</a>') +
          tile('Çalışan app channel instance', 'chinstance', inst.length, '<a href="' + b + '/channels">' + appCh.filter(function (c) { return c.chltype === 'SVRCONN'; }).length + ' kullanıcı tanımlı channel</a><a href="' + b + '/channels">' + appCh.filter(function (c) { return c.status === 'Inactive'; }).length + ' inactive channel</a>') +
          tile('Bağlantılar', 'connection', qm.conns.length, '<span>' + (qm.conns.length - remote) + ' yerel (bindings)</span><span>' + remote + ' uzak (client)</span>') + '</div>' +
          '<div class="grid g3 mt24">' +
          '<div class="tile"><div class="tile-h">En yaygın uygulamalar' + H('appltag') + '</div><ul class="tile-list">' + userApps.sort(function (a, c) { return c.conns - a.conns; }).slice(0, 4).map(function (a) { return '<li>' + I('app') + '<div class="nm"><a href="' + b + '/apps">' + E(a.name) + '</a><span class="sub">Bağlantı: ' + a.conns + '</span></div></li>'; }).join('') + '</ul></div>' +
          '<div class="tile"><div class="tile-h">En yaygın app channel\'lar' + H('svrconn') + '</div><ul class="tile-list">' + Object.keys(byCh).map(function (k) { return '<li><div class="nm"><a href="' + MQ.chLink(qm.name, k) + '">' + E(k) + '</a><span class="sub">Instance: ' + byCh[k] + '</span></div></li>'; }).join('') + '</ul></div>' +
          '<div class="tile"><div class="tile-h">En eski transaction\'lar' + H('uow') + '</div><ul class="tile-list">' + qm.conns.filter(function (c) { return c.uow !== '-'; }).slice(0, 4).map(function (c) { return '<li>' + I('app') + '<span class="nm">' + E(c.appltag) + '</span><span class="val">' + E(c.conntime.slice(11)) + '</span></li>'; }).join('') + '</ul></div>' +
          '<div class="tile"><div class="tile-h">Uzak bağlantı (istemci) sürümleri' + H('clientver') + '</div><ul class="tile-list">' + Object.keys(vers).map(function (v) { return '<li><span class="nm">' + E(v) + '</span><span class="val">' + vers[v] + ' instance</span></li>'; }).join('') + '</ul></div>' +
          '<div class="tile"><div class="tile-h">Application channel güvenliği' + H('tls') + '</div><ul class="tile-list">' + Object.keys(prot).map(function (p) { return '<li><span class="nm">' + E(p) + '</span><span class="val">' + prot[p] + ' channel</span></li>'; }).join('') + '</ul></div>' +
          '<div class="tile"><div class="tile-h">En yüksek transfer hızları' + H('chmonitor') + '</div><ul class="tile-list">' + Object.keys(byCh).map(function (k, i) { return '<li><span class="nm"><a href="' + MQ.chLink(qm.name, k) + '">' + E(k) + '</a></span><span class="val">' + (12.4 / (i + 1)).toFixed(2) + ' MQI çağrısı/sn</span></li>'; }).join('') + '</ul></div></div>';
      } else if (sub === 'apps') {
        body = MQ.table({ id: 'apps-' + qm.name, rows: function () { return appList; }, defaultSort: { key: 'conns', dir: 'desc' },
          columns: [
            { key: 'name', label: 'Application name (APPLTAG)', help: 'appltag' },
            { key: 'type', label: 'Type', help: 'appltype' },
            { key: 'conns', label: 'Connections', num: true, help: 'connection' },
            { key: 'channels', label: 'Channels', help: 'svrconn', render: function (a) { return a.channels ? E(a.channels) : '<span class="dim">yerel (bindings)</span>'; } },
            { key: 'users', label: 'User ID', help: 'ch.mcauser' },
            { key: 'hosts', label: 'Farklı host', num: true }
          ] });
      } else if (sub === 'connections') {
        body = MQ.table({ id: 'conns-' + qm.name, rows: function () { return qm.conns; }, pageSize: 20,
          filters: [{ label: 'Tür', options: [['client', 'Client (uzak)'], ['local', 'Bindings (yerel)'], ['SYSTEM', 'Sistem']], fn: function (c, v) { return v === 'client' ? !!c.channel && c.appltype !== 'SYSTEM' : v === 'local' ? !c.channel : c.appltype === 'SYSTEM'; } }],
          columns: [
            { key: 'connid', label: 'Connection ID', help: 'connid', render: function (c) { return '<span class="mono-sm">' + E(c.connid.slice(0, 16)) + '…</span>'; } },
            { key: 'appltag', label: 'Application', help: 'appltag' },
            { key: 'channel', label: 'Channel', help: 'svrconn', render: function (c) { return c.channel ? E(c.channel) : '-'; } },
            { key: 'conname', label: 'Connection name', help: 'ch.conname' },
            { key: 'userid', label: 'User ID', help: 'ch.mcauser' },
            { key: 'pid', label: 'PID', num: true },
            { key: 'conntime', label: 'Bağlanma zamanı' },
            { key: 'uow', label: 'UOW', help: 'uow' }
          ],
          overflow: function (c) { return [{ label: 'Ayrıntılar (DISPLAY CONN)', fn: function () { MQ.act.connDetail(qm, c); } }, { label: 'Bağlantıyı sonlandır (STOP CONN)', danger: true, disabled: c.appltype === 'SYSTEM', fn: function () { MQ.act.stopConn(qm, c); } }]; } });
      } else if (sub === 'channels') {
        body = MQ.table({ id: 'appch-' + qm.name, rows: function () { return qm.channels.filter(function (c) { return c.chltype === 'SVRCONN' || c.chltype === 'CLNTCONN'; }); },
          columns: [
            { key: 'name', label: 'Name', help: 'chname', render: function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '">' + E(c.name) + '</a>'; } },
            { key: 'chltype', label: 'Type', help: 'chltype', render: function (c) { return E(c.chltype) + H(c.chltype.toLowerCase()); } },
            { key: 'status', label: 'Status', help: 'chstatus', render: function (c) { return MQ.status(c.status); } },
            { key: 'inst', label: 'Instances', num: true, help: 'chinstance', val: function (c) { return c.inst ? c.inst.length : 0; }, render: function (c) { return c.inst ? c.inst.length : 0; } },
            { key: 'maxinst', label: 'MAXINST', num: true, help: 'ch.maxinst', render: function (c) { return c.chltype === 'SVRCONN' ? MQ.fmt(c.maxinst) : '-'; } },
            { key: 'maxinstc', label: 'MAXINSTC', num: true, help: 'ch.maxinstc', render: function (c) { return c.chltype === 'SVRCONN' ? MQ.fmt(c.maxinstc) : '-'; } },
            { key: 'sharecnv', label: 'SHARECNV', num: true, help: 'ch.sharecnv' },
            { key: 'sslciph', label: 'CipherSpec', help: 'ch.sslciph', render: function (c) { return c.sslciph ? '<span class="mono-sm">' + E(c.sslciph) + '</span>' : MQ.tag('TLS yok', 'red'); } }
          ],
          create: { label: 'Create', fn: function () { MQ.act.createChannel(qm, 'SVRCONN'); } },
          overflow: function (c) { return MQ.channelMenu(qm, c); } });
      } else {
        body = MQ.table({ id: 'appinst-' + qm.name, rows: function () { return inst; }, pageSize: 20,
          columns: [
            { key: 'channel', label: 'Channel', help: 'chinstance', render: function (i) { return '<a href="' + MQ.chLink(qm.name, i.channel) + '">' + E(i.channel) + '</a>'; } },
            { key: 'conname', label: 'Connection name', help: 'ch.conname' },
            { key: 'appltag', label: 'Application', help: 'appltag' },
            { key: 'mcauser', label: 'MCA user', help: 'ch.mcauser' },
            { key: 'msgs', label: 'Messages', num: true, help: 'chmonitor' },
            { key: 'bytessent', label: 'Bytes sent', num: true, render: function (i) { return MQ.bytes(i.bytessent); } },
            { key: 'curshcnv', label: 'Paylaşılan konuşma', num: true, help: 'ch.sharecnv' },
            { key: 'sslciph', label: 'CipherSpec', help: 'ch.sslciph', render: function (i) { return '<span class="mono-sm">' + E(i.sslciph) + '</span>'; } },
            { key: 'clientVer', label: 'İstemci sürümü', help: 'clientver' }
          ] });
      }
      return '<div class="content with-side">' + side + '<div>' + body + '</div></div>';
    });
  }
  MQ.route('/qm/:qm/applications', appsPage('overview'), 'manage');
  MQ.route('/qm/:qm/applications/apps', appsPage('apps'), 'manage');
  MQ.route('/qm/:qm/applications/connections', appsPage('connections'), 'manage');
  MQ.route('/qm/:qm/applications/channels', appsPage('channels'), 'manage');
  MQ.route('/qm/:qm/applications/instances', appsPage('instances'), 'manage');

  /* ================================================== MQ NETWORK */
  MQ.channelMenu = function (qm, c) {
    var a = MQ.act, t = c.chltype, items = [{ label: 'Görüntüle', fn: function () { MQ.go(MQ.chLink(qm.name, c.name)); } }];
    if (t !== 'CLNTCONN') {
      items.push({ label: 'Başlat (START CHANNEL)', fn: function () { a.startChannel(qm, c); }, disabled: c.status === 'Running' || t === 'RCVR' && false });
      items.push({ label: 'Durdur (STOP CHANNEL)', fn: function () { a.stopChannel(qm, c); }, disabled: c.status === 'Stopped' });
    }
    if (t === 'SDR' || t === 'SVR' || t === 'CLUSSDR') items.push({ label: 'Ping (PING CHANNEL)', fn: function () { a.pingChannel(qm, c); } });
    if (['SDR', 'SVR', 'RCVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR'].indexOf(t) >= 0) items.push({ label: 'Sıra numarasını sıfırla (RESET)', fn: function () { a.resetChannel(qm, c); } });
    items.push('-');
    items.push({ label: 'Özellikleri düzenle', fn: function () { MQ.ui = MQ.ui || {}; MQ.ui.editCh = c.name; MQ.go(MQ.chLink(qm.name, c.name) + '/properties'); } });
    items.push({ label: 'Sil', danger: true, disabled: c.auto ? 'Otomatik tanımlı cluster sender silinemez' : false, fn: function () { a.deleteChannel(qm, c); } });
    return items;
  };
  MQ.channelTable = function (qm, id, rowsFn, createType) {
    return MQ.table({
      id: id, rows: rowsFn, pageSize: 20,
      filters: [
        { label: 'Tür', options: ['SDR', 'RCVR', 'SVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR', 'SVRCONN', 'CLNTCONN'], fn: function (c, v) { return c.chltype === v; } },
        { label: 'Durum', options: ['Running', 'Inactive', 'Retrying', 'Stopped'], fn: function (c, v) { return c.status === v; } }
      ],
      columns: [
        { key: 'name', label: 'Name', help: 'chname', render: function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '">' + E(c.name) + '</a>' + (c.auto ? ' ' + MQ.tag('auto', 'gray') : ''); } },
        { key: 'chltype', label: 'Type', help: 'chltype', render: function (c) { return E(c.chltype) + H(MQ.chTypeHelp(c.chltype)); } },
        { key: 'status', label: 'Status', help: 'chstatus', render: function (c) { return MQ.status(c.status); } },
        { key: 'conname', label: 'Connection name', help: 'ch.conname', render: function (c) { return c.conname ? '<span class="mono-sm">' + E(c.conname) + '</span>' : '-'; } },
        { key: 'xmitq', label: 'Transmission queue', help: 'ch.xmitq', render: function (c) { return c.xmitq ? '<a href="' + MQ.qLink(qm.name, c.xmitq) + '">' + E(c.xmitq) + '</a>' : (c.chltype === 'CLUSSDR' ? '<span class="dim">' + (qm.attrs.DEFCLXQ === 'CHANNEL' ? 'SYSTEM.CLUSTER.TRANSMIT.' + E(c.name) : 'SYSTEM.CLUSTER.TRANSMIT.QUEUE') + '</span>' : '-'); } },
        { key: 'cluster', label: 'Cluster', help: 'cluster' },
        { key: 'sslciph', label: 'CipherSpec', help: 'ch.sslciph', render: function (c) { return c.sslciph ? '<span class="mono-sm">' + E(c.sslciph) + '</span>' : MQ.tag('TLS yok', 'red'); } }
      ],
      create: { label: 'Create', fn: function () { MQ.act.createChannel(qm, createType); } },
      overflow: function (c) { return MQ.channelMenu(qm, c); }
    });
  };
  MQ.chTypeHelp = function (t) { return { SDR: 'sender', RCVR: 'receiver', SVR: 'server', RQSTR: 'requester', SVRCONN: 'svrconn', CLNTCONN: 'clntconn', CLUSSDR: 'clussdr', CLUSRCVR: 'clusrcvr' }[t]; };

  function netPage(sub) {
    return qmPage('network', function (qm) {
      var b = '#/qm/' + MQ.enc(qm.name) + '/network';
      var side = MQ.sidenav([{ key: 'overview', label: 'Genel Bakış', href: b }, { key: 'channels', label: 'Queue manager channels', href: b + '/channels' }, { key: 'instances', label: 'Channel instances', href: b + '/instances' }, { key: 'remote', label: 'Remote queue managers', href: b + '/remote' }, { key: 'cluster', label: 'MQ Cluster', href: b + '/cluster' }], sub);
      var qch = function () { return qm.channels.filter(function (c) { return c.chltype !== 'SVRCONN' && c.chltype !== 'CLNTCONN'; }); };
      var body;
      if (sub === 'overview') {
        var list = qch(), by = function (s) { return list.filter(function (c) { return c.status === s; }).length; };
        var rq = remoteQms(qm);
        body = '<div class="grid g4">' +
          '<div class="tile"><div class="mini-stat"><div class="num">' + by('Running') + '</div><div class="lbl">' + MQ.status('Running') + H('chstatus') + '</div></div></div>' +
          '<div class="tile"><div class="mini-stat"><div class="num">' + by('Retrying') + '</div><div class="lbl">' + MQ.status('Retrying') + H('chretry') + '</div></div></div>' +
          '<div class="tile"><div class="mini-stat"><div class="num">' + by('Stopped') + '</div><div class="lbl">' + MQ.status('Stopped') + H('chstopped') + '</div></div></div>' +
          '<div class="tile"><div class="mini-stat"><div class="num">' + by('Inactive') + '</div><div class="lbl">' + MQ.status('Inactive') + H('chinactive') + '</div></div></div></div>' +
          '<h2 class="section-title">Queue manager bağlantı haritası' + H('distqueuing') + '</h2>' + netDiagram(qm, rq) +
          (list.some(function (c) { return c.status === 'Retrying'; }) ? '<div class="notice warn mt16">' + I('warning') + '<div class="grow"><b>RETRYING durumunda channel var.</b> ' + list.filter(function (c) { return c.status === 'Retrying'; }).map(function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '">' + E(c.name) + '</a>'; }).join(', ') + ' — karşı tarafa bağlanılamıyor, mesajlar transmission queue\'da birikiyor. Hata log\'unda AMQ9202E kaydını inceleyin.' + H('chretry') + '</div><a class="btn sm secondary" href="#/qm/' + MQ.enc(qm.name) + '/config/logs">Hata log\'u</a></div>' : '');
      } else if (sub === 'channels') {
        body = MQ.channelTable(qm, 'qmch-' + qm.name, qch, 'SDR');
      } else if (sub === 'instances') {
        body = MQ.table({ id: 'chinst-' + qm.name, rows: function () { return qch().filter(function (c) { return c.status === 'Running' || c.status === 'Retrying' || c.status === 'Binding'; }); },
          columns: [
            { key: 'name', label: 'Channel', help: 'chstatus', render: function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '/status">' + E(c.name) + '</a>'; } },
            { key: 'chltype', label: 'Type', help: 'chltype' },
            { key: 'status', label: 'Status', help: 'chstatus', render: function (c) { return MQ.status(c.status); } },
            { key: 'rqm', label: 'Remote QM', help: 'connectedqm', val: function (c) { return c.st && c.st.rqmname; }, render: function (c) { return E(c.st && c.st.rqmname || '-'); } },
            { key: 'msgs', label: 'Messages', num: true, help: 'chmonitor', val: function (c) { return c.st ? c.st.msgs || 0 : 0; }, render: function (c) { return MQ.fmt(c.st ? c.st.msgs || 0 : 0); } },
            { key: 'bs', label: 'Bytes sent', num: true, val: function (c) { return c.st ? c.st.bytessent || 0 : 0; }, render: function (c) { return MQ.bytes(c.st ? c.st.bytessent || 0 : 0); } },
            { key: 'br', label: 'Bytes received', num: true, val: function (c) { return c.st ? c.st.bytesrcvd || 0 : 0; }, render: function (c) { return MQ.bytes(c.st ? c.st.bytesrcvd || 0 : 0); } },
            { key: 'lst', label: 'Last message', render: function (c) { return E(c.st && c.st.lstmsg || '-'); } },
            { key: 'sub', label: 'Substate', help: 'substate', render: function (c) { return E(c.st && (c.st.substate || c.st.retries) || '-'); } }
          ] });
      } else if (sub === 'remote') {
        body = '<p style="margin-top:0">Bu queue manager\'ın distributed queuing ile mesaj gönderdiği veya aldığı diğer queue manager\'lar. Bu liste transmission queue, remote queue ve channel tanımlarından türetilir.' + H('distqueuing') + '</p>' +
          MQ.table({ id: 'rqm-' + qm.name, rows: function () { return remoteQms(qm); }, search: false,
            columns: [
              { key: 'name', label: 'Remote queue manager', help: 'qremote.rqmname' },
              { key: 'xmitq', label: 'Transmission queue', help: 'xmitq', render: function (r) { return r.xmitq ? '<a href="' + MQ.qLink(qm.name, r.xmitq) + '">' + E(r.xmitq) + '</a> (' + MQ.fmt(r.depth) + ')' : '-'; } },
              { key: 'out', label: 'Giden channel', help: 'sender', render: function (r) { return r.out ? '<a href="' + MQ.chLink(qm.name, r.out.name) + '">' + E(r.out.name) + '</a> ' + MQ.status(r.out.status) : '-'; } },
              { key: 'in', label: 'Gelen channel', help: 'receiver', render: function (r) { return r.inc ? '<a href="' + MQ.chLink(qm.name, r.inc.name) + '">' + E(r.inc.name) + '</a> ' + MQ.status(r.inc.status) : '-'; } },
              { key: 'rq', label: 'Remote queue tanımları', help: 'qremote', render: function (r) { return r.rqs.map(function (x) { return '<a href="' + MQ.qLink(qm.name, x) + '">' + E(x) + '</a>'; }).join(', ') || '-'; } }
            ] });
      } else {
        body = MQ.clusterView(qm);
      }
      return '<div class="content with-side">' + side + '<div>' + body + '</div></div>';
    });
  }
  function remoteQms(qm) {
    var m = {};
    function g(n) { return m[n] = m[n] || { name: n, xmitq: '', depth: 0, out: null, inc: null, rqs: [] }; }
    qm.queues.forEach(function (q) {
      if (q.usage === 'XMITQ' && !q.system) { var r = g(q.name); r.xmitq = q.name; r.depth = q.curdepth; }
      if (q.type === 'QREMOTE' && q.rqmname && !q.system) g(q.rqmname).rqs.push(q.name);
    });
    qm.channels.forEach(function (c) {
      if (c.chltype === 'SDR' || c.chltype === 'SVR') { var x = qm.queues.filter(function (q) { return q.name === c.xmitq; })[0]; var n = x ? x.name : c.xmitq; g(n).out = c; }
      if (c.chltype === 'RCVR' || c.chltype === 'RQSTR') { var parts = c.name.split('.'); g(parts[0]).inc = c; }
    });
    return Object.keys(m).map(function (k) { return m[k]; });
  }
  function netDiagram(qm, rq) {
    var h = 70 + rq.length * 80, cx = 140, s = '<div class="diagram"><svg viewBox="0 0 1000 ' + h + '" role="img" aria-label="Bağlantı haritası">';
    s += '<rect x="20" y="' + (h / 2 - 40) + '" width="240" height="80" fill="var(--layer2)" stroke="var(--link)" stroke-width="2"/><text x="' + cx + '" y="' + (h / 2 - 5) + '" text-anchor="middle" style="font-size:16px;font-weight:600">' + E(qm.name) + '</text><text x="' + cx + '" y="' + (h / 2 + 16) + '" text-anchor="middle" style="font-size:12px;fill:var(--text2)">' + E(qm.host) + '</text>';
    rq.forEach(function (r, i) {
      var y = 45 + i * 80, col = function (c) { return !c ? 'var(--border-strong)' : c.status === 'Running' ? '#42be65' : c.status === 'Retrying' ? '#f1c21b' : c.status === 'Stopped' ? '#fa4d56' : '#8d8d8d'; };
      s += '<line x1="260" y1="' + (h / 2 - 10) + '" x2="720" y2="' + (y + 12) + '" stroke="' + col(r.out) + '" stroke-width="2" ' + (r.out && r.out.status !== 'Running' ? 'stroke-dasharray="6 4"' : '') + '/>';
      s += '<line x1="720" y1="' + (y + 32) + '" x2="260" y2="' + (h / 2 + 10) + '" stroke="' + col(r.inc) + '" stroke-width="2" ' + (r.inc && r.inc.status !== 'Running' ? 'stroke-dasharray="6 4"' : '') + '/>';
      s += '<rect x="720" y="' + y + '" width="250" height="48" fill="var(--layer2)" stroke="var(--border-strong)"/><text x="845" y="' + (y + 20) + '" text-anchor="middle" style="font-size:14px;font-weight:600">' + E(r.name) + '</text><text x="845" y="' + (y + 38) + '" text-anchor="middle" style="font-size:11px;fill:var(--text2)">→ ' + E(r.out ? r.out.status : 'yok') + ' · ← ' + E(r.inc ? r.inc.status : 'yok') + (r.depth ? ' · xmitq: ' + r.depth : '') + '</text>';
    });
    return s + '</svg><div class="legend"><span><i style="background:#42be65"></i>Running</span><span><i style="background:#f1c21b"></i>Retrying</span><span><i style="background:#fa4d56"></i>Stopped</span><span><i style="background:#8d8d8d"></i>Inactive</span></div></div>';
  }
  MQ.route('/qm/:qm/network', netPage('overview'), 'manage');
  MQ.route('/qm/:qm/network/channels', netPage('channels'), 'manage');
  MQ.route('/qm/:qm/network/instances', netPage('instances'), 'manage');
  MQ.route('/qm/:qm/network/remote', netPage('remote'), 'manage');
  MQ.route('/qm/:qm/network/cluster', netPage('cluster'), 'manage');

  /* ---------------- MQ Cluster görünümü */
  MQ.clusterView = function (qm) {
    if (!qm.cluster) return '<div class="notice">' + I('info') + '<div class="grow"><b>Bu queue manager hiçbir cluster\'a üye değil.</b><br>Bir cluster\'a katılmak için bir CLUSRCVR ve bir full repository\'ye işaret eden CLUSSDR channel tanımlayın.' + H('cluster') + '</div><button class="btn sm" data-do="' + MQ.fn(function () { MQ.act.createChannel(qm, 'CLUSRCVR'); }) + '">CLUSRCVR oluştur</button></div>';
    var cl = qm.cluster.name;
    var members = MQ.state.qmgrs.filter(function (x) { return x.cluster && x.cluster.name === cl; });
    var cq = []; members.forEach(function (m) { m.queues.forEach(function (q) { if (q.type === 'QLOCAL' && q.cluster === cl) cq.push({ name: q.name, qm: m.name, defbind: q.defbind, clwlprty: q.clwlprty, clwlrank: q.clwlrank, put: q.put, depth: q.curdepth }); }); });
    var clch = qm.channels.filter(function (c) { return c.cluster === cl; });
    var full = members.filter(function (m) { return m.attrs.REPOS === cl; });
    var W = 900, pos = [[450, 60], [200, 200], [700, 200], [450, 300]];
    var dia = '<div class="diagram"><svg viewBox="0 0 ' + W + ' 350" role="img" aria-label="Cluster diyagramı">';
    for (var i = 0; i < members.length; i++) for (var j = i + 1; j < members.length; j++) dia += '<line x1="' + pos[i][0] + '" y1="' + pos[i][1] + '" x2="' + pos[j][0] + '" y2="' + pos[j][1] + '" stroke="var(--border-strong)" stroke-dasharray="' + (members[i].attrs.REPOS === cl && members[j].attrs.REPOS === cl ? '0' : '5 5') + '" stroke-width="2"/>';
    members.forEach(function (m, i) {
      var f = m.attrs.REPOS === cl;
      dia += '<g><rect x="' + (pos[i][0] - 95) + '" y="' + (pos[i][1] - 30) + '" width="190" height="60" fill="var(--layer2)" stroke="' + (f ? '#a56eff' : 'var(--border-strong)') + '" stroke-width="2"/><text x="' + pos[i][0] + '" y="' + (pos[i][1] - 4) + '" text-anchor="middle" style="font-size:15px;font-weight:600">' + E(m.name) + '</text><text x="' + pos[i][0] + '" y="' + (pos[i][1] + 16) + '" text-anchor="middle" style="font-size:11px;fill:var(--text2)">' + (f ? 'Full repository' : 'Partial repository') + '</text></g>';
    });
    dia += '<text x="20" y="30" style="font-size:16px;font-weight:600">' + E(cl) + '</text></svg><div class="legend"><span><i style="background:#a56eff"></i>Full repository</span><span><i style="background:var(--border-strong)"></i>Partial repository</span><span>Düz çizgi: full repository\'ler arası manuel CLUSSDR</span></div></div>';
    return '<div class="grid g4">' +
      tile('Cluster adı', 'cluster', '<span style="font-size:28px">' + E(cl) + '</span>', '<span>Bu QM: ' + E(qm.cluster.role) + H(qm.attrs.REPOS === cl ? 'fullrepos' : 'partialrepos') + '</span>') +
      tile('Cluster queue manager', 'clusqmgr', members.length, '<span>' + full.length + ' full, ' + (members.length - full.length) + ' partial repository</span>') +
      tile('Cluster queue', 'clusterq', cq.length, '<span>' + cq.filter(function (c) { return c.defbind === 'NOTFIXED'; }).length + ' adet DEFBIND(NOTFIXED)</span>') +
      tile('Cluster channel', 'clussdr', clch.length, '<span>' + clch.filter(function (c) { return c.status === 'Running'; }).length + ' running</span>') + '</div>' +
      '<h2 class="section-title">Cluster topolojisi' + H('cluster') + '</h2>' + dia +
      '<h2 class="section-title">Cluster queue manager\'lar (DISPLAY CLUSQMGR)' + H('clusqmgr') + '</h2>' +
      MQ.table({ id: 'clusqm-' + qm.name, search: false, rows: function () { return members; },
        columns: [
          { key: 'name', label: 'Queue manager', render: function (m) { return '<a href="' + MQ.qmLink(m.name) + '">' + E(m.name) + '</a>'; } },
          { key: 'qmtype', label: 'QMTYPE', help: 'fullrepos', val: function (m) { return m.attrs.REPOS === cl ? 'REPOS' : 'NORMAL'; }, render: function (m) { return m.attrs.REPOS === cl ? MQ.tag('REPOS (full)', 'purple') : MQ.tag('NORMAL (partial)', 'gray'); } },
          { key: 'ch', label: 'CLUSRCVR channel', help: 'clusrcvr', render: function (m) { var c = m.channels.filter(function (x) { return x.chltype === 'CLUSRCVR'; })[0]; return c ? E(c.name) : '-'; } },
          { key: 'conn', label: 'CONNAME', help: 'ch.conname', render: function (m) { var c = m.channels.filter(function (x) { return x.chltype === 'CLUSRCVR'; })[0]; return c ? '<span class="mono-sm">' + E(c.conname) + '</span>' : '-'; } },
          { key: 'st', label: 'Bu QM\'den iletişim', help: 'clusstatus', render: function (m) { if (m === qm) return '<span class="dim">(bu QM)</span>'; var c = qm.channels.filter(function (x) { return x.chltype === 'CLUSSDR' && x.st && x.st.rqmname === m.name || x.chltype === 'CLUSSDR' && x.name.indexOf(m.name) > 0; })[0]; return c ? MQ.status(c.status) : MQ.status('Inactive'); } },
          { key: 'version', label: 'Sürüm', help: 'mqversion' }
        ] }) +
      '<h2 class="section-title">Cluster queue\'lar (DISPLAY QCLUSTER)' + H('clusterq') + '</h2>' +
      MQ.table({ id: 'clusq-' + qm.name, search: false, rows: function () { return cq; },
        columns: [
          { key: 'name', label: 'Queue', help: 'qname' },
          { key: 'qm', label: 'Barındıran QM (CLUSQMGR)', help: 'clusqmgr' },
          { key: 'defbind', label: 'DEFBIND', help: 'q.defbind' },
          { key: 'clwlprty', label: 'CLWLPRTY', num: true, help: 'q.clwlprty' },
          { key: 'clwlrank', label: 'CLWLRANK', num: true, help: 'q.clwlrank' },
          { key: 'put', label: 'PUT', help: 'q.put' }
        ] }) +
      '<h2 class="section-title">Cluster workload balancing' + H('clwl') + '</h2>' +
      '<div class="props-panel">' +
      MQ.prop('CLWLUSEQ (QM)', 'CLWLUSEQ', E(qm.attrs.CLWLUSEQ), 'qm.clwluseq') +
      MQ.prop('Most recently used channels', 'CLWLMRUC', MQ.fmt(qm.attrs.CLWLMRUC), 'qm.clwlmruc') +
      MQ.prop('Default cluster transmission queue', 'DEFCLXQ', E(qm.attrs.DEFCLXQ), 'qm.defclxq') +
      MQ.prop('Workload exit', 'CLWLEXIT', E(qm.attrs.CLWLEXIT), 'qm.clwlexit') +
      MQ.prop('Channel ağırlıkları (CLWLWGHT)', 'CLWLWGHT', clch.map(function (c) { return E(c.name) + ': ' + c.clwlwght; }).join('<br>'), 'ch.clwlwght') +
      '</div>';
  };

  /* ================================================== MONITORING */
  MQ.route('/qm/:qm/monitoring', qmPage('monitoring', function (qm) {
    var labels = []; for (var i = 23; i >= 0; i--) { var h = (11 - i + 24) % 24; labels.push((h < 10 ? '0' : '') + h + ':00'); }
    var uq = MQ.userQueues(qm).filter(function (q) { return q.type === 'QLOCAL'; });
    var top = uq.slice().sort(function (a, b) { return MQ.pct(b.curdepth, b.maxdepth) - MQ.pct(a.curdepth, a.maxdepth); }).slice(0, 8);
    var putTot = qm.stats.puts.reduce(function (a, b) { return a + b; }, 0), getTot = qm.stats.gets.reduce(function (a, b) { return a + b; }, 0);
    var dlq = MQ.findQ(qm, qm.attrs.DEADQ); var dlqMsgs = dlq ? MQ.ensureMsgs(qm, dlq) : [];
    var reasons = {}; dlqMsgs.forEach(function (m) { if (m.dlh) reasons[m.dlh.reason] = (reasons[m.dlh.reason] || 0) + 1; });
    var sec = function (id, t, help) { return '<h2 class="section-title" id="' + id + '" style="scroll-margin-top:64px">' + t + H(help) + '</h2>'; };
    var nav = [['m-depth', 'Queue depth'], ['m-rate', 'Put / Get hızı'], ['m-flow', 'Mesaj akışı'], ['m-res', 'CPU / Bellek'], ['m-ch', 'Channel izleme'], ['m-conn', 'Bağlantı izleme'], ['m-stat', 'QM istatistikleri'], ['m-alert', 'Kuyruk alarmları'], ['m-dlq', 'DLQ istatistikleri'], ['m-ev', 'Olaylar (Events)']];
    var side = '<nav class="sidenav">' + nav.map(function (n, i) { return '<button class="' + (i === 0 ? 'active' : '') + '" data-do="' + MQ.fn(function (el) { var t = document.getElementById(n[0]); if (t) t.scrollIntoView({ behavior: 'smooth' }); var bs = el.parentNode.querySelectorAll('button'); for (var k = 0; k < bs.length; k++) bs[k].classList.toggle('active', bs[k] === el); }) + '">' + n[1] + '</button>'; }).join('') + '</nav>';
    var alerts = qm.events.filter(function (e) { return /Queue/.test(e.type); });
    uq.forEach(function (q) { var s = MQ.depthState(q); if (s !== 'normal' && !alerts.some(function (a) { return a.object === q.name; })) alerts.push({ time: q.lput, type: s === 'full' ? 'Queue Full' : 'Queue Depth High', object: q.name, reason: s === 'full' ? 'MQRC_Q_FULL (2053)' : 'MQRC_Q_DEPTH_HIGH (2224)', sev: s === 'full' ? 'Error' : 'Warning', detail: MQ.fmt(q.curdepth) + ' / ' + MQ.fmt(q.maxdepth) }); });
    var stats = [
      ['MQCONN / MQCONNX', 'connectsCount', 1284], ['MQOPEN', 'opensCount', 5120], ['MQPUT (persistent)', 'putsPersistent', Math.round(putTot * 0.62)], ['MQPUT (non-persistent)', 'putsNonPersistent', Math.round(putTot * 0.38)],
      ['MQPUT1', 'put1Count', 3310], ['MQGET (destructive)', 'getsCount', getTot], ['MQGET (browse)', 'browsesCount', 902], ['MQCMIT', 'commitsCount', 41022], ['MQBACK', 'backoutsCount', 37], ['Süresi dolan mesajlar (expired)', 'expiredMsgCount', 412], ['Purge edilen kuyruk', 'purgeCount', 0]
    ];
    return '<div class="content with-side">' + side + '<div>' +
      '<div class="notice">' + I('info') + '<div class="grow">Bu sayfadaki değerler, queue manager\'ın online monitoring (MONQ/MONCHL) ve statistics (STATMQI/STATQ/STATCHL) verilerinden üretilmiş örnek değerlerdir. Mevcut ayarlar: MONQ(' + E(qm.attrs.MONQ) + '), MONCHL(' + E(qm.attrs.MONCHL) + '), STATMQI(' + E(qm.attrs.STATMQI) + '), STATINT(' + qm.attrs.STATINT + ').' + H('monitoring') + '</div></div>' +
      sec('m-depth', 'Queue depth monitoring', 'qdepth.monitor') + '<div class="tile">' + MQ.hbars(top.map(function (q) { return { label: q.name, value: q.curdepth, max: q.maxdepth, warn: q.qdepthhi, link: MQ.qLink(qm.name, q.name) }; })) + '</div>' +
      sec('m-rate', 'Message put rate / get rate (son 24 saat)', 'putrate') + '<div class="tile">' + MQ.lineChart({ labels: labels, series: [{ name: 'Put / saat', data: qm.stats.puts }, { name: 'Get / saat', data: qm.stats.gets }], title: 'Put Get' }) + '</div>' +
      sec('m-flow', 'Message flow statistics', 'msgflow') + '<div class="grid g3">' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + MQ.fmt(putTot) + '</div><div class="lbl">Toplam put (24s)</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + MQ.fmt(getTot) + '</div><div class="lbl">Toplam get (24s)</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + MQ.fmt(putTot - getTot) + '</div><div class="lbl">Net birikim' + H('backlog') + '</div></div></div></div>' +
      '<div class="tile mt16">' + MQ.barChart({ labels: labels, series: [{ name: 'Giriş', data: qm.stats.puts }, { name: 'Çıkış', data: qm.stats.gets }], height: 200 }) + '</div>' +
      sec('m-res', 'CPU ve bellek kullanımı', 'cpumem') + '<div class="grid g2"><div class="tile"><div class="tile-h">CPU %</div>' + MQ.lineChart({ labels: labels, series: [{ name: 'CPU %', data: qm.stats.cpu, color: '#33b1ff' }], unit: '%', area: true, height: 180 }) + '</div>' +
      '<div class="tile"><div class="tile-h">Bellek %</div>' + MQ.lineChart({ labels: labels, series: [{ name: 'Bellek %', data: qm.stats.mem, color: '#a56eff' }], unit: '%', area: true, height: 180 }) + '</div></div>' +
      sec('m-ch', 'Channel monitoring (MONCHL)', 'chmonitor') + MQ.table({ id: 'mch-' + qm.name, search: false, rows: function () { return qm.channels.filter(function (c) { return c.st; }); },
        columns: [
          { key: 'name', label: 'Channel', render: function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '/status">' + E(c.name) + '</a>'; } },
          { key: 'status', label: 'Status', render: function (c) { return MQ.status(c.status); } },
          { key: 'msgs', label: 'MSGS', num: true, val: function (c) { return c.st.msgs || 0; }, render: function (c) { return MQ.fmt(c.st.msgs || 0); } },
          { key: 'xq', label: 'XQTIME (µs)', help: 'xqtime', render: function (c) { return E(c.st.xqtime || '-'); } },
          { key: 'nt', label: 'NETTIME (µs)', help: 'nettime', render: function (c) { return E(c.st.nettime || '-'); } },
          { key: 'b', label: 'BATCHES', num: true, help: 'ch.batchsz', val: function (c) { return c.st.batches || 0; }, render: function (c) { return MQ.fmt(c.st.batches || 0); } },
          { key: 'mon', label: 'MONCHL', help: 'ch.monchl', render: function (c) { return E(c.monchl === 'QMGR' ? 'QMGR (' + qm.attrs.MONCHL + ')' : c.monchl); } }
        ] }) +
      sec('m-conn', 'Connection monitoring', 'connection') + '<div class="tile">' + (function () { var by = {}; qm.conns.forEach(function (c) { var k = c.channel || '(bindings)'; by[k] = (by[k] || 0) + 1; }); var ks = Object.keys(by); return MQ.barChart({ labels: ks.map(function (k) { return k.length > 18 ? k.slice(0, 16) + '…' : k; }), series: [{ name: 'Bağlantı sayısı', data: ks.map(function (k) { return by[k]; }) }], height: 200 }); })() +
      '<div class="tile-foot"><span>MAXHANDS: ' + qm.attrs.MAXHANDS + H('qm.maxhands') + '</span><span>Toplam bağlantı: ' + qm.conns.length + '</span></div></div>' +
      sec('m-stat', 'Queue manager statistics (STATMQI)', 'qmstats') + MQ.table({ id: 'mstat-' + qm.name, search: false, rows: function () { return stats.map(function (s) { return { op: s[0], f: s[1], v: s[2] }; }); },
        columns: [{ key: 'op', label: 'İşlem' }, { key: 'f', label: 'PCF alanı', render: function (s) { return '<span class="mono-sm">' + E(s.f) + '</span>'; } }, { key: 'v', label: 'Son ' + qm.attrs.STATINT + ' sn', num: true }] }) +
      sec('m-alert', 'Queue full events / high queue depth alerts', 'qdepthhi') + MQ.table({ id: 'malert-' + qm.name, search: false, rows: function () { return alerts; },
        columns: [{ key: 'time', label: 'Zaman' }, { key: 'type', label: 'Olay', render: function (e) { return MQ.status(e.sev === 'Error' ? 'Full' : 'Warning').replace(/>[^<]*<\/span>$/, '>' + E(e.type) + '</span>'); } }, { key: 'object', label: 'Kuyruk', render: function (e) { return '<a href="' + MQ.qLink(qm.name, e.object) + '">' + E(e.object) + '</a>'; } }, { key: 'reason', label: 'Reason', help: 'reasoncode', render: function (e) { return '<span class="mono-sm">' + E(e.reason) + '</span>'; } }, { key: 'detail', label: 'Ayrıntı', wrap: true }] }) +
      sec('m-dlq', 'Dead letter queue statistics', 'dlq') + '<div class="grid g2"><div class="tile"><div class="mini-stat"><div class="num">' + (dlq ? MQ.fmt(dlq.curdepth) : '-') + '</div><div class="lbl">' + E(qm.attrs.DEADQ || 'DLQ tanımlı değil') + '</div></div><div class="tile-foot"><a href="' + MQ.qLink(qm.name, qm.attrs.DEADQ) + '/messages">DLQ mesajlarına göz at</a></div></div>' +
      '<div class="tile"><div class="tile-h">Reason code dağılımı (MQDLH)' + H('mqdlh') + '</div><ul class="tile-list">' + Object.keys(reasons).map(function (r) { return '<li><span class="nm mono-sm">' + E(r) + '</span><span class="val">' + reasons[r] + '</span></li>'; }).join('') + '</ul></div></div>' +
      sec('m-ev', 'Error ve warning events', 'qmevents') + MQ.table({ id: 'mev-' + qm.name, rows: function () { return qm.events; }, defaultSort: { key: 'time', dir: 'desc' },
        filters: [{ label: 'Kategori', options: ['Performance', 'Channel', 'Authority', 'Configuration', 'Start/Stop', 'Logger'], fn: function (e, v) { return e.cat === v; } }],
        columns: [{ key: 'time', label: 'Zaman' }, { key: 'sev', label: 'Önem', render: function (e) { return MQ.status(e.sev === 'Error' ? 'Error' : e.sev === 'Warning' ? 'Warning' : 'Normal').replace('Normal<', 'Info<'); } }, { key: 'cat', label: 'Kategori', help: 'qmevents' }, { key: 'type', label: 'Olay' }, { key: 'object', label: 'Nesne' }, { key: 'reason', label: 'Reason', help: 'reasoncode', render: function (e) { return '<span class="mono-sm">' + E(e.reason) + '</span>'; } }, { key: 'detail', label: 'Ayrıntı', wrap: true }] }) +
      '</div></div>';
  }), 'manage');
})();
