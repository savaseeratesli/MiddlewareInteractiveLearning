/* MQSC konsolu simülatörü. Komutlar yalnızca tarayıcıdaki simülasyon verisi üzerinde yorumlanır;
   gerçek bir queue manager'a (runmqsc / REST API) asla gönderilmez. */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc;

  var CMDS = [
    { g: 'Görüntüleme (DISPLAY)', items: [
      ['DISPLAY QMGR', 'mqsc.disqmgr'], ['DISPLAY QUEUE(*)', 'mqsc.disq'], ['DISPLAY QLOCAL(APP.*) CURDEPTH MAXDEPTH IPPROCS OPPROCS', 'mqsc.disq'], ["DISPLAY QLOCAL(*) WHERE(CURDEPTH GT 0)", 'mqsc.where'],
      ['DISPLAY QSTATUS(*)', 'mqsc.disqs'], ['DISPLAY QSTATUS(APP.ODEME.ISTEK) TYPE(HANDLE) ALL', 'mqsc.disqs'], ['DISPLAY CHANNEL(*)', 'mqsc.disch'], ['DISPLAY CHSTATUS(*)', 'mqsc.dischs'],
      ['DISPLAY LISTENER(*)', 'mqsc.dislstr'], ['DISPLAY LSSTATUS(*)', 'mqsc.dislss'], ['DISPLAY CONN(*) TYPE(CONN)', 'mqsc.disconn'], ['DISPLAY CLUSQMGR(*)', 'mqsc.disclusqmgr'],
      ['DISPLAY QCLUSTER(*)', 'mqsc.disqcluster'], ['DISPLAY TOPIC(*)', 'mqsc.distopic'], ['DISPLAY SUB(*)', 'mqsc.dissub'], ['DISPLAY PUBSUB', 'mqsc.dispubsub'], ['DISPLAY PROCESS(*)', 'process'], ['DISPLAY NAMELIST(*)', 'namelist'], ['DISPLAY SERVICE(*)', 'service']] },
    { g: 'Tanımlama (DEFINE)', items: [
      ["DEFINE QLOCAL(APP.TEST.IN) MAXDEPTH(10000) DEFPSIST(YES) DESCR('Test kuyrugu')", 'mqsc.defql'], ['DEFINE QREMOTE(QR.TEST) RNAME(APP.HESAP.IN) RQMNAME(QMCORE01) XMITQ(QMCORE01)', 'mqsc.defqr'],
      ['DEFINE QALIAS(QA.TEST) TARGET(APP.TEST.IN)', 'mqsc.defqa'], ['DEFINE QMODEL(APP.TEST.MODEL) DEFTYPE(TEMPDYN)', 'mqsc.defqm'],
      ["DEFINE CHANNEL(QMGW01.QMTEST) CHLTYPE(SDR) CONNAME('mqtest01.ornek.local(1416)') XMITQ(QMCORE01)", 'mqsc.defch'], ['DEFINE CHANNEL(APP.TEST.SVRCONN) CHLTYPE(SVRCONN) SSLCIPH(ANY_TLS12_OR_HIGHER)', 'mqsc.defch'],
      ['DEFINE LISTENER(LST.TCP.1430) TRPTYPE(TCP) PORT(1430) CONTROL(QMGR)', 'mqsc.deflstr'], ["DEFINE TOPIC(TEST.TOPIC) TOPICSTR('test/olay')", 'mqsc.deftopic'], ["DEFINE SUB(SUB.TEST) TOPICSTR('test/#') DEST(APP.TEST.IN)", 'mqsc.defsub']] },
    { g: 'Değiştirme / silme', items: [
      ['ALTER QLOCAL(APP.TEST.IN) MAXDEPTH(20000) DEFPRTY(4)', 'mqsc.alterql'], ["ALTER QMGR DESCR('MQSC ile degistirildi')", 'mqsc.alterqmgr'], ['CLEAR QLOCAL(APP.TEST.IN)', 'mqsc.clearql'], ['DELETE QLOCAL(APP.TEST.IN) PURGE', 'mqsc.deleteql']] },
    { g: 'Kontrol', items: [
      ['START CHANNEL(QMGW01.QMBATCH01)', 'mqsc.startch'], ['STOP CHANNEL(QMGW01.QMCORE01) MODE(QUIESCE) STATUS(INACTIVE)', 'mqsc.stopch'], ['PING CHANNEL(QMGW01.QMPARTNER)', 'mqsc.pingch'], ['RESET CHANNEL(QMGW01.QMBATCH01) SEQNUM(1)', 'mqsc.resetch'],
      ['START LISTENER(LST.TCP.1420.ADMIN)', 'mqsc.startlstr'], ['STOP LISTENER(LST.TCP.1420.ADMIN)', 'mqsc.stoplstr'], ['REFRESH SECURITY TYPE(CONNAUTH)', 'refreshsec']] },
    { g: 'Güvenlik', items: [
      ['DISPLAY CHLAUTH(*)', 'mqsc.dischlauth'], ["DISPLAY CHLAUTH(APP.MOBIL.SVRCONN) MATCH(RUNCHECK) ADDRESS('10.20.30.14') CLNTUSER('mobilapp')", 'chlauth.runcheck'],
      ["SET CHLAUTH(APP.TEST.SVRCONN) TYPE(ADDRESSMAP) ADDRESS('10.9.9.*') USERSRC(MAP) MCAUSER('testapp')", 'mqsc.setchlauth'], ['DISPLAY AUTHREC OBJTYPE(QUEUE)', 'mqsc.disauthrec'],
      ["SET AUTHREC PROFILE('APP.TEST.**') OBJTYPE(QUEUE) GROUP('testgrp') AUTHADD(PUT,GET,INQ)", 'mqsc.setauthrec'], ['DISPLAY AUTHINFO(*) ALL', 'authinfo']] }
  ];

  MQ.route('/mqsc', function () { var d = MQ.state.qmgrs.filter(function (q) { return q.isDefault && MQ.isUp(q); })[0] || MQ.state.qmgrs.filter(MQ.isUp)[0] || MQ.state.qmgrs[0]; location.replace('#/qm/' + MQ.enc(d.name) + '/mqsc'); return ''; }, 'mqsc');
  MQ.route('/qm/:qm/mqsc', function (p) {
    var qm = MQ.qm(p.qm); if (!qm) throw new Error('Queue manager bulunamadı');
    var head = MQ.qmHead(qm, 'mqsc');
    MQ.ui = MQ.ui || {}; MQ.ui.mqsc = MQ.ui.mqsc || {};
    var st = MQ.ui.mqsc[qm.name] || (MQ.ui.mqsc[qm.name] = { log: [], n: 0, hist: [], hi: -1 });
    if (!st.log.length) st.log.push(['', '5724-H72 (C) Copyright IBM Corp. 1994, 2024.\nStarting MQSC for queue manager ' + qm.name + '.\n']);
    if (!MQ.isUp(qm)) st.log.push(['er', 'AMQ8146E: IBM MQ queue manager not available.\n']);
    MQ.after(function () {
      var inp = document.getElementById('mqscIn'), out = document.getElementById('mqscOut');
      out.scrollTop = out.scrollHeight;
      if (MQ.ui.mqscPrefill) { inp.value = MQ.ui.mqscPrefill; MQ.ui.mqscPrefill = null; }
      inp.focus();
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); run(); }
        else if (e.key === 'ArrowUp') { if (st.hist.length) { st.hi = st.hi < 0 ? st.hist.length - 1 : Math.max(0, st.hi - 1); inp.value = st.hist[st.hi]; } e.preventDefault(); }
        else if (e.key === 'ArrowDown') { if (st.hi >= 0) { st.hi++; inp.value = st.hi < st.hist.length ? st.hist[st.hi] : ''; if (st.hi >= st.hist.length) st.hi = -1; } e.preventDefault(); }
      });
      inp.addEventListener('paste', function (e) {
        var t = (e.clipboardData || window.clipboardData).getData('text');
        if (t && t.indexOf('\n') >= 0) { e.preventDefault(); splitScript(t).forEach(function (c) { exec(c); }); paint(); }
      });
      document.getElementById('mqscRun').onclick = run;
      function run() { var v = inp.value.trim(); if (!v) return; st.hist.push(v); st.hi = -1; inp.value = ''; exec(v); paint(); }
      function paint() { var o = document.getElementById('mqscOut'); if (!o) return; o.innerHTML = render(); o.scrollTop = o.scrollHeight; }
      function exec(cmd) {
        st.n++; st.log.push(['cmd', pad(st.n) + ' : ' + cmd + '\n']);
        var res; try { res = MQ.mqscExec(qm, cmd); } catch (err) { res = [['er', 'AMQ8405I: Syntax error detected at or near end of command segment below:-\n' + cmd + '\n']]; console.error(err); }
        if (res === 'END') { st.log.push(['', st.n + ' MQSC commands read.\nNo commands have a syntax error.\nAll valid MQSC commands were processed.\n']); st.n = 0; return; }
        res.forEach(function (r) { st.log.push(r); });
        MQ.save();
      }
    });
    function pad(n) { var s = String(n); while (s.length < 6) s = ' ' + s; return s; }
    function render() { return st.log.map(function (l) { return '<span class="' + l[0] + '">' + E(l[1]) + '</span>'; }).join(''); }
    return head + '<div class="content"><div class="notice">' + I('info') + '<div class="grow"><b>MQSC simülatörü.</b> Komutlar yalnızca bu eğitim ortamındaki örnek veriler üzerinde yorumlanır; gerçek bir queue manager\'a gönderilmez. Sağdaki komutlara tıklayarak giriş satırına aktarabilir, <kbd>↑</kbd>/<kbd>↓</kbd> ile geçmişte gezinebilir, çok satırlı betik yapıştırabilirsiniz.' + H('mqsc') + '</div></div>' +
      '<div class="mqsc-wrap"><div class="term"><div class="term-h">' + I('terminal').replace('<svg', '<svg width="16" height="16"') + '<span class="grow">runmqsc ' + E(qm.name) + '</span><button class="link-btn" data-do="' + MQ.fn(function () { st.log = []; st.n = 0; MQ.refresh(); }) + '">Temizle</button></div>' +
      '<div class="term-out" id="mqscOut" aria-live="polite">' + render() + '</div>' +
      '<div class="term-in"><span>' + E(qm.name) + '&gt;</span><input id="mqscIn" autocomplete="off" spellcheck="false" placeholder="MQSC komutu yazın, ör. DISPLAY QLOCAL(*) CURDEPTH" aria-label="MQSC komutu"><button id="mqscRun">Çalıştır</button></div></div>' +
      '<div class="cmd-list">' + CMDS.map(function (g) { return '<h3>' + E(g.g) + '</h3>' + g.items.map(function (c) { return '<div class="cmd-i"><code data-do="' + MQ.fn(function () { var i = document.getElementById('mqscIn'); i.value = c[0]; i.focus(); }) + '" title="Giriş satırına aktar">' + E(c[0]) + '</code>' + H(c[1]) + '</div>'; }).join(''); }).join('') + '</div></div></div>';
  }, 'mqsc');

  function splitScript(t) {
    var out = [], buf = '';
    t.split(/\r?\n/).forEach(function (line) {
      var l = line.replace(/^\s+|\s+$/g, ''); if (!l || l[0] === '*') return;
      if (/[+-]$/.test(l)) { buf += l.slice(0, -1) + ' '; return; }
      out.push((buf + l).trim()); buf = '';
    });
    if (buf.trim()) out.push(buf.trim());
    return out;
  }

  /* ------------------------------------------------ parser */
  function parse(cmd) {
    var toks = [], re = /\s*([A-Za-z0-9_.*%\/]+)(?:\s*\(((?:'(?:[^']|'')*'|[^)'])*)\))?/g, m, last = 0;
    var s = cmd.replace(/;$/, '');
    while ((m = re.exec(s)) && m[0]) {
      if (m.index !== last && s.slice(last, m.index).trim()) return null;
      var raw = m[2], val = null;
      if (raw !== undefined) { raw = raw.trim(); val = /^'.*'$/.test(raw) ? raw.slice(1, -1).replace(/''/g, "'") : (raw.indexOf(',') >= 0 || raw.indexOf(' ') >= 0 ? raw.toUpperCase() : raw.toUpperCase()); }
      toks.push({ k: m[1].toUpperCase(), v: val, raw: raw }); last = re.lastIndex;
    }
    if (s.slice(last).trim()) return null;
    return toks;
  }
  var VERB = { DISPLAY: 'DISPLAY', DIS: 'DISPLAY', DEFINE: 'DEFINE', DEF: 'DEFINE', ALTER: 'ALTER', ALT: 'ALTER', DELETE: 'DELETE', DEL: 'DELETE', START: 'START', STA: 'START', STOP: 'STOP', CLEAR: 'CLEAR', PING: 'PING', RESET: 'RESET', REFRESH: 'REFRESH', REF: 'REFRESH', SET: 'SET', END: 'END' };
  var OBJ = { QMGR: 'QMGR', QUEUE: 'QUEUE', Q: 'QUEUE', QLOCAL: 'QLOCAL', QL: 'QLOCAL', QREMOTE: 'QREMOTE', QR: 'QREMOTE', QALIAS: 'QALIAS', QA: 'QALIAS', QMODEL: 'QMODEL', QM: 'QMODEL', QCLUSTER: 'QCLUSTER', QC: 'QCLUSTER', CHANNEL: 'CHANNEL', CHL: 'CHANNEL', CHSTATUS: 'CHSTATUS', CHS: 'CHSTATUS', LISTENER: 'LISTENER', LSTR: 'LISTENER', LSSTATUS: 'LSSTATUS', LSS: 'LSSTATUS', CONN: 'CONN', QSTATUS: 'QSTATUS', QS: 'QSTATUS', CLUSQMGR: 'CLUSQMGR', TOPIC: 'TOPIC', TOP: 'TOPIC', SUB: 'SUB', CHLAUTH: 'CHLAUTH', AUTHREC: 'AUTHREC', AUTHINFO: 'AUTHINFO', PROCESS: 'PROCESS', PRO: 'PROCESS', NAMELIST: 'NAMELIST', NL: 'NAMELIST', SERVICE: 'SERVICE', SVC: 'SERVICE', PUBSUB: 'PUBSUB', SECURITY: 'SECURITY', TPSTATUS: 'TPSTATUS', SBSTATUS: 'SBSTATUS' };
  function gmatch(pat, name) { if (pat === undefined || pat === null || pat === '*') return true; if (/\*$/.test(pat)) return name.indexOf(pat.slice(0, -1)) === 0; return pat === name; }
  function cols(pairs) {
    var lines = [], i = 0;
    while (i < pairs.length) {
      var a = '   ' + pairs[i]; i++;
      if (a.length > 38 || i >= pairs.length) { lines.push(a); continue; }
      var b = pairs[i];
      if (b.length > 36) { lines.push(a); continue; }
      while (a.length < 42) a += ' ';
      lines.push(a + b); i++;
    }
    return lines.join('\n') + '\n';
  }
  function kv(k, v) { return k + '(' + (v === undefined || v === null ? '' : (typeof v === 'string' && v && /[^A-Z0-9_.\/%*]/.test(v) && !/^[0-9,\s]+$/.test(v) ? (/^[A-Za-z0-9 .:\-\/,()=*'_#+]*$/.test(v) && v.indexOf(' ') < 0 && v.indexOf("'") < 0 ? v : v) : v)) + ')'; }

  function qAttrs(qm, q) {
    var t = q.type, a = [['QUEUE', q.name], ['TYPE', t]];
    var push = function (k, v) { a.push([k, v]); };
    if (t === 'QCLUSTER') { push('CLUSQMGR', q.clusqmgr); push('CLUSTER', q.cluster); push('DEFBIND', q.defbind); push('PUT', q.put); push('CLWLPRTY', q.clwlprty); push('CLWLRANK', q.clwlrank); push('DESCR', q.descr); return a; }
    push('DESCR', q.descr); push('PUT', q.put); push('DEFPRTY', q.defprty); push('DEFPSIST', q.defpsist);
    if (t === 'QLOCAL' || t === 'QMODEL' || t === 'QALIAS') push('GET', q.get);
    if (t === 'QLOCAL') { push('CURDEPTH', q.curdepth); push('IPPROCS', q.ipprocs); push('OPPROCS', q.opprocs); }
    if (t === 'QLOCAL' || t === 'QMODEL') {
      push('MAXDEPTH', q.maxdepth); push('MAXMSGL', q.maxmsgl); push('USAGE', q.usage); push(q.share === 'NOSHARE' ? 'NOSHARE' : 'SHARE', null); push('DEFSOPT', q.defsopt); push('MSGDLVSQ', q.msgdlvsq);
      push('BOTHRESH', q.bothresh); push('BOQNAME', q.boqname); push(q.harden, null); push(q.trigger ? 'TRIGGER' : 'NOTRIGGER', null); push('TRIGTYPE', q.trigtype); push('TRIGDPTH', q.trigdpth); push('TRIGMPRI', q.trigmpri); push('TRIGDATA', q.trigdata); push('INITQ', q.initq); push('PROCESS', q.process);
      push('QDEPTHHI', q.qdepthhi); push('QDEPTHLO', q.qdepthlo); push('QDPHIEV', q.qdphiev); push('QDPLOEV', q.qdploev); push('QDPMAXEV', q.qdpmaxev); push('QSVCIEV', q.qsvciev); push('QSVCINT', q.qsvcint);
      push('MONQ', q.monq); push('STATQ', q.statq); push('ACCTQ', q.acctq); push('NPMCLASS', q.npmclass); push('RETINTVL', q.retintvl); push('DEFREADA', q.defreada); push('DEFPRESP', q.defpresp); push('PROPCTL', q.propctl); push('MAXFSIZE', q.maxfsize); push('STREAMQ', q.streamq); push('STRMQOS', q.strmqos);
    }
    if (t === 'QMODEL') push('DEFTYPE', q.deftype);
    if (t === 'QREMOTE') { push('RNAME', q.rname); push('RQMNAME', q.rqmname); push('XMITQ', q.xmitq); }
    if (t === 'QALIAS') { push('TARGET', q.target); push('TARGTYPE', q.targtype); }
    if (t !== 'QMODEL') { push('CLUSTER', q.cluster); push('CLUSNL', q.clusnl); push('DEFBIND', q.defbind); push('CLWLPRTY', q.clwlprty); push('CLWLRANK', q.clwlrank); }
    if (t === 'QLOCAL') push('CLWLUSEQ', q.clwluseq);
    push('CRDATE', (q.created || '').slice(0, 10)); push('CRTIME', (q.created || '').slice(11).replace(/:/g, '.')); push('ALTDATE', (q.altered || '').slice(0, 10)); push('ALTTIME', (q.altered || '').slice(11).replace(/:/g, '.'));
    return a;
  }
  function chAttrs(c) {
    var a = [['CHANNEL', c.name], ['CHLTYPE', c.chltype]];
    ['TRPTYPE', 'CONNAME', 'XMITQ', 'QMNAME', 'DESCR', 'HBINT', 'BATCHSZ', 'BATCHINT', 'DISCINT', 'SHORTRTY', 'SHORTTMR', 'LONGRTY', 'LONGTMR', 'MRRTY', 'MRTMR', 'MCAUSER', 'MCATYPE', 'MAXMSGL', 'NPMSPEED', 'SSLCIPH', 'SSLCAUTH', 'SSLPEER', 'CERTLABL', 'SHARECNV', 'MAXINST', 'MAXINSTC', 'CLUSTER', 'CLWLPRTY', 'CLWLRANK', 'CLWLWGHT', 'NETPRTY', 'MONCHL', 'STATCHL', 'KAINT', 'COMPMSG', 'COMPHDR', 'USEDLQ', 'DEFRECON'].forEach(function (k) {
      var v = c[k.toLowerCase()]; if (v === undefined) return;
      if (c.chltype === 'SVRCONN' && ['XMITQ', 'CONNAME', 'BATCHSZ', 'BATCHINT', 'SHORTRTY', 'SHORTTMR', 'LONGRTY', 'LONGTMR', 'MRRTY', 'MRTMR', 'CLUSTER', 'CLWLPRTY', 'CLWLRANK', 'CLWLWGHT', 'NETPRTY', 'NPMSPEED', 'QMNAME', 'DEFRECON', 'MCATYPE', 'USEDLQ'].indexOf(k) >= 0) return;
      if (c.chltype !== 'SVRCONN' && ['MAXINST', 'MAXINSTC'].indexOf(k) >= 0) return;
      if (['SVRCONN', 'CLNTCONN'].indexOf(c.chltype) < 0 && k === 'SHARECNV') return;
      if (['SDR', 'SVR'].indexOf(c.chltype) < 0 && k === 'XMITQ') return;
      if (c.chltype !== 'CLNTCONN' && (k === 'QMNAME' || k === 'DEFRECON')) return;
      if (['CLUSSDR', 'CLUSRCVR'].indexOf(c.chltype) < 0 && /^CL|NETPRTY/.test(k)) return;
      a.push([k, v]);
    });
    a.push(['ALTDATE', (c.altered || '').slice(0, 10)]); a.push(['ALTTIME', (c.altered || '').slice(11).replace(/:/g, '.')]);
    return a;
  }
  function select(attrs, req, always) {
    if (!req.length) return attrs.filter(function (x) { return always.indexOf(x[0]) >= 0; });
    if (req.indexOf('ALL') >= 0) return attrs;
    var out = attrs.filter(function (x) { return always.indexOf(x[0]) >= 0 || req.indexOf(x[0]) >= 0 || (req.indexOf('TRIGGER') >= 0 && (x[0] === 'NOTRIGGER')); });
    return out;
  }
  function fmt(list) { return list.map(function (x) { return x[1] === null ? x[0] : kv(x[0], x[1]); }); }
  function where(toks) { var w = toks.filter(function (t) { return t.k === 'WHERE'; })[0]; if (!w || !w.v) return null; var m = /^\s*(\w+)\s+(EQ|NE|GT|LT|GE|LE|LK|NL)\s+(.+?)\s*$/i.exec(w.raw); if (!m) return 'ERR'; return { a: m[1].toUpperCase(), op: m[2].toUpperCase(), v: m[3].replace(/^'|'$/g, '') }; }
  function whereOk(w, attrs) {
    if (!w) return true; var p = attrs.filter(function (x) { return x[0] === w.a; })[0]; if (!p) return false;
    var a = p[1], b = isNaN(+w.v) ? w.v : +w.v;
    switch (w.op) { case 'EQ': return a == b; case 'NE': return a != b; case 'GT': return a > b; case 'LT': return a < b; case 'GE': return a >= b; case 'LE': return a <= b; case 'LK': return gmatch(String(w.v), String(a)); case 'NL': return !gmatch(String(w.v), String(a)); }
    return true;
  }
  var SYNTAX = function (cmd, hint) { return [['er', 'AMQ8405I: Syntax error detected at or near end of command segment below:-\n' + cmd + '\n' + (hint ? '' : '')], hint ? ['note', '(Eğitim notu) ' + hint + '\n'] : ['', '']]; };
  var NF = function (n) { return [['er', 'AMQ8147E: IBM MQ object ' + n + ' not found.\n']]; };

  MQ.mqscExec = function (qm, cmd) {
    var toks = parse(cmd); if (!toks || !toks.length) return SYNTAX(cmd);
    var verb = VERB[toks[0].k]; if (!verb) return SYNTAX(cmd, 'Bilinmeyen komut: ' + toks[0].k + '. Desteklenenler: DISPLAY, DEFINE, ALTER, DELETE, START, STOP, CLEAR, PING, RESET, REFRESH, SET, END.');
    if (verb === 'END') return 'END';
    if (!MQ.isUp(qm)) return [['er', 'AMQ8146E: IBM MQ queue manager not available.\n']];
    var objTok = toks[1]; var obj = objTok && OBJ[objTok.k];
    if (!obj) return SYNTAX(cmd, 'Nesne tipi eksik veya tanınmıyor (ör. QLOCAL, CHANNEL, LISTENER).');
    var name = objTok.v, rest = toks.slice(2), req = rest.filter(function (t) { return t.v === null && t.k !== 'WHERE'; }).map(function (t) { return t.k; });
    var get = function (k) { var t = rest.filter(function (x) { return x.k === k; })[0]; return t ? t.v : undefined; };
    var has = function (k) { return rest.some(function (x) { return x.k === k; }); };
    var out = [];
    var A = MQ.act;

    if (verb === 'DISPLAY') {
      var w = where(toks); if (w === 'ERR') return SYNTAX(cmd, 'WHERE biçimi: WHERE(ATTR OP DEĞER), OP = EQ NE GT LT GE LE LK NL');
      if (obj === 'QMGR') {
        var at = qm.attrs, list = [['QMNAME', qm.name]].concat(['ACCTCONO', 'ACCTINT', 'ACCTMQI', 'ACCTQ', 'ACTIVREC', 'ACTVCONO', 'ACTVTRC', 'ADVCAP', 'AUTHOREV', 'CCSID', 'CERTLABL', 'CHAD', 'CHADEV', 'CHADEXIT', 'CHLAUTH', 'CHLEV', 'CLWLDATA', 'CLWLEXIT', 'CLWLLEN', 'CLWLMRUC', 'CLWLUSEQ', 'CMDEV', 'CONFIGEV', 'CONNAUTH', 'CUSTOM', 'DEADQ', 'DEFCLXQ', 'DEFXMITQ', 'DESCR', 'IMGINTVL', 'IMGLOGLN', 'IMGRCOVO', 'IMGRCOVQ', 'IMGSCHED', 'INHIBTEV', 'IPADDRV', 'LOCALEV', 'LOGGEREV', 'MAXHANDS', 'MAXMSGL', 'MAXPROPL', 'MAXPRTY', 'MAXUMSGS', 'MONACLS', 'MONCHL', 'MONQ', 'PERFMEV', 'PSCLUS', 'PSMODE', 'PSNPMSG', 'PSNPRES', 'PSRTYCNT', 'PSSYNCPT', 'REMOTEEV', 'REPOS', 'REPOSNL', 'REVDNS', 'ROUTEREC', 'SCHINIT', 'SCMDSERV', 'SSLCRLNL', 'SSLCRYP', 'SSLEV', 'SSLFIPS', 'SSLKEYR', 'SSLRKEYC', 'STATACLS', 'STATCHL', 'STATINT', 'STATMQI', 'STATQ', 'STRSTPEV', 'TREELIFE', 'TRIGINT'].map(function (k) { return [k, at[k]]; }));
        list.splice(1, 0, ['PLATFORM', qm.platform.toUpperCase()], ['CMDLEVEL', qm.cmdlevel], ['VERSION', '0' + qm.version.split('.').map(function (x, i) { return i ? ('0' + x).slice(-2) : x; }).join('')]);
        var sel = req.length && req.indexOf('ALL') < 0 ? list.filter(function (x) { return x[0] === 'QMNAME' || req.indexOf(x[0]) >= 0; }) : list;
        out.push(['', 'AMQ8408I: Display Queue Manager details.\n' + cols(fmt(sel))]);
        return out;
      }
      if (/^Q(UEUE|LOCAL|REMOTE|ALIAS|MODEL|CLUSTER)$/.test(obj)) {
        var tmap = { QLOCAL: 'QLOCAL', QREMOTE: 'QREMOTE', QALIAS: 'QALIAS', QMODEL: 'QMODEL', QCLUSTER: 'QCLUSTER' };
        var qs = qm.queues.filter(function (q) { return gmatch(name, q.name) && (obj === 'QUEUE' ? q.type !== 'QCLUSTER' : q.type === tmap[obj]); });
        var ty = get('TYPE'); if (ty) qs = qs.filter(function (q) { return q.type === ty || (ty === 'QL' && q.type === 'QLOCAL'); });
        var hits = 0;
        qs.forEach(function (q) { var at2 = qAttrs(qm, q); if (!whereOk(w, at2)) return; hits++; out.push(['', 'AMQ8409I: Display Queue details.\n' + cols(fmt(select(at2, req, ['QUEUE', 'TYPE'].concat(w ? [w.a] : []))))]); });
        if (!hits) return name && name.indexOf('*') < 0 ? NF(name) : [['', 'AMQ8147E: IBM MQ object ' + (name || '*') + ' not found.\n']];
        return out;
      }
      if (obj === 'QSTATUS') {
        var htype = get('TYPE') || 'QUEUE';
        qm.queues.filter(function (q) { return q.type === 'QLOCAL' && gmatch(name, q.name); }).forEach(function (q) {
          if (htype === 'HANDLE') {
            qm.conns.filter(function (c) { return c.objects && c.objects.indexOf(q.name + ' (') >= 0; }).forEach(function (c) {
              var mm = c.objects.match(new RegExp(q.name.replace(/\./g, '\\.') + ' \\((\\w+)\\)'));
              out.push(['', 'AMQ8450I: Display queue status details.\n' + cols(fmt([['QUEUE', q.name], ['TYPE', 'HANDLE'], ['APPLDESC', c.appltype === 'JAVA' ? 'IBM MQ Channel' : ''], ['APPLTAG', c.appltag], ['APPLTYPE', c.appltype], ['BROWSE', 'NO'], ['CHANNEL', c.channel], ['CONNAME', c.conname], ['INPUT', mm && mm[1] === 'INPUT' ? 'SHARED' : 'NO'], ['OUTPUT', mm && mm[1] === 'OUTPUT' ? 'YES' : 'NO'], ['PID', c.pid], ['USERID', c.userid], ['ASTATE', 'NONE']]))]);
            });
          } else {
            var mon = q.monq !== 'OFF' && !(q.monq === 'QMGR' && qm.attrs.MONQ === 'OFF');
            out.push(['', 'AMQ8450I: Display queue status details.\n' + cols(fmt([['QUEUE', q.name], ['TYPE', 'QUEUE'], ['CURDEPTH', q.curdepth], ['IPPROCS', q.ipprocs], ['LGETDATE', (q.lget || '').slice(0, 10)], ['LGETTIME', (q.lget || '').slice(11).replace(/:/g, '.')], ['LPUTDATE', (q.lput || '').slice(0, 10)], ['LPUTTIME', (q.lput || '').slice(11).replace(/:/g, '.')], ['MEDIALOG', ''], ['MONQ', mon ? (q.monq === 'QMGR' ? qm.attrs.MONQ : q.monq) : 'OFF'], ['MSGAGE', mon ? q.msgage : ''], ['OPPROCS', q.opprocs], ['QTIME', mon ? q.qtime || '0, 0' : ''], ['UNCOM', q.uncom ? 'YES' : 'NO']]))]);
          }
        });
        if (!out.length) return htype === 'HANDLE' ? [['', 'AMQ8450I: Display queue status details.\n   (Açık handle yok)\n']] : NF(name);
        return out;
      }
      if (obj === 'CHANNEL') {
        var ct = get('CHLTYPE');
        qm.channels.filter(function (c) { return gmatch(name, c.name) && (!ct || c.chltype === ct); }).forEach(function (c) { var at3 = chAttrs(c); if (!whereOk(w, at3)) return; out.push(['', 'AMQ8414I: Display Channel details.\n' + cols(fmt(select(at3, req, ['CHANNEL', 'CHLTYPE'])))]); });
        return out.length ? out : NF(name);
      }
      if (obj === 'CHSTATUS') {
        qm.channels.filter(function (c) { return gmatch(name, c.name) && ['Running', 'Retrying', 'Stopped', 'Binding', 'Starting'].indexOf(c.status) >= 0; }).forEach(function (c) {
          var list = c.inst && c.inst.length ? c.inst.map(function (i) { return { conname: i.conname, msgs: i.msgs, st: 'RUNNING' }; }) : [{ conname: (c.st && c.st.conname) || c.conname, msgs: c.st && c.st.msgs || 0, st: c.status.toUpperCase() }];
          list.forEach(function (i) {
            var at4 = [['CHANNEL', c.name], ['CHLTYPE', c.chltype], ['CONNAME', i.conname], ['CURRENT', null], ['RQMNAME', c.st && c.st.rqmname || ''], ['STATUS', i.st], ['SUBSTATE', i.st === 'RUNNING' ? (c.st && c.st.substate) || 'RECEIVE' : '']];
            if (c.xmitq) at4.push(['XMITQ', c.xmitq]);
            if (req.indexOf('ALL') >= 0 || req.indexOf('MSGS') >= 0) at4.push(['MSGS', i.msgs]);
            if (req.indexOf('ALL') >= 0) { at4.push(['BYTSSENT', c.st && c.st.bytessent || 0], ['BYTSRCVD', c.st && c.st.bytesrcvd || 0], ['SSLCIPH', c.sslciph], ['XQTIME', c.st && c.st.xqtime || ''], ['NETTIME', c.st && c.st.nettime || ''], ['MONCHL', c.monchl]); }
            out.push(['', 'AMQ8417I: Display Channel Status details.\n' + cols(fmt(at4))]);
          });
        });
        return out.length ? out : [['er', 'AMQ8420I: Channel Status not found.\n']];
      }
      if (obj === 'LISTENER') {
        qm.listeners.filter(function (l) { return gmatch(name, l.name); }).forEach(function (l) { out.push(['', 'AMQ8630I: Display listener information details.\n' + cols(fmt(select([['LISTENER', l.name], ['CONTROL', l.control], ['TRPTYPE', l.trptype], ['PORT', l.port], ['IPADDR', l.ipaddr], ['BACKLOG', l.backlog], ['DESCR', l.descr]], req.length ? req : ['ALL'], ['LISTENER'])))]); });
        return out.length ? out : NF(name);
      }
      if (obj === 'LSSTATUS') {
        qm.listeners.filter(function (l) { return gmatch(name, l.name) && l.status === 'Running'; }).forEach(function (l) { out.push(['', 'AMQ8631I: Display listener status details.\n' + cols(fmt([['LISTENER', l.name], ['STATUS', 'RUNNING'], ['PID', l.pid], ['STARTDA', (l.started || '').slice(0, 10)], ['STARTTI', (l.started || '').slice(11).replace(/:/g, '.')], ['DESCR', l.descr], ['TRPTYPE', l.trptype], ['CONTROL', l.control], ['IPADDR', l.ipaddr || '*'], ['PORT', l.port], ['BACKLOG', l.backlog]]))]); });
        return out.length ? out : [['note', '(Eğitim notu) LSSTATUS yalnızca çalışan listener\'lar için kayıt döndürür; eşleşen çalışan listener yok.\n']];
      }
      if (obj === 'CONN') {
        qm.conns.filter(function (c) { return gmatch(name, c.connid.slice(-16)) || name === '*'; }).forEach(function (c) { out.push(['', 'AMQ8276I: Display Connection details.\n' + cols(fmt([['CONN', c.connid.slice(-16)], ['EXTCONN', c.connid.slice(0, 32)], ['TYPE', 'CONN'], ['PID', c.pid], ['APPLTAG', c.appltag], ['APPLTYPE', c.appltype], ['CHANNEL', c.channel], ['CONNAME', c.conname], ['USERID', c.userid], ['UOWSTATE', c.uow === '-' ? 'NONE' : 'ACTIVE'], ['CONNOPTS', c.channel ? 'MQCNO_SHARED_BINDING' : 'MQCNO_STANDARD_BINDING']]))]); });
        return out.length ? out : NF(name);
      }
      if (obj === 'CLUSQMGR') {
        if (!qm.cluster) return [['note', '(Eğitim notu) Bu queue manager bir cluster üyesi değil.\n']];
        MQ.state.qmgrs.filter(function (x) { return x.cluster && x.cluster.name === qm.cluster.name && gmatch(name, x.name); }).forEach(function (x) {
          var rc = x.channels.filter(function (c) { return c.chltype === 'CLUSRCVR'; })[0];
          var sc = qm.channels.filter(function (c) { return c.chltype === 'CLUSSDR' && c.name === (rc && rc.name); })[0];
          out.push(['', 'AMQ8441I: Display Cluster Queue Manager details.\n' + cols(fmt([['CLUSQMGR', x.name], ['CHANNEL', rc ? rc.name : ''], ['CLUSTER', qm.cluster.name], ['CONNAME', rc ? rc.conname : ''], ['DEFTYPE', x === qm ? 'CLUSRCVR' : (sc && !sc.auto ? 'CLUSSDRB' : 'CLUSSDRA')], ['QMTYPE', x.attrs.REPOS === qm.cluster.name ? 'REPOS' : 'NORMAL'], ['STATUS', x === qm ? 'RUNNING' : (sc ? sc.status.toUpperCase() : 'INACTIVE')], ['VERSION', '0' + x.version.split('.').map(function (z, i) { return i ? ('0' + z).slice(-2) : z; }).join('')]]))]);
        });
        return out.length ? out : NF(name);
      }
      if (obj === 'TOPIC') {
        qm.topics.filter(function (t) { return gmatch(name, t.name); }).forEach(function (t) { out.push(['', 'AMQ8633I: Display topic details.\n' + cols(fmt(select([['TOPIC', t.name], ['TYPE', 'LOCAL'], ['TOPICSTR', t.topicstr], ['DESCR', t.descr], ['CLUSTER', t.cluster], ['CLROUTE', t.clroute], ['DURSUB', t.dursub], ['PUB', t.pub], ['SUB', t.sub], ['DEFPSIST', t.defpsist], ['PUBSCOPE', t.pubscope], ['SUBSCOPE', t.subscope]], req.length ? req : ['ALL'], ['TOPIC', 'TYPE'])))]); });
        return out.length ? out : NF(name);
      }
      if (obj === 'SUB') {
        qm.subs.filter(function (s) { return gmatch(name, s.name); }).forEach(function (s, i) { out.push(['', 'AMQ8096I: IBM MQ subscription inquired.\n' + cols(fmt([['SUBID', '414D5120' + MQ.hex(40)], ['SUB', s.name], ['TOPICSTR', s.topicstr], ['TOPICOBJ', s.topicobj], ['DEST', s.dest], ['DESTQMGR', s.destqmgr], ['DESTCLAS', s.destclas], ['DURABLE', s.durable], ['SUBTYPE', s.subtype], ['SELECTOR', s.selector], ['EXPIRY', s.expiry]]))]); });
        return out.length ? out : NF(name);
      }
      if (obj === 'PUBSUB') { out.push(['', 'AMQ8723I: Display pub/sub status details.\n' + cols(fmt([['QMNAME', qm.name], ['TYPE', 'LOCAL'], ['STATUS', qm.attrs.PSMODE === 'DISABLED' ? 'INACTIVE' : 'ACTIVE'], ['SUBCOUNT', qm.subs.length], ['TPCOUNT', qm.topics.length]]))]); return out; }
      if (obj === 'CHLAUTH') {
        if (get('MATCH') === 'RUNCHECK') {
          var r = MQ.simulateChlauth(qm, { channel: name, address: get('ADDRESS') || '', clntuser: get('CLNTUSER') || '', sslpeer: get('SSLPEER') || '', qmname: get('QMNAME') || '', pwd: true });
          out.push([r.result === 'ALLOW' ? '' : 'er', 'AMQ8878I: Display channel authentication record details.\n']);
          out.push(['note', r.html.replace(/<li>/g, '\n  • ').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"') + '\n']);
          return out;
        }
        qm.chlauth.filter(function (r) { return gmatch(name, r.profile) || name === '*'; }).forEach(function (r) {
          var p = [['CHLAUTH', r.profile], ['TYPE', r.type]]; var m = /^(\w+)\('(.*)'\)$/.exec(r.match); if (m) p.push([m[1], m[2]]);
          if (r.usersrc) p.push(['USERSRC', r.usersrc]); if (r.mcauser) p.push(['MCAUSER', r.mcauser]); if (r.chckclnt) p.push(['CHCKCLNT', r.chckclnt]); p.push(['WARN', r.warn || 'NO']); if (r.descr) p.push(['DESCR', r.descr]);
          out.push(['', 'AMQ8878I: Display channel authentication record details.\n' + cols(fmt(p))]);
        });
        return out.length ? out : NF(name);
      }
      if (obj === 'AUTHREC') {
        var ot = get('OBJTYPE'), pr = get('PROFILE'), gr = get('GROUP');
        qm.authrec.filter(function (r) { return (!ot || r.objtype === ot) && (!pr || r.profile === pr) && (!gr || r.group === gr); }).forEach(function (r) { out.push(['', 'AMQ8864I: Display authority record details.\n' + cols(fmt([['PROFILE', r.profile === 'self' ? qm.name : r.profile], ['ENTITY', r.group], ['ENTTYPE', 'GROUP'], ['OBJTYPE', r.objtype], ['AUTHLIST', r.auth.split(' ').join(',')]]))]); });
        return out.length ? out : [['er', 'AMQ8459I: Not found.\n']];
      }
      if (obj === 'AUTHINFO') { qm.authinfo.filter(function (a) { return gmatch(name, a.name); }).forEach(function (a) { var p = [['AUTHINFO', a.name], ['AUTHTYPE', a.authtype]]; if (a.chckclnt) p.push(['CHCKCLNT', a.chckclnt], ['CHCKLOCL', a.chcklocl], ['ADOPTCTX', a.adoptctx], ['FAILDLAY', a.failDelay]); if (a.conname) p.push(['CONNAME', a.conname]); if (a.ocspurl) p.push(['OCSPURL', a.ocspurl]); p.push(['DESCR', a.descr]); out.push(['', 'AMQ8566I: Display authentication information details.\n' + cols(fmt(p))]); }); return out.length ? out : NF(name); }
      if (obj === 'PROCESS') { qm.processes.filter(function (p) { return gmatch(name, p.name); }).forEach(function (p) { out.push(['', 'AMQ8407I: Display Process details.\n' + cols(fmt([['PROCESS', p.name], ['APPLTYPE', p.appltype], ['APPLICID', p.applicid], ['USERDATA', p.userdata], ['ENVRDATA', p.envrdata], ['DESCR', p.descr]]))]); }); return out.length ? out : NF(name); }
      if (obj === 'NAMELIST') { qm.namelists.filter(function (n) { return gmatch(name, n.name); }).forEach(function (n) { out.push(['', 'AMQ8551I: Display namelist details.\n' + cols(fmt([['NAMELIST', n.name], ['NAMCOUNT', n.names.length], ['NAMES', n.names.join(',')], ['DESCR', n.descr]]))]); }); return out.length ? out : NF(name); }
      if (obj === 'SERVICE') { qm.services.filter(function (s) { return gmatch(name, s.name); }).forEach(function (s) { out.push(['', 'AMQ8629I: Display service information details.\n' + cols(fmt([['SERVICE', s.name], ['SERVTYPE', s.servtype], ['CONTROL', s.control], ['STARTCMD', s.startcmd], ['STARTARG', s.startarg], ['STDOUT', s.stdout], ['DESCR', s.descr]]))]); }); return out.length ? out : NF(name); }
      return SYNTAX(cmd, obj + ' için DISPLAY bu simülatörde desteklenmiyor.');
    }

    /* ---------- DEFINE / ALTER queue */
    var QFIELD = { DESCR: 'descr', MAXDEPTH: 'maxdepth', MAXMSGL: 'maxmsgl', DEFPSIST: 'defpsist', DEFPRTY: 'defprty', PUT: 'put', GET: 'get', USAGE: 'usage', BOTHRESH: 'bothresh', BOQNAME: 'boqname', TRIGTYPE: 'trigtype', TRIGDPTH: 'trigdpth', TRIGMPRI: 'trigmpri', INITQ: 'initq', PROCESS: 'process', TRIGDATA: 'trigdata', CLUSTER: 'cluster', CLUSNL: 'clusnl', DEFBIND: 'defbind', CLWLPRTY: 'clwlprty', CLWLRANK: 'clwlrank', CLWLUSEQ: 'clwluseq', RNAME: 'rname', RQMNAME: 'rqmname', XMITQ: 'xmitq', TARGET: 'target', TARGQ: 'target', TARGTYPE: 'targtype', DEFTYPE: 'deftype', QDEPTHHI: 'qdepthhi', QDEPTHLO: 'qdepthlo', QDPHIEV: 'qdphiev', QDPLOEV: 'qdploev', QDPMAXEV: 'qdpmaxev', MSGDLVSQ: 'msgdlvsq', DEFSOPT: 'defsopt', MONQ: 'monq', STATQ: 'statq', ACCTQ: 'acctq', MAXFSIZE: 'maxfsize', STREAMQ: 'streamq', DEFREADA: 'defreada', DEFPRESP: 'defpresp', PROPCTL: 'propctl', NPMCLASS: 'npmclass', RETINTVL: 'retintvl', QSVCIEV: 'qsvciev', QSVCINT: 'qsvcint' };
    var QFLAG = { TRIGGER: ['trigger', true], NOTRIGGER: ['trigger', false], SHARE: ['share', 'SHARE'], NOSHARE: ['share', 'NOSHARE'], HARDENBO: ['harden', 'HARDENBO'], NOHARDENBO: ['harden', 'NOHARDENBO'] };
    var NUM = { maxdepth: 1, maxmsgl: 1, defprty: 1, bothresh: 1, trigdpth: 1, trigmpri: 1, clwlprty: 1, clwlrank: 1, qdepthhi: 1, qdepthlo: 1, retintvl: 1, qsvcint: 1 };
    function applyQ(q, isDefine) {
      for (var i = 0; i < rest.length; i++) {
        var t = rest[i];
        if (t.k === 'LIKE' || t.k === 'REPLACE' || t.k === 'NOREPLACE' || t.k === 'PURGE' || t.k === 'NOPURGE' || t.k === 'FORCE') continue;
        if (QFLAG[t.k] && t.v === null) { q[QFLAG[t.k][0]] = QFLAG[t.k][1]; continue; }
        var f = QFIELD[t.k]; if (!f || t.v === null) return 'Tanınmayan öznitelik: ' + t.k;
        q[f] = NUM[f] ? parseInt(t.v, 10) : t.v;
        if (NUM[f] && isNaN(q[f])) return t.k + ' sayısal olmalıdır.';
      }
      if (q.defprty < 0 || q.defprty > 9) return 'DEFPRTY 0-9 arasında olmalıdır.';
      if (q.maxdepth < 0 || q.maxdepth > 999999999) return 'MAXDEPTH aralık dışı.';
      if (q.maxmsgl > 104857600) return 'MAXMSGL en fazla 104857600.';
      return '';
    }
    if ((verb === 'DEFINE' || verb === 'ALTER') && /^Q(LOCAL|REMOTE|ALIAS|MODEL)$/.test(obj)) {
      if (!name) return SYNTAX(cmd, 'Kuyruk adı gerekli: ' + verb + ' ' + obj + '(AD)');
      var ex = MQ.findQ(qm, name);
      if (verb === 'ALTER') {
        if (!ex || ex.type !== obj) return NF(name);
        var copy = MQ.clone(ex); var e1 = applyQ(copy); if (e1) return SYNTAX(cmd, e1);
        if (copy.usage !== ex.usage && (ex.ipprocs || ex.opprocs)) return [['er', 'AMQ8148E: IBM MQ object in use.\n']];
        Object.keys(copy).forEach(function (k) { if (k !== 'messages') ex[k] = copy[k]; }); ex.altered = MQ.now();
        return [['ok', 'AMQ8008I: IBM MQ queue changed.\n']];
      }
      if (MQ.validName(name)) return SYNTAX(cmd, MQ.validName(name));
      if (ex && !has('REPLACE')) return [['er', 'AMQ8150E: IBM MQ object already exists.\n']];
      if (ex && ex.type !== obj) return [['er', 'AMQ8150E: IBM MQ object already exists.\n'], ['note', '(Eğitim notu) Aynı ada sahip farklı tipte bir kuyruk var; tüm kuyruk tipleri aynı ad alanını paylaşır.\n']];
      var likeN = get('LIKE'), base = likeN ? MQ.findQ(qm, likeN) : MQ.findQ(qm, { QLOCAL: 'SYSTEM.DEFAULT.LOCAL.QUEUE', QREMOTE: 'SYSTEM.DEFAULT.REMOTE.QUEUE', QALIAS: 'SYSTEM.DEFAULT.ALIAS.QUEUE', QMODEL: 'SYSTEM.DEFAULT.MODEL.QUEUE' }[obj]);
      if (likeN && !base) return NF(likeN);
      var nq = MQ.clone(base || {}); nq.name = name; nq.type = obj; nq.system = false; nq.curdepth = ex ? ex.curdepth : 0; nq.ipprocs = 0; nq.opprocs = 0; nq.messages = ex ? ex.messages : null; nq.created = ex ? ex.created : MQ.now(); nq.altered = MQ.now(); nq.descr = ''; nq.role = undefined;
      var e2 = applyQ(nq); if (e2) return SYNTAX(cmd, e2);
      if (obj === 'QREMOTE' && !nq.rqmname && !nq.rname) { /* MQ kabul eder; uyarı ver */ out.push(['note', '(Eğitim notu) RQMNAME boş: XMITQ ya da DEFXMITQ ile çözümlenmezse put sırasında 2087 alınır.\n']); }
      if (obj === 'QALIAS' && !nq.target) return SYNTAX(cmd, 'QALIAS için TARGET gerekli.');
      if (ex) qm.queues[qm.queues.indexOf(ex)] = nq; else qm.queues.push(nq);
      out.unshift(['ok', 'AMQ8006I: IBM MQ queue created.\n']);
      return out;
    }
    if (verb === 'ALTER' && obj === 'QMGR') {
      var map = {}; Object.keys(qm.attrs).forEach(function (k) { map[k] = 1; });
      for (var i = 2; i < toks.length; i++) { var t = toks[i]; if (!map[t.k] || t.v === null) return SYNTAX(cmd, 'Tanınmayan QMGR özniteliği: ' + t.k); }
      for (i = 2; i < toks.length; i++) { var tt = toks[i]; qm.attrs[tt.k] = typeof qm.attrs[tt.k] === 'number' ? parseInt(tt.v, 10) : tt.v; }
      return [['ok', 'AMQ8005I: IBM MQ queue manager changed.\n']];
    }
    if (verb === 'DELETE' && /^Q(LOCAL|REMOTE|ALIAS|MODEL)$/.test(obj)) {
      var dq = MQ.findQ(qm, name); if (!dq || dq.type !== obj) return NF(name);
      if (dq.ipprocs || dq.opprocs) return [['er', 'AMQ8148E: IBM MQ object in use.\n']];
      if (dq.curdepth && !has('PURGE')) return [['er', 'AMQ8143E: IBM MQ queue not empty.\n']];
      qm.queues.splice(qm.queues.indexOf(dq), 1); return [['ok', 'AMQ8007I: IBM MQ queue deleted.\n']];
    }
    if (verb === 'CLEAR' && obj === 'QLOCAL') {
      var cq = MQ.findQ(qm, name); if (!cq || cq.type !== 'QLOCAL') return NF(name);
      if (cq.ipprocs || cq.opprocs) return [['er', 'AMQ8148E: IBM MQ object in use.\n']];
      cq.curdepth = 0; cq.messages = []; return [['ok', 'AMQ8022I: IBM MQ queue cleared.\n']];
    }

    /* ---------- CHANNEL */
    if (obj === 'CHANNEL') {
      var c = MQ.findCh(qm, name);
      if (verb === 'DEFINE' || verb === 'ALTER') {
        if (!name) return SYNTAX(cmd);
        if (name.length > 20) return SYNTAX(cmd, 'Channel adları en fazla 20 karakter olabilir.');
        var type = get('CHLTYPE'); if (!type) return SYNTAX(cmd, 'CHLTYPE zorunludur (SDR, RCVR, SVR, RQSTR, SVRCONN, CLNTCONN, CLUSSDR, CLUSRCVR).');
        if (['SDR', 'RCVR', 'SVR', 'RQSTR', 'SVRCONN', 'CLNTCONN', 'CLUSSDR', 'CLUSRCVR'].indexOf(type) < 0) return SYNTAX(cmd, 'Geçersiz CHLTYPE: ' + type);
        if (verb === 'ALTER') { if (!c || c.chltype !== type) return NF(name); }
        else if (c && !has('REPLACE')) return [['er', 'AMQ8150E: IBM MQ object already exists.\n']];
        var nc = verb === 'ALTER' ? c : MQ.clone(c && has('REPLACE') ? c : { name: name, chltype: type, status: type === 'CLNTCONN' ? 'N/A' : 'Inactive', descr: '', conname: '', xmitq: '', qmname: '', cluster: '', trptype: 'TCP', sslciph: '', sslcauth: 'REQUIRED', sslpeer: '', certlabl: '', mcauser: '', hbint: 300, batchsz: 50, batchint: 0, batchhb: 0, discint: type === 'SVRCONN' ? 0 : 6000, sharecnv: 10, maxinst: 999999999, maxinstc: 999999999, mrrty: 10, mrtmr: 1000, shortrty: 10, shorttmr: 60, longrty: 999999999, longtmr: 1200, kaint: 'AUTO', npmspeed: 'FAST', mcatype: 'PROCESS', maxmsgl: 4194304, monchl: 'QMGR', statchl: 'QMGR', clwlprty: 0, clwlrank: 0, clwlwght: 50, netprty: 0, compmsg: 'NONE', comphdr: 'NONE', seqwrap: 999999999, convert: 'NO', usedlq: 'YES', defrecon: 'NO', inst: null, st: null });
        for (var j = 0; j < rest.length; j++) {
          var tk = rest[j]; if (tk.k === 'CHLTYPE' || tk.k === 'REPLACE' || tk.k === 'LIKE') continue;
          var fld = tk.k.toLowerCase(); if (!(fld in nc) || tk.v === null) return SYNTAX(cmd, 'Tanınmayan channel özniteliği: ' + tk.k);
          nc[fld] = typeof nc[fld] === 'number' ? parseInt(tk.v, 10) : (tk.raw && /^'/.test(tk.raw) ? tk.v : tk.v);
          if (fld === 'sslciph' && nc.sslciph && !MQ.CIPHERS.some(function (x) { return x.name === nc.sslciph; })) return [['er', 'AMQ8242E: SSLCIPH definition wrong.\n']];
        }
        if (verb === 'DEFINE') {
          if (type === 'SDR' && (!nc.conname || !nc.xmitq)) return SYNTAX(cmd, 'CHLTYPE(SDR) için CONNAME ve XMITQ belirtilmelidir.');
          if ((type === 'CLUSSDR' || type === 'CLUSRCVR') && !nc.cluster) return SYNTAX(cmd, 'Cluster kanalları için CLUSTER veya CLUSNL gerekir.');
          nc.altered = MQ.now(); if (c) qm.channels[qm.channels.indexOf(c)] = nc; else qm.channels.push(nc);
          return [['ok', 'AMQ8014I: IBM MQ channel created.\n']];
        }
        nc.altered = MQ.now(); return [['ok', 'AMQ8016I: IBM MQ channel changed.\n']];
      }
      if (!c) return NF(name);
      if (verb === 'DELETE') { if (c.status === 'Running') return [['er', "AMQ9514E: Channel '" + c.name + "' is in use.\n"]]; qm.channels.splice(qm.channels.indexOf(c), 1); return [['ok', 'AMQ8015I: IBM MQ channel deleted.\n']]; }
      if (verb === 'START') { setTimeout(function () { A.startChannel(qm, c, true); var st = MQ.ui.mqsc && MQ.ui.mqsc[qm.name]; if (st) { st.log.push(['note', '(Simülasyon) ' + c.name + ' durumu: ' + c.status.toUpperCase() + '\n']); var o = document.getElementById('mqscOut'); if (o) { o.innerHTML += '<span class="note">' + E('(Simülasyon) ' + c.name + ' durumu: ' + c.status.toUpperCase() + '\n') + '</span>'; o.scrollTop = o.scrollHeight; } } }, 300); return [['ok', 'AMQ8018I: Start IBM MQ channel accepted.\n']]; }
      if (verb === 'STOP') { c.status = get('STATUS') === 'INACTIVE' ? 'Inactive' : 'Stopped'; c.inst = null; MQ.redrawTables(); return [['ok', 'AMQ8019I: Stop IBM MQ channel accepted.\n']]; }
      if (verb === 'PING') { if (c.status === 'Running') return [['er', "AMQ9514E: Channel '" + c.name + "' is in use.\n"]]; if (['SDR', 'SVR', 'CLUSSDR'].indexOf(c.chltype) < 0) return [['er', 'AMQ8401I: Ping yalnızca sending (SDR/SVR) kanallar için geçerlidir.\n']]; var r2 = A._reach(c); return r2.ok ? [['ok', 'AMQ8020I: Ping IBM MQ channel complete.\n']] : [['er', r2.code + ': ' + r2.msg + '\n'], ['note', '(Eğitim notu) ' + r2.why + '\n']]; }
      if (verb === 'RESET') { c.st = Object.assign(c.st || {}, { curseqno: parseInt(get('SEQNUM') || '1', 10) }); return [['ok', 'AMQ8023I: IBM MQ channel reset.\n']]; }
    }
    /* ---------- LISTENER */
    if (obj === 'LISTENER') {
      var l = qm.listeners.filter(function (x) { return x.name === name; })[0];
      if (verb === 'DEFINE') {
        if (l && !has('REPLACE')) return [['er', 'AMQ8150E: IBM MQ object already exists.\n']];
        var nl = { name: name, status: 'Stopped', trptype: get('TRPTYPE') || 'TCP', port: parseInt(get('PORT') || '0', 10), ipaddr: get('IPADDR') || '', control: get('CONTROL') || 'MANUAL', backlog: parseInt(get('BACKLOG') || '0', 10), descr: get('DESCR') || '', pid: '', started: '' };
        if (l) qm.listeners[qm.listeners.indexOf(l)] = nl; else qm.listeners.push(nl);
        return [['ok', 'AMQ8626I: IBM MQ listener created.\n']];
      }
      if (!l) return NF(name);
      if (verb === 'START') { setTimeout(function () { A.startListener(qm, l); }, 200); return [['ok', 'AMQ8021I: Request to start IBM MQ Listener accepted.\n']]; }
      if (verb === 'STOP') { l.status = 'Stopped'; l.pid = ''; return [['ok', 'AMQ8706I: Request to stop IBM MQ Listener accepted.\n']]; }
      if (verb === 'DELETE') { if (l.status === 'Running') return [['er', 'AMQ8148E: IBM MQ object in use.\n']]; qm.listeners.splice(qm.listeners.indexOf(l), 1); return [['ok', 'AMQ8627I: IBM MQ listener deleted.\n']]; }
    }
    /* ---------- TOPIC / SUB */
    if (obj === 'TOPIC' && verb === 'DEFINE') {
      if (qm.topics.some(function (t) { return t.name === name; }) && !has('REPLACE')) return [['er', 'AMQ8150E: IBM MQ object already exists.\n']];
      var ts = get('TOPICSTR'); if (ts === undefined) return SYNTAX(cmd, 'TOPICSTR gerekli.');
      qm.topics = qm.topics.filter(function (t) { return t.name !== name; });
      qm.topics.push({ name: name, topicstr: ts, descr: get('DESCR') || '', pub: get('PUB') || 'ENABLED', sub: get('SUB') || 'ENABLED', dursub: get('DURSUB') || 'YES', defpsist: get('DEFPSIST') || 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: get('CLUSTER') || '', clroute: get('CLROUTE') || 'DIRECT', pubs: 0, subs: 0, msgs: 0 });
      return [['ok', 'AMQ8690I: IBM MQ topic created.\n']];
    }
    if (obj === 'SUB' && verb === 'DEFINE') {
      if (qm.subs.some(function (s) { return s.name === name; })) return [['er', 'AMQ8150E: IBM MQ object already exists.\n']];
      var tobj = get('TOPICOBJ'), tstr = get('TOPICSTR'), t0 = tobj && qm.topics.filter(function (t) { return t.name === tobj; })[0];
      var full = [t0 && t0.topicstr, tstr].filter(Boolean).join('/'); if (!full) return SYNTAX(cmd, 'TOPICSTR veya TOPICOBJ gerekli.');
      if (!get('DEST')) return SYNTAX(cmd, 'DEST gerekli (yönetimsel abonelikler için hedef kuyruk).');
      qm.subs.push({ name: name, topicstr: full, topicobj: tobj || '', subtype: 'ADMIN', durable: 'YES', dest: get('DEST'), destqmgr: get('DESTQMGR') || qm.name, destclas: 'PROVIDED', selector: get('SELECTOR') || '', expiry: 'UNLIMITED', created: MQ.now(), lastmsg: '', msgs: 0 });
      return [['ok', 'AMQ8094I: IBM MQ subscription created.\n']];
    }
    if ((obj === 'TOPIC' || obj === 'SUB' || obj === 'PROCESS' || obj === 'NAMELIST' || obj === 'SERVICE' || obj === 'AUTHINFO') && verb === 'DELETE') {
      var coll = { TOPIC: 'topics', SUB: 'subs', PROCESS: 'processes', NAMELIST: 'namelists', SERVICE: 'services', AUTHINFO: 'authinfo' }[obj];
      var o = qm[coll].filter(function (x) { return x.name === name; })[0]; if (!o) return NF(name);
      qm[coll].splice(qm[coll].indexOf(o), 1); return [['ok', 'IBM MQ ' + obj.toLowerCase() + ' deleted.\n']];
    }
    /* ---------- SECURITY */
    if (verb === 'REFRESH' && obj === 'SECURITY') return [['ok', 'AMQ8560I: IBM MQ security cache refreshed.\n']];
    if (verb === 'SET' && obj === 'CHLAUTH') {
      var ty2 = get('TYPE'); if (!ty2) return SYNTAX(cmd, 'TYPE gerekli.');
      var mk = { BLOCKADDR: 'ADDRLIST', BLOCKUSER: 'USERLIST', ADDRESSMAP: 'ADDRESS', SSLPEERMAP: 'SSLPEER', USERMAP: 'CLNTUSER', QMGRMAP: 'QMNAME' }[ty2]; if (!mk) return SYNTAX(cmd, 'Geçersiz TYPE.');
      var mv = get(mk); if (mv === undefined) return SYNTAX(cmd, ty2 + ' için ' + mk + ' gerekli.');
      var rule = { profile: ty2 === 'BLOCKADDR' ? '*' : name, type: ty2, match: mk + "('" + mv + "')", usersrc: get('USERSRC') || (/BLOCK/.test(ty2) ? '' : 'MAP'), mcauser: get('MCAUSER') || '', chckclnt: get('CHCKCLNT') || (/BLOCK|QMGRMAP/.test(ty2) ? '' : 'ASQMGR'), warn: get('WARN') || 'NO', descr: get('DESCR') || '' };
      var ex2 = qm.chlauth.filter(function (x) { return x.profile === rule.profile && x.type === rule.type && x.match === rule.match; })[0];
      if (get('ACTION') === 'REMOVE') { if (!ex2) return NF(name); qm.chlauth.splice(qm.chlauth.indexOf(ex2), 1); }
      else { if (rule.usersrc === 'MAP' && !rule.mcauser) return SYNTAX(cmd, 'USERSRC(MAP) için MCAUSER gerekir.'); if (ex2) qm.chlauth[qm.chlauth.indexOf(ex2)] = rule; else qm.chlauth.push(rule); }
      return [['ok', 'AMQ8877I: IBM MQ channel authentication record set.\n']];
    }
    if (verb === 'SET' && obj === 'AUTHREC') {
      var ot2 = get('OBJTYPE'), gr2 = get('GROUP'), pr2 = ot2 === 'QMGR' ? 'self' : get('PROFILE');
      if (!ot2 || !gr2 || !pr2) return SYNTAX(cmd, 'PROFILE (QMGR hariç), OBJTYPE ve GROUP gerekli.');
      var add = (get('AUTHADD') || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean), rmv = (get('AUTHRMV') || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      var rec = qm.authrec.filter(function (x) { return x.profile === pr2 && x.objtype === ot2 && x.group === gr2; })[0];
      if (!rec) { rec = { profile: pr2, objtype: ot2, principal: '', group: gr2, auth: '', note: '' }; qm.authrec.push(rec); }
      var set = {}; rec.auth.split(' ').filter(Boolean).forEach(function (a) { set[a] = 1; }); add.forEach(function (a) { set[a] = 1; }); rmv.forEach(function (a) { if (a === 'ALL') set = {}; delete set[a]; });
      rec.auth = Object.keys(set).join(' '); if (!rec.auth) qm.authrec.splice(qm.authrec.indexOf(rec), 1);
      return [['ok', 'AMQ8862I: IBM MQ authority record set.\n']];
    }
    return SYNTAX(cmd, verb + ' ' + obj + ' bu simülatörde desteklenmiyor. Sağdaki örnek komutları deneyin.');
  };
})();
