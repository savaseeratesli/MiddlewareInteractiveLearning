/* Queue manager konfigürasyon sayfası: Properties, Security, Listeners, MQ Objects, Logs */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc;
  var ED = ['ENABLED', 'DISABLED'], ONOFF = ['ON', 'OFF'], LV = ['OFF', 'LOW', 'MEDIUM', 'HIGH', 'NONE'];

  MQ.CIPHERS = [
    { name: 'ANY_TLS13_OR_HIGHER', proto: 'TLS 1.3+', type: 'Alias', note: 'TLS 1.3 veya daha yeni herhangi bir güçlü CipherSpec ile anlaşır. Önerilen modern seçim.', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'ANY_TLS13', proto: 'TLS 1.3', type: 'Alias', note: 'Yalnızca TLS 1.3 CipherSpec\'leri.', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'ANY_TLS12_OR_HIGHER', proto: 'TLS 1.2+', type: 'Alias', note: 'TLS 1.2 veya 1.3; iki taraf ortak en güçlüsünde anlaşır. Geçiş dönemleri için idealdir.', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'ANY_TLS12', proto: 'TLS 1.2', type: 'Alias', note: 'Yalnızca TLS 1.2 CipherSpec\'leri.', since: '9.1.1 CD / 9.2 LTS' },
    { name: 'TLS_AES_256_GCM_SHA384', proto: 'TLS 1.3', type: 'Spesifik', note: 'AES-256 GCM. TLS 1.3 zorunlu kılınmak istendiğinde.', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'TLS_AES_128_GCM_SHA256', proto: 'TLS 1.3', type: 'Spesifik', note: 'AES-128 GCM.', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'TLS_CHACHA20_POLY1305_SHA256', proto: 'TLS 1.3', type: 'Spesifik', note: 'ChaCha20-Poly1305 (donanım AES hızlandırması olmayan sistemlerde verimli).', since: '9.1.4 CD / 9.2 LTS' },
    { name: 'ECDHE_RSA_AES_256_GCM_SHA384', proto: 'TLS 1.2', type: 'Spesifik', note: 'Forward secrecy sağlayan güçlü TLS 1.2 seçeneği.', since: '8.0' },
    { name: 'ECDHE_ECDSA_AES_256_GCM_SHA384', proto: 'TLS 1.2', type: 'Spesifik', note: 'ECDSA sertifikalarla kullanılır.', since: '8.0' },
    { name: 'TLS_RSA_WITH_AES_256_GCM_SHA384', proto: 'TLS 1.2', type: 'Spesifik', note: 'Forward secrecy sağlamaz (RSA anahtar değişimi). Yeni kurulumlarda ECDHE tercih edin.', since: '7.1' },
    { name: 'TLS_RSA_WITH_AES_128_CBC_SHA256', proto: 'TLS 1.2', type: 'Spesifik (zayıf)', note: 'CBC modu ve RSA anahtar değişimi; güncel sürümlerde zayıf kabul edilir.', since: '7.1' },
    { name: 'TLS_RSA_WITH_AES_256_CBC_SHA', proto: 'TLS 1.0', type: 'Devre dışı', note: 'TLS 1.0 varsayılan olarak devre dışıdır; kullanılmamalıdır.', since: 'eski' }
  ];

  function cfgPage(tab, fn) {
    return function (p) {
      var qm = MQ.qm(p.qm); if (!qm) throw new Error('Queue manager bulunamadı');
      var b = '#/qm/' + MQ.enc(qm.name) + '/config/';
      var acts = [
        { label: 'Queue manager\'ı durdur (endmqm)', fn: function () { MQ.act.stopQm(qm); }, disabled: !MQ.isUp(qm) },
        { label: 'Güvenliği yenile (REFRESH SECURITY)', fn: function () { MQ.act.refreshSecurity(qm); } },
        { label: 'TLS yapılandır', fn: function () { MQ.act.configureTls(qm); } },
        { label: 'CHLAUTH kuralı ekle', fn: function () { MQ.act.setChlauth(qm); } },
        { label: 'Konfigürasyonu dışa aktar (dmpmqcfg)', fn: function () { MQ.act.dmpmqcfg(qm); } }
      ];
      var head = MQ.pageHead({
        crumbs: [['Manage', '#/manage'], [qm.name, MQ.qmLink(qm.name)]], title: qm.name + ' configuration', icon: 'qm', help: 'qmconfig',
        right: MQ.ddButton('Actions', acts),
        tabs: [['properties', 'Properties'], ['security', 'Security'], ['listeners', 'Listeners'], ['objects', 'MQ Objects'], ['logs', 'Logs']].map(function (t) { return { label: t[1], href: b + t[0], active: t[0] === tab }; })
      });
      if (!MQ.isUp(qm)) return head + MQ.notRunning(qm);
      return head + '<div class="content">' + fn(qm, p) + '</div>';
    };
  }

  /* ================================================== PROPERTIES */
  var QMP = [
    { sec: 'General', help: 'qmgr', items: [['Queue manager name', 'QMNAME', 'QMNAME', 'qmname', null], ['Platform', 'PLATFORM', 'PLATFORM', 'platform', null], ['Queue manager status', 'QMSTATUS', 'QMSTATUS', 'qmstatus', null], ['Coded character set ID', 'CCSID', 'CCSID', 'qm.ccsid', 'num'], ['Description', 'DESCR', 'DESCR', 'qm.descr', 'text'], ['Command level', 'CMDLEVEL', 'CMDLEVEL', 'qm.cmdlevel', null], ['Version', 'VERSION', 'VERSION', 'mqversion', null], ['Command server control', 'SCMDSERV', 'SCMDSERV', 'qm.scmdserv', ['QMGR', 'MANUAL']], ['Channel init control', 'SCHINIT', 'SCHINIT', 'qm.schinit', ['QMGR', 'MANUAL']]] },
    { sec: 'Extended', items: [['Maximum message length', 'MAXMSGL', 'MAXMSGL', 'qm.maxmsgl', 'num'], ['Maximum handle limit', 'MAXHANDS', 'MAXHANDS', 'qm.maxhands', 'num'], ['Maximum uncommitted messages', 'MAXUMSGS', 'MAXUMSGS', 'qm.maxumsgs', 'num'], ['Maximum priority', 'MAXPRTY', 'MAXPRTY', 'qm.maxprty', null], ['Dead-letter queue', 'DEADQ', 'DEADQ', 'qm.deadq', 'text'], ['Default transmission queue', 'DEFXMITQ', 'DEFXMITQ', 'qm.defxmitq', 'text'], ['Trigger interval (ms)', 'TRIGINT', 'TRIGINT', 'qm.trigint', 'num'], ['Syncpoint', 'SYNCPT', 'SYNCPT', 'qm.syncpt', null], ['Channel authentication records', 'CHLAUTH', 'CHLAUTH', 'qm.chlauth', ED], ['Connection authentication', 'CONNAUTH', 'CONNAUTH', 'qm.connauth', 'text'], ['Maximum properties length', 'MAXPROPL', 'MAXPROPL', 'qm.maxpropl', 'text'], ['Reverse DNS lookup', 'REVDNS', 'REVDNS', 'qm.revdns', ED], ['Advanced capabilities', 'ADVCAP', 'ADVCAP', 'qm.advcap', null], ['Custom', 'CUSTOM', 'CUSTOM', 'qm.custom', 'text'], ['Media image scheduling', 'IMGSCHED', 'IMGSCHED', 'qm.imgsched', ['MANUAL', 'AUTO']], ['Media image interval (dk)', 'IMGINTVL', 'IMGINTVL', 'qm.imgsched', 'num'], ['Image recover objects', 'IMGRCOVO', 'IMGRCOVO', 'qm.imgsched', ['YES', 'NO']], ['Image recover queues', 'IMGRCOVQ', 'IMGRCOVQ', 'qm.imgsched', ['YES', 'NO']]] },
    { sec: 'Cluster', help: 'cluster', items: [['Cluster workload data', 'CLWLDATA', 'CLWLDATA', 'qm.clwlexit', 'text'], ['Cluster workload exit', 'CLWLEXIT', 'CLWLEXIT', 'qm.clwlexit', 'text'], ['Cluster workload length', 'CLWLLEN', 'CLWLLEN', 'qm.clwlexit', 'num'], ['Cluster workload MRU channels', 'CLWLMRUC', 'CLWLMRUC', 'qm.clwlmruc', 'num'], ['Cluster workload use queue', 'CLWLUSEQ', 'CLWLUSEQ', 'qm.clwluseq', ['LOCAL', 'ANY']], ['Default cluster transmission queue', 'DEFCLXQ', 'DEFCLXQ', 'qm.defclxq', ['SCTQ', 'CHANNEL']]] },
    { sec: 'Repository', help: 'fullrepos', items: [['Repository cluster', 'REPOS', 'REPOS', 'qm.repos', 'text'], ['Repository namelist', 'REPOSNL', 'REPOSNL', 'qm.repos', 'text']] },
    { sec: 'Communication', help: 'qm.chad', items: [['Channel auto-definition', 'CHAD', 'CHAD', 'qm.chad', ED], ['Channel auto-definition events', 'CHADEV', 'CHADEV', 'qm.chad', ED], ['Channel auto-definition exit', 'CHADEXIT', 'CHADEXIT', 'qm.chad', 'text'], ['IP address version', 'IPADDRV', 'IPADDRV', 'qm.ipaddrv', ['IPV4', 'IPV6']], ['Activity recording', 'ACTIVREC', 'ACTIVREC', 'qm.activrec', ['MSG', 'QUEUE', 'DISABLED']], ['Trace-route recording', 'ROUTEREC', 'ROUTEREC', 'qm.activrec', ['MSG', 'QUEUE', 'DISABLED']]] },
    { sec: 'Events', help: 'qmevents', items: [['Authority events', 'AUTHOREV', 'AUTHOREV', 'qm.authorev', ED], ['Inhibit events', 'INHIBTEV', 'INHIBTEV', 'qm.inhibtev', ED], ['Local events', 'LOCALEV', 'LOCALEV', 'qm.localev', ED], ['Remote events', 'REMOTEEV', 'REMOTEEV', 'qm.remoteev', ED], ['Start and stop events', 'STRSTPEV', 'STRSTPEV', 'qm.strstpev', ED], ['Performance events', 'PERFMEV', 'PERFMEV', 'perfevents', ED], ['Channel events', 'CHLEV', 'CHLEV', 'qm.chlev', ['ENABLED', 'DISABLED', 'EXCEPTION']], ['SSL events', 'SSLEV', 'SSLEV', 'qm.sslev', ED], ['Configuration events', 'CONFIGEV', 'CONFIGEV', 'qm.configev', ED], ['Command events', 'CMDEV', 'CMDEV', 'qm.cmdev', ['ENABLED', 'DISABLED', 'NODISPLAY']], ['Logger events', 'LOGGEREV', 'LOGGEREV', 'qm.loggerev', ED]] },
    { sec: 'SSL', help: 'tls', items: [['SSL key repository', 'SSLKEYR', 'SSLKEYR', 'qm.sslkeyr', 'text'], ['Certificate label', 'CERTLABL', 'CERTLABL', 'qm.certlabl', 'text'], ['SSL FIPS required', 'SSLFIPS', 'SSLFIPS', 'qm.sslfips', ['NO', 'YES']], ['SSL key reset count', 'SSLRKEYC', 'SSLRKEYC', 'qm.sslrkeyc', 'num'], ['SSL CRL namelist', 'SSLCRLNL', 'SSLCRLNL', 'qm.sslcrlnl', 'text'], ['SSL cryptographic hardware', 'SSLCRYP', 'SSLCRYP', 'qm.sslcryp', 'text']] },
    { sec: 'Statistics', help: 'qmstats', items: [['MQI statistics', 'STATMQI', 'STATMQI', 'qm.statmqi', ONOFF], ['Queue statistics', 'STATQ', 'STATQ', 'qm.statq', ['ON', 'OFF', 'NONE']], ['Channel statistics', 'STATCHL', 'STATCHL', 'qm.statchl', LV]] },
    { sec: 'Online monitoring', help: 'monitoring', items: [['Queue monitoring', 'MONQ', 'MONQ', 'q.monq', LV], ['Channel monitoring', 'MONCHL', 'MONCHL', 'ch.monchl', LV], ['Auto-defined cluster sender monitoring', 'MONACLS', 'MONACLS', 'qm.monacls', ['QMGR', 'OFF', 'LOW', 'MEDIUM', 'HIGH']]] },
    { sec: 'Statistics monitoring', help: 'qmstats', items: [['Statistics interval (sn)', 'STATINT', 'STATINT', 'qm.statint', 'num'], ['Auto-defined cluster sender statistics', 'STATACLS', 'STATACLS', 'qm.monacls', ['QMGR', 'OFF', 'LOW', 'MEDIUM', 'HIGH']], ['Activity trace', 'ACTVTRC', 'ACTVTRC', 'qm.actvtrc', ONOFF], ['Activity trace override', 'ACTVCONO', 'ACTVCONO', 'qm.actvtrc', ED]] },
    { sec: 'Account monitoring', help: 'accounting', items: [['MQI accounting', 'ACCTMQI', 'ACCTMQI', 'accounting', ONOFF], ['Queue accounting', 'ACCTQ', 'ACCTQ', 'accounting', ['ON', 'OFF', 'NONE']], ['Accounting interval (sn)', 'ACCTINT', 'ACCTINT', 'accounting', 'num'], ['Accounting override', 'ACCTCONO', 'ACCTCONO', 'accounting', ED]] },
    { sec: 'Log', help: 'logtype', items: [['Log type', 'LogType (qm.ini)', 'logType', 'logtype', null], ['Primary log files', 'LogPrimaryFiles', 'logPrimary', 'log.files', null], ['Secondary log files', 'LogSecondaryFiles', 'logSecondary', 'log.files', null], ['Log file pages (4 KB)', 'LogFilePages', 'logFilePages', 'log.files', null], ['Log path', 'LogPath', 'logPath', 'log.path', null], ['Log write integrity', 'LogWriteIntegrity', 'logWriteIntegrity', 'log.path', null]] },
    { sec: 'Publish/Subscribe', help: 'pubsub', items: [['Publish/subscribe mode', 'PSMODE', 'PSMODE', 'qm.psmode', ['ENABLED', 'COMPAT', 'DISABLED']], ['Pub/sub retry count', 'PSRTYCNT', 'PSRTYCNT', 'qm.psrtycnt', 'num'], ['Non-persistent message failure', 'PSNPMSG', 'PSNPMSG', 'qm.psnpmsg', ['DISCARD', 'KEEP']], ['Non-persistent message response', 'PSNPRES', 'PSNPRES', 'qm.psnpmsg', ['NORMAL', 'SAFE', 'DISCARD', 'KEEP']], ['Pub/sub syncpoint', 'PSSYNCPT', 'PSSYNCPT', 'qm.pssyncpt', ['IFPER', 'YES']], ['Topic tree lifetime (sn)', 'TREELIFE', 'TREELIFE', 'qm.treelife', 'num'], ['Pub/sub clustering', 'PSCLUS', 'PSCLUS', 'qm.psclus', ED]] }
  ];
  function qmVal(qm, f) {
    var map = { QMNAME: qm.name, PLATFORM: qm.platform.toUpperCase(), QMSTATUS: qm.status, CMDLEVEL: qm.cmdlevel, VERSION: '0' + qm.version.split('.').map(function (x, i) { return i ? ('0' + x).slice(-2) : x; }).join(''), MAXPRTY: 9 };
    if (f in map) return map[f];
    if (f in qm.attrs) return qm.attrs[f];
    return qm[f];
  }
  MQ.route('/qm/:qm/config', function (p) { location.replace('#/qm/' + MQ.enc(p.qm) + '/config/properties'); return ''; }, 'manage');
  MQ.route('/qm/:qm/config/properties', cfgPage('properties', function (qm) {
    return MQ.propsEditor({ obj: qm, groups: QMP, get: qmVal, editKey: 'editQm', editName: qm.name, verb: 'ALTER QMGR',
      validate: function (c) {
        if (c.MAXMSGL !== undefined && (c.MAXMSGL < 32768 || c.MAXMSGL > 104857600)) return 'QM MAXMSGL 32768 ile 104857600 arasında olmalıdır.';
        if (c.DEADQ && !MQ.findQ(qm, c.DEADQ)) return 'AMQ8147E: DEADQ olarak belirtilen ' + c.DEADQ + ' kuyruğu bulunamadı. (MQSC aslında kabul eder; ancak DLQ çalışmaz. Bu simülatör sizi uyarmak için reddediyor.)';
        if (c.CHLAUTH === 'DISABLED') return '';
        return '';
      },
      warn: function (c) {
        var w = [];
        if (c.CHLAUTH === 'DISABLED') w.push('CHLAUTH(DISABLED): tüm channel authentication kuralları (varsayılan engelleme kuralları dahil) devre dışı kalır! Üretimde önerilmez.');
        if (c.CONNAUTH !== undefined) w.push('CONNAUTH değişikliğinin etkin olması için REFRESH SECURITY TYPE(CONNAUTH) çalıştırılmalıdır.');
        if (c.SSLKEYR !== undefined || c.CERTLABL !== undefined) w.push('Key repository değişiklikleri için REFRESH SECURITY TYPE(SSL) gerekir.');
        if (c.REPOS !== undefined) w.push('REPOS değişikliği bu QM\'in full repository rolünü değiştirir; cluster\'da en az iki full repository bulunmalıdır.');
        if (c.CCSID !== undefined) w.push('CCSID değişikliği için QM yeniden başlatılmalıdır.');
        return w;
      },
      apply: function (c) { Object.keys(c).forEach(function (k) { qm.attrs[k] = c[k]; }); if (c.REPOS !== undefined) { if (c.REPOS) qm.cluster = { name: c.REPOS, role: 'Full repository' }; else if (qm.cluster) qm.cluster.role = 'Partial repository'; } MQ.addEvent(qm, 'Config Change', 'Configuration', qm.name, 'MQRC_CONFIG_CHANGE_OBJECT (2368)', 'Info', 'ALTER QMGR ' + Object.keys(c).join(', ')); },
      success: 'AMQ8005I: IBM MQ queue manager changed.'
    });
  }), 'manage');

  /* ================================================== SECURITY */
  MQ.chlauthTable = function (qm, id, rowsFn) {
    return MQ.table({ id: id, rows: rowsFn,
      filters: [{ label: 'Tür', options: ['BLOCKUSER', 'BLOCKADDR', 'ADDRESSMAP', 'USERMAP', 'SSLPEERMAP', 'QMGRMAP'], fn: function (r, v) { return r.type === v; } }],
      columns: [
        { key: 'profile', label: 'Channel profile', help: 'chlauth.profile', render: function (r) { return '<span class="mono-sm">' + E(r.profile) + '</span>' + (r.def ? ' ' + MQ.tag('varsayılan', 'gray') : ''); } },
        { key: 'type', label: 'Type', help: 'chlauth.type', render: function (r) { return E(r.type) + H('chlauth.' + r.type.toLowerCase()); } },
        { key: 'match', label: 'Eşleşme', help: 'chlauth.match', render: function (r) { return '<span class="mono-sm">' + E(r.match) + '</span>'; } },
        { key: 'usersrc', label: 'USERSRC', help: 'chlauth.usersrc', render: function (r) { return r.usersrc === 'NOACCESS' ? MQ.tag('NOACCESS', 'red') : E(r.usersrc || '-'); } },
        { key: 'mcauser', label: 'MCAUSER', help: 'ch.mcauser' },
        { key: 'chckclnt', label: 'CHCKCLNT', help: 'connauth.chckclnt' },
        { key: 'warn', label: 'WARN', help: 'chlauth.warn' },
        { key: 'descr', label: 'Açıklama', wrap: true }
      ],
      create: { label: 'Create', fn: function () { MQ.act.setChlauth(qm); } },
      overflow: function (r) { return [{ label: 'MQSC komutunu göster', fn: function () { MQ.modal({ title: 'CHLAUTH kuralı', help: 'chlauth', primary: false, cancel: 'Kapat', body: '<pre class="preview-box">' + E(MQ.chlauthCmd(r)) + '</pre>' }); } }, '-', { label: 'Kaldır (ACTION(REMOVE))', danger: true, fn: function () { MQ.confirm({ title: 'CHLAUTH kuralı kaldırılsın mı?', help: 'chlauth', body: (r.def ? '<div class="notice warn">' + I('warning') + '<div class="grow">Bu bir <b>varsayılan güvenlik kuralı</b>. Kaldırmak queue manager\'ı yetkisiz erişime açabilir.</div></div>' : '') + '<pre class="preview-box">' + E("SET CHLAUTH('" + r.profile + "') TYPE(" + r.type + ') ' + r.match + ' ACTION(REMOVE)') + '</pre>', primary: 'Kaldır', onOk: function () { qm.chlauth.splice(qm.chlauth.indexOf(r), 1); MQ.save(); MQ.refresh(); MQ.toast('', 'CHLAUTH kuralı kaldırıldı (simülasyon)', 'AMQ8877I: IBM MQ channel authentication record set.'); } }); } }]; }
    });
  };
  MQ.chlauthCmd = function (r) {
    return "SET CHLAUTH('" + r.profile + "') TYPE(" + r.type + ') ' + r.match + (r.usersrc ? ' USERSRC(' + r.usersrc + ')' : '') + (r.mcauser ? " MCAUSER('" + r.mcauser + "')" : '') + (r.chckclnt && r.chckclnt !== 'ASQMGR' && r.type !== 'BLOCKUSER' && r.type !== 'BLOCKADDR' ? ' CHCKCLNT(' + r.chckclnt + ')' : '') + (r.warn === 'YES' ? ' WARN(YES)' : '') + (r.descr ? " DESCR('" + r.descr.replace(/'/g, "''") + "')" : '') + ' ACTION(REPLACE)';
  };
  function secPage(sub) {
    return cfgPage('security', function (qm) {
      var b = '#/qm/' + MQ.enc(qm.name) + '/config/security';
      var nav = [{ key: 'chlauth', label: 'CHLAUTH rules', href: b }, { key: 'test', label: 'CHLAUTH kural testi', href: b + '/test' }, { key: 'authrec', label: 'Authorization records (OAM)', href: b + '/authrec' }, { key: 'perm', label: 'User permissions', href: b + '/permissions' }, { key: 'connauth', label: 'Connection authentication', href: b + '/connauth' }, { key: 'authinfo', label: 'Authentication information', href: b + '/authinfo' }, { key: 'tls', label: 'TLS/SSL configuration', href: b + '/tls' }, { key: 'certs', label: 'Certificates', href: b + '/certs' }, { key: 'ciphers', label: 'Cipher specifications', href: b + '/ciphers' }, { key: 'mqsc', label: 'MQSC security settings', href: b + '/mqsc' }];
      var body = '';
      if (sub === 'chlauth') {
        body = '<p style="margin-top:0">Channel authentication kayıtları, bir kanala kimin, hangi adresten, hangi kimlikle bağlanabileceğini belirler. QM düzeyinde: <b>CHLAUTH(' + E(qm.attrs.CHLAUTH) + ')</b>' + H('qm.chlauth') + '</p>' + (qm.attrs.CHLAUTH === 'DISABLED' ? '<div class="notice err">' + I('error') + '<div class="grow">CHLAUTH devre dışı: aşağıdaki kurallar uygulanmıyor!</div></div>' : '') + MQ.chlauthTable(qm, 'chlauth-' + qm.name, function () { return qm.chlauth; });
      } else if (sub === 'test') {
        body = chlauthTest(qm);
      } else if (sub === 'authrec') {
        body = '<p style="margin-top:0">Object Authority Manager (OAM) yetki kayıtları. Unix/Linux\'ta yetkiler varsayılan olarak <b>gruplara</b> verilir; bir kullanıcıya verilen yetki aslında onun birincil grubuna uygulanır (qm.ini SecurityPolicy=user ile değiştirilebilir).' + H('oam') + '</p>' +
          MQ.table({ id: 'authrec-' + qm.name, rows: function () { return qm.authrec; }, pageSize: 20,
            filters: [{ label: 'Nesne tipi', options: ['QMGR', 'QUEUE', 'TOPIC', 'CHANNEL', 'PROCESS', 'NAMELIST', 'AUTHINFO', 'CLNTCONN', 'LISTENER', 'SERVICE', 'COMMINFO'], fn: function (r, v) { return r.objtype === v; } }],
            columns: [{ key: 'profile', label: 'Profile', help: 'authprofile', render: function (r) { return '<span class="mono-sm">' + E(r.profile) + '</span>'; } }, { key: 'objtype', label: 'Object type', help: 'authobjtype' }, { key: 'group', label: 'Group', help: 'oam' }, { key: 'auth', label: 'Authorities', help: 'authlist', render: function (r) { return r.auth.split(' ').map(function (a) { return MQ.tag(a, a.indexOf('ALL') === 0 ? 'purple' : 'blue'); }).join(' '); } }, { key: 'note', label: 'Not', wrap: true }],
            create: { label: 'Create', fn: function () { MQ.act.setAuthrec(qm); } },
            overflow: function (r) { return [{ label: 'Yetki değiştir', fn: function () { MQ.act.setAuthrec(qm, r); } }, { label: 'Sil (DELETE AUTHREC)', danger: true, disabled: r.group === 'mqm' ? 'mqm grubunun yetkileri kaldırılamaz' : false, fn: function () { MQ.confirm({ title: 'Yetki kaydı silinsin mi?', help: 'oam', body: '<pre class="preview-box">' + E("DELETE AUTHREC PROFILE('" + r.profile + "') OBJTYPE(" + r.objtype + ") GROUP('" + r.group + "')") + '</pre>', primary: 'Sil', onOk: function () { qm.authrec.splice(qm.authrec.indexOf(r), 1); MQ.save(); MQ.refresh(); MQ.toast('', 'Yetki kaydı silindi (simülasyon)', 'AMQ8862I: IBM MQ authority record set.'); } }); } }]; } });
      } else if (sub === 'perm') {
        body = permCheck(qm);
      } else if (sub === 'connauth') {
        var ai = qm.authinfo.filter(function (a) { return a.name === qm.attrs.CONNAUTH; })[0];
        body = '<div class="props-panel"><div class="props-sec"><h2>Connection authentication' + H('connauth') + '</h2>' +
          MQ.prop('CONNAUTH (QM)', 'CONNAUTH', E(qm.attrs.CONNAUTH) || '<span class="dim">(boş - kullanıcı/parola denetimi kapalı)</span>', 'qm.connauth') +
          (ai ? MQ.prop('Authentication type', 'AUTHTYPE', E(ai.authtype), 'authinfo.authtype') + MQ.prop('Client connections check', 'CHCKCLNT', E(ai.chckclnt), 'connauth.chckclnt') + MQ.prop('Local connections check', 'CHCKLOCL', E(ai.chcklocl), 'connauth.chcklocl') + MQ.prop('Adopt context', 'ADOPTCTX', E(ai.adoptctx), 'connauth.adoptctx') + MQ.prop('Authentication fail delay (sn)', 'FAILDLAY', ai.failDelay, 'connauth.faildlay') : '') +
          '</div><div class="flex"><button class="btn md" data-do="' + MQ.fn(function () { MQ.act.editConnauth(qm, ai); }) + '">Düzenle' + I('edit') + '</button><button class="btn md secondary" data-do="' + MQ.fn(function () { MQ.act.refreshSecurity(qm, 'CONNAUTH'); }) + '">REFRESH SECURITY TYPE(CONNAUTH)</button></div></div>' +
          '<div class="notice mt24">' + I('info') + '<div class="grow"><b>Nasıl çalışır?</b> İstemci uygulama MQCONNX çağrısında MQCSP yapısıyla kullanıcı adı/parola gönderir. CONNAUTH ile belirtilen AUTHINFO nesnesi (IDPWOS: işletim sistemi, IDPWLDAP: LDAP) bu bilgiyi doğrular. ADOPTCTX(YES) ise doğrulanan kullanıcı sonraki yetki (OAM) denetimlerinde kullanılır. CHLAUTH kuralındaki CHCKCLNT, QM düzeyindeki ayarı kanal/adres bazında sıkılaştırabilir.' + H('connauth') + '</div></div>';
      } else if (sub === 'authinfo') {
        body = MQ.table({ id: 'authinfo-' + qm.name, rows: function () { return qm.authinfo; },
          columns: [{ key: 'name', label: 'Name', help: 'authinfo', render: function (a) { return E(a.name) + (a.name === qm.attrs.CONNAUTH ? ' ' + MQ.tag('CONNAUTH', 'green') : ''); } }, { key: 'authtype', label: 'AUTHTYPE', help: 'authinfo.authtype', render: function (a) { return E(a.authtype) + H('authinfo.' + a.authtype.toLowerCase()); } }, { key: 'chckclnt', label: 'CHCKCLNT', help: 'connauth.chckclnt' }, { key: 'chcklocl', label: 'CHCKLOCL', help: 'connauth.chcklocl' }, { key: 'conname', label: 'CONNAME', render: function (a) { return '<span class="mono-sm">' + E(a.conname || a.ocspurl || '-') + '</span>'; } }, { key: 'descr', label: 'Açıklama', wrap: true }],
          create: { label: 'Create', fn: function () { MQ.act.createAuthinfo(qm); } },
          overflow: function (a) { return [{ label: 'CONNAUTH olarak ata', disabled: !/^IDPW/.test(a.authtype) ? 'Yalnızca IDPWOS / IDPWLDAP tipleri CONNAUTH olabilir' : false, fn: function () { qm.attrs.CONNAUTH = a.name; MQ.save(); MQ.refresh(); MQ.toast('warn', 'CONNAUTH güncellendi (simülasyon)', 'Etkin olması için REFRESH SECURITY TYPE(CONNAUTH) çalıştırın.', "ALTER QMGR CONNAUTH('" + a.name + "')\nREFRESH SECURITY TYPE(CONNAUTH)"); } }, { label: 'Sil', danger: true, disabled: a.name.indexOf('SYSTEM.') === 0 || a.name === qm.attrs.CONNAUTH, fn: function () { MQ.act.deleteObj(qm, 'authinfo', a, 'AUTHINFO'); } }]; } });
      } else if (sub === 'tls') {
        var chs = qm.channels;
        body = '<div class="props-panel"><div class="props-sec"><h2>Key repository' + H('qm.sslkeyr') + '</h2>' +
          MQ.prop('SSL key repository', 'SSLKEYR', '<span class="mono-sm">' + E(qm.attrs.SSLKEYR || '') + '</span>' + (qm.attrs.SSLKEYR ? ' <span class="dim">(.kdb + .sth dosyaları)</span>' : ''), 'qm.sslkeyr') +
          MQ.prop('Certificate label', 'CERTLABL', E(qm.attrs.CERTLABL), 'qm.certlabl') + MQ.prop('FIPS', 'SSLFIPS', E(qm.attrs.SSLFIPS), 'qm.sslfips') + MQ.prop('Secret key reset count', 'SSLRKEYC', qm.attrs.SSLRKEYC, 'qm.sslrkeyc') + MQ.prop('CRL namelist', 'SSLCRLNL', E(qm.attrs.SSLCRLNL), 'qm.sslcrlnl') + MQ.prop('SSL events', 'SSLEV', E(qm.attrs.SSLEV), 'qm.sslev') +
          '</div><div class="flex"><button class="btn md" data-do="' + MQ.fn(function () { MQ.act.configureTls(qm); }) + '">TLS yapılandır' + I('lock') + '</button><button class="btn md secondary" data-do="' + MQ.fn(function () { MQ.act.refreshSecurity(qm, 'SSL'); }) + '">REFRESH SECURITY TYPE(SSL)</button></div></div>' +
          '<h2 class="section-title">Channel TLS durumu' + H('ch.sslciph') + '</h2>' +
          MQ.table({ id: 'tlsch-' + qm.name, rows: function () { return chs; },
            filters: [{ label: 'TLS', options: [['yes', 'TLS var'], ['no', 'TLS yok']], fn: function (c, v) { return v === 'yes' ? !!c.sslciph : !c.sslciph; } }],
            columns: [{ key: 'name', label: 'Channel', render: function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '/properties">' + E(c.name) + '</a>'; } }, { key: 'chltype', label: 'Type' }, { key: 'sslciph', label: 'SSLCIPH', help: 'ch.sslciph', render: function (c) { return c.sslciph ? '<span class="mono-sm">' + E(c.sslciph) + '</span>' : MQ.tag('TLS yok', 'red'); } }, { key: 'sslcauth', label: 'SSLCAUTH', help: 'ch.sslcauth' }, { key: 'sslpeer', label: 'SSLPEER', help: 'ch.sslpeer', wrap: true, render: function (c) { return '<span class="mono-sm">' + E(c.sslpeer || '-') + '</span>'; } }, { key: 'certlabl', label: 'CERTLABL', help: 'ch.certlabl', render: function (c) { return E(c.certlabl || '(QM)'); } }],
            overflow: function (c) { return [{ label: 'TLS ayarla', fn: function () { MQ.act.configureTls(qm, c); } }]; } });
      } else if (sub === 'certs') {
        body = '<p style="margin-top:0">Key repository (' + E(qm.attrs.SSLKEYR || '-') + '.kdb) içindeki sertifikalar. Gerçek ortamda <code>runmqakm -cert -list -db key.kdb -stashed</code> ile listelenir.' + H('certificate') + '</p>' +
          MQ.table({ id: 'certs-' + qm.name, rows: function () { return qm.certs; },
            columns: [{ key: 'label', label: 'Label', help: 'qm.certlabl', render: function (c) { return E(c.label) + (c.label === qm.attrs.CERTLABL ? ' ' + MQ.tag('QM sertifikası', 'green') : ''); } }, { key: 'type', label: 'Tür', help: 'certificate' }, { key: 'subject', label: 'Subject DN', wrap: true, render: function (c) { return '<span class="mono-sm">' + E(c.subject) + '</span>'; } }, { key: 'to', label: 'Geçerlilik sonu' }, { key: 'key', label: 'Anahtar' }, { key: 'status', label: 'Durum', render: function (c) { return MQ.status(c.status); } }],
            create: { label: 'Sertifika isteği (CSR)', fn: function () { MQ.act.certRequest(qm); } },
            overflow: function (c) { return [{ label: 'Ayrıntılar', fn: function () { MQ.modal({ title: c.label, help: 'certificate', primary: false, cancel: 'Kapat', body: '<dl class="kv"><dt>Subject</dt><dd class="mono-sm">' + E(c.subject) + '</dd><dt>Issuer</dt><dd class="mono-sm">' + E(c.issuer) + '</dd><dt>Seri no</dt><dd>' + E(c.serial) + '</dd><dt>Geçerlilik</dt><dd>' + E(c.from) + ' → ' + E(c.to) + '</dd><dt>İmza algoritması</dt><dd>' + E(c.alg) + '</dd><dt>Anahtar</dt><dd>' + E(c.key) + '</dd></dl><div class="preview-h">Görüntüleme komutu</div><pre class="preview-box">runmqakm -cert -details -db ' + E(qm.attrs.SSLKEYR) + ".kdb -stashed -label '" + E(c.label) + "'</pre>" }); } }]; } });
      } else if (sub === 'ciphers') {
        body = '<p style="margin-top:0">IBM MQ 9.4 tarafından desteklenen başlıca CipherSpec\'ler. Kanalın her iki ucundaki SSLCIPH değerleri uyumlu olmalıdır (ANY_* alias\'ları en güçlü ortak seçeneği müzakere eder).' + H('ch.sslciph') + '</p>' +
          MQ.table({ id: 'ciphers', rows: function () { return MQ.CIPHERS; }, pageSize: 20,
            columns: [{ key: 'name', label: 'CipherSpec', render: function (c) { return '<span class="mono-sm">' + E(c.name) + '</span>'; } }, { key: 'proto', label: 'Protokol', help: 'tls' }, { key: 'type', label: 'Tür', render: function (c) { return /zayıf|Devre/.test(c.type) ? MQ.tag(c.type, 'red') : c.type === 'Alias' ? MQ.tag('ANY_* alias', 'teal') : E(c.type); } }, { key: 'since', label: 'Sürümden beri', help: 'mqversion' }, { key: 'note', label: 'Not', wrap: true }, { key: 'u', label: 'Kullanan channel', sort: false, render: function (c) { var n = qm.channels.filter(function (x) { return x.sslciph === c.name; }).length; return n || '-'; } }] });
      } else {
        var cmds = [['DISPLAY QMGR CHLAUTH CONNAUTH SSLKEYR CERTLABL', 'qm.chlauth'], ['DISPLAY CHLAUTH(*)', 'chlauth'], ["DISPLAY CHLAUTH('APP.ODEME.SVRCONN') MATCH(RUNCHECK) ADDRESS('10.20.40.11') CLNTUSER('odemeapp')", 'chlauth.runcheck'], ['DISPLAY AUTHREC PROFILE(*) OBJTYPE(QUEUE)', 'oam'], ['DISPLAY ENTAUTH PRINCIPAL(\'odemeapp\') OBJTYPE(QUEUE) OBJNAME(\'APP.ODEME.ISTEK\')', 'entauth'], ["SET AUTHREC PROFILE('APP.**') OBJTYPE(QUEUE) GROUP('appgrp') AUTHADD(PUT,GET)", 'setauthrec'], ['REFRESH SECURITY TYPE(AUTHSERV)', 'refreshsec'], ['REFRESH SECURITY TYPE(CONNAUTH)', 'refreshsec'], ['REFRESH SECURITY TYPE(SSL)', 'refreshsec'], ['DISPLAY AUTHINFO(*) ALL', 'authinfo'], ["ALTER AUTHINFO('SYSTEM.DEFAULT.AUTHINFO.IDPWOS') AUTHTYPE(IDPWOS) CHCKCLNT(REQUIRED)", 'connauth.chckclnt']];
        body = '<p style="margin-top:0">Güvenlik yönetiminde en sık kullanılan MQSC komutları. Bir komuta tıklayarak MQSC konsolunda deneyebilirsiniz.' + H('mqsc') + '</p><div class="cmd-list">' + cmds.map(function (c) { return '<div class="cmd-i"><code data-do="' + MQ.fn(function () { MQ.ui = MQ.ui || {}; MQ.ui.mqscPrefill = c[0]; MQ.go('#/qm/' + MQ.enc(qm.name) + '/mqsc'); }) + '">' + E(c[0]) + '</code>' + H(c[1]) + '</div>'; }).join('') + '</div>' +
          '<div class="notice mt24">' + I('info') + '<div class="grow">İşletim sistemi seviyesindeki eşdeğer komutlar: <code>setmqaut</code> (yetki ver/al), <code>dspmqaut</code> (etkin yetki), <code>dmpmqaut</code> (yetki dökümü), <code>runmqakm</code> (key repository).' + H('setmqaut') + '</div></div>';
      }
      return '<div class="with-side content" style="padding:0">' + MQ.sidenav(nav, sub) + '<div>' + body + '</div></div>';
    });
  }
  function chlauthTest(qm) {
    var names = qm.channels.filter(function (c) { return c.chltype !== 'CLNTCONN'; }).map(function (c) { return c.name; });
    MQ.after(function () {
      var f = document.getElementById('chlTest'); if (!f) return;
      var run = function () {
        var v = MQ.vals(f), out = MQ.simulateChlauth(qm, v);
        document.getElementById('chlTestOut').innerHTML = out.html;
        MQ.setPreview(f, "DISPLAY CHLAUTH('" + v.channel + "') MATCH(RUNCHECK) ADDRESS('" + v.address + "')" + (v.clntuser ? " CLNTUSER('" + v.clntuser + "')" : '') + (v.sslpeer ? " SSLPEER('" + v.sslpeer + "')" : '') + (v.qmname ? " QMNAME('" + v.qmname + "')" : ''));
      };
      f.addEventListener('input', run); f.addEventListener('change', run); run();
    });
    return '<p style="margin-top:0">Gerçek MQ\'daki <code>DISPLAY CHLAUTH ... MATCH(RUNCHECK)</code> komutunun sadeleştirilmiş bir simülasyonu: bir bağlantı denemesi için hangi kuralın uygulanacağını ve sonucun ne olacağını görün.' + H('chlauth.runcheck') + '</p>' +
      '<form id="chlTest" class="props-panel" onsubmit="return false"><div class="frow">' +
      MQ.F.select({ name: 'channel', label: 'Channel', help: 'chname', options: names, value: 'APP.MOBIL.SVRCONN' }) +
      MQ.F.text({ name: 'address', label: 'İstemci IP adresi', help: 'chlauth.addressmap', value: '10.20.30.14' }) +
      MQ.F.text({ name: 'clntuser', label: 'İstemci kullanıcı (asserted user)', help: 'chlauth.usermap', value: 'mobilapp' }) +
      MQ.F.text({ name: 'sslpeer', label: 'İstemci sertifika DN (SSLPEER)', help: 'chlauth.sslpeermap', value: '' }) +
      MQ.F.text({ name: 'qmname', label: 'Uzak queue manager (QM kanalları için)', help: 'chlauth.qmgrmap', value: '' }) +
      MQ.F.check({ name: 'pwd', label: 'İstemci MQCSP ile parola gönderiyor', help: 'connauth', value: true }) + '</div>' +
      MQ.F.preview('Eşdeğer MQSC komutu', 'chlauth.runcheck') + '<div id="chlTestOut" class="mt16"></div></form>';
  }
  MQ.simulateChlauth = function (qm, v) {
    var steps = [], result = 'ALLOW', user = v.clntuser || '', applied = null;
    var rules = qm.chlauth.filter(function (r) { return MQ.profileMatch(r.profile, v.channel); });
    var ipm = function (pat, ip) { return pat.split(',').some(function (p) { p = p.trim().replace(/'/g, ''); return MQ.profileMatch(p.replace(/\./g, '.'), ip) || new RegExp('^' + p.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$').test(ip); }); };
    var arg = function (m) { var x = m.match(/\('([^']*)'\)/); return x ? x[1] : ''; };
    if (qm.attrs.CHLAUTH === 'DISABLED') { steps.push('QM CHLAUTH(DISABLED): hiçbir kural değerlendirilmez.'); }
    else {
      var ba = qm.chlauth.filter(function (r) { return r.type === 'BLOCKADDR' && ipm(arg(r.match), v.address); })[0];
      if (ba) { steps.push('1. BLOCKADDR kuralı (' + ba.match + ') adresi listener seviyesinde engelledi. Bağlantı kanal adı bile okunmadan kapatılır.'); result = 'BLOCKED'; applied = ba; }
      else {
        steps.push('1. BLOCKADDR: eşleşme yok.');
        var spec = function (r) { return r.profile.replace(/\*/g, '').length; };
        var order = ['SSLPEERMAP', 'ADDRESSMAP', 'USERMAP', 'QMGRMAP'];
        var maps = rules.filter(function (r) {
          if (r.type === 'SSLPEERMAP') return v.sslpeer && v.sslpeer.replace(/\s/g, '').toUpperCase().indexOf(arg(r.match).replace(/\s/g, '').toUpperCase()) >= 0;
          if (r.type === 'ADDRESSMAP') return ipm(arg(r.match), v.address);
          if (r.type === 'USERMAP') return v.clntuser && arg(r.match) === v.clntuser;
          if (r.type === 'QMGRMAP') return v.qmname && MQ.profileMatch(arg(r.match), v.qmname);
          return false;
        }).sort(function (a, b) { return spec(b) - spec(a) || order.indexOf(a.type) - order.indexOf(b.type); });
        if (maps.length) {
          applied = maps[0];
          steps.push('2. Eşleşen en özel eşleme kuralı: <b>' + E(applied.profile) + ' ' + applied.type + ' ' + E(applied.match) + '</b>' + (maps.length > 1 ? ' (diğer ' + (maps.length - 1) + ' eşleşen kural daha az özel)' : ''));
          if (applied.usersrc === 'NOACCESS') { result = 'BLOCKED'; steps.push('3. USERSRC(NOACCESS): bağlantı reddedilir.'); }
          else if (applied.usersrc === 'MAP') { user = applied.mcauser; steps.push('3. USERSRC(MAP): MCAUSER = <b>' + E(user) + '</b>'); }
          else steps.push('3. USERSRC(CHANNEL): kimlik kanaldaki MCAUSER veya istemciden gelen kullanıcı (' + E(user || '-') + ') olur.');
          var cc = applied.chckclnt && applied.chckclnt !== 'ASQMGR' ? applied.chckclnt : null;
          if (result !== 'BLOCKED' && cc === 'REQUIRED' && !v.pwd) { result = 'BLOCKED'; steps.push('4. CHCKCLNT(REQUIRED) ancak istemci parola göndermedi → MQRC_NOT_AUTHORIZED (2035), AMQ5541E.'); }
          else if (cc) steps.push('4. CHCKCLNT(' + cc + '): ' + (v.pwd ? 'parola doğrulaması yapılır (simülasyonda başarılı kabul edildi).' : 'parola gerekmiyor.'));
        } else steps.push('2. Eşleme (MAP) kuralı yok: kanaldaki MCAUSER veya istemci kimliği kullanılır.');
        if (result !== 'BLOCKED') {
          var bu = rules.filter(function (r) { return r.type === 'BLOCKUSER'; });
          var privileged = /^(mqm|root|admin|mqadmin)$/i.test(user);
          var hit = bu.filter(function (r) { var l = arg(r.match.replace('USERLIST', '')) || r.match; return (/\*MQADMIN/.test(r.match) && privileged) || r.match.indexOf("'" + user + "'") >= 0; })[0];
          if (hit) { result = 'BLOCKED'; steps.push('5. BLOCKUSER (' + E(hit.match) + '): son kullanıcı kimliği ' + E(user) + ' engellenen listede → AMQ9777E Channel was blocked.'); applied = hit; }
          else steps.push('5. BLOCKUSER: son kimlik (' + E(user || '(istemci kimliği)') + ') engellenmedi.');
        }
      }
    }
    var ok = result === 'ALLOW';
    return { result: result, html: '<div class="notice ' + (ok ? 'ok' : 'err') + '">' + I(ok ? 'check' : 'error') + '<div class="grow"><b>' + (ok ? 'Bağlantıya izin verilir' : 'Bağlantı engellenir') + '</b>' + (ok ? ' — etkin MCAUSER: <b>' + E(user || '(istemci kimliği)') + '</b>. Sonraki adımda OAM bu kullanıcının grubunun yetkilerini denetler.' : ' — istemci MQRC_NOT_AUTHORIZED (2035) alır.') + '<ol style="margin:8px 0 0;padding-left:18px">' + steps.map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ol></div></div>' };
  };
  function permCheck(qm) {
    var groups = {}; qm.authrec.forEach(function (r) { groups[r.group || r.principal] = 1; });
    var objs = qm.queues.filter(function (q) { return !q.system; }).map(function (q) { return q.name; });
    MQ.after(function () {
      var f = document.getElementById('permForm'); if (!f) return;
      var run = function () {
        var v = MQ.vals(f), name = v.objtype === 'QMGR' ? 'self' : v.objname;
        var recs = qm.authrec.filter(function (r) { return r.group === v.group && r.objtype === v.objtype && (v.objtype === 'QMGR' ? r.profile === 'self' : MQ.profileMatch(r.profile, name)); });
        var auths = {}; recs.forEach(function (r) { r.auth.split(' ').forEach(function (a) { auths[a] = 1; }); });
        var list = Object.keys(auths);
        var all = v.objtype === 'QMGR' ? ['CONNECT', 'INQ', 'SET', 'SETALL', 'SETID', 'ALTUSR', 'DSP', 'CHG', 'CTRL'] : ['PUT', 'GET', 'BROWSE', 'INQ', 'SET', 'PASSALL', 'PASSID', 'SETALL', 'SETID', 'DSP', 'CHG', 'CLR', 'DLT', 'CRT'];
        document.getElementById('permOut').innerHTML = '<div class="props-panel"><div class="props-sec"><h2>Etkin yetkiler: ' + E(v.group) + ' → ' + E(v.objtype === 'QMGR' ? qm.name : v.objname) + '</h2><div class="flex wrap">' + all.map(function (a) { var has = auths[a] || auths.ALLMQI && ['CONNECT', 'INQ', 'SET', 'SETALL', 'SETID', 'ALTUSR', 'PUT', 'GET', 'BROWSE', 'PASSALL', 'PASSID'].indexOf(a) >= 0 || auths.ALLADM && ['DSP', 'CHG', 'CLR', 'DLT', 'CTRL', 'CRT'].indexOf(a) >= 0; return MQ.tag((has ? '✓ ' : '✗ ') + a, has ? 'green' : 'gray'); }).join(' ') + '</div>' +
          '<p class="muted">Eşleşen kayıtlar: ' + (recs.length ? recs.map(function (r) { return '<code>' + E(r.profile) + '</code> (' + E(r.auth) + ')'; }).join(', ') : 'yok') + '</p><pre class="preview-box">dspmqaut -m ' + E(qm.name) + ' -n ' + E(v.objtype === 'QMGR' ? qm.name : v.objname) + ' -t ' + (v.objtype === 'QMGR' ? 'qmgr' : v.objtype.toLowerCase()) + ' -g ' + E(v.group) + '\n# Entity ' + E(v.group) + ' has the following authorizations for object ' + E(v.objtype === 'QMGR' ? qm.name : v.objname) + ':\n' + (list.length ? list.map(function (a) { return '#\t' + a.toLowerCase(); }).join('\n') : '#\t(none)') + '</pre></div></div>';
      };
      f.addEventListener('change', run); f.addEventListener('input', run); run();
    });
    return '<p style="margin-top:0">Bir grubun belirli bir nesne üzerindeki etkin yetkilerini hesaplayın (<code>dspmqaut</code> / <code>DISPLAY ENTAUTH</code> karşılığı).' + H('entauth') + '</p><form id="permForm" onsubmit="return false" class="props-panel"><div class="frow3">' +
      MQ.F.select({ name: 'group', label: 'Grup', help: 'oam', options: Object.keys(groups), value: 'odemegrp' }) +
      MQ.F.select({ name: 'objtype', label: 'Nesne tipi', help: 'authobjtype', options: ['QUEUE', 'QMGR', 'TOPIC'], value: 'QUEUE' }) +
      MQ.F.select({ name: 'objname', label: 'Nesne adı', help: 'authprofile', options: objs.concat(['bildirim/musteri']), value: 'APP.ODEME.ISTEK' }) + '</div></form><div id="permOut" class="mt16"></div>';
  }
  ['chlauth', 'test', 'authrec', 'perm', 'connauth', 'authinfo', 'tls', 'certs', 'ciphers', 'mqsc'].forEach(function (s) {
    var path = { chlauth: '', test: '/test', authrec: '/authrec', perm: '/permissions', connauth: '/connauth', authinfo: '/authinfo', tls: '/tls', certs: '/certs', ciphers: '/ciphers', mqsc: '/mqsc' }[s];
    MQ.route('/qm/:qm/config/security' + path, secPage(s), 'manage');
  });

  /* ================================================== LISTENERS */
  MQ.route('/qm/:qm/config/listeners', cfgPage('listeners', function (qm) {
    return '<p style="margin-top:0">Listener\'lar, gelen ağ bağlantılarını (istemci uygulamalar ve diğer queue manager\'ların kanalları) kabul eden süreçlerdir (runmqlsr).' + H('listener') + '</p>' +
      MQ.table({ id: 'lst-' + qm.name, rows: function () { return qm.listeners; },
        columns: [
          { key: 'name', label: 'Listener name', help: 'lstr.name', render: function (l) { return '<a href="#" data-do="' + MQ.fn(function () { MQ.act.listenerDetail(qm, l); }) + '">' + E(l.name) + '</a>'; } },
          { key: 'status', label: 'Status', help: 'lstr.status', render: function (l) { return MQ.status(l.status); } },
          { key: 'trptype', label: 'Transport type', help: 'lstr.trptype' },
          { key: 'port', label: 'Port', num: true, help: 'lstr.port', render: function (l) { return l.port === 0 ? '0 (=1414)' : l.port; } },
          { key: 'ipaddr', label: 'IP address', help: 'lstr.ipaddr', render: function (l) { return l.ipaddr ? E(l.ipaddr) : '<span class="dim">(tüm arayüzler)</span>'; } },
          { key: 'control', label: 'Control', help: 'lstr.control' },
          { key: 'backlog', label: 'Backlog', num: true, help: 'lstr.backlog', render: function (l) { return l.backlog === 0 ? '0 (varsayılan)' : l.backlog; } },
          { key: 'descr', label: 'Açıklama', wrap: true }
        ],
        create: { label: 'Create', fn: function () { MQ.act.createListener(qm); } },
        overflow: function (l) { return [{ label: 'Ayrıntılar (LSSTATUS)', fn: function () { MQ.act.listenerDetail(qm, l); } }, { label: 'Başlat (START LISTENER)', disabled: l.status === 'Running', fn: function () { MQ.act.startListener(qm, l); } }, { label: 'Durdur (STOP LISTENER)', disabled: l.status !== 'Running', fn: function () { MQ.act.stopListener(qm, l); } }, '-', { label: 'Sil', danger: true, disabled: l.status === 'Running' ? 'Çalışan listener silinemez; önce durdurun' : false, fn: function () { MQ.act.deleteObj(qm, 'listeners', l, 'LISTENER'); } }]; } });
  }), 'manage');

  /* ================================================== MQ OBJECTS */
  function objPage(sub) {
    return cfgPage('objects', function (qm) {
      var b = '#/qm/' + MQ.enc(qm.name) + '/config/objects';
      var nav = [{ key: 'process', label: 'Process definitions', href: b }, { key: 'namelist', label: 'Namelists', href: b + '/namelists' }, { key: 'service', label: 'Service objects', href: b + '/services' }, { key: 'comminfo', label: 'Communication information', href: b + '/comminfo' }, { key: 'stgclass', label: 'Storage classes', href: b + '/stgclass' }, { key: 'authinfo', label: 'Authentication information', href: '#/qm/' + MQ.enc(qm.name) + '/config/security/authinfo' }, { key: 'chlauth', label: 'Channel authentication records', href: '#/qm/' + MQ.enc(qm.name) + '/config/security' }, { key: 'qmattr', label: 'Queue manager attributes', href: '#/qm/' + MQ.enc(qm.name) + '/config/properties' }];
      var body;
      if (sub === 'process') {
        body = '<p style="margin-top:0">Process definition, triggering sırasında hangi uygulamanın başlatılacağını tanımlar.' + H('process') + '</p>' + MQ.table({ id: 'proc-' + qm.name, rows: function () { return qm.processes; },
          columns: [{ key: 'name', label: 'Name', help: 'process' }, { key: 'appltype', label: 'APPLTYPE', help: 'process.appltype' }, { key: 'applicid', label: 'APPLICID', help: 'process.applicid', render: function (p) { return '<span class="mono-sm">' + E(p.applicid || '-') + '</span>'; } }, { key: 'userdata', label: 'USERDATA', help: 'process.userdata' }, { key: 'envrdata', label: 'ENVRDATA', help: 'process.userdata' }, { key: 'descr', label: 'Açıklama', wrap: true }, { key: 'used', label: 'Kullanan kuyruk', sort: false, render: function (p) { return qm.queues.filter(function (q) { return q.process === p.name; }).map(function (q) { return '<a href="' + MQ.qLink(qm.name, q.name) + '">' + E(q.name) + '</a>'; }).join(', ') || '-'; } }],
          create: { label: 'Create', fn: function () { MQ.act.createProcess(qm); } }, overflow: function (p) { return [{ label: 'Sil', danger: true, disabled: p.name.indexOf('SYSTEM.') === 0, fn: function () { MQ.act.deleteObj(qm, 'processes', p, 'PROCESS'); } }]; } });
      } else if (sub === 'namelist') {
        body = '<p style="margin-top:0">Namelist, başka nesnelerin adlarından oluşan bir listedir; cluster listesi (CLUSNL, REPOSNL) veya CRL sunucuları (SSLCRLNL) için kullanılır.' + H('namelist') + '</p>' + MQ.table({ id: 'nl-' + qm.name, rows: function () { return qm.namelists; },
          columns: [{ key: 'name', label: 'Name', help: 'namelist' }, { key: 'names', label: 'NAMES', help: 'namelist.names', render: function (n) { return n.names.length ? n.names.map(function (x) { return MQ.tag(x, 'gray'); }).join(' ') : '-'; } }, { key: 'descr', label: 'Açıklama', wrap: true }],
          create: { label: 'Create', fn: function () { MQ.act.createNamelist(qm); } }, overflow: function (n) { return [{ label: 'Sil', danger: true, disabled: n.name.indexOf('SYSTEM.') === 0, fn: function () { MQ.act.deleteObj(qm, 'namelists', n, 'NAMELIST'); } }]; } });
      } else if (sub === 'service') {
        body = '<p style="margin-top:0">Service nesneleri, queue manager ile birlikte başlatılıp durdurulabilen harici programları (trigger monitor, DLQ handler, betikler) tanımlar.' + H('service') + '</p>' + MQ.table({ id: 'srv-' + qm.name, rows: function () { return qm.services; },
          columns: [{ key: 'name', label: 'Name', help: 'service' }, { key: 'servtype', label: 'SERVTYPE', help: 'service.servtype' }, { key: 'control', label: 'CONTROL', help: 'lstr.control' }, { key: 'status', label: 'Status', render: function (s) { return MQ.status(s.status); } }, { key: 'startcmd', label: 'STARTCMD', render: function (s) { return '<span class="mono-sm">' + E(s.startcmd) + '</span>'; } }, { key: 'startarg', label: 'STARTARG', render: function (s) { return '<span class="mono-sm">' + E(s.startarg) + '</span>'; } }, { key: 'descr', label: 'Açıklama', wrap: true }],
          create: { label: 'Create', fn: function () { MQ.act.createService(qm); } },
          overflow: function (s) { return [{ label: 'Başlat (START SERVICE)', disabled: s.status === 'Running' || s.servtype === 'COMMAND' && false, fn: function () { s.status = s.servtype === 'SERVER' ? 'Running' : 'N/A'; MQ.save(); MQ.redrawTable('srv-' + qm.name); MQ.toast('', 'Service başlatıldı (simülasyon)', 'AMQ8733I: Request to start Service accepted.', "START SERVICE('" + s.name + "')"); } }, { label: 'Durdur (STOP SERVICE)', disabled: s.status !== 'Running', fn: function () { s.status = 'Stopped'; MQ.save(); MQ.redrawTable('srv-' + qm.name); MQ.toast('', 'Service durduruldu (simülasyon)', 'AMQ8735I: Request to stop Service accepted.', "STOP SERVICE('" + s.name + "')"); } }, '-', { label: 'Sil', danger: true, fn: function () { MQ.act.deleteObj(qm, 'services', s, 'SERVICE'); } }]; } });
      } else if (sub === 'comminfo') {
        body = '<p style="margin-top:0">Communication information (COMMINFO) nesneleri, multicast publish/subscribe iletimi için gereken ağ bilgisini tutar.' + H('comminfo') + '</p>' + MQ.table({ id: 'ci-' + qm.name, rows: function () { return qm.comminfo; }, search: false,
          columns: [{ key: 'name', label: 'Name', help: 'comminfo' }, { key: 'grpaddr', label: 'GRPADDR', help: 'comminfo' }, { key: 'port', label: 'PORT', num: true }, { key: 'encoding', label: 'ENCODING' }, { key: 'bridge', label: 'BRIDGE' }, { key: 'descr', label: 'Açıklama', wrap: true }] });
      } else {
        body = '<div class="notice warn">' + I('info') + '<div class="grow"><b>Storage class nesneleri yalnızca IBM MQ for z/OS\'ta bulunur.</b> Bu queue manager ' + E(qm.platform) + ' platformunda çalıştığı için STGCLASS tanımlanamaz; dağıtık platformlarda (Linux, Windows, AIX) kuyruklar dosya sisteminde ayrı kuyruk dosyalarında saklanır.' + H('stgclass') + '</div></div>' +
          '<h2 class="section-title">z/OS örneği (QMZOS1 üzerinde)</h2>' + MQ.table({ id: 'stg', search: false, rows: function () { return [{ name: 'DEFAULT', psid: 0, descr: 'Varsayılan storage class' }, { name: 'SYSTEM', psid: 0, descr: 'Sistem nesneleri için' }, { name: 'STGONLINE', psid: 4, descr: 'Online işlem kuyrukları (örnek)' }, { name: 'STGBATCH', psid: 5, descr: 'Batch kuyrukları - ayrı page set (örnek)' }]; },
          columns: [{ key: 'name', label: 'STGCLASS', help: 'stgclass' }, { key: 'psid', label: 'PSID (page set)', num: true, help: 'stgclass' }, { key: 'descr', label: 'Açıklama' }] }) + '<pre class="preview-box mt16">DEFINE STGCLASS(STGBATCH) PSID(05) DESCR(\'Batch kuyruklari\')\nDEFINE QLOCAL(BATCH.IN) STGCLASS(STGBATCH)</pre>';
      }
      return '<div class="with-side content" style="padding:0">' + MQ.sidenav(nav, sub) + '<div>' + body + '</div></div>';
    });
  }
  MQ.route('/qm/:qm/config/objects', objPage('process'), 'manage');
  MQ.route('/qm/:qm/config/objects/namelists', objPage('namelist'), 'manage');
  MQ.route('/qm/:qm/config/objects/services', objPage('service'), 'manage');
  MQ.route('/qm/:qm/config/objects/comminfo', objPage('comminfo'), 'manage');
  MQ.route('/qm/:qm/config/objects/stgclass', objPage('stgclass'), 'manage');

  /* ================================================== LOGS */
  MQ.route('/qm/:qm/config/logs', cfgPage('logs', function (qm) {
    var sep = qm.platform === 'Windows' ? '\\' : '/';
    return '<h2 class="section-title">Hata log\'u (AMQERR01.LOG)' + H('errorlog') + '</h2>' +
      '<p class="muted" style="margin-top:0">Konum: <code>' + E(qm.dataPath + sep + 'errors' + sep + 'AMQERR01.LOG') + '</code> — dosya dolduğunda AMQERR02 ve AMQERR03\'e döner. Kuruluş geneli hatalar: <code>' + (qm.platform === 'Windows' ? 'C:\\ProgramData\\IBM\\MQ\\errors' : '/var/mqm/errors') + '</code></p>' +
      MQ.table({ id: 'err-' + qm.name, rows: function () { return qm.errlog; }, defaultSort: { key: 'time', dir: 'desc' },
        filters: [{ label: 'Önem', options: [['E', 'Error (E)'], ['W', 'Warning (W)'], ['I', 'Info (I)']], fn: function (r, v) { return r.sev === v; } }],
        columns: [{ key: 'time', label: 'Zaman' }, { key: 'code', label: 'Mesaj', help: 'amqcode', render: function (r) { return '<a href="#" data-do="' + MQ.fn(function () { MQ.act.errDetail(r); }) + '">' + MQ.status(r.sev === 'E' ? 'Error' : r.sev === 'W' ? 'Warning' : 'Normal').replace(/>[^<]*<\/span>$/, '>' + E(r.code) + '</span>') + '</a>'; } }, { key: 'text', label: 'Açıklama', wrap: true }],
        overflow: function (r) { return [{ label: 'Ayrıntılar', fn: function () { MQ.act.errDetail(r); } }]; } }) +
      '<h2 class="section-title">Recovery log yapılandırması' + H('logtype') + '</h2><div class="props-panel">' +
      MQ.prop('Log type', 'LogType', MQ.tag(qm.logType, qm.logType === 'LINEAR' ? 'purple' : 'teal'), 'logtype') +
      MQ.prop('Primary log files', 'LogPrimaryFiles', qm.logPrimary, 'log.files') +
      MQ.prop('Secondary log files', 'LogSecondaryFiles', qm.logSecondary, 'log.files') +
      MQ.prop('Log file pages', 'LogFilePages', MQ.fmt(qm.logFilePages) + ' × 4 KB = ' + Math.round(qm.logFilePages * 4 / 1024) + ' MB / dosya', 'log.files') +
      MQ.prop('Toplam log alanı (yaklaşık)', '', Math.round((qm.logPrimary + qm.logSecondary) * qm.logFilePages * 4 / 1024) + ' MB', 'log.files') +
      MQ.prop('Log path', 'LogPath', '<span class="mono-sm">' + E(qm.logPath) + '</span>', 'log.path') +
      MQ.prop('Log write integrity', 'LogWriteIntegrity', E(qm.logWriteIntegrity), 'log.path') +
      (qm.logType === 'LINEAR' ? MQ.prop('Media image scheduling', 'IMGSCHED', E(qm.attrs.IMGSCHED), 'qm.imgsched') : '') +
      '</div><div class="notice mt24">' + I('info') + '<div class="grow"><b>FDC dosyaları:</b> Beklenmeyen dahili hatalarda MQ, <code>' + (qm.platform === 'Windows' ? 'C:\\ProgramData\\IBM\\MQ\\errors' : '/var/mqm/errors') + '</code> altında <code>AMQnnnnn.n.FDC</code> (First Failure Data Capture) dosyaları üretir; IBM destek kaydı açarken bu dosyalar istenir.' + H('fdc') + '</div></div>';
  }), 'manage');
})();
