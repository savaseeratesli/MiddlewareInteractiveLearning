/* Kuyruk ve channel detay sayfaları (Messages, Properties, Status, Handles, Authority / Status, Instances, Security) */
(function () {
  'use strict';
  var MQ = window.MQ, H = MQ.help, I = MQ.icon, E = MQ.esc;
  var ED = ['ENABLED', 'DISABLED'], YN = ['YES', 'NO'], LVL = ['QMGR', 'OFF', 'LOW', 'MEDIUM', 'HIGH'];
  var LOC = ['QLOCAL', 'QMODEL'];

  /* [etiket, MQSC özniteliği, alan, help, düzenleme tipi, geçerli tipler] */
  MQ.QPROPS = [
    { sec: 'General', help: 'qlocal', items: [
      ['Queue name', 'QUEUE', 'name', 'qname', null],
      ['Queue type', 'TYPE', 'type', 'qtype', null],
      ['Description', 'DESCR', 'descr', 'q.descr', 'text'],
      ['Put messages', 'PUT', 'put', 'q.put', ED, ['QLOCAL', 'QMODEL', 'QREMOTE', 'QALIAS', 'QCLUSTER']],
      ['Get messages', 'GET', 'get', 'q.get', ED, ['QLOCAL', 'QMODEL', 'QALIAS']],
      ['Default priority', 'DEFPRTY', 'defprty', 'q.defprty', 'num'],
      ['Default persistence', 'DEFPSIST', 'defpsist', 'q.defpsist', YN],
      ['Usage', 'USAGE', 'usage', 'q.usage', ['NORMAL', 'XMITQ'], LOC],
      ['Default put response', 'DEFPRESP', 'defpresp', 'q.defpresp', ['SYNC', 'ASYNC']],
      ['Default read ahead', 'DEFREADA', 'defreada', 'q.defreada', ['NO', 'YES', 'DISABLED'], ['QLOCAL', 'QMODEL', 'QALIAS']],
      ['Property control', 'PROPCTL', 'propctl', 'q.propctl', ['COMPAT', 'ALL', 'FORCE', 'NONE', 'V6COMPAT'], ['QLOCAL', 'QMODEL', 'QALIAS']]
    ] },
    { sec: 'Remote', types: ['QREMOTE'], help: 'qremote', items: [
      ['Remote queue', 'RNAME', 'rname', 'qremote.rname', 'text'],
      ['Remote queue manager', 'RQMNAME', 'rqmname', 'qremote.rqmname', 'text'],
      ['Transmission queue', 'XMITQ', 'xmitq', 'qremote.xmitq', 'text']
    ] },
    { sec: 'Alias', types: ['QALIAS'], help: 'qalias', items: [
      ['Target', 'TARGET', 'target', 'qalias.target', 'text'],
      ['Target type', 'TARGTYPE', 'targtype', 'qalias.targtype', ['QUEUE', 'TOPIC']]
    ] },
    { sec: 'Model', types: ['QMODEL'], help: 'qmodel', items: [['Definition type', 'DEFTYPE', 'deftype', 'qmodel.deftype', ['TEMPDYN', 'PERMDYN']]] },
    { sec: 'Cluster queue', types: ['QCLUSTER'], help: 'clusterq', items: [['Hosting queue manager', 'CLUSQMGR', 'clusqmgr', 'clusqmgr', null]] },
    { sec: 'Extended', types: LOC, items: [
      ['Maximum queue depth', 'MAXDEPTH', 'maxdepth', 'maxdepth', 'num'],
      ['Maximum message length', 'MAXMSGL', 'maxmsgl', 'q.maxmsgl', 'num'],
      ['Shareability', 'SHARE/NOSHARE', 'share', 'q.share', ['SHARE', 'NOSHARE']],
      ['Default input open option', 'DEFSOPT', 'defsopt', 'q.defsopt', ['SHARED', 'EXCL']],
      ['Message delivery sequence', 'MSGDLVSQ', 'msgdlvsq', 'q.msgdlvsq', ['PRIORITY', 'FIFO']],
      ['Backout threshold', 'BOTHRESH', 'bothresh', 'backout', 'num'],
      ['Backout requeue name', 'BOQNAME', 'boqname', 'q.boqname', 'text'],
      ['Harden get backout', 'HARDENBO', 'harden', 'q.hardenbo', ['HARDENBO', 'NOHARDENBO']],
      ['Non-persistent message class', 'NPMCLASS', 'npmclass', 'q.npmclass', ['NORMAL', 'HIGH']],
      ['Retention interval (saat)', 'RETINTVL', 'retintvl', 'q.retintvl', 'num']
    ] },
    { sec: 'Cluster', types: ['QLOCAL', 'QREMOTE', 'QALIAS', 'QCLUSTER'], help: 'cluster', items: [
      ['Cluster name', 'CLUSTER', 'cluster', 'q.cluster', 'text'],
      ['Cluster namelist', 'CLUSNL', 'clusnl', 'q.clusnl', 'text'],
      ['Default bind', 'DEFBIND', 'defbind', 'q.defbind', ['OPEN', 'NOTFIXED', 'GROUP']],
      ['CLWL priority', 'CLWLPRTY', 'clwlprty', 'q.clwlprty', 'num'],
      ['CLWL rank', 'CLWLRANK', 'clwlrank', 'q.clwlrank', 'num'],
      ['CLWL use queue', 'CLWLUSEQ', 'clwluseq', 'q.clwluseq', ['QMGR', 'ANY', 'LOCAL'], ['QLOCAL']]
    ] },
    { sec: 'Triggering', types: LOC, help: 'triggering', items: [
      ['Trigger control', 'TRIGGER/NOTRIGGER', 'trigger', 'q.trigger', ['TRIGGER', 'NOTRIGGER']],
      ['Trigger type', 'TRIGTYPE', 'trigtype', 'q.trigtype', ['FIRST', 'EVERY', 'DEPTH', 'NONE']],
      ['Trigger depth', 'TRIGDPTH', 'trigdpth', 'q.trigdpth', 'num'],
      ['Trigger message priority', 'TRIGMPRI', 'trigmpri', 'q.trigmpri', 'num'],
      ['Trigger data', 'TRIGDATA', 'trigdata', 'q.trigdata', 'text'],
      ['Initiation queue', 'INITQ', 'initq', 'initq', 'text'],
      ['Process name', 'PROCESS', 'process', 'process', 'text']
    ] },
    { sec: 'Events', types: LOC, help: 'perfevents', items: [
      ['Queue depth high limit (%)', 'QDEPTHHI', 'qdepthhi', 'qdepthhi', 'num'],
      ['Queue depth low limit (%)', 'QDEPTHLO', 'qdepthlo', 'q.qdepthlo', 'num'],
      ['Queue depth high events', 'QDPHIEV', 'qdphiev', 'qdepthhi', ED],
      ['Queue depth low events', 'QDPLOEV', 'qdploev', 'q.qdepthlo', ED],
      ['Queue full events', 'QDPMAXEV', 'qdpmaxev', 'qfull', ED],
      ['Service interval events', 'QSVCIEV', 'qsvciev', 'q.qsvciev', ['NONE', 'HIGH', 'OK']],
      ['Service interval (ms)', 'QSVCINT', 'qsvcint', 'q.qsvciev', 'num']
    ] },
    { sec: 'Statistics & monitoring', types: LOC, help: 'monitoring', items: [
      ['Queue monitoring', 'MONQ', 'monq', 'q.monq', LVL],
      ['Queue statistics', 'STATQ', 'statq', 'q.statq', ['QMGR', 'ON', 'OFF']],
      ['Queue accounting', 'ACCTQ', 'acctq', 'accounting', ['QMGR', 'ON', 'OFF']]
    ] },
    { sec: 'Storage', types: LOC, help: 'q.maxfsize', items: [
      ['Maximum queue file size', 'MAXFSIZE', 'maxfsize', 'q.maxfsize', 'text'],
      ['Streaming queue', 'STREAMQ', 'streamq', 'q.streamq', 'text'],
      ['Streaming quality of service', 'STRMQOS', 'strmqos', 'q.streamq', ['BESTEF', 'MUSTDUP']]
    ] },
    { sec: 'Zaman damgaları', items: [['Oluşturulma', 'CRDATE/CRTIME', 'created', 'q.timestamps', null], ['Son değişiklik', 'ALTDATE/ALTTIME', 'altered', 'q.timestamps', null]] }
  ];
  function qVal(q, f) {
    if (f === 'trigger') return q.trigger ? 'TRIGGER' : 'NOTRIGGER';
    if (f === 'share') return q.share === 'NOSHARE' ? 'NOSHARE' : 'SHARE';
    if (f === 'type') return q.type;
    return q[f];
  }
  function setQVal(q, f, v) {
    if (f === 'trigger') q.trigger = v === 'TRIGGER';
    else if (typeof QDEF_NUM[f] !== 'undefined') q[f] = parseInt(v, 10) || 0;
    else q[f] = v;
  }
  var QDEF_NUM = { maxdepth: 1, maxmsgl: 1, defprty: 1, bothresh: 1, trigdpth: 1, trigmpri: 1, qdepthhi: 1, qdepthlo: 1, qsvcint: 1, clwlprty: 1, clwlrank: 1, retintvl: 1 };
  MQ.mqscVal = function (attr, v, editType) {
    if (editType === 'num') return attr + '(' + v + ')';
    if (Array.isArray(editType)) { if (/\//.test(attr)) return v; return attr + '(' + v + ')'; }
    return attr + "('" + String(v).replace(/'/g, "''") + "')";
  };

  /* ================================================== QUEUE DETAIL */
  function qPage(p) {
    var qm = MQ.qm(p.qm); if (!qm) throw new Error('Queue manager bulunamadı');
    if (!MQ.isUp(qm)) return MQ.qmHead(qm, 'queues') + MQ.notRunning(qm);
    var q = MQ.findQ(qm, p.q);
    if (!q) return MQ.pageHead({ crumbs: [['Manage', '#/manage'], [qm.name, MQ.qmLink(qm.name)], ['Queues', '#/qm/' + MQ.enc(qm.name) + '/queues']], title: 'Kuyruk bulunamadı' }) + '<div class="content"><div class="notice err">' + I('error') + '<div class="grow"><b>AMQ8147E: IBM MQ object ' + E(p.q) + ' not found.</b><br>Kuyruk silinmiş veya hiç tanımlanmamış olabilir. Reason: MQRC_UNKNOWN_OBJECT_NAME (2085)' + H('reasoncode') + '</div></div></div>';
    var loc = q.type === 'QLOCAL';
    var tab = p.tab || (loc ? 'messages' : 'properties');
    var base = MQ.qLink(qm.name, q.name);
    var tabs = (loc ? [['messages', 'Messages'], ['properties', 'Properties'], ['status', 'Status'], ['handles', 'Handles'], ['auth', 'Yetkiler']] : [['properties', 'Properties'], ['auth', 'Yetkiler']]);
    var a = MQ.act;
    var actions = [];
    if (q.type !== 'QMODEL') actions.push({ label: 'Mesaj koy (Put)', fn: function () { a.putMessage(qm, q); } });
    if (loc || q.type === 'QALIAS') actions.push({ label: 'Mesaj al (Get)', fn: function () { a.getMessage(qm, q); } });
    if (loc) actions.push({ label: 'Kuyruğu temizle (Clear)', fn: function () { a.clearQueue(qm, q); } });
    if (q.type !== 'QCLUSTER') { actions.push({ label: 'Özellikleri düzenle', fn: function () { MQ.ui = MQ.ui || {}; MQ.ui.editQ = q.name; MQ.go(base + '/properties'); MQ.refresh(); } }); actions.push({ label: 'Benzerini oluştur (LIKE)', fn: function () { a.createQueue(qm, q); } }); actions.push('-'); actions.push({ label: 'Sil', danger: true, fn: function () { a.deleteQueue(qm, q); } }); }
    var roles = MQ.qRoles(qm, q);
    var head = MQ.pageHead({
      crumbs: [['Manage', '#/manage'], [qm.name, MQ.qmLink(qm.name)], ['Queues', '#/qm/' + MQ.enc(qm.name) + '/queues']],
      title: q.name, icon: 'queue', help: { QLOCAL: 'qlocal', QREMOTE: 'qremote', QALIAS: 'qalias', QMODEL: 'qmodel', QCLUSTER: 'clusterq' }[q.type],
      right: actions.length ? MQ.ddButton('Actions', actions) : '',
      tabs: tabs.map(function (t) { return { label: t[1], href: base + '/' + t[0], active: t[0] === tab }; }),
      tabsRight: MQ.tag(MQ.qTypeLabel(q), 'blue') + roles.map(function (r) { return MQ.tag(r, r === 'Dead letter' ? 'red' : 'purple'); }).join('') + (loc ? MQ.tag(MQ.fmt(q.curdepth) + ' / ' + MQ.fmt(q.maxdepth), MQ.depthState(q) === 'full' ? 'red' : MQ.depthState(q) === 'warn' ? 'yellow' : 'teal') : '')
    });
    var body = '';
    var notes = '';
    if (q.get === 'DISABLED' || q.put === 'DISABLED') notes += '<div class="notice warn">' + I('warning') + '<div class="grow">Bu kuyrukta ' + (q.put === 'DISABLED' ? '<b>PUT</b> ' : '') + (q.get === 'DISABLED' && q.put === 'DISABLED' ? 've ' : '') + (q.get === 'DISABLED' ? '<b>GET</b> ' : '') + 'işlemleri engellenmiş (inhibited). Uygulamalar MQRC_PUT_INHIBITED (2051) / MQRC_GET_INHIBITED (2016) alır.' + H('q.put') + '</div></div>';
    if (loc && MQ.depthState(q) === 'full') notes += '<div class="notice err">' + I('error') + '<div class="grow"><b>Kuyruk dolu.</b> Yeni MQPUT çağrıları MQRC_Q_FULL (2053) ile reddedilir. Kanallarla gelen mesajlar dead-letter queue\'ya yönlendirilir.' + H('qfull') + '</div></div>';
    else if (loc && MQ.depthState(q) === 'warn') notes += '<div class="notice warn">' + I('warning') + '<div class="grow"><b>Kuyruk derinliği yüksek</b> (%' + MQ.pct(q.curdepth, q.maxdepth) + ' ≥ QDEPTHHI %' + q.qdepthhi + '). Tüketici uygulamaların çalıştığını kontrol edin.' + H('qdepthhi') + '</div></div>';
    if (q.usage === 'XMITQ' && q.curdepth > 0) notes += '<div class="notice warn">' + I('warning') + '<div class="grow">Bu bir <b>transmission queue</b>. Mesajların birikmesi, ilgili sender/server channel\'ın çalışmadığını gösterir. ' + qm.channels.filter(function (c) { return c.xmitq === q.name; }).map(function (c) { return '<a href="' + MQ.chLink(qm.name, c.name) + '">' + E(c.name) + '</a> ' + MQ.status(c.status); }).join(', ') + H('xmitq') + '</div></div>';
    if (tab === 'messages' && loc) body = messagesTab(qm, q);
    else if (tab === 'status' && loc) body = statusTab(qm, q);
    else if (tab === 'handles' && loc) body = handlesTab(qm, q);
    else if (tab === 'auth') body = MQ.authForObject(qm, q.name, 'QUEUE');
    else body = MQ.propsEditor({ obj: q, groups: MQ.QPROPS.filter(function (g) { return !g.types || g.types.indexOf(q.type) >= 0; }).map(function (g) { return { sec: g.sec, help: g.help, items: g.items.filter(function (it) { return !it[5] || it[5].indexOf(q.type) >= 0; }) }; }),
      get: qVal, editKey: 'editQ', editName: q.name, verb: 'ALTER ' + q.type + "('" + q.name + "')", readonly: q.type === 'QCLUSTER' || q.system && q.name.indexOf('SYSTEM.DEFAULT') !== 0 && false,
      validate: function (ch) {
        if (ch.defprty !== undefined && (ch.defprty < 0 || ch.defprty > 9)) return 'DEFPRTY 0 ile 9 (MAXPRTY) arasında olmalıdır.';
        if (ch.maxdepth !== undefined && (ch.maxdepth < 0 || ch.maxdepth > 999999999)) return 'MAXDEPTH 0 ile 999.999.999 arasında olmalıdır.';
        if (ch.maxmsgl !== undefined && (ch.maxmsgl < 0 || ch.maxmsgl > 104857600)) return 'MAXMSGL 0 ile 104.857.600 (100 MB) arasında olmalıdır.';
        if (ch.qdepthhi !== undefined && (ch.qdepthhi < 0 || ch.qdepthhi > 100)) return 'QDEPTHHI yüzde değeridir (0-100).';
        if (ch.usage === 'NORMAL' && q.usage === 'XMITQ' && qm.channels.some(function (c) { return c.xmitq === q.name && c.status === 'Running'; })) return 'AMQ8148E: IBM MQ object in use — bu kuyruk çalışan bir channel tarafından transmission queue olarak kullanılıyor.';
        return '';
      },
      warn: function (ch) {
        var w = [];
        if (ch.maxdepth !== undefined && ch.maxdepth < q.curdepth) w.push('Yeni MAXDEPTH mevcut derinlikten (' + q.curdepth + ') küçük: mevcut mesajlar korunur ancak yeni MQPUT çağrıları 2053 (Q_FULL) alır.');
        if (ch.boqname && !MQ.findQ(qm, ch.boqname)) w.push('BOQNAME olarak belirtilen ' + ch.boqname + ' kuyruğu bu queue manager\'da yok.');
        if (ch.initq && !MQ.findQ(qm, ch.initq)) w.push('INITQ olarak belirtilen kuyruk bulunamadı; tetikleme çalışmaz.');
        if (ch.maxmsgl && ch.maxmsgl > qm.attrs.MAXMSGL) w.push('Kuyruk MAXMSGL değeri queue manager MAXMSGL (' + qm.attrs.MAXMSGL + ') değerinden büyük; etkin sınır küçük olandır.');
        return w;
      },
      apply: function (ch) { Object.keys(ch).forEach(function (k) { setQVal(q, k, ch[k]); }); q.altered = MQ.now(); MQ.addEvent(qm, 'Config Change', 'Configuration', q.name, 'MQRC_CONFIG_CHANGE_OBJECT (2368)', 'Info', Object.keys(ch).map(function (k) { return k.toUpperCase(); }).join(', ') + ' değiştirildi.'); },
      success: 'AMQ8008I: IBM MQ queue changed.'
    });
    return head + '<div class="content">' + notes + body + '</div>';
  }
  MQ.route('/qm/:qm/queue/:q', qPage, 'manage');
  MQ.route('/qm/:qm/queue/:q/:tab', qPage, 'manage');

  function messagesTab(qm, q) {
    var msgs = MQ.ensureMsgs(qm, q);
    var info = '<div class="notice">' + I('info') + '<div class="grow">Mesajlar <b>browse</b> modunda görüntülenir (MQGET + MQGMO_BROWSE_NEXT): göz atmak mesajları kuyruktan silmez.' + H('browse') + (q.curdepth > msgs.length ? ' Kuyrukta ' + MQ.fmt(q.curdepth) + ' mesaj var; ilk ' + msgs.length + ' tanesi gösteriliyor.' : '') + (q.get === 'DISABLED' ? ' <b>GET inhibited olduğu için gerçek ortamda browse da engellenir (2016).</b>' : '') + '</div></div>';
    return info + MQ.table({
      id: 'msgs-' + qm.name + '-' + q.name, rows: function () { return MQ.ensureMsgs(qm, q); }, pageSize: 10, info: function (n) { return n + ' mesaj gösteriliyor (toplam derinlik: ' + MQ.fmt(q.curdepth) + ')'; },
      columns: [
        { key: 'puttime', label: 'Put zamanı', help: 'mqmd.puttime' },
        { key: 'msgid', label: 'Message ID', help: 'mqmd.msgid', render: function (m) { return '<a href="#" class="mono-sm" data-do="' + MQ.fn(function () { MQ.act.msgDetail(qm, q, m); }) + '">' + E(m.msgid.slice(0, 8) + '…' + m.msgid.slice(-12)) + '</a>'; } },
        { key: 'format', label: 'Format', help: 'mqmd.format' },
        { key: 'persist', label: 'Persistence', help: 'persistence' },
        { key: 'priority', label: 'Priority', num: true, help: 'priority' },
        { key: 'size', label: 'Boyut', num: true, render: function (m) { return MQ.bytes(m.size); } },
        { key: 'putappl', label: 'Put application', help: 'mqmd.putappl' },
        { key: 'body', label: 'Veri (önizleme)', render: function (m) { return '<span class="mono-sm">' + E(m.body.replace(/\s+/g, ' ').slice(0, 40)) + (m.body.length > 40 ? '…' : '') + '</span>'; } }
      ],
      create: { label: 'Put message', fn: function () { MQ.act.putMessage(qm, q); } },
      overflow: function (m) { return [{ label: 'Ayrıntılar (MQMD)', fn: function () { MQ.act.msgDetail(qm, q, m); } }, { label: 'Bu mesajı al (Get - destructive)', fn: function () { MQ.act.getMessage(qm, q, m); } }]; }
    });
  }
  function statusTab(qm, q) {
    var p = MQ.pct(q.curdepth, q.maxdepth);
    return '<div class="grid g4">' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + MQ.fmt(q.curdepth) + '</div><div class="lbl">Current depth' + H('curdepth') + '</div></div><div class="tile-body"><div class="meter ' + (p >= 100 ? 'err' : p >= q.qdepthhi ? 'warn' : '') + '"><i style="width:' + Math.max(p, 0.5) + '%"></i></div><div class="mono-sm mt16">%' + p + ' / MAXDEPTH ' + MQ.fmt(q.maxdepth) + '</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + q.ipprocs + '</div><div class="lbl">Open input count' + H('ipprocs') + '</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + q.opprocs + '</div><div class="lbl">Open output count' + H('opprocs') + '</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + MQ.fmt(q.uncom) + '</div><div class="lbl">Uncommitted' + H('uow') + '</div></div></div></div>' +
      '<div class="props-panel mt24"><div class="props-sec"><h2>Queue status (DISPLAY QSTATUS TYPE(QUEUE))' + H('qstatus') + '</h2>' +
      MQ.prop('Queue status', '', MQ.status(MQ.depthState(q) === 'full' ? 'Full' : q.get === 'DISABLED' && q.put === 'DISABLED' ? 'Disabled' : 'Active'), 'qstatus') +
      MQ.prop('Current depth', 'CURDEPTH', MQ.fmt(q.curdepth), 'curdepth') +
      MQ.prop('Open input count', 'IPPROCS', q.ipprocs, 'ipprocs') +
      MQ.prop('Open output count', 'OPPROCS', q.opprocs, 'opprocs') +
      MQ.prop('Last put', 'LPUTDATE/LPUTTIME', E(q.lput), 'lput') +
      MQ.prop('Last get', 'LGETDATE/LGETTIME', E(q.lget), 'lput') +
      MQ.prop('Oldest message age (sn)', 'MSGAGE', q.monq !== 'QMGR' || qm.attrs.MONQ !== 'OFF' ? MQ.fmt(q.msgage) : '<span class="dim">(MONQ kapalı)</span>', 'msgage') +
      MQ.prop('Queue time (µs) kısa, uzun', 'QTIME', q.qtime ? E(q.qtime) : '<span class="dim">-</span>', 'qtime') +
      MQ.prop('Uncommitted messages', 'UNCOM', q.uncom ? 'YES (' + q.uncom + ')' : 'NO', 'uow') +
      MQ.prop('Monitoring level', 'MONQ', E(q.monq === 'QMGR' ? 'QMGR → ' + qm.attrs.MONQ : q.monq), 'q.monq') +
      '</div></div>';
  }
  function handlesTab(qm, q) {
    var rows = qm.conns.filter(function (c) { return c.objects && c.objects.indexOf(q.name + ' (') >= 0; }).map(function (c) {
      var m = c.objects.match(new RegExp(q.name.replace(/\./g, '\\.') + ' \\((\\w+)\\)'));
      return { appltag: c.appltag, channel: c.channel || '(bindings)', conname: c.conname, userid: c.userid, pid: c.pid, mode: m ? m[1] : '?' };
    });
    return '<p style="margin-top:0">Bu kuyruğu şu anda açık tutan uygulama handle\'ları (DISPLAY QSTATUS(' + E(q.name) + ') TYPE(HANDLE)).' + H('handle') + '</p>' +
      MQ.table({ id: 'hdl-' + qm.name + q.name, search: false, rows: function () { return rows; }, empty: 'Bu kuyruğu açık tutan uygulama yok (IPPROCS=' + q.ipprocs + ', OPPROCS=' + q.opprocs + ').',
        columns: [{ key: 'appltag', label: 'Application', help: 'appltag' }, { key: 'mode', label: 'Açılış modu', help: 'ipprocs', render: function (r) { return r.mode === 'INPUT' ? MQ.tag('INPUT (get)', 'blue') : MQ.tag('OUTPUT (put)', 'teal'); } }, { key: 'channel', label: 'Channel' }, { key: 'conname', label: 'Connection name' }, { key: 'userid', label: 'User ID' }, { key: 'pid', label: 'PID', num: true }] });
  }

  /* --------- Ortak özellik düzenleyici (kuyruk / channel / QM) */
  MQ.propsEditor = function (o) {
    MQ.ui = MQ.ui || {};
    var editing = MQ.ui[o.editKey] === o.editName && !o.readonly;
    var formId = 'pe' + Math.floor(Math.random() * 1e6);
    var allItems = []; o.groups.forEach(function (g) { g.items.forEach(function (it) { allItems.push(it); }); });
    var side = '<nav class="sidenav">' + o.groups.map(function (g, i) { return '<button class="' + (i === 0 ? 'active' : '') + '" data-do="' + MQ.fn(function (el) { var t = document.getElementById(formId + '-s' + i); if (t) t.scrollIntoView({ behavior: 'smooth' }); var bs = el.parentNode.querySelectorAll('button'); for (var k = 0; k < bs.length; k++) bs[k].classList.toggle('active', bs[k] === el); }) + '">' + E(g.sec) + '</button>'; }).join('') + '</nav>';
    var secs = o.groups.map(function (g, gi) {
      return '<div class="props-sec" id="' + formId + '-s' + gi + '"><h2>' + E(g.sec) + H(g.help) + '</h2>' + g.items.map(function (it) {
        var v = o.get(o.obj, it[2]); var disp = v === '' || v === undefined || v === null ? '' : E(typeof v === 'number' ? MQ.fmt(v) : v);
        if (editing && it[4]) {
          var inp;
          if (Array.isArray(it[4])) inp = '<select class="in" data-pe="' + it[2] + '" data-orig="' + E(v) + '">' + it[4].map(function (op) { return '<option' + (String(op) === String(v) ? ' selected' : '') + '>' + E(op) + '</option>'; }).join('') + '</select>';
          else inp = '<input class="in" data-pe="' + it[2] + '" data-orig="' + E(v === undefined ? '' : v) + '" ' + (it[4] === 'num' ? 'type="number"' : '') + ' value="' + E(v === undefined ? '' : v) + '">';
          disp = inp;
        } else if (it[5] === 'html') disp = v;
        return MQ.prop(it[0], it[1], disp, it[3]);
      }).join('') + '</div>';
    }).join('');
    MQ.after(function () {
      var root = document.getElementById(formId); if (!root) return;
      var search = root.querySelector('[data-psearch]'), hide = root.querySelector('[data-phide]');
      function filter() {
        var qv = (search.value || '').toLowerCase(), he = hide.checked;
        var ps = root.querySelectorAll('.prop');
        for (var i = 0; i < ps.length; i++) { var t = ps[i].getAttribute('data-prop'); var empty = !!ps[i].querySelector('.v > .dim:only-child'); ps[i].style.display = (!qv || t.indexOf(qv) >= 0) && !(he && empty) ? '' : 'none'; }
      }
      search.addEventListener('input', filter); hide.addEventListener('change', filter);
      if (editing) {
        var prev = root.querySelector('[data-pe-preview]');
        var upd = function () { var c = changes(); prev.textContent = Object.keys(c).length ? o.verb + ' +\n  ' + Object.keys(c).map(function (k) { var it = allItems.filter(function (x) { return x[2] === k; })[0]; return MQ.mqscVal(it[1].split('/')[0], c[k], it[4]); }).join(' +\n  ') : '(henüz değişiklik yok)'; };
        root.addEventListener('input', upd); root.addEventListener('change', upd); upd();
      }
      function changes() {
        var c = {}, els = root.querySelectorAll('[data-pe]');
        for (var i = 0; i < els.length; i++) if (els[i].value !== els[i].getAttribute('data-orig')) { var it = allItems.filter(function (x) { return x[2] === els[i].getAttribute('data-pe'); })[0]; c[els[i].getAttribute('data-pe')] = it[4] === 'num' ? parseInt(els[i].value, 10) || 0 : els[i].value; }
        return c;
      }
      root._changes = changes;
    });
    var bar = o.readonly ? '' : editing ?
      '<div class="preview-h">Bu değişikliğin MQSC karşılığı' + H('alter') + '</div><pre class="preview-box" data-pe-preview></pre>' +
      '<div class="flex mt16" style="justify-content:flex-end"><button class="btn secondary" data-do="' + MQ.fn(function () { MQ.ui[o.editKey] = null; MQ.refresh(); }) + '">İptal</button><button class="btn" data-do="' + MQ.fn(function () {
        var root = document.getElementById(formId), c = root._changes();
        if (!Object.keys(c).length) { MQ.ui[o.editKey] = null; MQ.refresh(); return; }
        var err = o.validate ? o.validate(c) : ''; if (err) { MQ.toast('err', 'Değişiklik reddedildi', E(err)); return; }
        var w = o.warn ? o.warn(c) : [];
        o.apply(c); MQ.save(); MQ.ui[o.editKey] = null; MQ.refresh();
        MQ.toast('', 'Özellikler kaydedildi (simülasyon)', E(o.success || '') + (w.length ? '<br><b>Uyarı:</b> ' + w.map(E).join('<br>') : ''), root.querySelector('[data-pe-preview]').textContent);
      }) + '">Kaydet' + I('check') + '</button></div>'
      : '<div class="edit-float"><button class="btn secondary md" data-do="' + MQ.fn(function () { MQ.ui[o.editKey] = o.editName; MQ.refresh(); }) + '">Düzenle' + I('edit') + '</button></div>';
    return '<div class="content with-side" style="padding:0" id="' + formId + '">' + side + '<div>' +
      '<div class="props-search"><div class="search">' + I('search') + '<input data-psearch placeholder="Ne arıyorsunuz? (ad veya MQSC özniteliği, ör. MAXDEPTH)"></div><label class="toggle"><input type="checkbox" data-phide><span class="tr"></span>Boş özellikleri gizle</label></div>' +
      (editing ? '<div class="notice">' + I('edit') + '<div class="grow"><b>Düzenleme modu.</b> Değiştirdiğiniz alanlar aşağıda MQSC komutu olarak gösterilir. Kaydet gerçek bir queue manager\'ı değiştirmez; yalnızca simülasyon verisini günceller.</div></div>' : '') +
      '<div class="props-panel">' + secs + bar + (o.readonly ? '' : '') + '</div></div></div>';
  };

  /* ================================================== AUTHORITY (bir nesne için) */
  MQ.profileMatch = function (profile, name) {
    if (profile === name) return true;
    var re = '^' + profile.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '§').replace(/\*/g, '[^.]*').replace(/\?/g, '.').replace(/§/g, '.*') + '$';
    try { return new RegExp(re).test(name); } catch (e) { return false; }
  };
  MQ.authForObject = function (qm, name, objtype) {
    var rows = qm.authrec.filter(function (r) { return r.objtype === objtype && MQ.profileMatch(r.profile, name); });
    return '<p style="margin-top:0">Bu nesneye uygulanan OAM yetki kayıtları (generic profiller dahil). Bir kullanıcının etkin yetkisi, üye olduğu tüm grupların eşleşen profillerinin birleşimidir.' + H('oam') + '</p>' +
      MQ.table({ id: 'oa-' + qm.name + name, search: false, rows: function () { return rows; }, empty: 'Bu nesne için mqm dışındaki hiçbir gruba yetki verilmemiş.',
        columns: [{ key: 'profile', label: 'Profile', help: 'authprofile', render: function (r) { return '<span class="mono-sm">' + E(r.profile) + '</span>' + (r.profile !== name ? ' ' + MQ.tag('generic', 'gray') : ''); } }, { key: 'group', label: 'Group / Principal', help: 'oam', render: function (r) { return E(r.group || r.principal); } }, { key: 'auth', label: 'Yetkiler', help: 'authlist', render: function (r) { return r.auth.split(' ').map(function (a) { return MQ.tag(a, 'blue'); }).join(' '); } }, { key: 'note', label: 'Not', wrap: true }] }) +
      '<div class="flex mt16"><button class="btn sm" data-do="' + MQ.fn(function () { MQ.act.setAuthrec(qm, { profile: name, objtype: objtype }); }) + '">Yetki ekle (SET AUTHREC)' + I('add') + '</button></div>';
  };

  /* ================================================== CHANNEL DETAIL */
  var MSG = ['SDR', 'SVR', 'RCVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR'], SNDR = ['SDR', 'SVR', 'CLUSSDR', 'CLUSRCVR'], RCV = ['RCVR', 'RQSTR', 'CLUSRCVR'];
  MQ.CHPROPS = [
    { sec: 'General', help: 'channel', items: [
      ['Channel name', 'CHANNEL', 'name', 'chname', null],
      ['Channel type', 'CHLTYPE', 'chltype', 'chltype', null],
      ['Description', 'DESCR', 'descr', 'ch.descr', 'text'],
      ['Transport type', 'TRPTYPE', 'trptype', 'ch.trptype', ['TCP', 'LU62']],
      ['Connection name', 'CONNAME', 'conname', 'ch.conname', 'text', ['SDR', 'SVR', 'RQSTR', 'CLNTCONN', 'CLUSSDR', 'CLUSRCVR']],
      ['Transmission queue', 'XMITQ', 'xmitq', 'ch.xmitq', 'text', ['SDR', 'SVR']],
      ['Queue manager name', 'QMNAME', 'qmname', 'ch.qmname', 'text', ['CLNTCONN']],
      ['Maximum message length', 'MAXMSGL', 'maxmsgl', 'ch.maxmsgl', 'num']
    ] },
    { sec: 'Extended', items: [
      ['Heartbeat interval (sn)', 'HBINT', 'hbint', 'ch.hbint', 'num'],
      ['Keepalive interval', 'KAINT', 'kaint', 'ch.kaint', 'text'],
      ['Batch size', 'BATCHSZ', 'batchsz', 'ch.batchsz', 'num', MSG],
      ['Batch interval (ms)', 'BATCHINT', 'batchint', 'ch.batchint', 'num', SNDR],
      ['Batch heartbeat (ms)', 'BATCHHB', 'batchhb', 'ch.batchhb', 'num', SNDR],
      ['Disconnect interval (sn)', 'DISCINT', 'discint', 'ch.discint', 'num', ['SDR', 'SVR', 'SVRCONN', 'CLUSSDR', 'CLUSRCVR']],
      ['Non-persistent message speed', 'NPMSPEED', 'npmspeed', 'ch.npmspeed', ['FAST', 'NORMAL'], MSG],
      ['Sequence number wrap', 'SEQWRAP', 'seqwrap', 'ch.seqwrap', 'num', MSG],
      ['Data conversion', 'CONVERT', 'convert', 'ch.convert', YN, SNDR],
      ['Use dead-letter queue', 'USEDLQ', 'usedlq', 'ch.usedlq', YN, MSG],
      ['Sharing conversations', 'SHARECNV', 'sharecnv', 'ch.sharecnv', 'num', ['SVRCONN', 'CLNTCONN']],
      ['Maximum instances', 'MAXINST', 'maxinst', 'ch.maxinst', 'num', ['SVRCONN']],
      ['Maximum instances per client', 'MAXINSTC', 'maxinstc', 'ch.maxinstc', 'num', ['SVRCONN']],
      ['Default reconnect', 'DEFRECON', 'defrecon', 'ch.defrecon', ['NO', 'YES', 'QMGR', 'DISABLED'], ['CLNTCONN']],
      ['Message compression', 'COMPMSG', 'compmsg', 'ch.compmsg', ['NONE', 'RLE', 'ZLIBFAST', 'ZLIBHIGH', 'ANY']],
      ['Header compression', 'COMPHDR', 'comphdr', 'ch.compmsg', ['NONE', 'SYSTEM']]
    ] },
    { sec: 'Retry', help: 'chretry', items: [
      ['Short retry count', 'SHORTRTY', 'shortrty', 'ch.shortrty', 'num', SNDR],
      ['Short retry interval (sn)', 'SHORTTMR', 'shorttmr', 'ch.shortrty', 'num', SNDR],
      ['Long retry count', 'LONGRTY', 'longrty', 'ch.longrty', 'num', SNDR],
      ['Long retry interval (sn)', 'LONGTMR', 'longtmr', 'ch.longrty', 'num', SNDR],
      ['Message retry count', 'MRRTY', 'mrrty', 'ch.mrrty', 'num', RCV],
      ['Message retry interval (ms)', 'MRTMR', 'mrtmr', 'ch.mrtmr', 'num', RCV]
    ] },
    { sec: 'MCA', help: 'mca', items: [
      ['MCA user ID', 'MCAUSER', 'mcauser', 'ch.mcauser', 'text', ['SDR', 'SVR', 'RCVR', 'RQSTR', 'SVRCONN', 'CLUSSDR', 'CLUSRCVR']],
      ['MCA type', 'MCATYPE', 'mcatype', 'ch.mcatype', ['PROCESS', 'THREAD'], ['SDR', 'SVR', 'RQSTR', 'CLUSSDR', 'CLUSRCVR']]
    ] },
    { sec: 'SSL / TLS', help: 'tls', items: [
      ['SSL cipher specification', 'SSLCIPH', 'sslciph', 'ch.sslciph', 'text'],
      ['SSL client authentication', 'SSLCAUTH', 'sslcauth', 'ch.sslcauth', ['REQUIRED', 'OPTIONAL'], ['SVR', 'RCVR', 'RQSTR', 'SVRCONN', 'CLUSRCVR']],
      ['SSL peer name', 'SSLPEER', 'sslpeer', 'ch.sslpeer', 'text'],
      ['Certificate label', 'CERTLABL', 'certlabl', 'ch.certlabl', 'text']
    ] },
    { sec: 'Cluster', types: ['CLUSSDR', 'CLUSRCVR'], help: 'cluster', items: [
      ['Cluster', 'CLUSTER', 'cluster', 'q.cluster', 'text'],
      ['Cluster namelist', 'CLUSNL', 'clusnl', 'q.clusnl', 'text'],
      ['CLWL channel priority', 'CLWLPRTY', 'clwlprty', 'ch.clwlprty', 'num'],
      ['CLWL channel rank', 'CLWLRANK', 'clwlrank', 'ch.clwlprty', 'num'],
      ['CLWL channel weight', 'CLWLWGHT', 'clwlwght', 'ch.clwlwght', 'num'],
      ['Network priority', 'NETPRTY', 'netprty', 'ch.netprty', 'num', ['CLUSRCVR']]
    ] },
    { sec: 'Statistics & monitoring', help: 'chmonitor', items: [
      ['Channel monitoring', 'MONCHL', 'monchl', 'ch.monchl', ['QMGR', 'OFF', 'LOW', 'MEDIUM', 'HIGH'], ['SDR', 'SVR', 'RCVR', 'RQSTR', 'SVRCONN', 'CLUSSDR', 'CLUSRCVR']],
      ['Channel statistics', 'STATCHL', 'statchl', 'ch.statchl', ['QMGR', 'OFF', 'LOW', 'MEDIUM', 'HIGH'], MSG]
    ] },
    { sec: 'Zaman damgaları', items: [['Son değişiklik', 'ALTDATE/ALTTIME', 'altered', 'q.timestamps', null]] }
  ];
  var CH_NUM = { maxmsgl: 1, hbint: 1, batchsz: 1, batchint: 1, batchhb: 1, discint: 1, seqwrap: 1, sharecnv: 1, maxinst: 1, maxinstc: 1, shortrty: 1, shorttmr: 1, longrty: 1, longtmr: 1, mrrty: 1, mrtmr: 1, clwlprty: 1, clwlrank: 1, clwlwght: 1, netprty: 1 };

  function chPage(p) {
    var qm = MQ.qm(p.qm); if (!qm) throw new Error('Queue manager bulunamadı');
    if (!MQ.isUp(qm)) return MQ.qmHead(qm, 'network') + MQ.notRunning(qm);
    var c = MQ.findCh(qm, p.c);
    if (!c) return MQ.pageHead({ crumbs: [['Manage', '#/manage'], [qm.name, MQ.qmLink(qm.name)]], title: 'Channel bulunamadı' }) + '<div class="content"><div class="notice err">' + I('error') + '<div class="grow">AMQ8147E: IBM MQ object ' + E(p.c) + ' not found.</div></div></div>';
    var app = c.chltype === 'SVRCONN' || c.chltype === 'CLNTCONN';
    var tab = p.tab || 'properties', base = MQ.chLink(qm.name, c.name);
    var tabs = [['properties', 'Properties']];
    if (c.chltype !== 'CLNTCONN') tabs.push(['status', 'Status']);
    if (c.chltype === 'SVRCONN') tabs.push(['instances', 'Instances']);
    if (c.chltype !== 'CLNTCONN') tabs.push(['security', 'Channel authentication']);
    var head = MQ.pageHead({
      crumbs: [['Manage', '#/manage'], [qm.name, MQ.qmLink(qm.name)], app ? ['Applications', '#/qm/' + MQ.enc(qm.name) + '/applications/channels'] : ['MQ network', '#/qm/' + MQ.enc(qm.name) + '/network/channels']],
      title: c.name, icon: 'channel', help: MQ.chTypeHelp(c.chltype),
      right: MQ.ddButton('Actions', MQ.channelMenu(qm, c).slice(1)),
      tabs: tabs.map(function (t) { return { label: t[1], href: base + '/' + t[0], active: t[0] === tab }; }),
      tabsRight: MQ.tag(c.chltype, 'blue') + MQ.status(c.status) + H('chstatus')
    });
    var body, notes = '';
    if (c.status === 'Retrying') notes = '<div class="notice warn">' + I('warning') + '<div class="grow"><b>Channel RETRYING durumunda.</b> ' + E(c.st && c.st.retries || '') + '. Karşı tarafa (' + E(c.conname) + ') bağlantı kurulamıyor. Mesajlar ' + (c.xmitq ? '<a href="' + MQ.qLink(qm.name, c.xmitq) + '">' + E(c.xmitq) + '</a>' : 'transmission queue') + ' kuyruğunda bekliyor.' + H('chretry') + '</div></div>';
    if (c.status === 'Stopped') notes = '<div class="notice err">' + I('error') + '<div class="grow"><b>Channel STOPPED.</b> Bu durumda channel tetiklemeyle (trigger) ya da gelen bağlantıyla otomatik olarak başlamaz; START CHANNEL komutu gerekir.' + H('chstopped') + '</div><button class="btn sm" data-do="' + MQ.fn(function () { MQ.act.startChannel(qm, c); }) + '">Başlat' + I('play') + '</button></div>';
    if (!c.sslciph && c.chltype !== 'CLNTCONN') notes += '<div class="notice warn">' + I('lock') + '<div class="grow">Bu channel üzerinde <b>TLS yapılandırılmamış</b>; veriler ve parolalar ağda şifrelenmeden iletilir.' + H('tls') + '</div></div>';
    if (tab === 'status') body = chStatus(qm, c);
    else if (tab === 'instances') body = chInstances(qm, c);
    else if (tab === 'security') body = chSecurity(qm, c);
    else body = MQ.propsEditor({ obj: c, groups: MQ.CHPROPS.filter(function (g) { return !g.types || g.types.indexOf(c.chltype) >= 0; }).map(function (g) { return { sec: g.sec, help: g.help, items: g.items.filter(function (it) { return !it[5] || it[5].indexOf(c.chltype) >= 0; }) }; }).filter(function (g) { return g.items.length; }),
      get: function (o, f) { return o[f]; }, editKey: 'editCh', editName: c.name, verb: "ALTER CHANNEL('" + c.name + "') CHLTYPE(" + c.chltype + ')', readonly: !!c.auto,
      validate: function (ch) {
        if (ch.sslciph !== undefined && ch.sslciph && !MQ.CIPHERS.some(function (x) { return x.name === ch.sslciph; })) return 'AMQ8242E: SSLCIPH definition wrong — "' + ch.sslciph + '" geçerli bir CipherSpec değil.';
        if (ch.hbint !== undefined && (ch.hbint < 0 || ch.hbint > 999999)) return 'HBINT 0 - 999999 arasında olmalıdır.';
        if (ch.batchsz !== undefined && (ch.batchsz < 1 || ch.batchsz > 9999)) return 'BATCHSZ 1 - 9999 arasında olmalıdır.';
        if (ch.sharecnv !== undefined && (ch.sharecnv < 0 || ch.sharecnv > 999999999)) return 'SHARECNV geçersiz.';
        return '';
      },
      warn: function (ch) { var w = []; if (c.status === 'Running') w.push('Channel çalışırken yapılan değişiklikler channel yeniden başlatılana kadar etkin olmaz (STOP/START CHANNEL).'); if (ch.sslciph !== undefined || ch.certlabl !== undefined || ch.sslpeer !== undefined) w.push('TLS değişikliklerinden sonra çalışan kanallar için REFRESH SECURITY TYPE(SSL) gerekebilir.'); if (ch.mcauser !== undefined && /mqm|root|admin/i.test(ch.mcauser)) w.push('MCAUSER olarak yönetici bir kimlik kullanmak güvenlik riski oluşturur.'); return w; },
      apply: function (ch) { Object.keys(ch).forEach(function (k) { c[k] = CH_NUM[k] ? parseInt(ch[k], 10) || 0 : ch[k]; }); c.altered = MQ.now(); },
      success: 'AMQ8016I: IBM MQ channel changed.'
    });
    return head + '<div class="content">' + notes + body + '</div>';
  }
  MQ.route('/qm/:qm/channel/:c', chPage, 'manage');
  MQ.route('/qm/:qm/channel/:c/:tab', chPage, 'manage');

  function chStatus(qm, c) {
    var st = c.st || {};
    if (c.status === 'Inactive' || c.status === 'N/A') return '<div class="notice">' + I('info') + '<div class="grow"><b>Channel INACTIVE.</b> Bu channel için şu anda bir channel instance\'ı yok; DISPLAY CHSTATUS kayıt döndürmez (AMQ8420I: Channel Status not found).' + H('chinactive') + '</div></div>';
    if (c.chltype === 'SVRCONN') return chInstances(qm, c);
    return '<div class="props-panel"><div class="props-sec"><h2>DISPLAY CHSTATUS(' + E(c.name) + ') ALL' + H('chstatus') + '</h2>' +
      MQ.prop('Status', 'STATUS', MQ.status(c.status), 'chstatus') +
      MQ.prop('Substate', 'SUBSTATE', E(st.substate || ''), 'substate') +
      MQ.prop('Remote queue manager', 'RQMNAME', E(st.rqmname || ''), 'connectedqm') +
      MQ.prop('Connection name', 'CONNAME', E(st.conname || c.conname), 'ch.conname') +
      MQ.prop('Channel start', 'CHSTADA/CHSTATI', E(st.started || ''), 'chstatus') +
      MQ.prop('Messages', 'MSGS', MQ.fmt(st.msgs || 0), 'chmonitor') +
      MQ.prop('Batches', 'BATCHES', MQ.fmt(st.batches || 0), 'ch.batchsz') +
      MQ.prop('Bytes sent', 'BYTSSENT', MQ.bytes(st.bytessent || 0), 'chmonitor') +
      MQ.prop('Bytes received', 'BYTSRCVD', MQ.bytes(st.bytesrcvd || 0), 'chmonitor') +
      MQ.prop('Last message', 'LSTMSGDA/LSTMSGTI', E(st.lstmsg || ''), 'chmonitor') +
      MQ.prop('Current sequence number', 'CURSEQNO', st.curseqno ? MQ.fmt(st.curseqno) : '', 'ch.seqwrap') +
      MQ.prop('Transmission queue time (µs)', 'XQTIME', E(st.xqtime || ''), 'xqtime') +
      MQ.prop('Network time (µs)', 'NETTIME', E(st.nettime || ''), 'nettime') +
      MQ.prop('Retry bilgisi', 'SHORTRTS/LONGRTS', E(st.retries || ''), 'chretry') +
      MQ.prop('TLS peer', 'SSLPEER', E(st.sslpeer || c.sslpeer), 'ch.sslpeer') +
      MQ.prop('Negotiated CipherSpec', 'SSLCIPH', E(c.sslciph), 'ch.sslciph') +
      '</div></div>';
  }
  function chInstances(qm, c) {
    if (!c.inst || !c.inst.length) return '<div class="notice">' + I('info') + '<div class="grow">Bu SVRCONN channel için çalışan instance yok.' + H('chinstance') + '</div></div>';
    var tot = c.inst.length, conv = c.inst.reduce(function (a, i) { return a + i.curshcnv; }, 0);
    return '<div class="grid g3 mb24"><div class="tile"><div class="mini-stat"><div class="num">' + tot + ' <span class="muted" style="font-size:20px">/ ' + MQ.fmt(c.maxinst) + '</span></div><div class="lbl">Instance / MAXINST' + H('ch.maxinst') + '</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + conv + '</div><div class="lbl">Toplam conversation' + H('ch.sharecnv') + '</div></div></div>' +
      '<div class="tile"><div class="mini-stat"><div class="num">' + Object.keys(c.inst.reduce(function (m, i) { m[i.conname] = 1; return m; }, {})).length + '</div><div class="lbl">Farklı istemci adresi' + H('ch.maxinstc') + '</div></div></div></div>' +
      MQ.table({ id: 'inst-' + qm.name + c.name, rows: function () { return c.inst; },
        columns: [{ key: 'conname', label: 'Connection name', help: 'ch.conname' }, { key: 'appltag', label: 'Application', help: 'appltag' }, { key: 'mcauser', label: 'MCA user', help: 'ch.mcauser' }, { key: 'msgs', label: 'Messages', num: true }, { key: 'curshcnv', label: 'Conversations', num: true, help: 'ch.sharecnv' }, { key: 'lstmsg', label: 'Last message' }, { key: 'sslciph', label: 'CipherSpec', help: 'ch.sslciph' }, { key: 'clientVer', label: 'İstemci sürümü', help: 'clientver' }],
        overflow: function (i) { return [{ label: 'Bu instance\'ı durdur (STOP CHANNEL CONNAME)', danger: true, fn: function () { c.inst.splice(c.inst.indexOf(i), 1); MQ.save(); MQ.refresh(); MQ.toast('', 'Instance durduruldu (simülasyon)', 'İstemci yeniden bağlanabilir (STATUS(INACTIVE) ile durduruldu).', "STOP CHANNEL('" + c.name + "') CONNAME('" + i.conname + "') MODE(QUIESCE)"); } }]; } });
  }
  function chSecurity(qm, c) {
    var rules = qm.chlauth.filter(function (r) { return MQ.profileMatch(r.profile, c.name); });
    return '<p style="margin-top:0">Bu channel\'a (' + E(c.name) + ') uygulanan channel authentication (CHLAUTH) kuralları. QM düzeyinde CHLAUTH(' + E(qm.attrs.CHLAUTH) + ').' + H('chlauth') + '</p>' +
      MQ.chlauthTable(qm, 'chsec-' + qm.name + c.name, function () { return rules; }) +
      '<div class="props-panel mt24"><div class="props-sec"><h2>Bu channel\'ın güvenlik özellikleri</h2>' +
      MQ.prop('MCA user ID', 'MCAUSER', E(c.mcauser), 'ch.mcauser') + MQ.prop('SSL cipher spec', 'SSLCIPH', E(c.sslciph), 'ch.sslciph') + MQ.prop('SSL client auth', 'SSLCAUTH', E(c.sslcauth), 'ch.sslcauth') + MQ.prop('SSL peer', 'SSLPEER', E(c.sslpeer), 'ch.sslpeer') + MQ.prop('Certificate label', 'CERTLABL', E(c.certlabl || '(QM CERTLABL: ' + qm.attrs.CERTLABL + ')'), 'ch.certlabl') + '</div></div>';
  }
})();
