/* Türkçe açıklamalar — Temel kavramlar, Queue Manager, Mesaj, İzleme, Cluster, Konsol.
   Alanlar: t=başlık c=kategori m=MQSC adı w=ne işe yarar r=MQ içindeki görevi p=amaç n=ne zaman b=fayda e=örnek x=risk v=sürüm notu l=ilgili */
(function () {
  var MQ = window.MQ, h = function (k, o) { MQ.HELP[k] = o; };

  /* ============================== TEMEL KAVRAMLAR ============================== */
  h('qmgr', { t: 'Queue Manager', c: 'Temel kavramlar', m: 'QMGR',
    w: 'Queue manager (QM), IBM MQ altyapısının çekirdek sunucu bileşenidir. Kuyrukları, kanalları, topic\'leri ve diğer tüm MQ nesnelerini barındırır ve uygulamalara mesajlaşma hizmeti (MQI / JMS API) sunar.',
    r: 'Mesajların güvenli şekilde saklanmasını (kuyruk dosyaları + recovery log), transaction (unit of work) yönetimini, diğer queue manager\'lara iletimi (channel), yetkilendirmeyi (OAM) ve olay/istatistik üretimini yönetir. Uygulamalar her zaman bir queue manager\'a bağlanır (MQCONN/MQCONNX).',
    p: 'Uygulamalar arasında asenkron, güvenilir ve "tam olarak bir kez" (assured once-and-once-only) teslim garantili mesajlaşma sağlamak.',
    n: 'Her MQ kurulumunda en az bir queue manager gerekir. Ortamlar (test/üretim), iş alanları veya güvenlik bölgeleri ayrıştırılmak istendiğinde birden fazla QM kullanılır.',
    b: 'Uygulamaları birbirinden zamansal ve teknik olarak ayırır (loose coupling); karşı uygulama kapalı olsa bile mesajlar kaybolmaz.',
    e: 'crtmqm -u SYSTEM.DEAD.LETTER.QUEUE -lc QMGW01\nstrmqm QMGW01\nrunmqsc QMGW01\n  DISPLAY QMGR\ndspmq -o all',
    x: 'Yetersiz log alanı, DLQ tanımlanmaması veya varsayılan güvenlik kurallarının (CHLAUTH, CONNAUTH) kapatılması; mesaj kaybına, kanalların durmasına veya yetkisiz erişime yol açabilir.',
    v: 'Bu simülasyon IBM MQ 9.4 LTS (komut seviyesi 940) davranışını temel alır. 9.3 LTS = 930 komut seviyesidir.', l: ['qmstatus', 'qlocal', 'channel', 'listener', 'logtype'] });
  h('qmname', { t: 'Queue manager adı', c: 'Queue Manager', m: 'QMNAME',
    w: 'Queue manager\'ın benzersiz adıdır. Uygulamalar bağlanırken ve diğer QM\'ler mesaj yönlendirirken bu adı kullanır.',
    r: 'Mesaj yönlendirmede hedef adres (RQMNAME, ReplyToQMgr) olarak kullanılır; MsgId\'nin ilk baytlarına da gömülür.',
    p: 'Ağdaki her QM\'i tekil olarak tanımlamak.', n: 'Queue manager oluşturulurken bir kez verilir; sonradan değiştirilemez.',
    b: 'Anlamlı adlandırma (ör. QMGW01, QMCORE01) operasyon ve izlemeyi kolaylaştırır.',
    e: 'En fazla 48 karakter; A-Z a-z 0-9 . / _ % kullanılabilir.\ncrtmqm QMODEME01',
    x: 'Aynı ağda veya cluster\'da aynı adlı iki QM olması mesajların yanlış yere gitmesine ve cluster repository karışıklığına neden olur. Ad değiştirmek için QM\'i yeniden oluşturmak gerekir.', l: ['qmgr', 'defaultqm'] });
  h('qmstatus', { t: 'Queue manager durumu', c: 'Queue Manager',
    w: 'Queue manager\'ın o anki çalışma durumunu gösterir (dspmq çıktısındaki STATUS).',
    r: 'Running: çalışıyor. Ended normally: endmqm ile kontrollü durduruldu. Ended immediately: endmqm -i ile hemen durduruldu. Ended preemptively: endmqm -p ile zorla durduruldu. Ended unexpectedly: beklenmedik şekilde sonlandı (crash). Running as standby / Running elsewhere: multi-instance QM\'in yedek instance\'ı bu sunucuda / aktif instance başka sunucuda. Starting, Quiescing: geçiş durumları.',
    p: 'Operasyon ekiplerinin QM\'in erişilebilir olup olmadığını hızlıca anlaması.',
    n: 'Bakım öncesi/sonrası ve olay (incident) analizinde ilk kontrol edilen bilgidir.',
    b: 'Uygulama hatalarının (2059 MQRC_Q_MGR_NOT_AVAILABLE) kaynağını hızlıca tespit etmeyi sağlar.',
    e: 'dspmq -m QMGW01 -o status\nQMNAME(QMGW01)    STATUS(Running)',
    x: '"Ended unexpectedly" görüyorsanız /var/mqm/errors altındaki FDC dosyalarını inceleyin; QM\'i tekrar tekrar başlatmak sorunu gizleyebilir.', l: ['endmqm', 'multiinstance', 'fdc'] });
  h('crtmqm', { t: 'Queue manager oluşturma (crtmqm)', c: 'Queue Manager', m: 'crtmqm',
    w: 'Yeni bir queue manager\'ı veri ve log dizinleriyle birlikte oluşturan komut satırı aracıdır.',
    r: 'QM dizin yapısını, varsayılan ve sistem nesnelerini (SYSTEM.*), recovery log dosyalarını ve qm.ini konfigürasyonunu üretir.',
    p: 'Yeni bir mesajlaşma sunucusu kurmak.',
    n: 'Yeni ortam/uygulama alanı kurulurken. Oluşturma sırasında seçilen log tipi (circular/linear) ve log dosya boyutu sonradan kolayca değiştirilemez; baştan doğru planlanmalıdır.',
    b: 'Tek komutla standart, güvenlik varsayılanları açık bir QM elde edilir (CHLAUTH ve CONNAUTH varsayılan olarak etkin).',
    e: 'crtmqm -c "Odeme QM" -u SYSTEM.DEAD.LETTER.QUEUE -lc -lp 10 -ls 5 -lf 16384 -p 1414 QMODEME01\nstrmqm QMODEME01',
    x: '-u verilmezse QM\'in dead-letter queue\'su olmaz; teslim edilemeyen mesajlarda kanallar durur. Küçük log (-lf, -lp) seçimi büyük transaction\'larda MQRC_RESOURCE_PROBLEM (2102) / log full hatalarına yol açar.',
    v: '-p (listener portu) ve -ic/-ii (otomatik MQSC/INI konfigürasyonu) seçenekleri güncel 9.x sürümlerinde mevcuttur; eski sürümlerde listener ayrıca tanımlanmalıdır.', l: ['logtype', 'log.files', 'dlq', 'listener'] });
  h('endmqm', { t: 'Queue manager durdurma (endmqm)', c: 'Queue Manager', m: 'endmqm',
    w: 'Çalışan bir queue manager\'ı durdurur.',
    r: 'Varsayılan (controlled/quiesce) mod, bağlı uygulamaların işini bitirmesini bekler; -w aynı şeyi yapar ama komut QM durana kadar döner; -i (immediate) uygulamaları bekletmeden durdurur ve tamamlanmamış işleri geri alır; -p (preemptive) son çare olarak süreçleri zorla sonlandırır.',
    p: 'Bakım, yama (fix pack) veya yapılandırma değişikliği için QM\'i güvenli şekilde kapatmak.',
    n: 'Planlı bakımlarda önce varsayılan veya -i kullanılır. -p yalnızca QM yanıt vermiyorsa kullanılmalıdır.',
    b: 'Kontrollü kapatma veri bütünlüğünü korur ve yeniden başlatmada recovery süresini kısaltır.',
    e: 'endmqm QMGW01        # controlled\nendmqm -i QMGW01     # immediate\nendmqm -s QMMI01     # multi-instance: standby\'a devret',
    x: '-p ile zorla durdurma sonraki başlatmada uzun recovery gerektirebilir. Uygulamalara MQRC_Q_MGR_QUIESCING (2161) / CONNECTION_BROKEN (2009) dönecektir; yeniden bağlanma (reconnect) mantığı yoksa uygulamalar çöker.', l: ['qmstatus', 'multiinstance'] });
  h('dltmqm', { t: 'Queue manager silme (dltmqm)', c: 'Queue Manager', m: 'dltmqm',
    w: 'Durdurulmuş bir queue manager\'ı tüm nesneleri, mesajları ve log dosyalarıyla kalıcı olarak siler.', r: 'QM\'in veri/log dizinlerini ve mqs.ini kaydını kaldırır.',
    p: 'Artık kullanılmayan test/geçici QM\'leri temizlemek.', n: 'QM\'in hiçbir uygulama/cluster tarafından kullanılmadığından emin olunduktan sonra.',
    b: 'Disk alanı ve yönetim yükünü azaltır.', e: 'endmqm -i QMTEST01\ndltmqm QMTEST01',
    x: 'Geri alınamaz! Cluster üyesi bir QM silinmeden önce cluster\'dan düzgün çıkarılmalıdır (SUSPEND QMGR, RESET CLUSTER); aksi halde diğer üyeler var olmayan QM\'e mesaj göndermeye çalışır.', l: ['cluster'] });
  h('defaultqm', { t: 'Default queue manager', c: 'Queue Manager',
    w: 'Uygulama MQCONN çağrısında QM adı vermediğinde (boş ad) bağlanılan queue manager\'dır.', r: 'mqs.ini dosyasındaki DefaultQueueManager stanzasında tutulur; sunucu başına bir tane olabilir.',
    p: 'Komut ve örnek programların QM adı belirtmeden çalışabilmesi.', n: 'Sunucuda tek bir QM varsa veya geliştirme ortamlarında pratiklik için.',
    b: 'runmqsc, amqsput gibi araçların ad verilmeden kullanılabilmesi.', e: 'crtmqm -q QMGW01   # varsayılan yap\nrunmqsc            # QMGW01\'e bağlanır',
    x: 'Üretimde uygulamaların varsayılan QM\'e güvenmesi, QM taşındığında/yeniden adlandırıldığında hatalı bağlantılara yol açar. Uygulamalarda QM adını açıkça belirtin.', l: ['qmname'] });
  h('platform', { t: 'Platform', c: 'Queue Manager', m: 'PLATFORM',
    w: 'Queue manager\'ın çalıştığı işletim sistemi ailesini gösterir: UNIX (Linux/AIX), WINDOWSNT, MVS (z/OS), IBMI vb.',
    r: 'Bazı özellikler platforma bağlıdır: örn. Storage Class, Shared Queue, CF yalnızca z/OS\'ta; Native HA yalnızca Linux\'ta; dizin yolları ve servis yönetimi platforma göre değişir.',
    p: 'Yönetim araçlarının platforma özgü seçenekleri doğru sunması.', n: 'Mimari kararlar ve dokümantasyon okunurken.',
    b: 'Platforma özgü özelliklerin karıştırılmasını önler.', e: 'DISPLAY QMGR PLATFORM\nPLATFORM(UNIX)',
    x: 'z/OS\'a özgü özellikleri (STGCLASS, QSGDISP, CFSTRUCT) dağıtık platformlarda kullanmaya çalışmak sözdizimi hatası verir.', l: ['stgclass', 'ha'] });
  h('mqversion', { t: 'IBM MQ sürümü', c: 'Queue Manager', m: 'VERSION / CMDLEVEL',
    w: 'Kurulu IBM MQ ürün sürümüdür. V.R.M.F (Version.Release.Modification.Fix) biçimindedir; örn. 9.4.0.26.',
    r: 'LTS (Long Term Support, ör. 9.3.0.x, 9.4.0.x) sürümleri yalnızca düzeltme alır; CD (Continuous Delivery, ör. 9.4.1, 9.4.2) sürümleri yeni özellik getirir. Komut seviyesi (CMDLEVEL) hangi MQSC özelliklerinin kullanılabileceğini belirler (940 = 9.4).',
    p: 'Uyumluluk, destek süresi ve özellik kullanılabilirliğini değerlendirmek.',
    n: 'Yeni özellik kullanmadan önce (ör. ANY_TLS13 CipherSpec, streaming queue) QM sürümünü doğrulayın.',
    b: 'Doğru sürüm yönetimi güvenlik yamalarının zamanında uygulanmasını sağlar.', e: 'dspmqver\nDISPLAY QMGR VERSION CMDLEVEL\nVERSION(09040026)   CMDLEVEL(940)',
    x: 'Farklı sürümlerdeki QM\'ler birlikte çalışabilir ancak yeni özellikler eski taraf desteklemiyorsa kullanılamaz. Desteği biten sürümler güvenlik yaması almaz. CD sürümlerinden LTS\'e geri dönülemez.',
    v: '9.4.0 LTS Haziran 2024\'te yayımlandı; 9.3.0 LTS 2022\'de. Bu simülasyonda QMBATCH01 bilerek 9.3 (CMDLEVEL 930) çalışır.', l: ['qm.cmdlevel'] });
  h('installation', { t: 'Installation', c: 'Queue Manager',
    w: 'Aynı sunucuda birden fazla MQ sürümü kurulabilir (multi-installation). Her kurulumun bir adı (Installation1, Installation2…) ve kurulum yolu vardır.',
    r: 'Her queue manager bir installation\'a bağlıdır; QM\'i yeni sürüme geçirmek için setmqm komutu kullanılır.',
    p: 'Sürüm geçişlerini QM bazında kademeli yapabilmek.', n: 'Yükseltmelerde (ör. 9.3 → 9.4) yan yana kurulum ile riski azaltmak istendiğinde.',
    b: 'Tüm QM\'leri aynı anda yükseltme zorunluluğunu ortadan kaldırır.', e: 'dspmqinst\nsetmqenv -n Installation1\nsetmqm -m QMBATCH01 -n Installation1',
    x: 'Yanlış ortam değişkenleriyle (setmqenv) komut çalıştırmak, QM\'e farklı sürüm komutlarıyla erişmeye ve AMQ5691E gibi hatalara yol açar.', l: ['mqversion'] });
  h('datapath', { t: 'Veri dizini', c: 'Queue Manager',
    w: 'Queue manager\'ın kuyruk dosyaları, nesne tanımları, qm.ini ve hata loglarının bulunduğu dizindir.',
    r: 'Linux\'ta varsayılan /var/mqm/qmgrs/<QM>, Windows\'ta C:\\ProgramData\\IBM\\MQ\\qmgrs\\<QM>. Multi-instance QM\'lerde paylaşımlı (NFS v4) depolamada bulunur.',
    p: 'Kalıcı mesajların ve konfigürasyonun saklanması.', n: 'Disk kapasitesi planlaması, yedekleme ve HA tasarımında.',
    b: 'Doğru disk seçimi (hızlı, ayrı dosya sistemi) performansı doğrudan etkiler.', e: '/var/mqm/qmgrs/QMGW01/queues/APP!ODEME!ISTEK/q',
    x: 'Dosya sisteminin dolması kuyrukların yazılamamasına (MQRC_RESOURCE_PROBLEM 2102) ve QM\'in durmasına yol açar. Dosyaları elle değiştirmek QM\'i bozabilir.', l: ['log.path', 'q.maxfsize'] });
  h('ha', { t: 'Yüksek erişilebilirlik (HA)', c: 'Queue Manager',
    w: 'Queue manager\'ın donanım/sunucu arızasında hizmet vermeye devam etmesini sağlayan yapılandırmalardır.',
    r: 'Seçenekler: Multi-instance QM (paylaşımlı NFS depolama, aktif/yedek), Native HA (Linux/container, 3 replika, kendi log replikasyonu), RDQM (Linux, DRBD+Pacemaker), işletim sistemi cluster\'ları (HACMP, MSCS) ve z/OS Queue Sharing Group.',
    p: 'Planlı/plansız kesinti süresini en aza indirmek ve kalıcı mesajları korumak.',
    n: 'Kritik iş akışlarında (ödeme, sipariş) tek sunucu arızasının kabul edilemez olduğu durumlarda.',
    b: 'Otomatik devralma ile kesinti dakikalardan saniyelere iner. Uniform Cluster ile birlikte uygulama yükü de dengelenir.',
    e: 'crtmqm -md /MQHA/qmgrs -ld /MQHA/log QMDR01\nstrmqm -x QMDR01     # her iki sunucuda',
    x: 'HA, mesajların kopyasını tutar; yanlış yapılandırılmış paylaşımlı depolama (NFS kilitleme) veri bozulmasına yol açabilir. HA, felaket kurtarmanın (DR) yerini tutmaz.',
    v: 'Native HA, 9.2.x CD ile container\'lar için geldi; 9.4 ile Linux üzerinde ve bölgeler arası (cross-region) replikasyon seçenekleri genişledi. Multi-instance tüm dağıtık platformlarda vardır.', l: ['multiinstance'] });
  h('multiinstance', { t: 'Multi-instance queue manager', c: 'Queue Manager',
    w: 'Aynı QM\'in iki sunucuda tanımlandığı, birinin aktif diğerinin yedek (standby) çalıştığı HA modelidir.',
    r: 'QM verisi ve logları paylaşımlı ağ depolamasında (NFS v4, GPFS) tutulur. Aktif instance dosya kilidini kaybederse yedek instance kilidi alıp devralır.',
    p: 'Sunucu arızasında aynı QM\'in başka sunucuda otomatik başlaması.', n: 'Paylaşımlı depolama mevcutsa ve RDQM/Native HA kullanılamıyorsa.',
    b: 'Ek yazılım gerektirmeyen yerleşik HA.', e: 'strmqm -x QMDR01\ndspmq -x -m QMDR01\n  INSTANCE(mqdr01-a) MODE(Active)\n  INSTANCE(mqdr01-b) MODE(Standby)',
    x: 'Devralmada IP değişir; istemcilerin her iki adresi de bilmesi gerekir (CONNAME listesi veya CCDT). NFS kilit davranışı doğrulanmazsa iki instance aynı anda aktif olmaya çalışabilir.', l: ['ha', 'ccdt'] });
  h('logtype', { t: 'Recovery log tipi', c: 'Queue Manager', m: 'LogType',
    w: 'Queue manager\'ın kalıcı (persistent) mesajları ve transaction\'ları kurtarabilmek için kullandığı günlük (log) yöntemidir: CIRCULAR veya LINEAR.',
    r: 'Circular: log dosyaları döngüsel olarak yeniden kullanılır; yalnızca yeniden başlatma (restart) recovery sağlar. Linear: log dosyaları ardışık oluşturulur; ayrıca hasar gören kuyrukların log\'dan geri yüklenmesine (media recovery) olanak tanır.',
    p: 'Sistem çöktüğünde kalıcı mesajların ve tamamlanmış transaction\'ların kaybolmamasını garanti etmek.',
    n: 'Circular: çoğu kurulum için yeterli, yönetimi kolay. Linear: media recovery gereken, arşivleme süreçleri olan kritik ortamlarda.',
    b: 'Kalıcı mesajların sunucu çökse bile korunmasını sağlar.',
    e: 'crtmqm -lc QMGW01     # circular\ncrtmqm -ll QMCORE01   # linear\nrcdmqimg -m QMCORE01 -t all *   # linear: media image kaydet',
    x: 'Linear log\'larda eski dosyalar arşivlenip silinmezse disk dolar ve QM durur. Circular log çok küçükse uzun süren transaction\'lar log\'u doldurur (AMQ7469, 2102).',
    v: '9.0.2+ ile linear log için otomatik media image (IMGSCHED AUTO) ve log yönetimi (LogManagement=Automatic/Archive) eklendi.', l: ['log.files', 'log.path', 'qm.imgsched', 'persistence'] });
  h('log.files', { t: 'Log dosya sayısı ve boyutu', c: 'Queue Manager', m: 'LogPrimaryFiles / LogSecondaryFiles / LogFilePages',
    w: 'Primary dosyalar QM başlarken ayrılır; secondary dosyalar primary\'ler dolduğunda geçici olarak eklenir. LogFilePages her dosyanın 4 KB sayfa cinsinden boyutudur.',
    r: 'Aktif log alanı ≈ (primary + secondary) × LogFilePages × 4 KB. Bu alan, tamamlanmamış en uzun transaction\'ı ve henüz checkpoint edilmemiş kalıcı verileri barındırmalıdır.',
    p: 'Log kapasitesini iş yüküne göre boyutlandırmak.', n: 'QM oluşturulurken (LogFilePages sonradan değiştirilemez); primary/secondary qm.ini\'den değiştirilebilir.',
    b: 'Doğru boyut log-full hatalarını ve performans düşüşünü önler.', e: 'qm.ini:\nLog:\n   LogPrimaryFiles=10\n   LogSecondaryFiles=5\n   LogFilePages=16384\n   LogType=CIRCULAR',
    x: 'Uzun süren açık bir transaction (unit of work) log\'u kilitleyebilir; MQ bu durumda en eski transaction\'ı geri alır (AMQ7469W). Primary+secondary en fazla 511 olabilir (Windows/Unix).', l: ['logtype', 'uow'] });
  h('log.path', { t: 'Log dizini ve yazma bütünlüğü', c: 'Queue Manager', m: 'LogPath / LogWriteIntegrity',
    w: 'LogPath recovery log dosyalarının dizinidir. LogWriteIntegrity, log sayfalarının diske yazılma yöntemini belirler (SingleWrite, DoubleWrite, TripleWrite).',
    r: 'Log yazımı her kalıcı mesaj ve commit için senkron yapılır; bu nedenle log diskinin gecikmesi MQ performansını doğrudan belirler.',
    p: 'Veri bütünlüğü ve performans dengesini kurmak.', n: 'Disk tasarımında log\'u kuyruk verisinden ayrı, düşük gecikmeli bir diske koymak önerilir.',
    b: 'Ayrı ve hızlı log diski kalıcı mesaj hacmini ciddi şekilde artırır.', e: '/var/mqm/log/QMGW01/active/S0000041.LOG',
    x: 'TripleWrite varsayılandır ve en güvenlisidir; SingleWrite yalnızca diskin atomik yazmayı garanti ettiği durumlarda seçilmelidir, aksi halde güç kesintisinde log bozulabilir.', l: ['logtype'] });
  h('errorlog', { t: 'Hata log\'ları (AMQERR01.LOG)', c: 'Queue Manager',
    w: 'Queue manager\'ın bilgi, uyarı ve hata mesajlarını yazdığı metin dosyalarıdır.',
    r: 'QM\'e özgü loglar <veri dizini>/errors altında AMQERR01-03.LOG; QM\'den bağımsız loglar /var/mqm/errors altında bulunur. 9.x ile JSON formatlı loglar (AMQERR01.json) da üretilebilir.',
    p: 'Sorun teşhisi: kanal hataları, yetki reddi, log doluluğu, sertifika sorunları.',
    n: 'Her türlü MQ sorununda ilk bakılacak yer.', b: 'Hata kodu (AMQnnnn) ve EXPLANATION/ACTION bölümleri sorunun nedenini ve çözümünü verir.',
    e: 'tail -f /var/mqm/qmgrs/QMGW01/errors/AMQERR01.LOG\nAMQ9202E: Remote host ... not available, retry later.',
    x: 'Log dosyaları döngüseldir (01→02→03); sorun anında kopyalanmazsa kanıt kaybolabilir. Log boyutu qm.ini ErrorLogSize ile ayarlanır.', l: ['amqcode', 'fdc'] });
  h('amqcode', { t: 'AMQ mesaj kodları', c: 'Queue Manager',
    w: 'IBM MQ\'nun tanılama mesajları AMQnnnnX biçimindedir. Son harf önem derecesini gösterir: I = bilgi, W = uyarı, E = hata, S = ciddi.',
    r: 'Örn. AMQ9202E (uzak host erişilemez), AMQ9777E (CHLAUTH engeli), AMQ5534E (kimlik doğrulama hatası), AMQ9631E (CipherSpec uyuşmazlığı), AMQ8003I (QM başlatıldı).',
    p: 'Sorunları standart kodlarla tanımlamak ve dokümantasyonda aramak.', n: 'Hata log\'u veya runmqsc çıktısı incelenirken.',
    b: 'Kod ile IBM dokümantasyonunda kesin açıklama ve çözüm adımlarına ulaşılır.', e: 'mqrc AMQ9202\nmqrc 2035   # reason code açıklaması',
    x: 'Yalnızca ilk satıra bakmak yanıltıcı olabilir; ardışık mesajlar (ör. AMQ5534E + AMQ5542I) birlikte okunmalıdır.', l: ['errorlog', 'reasoncode'] });
  h('reasoncode', { t: 'Reason code (MQRC)', c: 'Temel kavramlar',
    w: 'MQI çağrılarının (MQCONN, MQOPEN, MQPUT, MQGET…) başarısız olduğunda döndürdüğü sayısal hata nedenidir.',
    r: 'Sık görülenler: 2009 CONNECTION_BROKEN, 2033 NO_MSG_AVAILABLE, 2035 NOT_AUTHORIZED, 2051 PUT_INHIBITED, 2053 Q_FULL, 2058 Q_MGR_NAME_ERROR, 2059 Q_MGR_NOT_AVAILABLE, 2085 UNKNOWN_OBJECT_NAME, 2087 UNKNOWN_REMOTE_Q_MGR, 2030 MSG_TOO_BIG_FOR_Q, 2538 HOST_NOT_AVAILABLE.',
    p: 'Uygulamanın hatayı programatik olarak ele alabilmesi.', n: 'Uygulama loglarında MQ hatası görüldüğünde.',
    b: 'Doğru reason code ile kök neden hızla bulunur.', e: '/opt/mqm/bin/mqrc 2053\n      2053  0x00000805  MQRC_Q_FULL',
    x: '2033 (mesaj yok) gerçek bir hata değildir; uygulama bunu normal akış olarak ele almalıdır. 2035 için CHLAUTH ve OAM birlikte incelenmelidir.', l: ['amqcode', 'dlq'] });
  h('fdc', { t: 'FDC (First Failure Data Capture)', c: 'Queue Manager',
    w: 'MQ\'nun beklenmeyen dahili hatalarda ürettiği ayrıntılı tanı dosyalarıdır (AMQnnnnn.n.FDC).',
    r: 'Hata anındaki süreç, çağrı yığını (stack), probe ID ve ortam bilgilerini içerir.', p: 'IBM desteğine sorunun teknik ayrıntılarını iletmek.',
    n: 'QM beklenmedik şekilde sonlandığında veya hata log\'u FDC üretildiğini söylediğinde.', b: 'Destek sürecini hızlandırır.',
    e: 'ls -lt /var/mqm/errors/*.FDC\nffstsummary', x: 'FDC dosyaları zamanla diski doldurabilir; düzenli arşivlenmelidir. Tekrarlayan FDC\'ler yama gerektiren bir hataya işaret edebilir.', l: ['errorlog'] });

  /* ============================== MESAJ ============================== */
  h('persistence', { t: 'Message Persistence (kalıcılık)', c: 'Mesaj', m: 'MQMD.Persistence / DEFPSIST',
    w: 'Mesajın queue manager yeniden başlatıldığında veya çöktüğünde korunup korunmayacağını belirler: Persistent (kalıcı) veya Not persistent (kalıcı olmayan).',
    r: 'Kalıcı mesajlar recovery log\'a yazılır ve yeniden başlatmada geri yüklenir. Kalıcı olmayan mesajlar bellekte tutulur (kuyruk dosyasına taşabilir) ve QM yeniden başlatıldığında silinir. Uygulama MQPER_PERSISTENCE_AS_Q_DEF kullanırsa kuyruğun DEFPSIST değeri geçerli olur.',
    p: 'İş değeri yüksek mesajların (ödeme, sipariş) kesinlikle kaybolmamasını sağlamak; geçici bilgiler için performans kazanmak.',
    n: 'Kayıp kabul edilemeyen iş verisi: Persistent. Kısa ömürlü, tekrar üretilebilir veriler (fiyat güncellemesi, sorgu yanıtı): Not persistent.',
    b: 'Kalıcılık güvence, kalıcı olmama ise yüksek hız sağlar (log yazımı yok).',
    e: 'MQMD md = {MQMD_DEFAULT}; md.Persistence = MQPER_PERSISTENT;\nDEFINE QLOCAL(APP.ODEME.ISTEK) DEFPSIST(YES)',
    x: 'Kritik veriyi kalıcı olmayan göndermek QM yeniden başlatıldığında veri kaybına; her şeyi kalıcı göndermek ise gereksiz log yükü ve düşük performansa yol açar. Kanal NPMSPEED(FAST) ile kalıcı olmayan mesajlar ağ arızasında kaybolabilir.', l: ['q.defpsist', 'logtype', 'ch.npmspeed'] });
  h('priority', { t: 'Message Priority (öncelik)', c: 'Mesaj', m: 'MQMD.Priority / DEFPRTY',
    w: 'Mesajın 0 (en düşük) ile 9 (en yüksek, MAXPRTY) arasındaki öncelik değeridir.',
    r: 'Kuyruğun MSGDLVSQ(PRIORITY) ayarında MQGET önce yüksek öncelikli mesajları, aynı öncelikte ise FIFO sırasını döndürür. MSGDLVSQ(FIFO) ise önceliği yok sayar.',
    p: 'Acil mesajların (ör. iptal talebi) kuyrukta bekleyen sıradan mesajların önüne geçmesi.',
    n: 'Aynı kuyrukta farklı aciliyette mesajlar taşınıyorsa.', b: 'Ayrı kuyruk açmadan basit önceliklendirme.',
    e: 'md.Priority = 7;   // veya MQPRI_PRIORITY_AS_Q_DEF\nDEFINE QLOCAL(APP.IN) DEFPRTY(4) MSGDLVSQ(PRIORITY)',
    x: 'Sürekli yüksek öncelikli trafik düşük öncelikli mesajları "aç bırakabilir" (starvation). Sıra (ordering) garantisi gereken akışlarda öncelik kullanımı mesaj sırasını bozar.', l: ['q.msgdlvsq', 'q.defprty'] });
  h('expiry', { t: 'Message Expiry (geçerlilik süresi)', c: 'Mesaj', m: 'MQMD.Expiry',
    w: 'Mesajın geçerlilik süresidir; saniyenin onda biri (1/10 sn) cinsindendir. -1 (MQEI_UNLIMITED) süresiz demektir.',
    r: 'Süresi dolan mesajlar MQGET ile alınamaz; QM bunları arka planda veya erişim sırasında siler. Report seçeneği verilirse süre dolumu raporu gönderilir.',
    p: 'Belirli bir süre sonra anlamını yitiren mesajların (ör. 30 sn içinde yanıtlanmayan sorgu) birikmesini önlemek.',
    n: 'Request/reply senaryolarında yanıt bekleme süresi aşıldıktan sonra mesaj gereksizse.', b: 'Kuyruk şişmesini ve eski verinin işlenmesini önler.',
    e: 'md.Expiry = 300;   // 30 saniye\n# 9.x: kuyrukta CAPEXPRY ile üst sınır uygulanabilir (CUSTOM/CAPEXPRY)',
    x: 'Çok kısa expiry yoğun saatlerde mesajların işlenmeden silinmesine neden olur. Expiry 1/10 sn birimindedir; saniye sanıp 30 yazmak 3 saniye demektir.', l: ['persistence'] });
  h('mqmd', { t: 'MQMD (Message Descriptor)', c: 'Mesaj',
    w: 'Her MQ mesajına eşlik eden ve mesajın meta verilerini taşıyan yapıdır.',
    r: 'MsgId, CorrelId, Format, Persistence, Priority, Expiry, MsgType, ReplyToQ/ReplyToQMgr, PutApplName, UserIdentifier, PutDate/PutTime, Encoding, CodedCharSetId, BackoutCount gibi alanları içerir.',
    p: 'Mesajın nasıl işleneceğini, kime yanıt verileceğini ve nasıl dönüştürüleceğini belirtmek.', n: 'Her MQPUT/MQGET işleminde.',
    b: 'Uygulama verisine dokunmadan yönlendirme ve ilişkilendirme (correlation) yapılabilir.', e: 'MQMD md = {MQMD_DEFAULT};\nmemcpy(md.Format, MQFMT_STRING, MQ_FORMAT_LENGTH);\nstrncpy(md.ReplyToQ, "APP.ODEME.YANIT", MQ_Q_NAME_LENGTH);',
    x: 'Context alanlarını (UserIdentifier) değiştirmek için özel yetki (SETID/SETALL) gerekir; yanlış Format değeri veri dönüştürmeyi bozar.', l: ['mqmd.msgid', 'mqmd.correlid', 'mqmd.format', 'persistence', 'priority', 'expiry'] });
  h('mqmd.msgid', { t: 'MsgId (Message ID)', c: 'Mesaj', m: 'MQMD.MsgId',
    w: '24 baytlık mesaj kimliğidir. Varsayılan olarak QM tarafından benzersiz üretilir ("AMQ " + QM adı + zaman damgası).',
    r: 'Mesajı tekil tanımlar; request/reply\'da yanıt mesajının CorrelId\'sine kopyalanarak ilişkilendirme sağlar.',
    p: 'Belirli bir mesajı bulmak (MQGET match options) veya izlemek.', n: 'Hata ayıklama, yanıt eşleme ve mesaj izleme sırasında.',
    b: 'Uçtan uca izlenebilirlik.', e: '414D5120514D475730312020202020206728B11A24008F02\n"AMQ QMGW01      " + benzersiz son ek',
    x: 'Uygulamanın kendi MsgId\'sini atayıp benzersizliği garanti etmemesi yanlış mesajın eşleşmesine yol açar.', l: ['mqmd.correlid'] });
  h('mqmd.correlid', { t: 'CorrelId (Correlation ID)', c: 'Mesaj', m: 'MQMD.CorrelId',
    w: 'Mesajları birbiriyle ilişkilendirmek için kullanılan 24 baytlık alandır.',
    r: 'Yaygın desen: yanıtlayan uygulama, isteğin MsgId\'sini yanıtın CorrelId\'sine kopyalar; isteyen taraf MQGET\'i CorrelId ile filtreler.',
    p: 'Request/reply ve gruplanmış işlemlerde eşleştirme.', n: 'Paylaşımlı yanıt kuyruğunda her istemci kendi yanıtını almak istediğinde.',
    b: 'Tek bir yanıt kuyruğunu çok sayıda istemci güvenle paylaşabilir.', e: 'gmo.MatchOptions = MQMO_MATCH_CORREL_ID;\nmemcpy(md.CorrelId, requestMsgId, MQ_CORREL_ID_LENGTH);',
    x: 'Derin bir kuyrukta CorrelId ile arama, index yoksa (z/OS INDXTYPE) yavaşlayabilir; yanıtı alınmayan mesajlar kuyrukta birikir — expiry kullanın.', l: ['mqmd.msgid', 'mqmd.replyto'] });
  h('mqmd.format', { t: 'Format', c: 'Mesaj', m: 'MQMD.Format',
    w: 'Mesaj verisinin yapısını belirten 8 karakterlik addır: MQSTR (metin), MQHRF2 (JMS özellik başlığı), MQDEAD (DLQ başlığı), MQXMIT (iletim başlığı), boş (ikili).',
    r: 'Kanal veya MQGET sırasında veri dönüştürme (CCSID/encoding) yapılıp yapılamayacağını belirler; MQSTR karakter dönüşümüne izin verir.',
    p: 'Alıcı uygulamanın veriyi nasıl yorumlayacağını bildirmek.', n: 'Farklı platformlar/karakter setleri arasında metin gönderirken MQSTR kullanın.',
    b: 'Otomatik karakter seti dönüşümü.', e: 'MQFMT_STRING  = "MQSTR   "\nMQFMT_DEAD_LETTER_HEADER = "MQDEAD  "',
    x: 'İkili veriyi MQSTR olarak işaretlemek dönüşümde veriyi bozar; metni boş formatla göndermek ise dönüşümü engeller.', l: ['mqmd', 'qm.ccsid'] });
  h('mqmd.msgtype', { t: 'MsgType', c: 'Mesaj', m: 'MQMD.MsgType', w: 'Mesajın türü: DATAGRAM (yanıt beklenmez), REQUEST (yanıt beklenir), REPLY (yanıt), REPORT (rapor).', r: 'Uygulamaların mesajın amacını anlamasını sağlar.', p: 'Mesajlaşma desenini belirtmek.', n: 'Request/reply akışlarında REQUEST/REPLY kullanın.', b: 'Standart desenler.', e: 'md.MsgType = MQMT_REQUEST;', x: 'REQUEST gönderip ReplyToQ belirtmemek MQRC_MISSING_REPLY_TO_Q (2027) hatası verir.', l: ['mqmd.replyto'] });
  h('mqmd.replyto', { t: 'ReplyToQ / ReplyToQMgr', c: 'Mesaj', m: 'MQMD.ReplyToQ',
    w: 'Yanıtın gönderileceği kuyruk ve queue manager adıdır.', r: 'Yanıtlayan uygulama bu alanlara MQPUT1 ile yanıt yazar; QM gerekiyorsa uzak QM\'e yönlendirir.',
    p: 'Asenkron request/reply.', n: 'Yanıt beklenen her istekte.', b: 'Yanıt adresi sabit kodlanmak zorunda kalmaz.',
    e: 'md.ReplyToQ = "APP.ODEME.YANIT"; md.ReplyToQMgr = "QMGW01";', x: 'Yanıtlayan tarafta ReplyToQMgr\'a giden bir yol (xmitq / cluster) yoksa yanıtlar DLQ\'ya düşer (2087).', l: ['qmodel', 'mqmd.correlid'] });
  h('mqmd.putappl', { t: 'PutApplName', c: 'Mesaj', m: 'MQMD.PutApplName', w: 'Mesajı koyan uygulamanın adıdır (en fazla 28 karakter, genelde programın son 28 karakteri).', r: 'Origin context bilgisinin parçasıdır; kanal (MCA) aktarımında korunur.', p: 'Mesajın kaynağını izlemek.', n: 'Hata ayıklama ve denetimde.', b: 'Hangi uygulamanın mesajı ürettiği görülür.', e: 'PutApplName = "ilGateway.WindowsService.exe"', x: 'Uygulama kendisi değiştirirse (SETALL) yanıltıcı olabilir.', l: ['appltag'] });
  h('mqmd.userid', { t: 'UserIdentifier', c: 'Mesaj', m: 'MQMD.UserIdentifier', w: 'Mesajı koyan kullanıcı kimliğidir (12 karakter).', r: 'Identity context; alıcı tarafta PUTAUT(CTX) kanallarında yetki denetiminde kullanılabilir.', p: 'Denetim ve yetkilendirme.', n: 'Güvenlik denetimlerinde.', b: 'İzlenebilirlik.', e: 'UserIdentifier = "odemeapp    "', x: 'Uygulamaların bu alanı serbestçe değiştirebilmesi (SETID yetkisi) kimlik sahteciliğine yol açar.', l: ['oam'] });
  h('mqmd.puttime', { t: 'PutDate / PutTime', c: 'Mesaj', m: 'MQMD.PutDate/PutTime', w: 'Mesajın kuyruğa konduğu tarih ve saattir (GMT/UTC).', r: 'Origin context parçası; MSGAGE hesaplamalarında kullanılır.', p: 'Mesaj yaşını ve gecikmeyi ölçmek.', n: 'Performans ve gecikme analizinde.', b: 'Darboğaz tespiti.', e: 'PutDate=20261123 PutTime=08402150', x: 'Saat GMT\'dir; yerel saatle karıştırmak yanlış yorumlara yol açar.', l: ['msgage'] });
  h('mqdlh', { t: 'MQDLH (Dead-letter header)', c: 'Mesaj', m: 'MQDLH',
    w: 'Bir mesaj DLQ\'ya konduğunda başına eklenen başlıktır.', r: 'Reason (neden), DestQName/DestQMgrName (asıl hedef), PutApplName (DLQ\'ya koyan, genelde amqrmppa) alanlarını içerir.',
    p: 'Mesajın neden teslim edilemediğini anlamak ve yeniden işlemek.', n: 'DLQ\'daki mesajlar incelenirken.', b: 'runmqdlq kuralları bu başlığa göre eylem (RETRY, FWD, DISCARD) seçer.',
    e: 'REASON(MQRC_Q_FULL) ACTION(RETRY) RETRY(5)\nDESTQ(APP.*) REASON(MQRC_UNKNOWN_OBJECT_NAME) ACTION(FWD) FWDQ(APP.HATA)', x: 'DLQ mesajını başlığı çıkarmadan yeniden göndermek alıcıda bozuk veriye yol açar.', l: ['dlq', 'reasoncode'] });
  h('retained', { t: 'Retained publication', c: 'Publish/Subscribe', w: 'Bir topic\'e yayınlanan son mesajın saklanıp yeni abonelere hemen iletilmesidir (MQPMO_RETAIN).', r: 'Saklanan yayınlar SYSTEM.RETAINED.PUB.QUEUE\'da tutulur.', p: 'Abonelerin bağlandıkları anda son durumu (ör. güncel kur) almaları.', n: 'Durum bilgisi yayınlarında.', b: 'Yeni abone bir sonraki güncellemeyi beklemez.', e: 'pmo.Options |= MQPMO_RETAIN;', x: 'Her topic için yalnızca son mesaj saklanır; olay akışı için uygun değildir.', l: ['pubsub'] });
  h('selector', { t: 'Selector (seçici)', c: 'Publish/Subscribe', m: 'SELECTOR', w: 'Mesaj özelliklerine göre SQL92 benzeri filtre ifadesidir.', r: 'Abonelik veya MQGET yalnızca ifadeyi sağlayan mesajları alır.', p: 'Gereksiz mesaj tüketimini önlemek.', n: 'Aynı topic\'teki mesajların yalnızca bir kısmı ilgilendiriyorsa.', b: 'Ağ ve işlem tasarrufu.', e: "SELECTOR('kanal = ''SMS'' AND tutar > 1000')", x: 'Karmaşık selector\'lar QM CPU\'sunu artırır; eşleşmeyen mesajlar abone kuyruğuna hiç gelmez.', l: ['subscription'] });
  h('syncpoint', { t: 'Syncpoint / Unit of work', c: 'Mesaj', m: 'MQPMO_SYNCPOINT / MQCMIT / MQBACK',
    w: 'Birden fazla MQPUT/MQGET işleminin tek bir atomik işlem (transaction) olarak yapılmasıdır.', r: 'Syncpoint altındaki işlemler MQCMIT ile kalıcı olur, MQBACK ile geri alınır. Geri alınan MQGET mesajı kuyruğa geri koyar ve BackoutCount\'u artırır.',
    p: 'Mesaj kaybı veya çift işleme olmadan güvenilir işleme.', n: 'Bir mesajı alıp işleyip yeni mesaj ürettiğiniz her senaryoda.', b: '"Tam olarak bir kez" işlemenin temelidir.',
    e: 'MQGET(..., gmo.Options = MQGMO_SYNCPOINT)\n// veritabanı işlemi\nMQPUT(..., pmo.Options = MQPMO_SYNCPOINT)\nMQCMIT(hConn)', x: 'Çok uzun açık kalan transaction\'lar log\'u doldurur; MAXUMSGS sınırı aşılırsa MQRC_SYNCPOINT_LIMIT_REACHED (2024).', l: ['backout', 'uow', 'qm.maxumsgs'] });
  h('uow', { t: 'Unit of work (UOW)', c: 'Mesaj', w: 'Henüz commit veya backout edilmemiş, syncpoint altındaki işlemler kümesidir.', r: 'UNCOM alanı bir kuyrukta commit edilmemiş mesaj olup olmadığını gösterir. DISPLAY CONN ile açık UOW\'ler görülebilir.', p: 'Transaction durumunu izlemek.', n: 'Mesajlar "görünmüyor" ama derinlik artıyorsa (commit edilmemiş put).', b: 'Kilitli/asılı transaction\'ları tespit etmek.', e: 'DISPLAY CONN(*) TYPE(CONN) UOWSTATE UOWLOGDA UOWLOGTI', x: 'Uzun süre açık UOW log alanını kilitler ve log full hatasına yol açar.', l: ['syncpoint', 'log.files'] });
  h('backout', { t: 'Backout threshold (poison message)', c: 'Queue özellikleri', m: 'BOTHRESH / BOQNAME',
    w: 'Bir mesajın kaç kez geri alındıktan (MQBACK) sonra "zehirli" (poison) kabul edileceğini ve hangi kuyruğa taşınacağını tanımlar.',
    r: 'Önemli: Queue manager bu değerleri kendisi uygulamaz; yalnızca saklar. Mesajı BOQNAME\'e taşıyan, BackoutCount ile BOTHRESH\'i karşılaştıran uygulama veya kütüphanedir (IBM MQ classes for JMS, MDB\'ler, App Connect/IIB bunu otomatik yapar).',
    p: 'İşlenemeyen bir mesajın sonsuz döngüde tekrar tekrar alınıp kuyruğu kilitlemesini önlemek.',
    n: 'Syncpoint ile mesaj işleyen tüm tüketici kuyruklarında (özellikle JMS/MDB).',
    b: 'Tek bir bozuk mesaj tüm akışı durdurmaz; sorunlu mesajlar ayrı incelenir.',
    e: 'DEFINE QLOCAL(APP.ODEME.ISTEK) BOTHRESH(3) BOQNAME(APP.ODEME.BACKOUT)\nDEFINE QLOCAL(APP.ODEME.BACKOUT)',
    x: 'BOTHRESH(0) veya BOQNAME yoksa poison mesaj sürekli geri alınıp CPU tüketir. BOQNAME kuyruğuna yazma yetkisi yoksa JMS mesajı DLQ\'ya gönderir; DLQ da yoksa tüketici durur.', l: ['q.boqname', 'syncpoint', 'dlq'] });

  /* ============================== İZLEME ============================== */
  h('monitoring', { t: 'Online monitoring', c: 'İzleme', m: 'MONQ / MONCHL / MONACLS',
    w: 'Kuyruk ve kanallar için gerçek zamanlı performans verisi (mesaj yaşı, kuyruk süresi, ağ süresi) toplanmasını sağlayan ayarlardır.',
    r: 'MONQ açıkken DISPLAY QSTATUS; MSGAGE, QTIME, LPUT/LGET değerlerini döndürür. MONCHL açıkken DISPLAY CHSTATUS; XQTIME, NETTIME, COMPRATE gibi değerleri döndürür. Değerler: OFF, LOW, MEDIUM, HIGH (örnekleme oranı); QMGR = QM ayarını kullan.',
    p: 'Gecikmeleri ve darboğazları anlık tespit etmek.', n: 'Üretimde en azından kritik kuyruk/kanallarda MEDIUM önerilir.',
    b: 'Kullanıcı şikâyetinden önce sorun görülür.', e: 'ALTER QMGR MONQ(MEDIUM) MONCHL(MEDIUM)\nDISPLAY QSTATUS(APP.*) MSGAGE QTIME',
    x: 'HIGH, çok yüksek hacimde küçük de olsa CPU yükü getirir. OFF iken MSGAGE/QTIME boş döner ve izleme araçları körleşir.', l: ['msgage', 'qtime', 'chmonitor', 'qmstats'] });
  h('qmstats', { t: 'Queue Manager Statistics', c: 'İzleme', m: 'STATMQI / STATQ / STATCHL / STATINT',
    w: 'Belirli aralıklarla (STATINT saniye) QM, kuyruk ve kanal faaliyet özetlerinin PCF mesajı olarak SYSTEM.ADMIN.STATISTICS.QUEUE\'ya yazılmasıdır.',
    r: 'STATMQI: MQI çağrı sayıları (MQCONN, MQOPEN, MQPUT, MQGET, MQCMIT…). STATQ: kuyruk başına put/get/derinlik istatistikleri. STATCHL: kanal başına mesaj/bayt/batch istatistikleri.',
    p: 'Kapasite planlama, trend analizi ve faturalama/raporlama.', n: 'Uzun dönemli performans izleme ve izleme araçlarına (amqsmon, Prometheus exporter, Instana) veri sağlamak için.',
    b: 'Tarihsel veri ile kapasite kararları.', e: 'ALTER QMGR STATMQI(ON) STATQ(ON) STATCHL(MEDIUM) STATINT(900)\n/opt/mqm/samp/bin/amqsmon -m QMGW01 -t statistics',
    x: 'İstatistik kuyruğunu okuyan bir araç yoksa SYSTEM.ADMIN.STATISTICS.QUEUE dolar ve yeni istatistikler kaybolur.', v: '9.x\'te ayrıca $SYS/MQ/INFO/QMGR/... topic\'lerinden yayınlanan kaynak izleme (amqsrua) verisi de mevcuttur.', l: ['monitoring', 'accounting'] });
  h('accounting', { t: 'Accounting (hesap izleme)', c: 'İzleme', m: 'ACCTMQI / ACCTQ / ACCTINT / ACCTCONO',
    w: 'Her bağlantı (uygulama) bazında MQI kullanım kayıtlarının SYSTEM.ADMIN.ACCOUNTING.QUEUE\'ya yazılmasıdır.',
    r: 'ACCTMQI bağlantı başına MQI çağrılarını, ACCTQ ise bağlantı başına kuyruk kullanımını kaydeder. ACCTCONO(ENABLED) uygulamaların MQCONNX ile bu ayarı geçersiz kılmasına izin verir.',
    p: 'Hangi uygulamanın ne kadar kaynak kullandığını ölçmek (chargeback).', n: 'Çok kiracılı (multi-tenant) QM\'lerde maliyet paylaştırma veya uygulama davranış analizinde.',
    b: 'Uygulama bazlı görünürlük.', e: 'ALTER QMGR ACCTMQI(ON) ACCTQ(ON) ACCTINT(1800)', x: 'Çok sayıda kısa ömürlü bağlantıda yoğun kayıt üretir; okunmazsa kuyruk dolar.', l: ['qmstats'] });
  h('msgage', { t: 'Mesaj yaşı (MSGAGE)', c: 'İzleme', m: 'MSGAGE',
    w: 'Kuyruktaki en eski mesajın saniye cinsinden yaşıdır.', r: 'MONQ etkinken DISPLAY QSTATUS ile döner.', p: 'Tüketicinin geride kalıp kalmadığını anlamak.',
    n: 'Derinlik normal görünse bile mesajlar bekliyorsa (ör. tüketici takılı).', b: 'SLA ihlallerinin erken tespiti.', e: 'DISPLAY QSTATUS(APP.RAPOR.BATCH) MSGAGE\nMSGAGE(45600)',
    x: 'MONQ(OFF) iken değer boş gelir; izleme yapılıyor sanılır.', l: ['monitoring', 'qtime'] });
  h('qtime', { t: 'Queue time (QTIME)', c: 'İzleme', m: 'QTIME',
    w: 'Mesajların kuyrukta ortalama bekleme süresidir (mikrosaniye). İki değer verilir: kısa dönem ve uzun dönem ortalaması.', r: 'MONQ etkinken hesaplanır.',
    p: 'Kuyruk kaynaklı gecikmeyi ölçmek.', n: 'Uçtan uca yanıt süresi analizinde.', b: 'Gecikmenin kuyrukta mı, uygulamada mı olduğunu ayırt eder.', e: 'QTIME(1250, 980)', x: 'Ortalama değer anlık sıçramaları gizleyebilir.', l: ['msgage'] });
  h('qdepth.monitor', { t: 'Queue depth monitoring', c: 'İzleme',
    w: 'Kuyruk derinliğinin (CURDEPTH) MAXDEPTH\'e göre izlenmesidir.', r: 'Performance event\'leri (QDEPTHHI/QDEPTHLO/QDPMAXEV) ve izleme araçları bu değeri kullanır.',
    p: 'Tüketici sorunlarını ve kapasite aşımını önceden yakalamak.', n: 'Tüm iş kritik kuyruklarda.', b: 'Kuyruk dolmadan müdahale.', e: 'DISPLAY QLOCAL(APP.*) CURDEPTH MAXDEPTH WHERE(CURDEPTH GT 1000)',
    x: 'Yalnızca derinliğe bakmak yanıltıcıdır: düşük derinlik + yüksek MSGAGE, takılı bir tüketiciye işaret edebilir.', l: ['qdepthhi', 'curdepth', 'msgage'] });
  h('putrate', { t: 'Message put rate / get rate', c: 'İzleme',
    w: 'Birim zamanda kuyruklara konan (put) ve alınan (get) mesaj sayısıdır.', r: 'STATQ/STATMQI istatistiklerinden veya $SYS/MQ kaynak izleme topic\'lerinden elde edilir.',
    p: 'Üretici/tüketici dengesini görmek.', n: 'Put hızı sürekli get hızını aşıyorsa kuyruk büyür; kapasite planlamasında.', b: 'Trend ve zirve saat analizi.',
    e: '/opt/mqm/samp/bin/amqsrua -m QMGW01 -c STATQ -t PUT -o APP.ODEME.ISTEK', x: 'Kısa aralıklı ölçümler dalgalı görünür; karar için uzun dönem ortalama kullanın.', l: ['qmstats', 'msgflow'] });
  h('msgflow', { t: 'Message flow statistics', c: 'İzleme',
    w: 'Mesajların sistemdeki genel akışını (giriş, çıkış, birikim) gösteren özet istatistiklerdir.', r: 'Put/get sayıları, bayt hacmi ve net birikim hesaplanır.',
    p: 'Sistemin genel sağlığını tek bakışta görmek.', n: 'Günlük operasyon ve raporlamada.', b: 'Anormal trafik artışlarını fark etmek.',
    e: 'Giriş: 4.760 mesaj / 11,13 MB\nÇıkış: 4.712 mesaj / 11,17 MB', x: 'Toplamlar, tek bir kuyruktaki sorunu gizleyebilir; kuyruk bazlı inceleyin.', l: ['putrate'] });
  h('cpumem', { t: 'CPU ve bellek kullanımı', c: 'İzleme',
    w: 'Queue manager süreçlerinin işlemci ve bellek tüketimidir.', r: 'MQ Console bu değerleri $SYS/MQ/INFO/QMGR/<QM>/Monitor/CPU ve /Monitor/... sistem topic\'lerinden okur.',
    p: 'Kaynak darboğazlarını tespit etmek.', n: 'Performans sorunlarında ve kapasite planlamasında.', b: 'Donanım ihtiyacını öngörmek.',
    e: 'amqsrua -m QMGW01 -c CPU -t SystemSummary', x: 'Yüksek CPU genelde aşırı bağlantı/kopma (connection churn), seçici (selector) kullanımı veya derin kuyrukta mesaj aramaktan kaynaklanır.', v: 'Kaynak izleme (resource usage) topic\'leri 9.0.x ile geldi.', l: ['storage'] });
  h('storage', { t: 'Storage (depolama)', c: 'İzleme', w: 'Queue manager veri ve log dizinlerinin kullandığı disk alanıdır.', r: 'Kuyruk dosyaları derin kuyruklarla büyür; log dizini log yapılandırmasına göre büyür.', p: 'Disk dolmasını önlemek.', n: 'Sürekli izlenmelidir.', b: 'Kesintisiz çalışma.', e: 'du -sh /var/mqm/qmgrs/QMGW01 /var/mqm/log/QMGW01', x: 'Disk dolarsa QM kalıcı mesaj yazamaz ve durabilir.', l: ['datapath', 'q.maxfsize'] });
  h('chmonitor', { t: 'Channel monitoring', c: 'İzleme', m: 'MONCHL',
    w: 'Kanal performans göstergelerinin (mesaj, bayt, batch sayıları, XQTIME, NETTIME, sıkıştırma oranı) izlenmesidir.', r: 'MONCHL ile etkinleştirilir; DISPLAY CHSTATUS ile görüntülenir.',
    p: 'Ağ ve kanal kaynaklı gecikmeleri bulmak.', n: 'QM\'ler arası trafik yavaşladığında.', b: 'Gecikmenin ağda mı (NETTIME), xmitq\'da mı (XQTIME) olduğu ayırt edilir.',
    e: 'DISPLAY CHSTATUS(QMGW01.QMCORE01) MSGS BYTSSENT XQTIME NETTIME', x: 'MONCHL(OFF) iken bu alanlar boş döner.', l: ['xqtime', 'nettime', 'ch.monchl'] });
  h('xqtime', { t: 'XQTIME', c: 'İzleme', m: 'XQTIME', w: 'Mesajların transmission queue\'da gönderilmeden önce bekledikleri süre (mikrosaniye, kısa/uzun dönem).', r: 'Sender kanallar için MONCHL etkinken hesaplanır.', p: 'Kanal kapasitesinin yeterliliğini ölçmek.', n: 'Uzak QM\'e gecikme şikâyetlerinde.', b: 'Darboğazın kaynağını gösterir.', e: 'XQTIME(820, 640)', x: 'Yüksek XQTIME: kanal yavaş, batch ayarları uygun değil veya ağ yetersiz olabilir.', l: ['nettime', 'xmitq'] });
  h('nettime', { t: 'NETTIME', c: 'İzleme', m: 'NETTIME', w: 'Bir batch sonunda karşı taraftan onay (confirm) gelene kadar geçen ağ gidiş-dönüş süresi (mikrosaniye).', r: 'Sender kanallar için MONCHL etkinken hesaplanır.', p: 'Ağ gecikmesini ölçmek.', n: 'WAN üzerinden kanal performansında.', b: 'Ağ ekibine somut veri.', e: 'NETTIME(1350, 1120)', x: 'Yüksek NETTIME\'da BATCHSZ artırmak verimi iyileştirebilir.', l: ['xqtime', 'ch.batchsz'] });
  h('backlog', { t: 'Birikim (backlog)', c: 'İzleme', w: 'Put sayısının get sayısını aşan kısmı; kuyruklarda biriken mesaj miktarıdır.', r: 'Derinliğin artış hızını gösterir.', p: 'Tüketici kapasitesi yetersizliğini görmek.', n: 'Derinlik alarmlarından önce trend izlemede.', b: 'Proaktif ölçekleme.', e: 'Net birikim = Σput − Σget', x: 'Batch işlerinde geçici birikim normaldir; mutlaka zaman bağlamıyla yorumlayın.', l: ['putrate'] });
  h('qmevents', { t: 'Queue Manager Events (olaylar)', c: 'İzleme',
    w: 'Queue manager\'ın belirli durumlarda ürettiği PCF formatlı olay mesajlarıdır.', r: 'Olay türleri ve kuyrukları: QMGR event\'leri (yetki, inhibit, local/remote, start/stop) → SYSTEM.ADMIN.QMGR.EVENT; performance event\'leri (derinlik, servis aralığı) → SYSTEM.ADMIN.PERFM.EVENT; channel event\'leri → SYSTEM.ADMIN.CHANNEL.EVENT; configuration → SYSTEM.ADMIN.CONFIG.EVENT; command → SYSTEM.ADMIN.COMMAND.EVENT; logger → SYSTEM.ADMIN.LOGGER.EVENT.',
    p: 'İzleme araçlarının MQ\'daki önemli olayları otomatik algılaması.', n: 'Kurumsal izleme (Instana, Tivoli, Splunk) entegrasyonunda.', b: 'Kural tabanlı alarm üretimi.',
    e: 'ALTER QMGR PERFMEV(ENABLED) CHLEV(ENABLED) AUTHOREV(ENABLED)\n/opt/mqm/samp/bin/amqsevt -m QMGW01 -q SYSTEM.ADMIN.PERFM.EVENT -o json',
    x: 'Event\'leri açıp olay kuyruklarını okumamak kuyrukların dolmasına neden olur (olaylar sonra sessizce kaybolur).', l: ['perfevents', 'qm.authorev', 'qm.chlev', 'qm.configev'] });
  h('perfevents', { t: 'Performance events', c: 'İzleme', m: 'PERFMEV',
    w: 'Kuyruk derinliği ve servis aralığına dayalı performans olaylarıdır.', r: 'QM düzeyinde PERFMEV(ENABLED) ve kuyruk düzeyinde QDPHIEV/QDPLOEV/QDPMAXEV/QSVCIEV birlikte açık olmalıdır. Olaylar SYSTEM.ADMIN.PERFM.EVENT\'e yazılır.',
    p: 'Kuyruk dolmadan ve tüketici yavaşlamadan alarm üretmek.', n: 'Kritik kuyruklarda.', b: 'Proaktif müdahale.', e: 'ALTER QMGR PERFMEV(ENABLED)\nALTER QLOCAL(APP.ODEME.ISTEK) QDEPTHHI(80) QDPHIEV(ENABLED)',
    x: 'QM düzeyinde PERFMEV kapalıyken kuyruk ayarları hiçbir olay üretmez. High event tetiklendikten sonra low event gelene kadar tekrar tetiklenmez (olay çifti mantığı).', l: ['qdepthhi', 'q.qdepthlo', 'qfull', 'q.qsvciev'] });
  h('health', { t: 'Sağlık durumu', c: 'İzleme', w: 'Bu konsoldaki özet sağlık göstergesidir: QM durumu, RETRYING kanallar, dolu/yüksek derinlikli kuyruklar ve durdurulmuş listener\'lar birlikte değerlendirilir.', r: 'Gerçek MQ\'da tek bir "sağlık" alanı yoktur; izleme araçları bu tür kuralları kendileri tanımlar.', p: 'Operatörlere tek bakışta durum özeti.', n: 'Vardiya devri ve günlük kontrolde.', b: 'Sorunlara öncelik verme.', e: 'Error: RETRYING kanal veya dolu kuyruk\nWarning: yüksek derinlik', x: 'Özet göstergeler ayrıntıları gizler; uyarıya tıklayıp kök nedeni inceleyin.', l: ['dashboard'] });

  /* ============================== MQ CLUSTER ============================== */
  h('cluster', { t: 'MQ Cluster', c: 'MQ Cluster', m: 'CLUSTER',
    w: 'Birden fazla queue manager\'ın mantıksal bir grup oluşturduğu, nesne tanımlarını paylaştığı ve mesajları otomatik yönlendirdiği yapıdır.',
    r: 'Full repository QM\'ler tüm cluster bilgisini tutar; partial repository QM\'ler yalnızca ilgilendikleri bilgiyi ister. Her üye bir CLUSRCVR (kendine gelen) ve en az bir full repository\'ye manuel CLUSSDR tanımlar; diğer kanallar otomatik oluşturulur. Mesajlar SYSTEM.CLUSTER.TRANSMIT.QUEUE üzerinden iletilir.',
    p: 'Point-to-point tanım yükünü (her QM çifti için xmitq + SDR + RCVR + QREMOTE) ortadan kaldırmak ve iş yükü dengelemesi yapmak.',
    n: 'Çok sayıda QM arasında dinamik mesajlaşma, aynı kuyruğun birden çok instance\'ı ile yatay ölçekleme veya HA gerektiğinde.',
    b: 'Yeni QM eklemek iki kanal tanımı kadar kolaydır; CLWL algoritması mesajları uygun instance\'lara dağıtır.',
    e: '* Her üyede:\nDEFINE CHANNEL(TO.CLS.ODEME.QMGW01) CHLTYPE(CLUSRCVR) CONNAME(\'mqgw01(1414)\') CLUSTER(CLS.ODEME)\nDEFINE CHANNEL(TO.CLS.ODEME.QMCORE01) CHLTYPE(CLUSSDR) CONNAME(\'mqcore01(1414)\') CLUSTER(CLS.ODEME)\n* Full repository\'lerde:\nALTER QMGR REPOS(CLS.ODEME)\n* Kuyruğu duyur:\nALTER QLOCAL(APP.HESAP.SORGU) CLUSTER(CLS.ODEME)',
    x: 'Tek full repository bir SPOF\'tur (en az iki önerilir, ikiden fazla gerekmez). Kanal adlandırma kuralsızlığı, REFRESH CLUSTER\'ın gereksiz kullanımı ve aynı adlı farklı amaçlı kuyruklar beklenmedik yönlendirmelere yol açar.',
    v: '9.1.2+ ile Uniform Cluster (uygulama bağlantılarının otomatik dengelenmesi) geldi. 8.0+ ile DEFCLXQ(CHANNEL) kanal başına ayrı cluster xmitq kullanımına izin verir.', l: ['fullrepos', 'partialrepos', 'clussdr', 'clusrcvr', 'clusterq', 'clwl'] });
  h('fullrepos', { t: 'Full repository', c: 'MQ Cluster', m: 'REPOS',
    w: 'Cluster\'daki tüm QM\'ler, kuyruklar ve topic\'ler hakkında eksiksiz bilgiyi tutan queue manager\'dır.', r: 'Diğer üyelerin güncellemelerini alır, birbirleriyle senkronize eder ve partial repository\'lerin sorgularını yanıtlar.',
    p: 'Cluster\'ın "dizin hizmeti".', n: 'Her cluster\'da tam olarak iki full repository önerilir; yüksek erişilebilir, az yüklü QM\'ler seçilmelidir.',
    b: 'İki full repository ile biri bakımdayken cluster çalışmaya devam eder.', e: 'ALTER QMGR REPOS(CLS.ODEME)\nDISPLAY CLUSQMGR(*) QMTYPE\nQMTYPE(REPOS)',
    x: 'Full repository\'lerin birbirine manuel CLUSSDR ile bağlanmaması bilgi tutarsızlığına yol açar. Uygulama trafiğini full repository\'lerde yoğunlaştırmak cluster yönetimini yavaşlatır.', l: ['cluster', 'partialrepos', 'qm.repos'] });
  h('partialrepos', { t: 'Partial repository', c: 'MQ Cluster', w: 'Cluster bilgisinin yalnızca kendisi için gerekli kısmını tutan üye QM\'dir.', r: 'Bir cluster nesnesini ilk kullandığında full repository\'den bilgi ister ve abone olur; bilgiler 30 günde bir yenilenir.',
    p: 'Ölçeklenebilirlik: her QM tüm cluster bilgisini tutmak zorunda kalmaz.', n: 'Cluster\'daki uygulama QM\'lerinin çoğu.', b: 'Az bellek, az ağ trafiği.', e: 'DISPLAY CLUSQMGR(*) QMTYPE\nQMTYPE(NORMAL)', x: 'Partial repository\'nin full repository\'lere ulaşamaması yeni cluster nesnelerinin "görünmemesine" (2085) yol açar.', l: ['fullrepos'] });
  h('clusqmgr', { t: 'Cluster queue managers (CLUSQMGR)', c: 'MQ Cluster', m: 'DISPLAY CLUSQMGR',
    w: 'Bir queue manager\'ın bildiği cluster üyelerini ve onlara giden cluster kanallarının durumunu listeler.', r: 'DEFTYPE alanı kanalın nasıl tanımlandığını gösterir: CLUSRCVR (kendisi), CLUSSDR (manuel), CLUSSDRA (otomatik), CLUSSDRB (ikisi birden).',
    p: 'Cluster topolojisini ve iletişim durumunu doğrulamak.', n: 'Cluster kurulumu sonrası ve sorun gidermede.', b: 'Hangi QM\'e erişilemediğini net gösterir.', e: 'DISPLAY CLUSQMGR(*) CONNAME QMTYPE STATUS DEFTYPE', x: 'Aynı QM adı farklı QMID ile iki kez görünüyorsa eski bir kayıt kalmıştır; RESET CLUSTER ile temizlenmelidir.', l: ['cluster', 'clusstatus'] });
  h('clusstatus', { t: 'Cluster communication status', c: 'MQ Cluster', w: 'Bu QM\'den diğer cluster üyelerine giden CLUSSDR kanallarının durumudur.', r: 'RUNNING: iletişim var. INACTIVE: henüz/şu an trafik yok (normal olabilir). RETRYING: karşı tarafa ulaşılamıyor.', p: 'Cluster sağlığını izlemek.', n: 'Mesajların SYSTEM.CLUSTER.TRANSMIT.QUEUE\'da biriktiği durumlarda.', b: 'Erişilemeyen üyelerin hızlı tespiti.', e: 'DISPLAY CHSTATUS(TO.CLS.*) STATUS', x: 'RETRYING bir cluster kanalı, CLWL\'nin o QM\'i seçmesini engellemeyebilir (DEFBIND OPEN) ve mesajlar birikir.', l: ['clusqmgr', 'clwl'] });
  h('clwl', { t: 'Cluster workload balancing (CLWL)', c: 'MQ Cluster',
    w: 'Aynı adlı cluster kuyruğunun birden fazla instance\'ı olduğunda mesajın hangisine gideceğini belirleyen algoritmadır.',
    r: 'Sırasıyla değerlendirilir: PUT(DISABLED) instance\'lar ve erişilemeyen kanallar elenir → CLWLRANK (yüksek rank öncelikli) → CLWLPRTY → kanal durumu → CLWLWGHT (ağırlık) → en az kullanılan kanal (round-robin). Yerel instance tercih kuralı CLWLUSEQ ile belirlenir.',
    p: 'Yükü birden çok QM\'e dağıtmak ve arızada otomatik yönlendirme yapmak.', n: 'Ölçekleme ve aktif-aktif mimarilerde.', b: 'Tek noktaya bağımlılığı azaltır.',
    e: 'ALTER QLOCAL(APP.KREDI.SKOR) CLWLPRTY(5)\nALTER CHANNEL(TO.CLS.ODEME.QMCORE01) CHLTYPE(CLUSRCVR) CLWLWGHT(70)',
    x: 'DEFBIND(OPEN) ile uygulama tüm mesajları tek instance\'a gönderir; dengeleme için DEFBIND(NOTFIXED) gerekir ancak mesaj sırası/afinite kaybolur.', l: ['q.defbind', 'q.clwlprty', 'q.clwlrank', 'qm.clwluseq', 'ch.clwlwght'] });

  /* ============================== KONSOL ============================== */
  h('console', { t: 'IBM MQ Console (eğitim simülasyonu)', c: 'Konsol',
    w: 'IBM MQ Console, mqweb sunucusu (WebSphere Liberty) üzerinde çalışan, queue manager\'ları tarayıcıdan yönetmeye yarayan web arayüzüdür. Bu uygulama onun eğitim amaçlı bir simülasyonudur.',
    r: 'Gerçek Console, aynı sunucudaki (local) QM\'leri doğrudan, uzak QM\'leri ise CCDT ile bağlanarak yönetir; işlemleri MQ REST API / PCF komutlarıyla gerçekleştirir.',
    p: 'Kuyruk, kanal, topic ve güvenlik nesnelerini görsel olarak yönetmek; MQSC bilmeden temel işlemleri yapmak.',
    n: 'Bu simülasyonu MQ kavramlarını öğrenmek için kullanın: her ? simgesine tıklayın, nesneler oluşturun, mesaj koyup alın, kanalları başlatıp durdurun. Sol menüde: Home, Manage, Gösterge paneli, MQSC konsolu, Öğrenme kaynakları, Ayarlar.',
    b: 'Gerçek sisteme zarar verme riski olmadan deneme yanılma ile öğrenme.',
    e: 'Gerçek konsol adresi (varsayılan): https://<host>:9443/ibmmq/console\nmqweb başlatma: strmqweb   |   durum: dspmqweb',
    x: 'Bu simülasyon gerçek bir MQ\'ya bağlanmaz; burada gördüğünüz başarılı/başarısız sonuçlar öğretici amaçlıdır. Gerçek ortamda yetkiler (mqweb rolleri + OAM) ve sürüm farklılıkları sonuçları değiştirebilir.', l: ['simulation', 'mqwebroles', 'mqsc', 'learning'] });
  h('simulation', { t: 'Simülasyon verileri', c: 'Konsol', w: 'Bu konsoldaki tüm queue manager\'lar, kuyruklar, kanallar ve mesajlar kurgusal örnek verilerdir ve tarayıcınızın yerel depolamasında (localStorage) tutulur.', r: 'Yaptığınız değişiklikler (yeni kuyruk, put edilen mesaj vb.) yalnızca bu tarayıcıda saklanır; Ayarlar → Sıfırla ile ilk haline döner.',
    p: 'Gerçekçi, tutarlı bir ortamda güvenle pratik yapmak.', n: 'Örnek senaryolar: QMGW01.QMBATCH01 kanalı neden RETRYING? (İpucu: QMBATCH01 listener\'larına bakın.) APP.LOG.AUDIT neden dolu? APP.FATURA.IN\'e mesaj koyunca ne olur (triggering)?',
    b: 'Gerçek dünyadaki arıza senaryolarını yeniden üretir.', e: 'Ayarlar → Simülasyon verilerini sıfırla', x: 'Tarayıcı verilerini temizlerseniz yaptığınız değişiklikler kaybolur (bu bir sorun değildir; örnek ortam yeniden yüklenir).', l: ['console'] });
  h('learning', { t: 'Öğrenme kaynakları', c: 'Konsol', w: 'Konsoldaki tüm açıklamaların kategorilere ayrılmış, aranabilir listesidir.', r: 'Her kart, sağ panelde açılan ayrıntılı bir açıklamaya karşılık gelir.', p: 'MQ kavramlarını sırayla veya ihtiyaç anında öğrenmek.', n: 'Yeni başlayanlar "Önerilen öğrenme yolu" sırasını izleyebilir.', b: 'Konsol içinde kaybolmadan konu bazlı çalışma.', e: 'Arama: "BOTHRESH", "CHLAUTH", "cluster"', x: 'Açıklamalar özet niteliğindedir; üretim kararları için IBM MQ resmi dokümantasyonunu da inceleyin.', l: ['console'] });
  h('manage', { t: 'Manage', c: 'Konsol', w: 'Queue manager\'ların listelendiği ve yönetildiği ana sayfadır.', r: 'Local queue managers: Console ile aynı sunucudaki QM\'ler. Remote queue managers: CCDT ile bağlanılan uzak QM\'ler.', p: 'Bir QM seçip nesnelerini yönetmek, QM oluşturmak/başlatmak/durdurmak.', n: 'Konsoldaki çoğu işin başlangıç noktası.', b: 'Tüm QM\'leri tek yerden görmek.', e: 'Manage → QMGW01 → Queues', x: 'Remote QM\'lerde Console\'un kullandığı SVRCONN kanalının yetkileri, yapılabilecek işlemleri sınırlar.', l: ['localqm', 'remoteqm'] });
  h('localqm', { t: 'Local queue managers', c: 'Konsol', w: 'MQ Console (mqweb) ile aynı sunucuda ve aynı installation\'da çalışan queue manager\'lardır.', r: 'Console bunlara yerel (bindings) bağlantı ile erişir; başlatma/durdurma/oluşturma yapılabilir.', p: 'Sunucudaki QM\'leri yönetmek.', n: 'Her zaman.', b: 'Ağ ve TLS yapılandırması gerektirmez.', e: 'dspmq', x: 'Console kullanıcısının ilgili OAM yetkileri yoksa nesneler görünmez veya işlemler 2035 ile reddedilir.', l: ['manage', 'remoteqm'] });
  h('remoteqm', { t: 'Remote queue managers', c: 'Konsol', w: 'Console\'un başka sunuculardaki QM\'lere istemci (client) bağlantısıyla eriştiği yapılandırmadır.', r: 'Her remote QM için bir CCDT (JSON) ve kimlik bilgisi tanımlanır; bağlantı bir SVRCONN kanalı üzerinden yapılır.', p: 'Merkezi bir Console\'dan çok sayıda QM\'i yönetmek.', n: 'z/OS veya container QM\'leri ya da farklı sunuculardaki QM\'leri yönetirken.', b: 'Tek arayüz.', e: 'Manage → Remote queue managers → Add\nCCDT: ccdt-zos1.json', x: 'Yönetim kanalını TLS ve CHLAUTH olmadan açmak ciddi güvenlik riskidir.', v: 'Remote queue manager desteği MQ 9.1.x CD / 9.2 LTS ile Console\'a eklendi.', l: ['ccdt', 'svrconn', 'chlauth'] });
  h('quickstart', { t: 'Application quick start', c: 'Konsol', w: 'Bir uygulamanın MQ ile çalışması için gereken asgari yapılandırmayı adım adım gösteren rehberdir.', r: 'Gerçek Console\'da örnek kod ve gerekli nesneleri oluşturma sihirbazı sunar.', p: 'Geliştiricilerin hızlı başlaması.', n: 'Yeni bir uygulamayı MQ\'ya bağlarken.', b: 'Kuyruk, kanal, CHLAUTH ve yetki adımlarının unutulmaması.', e: 'Kuyruk → SVRCONN → CHLAUTH → AUTHREC → CCDT → test', x: 'Hızlı başlangıç için açılan geniş yetkiler (ör. ALL) üretime taşınmamalıdır.', l: ['svrconn', 'chlauth', 'oam', 'ccdt'] });
  h('ccdt', { t: 'CCDT (Client Channel Definition Table)', c: 'Konsol', m: 'MQCCDTURL',
    w: 'İstemci uygulamaların hangi queue manager\'a, hangi host/port ve kanal ile, hangi TLS ayarlarıyla bağlanacağını tanımlayan dosyadır.',
    r: 'Uygulama MQCONN\'da QM adını (veya *grup adını) verir; MQ istemci kütüphanesi CCDT\'den uygun kanal tanımını seçer. JSON formatı 9.1.2+ ile desteklenir; eski format ikili AMQCLCHL.TAB dosyasıdır.',
    p: 'Bağlantı bilgisini koddan ayırmak, yedek adresler ve yük dağılımı tanımlamak.', n: 'Birden çok QM/adres, TLS ve yüksek erişilebilirlik gerektiren tüm istemci uygulamalarda.',
    b: 'Ortam değişikliğinde kod değişmez; yalnızca CCDT güncellenir.',
    e: 'export MQCCDTURL=file:///opt/app/ccdt.json\n{"channel":[{"name":"APP.ODEME.SVRCONN","clientConnection":{"connection":[{"host":"mqgw01","port":1414}],"queueManager":"QMGW01"},"transmissionSecurity":{"cipherSpecification":"ANY_TLS12_OR_HIGHER"},"type":"clientConnection"}]}',
    x: 'MQSERVER ortam değişkeni tanımlıysa CCDT\'den önce gelir ve TLS gibi ayarlar yok sayılabilir. CCDT\'deki CipherSpec sunucu kanalıyla uyumsuzsa 2393 (SSL_INITIALIZATION_ERROR) veya 2059 alınır.', l: ['clntconn', 'svrconn', 'tls'] });
  h('dashboard', { t: 'Gösterge paneli', c: 'Konsol', w: 'Tüm queue manager\'ların sürüm, durum, mesaj trafiği, bağlantı ve kaynak kullanımı özetini tek sayfada gösterir.', r: 'Gerçek IBM MQ Console\'da her QM\'in Overview sekmesi benzer bilgiler sunar; bu sayfa eğitim için tüm QM\'leri bir araya getirir.', p: 'Genel durum farkındalığı.', n: 'Vardiya başlangıcında ve sorun anında.', b: 'Sorunlu bileşenlere hızlı yönlendirme.', e: 'Gösterge paneli → sağlık tablosu → QMGW01', x: 'Özet değerler örnek verilerdir; gerçek ortamda izleme araçlarının eşik değerleri kurumunuza göre ayarlanmalıdır.', l: ['health', 'monitoring'] });
  h('settings', { t: 'Ayarlar', c: 'Konsol', w: 'Tema, açıklama simgeleri ve simülasyon verilerinin yönetildiği sayfadır.', r: 'Gerçek Console\'da kullanıcı tercihleri (tema, dil, tablo yoğunluğu) mqweb tarafından kullanıcı başına saklanır.', p: 'Arayüzü kişiselleştirmek.', n: 'İhtiyaç halinde.', b: 'Konfor.', e: 'Ayarlar → Tema → Açık', x: '-', l: ['theme', 'helpicons'] });
  h('theme', { t: 'Tema', c: 'Konsol', w: 'Koyu (Carbon g100) veya açık (Carbon white) görünüm seçer.', r: 'IBM MQ Console IBM Carbon tasarım sistemini kullanır.', p: 'Görsel tercih ve erişilebilirlik.', n: 'İsteğe bağlı.', b: 'Uzun süreli kullanımda göz konforu.', e: '-', x: '-', l: ['settings'] });
  h('helpicons', { t: 'Açıklama simgeleri (?)', c: 'Konsol', w: 'Arayüzdeki tüm ? simgelerini gösterir veya gizler.', r: 'Gizlendiğinde konsol gerçek MQ Console\'a daha çok benzer.', p: 'Öğrenme modu ile sade mod arasında geçiş.', n: 'Konsolu tanıdıktan sonra sade görünüm için kapatabilirsiniz.', b: '-', e: '-', x: 'Kapalıyken açıklamalara yalnızca Öğrenme kaynakları sayfasından ulaşılır.', l: ['learning'] });
  h('mqwebuser', { t: 'Console kullanıcısı', c: 'Konsol', w: 'MQ Console\'a giriş yapan kullanıcıdır.', r: 'mqweb, kullanıcıları mqwebuser.xml\'de tanımlı kayıt (basic registry, LDAP) ile doğrular ve rollere eşler. QM üzerindeki işlemler bu kullanıcının kimliğiyle OAM denetiminden geçer (MQWebAdmin rolü hariç).', p: 'Kimlik doğrulama ve yetkilendirme.', n: 'Her oturumda.', b: 'Kim ne yaptı izlenebilir.', e: '<user name="mqadmin" password="{aes}..."/>', x: 'Varsayılan örnek mqwebuser.xml\'i (basic_registry) parolalarıyla üretimde bırakmak ciddi güvenlik açığıdır.', l: ['mqwebroles'] });
  h('mqwebroles', { t: 'mqweb rolleri', c: 'Konsol', m: 'MQWebAdmin / MQWebAdminRO / MQWebUser',
    w: 'MQ Console ve REST API erişim rolleridir.', r: 'MQWebAdmin: tüm işlemleri mqweb sunucusunu çalıştıran işletim sistemi kullanıcısı (genelde mqm) yetkisiyle yapar. MQWebAdminRO: salt okunur. MQWebUser: işlemleri oturum açan kullanıcının kendi kimliğiyle yapar; OAM yetkileri uygulanır.',
    p: 'Console erişimini rol bazlı kısıtlamak.', n: 'Ekip üyelerine ihtiyaç kadar yetki vermek için.', b: 'En az yetki ilkesi; denetlenebilirlik.',
    e: '<security-role name="MQWebUser">\n  <group name="mqoperators"/>\n</security-role>', x: 'Herkese MQWebAdmin vermek, kullanıcıların mqm yetkisiyle her şeyi yapabilmesi demektir.', l: ['mqwebuser', 'oam'] });
})();
