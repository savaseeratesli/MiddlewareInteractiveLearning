/* Simülasyon verileri. Tüm nesneler kurgusaldır ve birbiriyle tutarlıdır:
   - QMGW01 ve QMCORE01 CLS.ODEME cluster'ının full repository üyeleridir, QMBATCH01 partial repository'dir.
   - QMBATCH01 üzerindeki LST.TCP.1415 listener'ı durdurulduğu için QMGW01.QMBATCH01 sender channel'ı RETRYING durumundadır
     ve QMBATCH01 transmission queue'sunda mesajlar birikmiştir. (Listener'ı başlatmayı deneyin!)
   - APP.LOG.AUDIT kuyruğu doludur (MAXDEPTH'e ulaşmıştır), APP.RAPOR.BATCH yüksek derinlik uyarısındadır. */
(function () {
  'use strict';
  var MQ = window.MQ;

  var QDEF = {
    type: 'QLOCAL', usage: 'NORMAL', system: false, descr: '', curdepth: 0, maxdepth: 5000, ipprocs: 0, opprocs: 0,
    get: 'ENABLED', put: 'ENABLED', defprty: 0, defpsist: 'NO', share: 'SHARE', defsopt: 'SHARED', maxmsgl: 4194304,
    trigger: false, trigtype: 'FIRST', trigdata: '', trigdpth: 1, trigmpri: 0, initq: '', process: '',
    bothresh: 0, boqname: '', harden: 'HARDENBO', qdepthhi: 80, qdepthlo: 20, qdphiev: 'DISABLED', qdploev: 'DISABLED', qdpmaxev: 'ENABLED',
    qsvciev: 'NONE', qsvcint: 999999999, msgdlvsq: 'PRIORITY', defbind: 'OPEN', defpresp: 'SYNC', defreada: 'NO', npmclass: 'NORMAL',
    cluster: '', clusnl: '', clwlprty: 0, clwlrank: 0, clwluseq: 'QMGR', monq: 'QMGR', statq: 'QMGR', acctq: 'QMGR', retintvl: 999999999,
    scope: 'QMGR', streamq: '', strmqos: 'BESTEF', maxfsize: 'DEFAULT', propctl: 'COMPAT',
    rname: '', rqmname: '', xmitq: '', target: '', targtype: 'QUEUE', deftype: 'PREDEFINED', clusqmgr: '',
    lput: '', lget: '', msgage: 0, uncom: 0, qtime: '', created: '2025-03-11 10:14:22', altered: '2026-10-02 09:41:05', messages: null
  };
  function q(o) { var r = MQ.clone(QDEF); for (var k in o) r[k] = o[k]; if (r.type === 'QMODEL' && r.deftype === 'PREDEFINED') r.deftype = 'TEMPDYN'; return r; }

  function sysQueues(qm, extra) {
    extra = extra || {};
    var list = [
      ['SYSTEM.ADMIN.ACCOUNTING.QUEUE', 0, 3000], ['SYSTEM.ADMIN.ACTIVITY.QUEUE', 0, 3000], ['SYSTEM.ADMIN.CHANNEL.EVENT', 9, 3000],
      ['SYSTEM.ADMIN.COMMAND.EVENT', 0, 3000], ['SYSTEM.ADMIN.COMMAND.QUEUE', 0, 3000, 1, 1], ['SYSTEM.ADMIN.CONFIG.EVENT', 2, 3000],
      ['SYSTEM.ADMIN.LOGGER.EVENT', 0, 3000], ['SYSTEM.ADMIN.PERFM.EVENT', 6, 3000], ['SYSTEM.ADMIN.PUBSUB.EVENT', 0, 3000],
      ['SYSTEM.ADMIN.QMGR.EVENT', 1, 3000], ['SYSTEM.ADMIN.STATISTICS.QUEUE', 0, 3000], ['SYSTEM.ADMIN.TRACE.ACTIVITY.QUEUE', 0, 3000],
      ['SYSTEM.AUTH.DATA.QUEUE', 64, 999999999, 1, 1], ['SYSTEM.CHANNEL.INITQ', 0, 1000, 1, 0], ['SYSTEM.CHANNEL.SYNCQ', 2, 20000, 1, 1],
      ['SYSTEM.CHLAUTH.DATA.QUEUE', 6, 999999999, 1, 1], ['SYSTEM.CLUSTER.COMMAND.QUEUE', 0, 999999999, 1, 0], ['SYSTEM.CLUSTER.HISTORY.QUEUE', 3, 999999999],
      ['SYSTEM.CLUSTER.REPOSITORY.QUEUE', 14, 999999999, 1, 1], ['SYSTEM.CLUSTER.TRANSMIT.QUEUE', 0, 999999999, 1, 1], ['SYSTEM.DDELAY.LOCAL.QUEUE', 0, 999999999],
      ['SYSTEM.DEFAULT.INITIATION.QUEUE', 0, 5000], ['SYSTEM.DEFAULT.LOCAL.QUEUE', 0, 5000], ['SYSTEM.DURABLE.SUBSCRIBER.QUEUE', 3, 999999999, 1, 1],
      ['SYSTEM.HIERARCHY.STATE', 0, 999999999, 1, 1], ['SYSTEM.INTER.QMGR.CONTROL', 0, 999999999, 1, 0], ['SYSTEM.INTER.QMGR.FANREQ', 0, 999999999, 1, 0],
      ['SYSTEM.INTER.QMGR.PUBS', 0, 999999999, 1, 0], ['SYSTEM.INTERNAL.REPLY.QUEUE', 0, 999999999, 1, 1], ['SYSTEM.PENDING.DATA.QUEUE', 0, 999999999],
      ['SYSTEM.PROTECTION.ERROR.QUEUE', 0, 5000], ['SYSTEM.RETAINED.PUB.QUEUE', 2, 999999999], ['SYSTEM.SELECTION.EVALUATION.QUEUE', 0, 999999999, 1, 0],
      ['SYSTEM.SELECTION.VALIDATION.QUEUE', 0, 999999999]
    ];
    var r = list.map(function (a) {
      var o = { name: a[0], system: true, curdepth: extra[a[0]] !== undefined ? extra[a[0]] : a[1], maxdepth: a[2], ipprocs: a[3] || 0, opprocs: a[4] || 0, created: qm.created, altered: qm.created };
      if (a[0] === 'SYSTEM.CLUSTER.TRANSMIT.QUEUE') o.usage = 'XMITQ';
      if (a[0] === 'SYSTEM.CHANNEL.INITQ' || a[0] === 'SYSTEM.DEFAULT.INITIATION.QUEUE') o.role = 'initq';
      if (/EVENT|DATA|REPOSITORY|SYNCQ|AUTH/.test(a[0])) o.defpsist = 'YES';
      return q(o);
    });
    r.push(q({ name: 'SYSTEM.DEAD.LETTER.QUEUE', system: true, curdepth: extra['SYSTEM.DEAD.LETTER.QUEUE'] || 0, maxdepth: 50000, defpsist: 'YES', created: qm.created, altered: qm.created, opprocs: 0 }));
    r.push(q({ name: 'SYSTEM.DEFAULT.ALIAS.QUEUE', type: 'QALIAS', system: true, target: '', created: qm.created }));
    r.push(q({ name: 'SYSTEM.DEFAULT.REMOTE.QUEUE', type: 'QREMOTE', system: true, created: qm.created }));
    r.push(q({ name: 'SYSTEM.DEFAULT.MODEL.QUEUE', type: 'QMODEL', system: true, deftype: 'TEMPDYN', created: qm.created }));
    r.push(q({ name: 'SYSTEM.DURABLE.MODEL.QUEUE', type: 'QMODEL', system: true, deftype: 'PERMDYN', maxdepth: 999999999, created: qm.created }));
    r.push(q({ name: 'SYSTEM.NDURABLE.MODEL.QUEUE', type: 'QMODEL', system: true, deftype: 'TEMPDYN', maxdepth: 999999999, created: qm.created }));
    r.push(q({ name: 'SYSTEM.MQEXPLORER.REPLY.MODEL', type: 'QMODEL', system: true, deftype: 'TEMPDYN', created: qm.created }));
    return r;
  }

  var CHDEF = {
    chltype: 'SDR', status: 'Inactive', descr: '', conname: '', xmitq: '', trptype: 'TCP', hbint: 300, batchsz: 50, batchint: 0, batchhb: 0,
    mrrty: 10, mrtmr: 1000, shortrty: 10, shorttmr: 60, longrty: 999999999, longtmr: 1200, discint: 6000, kaint: 'AUTO', npmspeed: 'FAST',
    sslciph: '', sslcauth: 'REQUIRED', sslpeer: '', certlabl: '', mcauser: '', mcatype: 'PROCESS', maxmsgl: 4194304, monchl: 'QMGR', statchl: 'QMGR',
    sharecnv: 10, maxinst: 999999999, maxinstc: 999999999, cluster: '', clusnl: '', clwlprty: 0, clwlrank: 0, clwlwght: 50, netprty: 0,
    compmsg: 'NONE', comphdr: 'NONE', seqwrap: 999999999, convert: 'NO', usedlq: 'YES', qmname: '', defrecon: 'NO',
    altered: '2026-09-18 14:02:44', inst: null, st: null
  };
  function ch(o) {
    var r = MQ.clone(CHDEF); for (var k in o) r[k] = o[k];
    if (r.chltype === 'SVRCONN') { r.discint = o.discint !== undefined ? o.discint : 0; r.hbint = o.hbint !== undefined ? o.hbint : 300; }
    if (r.chltype === 'CLNTCONN') { r.status = 'N/A'; }
    if (r.chltype === 'RCVR' || r.chltype === 'SVRCONN' || r.chltype === 'RQSTR' || r.chltype === 'CLUSRCVR') { if (o.discint === undefined && r.chltype !== 'SVRCONN') r.discint = 6000; }
    return r;
  }

  /* -------- Mesaj üretici: kuyruğa göre gerçekçi gövdeler -------- */
  function seeded(str) { var h = 2166136261; for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return function () { h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); return ((h ^= h >>> 16) >>> 0) / 4294967296; }; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function strHex(s, len) { var h = ''; for (var i = 0; i < len; i++) { var c = i < s.length ? s.charCodeAt(i) : 32; h += (c < 16 ? '0' : '') + c.toString(16).toUpperCase(); } return h; }
  MQ.msgId = function (qmName, r) { var h = '414D5120' + strHex(qmName, 12); for (var i = 0; i < 16; i++) h += '0123456789ABCDEF'[Math.floor((r ? r() : Math.random()) * 16)]; return h; };
  MQ.genMessage = function (qm, queue, i, r) {
    r = r || Math.random;
    var n = queue.name, d = new Date(2026, 10, 23, 11, 40, 0); d.setMinutes(d.getMinutes() - Math.floor(r() * 600) - i * 3);
    if (queue.msgage > 86400) d.setDate(d.getDate() - Math.floor(queue.msgage / 86400) + Math.floor(r() * 2));
    var ts = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    var m = { msgid: MQ.msgId(qm.name, r), correlid: '000000000000000000000000000000000000000000000000', puttime: ts, putappl: 'odeme-api.jar', userid: 'odemeapp',
      format: 'MQSTR', persist: queue.defpsist === 'YES' ? 'Persistent' : 'Not persistent', priority: queue.defprty, expiry: -1, msgtype: 'Datagram',
      replytoq: '', replytoqmgr: qm.name, encoding: 546, ccsid: 1208, backout: 0, body: '' };
    var id = 2026112300100 + Math.floor(r() * 89999);
    if (/ODEME\.ISTEK|^QA\.ODEME/.test(n)) {
      m.msgtype = 'Request'; m.replytoq = 'APP.ODEME.YANIT'; m.priority = r() > 0.8 ? 7 : 4; m.expiry = 3000;
      m.body = JSON.stringify({ islemId: 'TRX-' + id, tutar: Math.round(r() * 500000) / 100, paraBirimi: 'TRY', kaynakHesap: 'TR00 0001 0000 ' + Math.floor(1000 + r() * 8999) + ' 0000 0000 01', hedefHesap: 'TR00 0002 0000 ' + Math.floor(1000 + r() * 8999) + ' 0000 0000 02', kanal: r() > 0.5 ? 'MOBIL' : 'INTERNET' }, null, 2);
    } else if (/ODEME\.YANIT/.test(n)) {
      m.msgtype = 'Reply'; m.correlid = MQ.msgId(qm.name, r); m.putappl = 'ilGateway.WindowsService.exe'; m.userid = 'mobilapp'; m.expiry = 600;
      m.body = JSON.stringify({ islemId: 'TRX-' + id, sonuc: r() > 0.1 ? 'ONAYLANDI' : 'RED', hataKodu: null }, null, 2);
    } else if (/BACKOUT/.test(n)) {
      m.backout = 3 + Math.floor(r() * 2); m.priority = 4;
      m.body = '{\n  "islemId": "TRX-' + id + '",\n  "tutar": "12a5,00"\n}\n/* Uygulama bu mesajı ' + m.backout + ' kez işleyemedi (geçersiz tutar biçimi). BOTHRESH aşıldığı için backout kuyruğuna taşındı. */';
    } else if (/FATURA/.test(n)) {
      m.putappl = 'FaturaAdapter'; m.userid = 'faturaapp';
      m.body = '<?xml version="1.0" encoding="UTF-8"?>\n<Fatura>\n  <No>FTR' + id + '</No>\n  <MusteriNo>' + Math.floor(100000 + r() * 899999) + '</MusteriNo>\n  <Tutar paraBirimi="TRY">' + (r() * 9000).toFixed(2) + '</Tutar>\n</Fatura>';
    } else if (/RAPOR/.test(n)) {
      m.putappl = 'rapor_uretici'; m.userid = 'batchusr'; m.persist = 'Persistent';
      m.body = 'SUBE;TARIH;ISLEM_SAYISI;TOPLAM\n' + (100 + Math.floor(r() * 800)) + ';2026-11-22;' + Math.floor(r() * 5000) + ';' + (r() * 1e6).toFixed(2);
    } else if (/AUDIT/.test(n)) {
      m.putappl = 'audit-collector'; m.userid = 'auditapp';
      m.body = JSON.stringify({ zaman: ts, kullanici: 'u' + Math.floor(r() * 9999), olay: ['LOGIN', 'TRANSFER', 'LOGOUT', 'PROFIL_GUNCELLE'][Math.floor(r() * 4)], ip: '10.20.40.' + Math.floor(r() * 250) }, null, 2);
    } else if (/SMS|EPOSTA/.test(n)) {
      m.putappl = 'amqfqpub'; m.userid = 'mqm'; m.format = 'MQSTR';
      m.body = JSON.stringify({ topic: 'bildirim/musteri', musteriNo: Math.floor(100000 + r() * 899999), mesaj: 'Hesabınıza ' + (r() * 5000).toFixed(2) + ' TL yatırıldı.' }, null, 2);
    } else if (n === 'SYSTEM.DEAD.LETTER.QUEUE') {
      var reasons = [['2085', 'MQRC_UNKNOWN_OBJECT_NAME', 'APP.HESAP.INN'], ['2053', 'MQRC_Q_FULL', 'APP.LOG.AUDIT'], ['2051', 'MQRC_PUT_INHIBITED', 'APP.KAMPANYA.ESKI'], ['2030', 'MQRC_MSG_TOO_BIG_FOR_Q', 'APP.ODEME.ISTEK']];
      var rs = reasons[Math.floor(r() * reasons.length)];
      m.format = 'MQDEAD'; m.putappl = 'amqrmppa'; m.userid = 'mqm'; m.persist = 'Persistent';
      m.dlh = { reason: rs[0] + ' (' + rs[1] + ')', destq: rs[2], destqmgr: qm.name === 'QMGW01' ? 'QMCORE01' : qm.name, putapplname: 'amqrmppa' };
      m.body = '[MQDLH] Reason=' + rs[0] + ' (' + rs[1] + ')\n        DestQName=' + rs[2] + '\n        DestQMgrName=' + m.dlh.destqmgr + '\n        Format=MQSTR\n[Orijinal veri]\n{"islemId":"TRX-' + id + '"}';
    } else if (queue.usage === 'XMITQ') {
      m.format = 'MQXMIT'; m.putappl = 'odeme-api.jar'; m.persist = 'Persistent';
      m.body = '[MQXQH] RemoteQName=APP.GUNSONU.IN\n        RemoteQMgrName=' + n + '\n[MQMD + uygulama verisi]\nGUNSONU;2026-11-22;KAPANIS;' + Math.floor(r() * 99999);
    } else {
      m.putappl = 'amqsput'; m.userid = 'mqtest';
      m.body = 'Test mesajı #' + (i + 1) + ' - ' + n;
    }
    m.size = m.body.length;
    return m;
  };
  MQ.ensureMsgs = function (qm, queue) {
    if (queue.type !== 'QLOCAL') return [];
    if (!queue.messages) {
      var r = seeded(qm.name + queue.name); queue.messages = [];
      for (var i = 0; i < Math.min(queue.curdepth, 40); i++) queue.messages.push(MQ.genMessage(qm, queue, i, r));
      queue.messages.sort(function (a, b) { return b.priority - a.priority || (a.puttime < b.puttime ? -1 : 1); });
    }
    while (queue.messages.length < Math.min(queue.curdepth, 40)) queue.messages.push(MQ.genMessage(qm, queue, queue.messages.length, Math.random));
    if (queue.messages.length > queue.curdepth) queue.messages.length = queue.curdepth;
    return queue.messages;
  };

  function hours() { var a = []; for (var i = 23; i >= 0; i--) { var h = (11 - i + 24) % 24; a.push(pad(h) + ':00'); } return a; }
  function series(seed, base, amp, peakHour) {
    var r = seeded(seed); return hours().map(function (l, i) { var h = parseInt(l, 10); var day = h >= 8 && h <= 19 ? 1 : 0.25; var pk = Math.abs(h - peakHour) < 2 ? 1.6 : 1; return Math.round((base + r() * amp) * day * pk); });
  }

  var QMATTR = {
    CCSID: 1208, DESCR: '', SCMDSERV: 'QMGR', SCHINIT: 'QMGR', MAXMSGL: 4194304, MAXHANDS: 256, MAXUMSGS: 10000, MAXPRTY: 9,
    DEADQ: 'SYSTEM.DEAD.LETTER.QUEUE', DEFXMITQ: '', TRIGINT: 999999999, SYNCPT: 'Available', CHLAUTH: 'ENABLED', CONNAUTH: 'SYSTEM.DEFAULT.AUTHINFO.IDPWOS',
    MAXPROPL: 'NOLIMIT', CUSTOM: '', REVDNS: 'ENABLED', ADVCAP: 'ENABLED',
    CLWLDATA: '', CLWLEXIT: '', CLWLLEN: 100, CLWLMRUC: 999999999, CLWLUSEQ: 'LOCAL', DEFCLXQ: 'SCTQ', REPOS: '', REPOSNL: '',
    CHAD: 'DISABLED', CHADEV: 'DISABLED', CHADEXIT: '', IPADDRV: 'IPV4', ACTIVREC: 'MSG', ROUTEREC: 'MSG',
    AUTHOREV: 'DISABLED', INHIBTEV: 'DISABLED', LOCALEV: 'DISABLED', REMOTEEV: 'DISABLED', STRSTPEV: 'ENABLED', PERFMEV: 'DISABLED',
    CHLEV: 'DISABLED', SSLEV: 'DISABLED', CONFIGEV: 'DISABLED', CMDEV: 'DISABLED', LOGGEREV: 'DISABLED',
    SSLKEYR: '', CERTLABL: '', SSLFIPS: 'NO', SSLRKEYC: 0, SSLCRLNL: '', SSLCRYP: '',
    STATMQI: 'OFF', STATQ: 'OFF', STATCHL: 'OFF', STATINT: 1800, STATACLS: 'QMGR', ACTVTRC: 'OFF', ACTVCONO: 'DISABLED',
    MONQ: 'OFF', MONCHL: 'OFF', MONACLS: 'QMGR', ACCTMQI: 'OFF', ACCTQ: 'OFF', ACCTINT: 1800, ACCTCONO: 'DISABLED',
    PSMODE: 'ENABLED', PSRTYCNT: 5, PSNPMSG: 'DISCARD', PSNPRES: 'NORMAL', PSSYNCPT: 'IFPER', TREELIFE: 1800, PSCLUS: 'ENABLED',
    IMGSCHED: 'MANUAL', IMGINTVL: 60, IMGLOGLN: 'OFF', IMGRCOVO: 'YES', IMGRCOVQ: 'YES'
  };
  function attrs(o) { var r = MQ.clone(QMATTR); for (var k in o) r[k] = o[k]; return r; }

  function defaultChlauth() {
    return [
      { profile: 'SYSTEM.*', type: 'ADDRESSMAP', match: "ADDRESS('*')", usersrc: 'NOACCESS', mcauser: '', chckclnt: 'ASQMGR', warn: 'NO', descr: 'Varsayılan kural: SYSTEM.* kanallarına uzaktan erişimi engeller', def: true },
      { profile: 'SYSTEM.ADMIN.SVRCONN', type: 'ADDRESSMAP', match: "ADDRESS('*')", usersrc: 'CHANNEL', mcauser: '', chckclnt: 'REQUIRED', warn: 'NO', descr: 'Varsayılan kural: yönetim kanalı için kimlik doğrulama zorunlu', def: true },
      { profile: '*', type: 'BLOCKUSER', match: "USERLIST('*MQADMIN')", usersrc: '', mcauser: '', chckclnt: '', warn: 'NO', descr: 'Varsayılan kural: MQ yöneticilerinin istemci kanallarından bağlanmasını engeller', def: true }
    ];
  }
  function defaultAuthinfo() {
    return [
      { name: 'SYSTEM.DEFAULT.AUTHINFO.IDPWOS', authtype: 'IDPWOS', chckclnt: 'REQDADM', chcklocl: 'OPTIONAL', adoptctx: 'YES', failDelay: 1, conname: '', descr: 'İşletim sistemi kullanıcı/parola doğrulaması' },
      { name: 'SYSTEM.DEFAULT.AUTHINFO.IDPWLDAP', authtype: 'IDPWLDAP', chckclnt: 'REQDADM', chcklocl: 'OPTIONAL', adoptctx: 'YES', failDelay: 1, conname: '', descr: 'LDAP tabanlı kullanıcı/parola doğrulaması (şablon)' },
      { name: 'SYSTEM.DEFAULT.AUTHINFO.CRLLDAP', authtype: 'CRLLDAP', chckclnt: '', chcklocl: '', adoptctx: '', failDelay: '', conname: '', descr: 'LDAP sunucusundan CRL denetimi (şablon)' },
      { name: 'SYSTEM.DEFAULT.AUTHINFO.OCSP', authtype: 'OCSP', chckclnt: '', chcklocl: '', adoptctx: '', failDelay: '', conname: '', descr: 'OCSP ile sertifika iptal denetimi (şablon)' }
    ];
  }

  MQ.seed = function () {
    var S = { created: MQ.now(), qmgrs: [], remoteQmgrs: [], user: { name: 'mqadmin', role: 'MQWebAdmin' } };

    /* ============================ QMGW01 ============================ */
    var gw = {
      name: 'QMGW01', status: 'Running', version: '9.4.0.26', cmdlevel: 940, platform: 'Unix', os: 'Linux x86-64 (Red Hat Enterprise Linux 9.4)',
      host: 'mqgw01.ornek.local', ip: '10.10.10.21', port: 1414, isDefault: true, installation: 'Installation1', instPath: '/opt/mqm',
      dataPath: '/var/mqm/qmgrs/QMGW01', created: '2025-03-11 10:02:51', started: '2026-11-02 03:15:44', ha: 'Yok (tek instance)',
      logType: 'CIRCULAR', logPrimary: 10, logSecondary: 5, logFilePages: 16384, logPath: '/var/mqm/log/QMGW01/active/', logWriteIntegrity: 'TripleWrite',
      cpu: 3.4, mem: 21.6, storageMB: 1874, diskMB: 20480,
      attrs: attrs({ DESCR: 'Ödeme ağ geçidi - istemci uygulamalarının giriş noktası', REPOS: 'CLS.ODEME', PERFMEV: 'ENABLED', CHLEV: 'ENABLED', SSLEV: 'ENABLED', CONFIGEV: 'ENABLED', AUTHOREV: 'ENABLED',
        SSLKEYR: '/var/mqm/qmgrs/QMGW01/ssl/key', CERTLABL: 'ibmwebspheremqqmgw01', MONQ: 'MEDIUM', MONCHL: 'MEDIUM', STATMQI: 'ON', STATQ: 'ON', STATCHL: 'MEDIUM', STATINT: 900, MAXHANDS: 512 }),
      stats: { puts: series('gwp', 900, 400, 10), gets: series('gwg', 880, 380, 10), cpu: series('gwc', 2, 4, 10), mem: series('gwm', 18, 5, 14), msgsLastHour: 4760, bytesIn: 11.13, bytesOut: 11.17 }
    };
    gw.queues = [
      q({ name: 'APP.ODEME.ISTEK', descr: 'Ödeme isteği giriş kuyruğu (request)', curdepth: 12, maxdepth: 50000, ipprocs: 4, opprocs: 3, defpsist: 'YES', defprty: 4, maxmsgl: 1048576, bothresh: 3, boqname: 'APP.ODEME.BACKOUT', qdphiev: 'ENABLED', monq: 'MEDIUM', lput: '2026-11-23 11:42:18', lget: '2026-11-23 11:42:19', msgage: 2, qtime: '1250, 980', created: '2025-03-11 10:20:05' }),
      q({ name: 'APP.ODEME.YANIT', descr: 'Ödeme yanıtları (reply-to queue)', curdepth: 3, maxdepth: 50000, ipprocs: 2, opprocs: 4, lput: '2026-11-23 11:42:19', lget: '2026-11-23 11:42:19', msgage: 1, qtime: '840, 610' }),
      q({ name: 'APP.ODEME.BACKOUT', descr: 'İşlenemeyen (poison) ödeme mesajları', curdepth: 7, maxdepth: 5000, opprocs: 0, defpsist: 'YES', lput: '2026-11-23 09:12:40', msgage: 9200 }),
      q({ name: 'APP.FATURA.IN', descr: 'Fatura mesajları - tetiklemeli (trigger) işleme', curdepth: 0, maxdepth: 10000, defpsist: 'YES', trigger: true, trigtype: 'FIRST', initq: 'APP.TRIGGER.INITQ', process: 'FATURA.PROC', trigdata: 'FATURA', opprocs: 1, lput: '2026-11-23 10:05:12', lget: '2026-11-23 10:05:13' }),
      q({ name: 'APP.TRIGGER.INITQ', descr: 'Uygulama initiation queue (runmqtrm dinliyor)', role: 'initq', curdepth: 0, maxdepth: 1000, ipprocs: 1, lput: '2026-11-23 10:05:12', lget: '2026-11-23 10:05:12' }),
      q({ name: 'APP.RAPOR.BATCH', descr: 'Gece raporları - tüketici yavaş', curdepth: 4150, maxdepth: 5000, opprocs: 1, defpsist: 'YES', qdphiev: 'ENABLED', qdepthhi: 80, lput: '2026-11-23 11:40:02', lget: '2026-11-22 23:10:05', msgage: 45600 }),
      q({ name: 'APP.LOG.AUDIT', descr: 'Denetim kayıtları - tüketici uygulama durmuş', curdepth: 20000, maxdepth: 20000, opprocs: 2, qdphiev: 'ENABLED', qdpmaxev: 'ENABLED', lput: '2026-11-23 11:38:51', lget: '2026-11-21 06:12:00', msgage: 192600 }),
      q({ name: 'APP.SMS.IN', descr: 'SUB.BILDIRIM.SMS aboneliğinin hedef kuyruğu', curdepth: 41, maxdepth: 10000, ipprocs: 1, lput: '2026-11-23 11:41:07', lget: '2026-11-23 11:41:00', msgage: 30 }),
      q({ name: 'APP.EPOSTA.IN', descr: 'SUB.BILDIRIM.EPOSTA aboneliğinin hedef kuyruğu', curdepth: 0, maxdepth: 10000, ipprocs: 1, lput: '2026-11-23 11:41:07', lget: '2026-11-23 11:41:07' }),
      q({ name: 'APP.MUSTERI.BILGI', descr: 'Cluster\'a duyurulmuş müşteri bilgi kuyruğu', curdepth: 5, maxdepth: 20000, ipprocs: 2, cluster: 'CLS.ODEME', defbind: 'NOTFIXED', clwlprty: 5, lput: '2026-11-23 11:30:10', lget: '2026-11-23 11:30:12' }),
      q({ name: 'APP.KAMPANYA.ESKI', descr: 'Kullanımdan kaldırılan kampanya kuyruğu (GET/PUT inhibited)', curdepth: 15, maxdepth: 5000, get: 'DISABLED', put: 'DISABLED', lput: '2026-08-01 17:00:00', msgage: 9936000 }),
      q({ name: 'QMCORE01', usage: 'XMITQ', descr: 'QMCORE01 için transmission queue', curdepth: 0, maxdepth: 50000, defpsist: 'YES', ipprocs: 1, opprocs: 0, trigger: true, trigtype: 'FIRST', initq: 'SYSTEM.CHANNEL.INITQ', trigdata: 'QMGW01.QMCORE01', lput: '2026-11-23 11:42:10', lget: '2026-11-23 11:42:10' }),
      q({ name: 'QMBATCH01', usage: 'XMITQ', descr: 'QMBATCH01 için transmission queue (channel RETRYING)', curdepth: 128, maxdepth: 50000, defpsist: 'YES', trigger: true, trigtype: 'FIRST', initq: 'SYSTEM.CHANNEL.INITQ', trigdata: 'QMGW01.QMBATCH01', lput: '2026-11-23 11:39:44', lget: '2026-11-23 08:58:02', msgage: 9900 }),
      q({ name: 'QMPARTNER', usage: 'XMITQ', descr: 'Partner kurum için transmission queue (server channel)', curdepth: 54, maxdepth: 50000, defpsist: 'YES', lput: '2026-11-23 11:20:00', lget: '2026-11-22 18:00:00', msgage: 63000 }),
      q({ name: 'QR.CORE.HESAP', type: 'QREMOTE', descr: 'QMCORE01 üzerindeki APP.HESAP.IN kuyruğunun yerel tanımı', rname: 'APP.HESAP.IN', rqmname: 'QMCORE01', xmitq: 'QMCORE01', defpsist: 'YES' }),
      q({ name: 'QR.BATCH.GUNSONU', type: 'QREMOTE', descr: 'Gün sonu mesajları QMBATCH01\'e', rname: 'APP.GUNSONU.IN', rqmname: 'QMBATCH01', xmitq: 'QMBATCH01', defpsist: 'YES' }),
      q({ name: 'QR.PARTNER.MUTABAKAT', type: 'QREMOTE', descr: 'Partner kurum mutabakat kuyruğu', rname: 'PARTNER.MUTABAKAT.IN', rqmname: 'QMPARTNER', xmitq: 'QMPARTNER', defpsist: 'YES' }),
      q({ name: 'QMALIAS.CORE', type: 'QREMOTE', descr: 'Queue manager alias: RNAME boş, mesajlar QMCORE01\'e yönlendirilir', rname: '', rqmname: 'QMCORE01', xmitq: '' }),
      q({ name: 'QA.ODEME', type: 'QALIAS', descr: 'Uygulamaların kullandığı mantıksal ad', target: 'APP.ODEME.ISTEK', targtype: 'QUEUE', defpsist: 'YES' }),
      q({ name: 'QA.BILDIRIM', type: 'QALIAS', descr: 'Topic\'e yayın yapan alias (TARGTYPE TOPIC)', target: 'BILDIRIM.TOPIC', targtype: 'TOPIC' }),
      q({ name: 'APP.REPLY.MODEL', type: 'QMODEL', descr: 'Geçici yanıt kuyrukları için model', deftype: 'TEMPDYN', maxdepth: 5000 }),
      q({ name: 'APP.KALICI.MODEL', type: 'QMODEL', descr: 'Kalıcı dinamik kuyruklar için model', deftype: 'PERMDYN', defpsist: 'YES', maxdepth: 20000 }),
      q({ name: 'APP.HESAP.SORGU', type: 'QCLUSTER', descr: 'Cluster queue - QMCORE01 üzerinde barınıyor', cluster: 'CLS.ODEME', clusqmgr: 'QMCORE01', defbind: 'NOTFIXED' }),
      q({ name: 'APP.KREDI.SKOR', type: 'QCLUSTER', descr: 'Cluster queue - QMCORE01 ve QMBATCH01 üzerinde (iş yükü dengelemeli)', cluster: 'CLS.ODEME', clusqmgr: 'QMCORE01, QMBATCH01', defbind: 'NOTFIXED' })
    ].concat(sysQueues(gw, { 'SYSTEM.DEAD.LETTER.QUEUE': 23 }));

    gw.channels = [
      ch({ name: 'QMGW01.QMCORE01', chltype: 'SDR', status: 'Running', descr: 'QMCORE01\'e giden sender', conname: 'mqcore01.ornek.local(1414)', xmitq: 'QMCORE01', sslciph: 'TLS_AES_256_GCM_SHA384', certlabl: 'ibmwebspheremqqmgw01', mcauser: '', monchl: 'MEDIUM',
        st: { msgs: 182344, batches: 9120, bytessent: 412339201, bytesrcvd: 1192331, lstmsg: '2026-11-23 11:42:10', xqtime: '820, 640', nettime: '1350, 1120', substate: 'MQGET', curseqno: 182344, buffers: '182500, 9300', rqmname: 'QMCORE01', started: '2026-11-02 03:16:02', sslpeer: 'CN=QMCORE01,OU=MQ,O=Ornek Banka,C=TR' } }),
      ch({ name: 'QMCORE01.QMGW01', chltype: 'RCVR', status: 'Running', descr: 'QMCORE01\'den gelen receiver', sslciph: 'TLS_AES_256_GCM_SHA384', sslcauth: 'REQUIRED', sslpeer: 'CN=QMCORE01,OU=MQ,O=Ornek Banka,C=TR', mcauser: 'mqchl', monchl: 'MEDIUM',
        st: { msgs: 179210, batches: 8955, bytessent: 1102231, bytesrcvd: 398201120, lstmsg: '2026-11-23 11:42:19', xqtime: '', nettime: '', substate: 'RECEIVE', curseqno: 179210, conname: '10.10.10.31', rqmname: 'QMCORE01', started: '2026-11-02 03:16:05' } }),
      ch({ name: 'QMGW01.QMBATCH01', chltype: 'SDR', status: 'Retrying', descr: 'QMBATCH01\'e giden sender (karşı tarafta listener kapalı)', conname: 'mqbatch01.ornek.local(1415)', xmitq: 'QMBATCH01', sslciph: 'ANY_TLS12_OR_HIGHER', shortrty: 10, shorttmr: 60,
        st: { msgs: 0, batches: 0, bytessent: 0, bytesrcvd: 0, lstmsg: '2026-11-23 08:58:02', substate: '', curseqno: 55012, retries: 'Short retry 7/10, sonraki deneme 60 sn', rqmname: 'QMBATCH01', started: '' } }),
      ch({ name: 'QMBATCH01.QMGW01', chltype: 'RCVR', status: 'Inactive', descr: 'QMBATCH01\'den gelen receiver', sslciph: 'ANY_TLS12_OR_HIGHER', mcauser: 'mqchl' }),
      ch({ name: 'QMGW01.QMPARTNER', chltype: 'SVR', status: 'Stopped', descr: 'Partner kuruma server channel (bakım nedeniyle durduruldu)', conname: 'mq.partner.example(1414)', xmitq: 'QMPARTNER', sslciph: 'TLS_AES_256_GCM_SHA384', sslpeer: 'CN=QMPARTNER,O=Partner Kurum,C=TR' }),
      ch({ name: 'QMPARTNER.QMGW01', chltype: 'RQSTR', status: 'Inactive', descr: 'Partner kurumdan mesaj talep eden requester', conname: 'mq.partner.example(1414)', sslciph: 'TLS_AES_256_GCM_SHA384', mcauser: 'mqpartner' }),
      ch({ name: 'APP.ODEME.SVRCONN', chltype: 'SVRCONN', status: 'Running', descr: 'Ödeme API istemcileri (TLS + sertifika eşleme)', sslciph: 'ANY_TLS12_OR_HIGHER', sslcauth: 'REQUIRED', sharecnv: 10, maxinst: 200, maxinstc: 50, hbint: 300, monchl: 'MEDIUM' }),
      ch({ name: 'APP.MOBIL.SVRCONN', chltype: 'SVRCONN', status: 'Running', descr: 'Mobil arka uç servisleri (IIS üzerindeki .NET uygulamaları)', sslciph: 'TLS_AES_256_GCM_SHA384', sslcauth: 'OPTIONAL', sharecnv: 10, maxinst: 150, maxinstc: 40 }),
      ch({ name: 'ADMIN.TLS.SVRCONN', chltype: 'SVRCONN', status: 'Inactive', descr: 'MQ Explorer / yönetim araçları (TLS zorunlu)', sslciph: 'TLS_AES_256_GCM_SHA384', sslcauth: 'REQUIRED', maxinst: 10, maxinstc: 2, sharecnv: 1 }),
      ch({ name: 'SYSTEM.ADMIN.SVRCONN', chltype: 'SVRCONN', status: 'Inactive', descr: 'Varsayılan yönetim kanalı (CHLAUTH ile korunur)' }),
      ch({ name: 'APP.ODEME.CLNTCONN', chltype: 'CLNTCONN', descr: 'CCDT için istemci tanımı', conname: 'mqgw01.ornek.local(1414)', qmname: 'QMGW01', sslciph: 'ANY_TLS12_OR_HIGHER', sharecnv: 10, defrecon: 'YES' }),
      ch({ name: 'TO.CLS.ODEME.QMGW01', chltype: 'CLUSRCVR', status: 'Running', descr: 'CLS.ODEME cluster receiver', conname: 'mqgw01.ornek.local(1414)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', mcauser: 'mqchl',
        st: { msgs: 20311, batches: 3100, bytessent: 220031, bytesrcvd: 21993112, lstmsg: '2026-11-23 11:30:10', substate: 'RECEIVE', conname: '10.10.10.31', rqmname: 'QMCORE01', started: '2026-11-02 03:16:10' } }),
      ch({ name: 'TO.CLS.ODEME.QMCORE01', chltype: 'CLUSSDR', status: 'Running', descr: 'Full repository QMCORE01\'e manuel cluster sender', conname: 'mqcore01.ornek.local(1414)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384',
        st: { msgs: 18230, batches: 2900, bytessent: 19932100, bytesrcvd: 203300, lstmsg: '2026-11-23 11:30:12', xqtime: '410, 380', nettime: '1210, 1000', substate: 'MQGET', rqmname: 'QMCORE01', started: '2026-11-02 03:16:08' } }),
      ch({ name: 'TO.CLS.ODEME.QMBATCH01', chltype: 'CLUSSDR', status: 'Running', auto: true, descr: 'Otomatik tanımlı cluster sender (CONNAME, QMBATCH01\'in CLUSRCVR tanımından gelir)', conname: 'mqbatch01.ornek.local(1416)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384',
        st: { msgs: 3120, batches: 610, bytessent: 2210331, bytesrcvd: 12011, lstmsg: '2026-11-23 11:20:44', substate: 'MQGET', rqmname: 'QMBATCH01', started: '2026-11-20 22:00:10' } })
    ];
    gw.channels.forEach(function (c) {
      if (c.chltype === 'SVRCONN' && c.status === 'Running') {
        var r = seeded(c.name), n = c.name === 'APP.ODEME.SVRCONN' ? 18 : 10; c.inst = [];
        for (var i = 0; i < n; i++) c.inst.push({ conname: (c.name === 'APP.ODEME.SVRCONN' ? '10.20.40.' : '10.20.30.') + (11 + Math.floor(r() * 6)), appltag: c.name === 'APP.ODEME.SVRCONN' ? 'odeme-api.jar' : (i < 8 ? 'ws\\system32\\inetsrv\\w3wp.exe' : 'ilGateway.WindowsService.exe'), msgs: Math.floor(r() * 90000), bytessent: Math.floor(r() * 9e7), bytesrcvd: Math.floor(r() * 9e7), lstmsg: '2026-11-23 11:4' + Math.floor(r() * 3) + ':' + pad(Math.floor(r() * 59)), curshcnv: 1 + Math.floor(r() * 10), sslciph: c.name === 'APP.ODEME.SVRCONN' ? 'TLS_AES_256_GCM_SHA384' : 'TLS_AES_256_GCM_SHA384', mcauser: c.name === 'APP.ODEME.SVRCONN' ? 'odemeapp' : 'mobilapp', started: '2026-11-23 0' + Math.floor(r() * 9) + ':' + pad(Math.floor(r() * 59)), clientVer: r() > 0.3 ? '9.4.0.10' : '9.3.0.20' });
      }
    });
    gw.listeners = [
      { name: 'LST.TCP.1414', status: 'Running', trptype: 'TCP', port: 1414, ipaddr: '', control: 'QMGR', backlog: 0, descr: 'Ana TCP listener', pid: 41213, started: '2026-11-02 03:15:47' },
      { name: 'LST.TCP.1420.ADMIN', status: 'Stopped', trptype: 'TCP', port: 1420, ipaddr: '10.10.10.21', control: 'MANUAL', backlog: 50, descr: 'Yalnızca yönetim ağı arayüzünü dinler', pid: '', started: '' },
      { name: 'SYSTEM.DEFAULT.LISTENER.TCP', status: 'Stopped', trptype: 'TCP', port: 0, ipaddr: '', control: 'MANUAL', backlog: 0, descr: 'Sistem varsayılan listener tanımı (şablon)', pid: '', started: '' }
    ];
    gw.topics = [
      { name: 'SYSTEM.BASE.TOPIC', topicstr: '', descr: 'Konu ağacının kök (root) nesnesi', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: '', clroute: 'DIRECT', pubs: 0, subs: 0, system: true },
      { name: 'BILDIRIM.TOPIC', topicstr: 'bildirim/musteri', descr: 'Müşteri bildirimleri', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'YES', pubscope: 'QMGR', subscope: 'QMGR', cluster: '', clroute: 'DIRECT', pubs: 2, subs: 3, msgs: 15420 },
      { name: 'KUR.TOPIC', topicstr: 'piyasa/doviz/kur', descr: 'Döviz kuru yayınları - cluster genelinde', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: 'CLS.ODEME', clroute: 'TOPICHOST', pubs: 1, subs: 2, msgs: 86400 },
      { name: 'ODEME.OLAY.TOPIC', topicstr: 'odeme/olay', descr: 'Ödeme olayları (event-driven)', pub: 'ENABLED', sub: 'ENABLED', dursub: 'NO', defpsist: 'NO', pubscope: 'QMGR', subscope: 'QMGR', cluster: '', clroute: 'DIRECT', pubs: 1, subs: 1, msgs: 4410 },
      { name: 'ARSIV.TOPIC', topicstr: 'arsiv/eski', descr: 'Yayına kapatılmış konu', pub: 'DISABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'QMGR', subscope: 'QMGR', cluster: '', clroute: 'DIRECT', pubs: 0, subs: 0, msgs: 0 }
    ];
    gw.subs = [
      { name: 'SUB.BILDIRIM.SMS', topicstr: 'bildirim/musteri', topicobj: 'BILDIRIM.TOPIC', subtype: 'ADMIN', durable: 'YES', dest: 'APP.SMS.IN', destqmgr: 'QMGW01', destclas: 'PROVIDED', selector: '', expiry: 'UNLIMITED', created: '2025-04-02 13:11:00', lastmsg: '2026-11-23 11:41:07', msgs: 15420 },
      { name: 'SUB.BILDIRIM.EPOSTA', topicstr: 'bildirim/musteri', topicobj: 'BILDIRIM.TOPIC', subtype: 'ADMIN', durable: 'YES', dest: 'APP.EPOSTA.IN', destqmgr: 'QMGW01', destclas: 'PROVIDED', selector: "kanal = 'EPOSTA'", expiry: 'UNLIMITED', created: '2025-04-02 13:12:30', lastmsg: '2026-11-23 11:41:07', msgs: 3210 },
      { name: 'mobil-api:KurAbonesi', topicstr: 'piyasa/doviz/kur', topicobj: 'KUR.TOPIC', subtype: 'API', durable: 'YES', dest: 'SYSTEM.MANAGED.DURABLE.6728B11A2400F102', destqmgr: 'QMGW01', destclas: 'MANAGED', selector: '', expiry: 'UNLIMITED', created: '2026-10-28 08:00:12', lastmsg: '2026-11-23 11:42:00', msgs: 34210 },
      { name: '(non-durable) dashboard-ui', topicstr: 'piyasa/doviz/#', topicobj: 'KUR.TOPIC', subtype: 'API', durable: 'NO', dest: 'SYSTEM.MANAGED.NDURABLE.6741A2C02100A003', destqmgr: 'QMGW01', destclas: 'MANAGED', selector: '', expiry: 'UNLIMITED', created: '2026-11-23 08:30:00', lastmsg: '2026-11-23 11:42:00', msgs: 2930 },
      { name: 'SUB.BILDIRIM.AUDIT', topicstr: 'bildirim/musteri', topicobj: 'BILDIRIM.TOPIC', subtype: 'ADMIN', durable: 'YES', dest: 'QA.ODEME', destqmgr: 'QMGW01', destclas: 'PROVIDED', selector: '', expiry: 'UNLIMITED', created: '2025-06-10 10:00:00', lastmsg: '2026-11-20 16:00:00', msgs: 120 },
      { name: 'SYSTEM.DEFAULT.SUB', topicstr: '', topicobj: '', subtype: 'ADMIN', durable: 'YES', dest: '', destqmgr: '', destclas: 'PROVIDED', selector: '', expiry: 'UNLIMITED', created: gw.created, lastmsg: '', msgs: 0, system: true },
      { name: 'ODEME.OLAY.CEP', topicstr: 'odeme/olay', topicobj: 'ODEME.OLAY.TOPIC', subtype: 'API', durable: 'NO', dest: 'SYSTEM.MANAGED.NDURABLE.6741A2C02100A0F1', destqmgr: 'QMGW01', destclas: 'MANAGED', selector: '', expiry: 'UNLIMITED', created: '2026-11-23 07:00:00', lastmsg: '2026-11-23 11:39:00', msgs: 4410 }
    ];
    gw.chlauth = defaultChlauth().concat([
      { profile: 'APP.ODEME.SVRCONN', type: 'SSLPEERMAP', match: "SSLPEER('CN=odeme-api,OU=Odeme,O=Ornek Banka,C=TR')", usersrc: 'MAP', mcauser: 'odemeapp', chckclnt: 'ASQMGR', warn: 'NO', descr: 'Ödeme API sertifikasını odemeapp kullanıcısına eşler' },
      { profile: 'APP.MOBIL.SVRCONN', type: 'ADDRESSMAP', match: "ADDRESS('10.20.30.*')", usersrc: 'MAP', mcauser: 'mobilapp', chckclnt: 'REQUIRED', warn: 'NO', descr: 'Mobil sunucu ağı - kullanıcı/parola zorunlu' },
      { profile: '*', type: 'BLOCKADDR', match: "ADDRLIST('192.168.99.*')", usersrc: '', mcauser: '', chckclnt: '', warn: 'NO', descr: 'Test ağının üretim QM\'e bağlanmasını engeller' },
      { profile: 'QMCORE01.QMGW01', type: 'QMGRMAP', match: "QMNAME('QMCORE01')", usersrc: 'MAP', mcauser: 'mqchl', chckclnt: '', warn: 'NO', descr: 'QMCORE01 kanalını mqchl kullanıcısına eşler' },
      { profile: 'TO.CLS.ODEME.QMGW01', type: 'QMGRMAP', match: "QMNAME('QM*')", usersrc: 'MAP', mcauser: 'mqchl', chckclnt: '', warn: 'NO', descr: 'Cluster üyelerini mqchl ile eşler' },
      { profile: 'ADMIN.TLS.SVRCONN', type: 'USERMAP', match: "CLNTUSER('mqadmin1')", usersrc: 'MAP', mcauser: 'mqadmsvc', chckclnt: 'REQUIRED', warn: 'NO', descr: 'Yönetici istemci kullanıcısını servis hesabına eşler' }
    ]);
    gw.authinfo = defaultAuthinfo().concat([
      { name: 'LDAP.KURUMSAL', authtype: 'IDPWLDAP', chckclnt: 'REQUIRED', chcklocl: 'OPTIONAL', adoptctx: 'YES', failDelay: 1, conname: 'ldap1.ornek.local(636),ldap2.ornek.local(636)', descr: 'Kurumsal LDAP (henüz CONNAUTH\'a bağlı değil)', secomm: 'YES', basednu: 'OU=MQ,DC=ornek,DC=local', usrfield: 'sAMAccountName', classusr: 'user', authormd: 'SEARCHGRP' },
      { name: 'OCSP.KURUMSAL', authtype: 'OCSP', chckclnt: '', chcklocl: '', adoptctx: '', failDelay: '', conname: '', descr: 'OCSP responder', ocspurl: 'http://ocsp.ornek.local/' }
    ]);
    gw.authrec = [
      { profile: 'self', objtype: 'QMGR', principal: '', group: 'mqm', auth: 'ALLADM ALLMQI', note: 'mqm grubu tam yetkili (yönetici)' },
      { profile: 'self', objtype: 'QMGR', principal: '', group: 'odemegrp', auth: 'CONNECT INQ', note: '' },
      { profile: 'APP.ODEME.**', objtype: 'QUEUE', principal: '', group: 'odemegrp', auth: 'PUT GET BROWSE INQ', note: 'Generic profil' },
      { profile: 'QR.CORE.HESAP', objtype: 'QUEUE', principal: '', group: 'odemegrp', auth: 'PUT INQ', note: '' },
      { profile: 'QA.ODEME', objtype: 'QUEUE', principal: '', group: 'mobilgrp', auth: 'PUT INQ', note: 'Alias üzerinden erişim; hedef kuyruğa ayrıca yetki gerekmez' },
      { profile: 'APP.ODEME.YANIT', objtype: 'QUEUE', principal: '', group: 'mobilgrp', auth: 'GET BROWSE INQ', note: '' },
      { profile: 'self', objtype: 'QMGR', principal: '', group: 'mobilgrp', auth: 'CONNECT INQ', note: '' },
      { profile: 'APP.REPLY.MODEL', objtype: 'QUEUE', principal: '', group: 'mobilgrp', auth: 'DSP GET PUT', note: 'Dinamik kuyruk oluşturmak için model üzerinde DSP gerekir' },
      { profile: 'bildirim/#', objtype: 'TOPIC', principal: '', group: 'bildirimgrp', auth: 'PUB SUB', note: 'Topic yetkisi topic nesnesi üzerinden (BILDIRIM.TOPIC)' },
      { profile: 'self', objtype: 'QMGR', principal: '', group: 'monitorgrp', auth: 'CONNECT INQ DSP', note: 'Salt okunur izleme' },
      { profile: '**', objtype: 'QUEUE', principal: '', group: 'monitorgrp', auth: 'DSP INQ', note: '' },
      { profile: 'SYSTEM.ADMIN.COMMAND.QUEUE', objtype: 'QUEUE', principal: '', group: 'monitorgrp', auth: 'PUT DSP INQ', note: 'PCF komutları göndermek için' },
      { profile: 'SYSTEM.DEAD.LETTER.QUEUE', objtype: 'QUEUE', principal: '', group: 'mqchl', auth: 'PUT SETALL', note: 'Kanalların DLQ\'ya yazabilmesi için' }
    ];
    gw.certs = [
      { label: 'ibmwebspheremqqmgw01', type: 'Personal', subject: 'CN=QMGW01,OU=MQ,O=Ornek Banka,C=TR', issuer: 'CN=Ornek Issuing CA,O=Ornek Banka,C=TR', serial: '4A:1F:9C:22:7E', from: '2025-03-14', to: '2027-03-14', alg: 'SHA256withRSA', key: 'RSA 2048', status: 'Geçerli' },
      { label: 'ornek-root-ca', type: 'Signer (CA)', subject: 'CN=Ornek Root CA,O=Ornek Banka,C=TR', issuer: 'CN=Ornek Root CA,O=Ornek Banka,C=TR', serial: '01', from: '2020-01-01', to: '2035-01-01', alg: 'SHA384withRSA', key: 'RSA 4096', status: 'Geçerli' },
      { label: 'ornek-issuing-ca', type: 'Signer (CA)', subject: 'CN=Ornek Issuing CA,O=Ornek Banka,C=TR', issuer: 'CN=Ornek Root CA,O=Ornek Banka,C=TR', serial: '1B:02', from: '2022-06-01', to: '2030-06-01', alg: 'SHA256withRSA', key: 'RSA 4096', status: 'Geçerli' },
      { label: 'partner-ca', type: 'Signer (CA)', subject: 'CN=Partner Kurum CA,O=Partner Kurum,C=TR', issuer: 'CN=Partner Kurum CA,O=Partner Kurum,C=TR', serial: '7C:44:10', from: '2021-12-10', to: '2026-12-10', alg: 'SHA256withRSA', key: 'RSA 2048', status: 'Expiring' }
    ];
    gw.processes = [
      { name: 'FATURA.PROC', appltype: 'UNIX', applicid: '/opt/apps/fatura/bin/fatura_worker', userdata: 'MAXBATCH=500', envrdata: '&', descr: 'APP.FATURA.IN tetiklendiğinde başlatılan uygulama' },
      { name: 'SYSTEM.DEFAULT.PROCESS', appltype: 'UNIX', applicid: '', userdata: '', envrdata: '', descr: 'Varsayılan process şablonu' }
    ];
    gw.namelists = [
      { name: 'NL.CLUSTERS', names: ['CLS.ODEME', 'CLS.RAPOR'], nltype: 'NONE', descr: 'QM\'in üyesi olduğu cluster listesi (CLUSNL için)' },
      { name: 'NL.CRL.SUNUCULARI', names: ['OCSP.KURUMSAL'], nltype: 'AUTHINFO', descr: 'SSLCRLNL için authinfo listesi' },
      { name: 'SYSTEM.DEFAULT.NAMELIST', names: [], nltype: 'NONE', descr: 'Varsayılan şablon' }
    ];
    gw.services = [
      { name: 'SRV.TRIGMON', servtype: 'SERVER', control: 'QMGR', status: 'Running', startcmd: '+MQ_INSTALL_PATH+/bin/runmqtrm', startarg: '-m +QMNAME+ -q APP.TRIGGER.INITQ', stopcmd: '', stdout: '/var/mqm/qmgrs/+QMNAME+/trigmon.log', descr: 'Trigger monitor (runmqtrm)' },
      { name: 'SRV.DLQHANDLER', servtype: 'SERVER', control: 'MANUAL', status: 'Stopped', startcmd: '/var/mqm/scripts/dlq_handler.sh', startarg: '+QMNAME+', stopcmd: '', stdout: '/var/mqm/qmgrs/+QMNAME+/dlq.log', descr: 'runmqdlq kural tablosu ile DLQ işleyici (betik)' },
      { name: 'SRV.YEDEK.KOMUT', servtype: 'COMMAND', control: 'QMGR', status: 'N/A', startcmd: '/var/mqm/scripts/config_yedek.sh', startarg: '+QMNAME+', stopcmd: '', stdout: '', descr: 'QM başlarken dmpmqcfg ile konfigürasyon yedeği alır' }
    ];
    gw.comminfo = [{ name: 'SYSTEM.DEFAULT.COMMINFO.MULTICAST', grpaddr: '239.0.0.0', port: 1414, encoding: 'AS_PUBLISHED', mcprop: 'COMPAT', bridge: 'ENABLED', descr: 'Multicast pub/sub için varsayılan iletişim bilgisi' }];
    gw.errlog = [
      { time: '2026-11-23 11:40:12', code: 'AMQ9202E', sev: 'E', text: "Remote host 'mqbatch01.ornek.local (10.10.30.15) (1415)' not available, retry later.", exp: "Channel 'QMGW01.QMBATCH01' karşı sisteme TCP bağlantısı kuramadı (connect() 'ECONNREFUSED' döndü).", act: 'Karşı sistemdeki listener\'ın çalıştığını, portun doğru olduğunu ve ağ/firewall erişimini kontrol edin.' },
      { time: '2026-11-23 11:38:51', code: 'AMQ9999E', sev: 'E', text: "Channel 'QMGW01.QMBATCH01' to host 'mqbatch01.ornek.local(1415)' ended abnormally.", exp: 'Kanal programı beklenmedik şekilde sonlandı; kanal yeniden deneme (retry) moduna geçti.', act: 'Önceki hata mesajlarını inceleyin; ağ sorunu giderildiğinde kanal otomatik olarak yeniden başlar.' },
      { time: '2026-11-23 10:51:02', code: 'AMQ9777E', sev: 'E', text: "Channel was blocked", exp: "SVRCONN kanalına 192.168.99.14 adresinden gelen bağlantı BLOCKADDR CHLAUTH kuralı tarafından reddedildi.", act: 'Erişimin meşru olduğu doğrulanırsa CHLAUTH kuralını güncelleyin ve REFRESH gerekmez (CHLAUTH anında etkindir).' },
      { time: '2026-11-23 09:44:30', code: 'AMQ5534E', sev: 'E', text: "User ID 'mobilapp' authentication failed", exp: 'APP.MOBIL.SVRCONN üzerinden gelen bağlantıda parola doğrulaması başarısız oldu (CHCKCLNT REQUIRED).', act: 'İstemci uygulamanın MQCSP ile doğru kullanıcı/parola gönderdiğini kontrol edin.' },
      { time: '2026-11-23 09:44:30', code: 'AMQ5542I', sev: 'I', text: "The failed authentication check was caused by the queue manager CONNAUTH CHCKCLNT(REQUIRED) configuration.", exp: 'Bir önceki hata mesajının nedeni açıklanıyor.', act: 'Bilgilendirme amaçlıdır.' },
      { time: '2026-11-23 08:12:19', code: 'AMQ9631E', sev: 'E', text: "The CipherSpec negotiated during the TLS handshake does not match the required CipherSpec for channel 'ADMIN.TLS.SVRCONN'.", exp: 'İstemci TLS_RSA_WITH_AES_128_CBC_SHA256 önerdi; kanal TLS_AES_256_GCM_SHA384 gerektiriyor.', act: 'İstemci ve kanal SSLCIPH değerlerini eşleştirin veya ANY_TLS12_OR_HIGHER kullanın.' },
      { time: '2026-11-22 23:10:06', code: 'AMQ7467I', sev: 'I', text: "The oldest log file required to start queue manager QMGW01 is S0000041.LOG.", exp: 'Recovery log bilgisi.', act: 'Bilgilendirme amaçlıdır.' },
      { time: '2026-11-22 02:00:00', code: 'AMQ8003I', sev: 'I', text: "IBM MQ queue manager 'QMGW01' started using V9.4.0.26.", exp: 'Queue manager başarıyla başlatıldı.', act: 'Yok.' },
      { time: '2026-11-21 06:12:00', code: 'AMQ9545E', sev: 'W', text: "Disconnect interval expired.", exp: "Channel 'QMGW01.QMPARTNER' DISCINT süresince mesaj olmadığı için kapandı.", act: 'Normal davranıştır.' }
    ];
    gw.events = [
      { time: '2026-11-23 11:38:51', type: 'Queue Full', cat: 'Performance', object: 'APP.LOG.AUDIT', reason: 'MQRC_Q_FULL (2053)', sev: 'Error', detail: 'Kuyruk derinliği MAXDEPTH (20000) değerine ulaştı. Yeni MQPUT çağrıları 2053 ile reddediliyor.' },
      { time: '2026-11-23 11:05:00', type: 'Queue Depth High', cat: 'Performance', object: 'APP.RAPOR.BATCH', reason: 'MQRC_Q_DEPTH_HIGH (2224)', sev: 'Warning', detail: 'Derinlik QDEPTHHI eşiğini (%80 = 4000) aştı.' },
      { time: '2026-11-23 08:58:02', type: 'Channel Stopped', cat: 'Channel', object: 'QMGW01.QMBATCH01', reason: 'MQRC_CHANNEL_STOPPED (2283)', sev: 'Error', detail: 'Kanal hata nedeniyle durdu ve RETRYING durumuna geçti.' },
      { time: '2026-11-23 10:51:02', type: 'Channel Blocked', cat: 'Channel', object: 'APP.MOBIL.SVRCONN', reason: 'MQRC_CHANNEL_BLOCKED (2577)', sev: 'Warning', detail: 'CHLAUTH BLOCKADDR kuralı 192.168.99.14 adresini engelledi.' },
      { time: '2026-11-23 09:44:30', type: 'Not Authorized', cat: 'Authority', object: 'QMGW01', reason: 'MQRC_NOT_AUTHORIZED (2035)', sev: 'Warning', detail: 'Type 1 (connect) - kullanıcı mobilapp kimlik doğrulamasından geçemedi.' },
      { time: '2026-11-23 08:12:19', type: 'SSL Error', cat: 'Channel', object: 'ADMIN.TLS.SVRCONN', reason: 'MQRC_CHANNEL_SSL_ERROR (2371)', sev: 'Error', detail: 'CipherSpec uyuşmazlığı.' },
      { time: '2026-11-22 16:20:14', type: 'Config Change', cat: 'Configuration', object: 'APP.ODEME.ISTEK', reason: 'MQRC_CONFIG_CHANGE_OBJECT (2368)', sev: 'Info', detail: 'MAXDEPTH 20000 → 50000 olarak değiştirildi (ALTER QLOCAL).' },
      { time: '2026-11-02 03:15:44', type: 'Queue Manager Active', cat: 'Start/Stop', object: 'QMGW01', reason: 'MQRC_Q_MGR_ACTIVE (2222)', sev: 'Info', detail: 'Queue manager başlatıldı.' }
    ];
    gw.cluster = { name: 'CLS.ODEME', role: 'Full repository' };

    /* ============================ QMCORE01 ============================ */
    var core = {
      name: 'QMCORE01', status: 'Running', version: '9.4.0.26', cmdlevel: 940, platform: 'Unix', os: 'Linux x86-64 (Red Hat Enterprise Linux 9.4)',
      host: 'mqcore01.ornek.local', ip: '10.10.10.31', port: 1414, isDefault: false, installation: 'Installation1', instPath: '/opt/mqm',
      dataPath: '/var/mqm/qmgrs/QMCORE01', created: '2025-03-10 15:40:02', started: '2026-11-02 03:12:10', ha: 'Native HA (3 replika, aktif: mqcore01-a)',
      logType: 'LINEAR', logPrimary: 20, logSecondary: 10, logFilePages: 65535, logPath: '/var/mqm/log/QMCORE01/active/', logWriteIntegrity: 'TripleWrite',
      cpu: 7.9, mem: 34.2, storageMB: 6120, diskMB: 51200,
      attrs: attrs({ DESCR: 'Çekirdek bankacılık queue manager', REPOS: 'CLS.ODEME', PERFMEV: 'ENABLED', CHLEV: 'ENABLED', LOGGEREV: 'ENABLED', IMGSCHED: 'AUTO', IMGINTVL: 120,
        SSLKEYR: '/var/mqm/qmgrs/QMCORE01/ssl/key', CERTLABL: 'ibmwebspheremqqmcore01', MONQ: 'MEDIUM', MONCHL: 'MEDIUM', STATQ: 'ON', MAXHANDS: 1024, MAXUMSGS: 50000 }),
      stats: { puts: series('cp', 1500, 700, 11), gets: series('cg', 1480, 700, 11), cpu: series('cc', 5, 8, 11), mem: series('cm', 30, 6, 13), msgsLastHour: 9310, bytesIn: 24.02, bytesOut: 23.87 }
    };
    core.queues = [
      q({ name: 'APP.HESAP.IN', descr: 'Hesap işlemleri giriş kuyruğu', curdepth: 0, maxdepth: 100000, ipprocs: 6, defpsist: 'YES', bothresh: 5, boqname: 'APP.HESAP.BACKOUT', lput: '2026-11-23 11:42:10', lget: '2026-11-23 11:42:10', qtime: '300, 220' }),
      q({ name: 'APP.HESAP.BACKOUT', descr: 'Hesap backout kuyruğu', curdepth: 2, maxdepth: 5000, defpsist: 'YES', lput: '2026-11-20 14:00:00', msgage: 250000 }),
      q({ name: 'APP.HESAP.SORGU', descr: 'Cluster queue (CLS.ODEME)', curdepth: 1, maxdepth: 20000, ipprocs: 4, cluster: 'CLS.ODEME', defbind: 'NOTFIXED', lput: '2026-11-23 11:42:00', lget: '2026-11-23 11:42:00' }),
      q({ name: 'APP.KREDI.SKOR', descr: 'Cluster queue (iki instance\'dan biri)', curdepth: 9, maxdepth: 20000, ipprocs: 3, cluster: 'CLS.ODEME', defbind: 'NOTFIXED', clwlprty: 0, lput: '2026-11-23 11:41:00', lget: '2026-11-23 11:41:01' }),
      q({ name: 'APP.GUNSONU.IN', descr: 'Gün sonu işlemleri', curdepth: 0, maxdepth: 50000, defpsist: 'YES' }),
      q({ name: 'QR.GW.ODEME.YANIT', type: 'QREMOTE', descr: 'Yanıtları QMGW01\'e döndürür', rname: 'APP.ODEME.YANIT', rqmname: 'QMGW01', xmitq: 'QMGW01' }),
      q({ name: 'QMGW01', usage: 'XMITQ', descr: 'QMGW01 transmission queue', curdepth: 0, maxdepth: 50000, defpsist: 'YES', ipprocs: 1, trigger: true, initq: 'SYSTEM.CHANNEL.INITQ', trigdata: 'QMCORE01.QMGW01' }),
      q({ name: 'APP.CORE.REPLY.MODEL', type: 'QMODEL', deftype: 'TEMPDYN' }),
      q({ name: 'QA.HESAP', type: 'QALIAS', target: 'APP.HESAP.IN' })
    ].concat(sysQueues(core, { 'SYSTEM.DEAD.LETTER.QUEUE': 4 }));
    core.channels = [
      ch({ name: 'QMCORE01.QMGW01', chltype: 'SDR', status: 'Running', conname: 'mqgw01.ornek.local(1414)', xmitq: 'QMGW01', sslciph: 'TLS_AES_256_GCM_SHA384', st: { msgs: 179210, rqmname: 'QMGW01', substate: 'MQGET', lstmsg: '2026-11-23 11:42:19', xqtime: '700, 520', nettime: '1300, 1150' } }),
      ch({ name: 'QMGW01.QMCORE01', chltype: 'RCVR', status: 'Running', sslciph: 'TLS_AES_256_GCM_SHA384', mcauser: 'mqchl', st: { msgs: 182344, rqmname: 'QMGW01', substate: 'RECEIVE', lstmsg: '2026-11-23 11:42:10', conname: '10.10.10.21' } }),
      ch({ name: 'TO.CLS.ODEME.QMCORE01', chltype: 'CLUSRCVR', status: 'Running', conname: 'mqcore01.ornek.local(1414)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', mcauser: 'mqchl', st: { msgs: 18230, rqmname: 'QMGW01', substate: 'RECEIVE' } }),
      ch({ name: 'TO.CLS.ODEME.QMGW01', chltype: 'CLUSSDR', status: 'Running', conname: 'mqgw01.ornek.local(1414)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', st: { msgs: 20311, rqmname: 'QMGW01', substate: 'MQGET' } }),
      ch({ name: 'TO.CLS.ODEME.QMBATCH01', chltype: 'CLUSSDR', status: 'Running', auto: true, conname: 'mqbatch01.ornek.local(1416)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', st: { msgs: 7720, rqmname: 'QMBATCH01', substate: 'MQGET' } }),
      ch({ name: 'CORE.APP.SVRCONN', chltype: 'SVRCONN', status: 'Running', sslciph: 'TLS_AES_256_GCM_SHA384', maxinst: 300, maxinstc: 100,
        inst: [1, 2, 3, 4, 5, 6].map(function (i) { return { conname: '10.10.50.' + (10 + i), appltag: 'CoreBankingService', msgs: 50000 * i, bytessent: 1e7 * i, bytesrcvd: 1e7 * i, lstmsg: '2026-11-23 11:42:1' + i, curshcnv: 4, sslciph: 'TLS_AES_256_GCM_SHA384', mcauser: 'coreapp', started: '2026-11-23 06:00:0' + i, clientVer: '9.4.0.10' }; }) })
    ];
    core.listeners = [{ name: 'LST.TCP.1414', status: 'Running', trptype: 'TCP', port: 1414, ipaddr: '', control: 'QMGR', backlog: 0, descr: 'Ana listener', pid: 38110, started: '2026-11-02 03:12:12' }];
    core.topics = [
      { name: 'SYSTEM.BASE.TOPIC', topicstr: '', descr: 'Root', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: '', clroute: 'DIRECT', pubs: 0, subs: 0, system: true },
      { name: 'KUR.TOPIC', topicstr: 'piyasa/doviz/kur', descr: 'Topic host (cluster topic burada tanımlı)', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: 'CLS.ODEME', clroute: 'TOPICHOST', pubs: 1, subs: 1, msgs: 86400 }
    ];
    core.subs = [{ name: 'SUB.KUR.RISK', topicstr: 'piyasa/doviz/kur', topicobj: 'KUR.TOPIC', subtype: 'ADMIN', durable: 'YES', dest: 'APP.HESAP.SORGU', destqmgr: 'QMCORE01', destclas: 'PROVIDED', selector: '', expiry: 'UNLIMITED', created: '2025-05-01 10:00:00', lastmsg: '2026-11-23 11:42:00', msgs: 86400 }];
    core.chlauth = defaultChlauth().concat([{ profile: 'QMGW01.QMCORE01', type: 'QMGRMAP', match: "QMNAME('QMGW01')", usersrc: 'MAP', mcauser: 'mqchl', chckclnt: '', warn: 'NO', descr: '' }]);
    core.authinfo = defaultAuthinfo();
    core.authrec = [{ profile: 'self', objtype: 'QMGR', principal: '', group: 'mqm', auth: 'ALLADM ALLMQI', note: '' }, { profile: 'APP.HESAP.**', objtype: 'QUEUE', principal: '', group: 'coregrp', auth: 'PUT GET BROWSE INQ', note: '' }];
    core.certs = [{ label: 'ibmwebspheremqqmcore01', type: 'Personal', subject: 'CN=QMCORE01,OU=MQ,O=Ornek Banka,C=TR', issuer: 'CN=Ornek Issuing CA,O=Ornek Banka,C=TR', serial: '4A:1F:9C:22:80', from: '2025-03-14', to: '2027-03-14', alg: 'SHA256withRSA', key: 'RSA 2048', status: 'Geçerli' }, gw.certs[1], gw.certs[2]];
    core.processes = [{ name: 'SYSTEM.DEFAULT.PROCESS', appltype: 'UNIX', applicid: '', userdata: '', envrdata: '', descr: '' }];
    core.namelists = [{ name: 'SYSTEM.DEFAULT.NAMELIST', names: [], nltype: 'NONE', descr: '' }];
    core.services = [];
    core.comminfo = gw.comminfo.slice();
    core.errlog = [
      { time: '2026-11-23 06:00:00', code: 'AMQ7468I', sev: 'I', text: 'The oldest log file required to perform media recovery of queue manager QMCORE01 is S0001210.LOG.', exp: 'Linear logging - media recovery bilgisi.', act: 'Bu dosyadan eski log dosyaları arşivlenebilir.' },
      { time: '2026-11-23 06:00:00', code: 'AMQ7467I', sev: 'I', text: 'The oldest log file required to start queue manager QMCORE01 is S0001233.LOG.', exp: 'Restart recovery bilgisi.', act: 'Yok.' },
      { time: '2026-11-02 03:12:10', code: 'AMQ8003I', sev: 'I', text: "IBM MQ queue manager 'QMCORE01' started using V9.4.0.26.", exp: '', act: '' }
    ];
    core.events = [{ time: '2026-11-23 06:00:00', type: 'Logger', cat: 'Logger', object: 'QMCORE01', reason: 'MQRC_LOGGER_STATUS (2411)', sev: 'Info', detail: 'Media image kaydedildi; arşivlenebilir log dosyaları güncellendi.' }];
    core.cluster = { name: 'CLS.ODEME', role: 'Full repository' };

    /* ============================ QMBATCH01 ============================ */
    var batch = {
      name: 'QMBATCH01', status: 'Running', version: '9.3.0.20', cmdlevel: 930, platform: 'Unix', os: 'Linux x86-64 (Red Hat Enterprise Linux 8.8)',
      host: 'mqbatch01.ornek.local', ip: '10.10.30.15', port: 1415, isDefault: false, installation: 'Installation2', instPath: '/opt/mqm93',
      dataPath: '/var/mqm/qmgrs/QMBATCH01', created: '2023-08-20 09:00:00', started: '2026-11-20 22:00:00', ha: 'Multi-instance (aktif)',
      logType: 'CIRCULAR', logPrimary: 6, logSecondary: 4, logFilePages: 8192, logPath: '/MQHA/log/QMBATCH01/active/', logWriteIntegrity: 'TripleWrite',
      cpu: 1.1, mem: 12.4, storageMB: 940, diskMB: 20480,
      attrs: attrs({ DESCR: 'Batch / gün sonu queue manager (9.3 LTS)', CERTLABL: 'ibmwebspheremqqmbatch01', SSLKEYR: '/var/mqm/qmgrs/QMBATCH01/ssl/key' }),
      stats: { puts: series('bp', 100, 80, 23), gets: series('bg', 95, 80, 23), cpu: series('bc', 1, 2, 23), mem: series('bm', 10, 3, 23), msgsLastHour: 210, bytesIn: 0.8, bytesOut: 0.7 }
    };
    batch.queues = [
      q({ name: 'APP.GUNSONU.IN', curdepth: 0, maxdepth: 100000, ipprocs: 1, defpsist: 'YES' }),
      q({ name: 'APP.KREDI.SKOR', curdepth: 0, maxdepth: 20000, ipprocs: 2, cluster: 'CLS.ODEME', defbind: 'NOTFIXED' }),
      q({ name: 'QMGW01', usage: 'XMITQ', curdepth: 0, maxdepth: 50000, defpsist: 'YES', trigger: true, initq: 'SYSTEM.CHANNEL.INITQ', trigdata: 'QMBATCH01.QMGW01' })
    ].concat(sysQueues(batch, {}));
    batch.channels = [
      ch({ name: 'QMGW01.QMBATCH01', chltype: 'RCVR', status: 'Inactive', sslciph: 'ANY_TLS12_OR_HIGHER', mcauser: 'mqchl' }),
      ch({ name: 'QMBATCH01.QMGW01', chltype: 'SDR', status: 'Inactive', conname: 'mqgw01.ornek.local(1414)', xmitq: 'QMGW01', sslciph: 'ANY_TLS12_OR_HIGHER' }),
      ch({ name: 'TO.CLS.ODEME.QMBATCH01', chltype: 'CLUSRCVR', status: 'Running', conname: 'mqbatch01.ornek.local(1416)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', st: { msgs: 7720, rqmname: 'QMCORE01', substate: 'RECEIVE' } }),
      ch({ name: 'TO.CLS.ODEME.QMCORE01', chltype: 'CLUSSDR', status: 'Running', conname: 'mqcore01.ornek.local(1414)', cluster: 'CLS.ODEME', sslciph: 'TLS_AES_256_GCM_SHA384', st: { msgs: 2210, rqmname: 'QMCORE01', substate: 'MQGET' } })
    ];
    batch.listeners = [
      { name: 'LST.TCP.1415', status: 'Stopped', trptype: 'TCP', port: 1415, ipaddr: '', control: 'MANUAL', backlog: 0, descr: 'Uygulama ve QMGW01 kanalları için listener - DURDURULMUŞ', pid: '', started: '' },
      { name: 'LST.TCP.1416.CLUSTER', status: 'Running', trptype: 'TCP', port: 1416, ipaddr: '', control: 'QMGR', backlog: 0, descr: 'Cluster trafiği için listener', pid: 22011, started: '2026-11-20 22:00:03' }
    ];
    batch.topics = [{ name: 'SYSTEM.BASE.TOPIC', topicstr: '', descr: 'Root', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: '', clroute: 'DIRECT', pubs: 0, subs: 0, system: true }];
    batch.subs = []; batch.chlauth = defaultChlauth(); batch.authinfo = defaultAuthinfo(); batch.authrec = [{ profile: 'self', objtype: 'QMGR', principal: '', group: 'mqm', auth: 'ALLADM ALLMQI', note: '' }];
    batch.certs = [{ label: 'ibmwebspheremqqmbatch01', type: 'Personal', subject: 'CN=QMBATCH01,OU=MQ,O=Ornek Banka,C=TR', issuer: 'CN=Ornek Issuing CA,O=Ornek Banka,C=TR', serial: '3D:11', from: '2024-01-10', to: '2026-12-31', alg: 'SHA256withRSA', key: 'RSA 2048', status: 'Expiring' }];
    batch.processes = []; batch.namelists = []; batch.services = []; batch.comminfo = [];
    batch.errlog = [{ time: '2026-11-23 08:57:40', code: 'AMQ9228E', sev: 'E', text: 'The TCP/IP responder program could not be started.', exp: 'Listener LST.TCP.1415 bir operatör tarafından durduruldu (STOP LISTENER) ve CONTROL(MANUAL) olduğu için otomatik başlamadı.', act: 'START LISTENER(LST.TCP.1415) komutunu çalıştırın veya CONTROL(QMGR) yapın.' }];
    batch.events = [];
    batch.cluster = { name: 'CLS.ODEME', role: 'Partial repository' };

    /* ============================ QMTEST01 ============================ */
    var test = {
      name: 'QMTEST01', status: 'Ended normally', version: '9.4.0.26', cmdlevel: 940, platform: 'Windows', os: 'Windows Server 2022 (x64)',
      host: 'mqtest01.ornek.local', ip: '10.10.90.5', port: 1416, isDefault: false, installation: 'Installation1', instPath: 'C:\\Program Files\\IBM\\MQ',
      dataPath: 'C:\\ProgramData\\IBM\\MQ\\qmgrs\\QMTEST01', created: '2026-01-05 11:00:00', started: '', ha: 'Yok',
      logType: 'CIRCULAR', logPrimary: 3, logSecondary: 2, logFilePages: 4096, logPath: 'C:\\ProgramData\\IBM\\MQ\\log\\QMTEST01\\active\\', logWriteIntegrity: 'TripleWrite',
      cpu: 0, mem: 0, storageMB: 120, diskMB: 10240,
      attrs: attrs({ DESCR: 'Test / eğitim queue manager' }),
      stats: { puts: series('tp', 0, 1, 1).map(function () { return 0; }), gets: series('tg', 0, 1, 1).map(function () { return 0; }), cpu: series('tc', 0, 0, 1), mem: series('tm', 0, 0, 1), msgsLastHour: 0, bytesIn: 0, bytesOut: 0 }
    };
    test.queues = [q({ name: 'TEST.IN', curdepth: 3, maxdepth: 5000 }), q({ name: 'TEST.OUT', curdepth: 0 })].concat(sysQueues(test, {}));
    test.channels = [ch({ name: 'TEST.SVRCONN', chltype: 'SVRCONN', status: 'Inactive' })];
    test.listeners = [{ name: 'LST.TCP.1416', status: 'Stopped', trptype: 'TCP', port: 1416, ipaddr: '', control: 'QMGR', backlog: 0, descr: '', pid: '', started: '' }];
    test.topics = [{ name: 'SYSTEM.BASE.TOPIC', topicstr: '', descr: 'Root', pub: 'ENABLED', sub: 'ENABLED', dursub: 'YES', defpsist: 'NO', pubscope: 'ALL', subscope: 'ALL', cluster: '', clroute: 'DIRECT', pubs: 0, subs: 0, system: true }];
    test.subs = []; test.chlauth = defaultChlauth(); test.authinfo = defaultAuthinfo(); test.authrec = []; test.certs = []; test.processes = []; test.namelists = []; test.services = []; test.comminfo = [];
    test.errlog = [{ time: '2026-11-15 18:00:00', code: 'AMQ8004I', sev: 'I', text: "IBM MQ queue manager 'QMTEST01' ended.", exp: 'endmqm ile kontrollü (controlled) kapatıldı.', act: 'strmqm QMTEST01 ile başlatabilirsiniz.' }];
    test.events = []; test.cluster = null;

    /* ============================ QMDR01 ============================ */
    var dr = {
      name: 'QMDR01', status: 'Running elsewhere', version: '9.4.0.26', cmdlevel: 940, platform: 'Unix', os: 'Linux x86-64 (Red Hat Enterprise Linux 9.4)',
      host: 'mqdr01-b.ornek.local', ip: '10.20.10.12', port: 1414, isDefault: false, installation: 'Installation1', instPath: '/opt/mqm',
      dataPath: '/MQHA/qmgrs/QMDR01', created: '2024-11-01 10:00:00', started: '', ha: 'Multi-instance - aktif instance mqdr01-a üzerinde', logType: 'LINEAR', logPrimary: 10, logSecondary: 5, logFilePages: 16384, logPath: '/MQHA/log/QMDR01/active/', logWriteIntegrity: 'TripleWrite',
      cpu: 0, mem: 0, storageMB: 2300, diskMB: 40960, attrs: attrs({ DESCR: 'Felaket kurtarma (DR) - multi-instance queue manager' }),
      stats: { puts: series('dp', 0, 0, 1), gets: series('dg', 0, 0, 1), cpu: series('dc', 0, 0, 1), mem: series('dm', 0, 0, 1), msgsLastHour: 0, bytesIn: 0, bytesOut: 0 }
    };
    dr.queues = sysQueues(dr, {}); dr.channels = []; dr.listeners = []; dr.topics = []; dr.subs = []; dr.chlauth = defaultChlauth(); dr.authinfo = defaultAuthinfo(); dr.authrec = []; dr.certs = []; dr.processes = []; dr.namelists = []; dr.services = []; dr.comminfo = []; dr.errlog = []; dr.events = []; dr.cluster = null;

    /* -------- bağlantılar (DISPLAY CONN) -------- */
    function conns(qm) {
      var list = [], r = seeded('conn' + qm.name);
      qm.channels.forEach(function (c) {
        (c.inst || []).forEach(function (i, k) {
          var nconv = c.name === 'APP.ODEME.SVRCONN' ? 1 + (k % 3 === 0 ? 1 : 0) : 1;
          for (var z = 0; z < nconv; z++) list.push({ connid: '414D5143' + strHex(qm.name, 12).slice(0, 24) + MQ.hex(16), appltag: i.appltag, appltype: i.appltag.indexOf('.jar') > 0 ? 'JAVA' : (i.appltag.indexOf('.exe') > 0 ? 'DOTNET' : 'USER'), channel: c.name, conname: i.conname, userid: i.mcauser, pid: 3000 + Math.floor(r() * 9000), conntime: i.started, objects: c.name === 'APP.ODEME.SVRCONN' ? 'APP.ODEME.ISTEK (INPUT), APP.ODEME.YANIT (OUTPUT)' : 'QA.ODEME (OUTPUT), APP.ODEME.YANIT (INPUT)', uow: r() > 0.85 ? 'Açık (aktif UOW)' : '-', clientVer: i.clientVer });
        });
      });
      if (qm.name === 'QMGW01') {
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'fatura_worker', appltype: 'USER', channel: '', conname: '(bindings - yerel)', userid: 'faturaapp', pid: 51220, conntime: '2026-11-23 10:05:13', objects: 'APP.FATURA.IN (INPUT)', uow: '-', clientVer: '' });
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'runmqtrm', appltype: 'USER', channel: '', conname: '(bindings - yerel)', userid: 'mqm', pid: 41290, conntime: '2026-11-02 03:15:50', objects: 'APP.TRIGGER.INITQ (INPUT)', uow: '-', clientVer: '' });
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'audit-collector', appltype: 'USER', channel: '', conname: '(bindings - yerel)', userid: 'auditapp', pid: 50111, conntime: '2026-11-20 08:00:00', objects: 'APP.LOG.AUDIT (OUTPUT)', uow: '-', clientVer: '' });
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'runmqchi', appltype: 'SYSTEM', channel: '', conname: '(sistem)', userid: 'mqm', pid: 41201, conntime: '2026-11-02 03:15:46', objects: 'SYSTEM.CHANNEL.INITQ (INPUT)', uow: '-', clientVer: '' });
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'amqrmppa', appltype: 'SYSTEM', channel: 'QMGW01.QMCORE01', conname: 'mqcore01.ornek.local(1414)', userid: 'mqm', pid: 41250, conntime: '2026-11-02 03:16:02', objects: 'QMCORE01 (INPUT)', uow: '-', clientVer: '' });
        list.push({ connid: '414D5143514D4757303120202020' + MQ.hex(12), appltag: 'IBM MQ Web Server', appltype: 'JAVA', channel: '', conname: '(bindings - yerel)', userid: 'mqweb', pid: 40100, conntime: '2026-11-02 03:17:00', objects: 'SYSTEM.ADMIN.COMMAND.QUEUE (OUTPUT)', uow: '-', clientVer: '' });
      }
      return list;
    }
    gw.conns = conns(gw); core.conns = conns(core); batch.conns = conns(batch); test.conns = []; dr.conns = [];

    S.qmgrs = [gw, core, batch, test, dr];
    S.remoteQmgrs = [
      { name: 'QMZOS1', status: 'Connected', platform: 'z/OS', version: '9.3.0', cmdlevel: 930, host: 'zos1.ornek.local', port: 1414, channel: 'CONSOLE.SVRCONN', ccdt: 'ccdt-zos1.json', tls: 'TLS_AES_256_GCM_SHA384' },
      { name: 'QMPARTNER', status: 'Disconnected', platform: 'Unix', version: '9.4.0', cmdlevel: 940, host: 'mq.partner.example', port: 1414, channel: 'ORNEK.ADMIN.SVRCONN', ccdt: 'ccdt-partner.json', tls: 'TLS_AES_256_GCM_SHA384' }
    ];
    return S;
  };
})();
