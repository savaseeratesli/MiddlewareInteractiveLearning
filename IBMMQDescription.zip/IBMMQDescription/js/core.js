/* IBM MQ Console eğitim simülasyonu - çekirdek: yardımcılar, durum, yönlendirme, bileşenler.
   Bu dosya hiçbir gerçek IBM MQ sistemine bağlanmaz. Tüm veriler tarayıcı belleğinde simüle edilir. */
(function () {
  'use strict';
  var MQ = window.MQ = window.MQ || {};
  MQ.HELP = MQ.HELP || {};

  /* ------------------------------------------------------------------ utils */
  MQ.esc = function (s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  MQ.fmt = function (n) { return typeof n === 'number' ? n.toLocaleString('tr-TR') : (n === undefined || n === null || n === '' ? '-' : n); };
  MQ.enc = function (s) { return encodeURIComponent(s); };
  MQ.clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  MQ.pct = function (a, b) { return b ? Math.round((a / b) * 100) : 0; };
  MQ.now = function () {
    var d = new Date(); var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  };
  MQ.hex = function (len) { var s = ''; for (var i = 0; i < len; i++) s += '0123456789ABCDEF'[Math.floor(Math.random() * 16)]; return s; };
  MQ.bytes = function (n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1).replace('.', ',') + ' KB';
    return (n / 1048576).toFixed(2).replace('.', ',') + ' MB';
  };

  /* ------------------------------------------------------------------ icons */
  var IC = {
    home: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    manage: '<rect x="3" y="4" width="18" height="16"/><path d="M3 9h18M3 14.5h18M9 9v11"/>',
    learn: '<path d="M5 4h14M7 4v4a5 5 0 0 0 10 0V4M12 13v3M8 20h8M10 16h4v4h-4z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
    dashboard: '<path d="M5 20V11M10.5 20V5M16 20v-6M21 20H3"/>',
    terminal: '<rect x="3" y="4" width="18" height="16"/><path d="m7 9 3 3-3 3M12 15h5"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7v.5"/><circle cx="12" cy="17" r=".7" fill="currentColor"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.4"/>',
    user: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.5 18.5a6.5 6.5 0 0 1 11 0"/>',
    search: '<circle cx="10.5" cy="10.5" r="6"/><path d="m15 15 6 6"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4"/>',
    add: '<path d="M12 5v14M5 12h14"/>',
    overflow: '<circle cx="12" cy="5" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="19" r="1.3" fill="currentColor"/>',
    chevron: '<path d="m6 9 6 6 6-6"/>',
    chevronL: '<path d="m15 6-6 6 6 6"/>',
    chevronR: '<path d="m9 6 6 6-6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    queue: '<path d="M6 5v13a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V5"/>',
    app: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 17.5h7M17.5 14v7"/>',
    qm: '<rect x="4" y="3" width="16" height="18"/><path d="M8 7h8M8 11h8M8 15h8"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13 7 4 4"/>',
    wrench: '<path d="M15 4a5 5 0 0 0-4.6 6.9L4 17.3V20h2.7l6.4-6.4A5 5 0 0 0 20 9l-3 1-2-2 1-3z"/>',
    check: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    warning: '<path d="M12 3 2 20h20z"/><path d="M12 10v5M12 17.5v.4"/>',
    error: '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
    channel: '<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>',
    network: '<circle cx="5" cy="12" r="2.5"/><circle cx="19" cy="5" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M7.3 11 16.7 6M7.3 13l9.4 5"/>',
    topic: '<path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="16" r="3"/>',
    lock: '<rect x="5" y="10" width="14" height="10"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
    plug: '<path d="M12 15v6M8.5 3v5M15.5 3v5M6 8h12v3a6 6 0 0 1-12 0z"/>',
    quick: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><path d="M10 6.5h4a3 3 0 0 1 3 3V14"/>',
    listener: '<path d="M12 12v9M8.5 8.5a5 5 0 0 1 7 0M6 6a8.5 8.5 0 0 1 12 0"/><circle cx="12" cy="11.5" r="1.2" fill="currentColor"/>',
    cluster: '<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="18" r="2.5"/><circle cx="19" cy="18" r="2.5"/><path d="M10.7 7.2 6.3 15.8M13.3 7.2l4.4 8.6M7.5 18h9"/>',
    cert: '<rect x="3" y="4" width="18" height="12"/><circle cx="15" cy="15" r="3"/><path d="M13.5 17.5 13 21l2-1 2 1-.5-3.5M7 8h8M7 11h4"/>',
    play: '<path d="M7 4v16l13-8z"/>',
    stop: '<rect x="6" y="6" width="12" height="12"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    mail: '<rect x="3" y="5" width="18" height="14"/><path d="m3 6 9 7 9-7"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    chart: '<path d="M3 20h18M5 16l4-5 4 3 6-8"/>',
    book: '<path d="M4 4h6a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4zM20 4h-6a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h6z"/>',
    object: '<path d="M12 3 3 8v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    log: '<path d="M6 3h9l4 4v14H6z"/><path d="M9 11h7M9 15h7M9 7h3"/>',
    copy: '<rect x="8" y="8" width="12" height="12"/><path d="M16 8V4H4v12h4"/>'
  };
  MQ.icon = function (n, cls) {
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || '') + '</svg>';
  };

  /* ------------------------------------------------------------------ help (?) */
  MQ.help = function (key) {
    if (!key) return '';
    return '<button type="button" class="hq" data-help="' + MQ.esc(key) + '" title="Bu öğe hakkında bilgi" aria-label="Açıklama: ' + MQ.esc(key) + '">?</button>';
  };
  MQ._missingHelp = {};
  MQ.openHelp = function (key) {
    var e = MQ.HELP[key];
    var p = document.getElementById('helpPanel');
    if (!e) { MQ._missingHelp[key] = 1; e = { t: key, w: 'Bu öğe için açıklama henüz eklenmedi.' }; }
    var sec = function (title, body, cls, pre) {
      if (!body) return '';
      return '<div class="help-sec ' + (cls || '') + '"><h3>' + title + '</h3>' + (pre ? '<pre>' + MQ.esc(body) + '</pre>' : '<p>' + body + '</p>') + '</div>';
    };
    var rel = '';
    if (e.l && e.l.length) {
      rel = '<div class="help-sec"><h3>İlgili konular</h3><div class="help-rel">' + e.l.filter(function (k) { return MQ.HELP[k]; }).map(function (k) {
        return '<a data-help="' + MQ.esc(k) + '">' + MQ.esc(MQ.HELP[k].t) + '</a>';
      }).join('') + '</div></div>';
    }
    p.innerHTML =
      '<div class="help-head"><div style="flex:1"><span class="cat">' + MQ.esc(e.c || 'IBM MQ') + '</span><h2>' + MQ.esc(e.t) +
      (e.m ? ' <span class="help-mqsc">' + MQ.esc(e.m) + '</span>' : '') + '</h2></div>' +
      '<button class="help-close" data-close-help aria-label="Kapat">' + MQ.icon('close') + '</button></div>' +
      '<div class="help-body">' +
      sec('Ne işe yarar?', e.w) +
      sec('IBM MQ içindeki görevi', e.r) +
      sec('Hangi amaçla kullanılır?', e.p) +
      sec('Hangi durumlarda kullanılmalı?', e.n) +
      sec('Sağladığı fayda', e.b) +
      sec('Örnek', e.e, '', true) +
      sec('Yanlış yapılandırılırsa', e.x, 'risk') +
      sec('Sürüm / platform notu', e.v, 'ver') +
      rel + '</div>';
    p.classList.add('open');
    p.querySelector('.help-body').scrollTop = 0;
    var c = p.querySelector('.help-close'); if (c) c.focus();
  };
  MQ.closeHelp = function () { document.getElementById('helpPanel').classList.remove('open'); };

  /* ------------------------------------------------------------------ status / tags */
  var ST = {
    'Running': 'ok', 'Connected': 'ok', 'Enabled': 'ok', 'Normal': 'ok', 'Geçerli': 'ok', 'Active': 'ok',
    'Stopped': 'stop', 'Ended normally': 'stop', 'Ended immediately': 'stop', 'Ended unexpectedly': 'err',
    'Retrying': 'warn', 'Warning': 'warn', 'Expiring': 'warn', 'Paused': 'warn',
    'Inactive': 'off', 'Disconnected': 'off', 'Disabled': 'off', 'N/A': 'off',
    'Binding': 'pend', 'Starting': 'pend', 'Initializing': 'pend', 'Requesting': 'pend', 'Stopping': 'pend', 'Running as standby': 'pend', 'Switching': 'pend',
    'Full': 'err', 'Error': 'err', 'Expired': 'err', 'Blocked': 'err'
  };
  MQ.status = function (s) { return '<span class="st"><i class="' + (ST[s] || 'off') + '"></i>' + MQ.esc(s) + '</span>'; };
  MQ.tag = function (text, color) { return '<span class="tag ' + (color || 'gray') + '">' + MQ.esc(text) + '</span>'; };

  /* ------------------------------------------------------------------ prefs & state */
  var PREF_KEY = 'mqsim.prefs.v1', STATE_KEY = 'mqsim.state.v3';
  MQ.prefs = { theme: 'dark', help: true };
  try { var pp = JSON.parse(localStorage.getItem(PREF_KEY) || 'null'); if (pp) MQ.prefs = Object.assign(MQ.prefs, pp); } catch (e) { /* yok say */ }
  MQ.savePrefs = function () { try { localStorage.setItem(PREF_KEY, JSON.stringify(MQ.prefs)); } catch (e) { /* yok say */ } MQ.applyPrefs(); };
  MQ.applyPrefs = function () {
    document.documentElement.setAttribute('data-theme', MQ.prefs.theme === 'light' ? 'light' : 'dark');
    document.body.classList.toggle('no-help', !MQ.prefs.help);
  };
  MQ.loadState = function () {
    var s = null;
    try { s = JSON.parse(localStorage.getItem(STATE_KEY) || 'null'); } catch (e) { s = null; }
    MQ.state = s && s.qmgrs ? s : MQ.seed();
  };
  MQ.save = function () { try { localStorage.setItem(STATE_KEY, JSON.stringify(MQ.state)); } catch (e) { /* kota dolu ise sessizce geç */ } };
  MQ.resetState = function () { try { localStorage.removeItem(STATE_KEY); } catch (e) { /* yok say */ } MQ.state = MQ.seed(); };

  MQ.qm = function (n) { return MQ.state.qmgrs.filter(function (q) { return q.name === n; })[0]; };
  MQ.findQ = function (qm, n) { return qm.queues.filter(function (q) { return q.name === n; })[0]; };
  MQ.findCh = function (qm, n) { return qm.channels.filter(function (q) { return q.name === n; })[0]; };
  MQ.qmLink = function (n) { return '#/qm/' + MQ.enc(n) + '/overview'; };
  MQ.qLink = function (qm, q) { return '#/qm/' + MQ.enc(qm) + '/queue/' + MQ.enc(q); };
  MQ.chLink = function (qm, c) { return '#/qm/' + MQ.enc(qm) + '/channel/' + MQ.enc(c); };

  /* ------------------------------------------------------------------ callbacks registry */
  MQ._fns = {}; var fnSeq = 0;
  MQ.fn = function (f) { var id = 'f' + (++fnSeq); MQ._fns[id] = f; return id; };
  MQ._menus = {};
  MQ.overflow = function (items, label) {
    var id = MQ.fn(null); MQ._menus[id] = items;
    return '<button type="button" class="icon-btn sm" data-menu="' + id + '" aria-label="' + (label || 'Seçenekler') + '">' + MQ.icon('overflow') + '</button>';
  };
  MQ.ddButton = function (label, items) {
    var id = MQ.fn(null); MQ._menus[id] = items;
    return '<div class="dd"><button type="button" class="dd-btn" data-menu="' + id + '" data-menu-align="left">' + MQ.esc(label) + MQ.icon('chevron', 'ddc').replace('<svg', '<svg width="16" height="16"') + '</button></div>';
  };
  function closeMenus() { var m = document.querySelectorAll('.menu.floating'); for (var i = 0; i < m.length; i++) m[i].remove(); }
  MQ.closeMenus = closeMenus;
  function openMenu(btn) {
    var items = MQ._menus[btn.getAttribute('data-menu')] || [];
    closeMenus();
    var ul = document.createElement('div'); ul.className = 'menu floating'; ul.setAttribute('role', 'menu');
    items.forEach(function (it) {
      if (it === '-') { var s = document.createElement('div'); s.className = 'sep'; ul.appendChild(s); return; }
      var b = document.createElement('button'); b.type = 'button'; b.textContent = it.label; b.setAttribute('role', 'menuitem');
      if (it.danger) b.className = 'danger';
      if (it.disabled) { b.disabled = true; b.title = it.disabled === true ? '' : it.disabled; }
      b.addEventListener('click', function (ev) { ev.stopPropagation(); closeMenus(); if (it.fn) it.fn(); });
      ul.appendChild(b);
    });
    document.body.appendChild(ul);
    var r = btn.getBoundingClientRect();
    var w = Math.max(ul.offsetWidth, btn.getAttribute('data-menu-align') ? r.width : 0);
    ul.style.minWidth = w + 'px';
    var left = btn.getAttribute('data-menu-align') ? r.left : r.right - ul.offsetWidth;
    left = Math.max(8, Math.min(left, window.innerWidth - ul.offsetWidth - 8));
    var top = r.bottom;
    if (top + ul.offsetHeight > window.innerHeight - 8) top = Math.max(56, r.top - ul.offsetHeight);
    ul.style.position = 'fixed'; ul.style.left = left + 'px'; ul.style.top = top + 'px';
    var first = ul.querySelector('button:not(:disabled)'); if (first) first.focus();
  }

  /* ------------------------------------------------------------------ toast */
  MQ.toast = function (kind, title, msg, code) {
    var box = document.getElementById('toasts');
    var t = document.createElement('div'); t.className = 'toast ' + (kind || '');
    t.setAttribute('role', kind === 'err' ? 'alert' : 'status');
    t.innerHTML = '<div class="grow"><b>' + MQ.esc(title) + '</b>' + (msg ? '<span>' + msg + '</span>' : '') + (code ? '<code>' + MQ.esc(code) + '</code>' : '') + '</div><button aria-label="Kapat">' + MQ.icon('close').replace('<svg', '<svg width="16" height="16"') + '</button>';
    t.querySelector('button').onclick = function () { t.remove(); };
    box.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.remove(); }, kind === 'err' ? 12000 : 8000);
  };

  /* ------------------------------------------------------------------ modal */
  MQ.modal = function (o) {
    MQ.closeModal();
    var ov = document.createElement('div'); ov.className = 'overlay'; ov.id = 'modalOverlay';
    ov.innerHTML =
      '<form class="modal ' + (o.size || '') + '" role="dialog" aria-modal="true" novalidate>' +
      '<div class="modal-h"><div class="grow">' + (o.label ? '<div class="lbl">' + MQ.esc(o.label) + '</div>' : '') +
      '<h2>' + MQ.esc(o.title) + (o.help ? MQ.help(o.help) : '') + '</h2></div>' +
      '<button type="button" class="help-close" data-x aria-label="Kapat">' + MQ.icon('close') + '</button></div>' +
      '<div class="modal-b">' + o.body + '</div>' +
      (o.noFooter ? '' : '<div class="modal-f"><button type="button" class="btn secondary" data-x>' + MQ.esc(o.cancel || 'İptal') + '</button>' +
        (o.primary === false ? '' : '<button type="submit" class="btn ' + (o.danger ? 'danger' : '') + '">' + MQ.esc(o.primary || 'Kaydet') + '</button>') + '</div>') +
      '</form>';
    document.body.appendChild(ov);
    var form = ov.querySelector('form');
    var xs = ov.querySelectorAll('[data-x]');
    for (var i = 0; i < xs.length; i++) xs[i].onclick = MQ.closeModal;
    ov.addEventListener('mousedown', function (e) { if (e.target === ov) MQ.closeModal(); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!o.onSubmit) { MQ.closeModal(); return; }
      var r = o.onSubmit(form, MQ.vals(form));
      if (r !== false) MQ.closeModal();
    });
    if (o.onInput) { form.addEventListener('input', function () { o.onInput(form, MQ.vals(form)); }); form.addEventListener('change', function () { o.onInput(form, MQ.vals(form)); }); o.onInput(form, MQ.vals(form)); }
    if (o.onOpen) o.onOpen(form);
    var fi = form.querySelector('.modal-b input:not([type=hidden]):not([readonly]), .modal-b select, .modal-b textarea');
    if (fi) setTimeout(function () { fi.focus(); }, 30);
    return form;
  };
  MQ.closeModal = function () { var o = document.getElementById('modalOverlay'); if (o) o.remove(); };
  MQ.confirm = function (o) {
    MQ.modal({ title: o.title, label: o.label, size: 'sm', body: o.body, primary: o.primary || 'Onayla', danger: o.danger !== false, help: o.help, onSubmit: function (f, v) { return o.onOk(v, f); } });
  };
  MQ.vals = function (form) {
    var v = {}; var els = form.querySelectorAll('[name]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.type === 'checkbox') v[el.name] = el.checked;
      else if (el.type === 'radio') { if (el.checked) v[el.name] = el.value; else if (!(el.name in v)) v[el.name] = ''; }
      else v[el.name] = el.value;
    }
    return v;
  };
  MQ.invalid = function (form, name, msg) {
    var el = form.querySelector('[name="' + name + '"]'); if (!el) { MQ.toast('err', 'Doğrulama hatası', msg); return false; }
    var f = el.closest('.field'); if (f) { f.classList.add('invalid'); var em = f.querySelector('.err-msg'); if (em) em.textContent = msg; }
    el.focus(); return false;
  };

  /* ------------------------------------------------------------------ form fields */
  function lbl(o) { return '<label class="lb" for="fld_' + o.name + '">' + MQ.esc(o.label) + (o.attr ? '<span class="attr">' + MQ.esc(o.attr) + '</span>' : '') + MQ.help(o.help) + '</label>'; }
  function wrap(o, inner) { return '<div class="field" data-f="' + o.name + '">' + lbl(o) + inner + (o.hint ? '<div class="hint">' + o.hint + '</div>' : '') + '<div class="err-msg"></div></div>'; }
  MQ.F = {
    text: function (o) {
      return wrap(o, '<input class="in" id="fld_' + o.name + '" name="' + o.name + '" type="' + (o.type || 'text') + '" value="' + MQ.esc(o.value === undefined ? '' : o.value) + '"' +
        (o.placeholder ? ' placeholder="' + MQ.esc(o.placeholder) + '"' : '') + (o.readonly ? ' readonly' : '') + (o.min !== undefined ? ' min="' + o.min + '"' : '') + (o.max !== undefined ? ' max="' + o.max + '"' : '') + (o.maxlength ? ' maxlength="' + o.maxlength + '"' : '') + ' autocomplete="off" spellcheck="false">');
    },
    select: function (o) {
      return wrap(o, '<select class="in" id="fld_' + o.name + '" name="' + o.name + '">' + o.options.map(function (op) {
        var v = Array.isArray(op) ? op[0] : op, l = Array.isArray(op) ? op[1] : op;
        return '<option value="' + MQ.esc(v) + '"' + (String(v) === String(o.value) ? ' selected' : '') + '>' + MQ.esc(l) + '</option>';
      }).join('') + '</select>');
    },
    area: function (o) { return wrap(o, '<textarea class="in" id="fld_' + o.name + '" name="' + o.name + '" rows="' + (o.rows || 6) + '" spellcheck="false">' + MQ.esc(o.value || '') + '</textarea>'); },
    check: function (o) { return '<label class="chk"><input type="checkbox" name="' + o.name + '"' + (o.value ? ' checked' : '') + '> ' + MQ.esc(o.label) + MQ.help(o.help) + '</label>'; },
    radio: function (o) {
      return wrap(o, '<div class="radio-row">' + o.options.map(function (op) {
        var v = Array.isArray(op) ? op[0] : op, l = Array.isArray(op) ? op[1] : op;
        return '<label><input type="radio" name="' + o.name + '" value="' + MQ.esc(v) + '"' + (String(v) === String(o.value) ? ' checked' : '') + '> ' + MQ.esc(l) + '</label>';
      }).join('') + '</div>');
    },
    sec: function (t, help) { return '<div class="fsec">' + MQ.esc(t) + MQ.help(help) + '</div>'; },
    preview: function (title, help) { return '<div class="preview-h">' + MQ.esc(title || 'Bu işlemin MQSC karşılığı') + MQ.help(help || 'mqsc') + '</div><pre class="preview-box" data-preview></pre>'; }
  };
  MQ.setPreview = function (form, text) { var p = form.querySelector('[data-preview]'); if (p) p.textContent = text; };

  /* MQ nesne adı doğrulama: en fazla 48 karakter; A-Z a-z 0-9 . / _ % */
  MQ.validName = function (n, max) {
    max = max || 48;
    if (!n) return 'Ad zorunludur.';
    if (n.length > max) return 'Ad en fazla ' + max + ' karakter olabilir.';
    if (!/^[A-Za-z0-9._\/%]+$/.test(n)) return 'Yalnızca A-Z, a-z, 0-9, nokta (.), eğik çizgi (/), alt çizgi (_) ve yüzde (%) kullanılabilir.';
    return '';
  };

  /* ------------------------------------------------------------------ table component */
  MQ._tables = {}; MQ._tstate = {};
  MQ.table = function (cfg) {
    MQ._tables[cfg.id] = cfg;
    var st = MQ._tstate[cfg.id] || (MQ._tstate[cfg.id] = { q: '', sort: cfg.defaultSort || null, page: 1, size: cfg.pageSize || 10, flt: {} });
    var tb = '<div class="tbl-toolbar">' +
      '<div class="info" data-tinfo>' + '</div>' +
      (cfg.search === false ? '' : '<div class="search">' + MQ.icon('search') + '<input data-tsearch="' + cfg.id + '" placeholder="Tabloda ara" value="' + MQ.esc(st.q) + '" aria-label="Tabloda ara"></div>') +
      (cfg.filters || []).map(function (f, i) {
        return '<select class="flt" data-tfilter="' + cfg.id + '" data-fi="' + i + '" aria-label="' + MQ.esc(f.label) + '">' +
          '<option value="">' + MQ.esc(f.label) + ': Tümü</option>' + f.options.map(function (o) {
            var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o;
            return '<option value="' + MQ.esc(v) + '"' + (st.flt[i] === v ? ' selected' : '') + '>' + MQ.esc(l) + '</option>';
          }).join('') + '</select>';
      }).join('') +
      '<button class="icon-btn" data-trefresh="' + cfg.id + '" title="Yenile" aria-label="Yenile">' + MQ.icon('refresh') + '</button>' +
      (cfg.create ? '<button class="btn" data-do="' + MQ.fn(cfg.create.fn) + '">' + MQ.esc(cfg.create.label || 'Create') + MQ.icon('add') + '</button>' : '') +
      (cfg.createHelp ? MQ.help(cfg.createHelp) : '') +
      '</div>';
    return '<div class="tbl-wrap" id="tbl-' + cfg.id + '">' + tb + '<div class="tbl-body">' + MQ.tableBody(cfg.id) + '</div></div>';
  };
  MQ.tableBody = function (id) {
    var cfg = MQ._tables[id], st = MQ._tstate[id];
    var all = cfg.rows();
    var rows = all.slice();
    (cfg.filters || []).forEach(function (f, i) { if (st.flt[i]) rows = rows.filter(function (r) { return f.fn(r, st.flt[i]); }); });
    if (st.q) {
      var q = st.q.toLowerCase();
      rows = rows.filter(function (r) {
        return cfg.columns.some(function (c) { var v = c.val ? c.val(r) : r[c.key]; return v !== undefined && v !== null && String(v).toLowerCase().indexOf(q) >= 0; });
      });
    }
    if (st.sort) {
      var col = cfg.columns.filter(function (c) { return c.key === st.sort.key; })[0];
      if (col) {
        var dir = st.sort.dir === 'desc' ? -1 : 1;
        rows.sort(function (a, b) {
          var x = col.val ? col.val(a) : a[col.key], y = col.val ? col.val(b) : b[col.key];
          if (typeof x === 'number' && typeof y === 'number') return (x - y) * dir;
          return String(x === undefined ? '' : x).localeCompare(String(y === undefined ? '' : y), 'tr', { numeric: true }) * dir;
        });
      }
    }
    var total = rows.length, pages = Math.max(1, Math.ceil(total / st.size));
    if (st.page > pages) st.page = pages;
    var start = (st.page - 1) * st.size, view = rows.slice(start, start + st.size);
    var head = '<tr>' + cfg.columns.map(function (c) {
      var sortable = c.sort !== false;
      var sorted = st.sort && st.sort.key === c.key;
      var arr = sorted ? (st.sort.dir === 'desc' ? '&#8595;' : '&#8593;') : '&#8645;';
      return '<th class="' + (sortable ? 'sortable ' : '') + (sorted ? 'sorted ' : '') + (c.num ? 'num' : '') + '"' + (sortable ? ' data-sort="' + id + '" data-key="' + c.key + '" tabindex="0" aria-sort="' + (sorted ? (st.sort.dir === 'desc' ? 'descending' : 'ascending') : 'none') + '"' : '') + '>' +
        MQ.esc(c.label) + (c.help ? MQ.help(c.help) : '') + (sortable ? '<span class="arr">' + arr + '</span>' : '') + '</th>';
    }).join('') + (cfg.overflow ? '<th style="width:48px"></th>' : '') + '</tr>';
    var body = view.length ? view.map(function (r) {
      return '<tr>' + cfg.columns.map(function (c) {
        var v = c.render ? c.render(r) : MQ.esc(MQ.fmt(r[c.key]));
        return '<td class="' + (c.wrap ? 'wrap ' : '') + (c.num ? 'num' : '') + '">' + v + '</td>';
      }).join('') + (cfg.overflow ? '<td class="ovf">' + MQ.overflow(cfg.overflow(r)) + '</td>' : '') + '</tr>';
    }).join('') : '<tr class="empty-row"><td colspan="' + (cfg.columns.length + (cfg.overflow ? 1 : 0)) + '">' + (cfg.empty || 'Gösterilecek kayıt yok.') + '</td></tr>';
    var pageOpts = ''; for (var p = 1; p <= pages; p++) pageOpts += '<option' + (p === st.page ? ' selected' : '') + '>' + p + '</option>';
    var pager = '<div class="tbl-pager"><div>Sayfa başına kayıt: <select data-tsize="' + id + '">' + [5, 10, 20, 50, 100].map(function (n) { return '<option' + (n === st.size ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select></div>' +
      '<div class="grow">' + (total ? (start + 1) + '–' + Math.min(start + st.size, total) + ' / ' + total + ' kayıt' : '0 kayıt') + '</div>' +
      '<div><select data-tpagesel="' + id + '">' + pageOpts + '</select> / ' + pages + ' sayfa</div>' +
      '<button data-tpage="' + id + '" data-d="-1" ' + (st.page <= 1 ? 'disabled' : '') + ' aria-label="Önceki sayfa">&#9664;</button>' +
      '<button data-tpage="' + id + '" data-d="1" ' + (st.page >= pages ? 'disabled' : '') + ' aria-label="Sonraki sayfa">&#9654;</button></div>';
    setTimeout(function () {
      var w = document.getElementById('tbl-' + id); if (!w) return;
      var inf = w.querySelector('[data-tinfo]'); if (inf) inf.textContent = cfg.info ? cfg.info(total, all.length) : (total + ' / ' + all.length + ' kayıt yüklendi');
    }, 0);
    return '<div class="tbl-scroll"><table class="tbl"><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>' + pager;
  };
  MQ.redrawTable = function (id) {
    var w = document.getElementById('tbl-' + id); if (!w || !MQ._tables[id]) return;
    w.querySelector('.tbl-body').innerHTML = MQ.tableBody(id);
  };
  MQ.redrawTables = function () { Object.keys(MQ._tables).forEach(MQ.redrawTable); };

  /* ------------------------------------------------------------------ charts (bağımlılıksız SVG) */
  MQ.COLORS = ['#33b1ff', '#08bdba', '#a56eff', '#ff7eb6', '#f1c21b', '#fa4d56', '#6fdc8c'];
  MQ.lineChart = function (o) {
    var W = 640, H = o.height || 220, pl = 44, pr = 12, pt = 12, pb = 26;
    var all = []; o.series.forEach(function (s) { all = all.concat(s.data); });
    var max = o.max || Math.max.apply(null, all.concat([1])); max = niceMax(max);
    var n = o.labels.length, iw = W - pl - pr, ih = H - pt - pb;
    var x = function (i) { return pl + (n <= 1 ? 0 : (i * iw) / (n - 1)); }, y = function (v) { return pt + ih - (v / max) * ih; };
    var g = '';
    for (var k = 0; k <= 4; k++) { var vv = (max / 4) * k; g += '<line class="grid-l" x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(vv) + '" y2="' + y(vv) + '"/><text x="' + (pl - 6) + '" y="' + (y(vv) + 4) + '" text-anchor="end">' + shortNum(vv) + (o.unit || '') + '</text>'; }
    var step = Math.ceil(n / 8);
    o.labels.forEach(function (l, i) { if (i % step === 0 || i === n - 1) g += '<text x="' + x(i) + '" y="' + (H - 6) + '" text-anchor="middle">' + MQ.esc(l) + '</text>'; });
    var lines = o.series.map(function (s, si) {
      var c = s.color || MQ.COLORS[si];
      var d = s.data.map(function (v, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1); }).join(' ');
      var area = o.area ? '<path d="' + d + ' L' + x(n - 1) + ' ' + (pt + ih) + ' L' + x(0) + ' ' + (pt + ih) + ' Z" fill="' + c + '" opacity=".12"/>' : '';
      var pts = s.data.map(function (v, i) { return '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(v).toFixed(1) + '" r="7" fill="transparent"><title>' + MQ.esc(s.name + ' · ' + o.labels[i] + ': ' + MQ.fmt(v) + (o.unit || '')) + '</title></circle>'; }).join('');
      return area + '<path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="2"/>' + pts;
    }).join('');
    var legend = '<div class="legend">' + o.series.map(function (s, si) { return '<span><i style="background:' + (s.color || MQ.COLORS[si]) + '"></i>' + MQ.esc(s.name) + '</span>'; }).join('') + '</div>';
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + MQ.esc(o.title || 'Grafik') + '">' + g + '<line class="axis" x1="' + pl + '" x2="' + (W - pr) + '" y1="' + (pt + ih) + '" y2="' + (pt + ih) + '"/>' + lines + '</svg>' + legend;
  };
  MQ.barChart = function (o) {
    var W = 640, H = o.height || 220, pl = 44, pr = 12, pt = 12, pb = 26;
    var n = o.labels.length, iw = W - pl - pr, ih = H - pt - pb;
    var totals = o.labels.map(function (_, i) { return o.series.reduce(function (a, s) { return a + (o.stacked ? s.data[i] : 0); }, 0) || Math.max.apply(null, o.series.map(function (s) { return s.data[i]; })); });
    var max = niceMax(Math.max.apply(null, totals.concat([1])));
    var y = function (v) { return pt + ih - (v / max) * ih; };
    var g = '';
    for (var k = 0; k <= 4; k++) { var vv = (max / 4) * k; g += '<line class="grid-l" x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(vv) + '" y2="' + y(vv) + '"/><text x="' + (pl - 6) + '" y="' + (y(vv) + 4) + '" text-anchor="end">' + shortNum(vv) + '</text>'; }
    var bw = iw / n, step = Math.ceil(n / 12), bars = '';
    o.labels.forEach(function (l, i) {
      var acc = 0, sc = o.series.length;
      o.series.forEach(function (s, si) {
        var v = s.data[i], c = s.color || MQ.COLORS[si], h = (v / max) * ih;
        var bx, w;
        if (o.stacked) { bx = pl + i * bw + bw * 0.18; w = bw * 0.64; bars += '<rect x="' + bx.toFixed(1) + '" y="' + (y(acc) - h).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + h.toFixed(1) + '" fill="' + c + '"><title>' + MQ.esc(s.name + ' · ' + l + ': ' + MQ.fmt(v)) + '</title></rect>'; acc += v; }
        else { w = (bw * 0.7) / sc; bx = pl + i * bw + bw * 0.15 + si * w; bars += '<rect x="' + bx.toFixed(1) + '" y="' + y(v).toFixed(1) + '" width="' + Math.max(1, w - 1).toFixed(1) + '" height="' + h.toFixed(1) + '" fill="' + c + '"><title>' + MQ.esc(s.name + ' · ' + l + ': ' + MQ.fmt(v)) + '</title></rect>'; }
      });
      if (i % step === 0) g += '<text x="' + (pl + i * bw + bw / 2) + '" y="' + (H - 6) + '" text-anchor="middle">' + MQ.esc(l) + '</text>';
    });
    var legend = '<div class="legend">' + o.series.map(function (s, si) { return '<span><i style="background:' + (s.color || MQ.COLORS[si]) + '"></i>' + MQ.esc(s.name) + '</span>'; }).join('') + '</div>';
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + MQ.esc(o.title || 'Grafik') + '">' + g + bars + '<line class="axis" x1="' + pl + '" x2="' + (W - pr) + '" y1="' + (pt + ih) + '" y2="' + (pt + ih) + '"/></svg>' + legend;
  };
  MQ.hbars = function (items) {
    return '<div style="padding:0 16px 16px">' + items.map(function (it) {
      var p = Math.min(100, MQ.pct(it.value, it.max));
      var cls = p >= 100 ? 'err' : (p >= (it.warn || 80) ? 'warn' : '');
      return '<div style="margin-top:12px"><div class="flex"><span class="grow" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + (it.link ? '<a href="' + it.link + '">' + MQ.esc(it.label) + '</a>' : MQ.esc(it.label)) + '</span><span class="mono-sm">' + MQ.fmt(it.value) + ' / ' + MQ.fmt(it.max) + ' (' + p + '%)</span></div><div class="meter ' + cls + '" style="margin-top:6px"><i style="width:' + Math.max(p, 0.5) + '%"></i></div></div>';
    }).join('') + '</div>';
  };
  MQ.donut = function (o) {
    var r = 40, c = 2 * Math.PI * r, p = Math.min(1, o.value / o.max);
    var col = o.color || (p > 0.9 ? '#fa4d56' : p > 0.75 ? '#f1c21b' : '#33b1ff');
    return '<svg viewBox="0 0 120 120" width="' + (o.size || 120) + '" height="' + (o.size || 120) + '" role="img" aria-label="' + MQ.esc(o.label) + '"><circle cx="60" cy="60" r="' + r + '" fill="none" stroke="var(--layer2)" stroke-width="12"/>' +
      '<circle cx="60" cy="60" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="12" stroke-dasharray="' + (c * p).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 60 60)"/>' +
      '<text x="60" y="58" text-anchor="middle" style="fill:var(--text);font-size:18px;font-family:var(--font)">' + MQ.esc(o.text || Math.round(p * 100) + '%') + '</text><text x="60" y="76" text-anchor="middle" style="fill:var(--text2);font-size:10px;font-family:var(--font)">' + MQ.esc(o.label) + '</text></svg>';
  };
  function niceMax(v) { if (v <= 0) return 1; var e = Math.pow(10, Math.floor(Math.log10(v))); var f = v / e; var nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10; return nf * e; }
  function shortNum(v) { if (v >= 1e6) return (v / 1e6).toFixed(v % 1e6 ? 1 : 0) + 'M'; if (v >= 1e3) return (v / 1e3).toFixed(v % 1e3 ? 1 : 0) + 'K'; return Math.round(v * 10) / 10; }

  /* ------------------------------------------------------------------ page chrome helpers */
  MQ.pageHead = function (o) {
    return '<div class="page-head' + (o.tabs ? '' : ' plain') + '">' +
      (o.crumbs ? '<div class="crumbs">' + o.crumbs.map(function (c) { return c[1] ? '<a href="' + c[1] + '">' + MQ.esc(c[0]) + '</a>' : MQ.esc(c[0]); }).join(' / ') + ' /</div>' : '') +
      '<div class="title-row"><h1>' + (o.icon ? MQ.icon(o.icon) : '') + MQ.esc(o.title) + (o.help ? MQ.help(o.help) : '') + '</h1><div class="grow"></div>' + (o.right || '') + '</div>' +
      (o.desc ? '<p class="page-desc">' + o.desc + '</p>' : '') +
      (o.tabs ? '<div class="tabs-row"><nav class="tabs" role="tablist">' + o.tabs.map(function (t) {
        return '<a role="tab" href="' + t.href + '" class="' + (t.active ? 'active' : '') + '" aria-selected="' + (t.active ? 'true' : 'false') + '">' + MQ.esc(t.label) + '</a>';
      }).join('') + '</nav>' + (o.tabsRight ? '<div class="tags">' + o.tabsRight + '</div>' : '') + '</div>' : '') +
      '</div>';
  };
  MQ.sidenav = function (items, active) {
    return '<nav class="sidenav">' + items.map(function (it) {
      if (it.group) return '<div class="side-group">' + MQ.esc(it.group) + '</div>';
      return '<a href="' + it.href + '" class="' + (it.key === active ? 'active' : '') + '">' + MQ.esc(it.label) + '</a>';
    }).join('') + '</nav>';
  };
  MQ.updated = function () {
    return '<div class="updated">Son güncelleme: birkaç saniye önce <button data-refresh title="Yenile" aria-label="Yenile">' + MQ.icon('refresh').replace('<svg', '<svg width="16" height="16"') + '</button></div>';
  };
  MQ.prop = function (label, attr, value, help) {
    return '<div class="prop" data-prop="' + MQ.esc((label + ' ' + (attr || '') + ' ' + value).toLowerCase()) + '"><div class="k">' + MQ.esc(label) + (attr ? '<span class="attr">' + MQ.esc(attr) + '</span>' : '') + MQ.help(help) + '</div><div class="v">' + (value === '' || value === undefined || value === null ? '<span class="dim">-</span>' : value) + '</div></div>';
  };

  /* ------------------------------------------------------------------ router */
  var routes = [];
  MQ.route = function (pattern, fn, rail) {
    var keys = [];
    var re = new RegExp('^' + pattern.replace(/:(\w+)/g, function (_, k) { keys.push(k); return '([^/]+)'; }) + '/?$');
    routes.push({ re: re, keys: keys, fn: fn, rail: rail });
  };
  var lastPath = '';
  MQ.refresh = function () { dispatch(true); };
  function dispatch(keepScroll) {
    var path = (location.hash || '#/home').slice(1) || '/home';
    var main = document.getElementById('main');
    closeMenus(); MQ.closeModal();
    MQ._fns = {}; MQ._menus = {}; MQ._tables = {}; MQ._after = [];
    var html = null, rail = '';
    for (var i = 0; i < routes.length; i++) {
      var m = path.match(routes[i].re);
      if (m) {
        var params = {};
        routes[i].keys.forEach(function (k, j) { params[k] = decodeURIComponent(m[j + 1]); });
        try { html = routes[i].fn(params); } catch (err) { console.error(err); html = errorPage('Sayfa oluşturulurken bir hata oluştu: ' + err.message); }
        rail = routes[i].rail; break;
      }
    }
    if (html === null) html = errorPage('İstenen sayfa bulunamadı: ' + MQ.esc(path));
    main.innerHTML = html;
    var as = document.querySelectorAll('.rail a');
    for (var a = 0; a < as.length; a++) as[a].classList.toggle('active', as[a].getAttribute('data-rail') === rail);
    document.getElementById('rail').classList.remove('open');
    MQ._after.forEach(function (f) { try { f(); } catch (e) { console.error(e); } });
    if (!keepScroll && path !== lastPath) window.scrollTo(0, 0);
    lastPath = path;
    var h1 = main.querySelector('h1'); document.title = (h1 ? h1.textContent.replace(/\?$/, '').trim() + ' - ' : '') + 'IBM MQ Console (Eğitim Simülasyonu)';
  }
  MQ.after = function (f) { MQ._after.push(f); };
  function errorPage(msg) {
    return MQ.pageHead({ title: 'Sayfa bulunamadı' }) + '<div class="content"><div class="notice err">' + MQ.icon('error') + '<div class="grow">' + msg + '<br><a href="#/home">Ana sayfaya dön</a></div></div></div>';
  }

  /* ------------------------------------------------------------------ global events */
  document.addEventListener('click', function (e) {
    var t = e.target;
    var h = t.closest('[data-help]');
    if (h) { e.preventDefault(); e.stopPropagation(); MQ.openHelp(h.getAttribute('data-help')); return; }
    if (t.closest('[data-close-help]')) { MQ.closeHelp(); return; }
    var mb = t.closest('[data-menu]');
    if (mb) { e.preventDefault(); e.stopPropagation(); var isOpen = document.querySelector('.menu.floating') && mb.classList.contains('menu-open'); var prev = document.querySelector('.menu-open'); if (prev) prev.classList.remove('menu-open'); if (isOpen) { closeMenus(); return; } mb.classList.add('menu-open'); openMenu(mb); return; }
    if (!t.closest('.menu')) { closeMenus(); var po = document.querySelector('.menu-open'); if (po) po.classList.remove('menu-open'); }
    var d = t.closest('[data-do]');
    if (d) { if (!d.matches('input')) e.preventDefault(); var f = MQ._fns[d.getAttribute('data-do')]; if (f) f(d, e); return; }
    var s = t.closest('th[data-sort]');
    if (s) {
      var id = s.getAttribute('data-sort'), key = s.getAttribute('data-key'), st = MQ._tstate[id];
      st.sort = st.sort && st.sort.key === key ? (st.sort.dir === 'asc' ? { key: key, dir: 'desc' } : null) : { key: key, dir: 'asc' };
      MQ.redrawTable(id); return;
    }
    var pg = t.closest('[data-tpage]');
    if (pg) { var pid = pg.getAttribute('data-tpage'); MQ._tstate[pid].page += parseInt(pg.getAttribute('data-d'), 10); MQ.redrawTable(pid); return; }
    var rf = t.closest('[data-trefresh]');
    if (rf) { MQ.redrawTable(rf.getAttribute('data-trefresh')); MQ.toast('info', 'Tablo yenilendi', 'Simülasyon verileri yeniden okundu.'); return; }
    if (t.closest('[data-refresh]')) { MQ.refresh(); MQ.toast('info', 'Yenilendi', 'Gösterilen değerler simülasyon verilerinden yeniden okundu.'); return; }
    if (t.closest('#railToggle')) { document.getElementById('rail').classList.toggle('open'); return; }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (document.querySelector('.menu.floating')) closeMenus(); else if (document.getElementById('modalOverlay')) MQ.closeModal(); else MQ.closeHelp(); }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('th[data-sort]')) { e.preventDefault(); e.target.click(); }
  });
  document.addEventListener('input', function (e) {
    var s = e.target.getAttribute && e.target.getAttribute('data-tsearch');
    if (s) { MQ._tstate[s].q = e.target.value; MQ._tstate[s].page = 1; MQ.redrawTable(s); }
    var fe = e.target.closest && e.target.closest('.field.invalid'); if (fe) fe.classList.remove('invalid');
  });
  document.addEventListener('change', function (e) {
    var t = e.target;
    var z = t.getAttribute('data-tsize'); if (z) { MQ._tstate[z].size = parseInt(t.value, 10); MQ._tstate[z].page = 1; MQ.redrawTable(z); return; }
    var p = t.getAttribute('data-tpagesel'); if (p) { MQ._tstate[p].page = parseInt(t.value, 10); MQ.redrawTable(p); return; }
    var fl = t.getAttribute('data-tfilter'); if (fl) { MQ._tstate[fl].flt[t.getAttribute('data-fi')] = t.value; MQ._tstate[fl].page = 1; MQ.redrawTable(fl); }
  });
  window.addEventListener('scroll', closeMenus, true);
  window.addEventListener('resize', closeMenus);
  window.addEventListener('hashchange', function () { dispatch(false); });

  MQ.start = function () {
    MQ.loadState();
    MQ.applyPrefs();
    dispatch(false);
  };
})();
