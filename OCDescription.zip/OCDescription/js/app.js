/* OpenShift Eğitim Konsolu – uygulama kabuğu, yönlendirme, liste/detay motoru */
(function () {
  "use strict";
  const OC = window.OC, U = OC.u, H = OC.H, K = OC.K, R = OC.r, db = OC.db;
  const { $, $$, esc } = U;

  const clone = (x) => JSON.parse(JSON.stringify(x, (k, v) => (k && k[0] === "_" ? undefined : v)));
  /* ---------------- Durum ---------------- */
  const st = (OC.st = {
    ns: U.store.get("ns", "eticaret-prod"),
    learn: U.store.get("learn", true),
    theme: U.store.get("theme", "dark"),
    favs: U.store.get("favs", []),
    navOpen: U.store.get("navOpen", { home: true, ecosystem: true, helm: true, workloads: true, networking: true, storage: true, builds: true, pipelines: false, observe: false, compute: false, usermgmt: false, admin: false }),
    hiddenCols: U.store.get("hiddenCols", {}),
    showSys: U.store.get("showSys", true),
    timers: []
  });
  if (st.ns !== "all" && !db.Namespace.some((n) => n.metadata.name === st.ns)) st.ns = "eticaret-prod";
  document.documentElement.setAttribute("data-theme", st.theme);
  document.body.classList.toggle("learn-off", !st.learn);

  /* ---------------- Menü yapısı (OpenShift 4.20 konsol düzeni) ---------------- */
  const NAV = [
    { id: "home", t: "Home", h: "nav-home", items: [["Overview", "#/dashboard", "overview"], ["Projects", "Project"], ["Search", "#/search", "search"], ["API Explorer", "#/api-explorer", "api-explorer"], ["Events", "#/events", "event"]] },
    { id: "favorites", t: "Favorites", h: "favorites", fav: true },
    { id: "ecosystem", t: "Ecosystem", h: "nav-ecosystem", items: [["Software Catalog", "#/catalog", "software-catalog"], ["Installed Operators", "ClusterServiceVersion"]] },
    { id: "helm", t: "Helm", h: "nav-helm", items: [["Repositories", "HelmChartRepository", "helm-repo"], ["Releases", "#/helm-releases", "helm-release"]] },
    { id: "workloads", t: "Workloads", h: "nav-workloads", items: [["Topology", "#/topology", "topology"], ["Pods", "Pod"], ["Deployments", "Deployment"], ["DeploymentConfigs", "DeploymentConfig"], ["StatefulSets", "StatefulSet"], ["Secrets", "Secret"], ["ConfigMaps", "ConfigMap"], "-", ["CronJobs", "CronJob"], ["Jobs", "Job"], ["DaemonSets", "DaemonSet"], ["ReplicaSets", "ReplicaSet"], ["ReplicationControllers", "ReplicationController"], ["HorizontalPodAutoscalers", "HorizontalPodAutoscaler"], ["PodDisruptionBudgets", "PodDisruptionBudget"]] },
    { id: "networking", t: "Networking", h: "nav-networking", items: [["Services", "Service"], ["Routes", "Route"], ["Ingresses", "Ingress"], ["NetworkPolicies", "NetworkPolicy"], ["UserDefinedNetworks", "UserDefinedNetwork"]] },
    { id: "storage", t: "Storage", h: "nav-storage", items: [["PersistentVolumeClaims", "PersistentVolumeClaim"], ["PersistentVolumes", "PersistentVolume"], ["StorageClasses", "StorageClass"], ["VolumeSnapshots", "VolumeSnapshot"], ["VolumeSnapshotClasses", "VolumeSnapshotClass"], ["Object Storage", "ObjectBucketClaim", "obc"]] },
    { id: "builds", t: "Builds", h: "nav-builds", items: [["BuildConfigs", "BuildConfig"], ["Builds", "Build"], ["ImageStreams", "ImageStream"]] },
    { id: "pipelines", t: "Pipelines", h: "nav-pipelines", items: [["Pipelines", "Pipeline"], ["PipelineRuns", "PipelineRun"], ["Tasks", "Task"]] },
    { id: "observe", t: "Observe", h: "nav-observe", items: [["Alerting", "#/alerts", "alerting"], ["Metrics", "#/metrics", "metrics"], ["Dashboards", "#/dashboards", "dashboards"], ["Targets", "#/targets", "targets"]] },
    { id: "compute", t: "Compute", h: "nav-compute", items: [["Nodes", "Node"], ["Machines", "Machine"], ["MachineSets", "MachineSet"], ["MachineAutoscalers", "MachineAutoscaler"], ["MachineHealthChecks", "MachineHealthCheck"], ["MachineConfigs", "MachineConfig"], ["MachineConfigPools", "MachineConfigPool"]] },
    { id: "usermgmt", t: "User Management", h: "nav-usermgmt", items: [["Users", "User"], ["Groups", "Group"], ["ServiceAccounts", "ServiceAccount"], ["Roles", "Role"], ["RoleBindings", "RoleBinding"]] },
    { id: "admin", t: "Administration", h: "nav-admin", items: [["Cluster Settings", "#/settings/cluster", "cluster-settings"], ["Namespaces", "Namespace"], ["ResourceQuotas", "ResourceQuota"], ["LimitRanges", "LimitRange"], ["CustomResourceDefinitions", "CustomResourceDefinition"], ["Dynamic Plugins", "#/plugins", "dynamic-plugins"]] }
  ];
  K.Role.merge = ["ClusterRole"];
  K.RoleBinding.merge = ["ClusterRoleBinding"];
  K.HelmChartRepository.merge = ["ProjectHelmChartRepository"];
  K.HelmChartRepository.label = "Helm Repositories";
  K.ObjectBucketClaim.label = "Object Bucket Claims";
  K.ClusterServiceVersion.nameV = (o) => `<span class="rlink">${opIcon(o.spec.displayName)}<span><a href="${R.href("ClusterServiceVersion", o.metadata.namespace, o.metadata.name)}"><b>${esc(o.spec.displayName)}</b></a><div class="muted sm">${esc(o.spec.version)} provided by ${esc(o.spec.provider.name)}</div></span></span>`;
  K.ClusterServiceVersion.cols = [{ t: "Managed Namespaces", v: (o) => (o._all ? "All Namespaces" : R.nsLink(o.metadata.namespace)), h: "install-mode" }, { t: "Status", v: (o) => R.status(o.status.phase) + '<div class="muted sm">Up to date</div>', h: "csv-status" }, { t: "Last updated", v: (o) => U.ts(o.metadata.creationTimestamp) }, { t: "Provided APIs", v: (o) => o.spec.customresourcedefinitions.owned.slice(0, 3).map((c) => `<div><a href="#" data-nop="1">${esc(c.displayName)}</a></div>`).join("") + (o.spec.customresourcedefinitions.owned.length > 3 ? '<div class="muted sm">+' + (o.spec.customresourcedefinitions.owned.length - 3) + " more</div>" : ""), h: "crd" }];
  function opIcon(name) { const c = ["#e00", "#0066cc", "#5e40be", "#3d7317", "#c46100", "#009596"][name.length % 6]; return `<span class="op-ico" style="background:${c}">${esc(name.replace(/^Red Hat (build of )?(OpenShift )?/, "").slice(0, 1))}</span>`; }
  OC.opIcon = opIcon;

  /* ---------------- Yönlendirme ---------------- */
  function parse() {
    const raw = location.hash.replace(/^#/, "") || "/dashboard";
    const [path, qs] = raw.split("?");
    const p = path.split("/").filter(Boolean).map(decodeURIComponent);
    const q = {}; (qs || "").split("&").filter(Boolean).forEach((kv) => { const [a, b] = kv.split("="); q[a] = decodeURIComponent(b || ""); });
    const r = { p: p, q: q, raw: raw };
    if (p[0] === "k8s") {
      if (p[1] === "all") Object.assign(r, { type: "list", ns: "all", kind: OC.byPlural[p[2]] });
      else if (p[1] === "ns") Object.assign(r, { type: p[4] ? "detail" : "list", ns: p[2], kind: OC.byPlural[p[3]], name: p[4], tab: p[5] || "details" });
      else if (p[1] === "cluster") Object.assign(r, { type: p[3] ? "detail" : "list", kind: OC.byPlural[p[2]], name: p[3], tab: p[4] || "details" });
      if (!r.kind) r.type = "404";
    } else if (p[0] === "create") Object.assign(r, { type: "create", kind: OC.byPlural[p[1]] });
    else if (p[0] === "import") Object.assign(r, { type: "create", kind: null });
    else Object.assign(r, { type: "page", page: p[0] || "dashboard", sub: p[1] });
    return r;
  }
  OC.listHref = (kind, ns) => { const k = K[kind]; if (!k.ns) return R.href(kind); ns = ns || st.ns; return ns === "all" ? `#/k8s/all/${k.plural}` : `#/k8s/ns/${ns}/${k.plural}`; };
  OC.go = (h) => { if (location.hash === h) render(); else location.hash = h; };

  /* ---------------- Sol menü ---------------- */
  function itemHref(it) { return it[1][0] === "#" ? it[1] : OC.listHref(it[1]); }
  function isActive(it, r) {
    if (it[1][0] === "#") return r.raw.indexOf(it[1].slice(1)) === 0 || (it[1] === "#/dashboard" && r.page === "dashboard");
    const k = K[it[1]];
    return r.kind && (r.kind === it[1] || (k.merge && k.merge.indexOf(r.kind) >= 0)) || (it[1] === "Project" && r.kind === "Project");
  }
  function renderNav(r) {
    const html = NAV.map((s) => {
      const open = s.fav ? st.navOpen.favorites !== false : st.navOpen[s.id];
      let body;
      if (s.fav) body = st.favs.length ? st.favs.map((f) => `<a class="nav-i ${location.hash === f.h ? "active" : ""}" href="${esc(f.h)}"><span>${esc(f.t)}</span><button class="nav-unfav" data-unfav="${esc(f.h)}" title="Favorilerden çıkar">&#10005;</button></a>`).join("") : '<div class="nav-empty">No favorites added</div>';
      else body = s.items.map((it) => (it === "-" ? '<div class="nav-sep"></div>' : `<a class="nav-i ${isActive(it, r) ? "active" : ""}" href="${itemHref(it)}"><span>${esc(it[0])}</span>${R.q(it[2] || (K[it[1]] && K[it[1]].help), "qh-nav")}</a>`)).join("");
      return `<div class="nav-s ${open ? "open" : ""}"><div class="nav-st" role="button" tabindex="0" data-sec="${s.id}" aria-expanded="${open}"><span>${esc(s.t)}</span>${R.q(s.h, "qh-nav")}<i class="chev">${U.ico("chev", 12)}</i></div><div class="nav-b">${body}</div></div>`;
    }).join("");
    const sb = $("#sidebar"), sc = sb.scrollTop;
    sb.innerHTML = `<div class="nav-learn"><a class="nav-i learn-link ${r.page === "learn" ? "active" : ""}" href="#/learn">${U.ico("book", 14)}<span>Öğrenme Merkezi</span></a></div>` + html;
    sb.scrollTop = sc;
  }

  /* ---------------- Proje seçici çubuğu ---------------- */
  function renderNsBar(show) {
    const bar = $("#nsbar");
    if (!show) { bar.innerHTML = ""; bar.hidden = true; return; }
    bar.hidden = false;
    const label = st.ns === "all" ? "All Projects" : st.ns;
    bar.innerHTML = `<button class="ns-btn" id="nsBtn"><span class="ns-l">Project:</span> <b>${esc(label)}</b> <i class="caret"></i></button>${R.q("ui-project-selector")}`;
  }
  function nsMenu(anchor) {
    const sys = (n) => /^(openshift|kube|default$)/.test(n);
    const list = (f) => db.Project.filter((p) => (st.showSys || !sys(p.metadata.name)) && (!f || p.metadata.name.indexOf(f) >= 0)).map((p) => `<button class="mi ${p.metadata.name === st.ns ? "sel" : ""}" data-ns="${esc(p.metadata.name)}">${esc(p.metadata.name)}${(p.metadata.annotations || {})["openshift.io/display-name"] ? `<small>${esc(p.metadata.annotations["openshift.io/display-name"])}</small>` : ""}</button>`).join("");
    const m = openMenu(anchor, `<div class="ns-menu"><div class="mi-search">${U.ico("search", 12)}<input id="nsFilter" placeholder="Select project..." autocomplete="off"></div><label class="mi-toggle"><input type="checkbox" id="nsSys" ${st.showSys ? "checked" : ""}> Show default projects</label><button class="mi ${st.ns === "all" ? "sel" : ""}" data-ns="all"><b>All Projects</b></button><div class="mi-div"></div><div id="nsList">${list()}</div><div class="mi-div"></div><button class="mi" data-go="#/create/projects">${U.ico("plus", 11)} Create Project</button></div>`, "ns-pop");
    const f = $("#nsFilter", m); f.focus();
    f.addEventListener("input", () => ($("#nsList", m).innerHTML = list(f.value.trim())));
    $("#nsSys", m).addEventListener("change", (e) => { st.showSys = e.target.checked; U.store.set("showSys", st.showSys); $("#nsList", m).innerHTML = list(f.value.trim()); });
  }
  function setNs(ns) {
    st.ns = ns; U.store.set("ns", ns);
    const r = parse();
    if (r.type === "list" && K[r.kind].ns) return OC.go(OC.listHref(r.kind, ns));
    if (r.type === "detail" && K[r.kind].ns) return OC.go(OC.listHref(r.kind, ns));
    render();
  }

  /* ---------------- Sayfa başlığı ---------------- */
  OC.pageHead = function (title, help, opt) {
    opt = opt || {};
    const fav = st.favs.some((f) => f.h === location.hash);
    return `<div class="ph ${opt.cls || ""}">${opt.crumb || ""}<div class="ph-row"><h1 class="ph-t">${opt.badge || ""}<span class="ph-tt">${esc(title)}</span>${opt.status || ""}${R.q(help)}</h1><div class="ph-r">${opt.right || ""}<button class="fav-btn ${fav ? "on" : ""}" id="favBtn" title="${fav ? "Favorilerden çıkar" : "Favorilere ekle"}">${U.ico("star", 18)}</button>${R.q("ui-favorite", "qh-fav")}</div></div>${opt.desc ? `<p class="ph-desc">${opt.desc}</p>` : ""}</div>`;
  };

  /* ---------------- LİSTE MOTORU ---------------- */
  function itemsFor(kind, ns) {
    const k = K[kind];
    let items = [kind].concat(k.merge || []).reduce((a, kk) => a.concat(OC.items(kk)), []);
    if (ns && ns !== "all") items = items.filter((o) => !K[o.kind].ns || o.metadata.namespace === ns);
    if ((kind === "Project" || kind === "Namespace") && !st.showSys) items = items.filter((o) => !/^(openshift|kube|default$)/.test(o.metadata.name));
    return items;
  }
  OC.itemsFor = itemsFor;
  function listPage(r) {
    const kind = r.kind, k = K[kind];
    if (k.ns && r.ns && r.ns !== st.ns) { st.ns = r.ns; U.store.set("ns", r.ns); }
    const ns = k.ns ? st.ns : null;
    const L = (st.list = { kind: kind, q: r.q.q || "", mode: r.q.mode || "name", filters: new Set(), sort: { i: 0, dir: 1 } });
    const canCreate = !!k.tpl || !!k.form;
    const createBtn = canCreate ? `<button class="btn btn-primary" data-go="#/create/${k.plural}">Create ${esc(kind === "Project" ? "Project" : kind)}</button>${R.q("ui-create")}` : "";
    const info = { Project: "Proje (namespace), uygulamalarınızın ve kaynaklarınızın izole çalışma alanıdır.", ClusterServiceVersion: "Installed Operators are represented by ClusterServiceVersions within this namespace.", Pod: null }[kind];
    $("#page").innerHTML = OC.pageHead(k.label, k.help, { right: createBtn, desc: info ? esc(info) : "" }) +
      `<div class="page-body"><div class="toolbar">
        ${k.filter ? `<div class="tb-g"><button class="btn btn-outline" id="filterBtn">${U.ico("filter", 12)} Filter <i class="caret"></i></button>${R.q("ui-filter")}</div>` : ""}
        <div class="tb-g sgroup"><button class="btn btn-outline" id="modeBtn"><span id="modeL">${L.mode === "label" ? "Label" : "Name"}</span> <i class="caret"></i></button><div class="search-box"><input id="listQ" placeholder="${L.mode === "label" ? "Search by label..." : "Search by name..."}" value="${esc(L.q)}" autocomplete="off"><kbd>/</kbd></div>${R.q("ui-name-label-search")}</div>
        <div class="tb-g"><button class="icon-btn" id="colsBtn" title="Manage columns">${U.ico("cols", 15)}</button>${R.q("ui-columns")}</div>
        ${kind === "Project" || kind === "Namespace" ? `<label class="chk"><input type="checkbox" id="sysChk" ${st.showSys ? "checked" : ""}> Show default projects</label>` : ""}
      </div><div class="chipbar" id="chipbar"></div><div id="listT"></div></div>`;
    const draw = () => drawList(kind, ns);
    draw();
    const q = $("#listQ");
    q.addEventListener("input", () => { L.q = q.value; draw(); });
    $("#modeBtn").addEventListener("click", (e) => { const m = openMenu(e.currentTarget, `<button class="mi" data-m="name">Name</button><button class="mi" data-m="label">Label</button>`); m.addEventListener("click", (ev) => { const b = ev.target.closest("[data-m]"); if (!b) return; L.mode = b.dataset.m; $("#modeL").textContent = L.mode === "label" ? "Label" : "Name"; q.placeholder = L.mode === "label" ? "Search by label... (ör. app=frontend)" : "Search by name..."; closeMenus(); draw(); q.focus(); }); });
    if (k.filter) $("#filterBtn").addEventListener("click", (e) => {
      const all = itemsFor(kind, ns);
      const m = openMenu(e.currentTarget, `<div class="mi-h">${esc(k.filter.title)}</div>` + k.filter.opts.map((o) => `<label class="mi mi-chk"><input type="checkbox" value="${esc(o)}" ${L.filters.has(o) ? "checked" : ""}> ${esc(o)} <span class="cnt">${all.filter((x) => k.filter.fn(x) === o).length}</span></label>`).join(""));
      m.addEventListener("change", (ev) => { const v = ev.target.value; ev.target.checked ? L.filters.add(v) : L.filters.delete(v); draw(); });
    });
    $("#colsBtn").addEventListener("click", () => colsModal(kind, draw));
    const sc = $("#sysChk"); if (sc) sc.addEventListener("change", () => { st.showSys = sc.checked; U.store.set("showSys", st.showSys); draw(); });
  }
  function visibleCols(kind) {
    const k = K[kind], hid = st.hiddenCols[kind];
    return k.cols.filter((c) => (hid ? hid.indexOf(c.t) < 0 : !c.hidden));
  }
  function drawList(kind, ns) {
    const k = K[kind], L = st.list;
    let items = itemsFor(kind, ns);
    const qv = L.q.trim().toLowerCase();
    if (qv) {
      if (L.mode === "label") { const parts = qv.split(",").map((s) => s.trim()).filter(Boolean); items = items.filter((o) => parts.every((p) => { const [a, b] = p.split("="); const lab = o.metadata.labels || {}; return Object.keys(lab).some((x) => x.toLowerCase() === a && (b === undefined || String(lab[x]).toLowerCase() === b)); })); }
      else items = items.filter((o) => o.metadata.name.toLowerCase().indexOf(qv) >= 0 || (o.spec && o.spec.displayName && o.spec.displayName.toLowerCase().indexOf(qv) >= 0));
    }
    if (L.filters.size) items = items.filter((o) => L.filters.has(k.filter.fn(o)));
    const cols = visibleCols(kind);
    const showNs = k.ns && ns === "all";
    const allCols = [{ t: "Name", s: (o) => o.metadata.name, h: "name", v: (o) => (k.nameV ? k.nameV(o) : R.link(o.kind, o.metadata.namespace, o.metadata.name)) }].concat(showNs ? [{ t: "Namespace", s: (o) => o.metadata.namespace, v: (o) => R.nsLink(o.metadata.namespace), h: "namespace-field" }] : []).concat(cols);
    const sc = allCols[L.sort.i] || allCols[0];
    if (sc.s) items = items.slice().sort((a, b) => { const x = sc.s(a), y = sc.s(b); return (x > y ? 1 : x < y ? -1 : 0) * L.sort.dir; });
    $("#chipbar").innerHTML = L.filters.size ? `<span class="fchip-g"><span class="fchip-t">${esc(k.filter.title)}</span>${Array.from(L.filters).map((f) => `<span class="fchip">${esc(f)}<button data-rmf="${esc(f)}">&#10005;</button></span>`).join("")}</span><button class="btn btn-link btn-sm" data-clearf="1">Clear all filters</button>` : "";
    const host = $("#listT");
    if (!items.length) { host.innerHTML = `<div class="empty"><div class="empty-ic">${U.ico("search", 34)}</div><h3>No ${esc(k.label)} found</h3><p class="muted">${qv || L.filters.size ? "Arama veya filtre ölçütlerinize uyan kaynak yok." : ns && ns !== "all" ? "Seçili projede (" + esc(ns) + ") bu türde kaynak bulunmuyor. Üstteki Project seçiciden başka bir proje veya <b>All Projects</b> seçebilirsiniz." : ""}</p>${R.q(k.help)}</div>`; return; }
    host.innerHTML = `<div class="tbl-wrap"><table class="tbl list-tbl"><thead><tr>${allCols.map((c, i) => `<th class="${c.cls || ""}"><button class="sort ${L.sort.i === i ? "on" : ""}" data-sort="${i}">${esc(c.t)} <span class="si">${U.ico(L.sort.i === i ? (L.sort.dir > 0 ? "up" : "down") : "sort", 10)}</span></button>${c.h ? R.q(c.h) : ""}</th>`).join("")}<th class="kc"></th></tr></thead><tbody>${items.map((o, ri) => `<tr>${allCols.map((c) => `<td class="${c.cls || ""}">${c.v(o)}</td>`).join("")}<td class="kc"><button class="kebab" data-kebab="${ri}" aria-label="Actions">${U.ico("kebab", 14)}</button></td></tr>`).join("")}</tbody></table></div><div class="list-foot muted">${items.length} öğe ${R.q("ui-kebab")}</div>`;
    host.querySelectorAll("[data-sort]").forEach((b) => b.addEventListener("click", () => { const i = +b.dataset.sort; L.sort = { i: i, dir: L.sort.i === i ? -L.sort.dir : 1 }; drawList(kind, ns); }));
    host.querySelectorAll("[data-kebab]").forEach((b) => b.addEventListener("click", (e) => actionsMenu(e.currentTarget, items[+b.dataset.kebab])));
    $("#chipbar").onclick = (e) => { const b = e.target.closest("[data-rmf]"); if (b) { L.filters.delete(b.dataset.rmf); drawList(kind, ns); } if (e.target.closest("[data-clearf]")) { L.filters.clear(); drawList(kind, ns); } };
  }
  OC.miniList = function (kind, items, opt) {
    opt = opt || {};
    const k = K[kind];
    const cols = (opt.cols || visibleCols(kind));
    if (!items.length) return `<div class="empty-s">${esc(opt.empty || "No " + k.label + " found")}</div>`;
    return `<div class="tbl-wrap"><table class="tbl list-tbl"><thead><tr><th>Name${R.q("name")}</th>${opt.ns ? "<th>Namespace</th>" : ""}${cols.map((c) => `<th class="${c.cls || ""}">${esc(c.t)}${c.h ? R.q(c.h) : ""}</th>`).join("")}</tr></thead><tbody>${items.map((o) => `<tr><td>${k.nameV ? k.nameV(o) : R.link(o.kind, o.metadata.namespace, o.metadata.name)}</td>${opt.ns ? `<td>${R.nsLink(o.metadata.namespace)}</td>` : ""}${cols.map((c) => `<td class="${c.cls || ""}">${c.v(o)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  };
  function colsModal(kind, redraw) {
    const k = K[kind], vis = visibleCols(kind).map((c) => c.t);
    modal("Manage columns", `<p class="muted">Tabloda görüntülenecek sütunları seçin. ${R.q("ui-columns")}</p><div class="col-list"><label class="chk dis"><input type="checkbox" checked disabled> Name</label>${k.cols.map((c) => `<label class="chk"><input type="checkbox" value="${esc(c.t)}" ${vis.indexOf(c.t) >= 0 ? "checked" : ""}> ${esc(c.t)}</label>`).join("")}</div>`, [["Save", "primary", (m) => { const on = $$("input[value]", m).filter((i) => i.checked).map((i) => i.value); st.hiddenCols[kind] = k.cols.map((c) => c.t).filter((t) => on.indexOf(t) < 0); U.store.set("hiddenCols", st.hiddenCols); redraw(); return true; }], ["Restore default columns", "link", () => { delete st.hiddenCols[kind]; U.store.set("hiddenCols", st.hiddenCols); redraw(); return true; }], ["Cancel", "secondary"]]);
  }

  /* ---------------- DETAY MOTORU ---------------- */
  const TAB_L = { details: ["Details", "tab-details"], metrics: ["Metrics", "tab-metrics"], yaml: ["YAML", "tab-yaml"], environment: ["Environment", "tab-environment"], logs: ["Logs", "tab-logs"], events: ["Events", "tab-events"], terminal: ["Terminal", "tab-terminal"], pods: ["Pods", "tab-pods"], replicasets: ["ReplicaSets", "replicaset"], replicationcontrollers: ["ReplicationControllers", "replicationcontroller"], jobs: ["Jobs", "job"], builds: ["Builds", "build"], pipelineruns: ["PipelineRuns", "pipelinerun"], parameters: ["Parameters", "pipeline"], rolebindings: ["RoleBindings", "rolebinding"], instances: ["Instances", "crd"], overview: ["Overview", "project"], workloads: ["Workloads", "nav-workloads"] };
  const T = (OC.T = OC.T || {});
  function detailPage(r) {
    const kind = r.kind, k = K[kind];
    if (k.ns && r.ns !== st.ns && st.ns !== "all") { st.ns = r.ns; U.store.set("ns", r.ns); }
    const o = OC.find(kind, r.ns, r.name);
    if (!o) { $("#page").innerHTML = OC.pageHead("404: Not Found", null) + `<div class="page-body"><div class="empty"><h3>${esc(kind)} "${esc(r.name)}" bulunamadı</h3><p class="muted">Kaynak silinmiş olabilir (simülasyonda yapılan silmeler sayfa yenilenince geri gelir).</p><a class="btn btn-primary" href="${OC.listHref(kind)}">${esc(k.label)} listesine dön</a></div></div>`; return; }
    const tabs = k.tabs.filter((t) => TAB_L[t]);
    const tab = tabs.indexOf(r.tab) >= 0 ? r.tab : tabs[0];
    const statusPill = kind === "Pod" ? `<span class="spill">${R.statusIcon(OC.podStatus(o))} ${esc(OC.podStatus(o))}</span>` : kind === "Build" ? `<span class="spill">${R.statusIcon(o.status.phase)} ${esc(o.status.phase)}</span>` : kind === "PipelineRun" ? `<span class="spill">${R.statusIcon(o._st)} ${esc(o._st)}</span>` : kind === "Node" ? `<span class="spill">${R.statusIcon(o.spec.unschedulable ? "SchedulingDisabled" : "Ready")} ${o.spec.unschedulable ? "Ready, SchedulingDisabled" : "Ready"}</span>` : "";
    const crumb = `<nav class="crumb"><a href="${kind === "ClusterServiceVersion" ? OC.listHref(kind) : OC.listHref(kind, r.ns)}">${esc(k.label)}</a><span class="sep">${U.ico("chevr", 10)}</span><span>${esc(kind === "ClusterServiceVersion" ? "Operator details" : kind + " details")}</span>${R.q("ui-breadcrumb")}</nav>`;
    const title = kind === "ClusterServiceVersion" ? o.spec.displayName : o.metadata.name;
    $("#page").innerHTML = OC.pageHead(title, k.help, { crumb: crumb, badge: kind === "ClusterServiceVersion" ? opIcon(o.spec.displayName) : R.badge(kind), status: statusPill, cls: "ph-detail", right: k.actions && k.actions.length ? `<button class="btn btn-primary" id="actBtn">Actions <i class="caret"></i></button>${R.q("ui-actions")}` : "" }) +
      `<div class="tabs" role="tablist">${tabs.map((t) => `<a class="tab ${t === tab ? "on" : ""}" href="${R.href(kind, o.metadata.namespace, o.metadata.name, t)}" role="tab">${esc(TAB_L[t][0])}</a>`).join("")}<span class="tabs-q">${R.q(TAB_L[tab][1])}</span></div><div class="page-body tab-body" id="tabBody"></div>`;
    const ab = $("#actBtn"); if (ab) ab.addEventListener("click", (e) => actionsMenu(e.currentTarget, o));
    (T[tab] || T.details)(o, $("#tabBody"), r);
  }

  T.details = function (o, el) {
    const k = K[o.kind];
    const d = k.details ? k.details(o) : { l: OC.metaRows(o), r: [] };
    const ring = k.ring ? podRing(o) : "";
    el.innerHTML = `<section class="dsec"><h2 class="dsec-t">${esc(o.kind === "ClusterServiceVersion" ? "Details" : o.kind + " details")}${R.q(k.help)}</h2>${ring}<div class="dgrid"><div>${R.dl(d.l)}</div><div>${R.dl(d.r)}</div></div></section>${k.sections ? k.sections(o) : ""}`;
    bindDetail(o, el);
  };
  function bindDetail(o, el) {
    el.querySelectorAll("[data-ann]").forEach((a) => a.addEventListener("click", () => kvModal("Annotations", o.metadata.annotations || {}, "annotations")));
    el.querySelectorAll("[data-scale]").forEach((b) => b.addEventListener("click", () => { scaleTo(o, Math.max(0, o.spec.replicas + +b.dataset.scale)); T.details(o, el); }));
    const rv = el.querySelector("[data-reveal]");
    if (rv) rv.addEventListener("click", () => { const box = el.querySelector("[data-secret]"); box.classList.toggle("show"); rv.innerHTML = U.ico("lock", 12) + (box.classList.contains("show") ? " Hide values" : " Reveal values"); });
  }
  function podRing(o) {
    const pods = OC.podsOf(o);
    const cnt = { run: 0, pend: 0, fail: 0 };
    pods.forEach((p) => { const s = OC.podStatus(p); if (s === "Running" && p.status.containerStatuses[0] && p.status.containerStatuses[0].ready) cnt.run++; else if (/Pending|ContainerCreating|ImagePull|ErrImage/.test(s)) cnt.pend++; else cnt.fail++; });
    const total = pods.length || 1, R0 = 48, C0 = 2 * Math.PI * R0;
    let off = 0;
    const seg = (n, col) => { if (!n) return ""; const len = (n / total) * C0; const s = `<circle r="${R0}" cx="60" cy="60" fill="none" stroke="${col}" stroke-width="13" stroke-dasharray="${Math.max(0, len - (pods.length > 1 ? 2 : 0))} ${C0}" stroke-dashoffset="${-off}" transform="rotate(-90 60 60)"/>`; off += len; return s; };
    const svg = `<svg viewBox="0 0 120 120" width="130" height="130" class="ring"><circle r="${R0}" cx="60" cy="60" fill="none" stroke="var(--ring-bg)" stroke-width="13"/>${seg(cnt.run, "var(--pod-run)")}${seg(cnt.pend, "var(--pod-pend)")}${seg(cnt.fail, "var(--danger)")}<text x="60" y="58" text-anchor="middle" class="ring-n">${pods.length}</text><text x="60" y="76" text-anchor="middle" class="ring-s">${pods.length === 1 ? "Pod" : "Pods"}</text></svg>`;
    const scal = o.kind !== "DaemonSet" ? `<div class="ring-ctl"><button class="icon-btn" data-scale="1" title="Increase the pod count">${U.ico("up", 14)}</button><button class="icon-btn" data-scale="-1" title="Decrease the pod count">${U.ico("down", 14)}</button></div>` : "";
    return `<div class="ring-wrap">${svg}${scal}<div class="ring-legend"><span><i style="background:var(--pod-run)"></i>Running ${cnt.run}</span><span><i style="background:var(--pod-pend)"></i>Pending / Not Ready ${cnt.pend}</span><span><i style="background:var(--danger)"></i>Failed ${cnt.fail}</span>${R.q("pod-ring")}</div></div>`;
  }

  T.yaml = function (o, el) {
    const y = U.yaml(o);
    el.classList.add("tab-yaml");
    el.innerHTML = `<div class="yaml-tb"><div class="alert alert-info inline">${U.ico("info", 14)} Simülasyon: YAML salt okunur gösterilir; gerçek konsolda burada düzenleyip <b>Save</b> ile uygulayabilirsiniz.</div><span class="grow"></span><button class="btn btn-secondary btn-sm" id="yCopy">${U.ico("copy", 12)} Copy</button><button class="btn btn-secondary btn-sm" id="yDl">${U.ico("download", 12)} Download</button>${R.q("tab-yaml")}</div><div class="yaml-wrap"><div class="yaml">${U.yamlHtml(y)}</div><aside class="schema"><h3>Schema ${R.q("kubernetes-object")}</h3><p><b>${esc(o.kind)}</b> <span class="muted mono sm">${esc(o.apiVersion)}</span></p><p class="sm">${esc((H[K[o.kind].help] || {}).what || "")}</p><ul class="schema-l"><li><b>apiVersion</b> <span class="muted">string</span> – Nesnenin API grubu ve sürümü.</li><li><b>kind</b> <span class="muted">string</span> – Nesne türü.</li><li><b>metadata</b> <span class="muted">object</span> – Ad, namespace, label ve annotation'lar.</li>${o.spec ? '<li><b>spec</b> <span class="muted">object</span> – İstenen durum (sizin tanımladığınız).</li>' : ""}${o.status ? '<li><b>status</b> <span class="muted">object</span> – Gözlemlenen durum (sistem yazar, salt okunur).</li>' : ""}</ul><p class="sm muted">CLI: <span class="mono">oc explain ${esc(o.kind.toLowerCase())}.spec</span></p></aside></div><div class="yaml-foot"><button class="btn btn-primary" id="ySave">Save</button><button class="btn btn-secondary" id="yReload">Reload</button><button class="btn btn-link" data-back="1">Cancel</button></div>`;
    $("#yCopy").onclick = () => U.copy(y).then(() => toast("YAML panoya kopyalandı"));
    $("#yDl").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([y], { type: "text/yaml" })); a.download = o.metadata.name + ".yaml"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 500); };
    $("#ySave").onclick = () => toast("Simülasyon: değişiklik kaydedilmedi. Gerçek cluster'da: oc apply -f " + o.metadata.name + ".yaml");
    $("#yReload").onclick = () => T.yaml(o, el);
  };

  OC.eventRow = (e, showObj) => `<div class="ev ${e.type === "Warning" ? "ev-w" : ""}"><div class="ev-h">${showObj !== false ? R.link(e.involvedObject.kind, e.involvedObject.namespace, e.involvedObject.name) : ""}${e.involvedObject.namespace && showObj !== false ? `<span class="ev-ns">${R.badge("Namespace")}${esc(e.involvedObject.namespace)}</span>` : ""}<span class="grow"></span>${e.type === "Warning" ? `<span class="ev-type">${U.ico("warn", 12)} Warning</span>` : ""}<span class="ev-t">${U.ts(e.lastTimestamp)}</span></div><div class="ev-r"><b>${esc(e.reason)}</b> <span class="muted">Generated from ${esc(e.source.component)}${e.count > 1 ? ` · ${e.count} times in the last ${U.rel(e.firstTimestamp).replace(" önce", "")}` : ""}</span></div><div class="ev-m">${esc(e.message)}</div></div>`;
  T.events = function (o, el) {
    const evs = db.Event.filter((e) => e.involvedObject.uid === o.metadata.uid || (e.involvedObject.name === o.metadata.name && e.involvedObject.kind === o.kind));
    el.innerHTML = `<div class="ev-head">${evs.length ? `<span class="stream">${U.ico("play", 10)} Streaming events...</span>` : ""}<span class="muted">Showing ${evs.length} events ${R.q("tab-events")} ${R.q("event-type")}</span></div><div class="evs">${evs.map((e) => OC.eventRow(e, false)).join("") || '<div class="empty-s">No events in the past hour</div>'}</div>`;
  };
  T.pods = function (o, el) {
    const pods = o.kind === "Job" ? db.Pod.filter((p) => (p.metadata.ownerReferences || [])[0] && p.metadata.ownerReferences[0].uid === o.metadata.uid) : OC.podsOf(o);
    el.innerHTML = `<div class="sub-h">Pods ${R.q("tab-pods")}</div>` + OC.miniList("Pod", pods, { cols: K.Pod.cols.filter((c) => !c.hidden || c.t === "Node"), empty: "No Pods found" });
  };
  T.replicasets = (o, el) => (el.innerHTML = OC.miniList("ReplicaSet", db.ReplicaSet.filter((r) => (r.metadata.ownerReferences || [])[0].uid === o.metadata.uid).sort((a, b) => +b.metadata.annotations["deployment.kubernetes.io/revision"] - +a.metadata.annotations["deployment.kubernetes.io/revision"]), { cols: [{ t: "Status", v: (x) => `${x.status.readyReplicas || 0} of ${x.spec.replicas} pods` }, { t: "Revision", v: (x) => x.metadata.annotations["deployment.kubernetes.io/revision"], h: "revision-history" }, K.ReplicaSet.cols[2]] }));
  T.replicationcontrollers = (o, el) => (el.innerHTML = OC.miniList("ReplicationController", db.ReplicationController.filter((r) => (r.metadata.ownerReferences || [])[0].uid === o.metadata.uid), { cols: K.ReplicationController.cols }));
  T.jobs = (o, el) => (el.innerHTML = OC.miniList("Job", db.Job.filter((j) => (j.metadata.ownerReferences || [])[0] && j.metadata.ownerReferences[0].uid === o.metadata.uid), { cols: K.Job.cols }));
  T.builds = (o, el) => (el.innerHTML = OC.miniList("Build", db.Build.filter((b) => b.status.config.name === o.metadata.name && b.metadata.namespace === o.metadata.namespace).reverse(), { cols: K.Build.cols }));
  T.pipelineruns = (o, el) => (el.innerHTML = OC.miniList("PipelineRun", db.PipelineRun.filter((p) => p.spec.pipelineRef.name === o.metadata.name), { cols: K.PipelineRun.cols }));
  T.parameters = (o, el) => (el.innerHTML = R.section("Parameters", R.table([["Name"], ["Type"], ["Default value"]], o.spec.params.map((p) => [esc(p.name), p.type, `<span class="mono sm">${esc(p.default || "-")}</span>`])), "pipeline") + R.section("Workspaces", R.table([["Name"]], o.spec.workspaces.map((w) => [esc(w.name)])), "workspace"));
  T.instances = (o, el) => (el.innerHTML = `<div class="empty"><h3>${esc(o.spec.names.kind)} instances</h3><p class="muted">Bu CRD türünden oluşturulmuş nesneler burada listelenir.</p><p class="mono">oc get ${esc(o.spec.names.plural)} -A</p></div>`);
  T.rolebindings = function (o, el) {
    const name = o.metadata.name;
    let rb = db.RoleBinding.concat(db.ClusterRoleBinding || []);
    if (o.kind === "User" || o.kind === "Group") rb = rb.filter((b) => b.subjects.some((s) => s.kind === o.kind && s.name === name));
    else if (o.kind === "Namespace" || o.kind === "Project") rb = db.RoleBinding.filter((b) => b.metadata.namespace === name);
    else rb = rb.filter((b) => b.roleRef.name === name);
    el.innerHTML = `<div class="sub-h">RoleBindings ${R.q("rolebinding")}</div>` + OC.miniList("RoleBinding", rb, { cols: K.RoleBinding.cols, ns: true, empty: "No RoleBindings found" });
  };
  T.environment = function (o, el) {
    const cs = R.cnt(o);
    el.innerHTML = `<div class="alert alert-info">${U.ico("info", 14)}<div>Ortam değişkenleri Pod şablonundan gelir. Değiştirildiğinde ${o.kind === "Pod" ? "Pod'un sahibi (Deployment) yeni Pod oluşturur" : "yeni bir rollout başlar"}. ${R.q("env")}</div></div>` + cs.map((c) => R.section("Container: " + c.name, `<div class="env-l">${(c.env || []).map((e) => `<div class="env-r"><input value="${esc(e.name)}" readonly><span class="env-eq">=</span>${e.valueFrom ? `<span class="env-from">${e.valueFrom.secretKeyRef ? R.badge("Secret") + esc(e.valueFrom.secretKeyRef.name) + " → " + esc(e.valueFrom.secretKeyRef.key) : e.valueFrom.configMapKeyRef ? R.badge("ConfigMap") + esc(e.valueFrom.configMapKeyRef.name) : esc(JSON.stringify(e.valueFrom))}</span>` : `<input value="${esc(e.value)}" readonly>`}</div>`).join("") || '<div class="empty-s">No environment variables</div>'}</div>${(c.envFrom || []).length ? `<h4 class="env-h">All values from existing ConfigMaps or Secrets (envFrom) ${R.q("envfrom")}</h4>${c.envFrom.map((f) => `<div class="env-r">${f.configMapRef ? R.link("ConfigMap", o.metadata.namespace, f.configMapRef.name) : R.link("Secret", o.metadata.namespace, f.secretRef.name)}</div>`).join("")}` : ""}<div class="env-add"><button class="btn btn-link btn-sm sim-act" data-cmd="oc set env ${o.kind.toLowerCase()}/${esc(o.metadata.name)} YENI_DEGISKEN=deger" data-title="Add value" data-h2="env">${U.ico("plus", 11)} Add value</button><button class="btn btn-link btn-sm sim-act" data-cmd="oc set env ${o.kind.toLowerCase()}/${esc(o.metadata.name)} --from=configmap/&lt;ad&gt;" data-title="Add from ConfigMap or Secret" data-h2="envfrom">${U.ico("plus", 11)} Add from ConfigMap or Secret</button></div>`, "env")).join("");
  };
  T.metrics = function (o, el) {
    const pods = o.kind === "Pod" ? [o] : o.kind === "Node" ? null : OC.podsOf(o);
    const m = o.kind === "Node" ? o._m : { cpu: pods.reduce((a, p) => a + p._m.cpu, 0), mem: pods.reduce((a, p) => a + p._m.mem, 0) };
    const lim = o.kind === "Node" ? null : R.cnt(o)[0] && R.cnt(o)[0].resources.limits ? R.cnt(o)[0].resources : null;
    const card = (t, val, series, help, sub) => `<div class="card mcard"><div class="mcard-h">${esc(t)}${R.q(help)}<span class="grow"></span><b>${val}</b></div>${U.spark(series, { grid: true, h: 120 })}<div class="mcard-x muted sm"><span>-1h</span><span>-30m</span><span>now</span></div>${sub ? `<div class="muted sm">${sub}</div>` : ""}</div>`;
    el.innerHTML = `<div class="m-tb"><label>Time range <select class="sel"><option>1 hour</option><option>6 hours</option><option>24 hours</option></select></label>${R.q("tab-metrics")}</div><div class="mgrid">${card("Memory usage", U.mib(m.mem), U.series(40, m.mem || 1, (m.mem || 1) * 0.08), "pod-memory", lim ? "Limit: " + lim.limits.memory + " · Request: " + lim.requests.memory : o.kind === "Node" ? "Total: " + o._mem + " GiB" : "")}${card("CPU usage", U.num(m.cpu, 3) + " cores", U.series(40, m.cpu || 0.001, (m.cpu || 0.001) * 0.4), "pod-cpu", lim ? "Limit: " + lim.limits.cpu + " · Request: " + lim.requests.cpu : o.kind === "Node" ? "Total: " + o._cpu + " cores" : "")}${card("Filesystem", U.num(o.kind === "Node" ? o._m.fs : 0.02 + (m.mem % 7) / 40, 2) + " GiB", U.series(40, 10, 0.3), "capacity")}${card("Network in", U.num((m.cpu || 0.01) * 820, 1) + " KBps", U.series(40, 50, 30), "service")}${card("Network out", U.num((m.cpu || 0.01) * 610, 1) + " KBps", U.series(40, 40, 25), "service")}${o.kind !== "Node" ? card("Pod count", String(pods.length), U.series(40, pods.length, 0), "replicas") : ""}</div><p class="muted sm">Metrikler Prometheus'tan alınır (simülasyonda üretilmiş örnek değerler). Sorgu örneği: <span class="mono">sum(container_memory_working_set_bytes{namespace="${esc(o.metadata.namespace || "")}",pod=~"${esc(o.metadata.name)}.*"})</span></p>`;
  };

  /* ---- Loglar ---- */
  function logLines(o, n) {
    const a = o._app || {}, rt = (o.metadata.labels || {})["app.openshift.io/runtime"] || (a.baseLabels || {})["app.openshift.io/runtime"] || a.runtime || "";
    const t = (i) => new Date(U.NOW - (n - i) * 7000).toISOString();
    const st = OC.podStatus(o);
    if (st === "CrashLoopBackOff") return [t(0) + " INFO  [io.quarkus] katalog-api 1.13.0-SNAPSHOT on JVM starting", t(1) + " INFO  [io.agroal.pool] Datasource '<default>': Initial size smaller than min", t(2) + " WARN  [org.hibernate] HHH000342: Could not obtain connection to query metadata", t(3) + " ERROR [io.quarkus.runtime] Failed to start application (with profile [prod])", "java.lang.RuntimeException: Failed to load config value of type class java.lang.String for: quarkus.datasource.password", "\tat io.quarkus.runtime.configuration.ConfigRecorder.handleConfigChange(ConfigRecorder.java:68)", "\tat io.quarkus.runner.ApplicationImpl.doStart(Unknown Source)", "Caused by: java.util.NoSuchElementException: SRCFG00014: The config property quarkus.datasource.password is required but it could not be found in any config source", t(4) + " INFO  [io.quarkus] katalog-api stopped in 0.021s", "", "# Eğitim notu: Uygulama, Secret'tan gelmesi gereken DB_PASSWORD değerini bulamadığı için açılamıyor.", "# Çözüm: oc set env deploy/katalog-api --from=secret/postgresql --prefix=DB_  veya env tanımını düzeltin."];
    if (st === "ImagePullBackOff" || st === "Pending") return ['container "' + (a.cname || a.name) + '" in pod "' + o.metadata.name + '" is waiting to start: ' + (st === "Pending" ? "pod has not been scheduled" : "trying and failing to pull image")];
    const L = [];
    const ip = () => "10.1" + U.ri(28, 35) + "." + U.ri(0, 1) + "." + U.ri(2, 250);
    for (let i = 0; i < n; i++) {
      const path = U.pick(["/", "/api/urunler", "/api/urunler/1042", "/api/kategoriler", "/health/ready", "/sepet", "/static/main.js", "/api/siparis"]);
      if (/nginx|httpd/.test(rt)) L.push(ip() + ' - - [' + new Date(U.NOW - (n - i) * 4000).toUTCString().slice(5, 25) + ' +0000] "GET ' + path + ' HTTP/1.1" ' + U.pick([200, 200, 200, 304, 200, 404]) + " " + U.ri(120, 48000) + ' "-" "Mozilla/5.0"');
      else if (/quarkus|java|spring/.test(rt)) L.push(t(i) + " " + U.pick(["INFO ", "INFO ", "DEBUG", "INFO ", "WARN "]) + " [" + U.pick(["c.e.k.UrunResource", "o.h.e.j.s.SqlExceptionHelper", "c.e.s.SiparisService", "io.quarkus.http"]) + "] (executor-thread-" + U.ri(1, 12) + ") " + U.pick(["GET " + path + " 200 " + U.ri(3, 90) + "ms", "Önbellekten " + U.ri(10, 300) + " ürün döndü", "Sipariş #" + U.ri(100000, 999999) + " oluşturuldu", "Veritabanı bağlantı havuzu: aktif=" + U.ri(1, 8) + " boşta=" + U.ri(2, 12), "Yavaş sorgu tespit edildi: " + U.ri(500, 1400) + "ms"]));
      else if (rt === "golang") L.push('{"level":"info","ts":"' + t(i) + '","msg":"' + U.pick(["sepet güncellendi", "istek işlendi", "redis bağlantısı sağlıklı"]) + '","method":"GET","path":"' + path + '","status":200,"duration_ms":' + U.ri(1, 30) + "}");
      else if (rt === "postgresql") L.push(t(i).replace("T", " ").slice(0, 23) + " UTC [" + U.ri(100, 999) + "] LOG:  " + U.pick(["checkpoint starting: time", "checkpoint complete: wrote " + U.ri(10, 400) + " buffers (0.4%)", "connection received: host=" + ip() + " port=" + U.ri(30000, 60000), "connection authorized: user=katalog_app database=katalog", "automatic vacuum of table \"katalog.public.urun\""]));
      else if (rt === "redis") L.push("1:M " + new Date(U.NOW - (n - i) * 9000).toUTCString().slice(5, 25) + " * " + U.pick(["Background saving started by pid " + U.ri(100, 999), "DB saved on disk", "100 changes in 300 seconds. Saving...", "Background saving terminated with success"]));
      else if (rt === "nodejs") L.push("[" + t(i) + "] " + U.pick(["info", "info", "warn"]) + ": " + U.pick(["GET " + path + " 200 - " + U.ri(2, 80) + " ms", "Oturum yenilendi kullanıcı=" + U.ri(1000, 9999), "Keycloak token doğrulandı", "Fatura listesi önbelleğe alındı"]));
      else L.push(t(i) + " " + U.pick(["INFO", "INFO", "DEBUG"]) + " " + U.pick(["İstek işlendi " + path, "Sağlık kontrolü başarılı", "Metrikler güncellendi", "Bağlantı havuzu durumu normal"]));
    }
    return L;
  }
  T.logs = function (o, el) {
    const lines = o.kind === "Build" ? buildLog(o) : o.kind === "PipelineRun" ? ["[fetch-repository : clone] + git clone https://git.egitim.local/portal/portal-web.git", "[fetch-repository : clone] Cloning into '/workspace/output'...", "[fetch-repository : clone] Successfully cloned at commit 3f9a2c1", "[unit-test : test] > portal-web@1.4.0 test", "[unit-test : test] PASS  src/fatura.test.js (24 tests)", "[build : build] STEP 1/9: FROM registry.access.redhat.com/ubi9/nodejs-22", "[build : build] Successfully tagged image-registry.openshift-image-registry.svc:5000/musteri-portali/portal-web:latest", "[deploy : oc] deployment \"portal-web\" successfully rolled out"] : logLines(o, 40);
    const live = o.kind === "Pod" && OC.podStatus(o) === "Running";
    const cname = (R.cnt(o)[0] || {}).name || "build";
    el.innerHTML = `<div class="log-tb"><select class="sel">${R.cnt(o).map((c) => `<option>${esc(c.name)}</option>`).join("") || "<option>" + esc(cname) + "</option>"}</select>${live ? `<button class="btn btn-secondary btn-sm" id="logPause">${U.ico("pause", 11)} Pause</button><span class="stream" id="logSt">${U.ico("play", 10)} Log stream ongoing</span>` : `<span class="muted">Log stream ended.</span>`}<span class="grow"></span><label class="chk sm"><input type="checkbox" id="logWrap" checked> Wrap lines</label><button class="btn btn-link btn-sm" id="logDl">${U.ico("download", 12)} Download</button>${R.q("tab-logs")}</div><div class="log-box wrap" id="logBox">${lines.map((l) => `<div class="log-l">${esc(l)}</div>`).join("")}</div><p class="muted sm">CLI: <span class="mono">oc logs -f ${esc(o.kind === "Build" ? "build/" : "")}${esc(o.metadata.name)}${o.kind === "Pod" ? " -c " + esc(cname) : ""}</span></p>`;
    const box = $("#logBox"); box.scrollTop = box.scrollHeight;
    $("#logWrap").onchange = (e) => box.classList.toggle("wrap", e.target.checked);
    $("#logDl").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([box.innerText], { type: "text/plain" })); a.download = o.metadata.name + ".log"; a.click(); };
    if (live) {
      let paused = false;
      $("#logPause").onclick = (e) => { paused = !paused; e.currentTarget.innerHTML = paused ? U.ico("play", 11) + " Resume" : U.ico("pause", 11) + " Pause"; $("#logSt").innerHTML = paused ? "Log stream paused." : U.ico("play", 10) + " Log stream ongoing"; };
      st.timers.push(setInterval(() => { if (paused || !document.body.contains(box)) return; const ln = logLines(o, 1)[0]; const d = document.createElement("div"); d.className = "log-l new"; d.textContent = ln.replace(/^\S+Z/, new Date().toISOString()); box.appendChild(d); box.scrollTop = box.scrollHeight; }, 2200));
    }
  };
  function buildLog(b) {
    const base = ["Cloning \"https://git.egitim.local/portal/portal-web.git\" ...", "\tCommit:\t" + b.spec.revision.git.commit.slice(0, 7) + " (" + b.spec.revision.git.message + ")", "\tAuthor:\t" + b.spec.revision.git.author.name, "time=\"" + b.status.startTimestamp + "\" level=info msg=\"Not using native diff for overlay\"", "Caching blobs under \"/var/cache/blobs\".", "Trying to pull image-registry.openshift-image-registry.svc:5000/openshift/nodejs@sha256:7c1f...", "Getting image source signatures", "Copying blob sha256:2f0e9c... done", "Writing manifest to image destination", "Adding transient rw bind mount for /run/secrets/rhsm", "STEP 1/9: FROM image-registry.openshift-image-registry.svc:5000/openshift/nodejs@sha256:7c1f...", "STEP 2/9: LABEL \"io.openshift.build.commit.id\"=\"" + b.spec.revision.git.commit.slice(0, 12) + "\"", "STEP 3/9: ENV OPENSHIFT_BUILD_NAME=\"" + b.metadata.name + "\" OPENSHIFT_BUILD_NAMESPACE=\"musteri-portali\"", "STEP 4/9: USER root", "STEP 5/9: COPY upload/src /tmp/src", "STEP 6/9: RUN chown -R 1001:0 /tmp/src", "STEP 7/9: USER 1001", "STEP 8/9: RUN /usr/libexec/s2i/assemble", "---> Installing application source ...", "---> Installing all dependencies", "npm ci"];
    if (b.status.phase === "Failed") return base.concat(["npm ERR! code ERESOLVE", "npm ERR! ERESOLVE unable to resolve dependency tree", "npm ERR! Found: react@18.3.1", "npm ERR! Could not resolve dependency: peer react@\"^17.0.0\" from react-datepicker@4.2.0", "error: build error: building at STEP \"RUN /usr/libexec/s2i/assemble\": while running runtime: exit status 1", "", "# Eğitim notu: Bağımlılık çakışması. package.json'da sürümleri uyumlu hale getirip yeniden build başlatın."]);
    if (b.status.phase === "Running") return base.concat(["added 812 packages, and audited 813 packages in 41s", "---> Building in production mode", "> portal-web@1.4.0 build", "> vite build", "vite v5.4.2 building for production..."]);
    return base.concat(["added 812 packages, and audited 813 packages in 38s", "---> Pruning the development dependencies", "STEP 9/9: CMD /usr/libexec/s2i/run", "COMMIT temp.builder.openshift.io/musteri-portali/" + b.metadata.name + ":" + U.hex(8), "Getting image source signatures", "Writing manifest to image destination", "Successfully pushed image-registry.openshift-image-registry.svc:5000/musteri-portali/portal-web@sha256:" + U.hex(64), "Push successful"]);
  }

  /* ---- Terminal (Pod içi) ---- */
  T.terminal = function (o, el) {
    if (OC.podStatus(o) !== "Running") { el.innerHTML = `<div class="empty"><h3>Terminal kullanılamıyor</h3><p class="muted">Terminal yalnızca çalışan (Running) konteynerlerde açılabilir. Bu Pod'un durumu: <b>${esc(OC.podStatus(o))}</b></p>${R.q("tab-terminal")}</div>`; return; }
    el.innerHTML = `<div class="log-tb"><span>Connecting to</span><select class="sel"><option>${esc(o.spec.containers[0].name)}</option></select><span class="grow"></span><span class="muted sm">Denemek için: <span class="mono">help</span></span>${R.q("tab-terminal")}</div><div class="term" id="podTerm"></div>`;
    OC.shell($("#podTerm"), podShell(o), "sh-5.1$ ");
  };
  function podShell(o) {
    const c = o.spec.containers[0], env = (c.env || []).map((e) => e.name + "=" + (e.valueFrom ? "(secret/configmap değeri)" : e.value));
    return (cmd) => {
      const [c0, ...args] = cmd.trim().split(/\s+/);
      switch (c0) {
        case "": return "";
        case "help": return "Kullanılabilir komutlar: ls, pwd, whoami, id, hostname, env, ps, df, cat /etc/os-release, curl localhost:" + ((c.ports || [])[0] || {}).containerPort + "/health, nslookup <servis>, exit, clear";
        case "ls": return "app.js  config  node_modules  package.json  public  views";
        case "pwd": return "/opt/app-root/src";
        case "whoami": return "1000660000\n# Not: OpenShift konteynerleri projeye atanmış rastgele, root olmayan bir UID ile çalıştırır (restricted-v2 SCC).";
        case "id": return "uid=1000660000(1000660000) gid=0(root) groups=0(root),1000660000";
        case "hostname": return o.metadata.name;
        case "env": return ["HOSTNAME=" + o.metadata.name, "KUBERNETES_SERVICE_HOST=172.30.0.1", "KUBERNETES_SERVICE_PORT=443"].concat(env).join("\n");
        case "ps": return "    PID TTY          TIME CMD\n      1 ?        00:01:12 " + (c.command ? c.command[0] : "run") + "\n    214 pts/0    00:00:00 sh\n    230 pts/0    00:00:00 ps";
        case "df": return "Filesystem      Size  Used Avail Use% Mounted on\noverlay         120G   38G   82G  32% /\ntmpfs            64M     0   64M   0% /dev\n" + ((c.volumeMounts || []).filter((m) => !/serviceaccount/.test(m.mountPath)).map((m) => "/dev/rbd" + U.ri(0, 4) + "        20G  4.1G   16G  21% " + m.mountPath).join("\n"));
        case "cat": return args[0] === "/etc/os-release" ? 'NAME="Red Hat Enterprise Linux"\nVERSION="9.6 (Plow)"\nID="rhel"\nPRETTY_NAME="Red Hat Enterprise Linux 9.6 (Plow)"' : "cat: " + (args[0] || "") + ": No such file or directory";
        case "curl": return /health|localhost/.test(args.join(" ")) ? '{"status":"UP","checks":[{"name":"Database connections health check","status":"UP"}]}' : "curl: (6) Could not resolve host: " + (args[0] || "");
        case "nslookup": return "Server:\t\t172.30.0.10\nAddress:\t172.30.0.10#53\n\nName:\t" + (args[0] || "kubernetes") + "." + o.metadata.namespace + ".svc.cluster.local\nAddress: 172.30." + U.ri(1, 250) + "." + U.ri(2, 250);
        case "exit": return "exit\n(Bağlantı kapatıldı – yeniden bağlanmak için sekmeyi tekrar açın)";
        default: return "sh: " + c0 + ": command not found";
      }
    };
  }
  OC.shell = function (host, handler, prompt) {
    host.innerHTML = `<div class="term-out"></div><div class="term-in"><span class="term-p">${esc(prompt)}</span><input autocomplete="off" spellcheck="false" aria-label="Terminal girişi"></div>`;
    const out = host.querySelector(".term-out"), inp = host.querySelector("input"), hist = []; let hi = 0;
    const print = (t, cls) => { const d = document.createElement("pre"); d.className = cls || ""; d.textContent = t; out.appendChild(d); host.scrollTop = host.scrollHeight; };
    print("Eğitim terminali – komutlar simüle edilir, gerçek bir sisteme bağlanmaz. 'help' yazın.", "term-info");
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { const v = inp.value; hist.push(v); hi = hist.length; print(prompt + v, "term-cmd"); inp.value = ""; if (v.trim() === "clear") { out.innerHTML = ""; return; } const r = handler(v); if (r) print(r); }
      else if (e.key === "ArrowUp") { if (hi > 0) inp.value = hist[--hi]; e.preventDefault(); }
      else if (e.key === "ArrowDown") { inp.value = hi < hist.length - 1 ? hist[++hi] : ""; hi = Math.min(hi, hist.length); e.preventDefault(); }
    });
    host.addEventListener("click", () => inp.focus());
    setTimeout(() => inp.focus(), 50);
  };

  /* ---------------- İşlemler (Actions) ---------------- */
  function actionsMenu(anchor, o) {
    const k = K[o.kind];
    const acts = k.actions || [];
    const m = openMenu(anchor, acts.map((a, i) => `<button class="mi ${a[3] === "danger" ? "danger" : ""}" data-act="${i}">${esc(a[0])}</button>`).join("") + `<div class="mi-div"></div><div class="mi-note">${U.ico("info", 11)} Eğitim simülatörü: işlemler açıklamalı gösterilir ${R.q("ui-actions")}</div>`, "act-pop");
    m.addEventListener("click", (e) => { const b = e.target.closest("[data-act]"); if (!b) return; closeMenus(); runAction(acts[+b.dataset.act], o); });
  }
  function runAction(a, o) {
    const label = a[0], cmd = a[1] ? a[1](o) : "", help = a[2], special = a[4];
    if (special === "scale") return scaleModal(o);
    if (special === "deletePod") return confirmDelete(o, true);
    if (special === "cordon") { o.spec.unschedulable = !o.spec.unschedulable; toast(o.spec.unschedulable ? "Node zamanlanamaz (cordon) yapıldı – simülasyon" : "Node yeniden zamanlanabilir (uncordon) – simülasyon"); a[0] = o.spec.unschedulable ? "Mark as schedulable" : "Mark as unschedulable"; return render(); }
    if (special === "startBuild") return startBuild(o);
    if (/^Edit labels/.test(label)) return labelsModal(o, "labels");
    if (/^Edit annotations/.test(label)) return labelsModal(o, "annotations");
    if (a[3] === "danger" && /^Delete/.test(label)) return confirmDelete(o, false);
    if (/^Edit( |$)/.test(label) && help === "tab-yaml") return OC.go(R.href(o.kind, o.metadata.namespace, o.metadata.name, "yaml"));
    simModal(label, cmd, help);
  }
  function simModal(title, cmd, help) {
    const hh = H[help];
    modal(title, `${hh ? `<p>${esc(hh.what)}</p>` : ""}<div class="cmd-box"><div class="cmd-h">Komut satırı karşılığı ${R.q("ui-terminal")}</div><pre class="code">${esc(cmd)}</pre><button class="btn btn-link btn-sm" data-copy="${esc(cmd)}">${U.ico("copy", 11)} Kopyala</button></div><div class="alert alert-info">${U.ico("info", 14)}<div>Bu bir eğitim simülatörüdür. İşlem gerçek bir cluster üzerinde uygulanmaz.</div></div>${hh ? `<button class="btn btn-link" data-h="${help}">${U.ico("book", 12)} "${esc(hh.t)}" hakkında daha fazla bilgi</button>` : ""}`, [["Tamam (simüle et)", "primary", () => (toast("Simülasyon: \"" + title + "\" uygulandı sayıldı"), true)], ["Cancel", "secondary"]]);
  }
  OC.simModal = simModal;
  function scaleTo(o, n) {
    const pods = OC.podsOf(o);
    o.spec.replicas = n;
    if (n > pods.length && pods.length) {
      for (let i = pods.length; i < n; i++) {
        const tpl = pods[0], p = clone(tpl);
        p.metadata.name = o.kind === "StatefulSet" ? o.metadata.name + "-" + i : tpl.metadata.name.replace(/[^-]+$/, U.hs(5));
        p.metadata.uid = U.uid(); p.metadata.creationTimestamp = new Date().toISOString();
        p.status.containerStatuses = [Object.assign({}, p.status.containerStatuses[0] || {}, { ready: true, restartCount: 0, state: { running: { startedAt: new Date().toISOString() } }, lastState: {} })];
        p.status.phase = "Running"; p._m = Object.assign({}, tpl._m); p._app = tpl._app;
        p.spec.nodeName = OC.db.Node.filter((x) => x._role === "worker" && !x.spec.unschedulable)[i % 3].metadata.name;
        db.Pod.push(p);
      }
    } else if (n < pods.length) pods.slice(n).forEach((p) => db.Pod.splice(db.Pod.indexOf(p), 1));
    if (o.status) { o.status.replicas = n; o.status.readyReplicas = Math.min(n, o.status.readyReplicas + Math.max(0, n - pods.length)); o.status.availableReplicas = o.status.readyReplicas; }
    toast(o.metadata.name + " " + n + " Pod'a ölçeklendi (simülasyon)");
  }
  function scaleModal(o) {
    modal("Edit Pod count", `<p>${esc(o.kind)} <b>${esc(o.metadata.name)}</b> için istenen Pod sayısını girin. ${R.q("replicas")}</p><div class="spin-in"><button class="btn btn-secondary" data-d="-1">−</button><input type="number" id="repIn" min="0" value="${o.spec.replicas}"><button class="btn btn-secondary" data-d="1">+</button><span class="muted">pods</span></div><div class="cmd-box"><pre class="code">oc scale ${esc(o.kind.toLowerCase())}/${esc(o.metadata.name)} --replicas=<span id="repCmd">${o.spec.replicas}</span></pre></div>${db.HorizontalPodAutoscaler.some((h) => h.spec.scaleTargetRef.name === o.metadata.name && h.metadata.namespace === o.metadata.namespace) ? `<div class="alert alert-warn">${U.ico("warn", 14)}<div>Bu ${esc(o.kind)} bir HPA tarafından yönetiliyor. Elle değiştirilen sayı HPA tarafından tekrar ayarlanır. ${R.q("hpa")}</div></div>` : ""}`, [["Save", "primary", (m) => { scaleTo(o, Math.max(0, +$("#repIn", m).value || 0)); render(); return true; }], ["Cancel", "secondary"]], (m) => { m.addEventListener("click", (e) => { const b = e.target.closest("[data-d]"); if (b) { const i = $("#repIn", m); i.value = Math.max(0, +i.value + +b.dataset.d); $("#repCmd", m).textContent = i.value; } }); $("#repIn", m).addEventListener("input", (e) => ($("#repCmd", m).textContent = e.target.value)); });
  }
  function confirmDelete(o, isPod) {
    const ow = (o.metadata.ownerReferences || [])[0];
    modal("Delete " + o.kind + "?", `<p><b>${esc(o.metadata.name)}</b> ${o.metadata.namespace ? `(namespace <b>${esc(o.metadata.namespace)}</b>)` : ""} kalıcı olarak silinecek.</p>${isPod && ow ? `<div class="alert alert-info">${U.ico("info", 14)}<div><b>Öğretici not:</b> Bu Pod bir <b>${esc(ow.kind)}</b> tarafından yönetiliyor. Silindiğinde controller istenen replica sayısını korumak için hemen <b>yeni bir Pod</b> oluşturur (self-healing). Silmeden sonra listeyi izleyin! ${R.q("owner")}</div></div>` : ""}<div class="cmd-box"><pre class="code">oc delete ${esc(o.kind.toLowerCase())} ${esc(o.metadata.name)}${o.metadata.namespace ? " -n " + esc(o.metadata.namespace) : ""}</pre></div><p class="muted sm">Simülasyon: silme yalnızca bu tarayıcı oturumunda geçerlidir; sayfa yenilenince veri geri gelir.</p>`, [["Delete", "danger", () => { doDelete(o, isPod && ow); return true; }], ["Cancel", "secondary"]]);
  }
  function doDelete(o, recreate) {
    const arr = db[o.kind]; arr.splice(arr.indexOf(o), 1);
    toast(o.kind + " " + o.metadata.name + " silindi (simülasyon)");
    if (recreate) {
      const p = clone(o);
      p._m = Object.assign({}, o._m); p._app = o._app;
      p.metadata.name = /-\d+$/.test(o.metadata.name) && o.metadata.ownerReferences[0].kind === "StatefulSet" ? o.metadata.name : o.metadata.name.replace(/[^-]+$/, U.hs(5));
      p.metadata.uid = U.uid(); p.metadata.creationTimestamp = new Date().toISOString();
      p.status.phase = "Pending"; p.status.containerStatuses = [{ name: p.spec.containers[0].name, ready: false, restartCount: 0, state: { waiting: { reason: "ContainerCreating" } }, lastState: {} }];
      db.Pod.push(p);
      db.Event.unshift({ kind: "Event", metadata: { name: p.metadata.name + ".x", namespace: p.metadata.namespace }, involvedObject: { kind: "Pod", name: p.metadata.name, namespace: p.metadata.namespace, uid: p.metadata.uid }, reason: "Scheduled", message: "Successfully assigned " + p.metadata.namespace + "/" + p.metadata.name + " to " + p.spec.nodeName, type: "Normal", source: { component: "default-scheduler" }, firstTimestamp: p.metadata.creationTimestamp, lastTimestamp: p.metadata.creationTimestamp, count: 1 });
      setTimeout(() => { p.status.phase = "Running"; p.status.containerStatuses[0] = { name: p.spec.containers[0].name, ready: true, restartCount: 0, started: true, state: { running: { startedAt: new Date().toISOString() } }, lastState: {} }; if (st.list && st.list.kind === "Pod") render(); toast("Controller yeni Pod oluşturdu: " + p.metadata.name + " → Running"); }, 3500);
    }
    OC.go(OC.listHref(o.kind, o.metadata.namespace));
  }
  function startBuild(bc) {
    const n = ++bc.status.lastVersion, last = OC.lastBuild(bc);
    const b = clone(last);
    b.metadata.name = bc.metadata.name + "-" + n; b.metadata.uid = U.uid(); b.metadata.creationTimestamp = new Date().toISOString(); b.metadata.annotations["openshift.io/build.number"] = String(n);
    b.status = { phase: "Running", startTimestamp: new Date().toISOString(), outputDockerImageReference: last.status.outputDockerImageReference, config: last.status.config };
    b.spec.triggeredBy = [{ message: "Manually triggered" }];
    db.Build.push(b);
    toast("Build " + b.metadata.name + " başlatıldı (simülasyon)");
    OC.go(R.href("Build", b.metadata.namespace, b.metadata.name, "logs"));
  }
  function labelsModal(o, field) {
    const obj = o.metadata[field] || {};
    const val = Object.keys(obj).map((k) => k + "=" + obj[k]).join("\n");
    modal(field === "labels" ? "Edit labels" : "Edit annotations", `<p class="muted">${field === "labels" ? "Label'lar nesneleri gruplamak ve seçmek için kullanılır." : "Annotation'lar araçların okuduğu ek bilgilerdir."} Her satıra bir <span class="mono">anahtar=deger</span> yazın. ${R.q(field)}</p><textarea id="lblIn" class="txt mono" rows="8">${esc(val)}</textarea>`, [["Save", "primary", (m) => { const nv = {}; $("#lblIn", m).value.split("\n").map((s) => s.trim()).filter(Boolean).forEach((l) => { const i = l.indexOf("="); nv[i < 0 ? l : l.slice(0, i)] = i < 0 ? "" : l.slice(i + 1); }); o.metadata[field] = nv; toast(field === "labels" ? "Label'lar güncellendi (simülasyon)" : "Annotation'lar güncellendi (simülasyon)"); render(); return true; }], ["Cancel", "secondary"]]);
  }
  function kvModal(title, obj, help) {
    modal(title, `<p class="muted">${R.q(help)}</p>${R.table([["Key"], ["Value"]], Object.keys(obj).map((k) => [`<span class="mono sm">${esc(k)}</span>`, `<span class="mono sm brk">${esc(obj[k])}</span>`]), { empty: "No annotations" })}`, [["Close", "secondary"]], null, "wide");
  }

  /* ---------------- Oluşturma sayfası ---------------- */
  function createPage(r) {
    const kind = r.kind, k = kind ? K[kind] : null;
    const tpl = k && k.tpl ? Object.assign({}, k.tpl, { metadata: Object.assign({}, k.tpl.metadata, k.ns && st.ns !== "all" ? { namespace: st.ns } : {}) }) : null;
    const y = tpl ? U.yaml(tpl) : "# YAML içeriğini buraya yapıştırın\n# Örnek:\napiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: ornek\ndata:\n  anahtar: deger\n";
    const hasForm = k && k.form;
    let view = hasForm ? "form" : "yaml";
    const title = k ? "Create " + kind : "Import YAML";
    const draw = () => {
      $("#page").innerHTML = OC.pageHead(title, k ? k.help : "ui-quick-create", { desc: k ? esc((H[k.help] || {}).what || "") : "YAML içeriğini sürükleyip bırakın veya yapıştırın. Birden fazla kaynağı '---' ile ayırabilirsiniz." }) +
        `<div class="page-body">${hasForm ? `<div class="view-sw"><span>Configure via:</span><label class="radio"><input type="radio" name="vw" value="form" ${view === "form" ? "checked" : ""}> Form view</label><label class="radio"><input type="radio" name="vw" value="yaml" ${view === "yaml" ? "checked" : ""}> YAML view</label>${R.q("ui-create")}</div>` : ""}
        ${view === "form" ? `<form class="cform" id="cform">${k.form.map(([id, label, type, d, help]) => `<div class="fg"><label for="f_${id}">${esc(label)}${type !== "checkbox" ? ' <span class="req">*</span>' : ""} ${R.q(help)}</label>${type === "select" ? `<select id="f_${id}" class="sel wide">${d.map((x) => `<option>${esc(x)}</option>`).join("")}</select>` : type === "checkbox" ? `<label class="chk"><input type="checkbox" id="f_${id}" ${d ? "checked" : ""}> ${esc(label)}</label>` : type === "textarea" ? `<textarea id="f_${id}" class="txt" rows="4">${esc(d)}</textarea>` : `<input id="f_${id}" class="txt" type="${type}" value="${esc(d)}">`}${H[help] ? `<div class="fhelp">${esc(H[help].what.split(". ")[0])}.</div>` : ""}</div>`).join("")}</form>` : `<div class="yaml-edit"><textarea id="yIn" class="code-in" spellcheck="false">${esc(y)}</textarea><aside class="schema"><h3>Schema ${R.q("kubernetes-object")}</h3><p class="sm">${k ? `<b>${esc(kind)}</b> <span class="mono sm">${esc(k.api)}</span><br>` : ""}apiVersion, kind ve metadata.name zorunludur. ${k && k.ns ? "namespace belirtilmezse seçili proje kullanılır." : ""}</p><p class="sm muted">CLI: <span class="mono">oc apply -f dosya.yaml</span></p></aside></div>`}
        <div class="form-foot"><button class="btn btn-primary" id="cCreate">Create</button><button class="btn btn-secondary" data-back="1">Cancel</button></div></div>`;
      $$("input[name=vw]").forEach((i) => i.addEventListener("change", () => { view = i.value; draw(); }));
      $("#cCreate").onclick = () => doCreate(kind, view);
    };
    draw();
  }
  function doCreate(kind, view) {
    const nameEl = $("#f_name"); const name = nameEl ? nameEl.value.trim() : ((($("#yIn") || {}).value || "").match(/name:\s*(\S+)/) || [])[1] || "ornek";
    if (kind === "Project" && view === "form" && name) {
      if (db.Namespace.some((n) => n.metadata.name === name)) return toast("Bu isimde bir proje zaten var");
      const md = { name: name, uid: U.uid(), creationTimestamp: new Date().toISOString(), labels: { "kubernetes.io/metadata.name": name }, annotations: { "openshift.io/display-name": $("#f_display").value, "openshift.io/description": $("#f_desc").value, "openshift.io/requester": "egitim.admin" } };
      db.Namespace.push({ kind: "Namespace", apiVersion: "v1", metadata: md, spec: {}, status: { phase: "Active" } });
      db.Project.push({ kind: "Project", apiVersion: "project.openshift.io/v1", metadata: JSON.parse(JSON.stringify(md)), spec: {}, status: { phase: "Active" } });
      st.ns = name; U.store.set("ns", name);
      toast("Proje oluşturuldu (yalnızca bu oturumda): " + name);
      return OC.go(R.href("Project", null, name));
    }
    modal("Simülasyon: " + (kind || "kaynak") + " oluşturuldu sayıldı", `<p>Gerçek bir cluster'da bu işlem API sunucusuna bir <b>POST</b> isteği gönderir ve nesne etcd'ye kaydedilir. Ardından ilgili controller'lar nesneyi gerçekleştirmeye başlar (örn. Deployment → ReplicaSet → Pod).</p><div class="cmd-box"><div class="cmd-h">Komut satırı karşılığı</div><pre class="code">oc apply -f ${esc(name)}.yaml${kind && K[kind].ns && st.ns !== "all" ? " -n " + esc(st.ns) : ""}</pre></div><div class="alert alert-info">${U.ico("info", 14)}<div>Eğitim simülatöründe yeni kaynaklar kalıcı olarak oluşturulmaz (Project form görünümü hariç).</div></div>`, [["Tamam", "primary", () => { history.back(); return true; }]]);
  }

  /* ---------------- Menü / Modal / Toast ---------------- */
  function openMenu(anchor, html, cls) {
    closeMenus();
    const m = document.createElement("div");
    m.className = "menu " + (cls || "");
    m.innerHTML = html;
    $("#menuRoot").appendChild(m);
    const r = anchor.getBoundingClientRect();
    const w = m.offsetWidth, vw = window.innerWidth;
    let left = r.left; if (left + w > vw - 8) left = Math.max(8, r.right - w);
    m.style.left = left + "px";
    m.style.top = Math.min(r.bottom + 4, window.innerHeight - 60) + "px";
    m.style.maxHeight = (window.innerHeight - r.bottom - 16) + "px";
    setTimeout(() => document.addEventListener("click", outside, true), 0);
    function outside(e) { if (!m.contains(e.target) && !anchor.contains(e.target)) { closeMenus(); document.removeEventListener("click", outside, true); } }
    m._off = () => document.removeEventListener("click", outside, true);
    return m;
  }
  function closeMenus() { $$(".menu").forEach((m) => { m._off && m._off(); m.remove(); }); }
  OC.openMenu = openMenu; OC.closeMenus = closeMenus;
  function modal(title, body, buttons, init, size) {
    const root = $("#modalRoot");
    const w = document.createElement("div");
    w.className = "modal-bg";
    w.innerHTML = `<div class="modal ${size || ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-h"><h2>${esc(title)}</h2><button class="hp-x" data-close="1" aria-label="Kapat">&#10005;</button></div><div class="modal-b">${body}</div><div class="modal-f">${(buttons || []).map((b, i) => `<button class="btn btn-${b[1]}" data-bi="${i}">${esc(b[0])}</button>`).join("")}</div></div>`;
    root.appendChild(w);
    const close = () => w.remove();
    w.addEventListener("click", (e) => {
      if (e.target === w || e.target.closest("[data-close]")) return close();
      const b = e.target.closest("[data-bi]");
      if (b) { const fn = buttons[+b.dataset.bi][2]; if (!fn || fn(w) !== false) close(); }
    });
    if (init) init(w);
    const f = w.querySelector("input,textarea,.btn-primary,.btn-danger"); if (f) setTimeout(() => f.focus(), 30);
    return w;
  }
  OC.modal = modal;
  let toastT;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("on"), 3200); }
  OC.toast = toast;

  /* ---------------- Yardım paneli ---------------- */
  function kindForHelp(key) { return Object.keys(K).find((k) => K[k].help === key && K[k].cols && K[k].cols.length && !/Event|Container|Subscription|ControllerRevision/.test(k)); }
  function showHelp(key) {
    const h = H[key]; if (!h) return;
    $("#hpCat").textContent = h.cat || "Öğren";
    $("#hpTitle").textContent = h.t;
    const sec = (ic, t, v) => (v ? `<section class="hp-s"><h3>${ic}${esc(t)}</h3><p>${esc(v)}</p></section>` : "");
    const kk = kindForHelp(key);
    $("#hpBody").innerHTML =
      sec('<i class="hpi hpi-what">i</i>', "Nedir?", h.what) +
      sec('<i class="hpi hpi-why">◎</i>', "Ne için kullanılır?", h.why) +
      sec('<i class="hpi hpi-when">⏱</i>', "Ne zaman kullanılmalı?", h.when) +
      sec('<i class="hpi hpi-ben">✓</i>', "Sağladığı fayda", h.ben) +
      (h.ex ? `<section class="hp-s"><h3><i class="hpi hpi-ex">&lt;/&gt;</i>Teknik örnek</h3><div class="hp-code"><button class="hp-copy" data-copy="${esc(h.ex)}" title="Kopyala">${U.ico("copy", 12)}</button><pre>${esc(h.ex)}</pre></div></section>` : "") +
      (kk ? `<a class="btn btn-secondary btn-sm hp-go" href="${OC.listHref(kk)}">${R.badge(kk)} ${esc(K[kk].label)} listesini aç</a>` : "") +
      (h.rel && h.rel.length ? `<section class="hp-s"><h3>İlgili konular</h3><div class="hp-rel">${h.rel.filter((x) => H[x]).map((x) => `<button class="chip chip-btn" data-h="${x}">${esc(H[x].t)}</button>`).join("")}</div></section>` : "") +
      `<p class="hp-foot muted">${U.ico("info", 11)} Eğitim simülatörü · Tüm konular: <a href="#/learn">Öğrenme Merkezi</a></p>`;
    $("#hpBody").scrollTop = 0;
    const p = $("#helpPanel"); p.classList.add("open"); p.setAttribute("aria-hidden", "false");
    document.body.classList.add("hp-open");
  }
  OC.showHelp = showHelp;
  function closeHelp() { $("#helpPanel").classList.remove("open"); $("#helpPanel").setAttribute("aria-hidden", "true"); document.body.classList.remove("hp-open"); }

  /* ---------------- Masthead menüleri ---------------- */
  function mastMenu(btn, which) {
    const hq = (k) => R.q(k);
    if (which === "apps") openMenu(btn, `<div class="mi-h">Red Hat Applications ${hq("ui-apps")}</div><button class="mi sim-act" data-cmd="https://console.redhat.com/openshift" data-title="Hybrid Cloud Console">${U.ico("ext", 11)} Hybrid Cloud Console</button><button class="mi sim-act" data-cmd="https://console.redhat.com/openshift/details/${OC.cluster.id}" data-title="OpenShift Cluster Manager">${U.ico("ext", 11)} OpenShift Cluster Manager</button><div class="mi-h">Third Party Applications</div><button class="mi sim-act" data-cmd="https://openshift-gitops-server-openshift-gitops.${OC.cluster.domain}" data-title="Cluster Argo CD">${U.ico("ext", 11)} Cluster Argo CD</button>`, "right-pop");
    else if (which === "quick") { const m = openMenu(btn, `<div class="mi-h">Quick create ${hq("ui-quick-create")}</div><button class="mi" data-go="#/import">Import YAML</button><button class="mi" data-go="#/catalog">Import from Git</button><button class="mi" data-go="#/create/deployments">Container images</button>`, "right-pop"); m.addEventListener("click", closeMenus); }
    else if (which === "help") openMenu(btn, `<button class="mi" data-go="#/learn">${U.ico("book", 12)} Öğrenme Merkezi (tüm konular)</button><button class="mi" data-h="ui-learn">${U.ico("info", 12)} Bu simülatör nasıl kullanılır?</button><button class="mi" id="tourBtn">Guided Tour</button><div class="mi-div"></div><button class="mi" data-go="#/learn?cat=Temel kavram">Quick Starts</button><button class="mi sim-act" data-cmd="https://docs.redhat.com/en/documentation/openshift_container_platform/4.20" data-title="Documentation">Documentation ${U.ico("ext", 10)}</button><button class="mi" id="cliBtn">Command Line Tools</button><button class="mi" id="aboutBtn">About</button>`, "right-pop");
    else if (which === "user") openMenu(btn, `<div class="mi-h">egitim.admin ${hq("ui-user-menu")}</div><button class="mi" data-go="#/k8s/cluster/users/egitim.admin">My profile</button><button class="mi" id="themeBtn">${U.ico("sun", 12)} Tema: ${st.theme === "dark" ? "Koyu → Açık" : "Açık → Koyu"}</button><button class="mi" id="loginCmd">Copy login command</button><div class="mi-div"></div><button class="mi" id="logoutBtn">Log out</button>`, "right-pop");
  }

  /* ---------------- Ana render ---------------- */
  function render() {
    st.timers.forEach(clearInterval); st.timers = [];
    closeMenus();
    const r = parse();
    renderNav(r);
    const page = $("#page");
    page.className = "page";
    const nsKind = (r.type === "list" || r.type === "detail" || r.type === "create") && r.kind && K[r.kind].ns;
    const nsPages = ["topology", "helm-releases", "events"].indexOf(r.page) >= 0;
    renderNsBar(nsKind || nsPages);
    try {
      if (r.type === "list") listPage(r);
      else if (r.type === "detail") detailPage(r);
      else if (r.type === "create") createPage(r);
      else if (r.type === "page" && OC.P && OC.P[r.page]) OC.P[r.page](r);
      else page.innerHTML = OC.pageHead("404: Page Not Found", null) + '<div class="page-body"><div class="empty"><h3>Sayfa bulunamadı</h3><a class="btn btn-primary" href="#/dashboard">Overview\'a dön</a></div></div>';
    } catch (e) {
      console.error(e);
      page.innerHTML = `<div class="page-body"><div class="alert alert-danger">${U.ico("err", 16)}<div><b>Sayfa görüntülenirken hata oluştu</b><pre class="code">${esc(e.stack || e)}</pre></div></div></div>`;
    }
    $("#main").scrollTop = 0;
    if (window.innerWidth < 1200) document.body.classList.remove("nav-show");
    const tt = ($(".ph-tt") || {}).textContent;
    document.title = (tt ? tt + " · " : "") + "OpenShift Eğitim Konsolu";
  }
  OC.render = render;

  /* ---------------- Olay dinleyicileri ---------------- */
  document.addEventListener("click", (e) => {
    const t = e.target;
    if (t.closest("a[data-nop]")) e.preventDefault();
    if (t.closest("[data-back]")) { history.back(); return; }
    if (t.closest("[data-tour]")) { OC.tour(); return; }
    const qh = t.closest("[data-h]");
    if (qh) { e.preventDefault(); e.stopPropagation(); closeMenus(); showHelp(qh.dataset.h); return; }
    const sec = t.closest("[data-sec]");
    if (sec) { const id = sec.dataset.sec; st.navOpen[id] = !(id === "favorites" ? st.navOpen.favorites !== false : st.navOpen[id]); U.store.set("navOpen", st.navOpen); sec.parentElement.classList.toggle("open"); sec.setAttribute("aria-expanded", sec.parentElement.classList.contains("open")); return; }
    const unf = t.closest("[data-unfav]");
    if (unf) { e.preventDefault(); st.favs = st.favs.filter((f) => f.h !== unf.dataset.unfav); U.store.set("favs", st.favs); renderNav(parse()); return; }
    const go = t.closest("[data-go]");
    if (go) { closeMenus(); OC.go(go.dataset.go); return; }
    const nsb = t.closest("[data-ns]");
    if (nsb) { closeMenus(); setNs(nsb.dataset.ns); return; }
    if (t.closest("#nsBtn")) return nsMenu(t.closest("#nsBtn"));
    if (t.closest("#favBtn")) { const h = location.hash, i = st.favs.findIndex((f) => f.h === h); if (i >= 0) st.favs.splice(i, 1); else st.favs.push({ h: h, t: ($(".ph-tt") || {}).textContent || h }); U.store.set("favs", st.favs); t.closest("#favBtn").classList.toggle("on", i < 0); renderNav(parse()); toast(i < 0 ? "Favorilere eklendi" : "Favorilerden çıkarıldı"); return; }
    const mm = t.closest("[data-menu]");
    if (mm) return mastMenu(mm, mm.dataset.menu);
    const cp = t.closest("[data-copy]");
    if (cp) { U.copy(cp.dataset.copy).then(() => toast("Panoya kopyalandı")); return; }
    const ext = t.closest("[data-ext]");
    if (ext) { modal("Route adresi", `<p>Bu adres gerçek cluster'da Ingress Controller (router-default) üzerinden uygulamaya ulaşır:</p><div class="cmd-box"><pre class="code">${esc(ext.dataset.ext)}</pre></div><div class="alert alert-info">${U.ico("info", 14)}<div>Eğitim simülatöründe uygulamalar gerçekten çalışmadığı için adres açılmaz. ${R.q("route")}</div></div>`, [["Close", "secondary"]]); return; }
    const sa = t.closest(".sim-act");
    if (sa) { closeMenus(); simModal(sa.dataset.title || "İşlem", sa.dataset.cmd || "", sa.dataset.h2); return; }
    if (t.closest("#themeBtn")) { st.theme = st.theme === "dark" ? "light" : "dark"; U.store.set("theme", st.theme); document.documentElement.setAttribute("data-theme", st.theme); closeMenus(); return; }
    if (t.closest("#loginCmd")) { closeMenus(); const c = "oc login --token=sha256~" + U.hex(43) + " --server=" + OC.cluster.api; modal("Copy login command", `<p>Komut satırından aynı kimlikle bağlanmak için kullanılan komut (örnek token): ${R.q("api-url")}</p><div class="cmd-box"><pre class="code brk">${esc(c)}</pre><button class="btn btn-link btn-sm" data-copy="${esc(c)}">${U.ico("copy", 11)} Kopyala</button></div><p class="muted sm">Gerçek konsolda bu sayfa OAuth sunucusundan kısa ömürlü bir token üretir. Token'ı kimseyle paylaşmayın.</p>`, [["Close", "secondary"]]); return; }
    if (t.closest("#logoutBtn")) { closeMenus(); toast("Simülasyon: oturum kapatılmaz 🙂"); return; }
    if (t.closest("#aboutBtn")) { closeMenus(); modal("About", `<div class="about"><img src="img/logo.svg" width="48" alt=""><div><h3>OpenShift Container Platform (Eğitim Simülatörü)</h3>${R.dl([["OpenShift version", OC.cluster.version, "cluster-version"], ["Kubernetes version", OC.cluster.k8s], ["Channel", OC.cluster.channel, "update-channel"], ["Cluster ID", OC.cluster.id, "cluster-id"], ["API server", OC.cluster.api, "api-url"]])}<p class="muted sm">Bu arayüz eğitim amaçlıdır; Red Hat ürünü değildir ve gerçek bir cluster'a bağlanmaz.</p></div></div>`, [["Close", "secondary"]]); return; }
    if (t.closest("#cliBtn")) { closeMenus(); modal("Command Line Tools", `<p><b>oc</b> – OpenShift komut satırı istemcisi. kubectl'in tüm özelliklerini ve OpenShift'e özgü komutları (new-app, start-build, rsh, adm…) içerir. ${R.q("ui-terminal")}</p><ul class="lst"><li>Download oc for Linux for x86_64</li><li>Download oc for Mac for ARM 64</li><li>Download oc for Windows for x86_64</li></ul><p><b>helm</b> 3, <b>tkn</b> (Tekton CLI), <b>kn</b> (Serverless CLI) ve <b>virtctl</b> da buradan indirilebilir.</p><div class="cmd-box"><pre class="code">oc version\noc login ${esc(OC.cluster.api)}\noc help</pre></div>`, [["Close", "secondary"]]); return; }
    if (t.closest("#tourBtn")) { closeMenus(); OC.tour(); return; }
  });
  $("#hpClose").addEventListener("click", closeHelp);
  document.addEventListener("keydown", (e) => {
    if ((e.key === "Enter" || e.key === " ") && document.activeElement && document.activeElement.matches("[data-sec]")) { e.preventDefault(); document.activeElement.click(); return; }
    if (e.key === "Escape") { if ($(".modal-bg")) $(".modal-bg").remove(); else if ($(".menu")) closeMenus(); else closeHelp(); }
    if (e.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { const q = $("#listQ") || $("#searchQ"); if (q) { e.preventDefault(); q.focus(); } }
  });
  $("#navToggle").addEventListener("click", () => { if (window.innerWidth < 1200) document.body.classList.toggle("nav-show"); else { document.body.classList.toggle("nav-hide"); } });
  $("#scrim").addEventListener("click", () => document.body.classList.remove("nav-show"));
  const lm = $("#learnMode"); lm.checked = st.learn;
  lm.addEventListener("change", () => { st.learn = lm.checked; U.store.set("learn", st.learn); document.body.classList.toggle("learn-off", !st.learn); toast(st.learn ? "Öğrenme modu açık: (?) simgeleri görünür" : "Öğrenme modu kapalı: konsol gerçek görünümünde"); });
  $("#mhHelpSlot").innerHTML = R.q("ui-learn", "qh-mast");
  $("#termBtn").addEventListener("click", () => OC.webTerminal());

  /* ---------------- Rehberli tur ---------------- */
  OC.tour = function () {
    const steps = [["Hoş geldiniz!", "Bu, OpenShift Web Console'un eğitim amaçlı bir simülasyonudur. Gerçek bir cluster'a bağlı değildir; rahatça gezinip deneyebilirsiniz."], ["(?) simgeleri", "Her menü, alan, sütun ve sekmenin yanındaki küçük (?) simgesine tıklayın: sağda Türkçe açıklama, kullanım amacı, ne zaman kullanılacağı ve teknik örnek açılır. Altı kesik çizgili alan adları da tıklanabilir."], ["Sol menü", "Home, Workloads, Networking, Storage, Builds, Observe, Compute, User Management ve Administration bölümleri gerçek konsoldaki gibi düzenlenmiştir."], ["Project seçici", "Liste sayfalarının üstündeki 'Project:' menüsünden çalışacağınız projeyi seçin veya 'All Projects' ile hepsini görün."], ["Deneyin!", "Bir Deployment'ı ölçekleyin, bir Pod'u silip controller'ın yenisini oluşturmasını izleyin, Pod loglarını ve terminalini açın, Topology görünümüne göz atın. İyi öğrenmeler!"]];
    let i = 0;
    const show = () => modal(steps[i][0] + "  (" + (i + 1) + "/" + steps.length + ")", `<p>${esc(steps[i][1])}</p>`, [[i < steps.length - 1 ? "İleri" : "Başla", "primary", () => { if (i < steps.length - 1) { i++; setTimeout(show, 10); } else U.store.set("toured", true); return true; }], ["Turu kapat", "link", () => (U.store.set("toured", true), true)]]);
    show();
  };

  window.addEventListener("hashchange", render);
  render();
  if (!U.store.get("toured", false)) setTimeout(OC.tour, 400);
})();
