/* OpenShift Eğitim Konsolu – yardımcı fonksiyonlar */
(function () {
  "use strict";
  const OC = (window.OC = window.OC || {});
  const U = (OC.u = {});

  U.$ = (s, el) => (el || document).querySelector(s);
  U.$$ = (s, el) => Array.from((el || document).querySelectorAll(s));
  U.esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* Belirlenimci (deterministic) rastgele sayı üreteci: her açılışta aynı örnek veriler */
  let seed = 20261119;
  U.rnd = function () {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  U.pick = (a) => a[Math.floor(U.rnd() * a.length)];
  U.ri = (a, b) => a + Math.floor(U.rnd() * (b - a + 1));
  const HC = "bcdfghjklmnpqrstvwxz2456789";
  U.hs = (n) => Array.from({ length: n }, () => U.pick(HC)).join("");
  U.hex = (n) => Array.from({ length: n }, () => "0123456789abcdef"[Math.floor(U.rnd() * 16)]).join("");
  U.uid = () => [8, 4, 4, 4, 12].map(U.hex).join("-");

  U.NOW = Date.now();
  U.ago = (min) => new Date(U.NOW - min * 60000).toISOString().replace(/\.\d+Z$/, "Z");

  const fmt = new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  U.date = (iso) => (iso ? fmt.format(new Date(iso)) : "-");
  U.age = (iso) => {
    if (!iso) return "-";
    const m = Math.max(0, Math.round((U.NOW - Date.parse(iso)) / 60000));
    if (m < 60) return m + "m";
    if (m < 1440) return Math.floor(m / 60) + "h" + (m % 60 ? (m % 60) + "m" : "");
    const d = Math.floor(m / 1440);
    return d + "d" + (d < 10 && Math.floor((m % 1440) / 60) ? Math.floor((m % 1440) / 60) + "h" : "");
  };
  U.rel = (iso) => {
    const m = Math.round((U.NOW - Date.parse(iso)) / 60000);
    if (m < 1) return "az önce";
    if (m < 60) return m + " dakika önce";
    if (m < 1440) return Math.floor(m / 60) + " saat önce";
    return Math.floor(m / 1440) + " gün önce";
  };
  U.ts = (iso) => `<span class="ts">${U.ico("globe")} ${U.esc(U.date(iso))}</span>`;

  /* Sayı biçimleri (Türkçe ondalık ayırıcı) */
  U.num = (n, d) => Number(n).toLocaleString("tr-TR", { maximumFractionDigits: d == null ? 1 : d, minimumFractionDigits: 0 });
  U.mib = (m) => (m >= 1024 ? U.num(m / 1024, 1) + " GiB" : U.num(m, 1) + " MiB");
  U.cores = (c) => (c < 1 ? U.num(c, 3) + " cores" : U.num(c, 2) + " cores");

  /* Basit YAML serileştirici */
  const needQ = (s) => s === "" || /^[\s]|[\s]$|^[-?:,\[\]{}#&*!|>'"%@`]|: | #|^(true|false|null|yes|no|on|off|~)$/i.test(s) || /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(s) || /^0x/.test(s);
  function scalar(v) {
    if (v === null || v === undefined) return "null";
    if (typeof v === "number" || typeof v === "boolean") return String(v);
    const s = String(v);
    return needQ(s) ? "'" + s.replace(/'/g, "''") + "'" : s;
  }
  U.yaml = function (obj) {
    const out = [];
    function w(v, ind, inList) {
      const pad = "  ".repeat(ind);
      if (Array.isArray(v)) {
        if (!v.length) return " []";
        v.forEach((it) => {
          if (it && typeof it === "object" && !Array.isArray(it)) {
            const keys = Object.keys(it).filter((k) => k[0] !== "_");
            if (!keys.length) { out.push(pad + "- {}"); return; }
            keys.forEach((k, i) => {
              const pre = i === 0 ? pad + "- " : pad + "  ";
              line(pre, k, it[k], ind + 1);
            });
          } else if (Array.isArray(it)) {
            out.push(pad + "-"); w(it, ind + 1);
          } else out.push(pad + "- " + scalar(it));
        });
        return null;
      }
      Object.keys(v).filter((k) => k[0] !== "_").forEach((k) => line(pad, k, v[k], ind));
      return null;
    }
    function line(pre, k, val, ind) {
      const key = needQ(k) ? "'" + k + "'" : k;
      if (val && typeof val === "object") {
        if (Array.isArray(val)) {
          if (!val.length) { out.push(pre + key + ": []"); return; }
          out.push(pre + key + ":"); w(val, ind);
        } else {
          if (!Object.keys(val).filter((x) => x[0] !== "_").length) { out.push(pre + key + ": {}"); return; }
          out.push(pre + key + ":"); w(val, ind + 1);
        }
      } else if (typeof val === "string" && val.indexOf("\n") >= 0) {
        out.push(pre + key + ": |");
        val.replace(/\n$/, "").split("\n").forEach((l) => out.push("  ".repeat(ind + 1) + l));
      } else out.push(pre + key + ": " + scalar(val));
    }
    w(obj, 0);
    return out.join("\n");
  };
  /* YAML renklendirme (salt görsel) */
  U.yamlHtml = function (txt) {
    return txt.split("\n").map((l, i) => {
      let h = U.esc(l);
      h = h.replace(/^(\s*-?\s*)([^:\s][^:]*?)(:)(\s|$)/, '$1<span class="yk">$2</span>$3$4');
      h = h.replace(/(:\s)(&#39;.*&#39;)$/, '$1<span class="ys">$2</span>').replace(/(:\s)(\d+(\.\d+)?|true|false|null)$/, '$1<span class="yn">$2</span>');
      h = h.replace(/(^|\s)(#.*)$/, '$1<span class="yc">$2</span>');
      return `<div class="yl"><span class="ln">${i + 1}</span><span class="lc">${h || " "}</span></div>`;
    }).join("");
  };

  /* Simgeler (sade, özgün SVG) */
  const P = {
    globe: '<circle cx="8" cy="8" r="7" fill="currentColor"/><path d="M8 1c2 2 2.6 4.4 2.6 7S10 13 8 15M8 1C6 3 5.4 5.4 5.4 8S6 13 8 15M1.3 6h13.4M1.3 10h13.4" stroke="var(--globe-ln)" stroke-width="1" fill="none"/>',
    sync: '<path d="M13.5 6.2A5.7 5.7 0 0 0 3 4.6M2.5 9.8A5.7 5.7 0 0 0 13 11.4" stroke="currentColor" stroke-width="1.7" fill="none"/><path d="M2 1.8v3.8h3.8M14 14.2v-3.8h-3.8" stroke="currentColor" stroke-width="1.7" fill="none"/>',
    check: '<circle cx="8" cy="8" r="7" fill="var(--ok)"/><path d="m4.6 8.2 2.3 2.3 4.6-4.8" stroke="#fff" stroke-width="1.7" fill="none"/>',
    warn: '<path d="M8 1.2 15.2 14H.8z" fill="var(--warn)"/><path d="M8 5.6v4.2" stroke="#1b1b1b" stroke-width="1.6"/><circle cx="8" cy="11.8" r=".95" fill="#1b1b1b"/>',
    err: '<circle cx="8" cy="8" r="7" fill="var(--danger)"/><path d="m5.3 5.3 5.4 5.4m0-5.4-5.4 5.4" stroke="#fff" stroke-width="1.7"/>',
    info: '<circle cx="8" cy="8" r="7" fill="var(--info)"/><path d="M8 7v4.6" stroke="#fff" stroke-width="1.7"/><circle cx="8" cy="4.7" r="1" fill="#fff"/>',
    pend: '<circle cx="8" cy="8" r="6.3" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M8 4.3V8l2.6 1.7" stroke="currentColor" stroke-width="1.5" fill="none"/>',
    ban: '<circle cx="8" cy="8" r="6.3" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="m3.6 12.4 8.8-8.8" stroke="currentColor" stroke-width="1.6"/>',
    unknown: '<circle cx="8" cy="8" r="6.3" stroke="currentColor" stroke-width="1.5" fill="none" stroke-dasharray="2 2"/>',
    sort: '<path d="M8 1.5 11 5H5zM8 14.5 5 11h6z" fill="currentColor"/>',
    up: '<path d="M8 2 12 7H4z" fill="currentColor"/><path d="M8 6v8" stroke="currentColor" stroke-width="1.6"/>',
    down: '<path d="M8 14 4 9h8z" fill="currentColor"/><path d="M8 2v8" stroke="currentColor" stroke-width="1.6"/>',
    star: '<path d="m8 1 2.1 4.5 4.9.6-3.6 3.4.9 4.9L8 12 3.7 14.4l.9-4.9L1 6.1l4.9-.6z" fill="currentColor"/>',
    filter: '<path d="M1 2h14L9.5 8.6V14l-3-1.5V8.6z" fill="currentColor"/>',
    cols: '<path d="M1.5 2.5h13v11h-13z" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M1.5 5h13" stroke="currentColor" stroke-width="2.5"/><path d="M8 5v8.5" stroke="currentColor" stroke-width="1.5"/>',
    kebab: '<circle cx="8" cy="3" r="1.5" fill="currentColor"/><circle cx="8" cy="8" r="1.5" fill="currentColor"/><circle cx="8" cy="13" r="1.5" fill="currentColor"/>',
    chev: '<path d="m4 6 4 4 4-4" stroke="currentColor" stroke-width="1.8" fill="none"/>',
    chevr: '<path d="m6 4 4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none"/>',
    copy: '<path d="M5 1.5h8v10H5z" stroke="currentColor" stroke-width="1.4" fill="none"/><path d="M3 4.5v10h8" stroke="currentColor" stroke-width="1.4" fill="none"/>',
    ext: '<path d="M9 2h5v5M14 2 7.5 8.5M12 9.5V14H2V4h4.5" stroke="currentColor" stroke-width="1.5" fill="none"/>',
    search: '<circle cx="6.8" cy="6.8" r="5" stroke="currentColor" stroke-width="1.7" fill="none"/><path d="m10.5 10.5 4 4" stroke="currentColor" stroke-width="1.9"/>',
    pencil: '<path d="m2 11.5 8.3-8.3 2.5 2.5L4.5 14H2zM11.4 2.1l1-1 2.5 2.5-1 1z" fill="currentColor"/>',
    lock: '<rect x="3" y="7" width="10" height="8" rx="1.3" fill="currentColor"/><path d="M5 7V5a3 3 0 0 1 6 0v2" stroke="currentColor" stroke-width="1.6" fill="none"/>',
    book: '<path d="M2 2.5c2-.8 4-.8 6 .6v11c-2-1.4-4-1.4-6-.6zm12 0c-2-.8-4-.8-6 .6v11c2-1.4 4-1.4 6-.6z" fill="currentColor"/>',
    bell: '<path d="M8 1.5a4.2 4.2 0 0 0-4.2 4.2v3.6L2.3 12h11.4l-1.5-2.7V5.7A4.2 4.2 0 0 0 8 1.5z" fill="currentColor"/><circle cx="8" cy="13.7" r="1.4" fill="currentColor"/>',
    play: '<path d="M4 2v12l10-6z" fill="currentColor"/>',
    pause: '<path d="M3.5 2h3v12h-3zm6 0h3v12h-3z" fill="currentColor"/>',
    download: '<path d="M8 1.5v8.5M4.4 6.8 8 10.4l3.6-3.6M2 13.5h12" stroke="currentColor" stroke-width="1.7" fill="none"/>',
    plus: '<path d="M7.1 2h1.8v5.1H14v1.8H8.9V14H7.1V8.9H2V7.1h5.1z" fill="currentColor"/>',
    trash: '<path d="M2.5 3.5h11M6 3.5V2h4v1.5M3.8 3.5l.8 11h6.8l.8-11" stroke="currentColor" stroke-width="1.5" fill="none"/>',
    sun: '<circle cx="8" cy="8" r="3.2" fill="currentColor"/><path d="M8 .8v2.2M8 13v2.2M.8 8H3M13 8h2.2M2.9 2.9l1.6 1.6M11.5 11.5l1.6 1.6M2.9 13.1l1.6-1.6M11.5 4.5l1.6-1.6" stroke="currentColor" stroke-width="1.4"/>',
    cube: '<path d="M8 1 14.5 4.5v7L8 15 1.5 11.5v-7z" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M1.5 4.5 8 8l6.5-3.5M8 8v7" stroke="currentColor" stroke-width="1.4" fill="none"/>'
  };
  U.ico = (n, sz, cls) => `<svg class="ic ${cls || ""}" viewBox="0 0 16 16" width="${sz || 14}" height="${sz || 14}" aria-hidden="true">${P[n] || ""}</svg>`;

  U.copy = function (text) {
    try {
      if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    } catch (e) { /* yoksay */ }
    const ta = document.createElement("textarea");
    ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); } catch (e) { /* yoksay */ }
    ta.remove();
    return Promise.resolve();
  };

  U.store = {
    get(k, d) { try { const v = localStorage.getItem("ocedu." + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("ocedu." + k, JSON.stringify(v)); } catch (e) { /* yoksay */ } }
  };

  /* Basit sparkline / alan grafiği (SVG) */
  U.spark = function (vals, opt) {
    opt = opt || {};
    const w = opt.w || 260, h = opt.h || 60, max = opt.max || Math.max.apply(null, vals) * 1.15 || 1;
    const step = w / (vals.length - 1);
    const pts = vals.map((v, i) => [i * step, h - (v / max) * (h - 4) - 2]);
    const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
    const col = opt.color || "var(--chart1)";
    const grid = opt.grid ? [0.25, 0.5, 0.75].map((g) => `<line x1="0" x2="${w}" y1="${(h * g).toFixed(1)}" y2="${(h * g).toFixed(1)}" class="grid"/>`).join("") : "";
    return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" width="100%" height="${h}">${grid}<path d="${d} L${w} ${h} L0 ${h}Z" fill="${col}" fill-opacity=".22"/><path d="${d}" fill="none" stroke="${col}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
  };
  U.series = function (n, base, jitter, trend) {
    const a = []; let v = base;
    for (let i = 0; i < n; i++) { v = Math.max(0, base + (trend || 0) * i + (U.rnd() - 0.5) * jitter * 2); a.push(v); }
    return a;
  };
})();
