/* OpenShift Eğitim Konsolu – Türkçe açıklamalar (kaynak türleri, kavramlar, menüler)
   Her kayıt: başlık, kategori, ne olduğu, ne için kullanıldığı, ne zaman kullanılacağı,
   sağladığı fayda, isteğe bağlı teknik örnek ve ilgili konular. */
(function () {
  "use strict";
  const OC = window.OC;
  const H = (OC.H = OC.H || {});
  OC.h = function (key, t, cat, what, why, when, ben, ex, rel) { H[key] = { t: t, cat: cat, what: what, why: why, when: when, ben: ben, ex: ex, rel: rel || [] }; };
  const h = OC.h;

  /* =================== TEMEL KAVRAMLAR =================== */
  h("openshift", "OpenShift Container Platform", "Temel kavram",
    "Red Hat OpenShift, Kubernetes üzerine kurulmuş kurumsal bir konteyner platformudur. Kubernetes'in tüm API'lerini içerir; buna ek olarak yerleşik image registry, Route ile dış erişim, Source-to-Image (S2I) derleme, OAuth tabanlı kimlik doğrulama, Operator yaşam döngüsü yönetimi (OLM), izleme (Prometheus/Alertmanager) ve bu web konsolu gibi bileşenleri hazır sunar.",
    "Uygulamaları konteyner olarak paketleyip birden fazla sunucu (node) üzerinde güvenli, ölçeklenebilir ve kendi kendini onaran biçimde çalıştırmak için kullanılır.",
    "Mikroservis mimarisine geçişte, çok sayıda uygulamanın standart bir platformda işletilmesi gerektiğinde, CI/CD ve otomatik ölçekleme ihtiyaçlarında tercih edilir.",
    "Kubernetes'i sıfırdan kurup entegre etme yükünü ortadan kaldırır; güvenlik varsayılan olarak sıkıdır (ör. konteynerler root olmayan rastgele UID ile çalışır), güncellemeler tek tıkla cluster genelinde yapılır.",
    "# Cluster'a giriş ve proje oluşturma\noc login https://api.ocp-egitim.egitim.local:6443 -u egitim.admin\noc new-project demo\noc new-app --name=merhaba registry.access.redhat.com/ubi9/httpd-24\noc expose service/merhaba",
    ["project", "pod", "deployment", "route", "operator"]);

  h("kubernetes-object", "Kubernetes nesne modeli", "Temel kavram",
    "Cluster'daki her şey (Pod, Service, Deployment…) bir API nesnesidir. Her nesnede dört ana bölüm bulunur: apiVersion/kind (türü), metadata (ad, namespace, label, annotation), spec (istenen durum – siz yazarsınız) ve status (gerçekleşen durum – sistem yazar).",
    "Kubernetes 'bildirimsel' (declarative) çalışır: Siz spec içinde ne istediğinizi tanımlarsınız, controller'lar sürekli olarak gerçek durumu bu hedefe yaklaştırır (reconciliation loop).",
    "Konsoldaki her detay sayfası aslında bir nesnenin spec ve status alanlarının görselleştirilmesidir. YAML sekmesi ham nesneyi gösterir.",
    "Aynı YAML'ı Git'te saklayıp her ortama uygulayabilirsiniz (GitOps). Elle yapılan değişiklikler yerine tekrarlanabilir tanımlar oluşur.",
    "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: ornek\n  namespace: demo\nspec:        # istenen durum\n  replicas: 3\nstatus:      # gerçekleşen durum (salt okunur)\n  readyReplicas: 3",
    ["labels", "annotations", "tab-yaml"]);

  /* =================== WORKLOADS =================== */
  h("pod", "Pod", "Workloads",
    "Pod, Kubernetes'te çalıştırılabilen en küçük birimdir. Bir veya daha fazla konteyneri aynı ağ ad alanı (aynı IP adresi ve portlar), aynı depolama birimleri ve aynı yaşam döngüsü ile bir arada çalıştırır. Her Pod'a cluster içi ağdan benzersiz bir IP atanır.",
    "Uygulamanızın çalışan kopyasını (instance) temsil eder. Konteynerler doğrudan değil, her zaman bir Pod içinde çalıştırılır.",
    "Pod'ları genellikle doğrudan oluşturmazsınız; Deployment, StatefulSet, DaemonSet veya Job gibi bir controller sizin yerinize oluşturur ve yönetir. Doğrudan Pod oluşturmak yalnızca hata ayıklama veya tek seferlik testler için uygundur.",
    "Pod'lar geçicidir (ephemeral): çökerse veya node kaybolursa controller yenisini oluşturur. Bu sayede uygulama kendi kendini onarır. Ana konteynerin yanına log toplayıcı veya proxy gibi 'sidecar' konteynerler eklenebilir.",
    "apiVersion: v1\nkind: Pod\nmetadata:\n  name: curl-test\nspec:\n  containers:\n  - name: curl\n    image: curlimages/curl:8.6.0\n    command: [\"sleep\", \"infinity\"]\n\n# Komut satırı:\noc get pods\noc logs curl-test\noc rsh curl-test",
    ["deployment", "container", "pod-status", "replicaset", "node"]);

  h("deployment", "Deployment", "Workloads",
    "Deployment, durumsuz (stateless) uygulamaları bildirimsel olarak yöneten Kubernetes controller'ıdır. Hangi imajın, kaç kopya (replica) ile ve hangi ayarlarla çalışacağını tanımlar; bunu bir ReplicaSet aracılığıyla Pod'lara dönüştürür.",
    "Web sunucuları, REST API'leri, frontend uygulamaları gibi her kopyası birbirinin aynı olan uygulamaları dağıtmak, ölçeklemek ve güncellemek için kullanılır.",
    "Kalıcı kimlik veya Pod'a özel disk gerektirmeyen her uygulama için ilk tercih Deployment'tır. Veritabanı gibi sıralı kimlik isteyen uygulamalar için StatefulSet tercih edilmelidir. OpenShift'te eski DeploymentConfig yerine artık Deployment önerilir.",
    "Yeni sürüme geçerken kesintisiz 'rolling update' yapar, sorun çıkarsa önceki ReplicaSet'e tek komutla geri döner (rollback), Pod çökerse otomatik olarak yenisini başlatır. HPA ile otomatik ölçeklenebilir.",
    "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: frontend\nspec:\n  replicas: 3\n  selector:\n    matchLabels: { app: frontend }\n  template:\n    metadata:\n      labels: { app: frontend }\n    spec:\n      containers:\n      - name: frontend\n        image: quay.io/eticaret/frontend:2.4.1\n        ports: [{ containerPort: 8080 }]\n\n# Ölçekleme ve geri alma\noc scale deployment/frontend --replicas=5\noc rollout undo deployment/frontend",
    ["replicaset", "pod", "replicas", "strategy", "hpa", "deploymentconfig"]);

  h("deploymentconfig", "DeploymentConfig", "Workloads",
    "DeploymentConfig (DC), OpenShift'e özgü ve Kubernetes Deployment'tan önce geliştirilmiş dağıtım nesnesidir. ReplicaSet yerine ReplicationController kullanır ve her sürümü numaralandırır (portal-web-1, portal-web-2 …). ImageStream değiştiğinde otomatik yeniden dağıtım yapan 'trigger' mekanizmasına ve lifecycle hook'larına sahiptir.",
    "Eski OpenShift 3.x tabanlı uygulamaların ve S2I ile oluşan ImageStream'e bağlı otomatik dağıtımların yönetiminde kullanılır.",
    "OpenShift 4.14 itibarıyla DeploymentConfig 'deprecated' (kullanımdan kaldırılacak) durumdadır. Yeni projelerde Deployment kullanın; ImageStream tetikleme ihtiyacı için Deployment'a 'image.openshift.io/triggers' annotation'ı eklenebilir. Mevcut DC'leri planlı olarak Deployment'a taşıyın.",
    "Mevcut uygulamalarda ImageChange ve ConfigChange tetikleyicileri sayesinde yeni imaj build edildiği anda otomatik dağıtım yapılır.",
    "# DC'yi elle yeni sürüme çıkarma\noc rollout latest dc/portal-web\n# Deployment'a ImageStream tetikleyicisi ekleme (DC alternatifi)\noc set triggers deploy/portal-web --from-image=portal-web:latest -c portal-web",
    ["deployment", "replicationcontroller", "imagestream", "dc-triggers"]);

  h("replicaset", "ReplicaSet", "Workloads",
    "ReplicaSet, belirli bir label seçicisine uyan Pod'lardan her an tanımlı sayıda (replicas) çalıştığını garanti eden controller'dır. Eksik Pod varsa oluşturur, fazlaysa siler.",
    "Deployment'ın arka planda kullandığı yapı taşıdır. Deployment her şablon değişikliğinde yeni bir ReplicaSet oluşturur; eski ReplicaSet'ler 0 replica ile geçmiş (revision history) olarak saklanır.",
    "Doğrudan ReplicaSet oluşturmanız neredeyse hiç gerekmez; her zaman Deployment kullanın. ReplicaSet listesi, bir Deployment'ın sürüm geçmişini incelemek için faydalıdır.",
    "Pod sayısının sürekli korunmasını sağlar; rollback işlemi aslında eski ReplicaSet'in tekrar ölçeklenmesidir.",
    "oc get rs -l app=frontend\n# Adın sonundaki 'pod-template-hash' şablonun özetidir:\n# frontend-7c9d8f6b5d  ->  Pod: frontend-7c9d8f6b5d-x2kqp",
    ["deployment", "pod", "revision-history"]);

  h("replicationcontroller", "ReplicationController", "Workloads",
    "ReplicationController, ReplicaSet'in eski sürümüdür; Pod sayısını sabit tutar ancak yalnızca eşitlik tabanlı label seçicisi destekler.",
    "OpenShift'te DeploymentConfig her sürüm için bir ReplicationController oluşturur (ör. portal-web-6).",
    "Yeni uygulamalarda kullanılmamalıdır. Yalnızca DeploymentConfig geçmişini incelerken karşınıza çıkar.",
    "DC sürüm geçmişinin ve geri dönüşlerin temelini oluşturur.",
    "oc get rc -l openshift.io/deployment-config.name=portal-web",
    ["deploymentconfig", "replicaset"]);

  h("statefulset", "StatefulSet", "Workloads",
    "StatefulSet, durum bilgisi tutan (stateful) uygulamalar için tasarlanmış controller'dır. Her Pod'a kalıcı ve sıralı bir kimlik verir (postgresql-0, postgresql-1 …), her Pod için ayrı bir PersistentVolumeClaim oluşturur ve Pod'ları belirli bir sırayla başlatır/durdurur.",
    "Veritabanları (PostgreSQL, MongoDB), mesaj kuyrukları (Kafka, RabbitMQ), dağıtık depolama ve cluster üyelerinin birbirini isimle bulması gereken sistemler için kullanılır.",
    "Pod yeniden oluştuğunda aynı isim, aynı DNS kaydı ve aynı diskle geri gelmesi gerekiyorsa StatefulSet kullanın. Kopyaları birbirinin aynı olan uygulamalar için Deployment yeterlidir.",
    "Pod kimliği ve verisi Pod silinse bile korunur. Headless Service ile her Pod'a sabit DNS adı verilir: postgresql-0.postgresql-headless.eticaret-prod.svc.cluster.local",
    "apiVersion: apps/v1\nkind: StatefulSet\nmetadata:\n  name: postgresql\nspec:\n  serviceName: postgresql-headless\n  replicas: 1\n  selector: { matchLabels: { app: postgresql } }\n  template: { ... }\n  volumeClaimTemplates:\n  - metadata: { name: data }\n    spec:\n      accessModes: [ReadWriteOnce]\n      resources: { requests: { storage: 20Gi } }",
    ["pvc", "volume-claim-templates", "headless-service", "pod-management-policy"]);

  h("daemonset", "DaemonSet", "Workloads",
    "DaemonSet, seçilen her node üzerinde bir Pod kopyasının çalışmasını garanti eder. Cluster'a yeni node eklendiğinde Pod otomatik olarak oraya da yerleştirilir; node çıkarıldığında Pod da kaldırılır.",
    "Node seviyesinde çalışması gereken altyapı bileşenleri için kullanılır: log toplayıcılar (Vector), izleme ajanları (node-exporter), ağ eklentileri, DNS (dns-default), depolama sürücüleri.",
    "'Her sunucuda bir tane' mantığı gerekiyorsa DaemonSet kullanın. Belirli node'lara sınırlamak için nodeSelector, master/infra node'lara da yerleşmesi için tolerations ekleyin.",
    "Node sayısı değiştikçe elle müdahale gerekmez; altyapı ajanları her zaman eksiksiz dağıtılmış olur.",
    "oc get ds -n openshift-monitoring\nNAME            DESIRED   CURRENT   READY   NODE SELECTOR\nnode-exporter   8         8         8       kubernetes.io/os=linux",
    ["node", "tolerations", "node-selector"]);

  h("job", "Job", "Workloads",
    "Job, bir veya daha fazla Pod çalıştırıp bunların başarıyla tamamlanmasını sağlayan controller'dır. Pod başarısız olursa backoffLimit'e kadar yeniden dener. Tamamlanan Pod 'Completed' durumunda kalır ve logları incelenebilir.",
    "Veritabanı migration'ı, toplu veri işleme, rapor üretimi, yedek alma gibi başlangıcı ve sonu olan tek seferlik işler için kullanılır.",
    "Sürekli çalışması gerekmeyen, işini bitirip çıkan görevlerde Job kullanın. Düzenli tekrarlanması gerekiyorsa CronJob tercih edin.",
    "Hata durumunda otomatik yeniden deneme, paralel çalışma (parallelism) ve tamamlanma sayısı (completions) kontrolü sağlar.",
    "apiVersion: batch/v1\nkind: Job\nmetadata:\n  name: db-migrate-v12\nspec:\n  backoffLimit: 6\n  template:\n    spec:\n      restartPolicy: OnFailure\n      containers:\n      - name: migrate\n        image: quay.io/eticaret/katalog-api:1.12.0\n        command: [\"./migrate.sh\", \"--target=12\"]",
    ["cronjob", "backoff-limit", "completions", "restart-policy"]);

  h("cronjob", "CronJob", "Workloads",
    "CronJob, Linux cron söz dizimiyle tanımlanan bir zamanlamaya göre periyodik olarak Job oluşturur.",
    "Gece raporları, düzenli yedeklemeler, eski verilerin temizlenmesi, periyodik senkronizasyon gibi tekrar eden işler için kullanılır.",
    "Bir işin belirli saatlerde veya aralıklarla otomatik çalışması gerektiğinde kullanın. timeZone alanıyla saat dilimini (ör. Europe/Istanbul) belirtmeyi unutmayın; aksi halde UTC kullanılır.",
    "Harici bir zamanlayıcıya gerek kalmadan işler cluster içinde, kaynak limitleri ve loglarıyla birlikte yönetilir. Geçmiş Job sayısı history limit'lerle sınırlanır.",
    "apiVersion: batch/v1\nkind: CronJob\nmetadata:\n  name: gece-raporu\nspec:\n  schedule: \"0 2 * * *\"      # her gün 02:00\n  timeZone: Europe/Istanbul\n  concurrencyPolicy: Forbid\n  jobTemplate:\n    spec:\n      template:\n        spec:\n          restartPolicy: OnFailure\n          containers:\n          - name: rapor\n            image: quay.io/eticaret/raporlama:1.3.0",
    ["job", "cron-schedule", "concurrency-policy", "suspend"]);

  h("hpa", "HorizontalPodAutoscaler (HPA)", "Workloads",
    "HPA, bir Deployment/StatefulSet'in replica sayısını CPU, bellek veya özel metriklere göre otomatik olarak artırıp azaltan nesnedir. Metrikleri belirli aralıklarla (varsayılan 15 sn) okur ve hedef değere ulaşmak için gereken Pod sayısını hesaplar.",
    "Trafiği gün içinde dalgalanan uygulamalarda kaynakları verimli kullanmak için kullanılır.",
    "Uygulamanız yatay ölçeklenebiliyorsa (durumsuzsa) ve konteynerlerde resources.requests tanımlıysa kullanın. Utilization hedefleri 'request' değerine göre hesaplanır; request tanımlı değilse HPA çalışmaz.",
    "Yoğun saatlerde performansı korur, sakin saatlerde kaynak tasarrufu sağlar. minReplicas ile asgari erişilebilirlik garanti edilir.",
    "oc autoscale deployment/frontend --min=3 --max=10 --cpu-percent=70\n\n# Hesaplama: istenen = ceil(mevcut * (mevcutMetrik / hedefMetrik))\n# 3 pod, CPU %140, hedef %70  =>  ceil(3 * 140/70) = 6 pod",
    ["deployment", "requests-limits", "replicas"]);

  h("pdb", "PodDisruptionBudget (PDB)", "Workloads",
    "PDB, planlı (gönüllü) kesintiler sırasında bir uygulamanın en az kaç Pod'unun çalışır kalması gerektiğini (minAvailable) veya en fazla kaçının aynı anda kapatılabileceğini (maxUnavailable) belirtir.",
    "Node bakımı (drain), cluster güncellemesi ve MachineConfig değişiklikleri sırasında uygulamanın tamamen kapanmasını engeller.",
    "Üretimdeki ve birden fazla replica'ya sahip tüm kritik uygulamalar için tanımlanmalıdır. Tek replica'lı uygulamada minAvailable: 1 tanımlamak node drain işlemini sonsuza kadar bekletir; dikkatli olun.",
    "OpenShift güncellemeleri node'ları tek tek boşaltırken uygulama erişilebilirliği korunur.",
    "apiVersion: policy/v1\nkind: PodDisruptionBudget\nmetadata:\n  name: frontend-pdb\nspec:\n  minAvailable: 2\n  selector:\n    matchLabels: { app: frontend }",
    ["node-drain", "deployment"]);

  h("container", "Container (Konteyner)", "Workloads",
    "Konteyner; uygulamanın kodunu, çalışma zamanını ve bağımlılıklarını içeren imajdan başlatılan, izole bir işlemdir. OpenShift'te konteynerler CRI-O çalışma zamanı ile çalıştırılır.",
    "Uygulamayı her ortamda aynı şekilde çalışacak biçimde paketlemek için kullanılır.",
    "Her Pod en az bir konteyner içerir. Yardımcı görevler için 'init container' (ana konteynerden önce çalışıp biter) veya 'sidecar' (yan konteyner) eklenebilir.",
    "'Benim bilgisayarımda çalışıyordu' sorununu ortadan kaldırır; hızlı başlar, kaynak izolasyonu sağlar.",
    "containers:\n- name: katalog-api\n  image: quay.io/eticaret/katalog-api:1.12.0\n  ports:\n  - containerPort: 8080\n  resources:\n    requests: { cpu: 100m, memory: 384Mi }\n    limits:   { cpu: \"1\", memory: 768Mi }",
    ["pod", "image", "requests-limits", "readiness-probe"]);

  h("topology", "Topology", "Workloads",
    "Topology görünümü, seçili projedeki uygulamaları ve aralarındaki bağlantıları grafiksel olarak gösterir. Her daire bir workload'u (Deployment, StatefulSet vb.) temsil eder; dairenin çevresindeki halka Pod durumlarını renklerle gösterir. Aynı 'app.kubernetes.io/part-of' label'ına sahip bileşenler bir uygulama grubu içinde toplanır.",
    "Uygulama mimarisini bir bakışta anlamak, hangi bileşenin sorunlu olduğunu hızlıca görmek ve Route URL'lerine kısayoldan erişmek için kullanılır.",
    "Yeni bir projeyi tanırken, dağıtım sonrası durumu kontrol ederken veya geliştiricilere mimariyi anlatırken kullanın.",
    "Mavi halka = Running, açık mavi = Pending, kırmızı = hata (CrashLoopBackOff vb.). Ok işaretleri 'app.openshift.io/connects-to' annotation'ından gelir.",
    "# Bağlantı okunu oluşturan annotation:\noc annotate deploy/frontend app.openshift.io/connects-to='[{\"apiVersion\":\"apps/v1\",\"kind\":\"Deployment\",\"name\":\"katalog-api\"}]'",
    ["deployment", "labels", "route"]);

  /* =================== CONFIG =================== */
  h("configmap", "ConfigMap", "Workloads",
    "ConfigMap, uygulama yapılandırmasını anahtar-değer çiftleri veya dosya içeriği olarak saklayan nesnedir. Konteyner imajından bağımsız olarak yapılandırmayı değiştirmeyi sağlar.",
    "Ortam değişkenleri, yapılandırma dosyaları (nginx.conf, application.properties), özellik bayrakları (feature flags) gibi gizli olmayan ayarları uygulamaya aktarmak için kullanılır.",
    "Aynı imajı test ve üretim ortamında farklı ayarlarla çalıştırmak istediğinizde kullanın. Parola, token gibi hassas veriler için ConfigMap değil Secret kullanılmalıdır. Boyut sınırı 1 MiB'dir.",
    "'Bir kez derle, her yerde çalıştır' ilkesini mümkün kılar. Volume olarak bağlanan ConfigMap güncellendiğinde dosya Pod içinde bir süre sonra kendiliğinden güncellenir (env olarak verilenler için Pod yeniden başlatılmalıdır).",
    "apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: katalog-api-config\ndata:\n  LOG_LEVEL: INFO\n  application.properties: |\n    quarkus.http.port=8080\n\n# Deployment'a ortam değişkeni olarak ekleme\noc set env deploy/katalog-api --from=configmap/katalog-api-config",
    ["secret", "env", "envfrom", "volumes"]);

  h("secret", "Secret", "Workloads",
    "Secret; parola, API anahtarı, TLS sertifikası, registry kimlik bilgisi gibi hassas verileri saklayan nesnedir. Değerler YAML'da base64 kodlu tutulur. Base64 bir şifreleme değil yalnızca kodlamadır; asıl koruma RBAC yetkileri ve isteğe bağlı etcd şifrelemesi ile sağlanır.",
    "Uygulamaların veritabanı parolası, harici servis token'ları ve sertifikalar gibi gizli bilgilere kodda sabit yazmadan erişmesini sağlar.",
    "Gizli olması gereken her veri için kullanın. Türler: Opaque (genel), kubernetes.io/tls (sertifika), kubernetes.io/dockerconfigjson (imaj çekme), kubernetes.io/basic-auth, kubernetes.io/ssh-auth. Kurumsal ortamlarda External Secrets veya Vault entegrasyonu değerlendirilebilir.",
    "Hassas veri imaj ve Git deposu dışında tutulur; erişim yetkisi RBAC ile ayrıca kontrol edilir. Konsolda değerler varsayılan olarak gizlenir ('Reveal values' ile gösterilir).",
    "oc create secret generic postgresql \\\n  --from-literal=database-user=katalog_app \\\n  --from-literal=database-password='S1fre!'\n\n# base64 çözme (yetkiniz varsa):\noc get secret postgresql -o jsonpath='{.data.database-password}' | base64 -d",
    ["configmap", "secret-type", "serviceaccount", "env"]);

  /* =================== NETWORKING =================== */
  h("service", "Service", "Networking",
    "Service, label seçicisi ile eşleşen Pod'lara sabit bir sanal IP (ClusterIP) ve DNS adı üzerinden erişim sağlayan ağ soyutlamasıdır. Pod'lar sürekli değişse de Service adresi sabit kalır ve trafik sağlıklı (Ready) Pod'lara dağıtılır.",
    "Uygulama bileşenlerinin birbirine erişmesi için kullanılır. Örneğin frontend, katalog-api'ye 'http://katalog-api:8080' adresiyle ulaşır.",
    "Cluster içinde erişilmesi gereken her uygulama için Service oluşturun. Dış dünyaya açmak için Service'in önüne bir Route (veya Ingress) eklenir. Türler: ClusterIP (yalnızca içeriden), NodePort, LoadBalancer, ExternalName.",
    "Servis keşfi (service discovery) ve yük dengeleme otomatik hale gelir. Readiness probe'u başarısız olan Pod'lara trafik gönderilmez.",
    "apiVersion: v1\nkind: Service\nmetadata:\n  name: katalog-api\nspec:\n  selector: { app: katalog-api }\n  ports:\n  - name: 8080-tcp\n    port: 8080        # Service portu\n    targetPort: 8080  # konteyner portu\n\n# Tam DNS adı:\n# katalog-api.eticaret-prod.svc.cluster.local",
    ["route", "service-type", "selector", "target-port", "endpoints"]);

  h("route", "Route", "Networking",
    "Route, OpenShift'e özgü ve bir Service'i cluster dışından bir host adı (URL) ile erişilebilir kılan nesnedir. Trafik, Ingress Controller (HAProxy tabanlı 'router-default') üzerinden ilgili Service'e ve oradan Pod'lara iletilir.",
    "Web uygulamalarını ve API'leri kullanıcılara açmak, TLS (HTTPS) sonlandırmayı yönetmek, A/B testi veya blue-green dağıtım için trafiği birden fazla Service'e ağırlıklı bölmek amacıyla kullanılır.",
    "Uygulamanızın tarayıcıdan veya cluster dışındaki sistemlerden erişilmesi gerektiğinde oluşturun. Host belirtmezseniz otomatik olarak <route>-<proje>.apps.<cluster-domain> üretilir.",
    "Tek komutla HTTPS'li dış erişim sağlar; edge, passthrough ve re-encrypt TLS modlarını, path tabanlı yönlendirmeyi, zaman aşımı ve IP whitelist gibi ayarları annotation'larla destekler.",
    "oc expose service/frontend --hostname=shop.apps.ocp-egitim.egitim.local\noc create route edge frontend --service=frontend --insecure-policy=Redirect\n\n# Trafik bölme (canary):\nspec:\n  to: { kind: Service, name: frontend-v1, weight: 90 }\n  alternateBackends:\n  - { kind: Service, name: frontend-v2, weight: 10 }",
    ["service", "tls-termination", "route-host", "ingress", "insecure-policy"]);

  h("ingress", "Ingress", "Networking",
    "Ingress, dış HTTP/HTTPS trafiğini host ve path kurallarına göre Service'lere yönlendiren standart Kubernetes nesnesidir. OpenShift'te bir Ingress oluşturduğunuzda ingress-to-route controller onu otomatik olarak bir veya daha fazla Route'a dönüştürür.",
    "Farklı Kubernetes dağıtımları arasında taşınabilir (portable) dış erişim tanımları yazmak için kullanılır.",
    "Uygulama manifestlerinizin başka Kubernetes platformlarında da çalışması gerekiyorsa veya Helm chart'ı Ingress kullanıyorsa tercih edin. Yalnızca OpenShift hedefleniyorsa Route daha fazla özellik sunar (ağırlıklı trafik, re-encrypt vb.).",
    "Standart Kubernetes API'si ile uyumluluk; mevcut chart ve manifestlerin değiştirilmeden kullanılabilmesi.",
    "apiVersion: networking.k8s.io/v1\nkind: Ingress\nmetadata:\n  name: kampanya\nspec:\n  ingressClassName: openshift-default\n  rules:\n  - host: kampanya.apps.ocp-egitim.egitim.local\n    http:\n      paths:\n      - path: /\n        pathType: Prefix\n        backend:\n          service: { name: frontend, port: { number: 8080 } }",
    ["route", "service"]);

  h("networkpolicy", "NetworkPolicy", "Networking",
    "NetworkPolicy, Pod'lar arasındaki ve Pod'lara gelen/giden ağ trafiğine izin veren güvenlik duvarı kurallarıdır. Bir Pod'u seçen en az bir policy varsa, o Pod için yalnızca açıkça izin verilen trafik kabul edilir (beyaz liste).",
    "Projeleri birbirinden izole etmek, veritabanına yalnızca backend'in erişmesini sağlamak, 'sıfır güven' (zero trust) ağ modeli kurmak için kullanılır.",
    "Üretim ortamlarında, PCI-DSS gibi uyumluluk gerektiren projelerde ve çok kiracılı (multi-tenant) cluster'larda mutlaka kullanın. Router'dan gelen trafiğe (allow-from-openshift-ingress) ve izlemeye izin vermeyi unutmayın; aksi halde Route'lar çalışmaz.",
    "Ele geçirilen bir Pod'un diğer servislere yayılmasını (lateral movement) zorlaştırır. Kurallar label tabanlı olduğundan Pod IP'leri değişse de geçerli kalır.",
    "# Tüm gelen trafiği reddet (varsayılan red)\nkind: NetworkPolicy\nmetadata: { name: default-deny-all }\nspec:\n  podSelector: {}\n  policyTypes: [Ingress]\n---\n# Yalnızca backend -> postgresql:5432\nspec:\n  podSelector: { matchLabels: { app: postgresql } }\n  ingress:\n  - from:\n    - podSelector: { matchLabels: { app.kubernetes.io/component: backend } }\n    ports: [{ protocol: TCP, port: 5432 }]",
    ["pod-selector", "policy-types", "labels"]);

  h("udn", "UserDefinedNetwork (UDN)", "Networking",
    "UserDefinedNetwork, OVN-Kubernetes ağ eklentisinin sunduğu, bir namespace (veya ClusterUserDefinedNetwork ile birden fazla namespace) için varsayılan Pod ağından tamamen ayrı, özel bir ağ tanımlamayı sağlayan nesnedir. Layer2 veya Layer3 topolojisi seçilebilir.",
    "Kiracıları ağ seviyesinde tamamen izole etmek, örtüşen IP aralıkları kullanmak veya sanal makinelere (OpenShift Virtualization) geleneksel ağ benzeri ortam sunmak için kullanılır.",
    "NetworkPolicy ile yapılan mantıksal izolasyonun yetmediği, fiziksel ağ ayrımına yakın izolasyon gereken durumlarda kullanın. UDN, namespace oluşturulurken tanımlanmalıdır ('k8s.ovn.org/primary-user-defined-network' label'ı).",
    "Güçlü kiracı izolasyonu ve esnek IP adresleme sağlar.",
    "apiVersion: k8s.ovn.org/v1\nkind: UserDefinedNetwork\nmetadata:\n  name: odeme-agi\n  namespace: odeme-api\nspec:\n  topology: Layer2\n  layer2:\n    role: Primary\n    subnets: [\"10.200.0.0/16\"]",
    ["networkpolicy"]);

  h("endpoints", "Endpoints / EndpointSlice", "Networking",
    "EndpointSlice, bir Service'in selector'üyle eşleşen ve Ready durumundaki Pod'ların IP:port listesidir. Service controller tarafından otomatik güncellenir.",
    "Service'e gelen trafiğin hangi Pod'lara gideceğini belirler.",
    "Bir Service'e erişilemiyorsa ilk kontrol edilecek yerdir: Endpoint listesi boşsa selector yanlış veya Pod'lar Ready değildir.",
    "Sorun gidermeyi hızlandırır.",
    "oc get endpointslice -l kubernetes.io/service-name=katalog-api\noc describe svc katalog-api   # Endpoints: 10.131.0.24:8080,10.132.0.18:8080",
    ["service", "readiness-probe"]);

  /* =================== STORAGE =================== */
  h("pvc", "PersistentVolumeClaim (PVC)", "Storage",
    "PVC, bir uygulamanın belirli boyut ve erişim modunda kalıcı depolama 'talebidir'. Geliştirici yalnızca ne kadar alana ihtiyaç duyduğunu söyler; StorageClass'taki provisioner bu talebe uygun bir PersistentVolume'u (PV) otomatik oluşturur ve PVC'ye bağlar (Bound).",
    "Pod yeniden başlasa veya başka node'a taşınsa bile verinin korunması gereken uygulamalar (veritabanları, yüklenen dosyalar, kuyruklar) için kullanılır.",
    "Konteynerin dosya sistemi geçicidir; Pod silindiğinde içindeki veri kaybolur. Kalıcı olması gereken her veri için PVC oluşturup Pod'a volume olarak bağlayın. Paylaşımlı erişim gerekiyorsa ReadWriteMany destekleyen bir StorageClass (ör. CephFS) seçin.",
    "Depolama altyapısının detayları (vSphere, Ceph, NFS…) uygulamadan soyutlanır; aynı PVC tanımı farklı ortamlarda çalışır. StorageClass izin veriyorsa boyut sonradan büyütülebilir.",
    "apiVersion: v1\nkind: PersistentVolumeClaim\nmetadata:\n  name: urun-gorselleri\nspec:\n  accessModes: [ReadWriteMany]\n  storageClassName: ocs-storagecluster-cephfs\n  resources:\n    requests:\n      storage: 50Gi\n\n# Pod'a bağlama:\noc set volume deploy/frontend --add --name=gorseller \\\n  --claim-name=urun-gorselleri --mount-path=/data/gorseller",
    ["pv", "storageclass", "access-modes", "volumes"]);

  h("pv", "PersistentVolume (PV)", "Storage",
    "PV, cluster'daki gerçek bir depolama biriminin (vSphere diski, Ceph RBD imajı, NFS paylaşımı vb.) Kubernetes'teki temsilidir. Cluster seviyesinde (namespace'siz) bir kaynaktır ve bir PVC'ye bire bir bağlanır.",
    "Depolamanın yaşam döngüsünü uygulamadan bağımsız yönetmek için kullanılır.",
    "Dinamik provisioning kullanıyorsanız PV'leri elle oluşturmazsınız. Statik provisioning (ör. mevcut bir NFS paylaşımını sunmak) gerektiğinde yönetici PV'yi elle tanımlar.",
    "Reclaim policy ile PVC silindiğinde verinin silinmesi (Delete) veya korunması (Retain) kontrol edilir.",
    "oc get pv\nNAME          CAPACITY  ACCESS MODES  RECLAIM POLICY  STATUS  CLAIM\npvc-3f2a...   20Gi      RWO           Delete          Bound   eticaret-prod/data-postgresql-0",
    ["pvc", "reclaim-policy", "storageclass"]);

  h("storageclass", "StorageClass", "Storage",
    "StorageClass, sunulan depolama türlerini (sınıflarını) tanımlar: hangi provisioner'ın (CSI sürücüsü) kullanılacağı, parametreler (disk tipi, havuz), genişletme izni ve reclaim policy. Bir sınıf 'default' olarak işaretlenebilir.",
    "Yöneticilerin farklı performans ve maliyet seviyelerinde depolama sunması (ör. hızlı blok, paylaşımlı dosya, nesne depolama) için kullanılır.",
    "PVC oluştururken storageClassName ile ihtiyaca uygun sınıfı seçin. Belirtmezseniz default sınıf kullanılır. Bu cluster'da: thin-csi (vSphere, RWO), ceph-rbd (blok, RWO), cephfs (dosya, RWX), noobaa (nesne/S3).",
    "Dinamik provisioning sayesinde geliştiriciler yöneticiye bilet açmadan saniyeler içinde disk edinir.",
    "apiVersion: storage.k8s.io/v1\nkind: StorageClass\nmetadata:\n  name: ocs-storagecluster-ceph-rbd\nprovisioner: openshift-storage.rbd.csi.ceph.com\nreclaimPolicy: Delete\nallowVolumeExpansion: true\nvolumeBindingMode: Immediate",
    ["pvc", "pv", "volume-binding-mode", "provisioner"]);

  h("volumesnapshot", "VolumeSnapshot", "Storage",
    "VolumeSnapshot, bir PVC'nin belirli bir andaki anlık görüntüsüdür (snapshot). CSI sürücüsü destekliyorsa depolama sistemi seviyesinde hızlıca alınır.",
    "Yedekleme, güncelleme öncesi güvenli dönüş noktası oluşturma ve bir PVC'yi kopyalama (snapshot'tan yeni PVC oluşturma) için kullanılır.",
    "Veritabanı şema değişikliği gibi riskli işlemlerden önce snapshot alın. Tutarlı bir yedek için uygulamayı kısa süreliğine durdurmak veya veritabanını 'flush' etmek gerekebilir.",
    "Dakikalar yerine saniyeler içinde geri dönüş noktası oluşturur.",
    "apiVersion: snapshot.storage.k8s.io/v1\nkind: VolumeSnapshot\nmetadata:\n  name: postgresql-yedek-1\nspec:\n  volumeSnapshotClassName: ocs-storagecluster-rbdplugin-snapclass\n  source:\n    persistentVolumeClaimName: data-postgresql-0\n---\n# Snapshot'tan geri yükleme (yeni PVC):\nspec:\n  dataSource:\n    name: postgresql-yedek-1\n    kind: VolumeSnapshot\n    apiGroup: snapshot.storage.k8s.io",
    ["pvc", "volumesnapshotclass"]);
  h("volumesnapshotclass", "VolumeSnapshotClass", "Storage",
    "VolumeSnapshotClass, snapshot alınırken hangi CSI sürücüsünün ve hangi silme politikasının kullanılacağını tanımlar (StorageClass'ın snapshot karşılığı).",
    "Farklı depolama sistemleri için snapshot davranışını standartlaştırmak için kullanılır.",
    "Snapshot alacağınız PVC'nin sürücüsüyle eşleşen sınıfı seçin (ör. RBD PVC için rbdplugin-snapclass).",
    "Snapshot'ların otomatik ve tutarlı yönetimi.",
    "oc get volumesnapshotclass", ["volumesnapshot", "storageclass"]);
  h("obc", "ObjectBucketClaim (Object Storage)", "Storage",
    "ObjectBucketClaim, OpenShift Data Foundation (NooBaa) veya uyumlu bir sağlayıcıdan S3 uyumlu nesne depolama 'bucket'ı talep etmeyi sağlar. Bağlandığında aynı isimde bir ConfigMap (endpoint, bucket adı) ve Secret (erişim anahtarları) oluşturulur.",
    "Yedek dosyaları, görseller, loglar gibi büyük ve yapılandırılmamış verileri S3 API'si ile saklamak için kullanılır.",
    "Uygulamanız S3 API'sini kullanıyorsa ve dosya sistemi yerine nesne depolama uygunsa tercih edin.",
    "Geliştirici bucket'ı PVC gibi self-servis olarak edinir.",
    "apiVersion: objectbucket.io/v1alpha1\nkind: ObjectBucketClaim\nmetadata:\n  name: urun-yedekleri\nspec:\n  generateBucketName: urun-yedekleri\n  storageClassName: openshift-storage.noobaa.io",
    ["pvc", "storageclass"]);

  /* =================== BUILDS =================== */
  h("buildconfig", "BuildConfig", "Builds",
    "BuildConfig, kaynak koddan veya Dockerfile'dan konteyner imajı üretme sürecini tanımlayan OpenShift nesnesidir: kaynak (Git deposu), strateji (Source/S2I, Docker, Custom), çıktı (ImageStreamTag veya harici registry) ve tetikleyiciler (webhook, imaj değişikliği, yapılandırma değişikliği).",
    "Cluster içinde, harici bir CI aracına ihtiyaç duymadan imaj derlemek için kullanılır.",
    "Basit 'koddan imaja' ihtiyaçlarında BuildConfig yeterlidir. Test, tarama, onay gibi çok adımlı süreçler için OpenShift Pipelines (Tekton) veya yeni nesil 'Builds for OpenShift' (Shipwright) tercih edilebilir.",
    "Git'e her push'ta webhook ile otomatik build; S2I sayesinde Dockerfile yazmadan güvenli, root olmayan imajlar.",
    "oc new-build nodejs:22-ubi9~https://git.egitim.local/portal/portal-web.git --name=portal-web\noc start-build portal-web --follow\n\n# Webhook URL:\noc describe bc portal-web | grep -A1 Webhook",
    ["build", "s2i", "imagestream", "bc-strategy", "bc-triggers"]);
  h("build", "Build", "Builds",
    "Build, bir BuildConfig'in tek bir çalıştırılmasıdır (portal-web-1, portal-web-2 …). Bir build Pod'u içinde kaynak kod çekilir, derlenir ve sonuç imaj registry'ye gönderilir (push).",
    "Derleme geçmişini, sürelerini, loglarını ve başarısız olanların nedenini incelemek için kullanılır.",
    "Bir build 'Failed' olduğunda Logs sekmesinden hata mesajını inceleyin (bağımlılık hatası, test hatası, kimlik doğrulama sorunu vb.).",
    "Her imajın hangi Git commit'inden üretildiği izlenebilir.",
    "oc get builds\noc logs build/portal-web-7 -f\noc cancel-build portal-web-7",
    ["buildconfig", "build-phase"]);
  h("imagestream", "ImageStream", "Builds",
    "ImageStream, bir veya daha fazla konteyner imajına işaret eden etiketlerden (tag) oluşan OpenShift soyutlamasıdır. İmajın kendisini değil, imaj referanslarını (sha256 digest) saklar. Dahili registry'deki veya harici registry'deki imajları izleyebilir.",
    "Bir etiket yeni bir imaja işaret ettiğinde (ör. yeni build bittiğinde) Deployment/DeploymentConfig'leri ve BuildConfig'leri otomatik tetiklemek için kullanılır.",
    "S2I build'leri, imaj güncellemesine bağlı otomatik dağıtım ve imajların ortamlar arasında 'tag' ile terfi ettirilmesi (dev → test → prod) senaryolarında kullanın.",
    "İmaj güncelleme olaylarına tepki veren otomasyon; harici registry'yi periyodik içe aktarma (scheduled import); digest ile sabitlenmiş güvenli referanslar.",
    "oc tag eticaret-test/frontend:2.5.0 eticaret-prod/frontend:latest\noc import-image ubi9 --from=registry.access.redhat.com/ubi9/ubi --confirm --scheduled",
    ["buildconfig", "deploymentconfig", "image"]);
  h("s2i", "Source-to-Image (S2I)", "Builds",
    "S2I, uygulamanın kaynak kodunu bir 'builder image' (ör. nodejs:22-ubi9) ile birleştirerek Dockerfile yazmadan çalıştırılabilir bir imaj üreten OpenShift derleme yöntemidir. Builder imajı dile özgü derleme betiklerini (assemble, run) içerir.",
    "Geliştiricilerin yalnızca kodlarına odaklanmasını, imaj güvenliği ve standartlarının platform ekibince yönetilmesini sağlar.",
    "Standart dillerde (Node.js, Java, Python, .NET, Go, PHP) yazılmış uygulamalar için idealdir. Özel bağımlılıklar gerekiyorsa Docker stratejisi seçilebilir.",
    "Tutarlı, root olmayan, Red Hat tarafından güncellenen temel imajlar; builder imajı güncellendiğinde uygulama otomatik yeniden derlenebilir.",
    "oc new-app python:3.12-ubi9~https://github.com/ornek/flask-app.git",
    ["buildconfig", "imagestream"]);

  /* =================== PIPELINES =================== */
  h("pipeline", "Pipeline (Tekton)", "Pipelines",
    "Pipeline, OpenShift Pipelines (Tekton) ile tanımlanan, sıralı veya paralel çalışan Task'lardan oluşan CI/CD iş akışıdır. Her Task ayrı bir Pod içinde konteyner adımları (steps) olarak çalışır.",
    "Kodu çekme, test etme, imaj derleme, güvenlik taraması ve dağıtım adımlarını otomatikleştirmek için kullanılır.",
    "Birden fazla adımlı, onay ve parametre içeren CI/CD süreçleri gerektiğinde kullanın. Jenkins gibi merkezi bir sunucu gerektirmez; her çalıştırma izole Pod'larda gerçekleşir.",
    "Kubernetes-yerel, ölçeklenebilir ve YAML olarak sürüm kontrolünde tutulabilen pipeline'lar. Pipelines as Code ile Git deposundaki .tekton klasöründen tetiklenebilir.",
    "apiVersion: tekton.dev/v1\nkind: Pipeline\nmetadata: { name: portal-web-build-deploy }\nspec:\n  params: [{ name: GIT_REPO, type: string }]\n  workspaces: [{ name: workspace }]\n  tasks:\n  - name: fetch-repository\n    taskRef: { resolver: cluster, params: [{ name: name, value: git-clone }] }\n  - name: build\n    runAfter: [fetch-repository]\n    taskRef: { name: buildah }\n\ntkn pipeline start portal-web-build-deploy -w name=workspace,volumeClaimTemplateFile=pvc.yaml",
    ["pipelinerun", "task", "workspace"]);
  h("pipelinerun", "PipelineRun", "Pipelines",
    "PipelineRun, bir Pipeline'ın belirli parametre ve workspace değerleriyle tek bir çalıştırılmasıdır. Her Task için bir TaskRun ve Pod oluşur.",
    "Pipeline çalıştırmalarının geçmişini, sürelerini ve hangi adımda başarısız olduğunu görmek için kullanılır.",
    "Başarısız bir PipelineRun'da ilgili TaskRun loglarını inceleyin; 'Rerun' ile aynı parametrelerle tekrar çalıştırılabilir.",
    "Tam izlenebilirlik: hangi commit, hangi parametre, hangi sonuç.",
    "tkn pipelinerun list\ntkn pipelinerun logs portal-web-build-deploy-x7k2p -f",
    ["pipeline", "task"]);
  h("task", "Task", "Pipelines",
    "Task, bir Pipeline içindeki yeniden kullanılabilir iş birimidir; sırayla çalışan adımlardan (steps) oluşur. OpenShift Pipelines, git-clone, buildah, s2i-*, openshift-client gibi hazır Task'larla gelir (cluster resolver ile erişilir).",
    "Ortak CI adımlarını bir kez tanımlayıp birçok pipeline'da kullanmak için.",
    "Kendi özel adımlarınız (ör. npm test) için proje içinde Task tanımlayın; genel işler için hazır Task'ları tercih edin.",
    "Tekrar kullanılabilirlik ve standartlaşma.",
    "apiVersion: tekton.dev/v1\nkind: Task\nmetadata: { name: npm-test }\nspec:\n  workspaces: [{ name: source }]\n  steps:\n  - name: test\n    image: registry.access.redhat.com/ubi9/nodejs-22\n    script: |\n      npm ci && npm test",
    ["pipeline"]);

  /* =================== COMPUTE =================== */
  h("node", "Node", "Compute",
    "Node, cluster'daki bir sanal veya fiziksel sunucudur. Üzerinde kubelet (Pod'ları çalıştıran ajan), CRI-O (konteyner çalışma zamanı) ve OVN-Kubernetes ağ bileşenleri bulunur. OpenShift node'ları Red Hat Enterprise Linux CoreOS (RHCOS) işletim sistemi ile çalışır.",
    "Control plane (master) node'ları API sunucusu, etcd ve scheduler'ı; worker node'ları uygulama Pod'larını; infra node'ları router, registry ve izleme gibi altyapı bileşenlerini çalıştırır.",
    "Kapasite planlaması, bakım (cordon/drain), sorunlu node tespiti ve kaynak kullanımını izlemek için Node sayfasını kullanın.",
    "Scheduler, Pod'ları node'ların boş kaynaklarına, label'larına ve taint'lerine göre en uygun yere yerleştirir.",
    "oc get nodes -o wide\noc adm top nodes\noc adm cordon worker-3.ocp-egitim.egitim.local     # yeni Pod alma\noc adm drain worker-3... --ignore-daemonsets --delete-emptydir-data\noc adm uncordon worker-3...",
    ["taints", "node-roles", "machine", "mcp", "node-drain"]);
  h("machine", "Machine", "Compute",
    "Machine, Machine API tarafından yönetilen ve altyapı sağlayıcısındaki (bu cluster'da VMware vSphere) bir sanal makineyi temsil eden nesnedir. Machine oluşturulduğunda VM yaratılır, RHCOS kurulur ve Node olarak cluster'a katılır.",
    "Node'ların altyapı seviyesinde yaşam döngüsünü (oluşturma, silme, yeniden oluşturma) yönetmek için kullanılır.",
    "Node sayısını değiştirmek için Machine'leri tek tek değil, MachineSet'in replica sayısını değiştirerek yönetin.",
    "Altyapı otomasyonu: bozuk node'lar MachineHealthCheck ile otomatik yenilenir.",
    "oc get machines -n openshift-machine-api", ["machineset", "node", "mhc"]);
  h("machineset", "MachineSet", "Compute",
    "MachineSet, belirli bir şablondan (CPU, bellek, disk, ağ) istenen sayıda Machine oluşturan nesnedir — node'lar için bir ReplicaSet gibi düşünülebilir.",
    "Worker veya infra node havuzlarını ölçeklemek için kullanılır.",
    "Kapasite yetmediğinde replica sayısını artırın; otomatik ölçekleme için MachineAutoscaler ve ClusterAutoscaler tanımlayın.",
    "Yeni node eklemek tek komuta iner.",
    "oc scale machineset ocp-egitim-x7k2p-worker-dc1 --replicas=3 -n openshift-machine-api", ["machine", "machineautoscaler"]);
  h("machineautoscaler", "MachineAutoscaler", "Compute",
    "MachineAutoscaler, bir MachineSet için asgari ve azami replica sınırlarını belirler. ClusterAutoscaler, kaynak yetersizliğinden zamanlanamayan (Pending) Pod'lar gördüğünde bu sınırlar içinde yeni node ekler; boş kalan node'ları kaldırır.",
    "Cluster kapasitesini iş yüküne göre otomatik ayarlamak için.",
    "Değişken yük altında ve bulut/sanallaştırma ortamlarında kullanın. Önce cluster genelinde bir ClusterAutoscaler kaynağı oluşturulmalıdır.",
    "Maliyet ve kapasite dengesi otomatik sağlanır.",
    "spec:\n  minReplicas: 2\n  maxReplicas: 4\n  scaleTargetRef:\n    kind: MachineSet\n    name: ocp-egitim-x7k2p-worker-dc1", ["machineset", "hpa"]);
  h("mhc", "MachineHealthCheck", "Compute",
    "MachineHealthCheck, seçilen Machine'lerin node durumunu izler; node belirtilen süre boyunca NotReady/Unknown kalırsa Machine'i silip yerine yenisini oluşturur (remediation).",
    "Bozulan worker node'ların insan müdahalesi olmadan yenilenmesi için.",
    "Machine API ile yönetilen worker havuzlarında kullanın. maxUnhealthy ile aynı anda en fazla kaç makinenin yenileneceği sınırlanır (ağ kesintisinde toplu silmeyi önler).",
    "Kendi kendini onaran altyapı.",
    "unhealthyConditions:\n- type: Ready\n  status: \"False\"\n  timeout: 300s\nmaxUnhealthy: 40%", ["machine", "node"]);
  h("machineconfig", "MachineConfig", "Compute",
    "MachineConfig, RHCOS node'larının işletim sistemi yapılandırmasını (dosyalar, systemd servisleri, kernel argümanları, SSH anahtarları) Ignition formatında tanımlayan nesnedir. Machine Config Operator (MCO) bu tanımları node'lara uygular.",
    "Node'lara NTP (chrony) ayarı, sertifika, kernel parametresi gibi işletim sistemi düzeyinde değişiklik yapmak için kullanılır.",
    "Node'lara asla SSH ile elle değişiklik yapmayın; her değişikliği MachineConfig ile yapın. Uygulandığında node'lar sırayla drain edilip yeniden başlatılabilir.",
    "Tüm node'larda tutarlı, sürümlenmiş ve geri alınabilir işletim sistemi yapılandırması.",
    "apiVersion: machineconfiguration.openshift.io/v1\nkind: MachineConfig\nmetadata:\n  name: 99-worker-chrony-ntp\n  labels: { machineconfiguration.openshift.io/role: worker }\nspec:\n  config:\n    ignition: { version: 3.4.0 }\n    storage:\n      files:\n      - path: /etc/chrony.conf\n        mode: 420\n        contents: { source: data:text/plain;base64,... }",
    ["mcp", "node"]);
  h("mcp", "MachineConfigPool", "Compute",
    "MachineConfigPool, node'ları gruplar (master, worker veya özel havuzlar) ve o gruba ait MachineConfig'leri birleştirerek 'rendered' tek bir yapılandırma üretir. Güncelleme sırasında kaç node'un aynı anda güncelleneceğini (maxUnavailable) belirler.",
    "Node gruplarının yapılandırma güncelleme durumunu izlemek ve kontrol etmek için.",
    "Bir MachineConfig değişikliğinden sonra Updated/Updating/Degraded durumlarını buradan izleyin. Bakım penceresi dışında güncellemeyi durdurmak için havuzu 'paused' yapabilirsiniz.",
    "Kontrollü ve kademeli işletim sistemi güncellemeleri.",
    "oc get mcp\nNAME     UPDATED  UPDATING  DEGRADED  MACHINECOUNT  READYMACHINECOUNT\nmaster   True     False     False     3             3\nworker   True     False     False     5             5",
    ["machineconfig", "node"]);

  /* =================== USER MANAGEMENT =================== */
  h("user", "User", "User Management",
    "User, OpenShift'e kimlik sağlayıcı (identity provider: LDAP, htpasswd, OIDC/Keycloak, GitHub vb.) üzerinden ilk kez giriş yapan bir kişi için otomatik oluşturulan nesnedir. Kimlik bilgisi (parola) OpenShift'te saklanmaz; doğrulama kimlik sağlayıcıda yapılır.",
    "Kimin cluster'a eriştiğini görmek ve kullanıcılara rol atamak için.",
    "Kullanıcılara doğrudan değil, mümkünse Group üzerinden yetki verin. 'kubeadmin' geçici yöneticisini, kalıcı bir kimlik sağlayıcı ve cluster-admin kullanıcı yapılandırdıktan sonra silin.",
    "Merkezi kimlik yönetimi (LDAP/AD) ile entegrasyon; tek oturum açma (SSO).",
    "oc get users\noc whoami\noc adm policy add-role-to-user edit ayse.yilmaz -n eticaret-prod",
    ["group", "rolebinding", "role"]);
  h("group", "Group", "User Management",
    "Group, kullanıcıları bir arada toplayan nesnedir. Gruplar elle oluşturulabilir veya LDAP/AD ile senkronize edilebilir (oc adm groups sync).",
    "Yetkileri tek tek kullanıcılar yerine ekiplere vermek için kullanılır.",
    "Ekip bazlı yetkilendirmede her zaman Group kullanın; çalışan ekipten ayrıldığında yalnızca gruptan çıkarılması yeterlidir.",
    "Yönetimi kolay, denetlenebilir yetki yapısı.",
    "oc adm groups new eticaret-gelistiriciler ayse.yilmaz ali.vural\noc adm policy add-role-to-group edit eticaret-gelistiriciler -n eticaret-prod",
    ["user", "rolebinding"]);
  h("serviceaccount", "ServiceAccount", "User Management",
    "ServiceAccount, insanlar için değil, Pod içinde çalışan uygulamalar ve otomasyon araçları için bir kimliktir. Her projede builder, default ve deployer adlı ServiceAccount'lar otomatik oluşturulur. Pod'a, kısa ömürlü ve otomatik yenilenen bir token projected volume ile bağlanır.",
    "Uygulamaların Kubernetes API'sine erişmesi, imaj çekmek için registry kimlik bilgisi kullanması ve SCC (güvenlik kısıtlaması) atanması için kullanılır.",
    "Her uygulama için ayrı bir ServiceAccount oluşturup yalnızca gereken yetkileri verin (en az yetki ilkesi). Varsayılan 'default' hesaba yetki eklemekten kaçının.",
    "Uygulama kimliklerinin insan kimliklerinden ayrılması, ince taneli yetkilendirme.",
    "oc create sa odeme-gateway\noc set sa deploy/odeme-gateway odeme-gateway\noc adm policy add-role-to-user view -z odeme-gateway",
    ["role", "rolebinding", "scc"]);
  h("role", "Role / ClusterRole", "User Management",
    "Role, bir namespace içindeki kaynaklar üzerinde hangi işlemlere (verbs: get, list, watch, create, update, patch, delete) izin verildiğini tanımlayan kural listesidir. ClusterRole aynı şeyi cluster genelinde tanımlar ve namespace'lerde de yeniden kullanılabilir. Yerleşik roller: cluster-admin, admin, edit, view, basic-user, self-provisioner.",
    "Rol tabanlı erişim kontrolü (RBAC) ile kimin neyi yapabileceğini belirlemek için kullanılır.",
    "Çoğu ihtiyaç yerleşik admin/edit/view rolleriyle karşılanır. Özel ihtiyaçlarda (ör. yalnızca Pod loglarını okuma) en az yetki ilkesine uygun özel Role yazın.",
    "Ayrıntılı ve denetlenebilir yetkilendirme; yanlışlıkla silme gibi riskleri azaltır.",
    "apiVersion: rbac.authorization.k8s.io/v1\nkind: Role\nmetadata: { name: pod-okuyucu, namespace: eticaret-prod }\nrules:\n- apiGroups: [\"\"]\n  resources: [pods, pods/log]\n  verbs: [get, list, watch]\n\noc auth can-i delete pods -n eticaret-prod --as=ali.vural",
    ["rolebinding", "user", "group", "rbac-verbs"]);
  h("rolebinding", "RoleBinding / ClusterRoleBinding", "User Management",
    "RoleBinding, bir Role veya ClusterRole'ü belirli öznelere (User, Group, ServiceAccount) bir namespace içinde bağlar. ClusterRoleBinding ise yetkiyi cluster genelinde verir.",
    "Kullanıcıya veya ekibe bir projede yetki vermek için kullanılır. Proje oluşturan kişiye otomatik olarak 'admin' RoleBinding'i verilir.",
    "Proje bazlı yetkilerde RoleBinding kullanın. ClusterRoleBinding'i (özellikle cluster-admin) yalnızca platform yöneticilerine verin.",
    "Yetkiler kapsamla sınırlı kalır; bir projedeki admin başka projeye erişemez.",
    "oc adm policy add-role-to-group edit eticaret-gelistiriciler -n eticaret-prod\noc get rolebindings -n eticaret-prod\noc adm policy who-can delete deployments -n eticaret-prod",
    ["role", "user", "group"]);
  h("scc", "SecurityContextConstraints (SCC)", "Güvenlik",
    "SCC, OpenShift'e özgü güvenlik politikasıdır; Pod'ların hangi kullanıcı kimliğiyle (UID) çalışabileceğini, ayrıcalıklı (privileged) mod, host ağı/dosya sistemi erişimi, Linux yetenekleri (capabilities) ve volume türleri gibi konuları kontrol eder. Varsayılan 'restricted-v2' SCC, konteynerleri projeye atanmış rastgele, root olmayan bir UID ile ve tüm capability'ler düşürülmüş olarak çalıştırır.",
    "Konteynerlerin node'a veya diğer iş yüklerine zarar vermesini önlemek için kullanılır.",
    "İmajınız root olarak çalışmayı zorunlu tutuyorsa önce imajı düzeltmeyi tercih edin. Kaçınılmazsa ayrı bir ServiceAccount'a 'anyuid' gibi daha geniş bir SCC verin; asla default hesaba privileged vermeyin.",
    "Konteyner kaçışı (container escape) gibi saldırıların etkisini en aza indirir. Pod'a hangi SCC'nin uygulandığı 'openshift.io/scc' annotation'ında görünür.",
    "oc get scc\noc adm policy add-scc-to-user anyuid -z legacy-app -n demo\noc get pod <pod> -o jsonpath='{.metadata.annotations.openshift\\.io/scc}'",
    ["serviceaccount", "pod-security"]);

  /* =================== ADMINISTRATION =================== */
  h("project", "Project (Proje)", "Home",
    "Project, OpenShift'te bir Kubernetes Namespace'inin ek bilgilerle (görünen ad, açıklama, talep eden kişi) zenginleştirilmiş halidir. Kaynakları, yetkileri, kotaları ve ağ politikalarını birbirinden izole eden mantıksal çalışma alanıdır.",
    "Ekipleri, uygulamaları veya ortamları (dev, test, prod) birbirinden ayırmak için kullanılır.",
    "Her uygulama/ortam kombinasyonu için ayrı proje oluşturun (ör. eticaret-test, eticaret-prod). Normal kullanıcılar self-provisioner rolüyle kendi projelerini oluşturabilir; yönetici bu yetkiyi kaldırabilir veya proje şablonu (project template) ile varsayılan kota/limit ekleyebilir.",
    "İsim çakışmalarını önler, ResourceQuota ve NetworkPolicy ile kaynak ve ağ izolasyonu sağlar, oluşturana otomatik admin yetkisi verir.",
    "oc new-project eticaret-test --display-name=\"E-Ticaret (Test)\" --description=\"Test ortamı\"\noc projects\noc project eticaret-prod",
    ["namespace", "resourcequota", "rolebinding", "ui-project-selector"]);
  h("namespace", "Namespace", "Administration",
    "Namespace, Kubernetes kaynaklarını mantıksal olarak gruplandıran ad alanıdır. Aynı isimdeki kaynaklar farklı namespace'lerde bulunabilir. OpenShift'te her Project bir Namespace'e karşılık gelir. 'openshift-' ve 'kube-' ile başlayanlar platformun sistem namespace'leridir.",
    "Kaynak izolasyonu, yetkilendirme kapsamı ve kota uygulama sınırı olarak kullanılır.",
    "Yöneticiler tüm namespace'leri buradan görür. Sistem namespace'lerinde (openshift-*) değişiklik yapmaktan kaçının; bunlar Operator'ler tarafından yönetilir.",
    "Pod Security Admission label'ları (pod-security.kubernetes.io/*) namespace seviyesinde güvenlik standardı uygular.",
    "oc get ns\noc label ns eticaret-prod ortam=prod",
    ["project", "pod-security"]);
  h("resourcequota", "ResourceQuota", "Administration",
    "ResourceQuota, bir namespace'in toplamda tüketebileceği kaynakları sınırlar: CPU/bellek request ve limit toplamı, Pod sayısı, PVC sayısı ve toplam depolama, Service/Secret sayısı vb.",
    "Bir projenin cluster kaynaklarını tek başına tüketmesini önlemek ve ekiplere adil kapasite dağıtmak için kullanılır.",
    "Paylaşımlı cluster'larda her ekip projesine kota tanımlayın. CPU/bellek kotası varsa tüm konteynerlerde request/limit tanımlı olmalıdır; bunun için LimitRange ile varsayılan değer verin.",
    "Kapasite planlaması ve 'gürültülü komşu' (noisy neighbor) sorununun önlenmesi. Kota aşılırsa yeni Pod oluşturma isteği 'exceeded quota' hatasıyla reddedilir.",
    "apiVersion: v1\nkind: ResourceQuota\nmetadata: { name: compute-quota }\nspec:\n  hard:\n    requests.cpu: \"8\"\n    requests.memory: 16Gi\n    limits.cpu: \"16\"\n    limits.memory: 32Gi\n    pods: \"50\"\n\noc describe quota -n eticaret-prod",
    ["limitrange", "requests-limits", "project"]);
  h("limitrange", "LimitRange", "Administration",
    "LimitRange, bir namespace içindeki tekil konteyner, Pod veya PVC için asgari/azami kaynak değerlerini ve request/limit belirtilmemiş konteynerlere uygulanacak varsayılan değerleri tanımlar.",
    "Geliştiricilerin kaynak tanımını unuttuğu konteynerlere makul varsayılanlar atamak ve aşırı büyük konteynerleri engellemek için.",
    "ResourceQuota ile birlikte kullanın. Örneğin default request 100m CPU / 256Mi bellek, azami 2 CPU / 4Gi.",
    "Tutarlı kaynak kullanımı ve öngörülebilir zamanlama.",
    "spec:\n  limits:\n  - type: Container\n    default:        { cpu: 500m, memory: 512Mi }   # limit\n    defaultRequest: { cpu: 100m, memory: 256Mi }   # request\n    max:            { cpu: \"2\", memory: 4Gi }",
    ["resourcequota", "requests-limits"]);
  h("crd", "CustomResourceDefinition (CRD)", "Administration",
    "CRD, Kubernetes API'sine yeni bir kaynak türü ekler. Örneğin Tekton 'Pipeline', Strimzi 'Kafka', Argo CD 'Application' türleri birer CRD'dir. CRD tanımlandıktan sonra bu türden nesneler (Custom Resource) diğer Kubernetes nesneleri gibi oluşturulup yönetilir.",
    "Operator'lerin ve platform eklentilerinin kendi kavramlarını Kubernetes'e eklemesi için kullanılır.",
    "Genellikle CRD'leri Operator'ler kurar. Yöneticiler hangi API'lerin mevcut olduğunu ve sürümlerini incelemek için bu listeyi kullanır. Bir CRD'yi silmek o türdeki TÜM nesneleri siler; çok dikkatli olun.",
    "Kubernetes'i genişletilebilir bir platforma dönüştürür; kubectl/oc, RBAC ve konsol özel türleri de otomatik destekler.",
    "oc get crd | grep tekton\noc explain pipeline.spec\noc api-resources --api-group=kafka.strimzi.io",
    ["operator", "api-explorer"]);
  h("operator", "Operator / Installed Operators", "Ecosystem",
    "Operator, bir uygulamayı kurma, yapılandırma, güncelleme, yedekleme ve hata durumunda onarma bilgisini yazılıma dönüştüren bir Kubernetes controller'ıdır ('operasyon uzmanının kodlanmış hali'). Operator Lifecycle Manager (OLM), Operator'lerin kurulumunu ve güncellemesini ClusterServiceVersion (CSV), Subscription ve InstallPlan nesneleriyle yönetir.",
    "Veritabanı, mesajlaşma, depolama, CI/CD, güvenlik gibi karmaşık yazılımları birkaç satır YAML ile işletmek için kullanılır.",
    "Karmaşık ve gün-2 operasyonu (yedek, ölçekleme, güncelleme) gerektiren yazılımlar için Operator tercih edin. Software Catalog'dan (eski OperatorHub) kurulur; tüm namespace'lerde veya yalnızca seçilen namespace'te çalışacak şekilde ayarlanabilir.",
    "Uzman bilgisi otomasyona dönüşür; güncellemeler kanal (channel) bazlı ve otomatik/manuel onaylı yapılabilir.",
    "# Kafka Operator kurulduktan sonra bir Kafka cluster'ı:\napiVersion: kafka.strimzi.io/v1beta2\nkind: Kafka\nmetadata: { name: analitik-kafka }\nspec:\n  kafka: { replicas: 3, ... }\n\noc get csv -n openshift-operators\noc get subscription -A",
    ["crd", "subscription", "install-mode", "software-catalog"]);
  h("subscription", "Subscription", "Ecosystem",
    "Subscription, bir Operator'ün hangi katalogdan (ör. redhat-operators), hangi kanaldan (channel) kurulup takip edileceğini ve güncellemelerin otomatik mi yoksa manuel onayla mı uygulanacağını belirtir.",
    "Operator güncelleme politikasını yönetmek için kullanılır.",
    "Üretimde kritik Operator'ler için installPlanApproval: Manual seçip güncellemeleri bakım penceresinde onaylamak iyi bir uygulamadır.",
    "Kontrollü Operator güncellemeleri.",
    "spec:\n  channel: latest\n  name: openshift-pipelines-operator-rh\n  source: redhat-operators\n  sourceNamespace: openshift-marketplace\n  installPlanApproval: Automatic",
    ["operator"]);
  h("workspace", "Workspace (Tekton)", "Pipelines",
    "Workspace, bir Pipeline'daki Task'ların dosya paylaştığı ortak depolama alanıdır. Çalıştırma anında bir PVC, volumeClaimTemplate (her çalıştırmaya özel geçici PVC), ConfigMap, Secret veya emptyDir ile karşılanır.",
    "git-clone Task'ının çektiği kaynak kodun build ve test Task'larına aktarılması için kullanılır.",
    "Task'lar arasında veri taşıması gereken her pipeline'da tanımlayın. Paralel çalışan Task'lar aynı RWO PVC'yi farklı node'larda kullanamayabilir; gerekirse RWX depolama veya affinity assistant kullanın.",
    "Her çalıştırma izole ve tekrarlanabilir olur; volumeClaimTemplate ile çalıştırma bitince alan temizlenebilir.",
    "workspaces:\n- name: workspace\n  volumeClaimTemplate:\n    spec:\n      accessModes: [ReadWriteOnce]\n      resources: { requests: { storage: 1Gi } }",
    ["pipeline", "pvc"]);
  h("event", "Event", "Home",
    "Event, cluster'da gerçekleşen önemli olayların kaydıdır: Pod'un bir node'a yerleştirilmesi (Scheduled), imaj çekilmesi (Pulled), konteynerin başlaması (Started), probe hataları (Unhealthy), zamanlanamama (FailedScheduling), ölçekleme (ScalingReplicaSet) vb. Her event'in türü (Normal/Warning), nedeni (reason), mesajı, kaynağı ve tekrar sayısı vardır.",
    "Bir şeyin neden çalışmadığını anlamak için ilk bakılacak yerdir.",
    "Pod Pending, CrashLoopBackOff veya ImagePullBackOff durumundaysa önce Events'e bakın. Event'ler varsayılan olarak yaklaşık 1-3 saat saklanır; kalıcı kayıt için log/izleme çözümleri kullanılmalıdır.",
    "Sorun giderme süresini ciddi ölçüde kısaltır. Konsoldaki Events sayfası olayları canlı akış (streaming) olarak gösterir.",
    "oc get events --sort-by=.lastTimestamp\noc get events --field-selector type=Warning -n eticaret-test\noc describe pod <pod-adi>   # en altta Events bölümü",
    ["pod-status", "event-type"]);
  h("controllerrevision", "ControllerRevision", "Workloads",
    "ControllerRevision, StatefulSet ve DaemonSet'in Pod şablonunun geçmiş sürümlerini saklayan nesnedir (Deployment'taki eski ReplicaSet'lerin karşılığı).",
    "StatefulSet/DaemonSet rollback işlemleri için kullanılır.",
    "Doğrudan düzenlenmez; 'oc rollout history sts/<ad>' ile incelenir.",
    "Durumlu uygulamalarda da sürüm geçmişi ve geri dönüş.",
    "oc rollout history statefulset/postgresql\noc rollout undo statefulset/postgresql --to-revision=1", ["statefulset", "daemonset"]);
  h("helm", "Helm", "Helm",
    "Helm, Kubernetes uygulamaları için bir paket yöneticisidir. 'Chart' adı verilen paketler, şablonlaştırılmış Kubernetes manifestleri ve yapılandırılabilir değerler (values.yaml) içerir. Kurulan her chart bir 'Release' olur ve her güncelleme yeni bir 'Revision' oluşturur.",
    "Karmaşık uygulamaları tek komutla kurmak, sürümlemek, güncellemek ve geri almak için kullanılır.",
    "Topluluk veya şirket içi chart'larla standart kurulumlar yaparken kullanın. OpenShift konsolu Helm release'lerini doğrudan yönetebilir; chart depoları HelmChartRepository (cluster) veya ProjectHelmChartRepository (proje) ile eklenir.",
    "Tekrarlanabilir kurulumlar ve kolay geri alma (rollback).",
    "helm repo add sirket https://charts.egitim.local/stable\nhelm install redis-test sirket/redis-persistent -n eticaret-test --set persistence.size=2Gi\nhelm history redis-test -n eticaret-test\nhelm rollback redis-test 1 -n eticaret-test",
    ["helm-repo", "helm-release"]);
  h("helm-repo", "Helm Repositories", "Helm",
    "Konsolun Helm chart'larını listelediği depolardır. HelmChartRepository cluster genelinde, ProjectHelmChartRepository ise yalnızca ilgili projede görünür.",
    "Şirket içi onaylı chart'ları geliştiricilere self-servis sunmak için.",
    "Kurumsal chart deponuzu (Artifactory, Nexus, ChartMuseum) buradan ekleyin; gerekiyorsa TLS ve kimlik bilgisi tanımlayın.",
    "Chart'lar Software Catalog'da otomatik görünür.",
    "apiVersion: helm.openshift.io/v1beta1\nkind: ProjectHelmChartRepository\nmetadata: { name: sirket-ici-chartlar }\nspec:\n  connectionConfig:\n    url: https://charts.egitim.local/stable", ["helm"]);
  h("helm-release", "Helm Releases", "Helm",
    "Release, bir Helm chart'ının belirli bir namespace'e kurulmuş örneğidir. Revision numarası her upgrade/rollback'te artar. Release bilgisi namespace içinde 'sh.helm.release.v1.<ad>.v<rev>' adlı Secret'larda saklanır.",
    "Kurulu Helm uygulamalarının sürümünü, durumunu (deployed, failed, pending-upgrade) ve kaynaklarını görmek için.",
    "Başarısız (failed) bir release'te önce Events ve Pod durumlarını inceleyin, sonra önceki revizyona dönün.",
    "Kurulum geçmişi ve hızlı geri dönüş.",
    "helm list -A\nhelm upgrade nginx-kampanya sirket/nginx -n eticaret-prod -f values-prod.yaml", ["helm"]);
})();
