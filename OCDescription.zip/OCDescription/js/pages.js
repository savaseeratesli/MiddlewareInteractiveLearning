/* OpenShift Eğitim Konsolu – özel sayfalar */
(function () {
  "use strict";
  const OC = window.OC, U = OC.u, H = OC.H, K = OC.K, R = OC.r, db = OC.db;
  const { $, $$, esc } = U;
  const P = (OC.P = {});
  OC.T = OC.T || {};
  const head = (...a) => OC.pageHead(...a);
  const card = (title, body, help, extra, cls) => `<div class="card ${cls || ""}"><div class="card-h"><h3>${esc(title)}${R.q(help)}</h3>${extra || ""}</div><div class="card-b">${body}</div></div>`;
  const allPods = () => db.Pod;

  /* =================== OVERVIEW (Cluster dashboard) =================== */
  P.dashboard = function () {
    const cl = OC.cluster;
    const firing = OC.alerts.filter((a) => a.state === "firing" && a.severity !== "none");
    const cpuUsed = db.Node.reduce((a, n) => a + n._m.cpu, 0), cpuTot = db.Node.reduce((a, n) => a + n._cpu, 0);
    const memUsed = db.Node.reduce((a, n) => a + n._m.mem, 0) / 1024, memTot = db.Node.reduce((a, n) => a + n._mem, 0);
    const fsUsed = db.Node.reduce((a, n) => a + n._m.fs, 0);
    const util = (t, val, tot, unit, series, help, req) => `<div class="util-r"><div class="util-l"><b>${esc(t)}</b>${R.q(help)}<div class="util-v">${val}</div><div class="muted sm">${tot ? "of " + tot + " " + unit : ""}</div>${req ? `<div class="muted sm">${req}</div>` : ""}</div><div class="util-c">${U.spark(series, { h: 64, grid: true })}</div></div>`;
    const inv = [["Node", db.Node.length, "Nodes", "#/k8s/cluster/nodes"], ["Pod", db.Pod.length, "Pods", "#/k8s/all/pods"], ["StorageClass", db.StorageClass.length, "StorageClasses", "#/k8s/cluster/storageclasses"], ["PersistentVolumeClaim", db.PersistentVolumeClaim.length, "PersistentVolumeClaims", "#/k8s/all/persistentvolumeclaims"]];
    const podIssues = db.Pod.filter((p) => ["Running", "Completed"].indexOf(OC.podStatus(p)) < 0);
    $("#page").innerHTML = head("Overview", "overview", { desc: "Cluster" }) + `<div class="page-body dash">
      <div class="dash-col">
        ${card("Details", R.dl([["Cluster API address", `<span class="mono sm">${esc(cl.api)}</span>`, "api-url"], ["Cluster ID", `<span class="mono sm">${esc(cl.id)}</span>`, "cluster-id"], ["Infrastructure provider", cl.provider, "infra-provider"], ["OpenShift version", `${cl.version} ${R.q("cluster-version")}<div class="upd"><a href="#/settings/cluster">${U.ico("up", 11)} Update available: ${cl.updates[1]}</a></div>`], ["Service Level Agreement (SLA)", "Self-support, 60 day trial"], ["Update channel", cl.channel, "update-channel"], ["Control plane high availability", "Yes (3 control plane nodes)"]]), "overview", '<a class="card-l" href="#/settings/cluster">View settings</a>')}
        ${card("Cluster inventory", inv.map(([k, n, l, h]) => `<a class="inv" href="${h}">${R.badge(k)}<span>${n} ${l}</span>${k === "Pod" && podIssues.length ? `<span class="inv-w">${U.ico("err", 12)} ${podIssues.filter((p) => /CrashLoop|Error|Failed|ImagePull/.test(OC.podStatus(p))).length} ${U.ico("pend", 12, "st-pend")} ${podIssues.filter((p) => /Pending|ContainerCreating/.test(OC.podStatus(p))).length}</span>` : ""}${k === "PersistentVolumeClaim" ? `<span class="inv-w">${U.ico("pend", 12, "st-pend")} ${db.PersistentVolumeClaim.filter((p) => p.status.phase === "Pending").length}</span>` : ""}</a>`).join(""), "nav-workloads")}
      </div>
      <div class="dash-col dash-main">
        ${card("Status", `<div class="hs">${[["Cluster", "ok", "cluster-version"], ["Control Plane", "ok", "node-roles"], ["Operators", "ok", "cluster-operators"], ["Dynamic Plugins", "ok", "dynamic-plugins"], ["Insights", "ok", null]].map(([t, s, h]) => `<div class="hs-i">${U.ico(s === "ok" ? "check" : "warn", 18)}<div><b>${t}</b>${R.q(h)}<div class="muted sm">${s === "ok" ? "Healthy" : "Degraded"}</div></div></div>`).join("")}</div>
          <div class="alerts-l">${firing.map((a) => `<a class="al-i" href="#/alerts/${encodeURIComponent(a.name)}">${U.ico(a.severity === "critical" ? "err" : a.severity === "warning" ? "warn" : "info", 14)}<div><div class="al-t"><b>${esc(a.name)}</b> <span class="muted sm">${U.date(a.since)}</span></div><div class="sm">${esc(a.desc)}</div></div></a>`).join("")}</div>`, "alerting", '<a class="card-l" href="#/alerts">View alerts</a>')}
        ${card("Cluster utilization", util("CPU", U.num(cpuUsed, 2), cpuTot, "cores", U.series(48, cpuUsed, cpuUsed * 0.12), "pod-cpu", "Requests: " + U.num(cpuTot * 0.31, 1) + " cores") + util("Memory", U.num(memUsed, 1) + " GiB", memTot, "GiB", U.series(48, memUsed, memUsed * 0.05), "pod-memory", "Requests: " + U.num(memTot * 0.28, 1) + " GiB") + util("Filesystem", U.num(fsUsed, 1) + " GiB", db.Node.length * 119.5, "GiB", U.series(48, fsUsed, 4), "capacity") + util("Network transfer", U.num(cpuUsed * 1.9, 1) + " MBps in", null, "", U.series(48, 20, 12), "service", U.num(cpuUsed * 1.4, 1) + " MBps out") + util("Pod count", String(db.Pod.length), null, "", U.series(48, db.Pod.length, 2), "pod"), "cluster-utilization", '<select class="sel sm"><option>1 hour</option><option>6 hours</option><option>24 hours</option></select>')}
      </div>
      <div class="dash-col">
        ${card("Activity", `<h4 class="act-h">Ongoing</h4><div class="act-i">${U.ico("sync", 13, "spin")} <div><b>Build portal-web-7</b> çalışıyor<div class="muted sm">musteri-portali</div></div></div><div class="act-i">${U.ico("sync", 13, "spin")} <div><b>PipelineRun</b> portal-web-build-deploy çalışıyor</div></div><h4 class="act-h">Recent events <a class="card-l" href="#/events">View all events</a></h4>${db.Event.slice(0, 14).map((e) => `<div class="act-e ${e.type === "Warning" ? "w" : ""}"><span class="muted sm">${new Date(e.lastTimestamp).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}</span>${e.type === "Warning" ? U.ico("warn", 12) : ""}${R.badge(e.involvedObject.kind)}<span class="sm"><b>${esc(e.reason)}</b> ${esc(e.involvedObject.name)}</span></div>`).join("")}`, "event")}
      </div></div>`;
  };

  /* =================== PROJECT: overview & workloads sekmeleri =================== */
  OC.T.overview = function (o, el) {
    const ns = o.metadata.name;
    const pods = db.Pod.filter((p) => p.metadata.namespace === ns);
    const cpu = pods.reduce((a, p) => a + p._m.cpu, 0), mem = pods.reduce((a, p) => a + p._m.mem, 0);
    const q = db.ResourceQuota.filter((x) => x.metadata.namespace === ns);
    const inv = ["Deployment", "DeploymentConfig", "StatefulSet", "Pod", "PersistentVolumeClaim", "Service", "Route", "ConfigMap", "Secret", "VolumeSnapshot"].map((k) => [k, db[k] ? db[k].filter((x) => x.metadata.namespace === ns).length : 0]);
    const ann = o.metadata.annotations || {};
    el.innerHTML = `<div class="dash">
      <div class="dash-col">${card("Details", R.dl([["Name", esc(ns), "name"], ["Requester", esc(ann["openshift.io/requester"] || "No requester")], ["Labels", R.labels(o.metadata.labels), "labels"], ["Description", esc(ann["openshift.io/description"] || "No description")]]), "project", `<a class="card-l" href="${R.href("Project", null, ns, "details")}">View all</a>`)}
      ${card("Inventory", inv.map(([k, n]) => `<a class="inv" href="${n ? OC.listHref(k, ns) : "#\" data-nop=\"1"}">${R.badge(k)}<span>${n} ${esc(K[k].label)}</span></a>`).join(""), "nav-workloads")}</div>
      <div class="dash-col dash-main">${card("Status", `<div class="hs"><div class="hs-i">${U.ico("check", 18)}<div><b>Active</b><div class="muted sm">Proje kullanılabilir</div></div></div></div>${OC.alerts.filter((a) => a.ns === ns && a.state === "firing").map((a) => `<a class="al-i" href="#/alerts/${encodeURIComponent(a.name)}">${U.ico("warn", 14)}<div><b>${esc(a.name)}</b><div class="sm">${esc(a.desc)}</div></div></a>`).join("")}`, "alerting")}
      ${card("Utilization", `<div class="util-r"><div class="util-l"><b>CPU</b>${R.q("pod-cpu")}<div class="util-v">${U.num(cpu, 3)} cores</div></div><div class="util-c">${U.spark(U.series(40, cpu || 0.01, (cpu || 0.01) * 0.2), { h: 60, grid: true })}</div></div><div class="util-r"><div class="util-l"><b>Memory</b>${R.q("pod-memory")}<div class="util-v">${U.mib(mem)}</div></div><div class="util-c">${U.spark(U.series(40, mem || 1, mem * 0.05 || 1), { h: 60, grid: true })}</div></div>`, "cluster-utilization")}
      ${q.length ? card("Resource quotas", q.map((x) => `<div class="rq"><b>${R.link("ResourceQuota", ns, x.metadata.name)}</b>${Object.keys(x.spec.hard).slice(0, 4).map((k) => { const used = x.status.used[k], hard = x.spec.hard[k]; const pct = Math.min(100, (parseQ(used) / parseQ(hard)) * 100); return `<div class="rq-r"><span class="mono sm">${esc(k)}</span><div class="util-bar sm"><span class="${pct > 85 ? "hi" : ""}" style="width:${pct}%"></span></div><span class="sm">${esc(used)} / ${esc(hard)}</span></div>`; }).join("")}</div>`).join(""), "resourcequota") : ""}</div>
      <div class="dash-col">${card("Activity", db.Event.filter((e) => e.metadata.namespace === ns).slice(0, 12).map((e) => `<div class="act-e ${e.type === "Warning" ? "w" : ""}"><span class="muted sm">${U.age(e.lastTimestamp)}</span>${e.type === "Warning" ? U.ico("warn", 12) : ""}${R.badge(e.involvedObject.kind)}<span class="sm"><b>${esc(e.reason)}</b> ${esc(e.involvedObject.name)}</span></div>`).join("") || '<div class="empty-s">No events</div>', "event")}</div></div>`;
  };
  function parseQ(v) { v = String(v); if (/m$/.test(v)) return parseFloat(v) / 1000; if (/Gi$/.test(v)) return parseFloat(v) * 1024; if (/Mi$/.test(v)) return parseFloat(v); return parseFloat(v); }
  OC.T.workloads = function (o, el) {
    const ns = o.metadata.name;
    const wl = ["Deployment", "DeploymentConfig", "StatefulSet", "DaemonSet"].reduce((a, k) => a.concat(db[k].filter((x) => x.metadata.namespace === ns)), []);
    el.innerHTML = wl.length ? `<div class="wl-cards">${wl.map((w) => `<div class="card wl-card"><div class="wl-h">${R.link(w.kind, ns, w.metadata.name)}</div>${OC.wlStatus(w)}<div class="muted sm mono">${esc(R.cnt(w)[0].image.split("@")[0])}</div></div>`).join("")}</div>` : '<div class="empty"><h3>No workloads found</h3><p class="muted">Bu projede henüz uygulama yok. Software Catalog veya +Add ile başlayabilirsiniz.</p></div>';
  };

  /* =================== TOPOLOGY =================== */
  P.topology = function () {
    const ns = OC.st.ns === "all" ? "eticaret-prod" : OC.st.ns;
    const wl = ["Deployment", "DeploymentConfig", "StatefulSet", "DaemonSet"].reduce((a, k) => a.concat(db[k].filter((x) => x.metadata.namespace === ns)), []);
    const groups = {};
    wl.forEach((w) => { const g = (w.metadata.labels || {})["app.kubernetes.io/part-of"] || ""; (groups[g] = groups[g] || []).push(w); });
    const colW = 170, rowH = 150, pos = {};
    let gx = 30, html = "", nodes = "", links = "";
    const gkeys = Object.keys(groups).sort((a, b) => (a ? 0 : 1) - (b ? 0 : 1));
    let maxH = 0;
    gkeys.forEach((g) => {
      const items = groups[g], cols = Math.min(3, items.length), rows = Math.ceil(items.length / cols);
      const w = cols * colW + 30, h = rows * rowH + 40;
      if (g) html += `<rect x="${gx}" y="20" width="${w}" height="${h}" rx="14" class="tg"/><text x="${gx + 14}" y="44" class="tg-t">${R.badge ? "" : ""}${esc(g)}</text><rect x="${gx + 10}" y="30" width="26" height="18" rx="9" class="tg-b"/><text x="${gx + 23}" y="43" text-anchor="middle" class="tg-bt">A</text>`;
      items.forEach((it, i) => { const cx = gx + 15 + (i % cols) * colW + colW / 2, cy = 60 + Math.floor(i / cols) * rowH + 60; pos[it.metadata.name] = [cx, cy, it]; });
      gx += w + 30; maxH = Math.max(maxH, h + 40);
    });
    // bağlantılar
    wl.forEach((w) => { const ct = (w.metadata.annotations || {})["app.openshift.io/connects-to"]; if (!ct) return; try { JSON.parse(ct).forEach((t) => { const a = pos[w.metadata.name], b = pos[t.name]; if (a && b) { const dx = b[0] - a[0], dy = b[1] - a[1], d = Math.sqrt(dx * dx + dy * dy) || 1; links += `<line x1="${a[0] + (dx / d) * 46}" y1="${a[1] + (dy / d) * 46}" x2="${b[0] - (dx / d) * 50}" y2="${b[1] - (dy / d) * 50}" class="tl" marker-end="url(#arr)"/>`; } }); } catch (e) { /* yoksay */ } });
    Object.keys(pos).forEach((n) => {
      const [cx, cy, w] = pos[n];
      const pods = OC.podsOf(w);
      const total = Math.max(1, pods.length), C = 2 * Math.PI * 40;
      let off = 0;
      const segs = pods.map((p) => { const s = OC.podStatus(p); const col = s === "Running" && p.status.containerStatuses[0] && p.status.containerStatuses[0].ready ? "var(--pod-run)" : /Pending|ContainerCreating/.test(s) ? "var(--pod-pend)" : "var(--danger)"; const len = C / total; const r = `<circle r="40" cx="${cx}" cy="${cy}" fill="none" stroke="${col}" stroke-width="7" stroke-dasharray="${len - (total > 1 ? 3 : 0)} ${C}" stroke-dashoffset="${-off}" transform="rotate(-90 ${cx} ${cy})"/>`; off += len; return r; }).join("");
      const rt = (w.metadata.labels || {})["app.openshift.io/runtime"] || "";
      const route = db.Route.find((r) => r.metadata.namespace === ns && r.spec.to.name === n);
      const k = K[w.kind];
      nodes += `<g class="tn" data-tn="${esc(w.kind)}|${esc(n)}" tabindex="0"><circle r="40" cx="${cx}" cy="${cy}" fill="none" stroke="var(--ring-bg)" stroke-width="7"/>${segs}<circle r="33" cx="${cx}" cy="${cy}" class="tn-c"/><text x="${cx}" y="${cy + 6}" text-anchor="middle" class="tn-ic">${esc(rtIcon(rt))}</text>${route ? `<g class="tn-route" data-ext="https://${esc(route.spec.host)}"><circle r="11" cx="${cx + 30}" cy="${cy - 30}"/><path d="M${cx + 26} ${cy - 26}l8-8m-5 0h5v5" class="tn-rp"/></g>` : ""}${w.metadata.annotations && w.metadata.annotations["app.openshift.io/vcs-uri"] ? `<g class="tn-git"><circle r="11" cx="${cx - 30}" cy="${cy + 30}"/><text x="${cx - 30}" y="${cy + 34}" text-anchor="middle">⎇</text></g>` : ""}<rect x="${cx - 70}" y="${cy + 50}" width="140" height="22" rx="11" class="tn-lb"/><text x="${cx - 56}" y="${cy + 65}" class="tn-k">${esc(k.abbr)}</text><text x="${cx - 36}" y="${cy + 65}" class="tn-n">${esc(n.length > 15 ? n.slice(0, 14) + "…" : n)}</text></g>`;
    });
    const W = Math.max(gx, 700), Hh = Math.max(maxH + 40, 420);
    $("#page").innerHTML = head("Topology", "topology", { right: `<div class="seg"><button class="on">${U.ico("cube", 12)} Graph</button><button data-go="${OC.listHref("Deployment", ns)}">List</button></div>` }) + `<div class="page-body topo-body">
      <div class="topo-tb"><div class="search-box sm"><input id="topoQ" placeholder="Find by name..." autocomplete="off"></div><span class="muted sm">Proje: <b>${esc(ns)}</b>${OC.st.ns === "all" ? " (All Projects seçiliyken örnek olarak gösteriliyor)" : ""}</span><span class="grow"></span><span class="legend"><i style="background:var(--pod-run)"></i>Running <i style="background:var(--pod-pend)"></i>Pending <i style="background:var(--danger)"></i>Failed</span></div>
      <div class="topo-wrap"><svg class="topo" viewBox="0 0 ${W} ${Hh}" width="${W}" height="${Hh}"><defs><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="tl-a"/></marker></defs>${html}${links}${nodes}</svg>${wl.length ? "" : '<div class="empty"><h3>No resources found</h3><p class="muted">Bu projede workload yok.</p></div>'}<aside class="topo-side" id="topoSide"></aside></div>
      <p class="muted sm">Bir düğüme tıklayarak yan paneli açın. Oklar <span class="mono">app.openshift.io/connects-to</span> annotation'ından, gruplar <span class="mono">app.kubernetes.io/part-of</span> label'ından gelir. ${R.q("topology")}</p></div>`;
    $$(".tn").forEach((g) => g.addEventListener("click", (e) => { if (e.target.closest("[data-ext]")) return; const [kind, name] = g.dataset.tn.split("|"); $$(".tn").forEach((x) => x.classList.remove("sel")); g.classList.add("sel"); topoSide(OC.find(kind, ns, name)); }));
    $("#topoQ").addEventListener("input", (e) => { const v = e.target.value.toLowerCase(); $$(".tn").forEach((g) => g.classList.toggle("dim", v && g.dataset.tn.toLowerCase().indexOf(v) < 0)); });
  };
  function rtIcon(rt) { return { nginx: "N", quarkus: "Q", golang: "Go", "spring-boot": "S", postgresql: "PG", redis: "R", rabbitmq: "MQ", nodejs: "JS", keycloak: "K", java: "J", python: "Py", amq: "K" }[rt] || "◆"; }
  function topoSide(w) {
    const side = $("#topoSide"); if (!w) return;
    const pods = OC.podsOf(w), ns = w.metadata.namespace;
    const svc = db.Service.filter((s) => s.metadata.namespace === ns && OC.selMatch(s.spec.selector, w.spec.template.metadata.labels));
    const routes = db.Route.filter((r) => r.metadata.namespace === ns && svc.some((s) => s.metadata.name === r.spec.to.name));
    side.innerHTML = `<div class="ts-h">${R.badge(w.kind)}<b>${esc(w.metadata.name)}</b><button class="hp-x" id="tsX">&#10005;</button></div><div class="ts-b"><div class="ts-sec"><h4>Pods ${R.q("pod")}</h4>${pods.map((p) => `<div class="ts-r">${R.link("Pod", ns, p.metadata.name)} ${R.status(OC.podStatus(p))} <a class="sm" href="${R.href("Pod", ns, p.metadata.name, "logs")}">View logs</a></div>`).join("")}</div><div class="ts-sec"><h4>Builds ${R.q("build")}</h4>${w.metadata.annotations && w.metadata.annotations["app.openshift.io/vcs-uri"] ? `<div class="ts-r mono sm">${esc(w.metadata.annotations["app.openshift.io/vcs-uri"])}</div>` : '<div class="muted sm">No BuildConfigs found for this resource.</div>'}</div><div class="ts-sec"><h4>Services ${R.q("service")}</h4>${svc.map((s) => `<div class="ts-r">${R.link("Service", ns, s.metadata.name)}<div class="muted sm mono">${s.spec.ports.map((p) => "Service port: " + p.port + " → Pod port: " + p.targetPort).join("<br>")}</div></div>`).join("") || '<div class="muted sm">No Services found</div>'}</div><div class="ts-sec"><h4>Routes ${R.q("route")}</h4>${routes.map((r) => `<div class="ts-r">${R.link("Route", ns, r.metadata.name)}<div><a class="ext sm" href="#" data-nop="1" data-ext="https://${esc(r.spec.host)}">https://${esc(r.spec.host)} ${U.ico("ext", 10)}</a></div></div>`).join("") || '<div class="muted sm">No Routes found</div>'}</div><a class="btn btn-secondary btn-sm" href="${R.href(w.kind, ns, w.metadata.name)}">${esc(w.kind)} detaylarına git</a></div>`;
    side.classList.add("open");
    $("#tsX").onclick = () => side.classList.remove("open");
  }

  /* =================== SEARCH =================== */
  P.search = function (r) {
    const kinds = Object.keys(K).filter((k) => K[k].cols && K[k].cols.length && ["Event", "Container"].indexOf(k) < 0).sort();
    const sel = new Set((r.q.kind || "Pod").split(",").filter((k) => K[k]));
    $("#page").innerHTML = head("Search", "search") + `<div class="page-body"><div class="toolbar"><div class="tb-g"><button class="btn btn-outline" id="kindBtn">Resources <span class="pill">${sel.size}</span> <i class="caret"></i></button></div><div class="tb-g sgroup"><button class="btn btn-outline" id="smode">Label</button><div class="search-box"><input id="searchQ" placeholder="app=frontend" value="${esc(r.q.q || "")}" autocomplete="off"><kbd>/</kbd></div>${R.q("ui-name-label-search")}</div><label class="chk"><input type="checkbox" id="sAll" ${r.q.ns ? "" : "checked"}> All Projects</label></div><div class="chipbar" id="sChips"></div><div id="sRes"></div></div>`;
    let mode = "label";
    const draw = () => {
      const qv = $("#searchQ").value.trim().toLowerCase();
      const allNs = $("#sAll").checked;
      $("#sChips").innerHTML = Array.from(sel).map((k) => `<span class="fchip">${R.badge(k)} ${esc(k)}<button data-rk="${k}">&#10005;</button></span>`).join("");
      $("#sRes").innerHTML = Array.from(sel).map((k) => {
        let items = OC.itemsFor(k, allNs ? "all" : (r.q.ns || OC.st.ns));
        if (qv) items = items.filter((o) => mode === "label" ? qv.split(",").every((p) => { const [a, b] = p.split("="); const l = o.metadata.labels || {}; return Object.keys(l).some((x) => x.toLowerCase() === a.trim() && (b === undefined || String(l[x]).toLowerCase() === b.trim())); }) : o.metadata.name.indexOf(qv) >= 0);
        return `<section class="dsec"><h2 class="dsec-t">${R.badge(k)} ${esc(K[k].label)} <span class="muted sm">(${items.length})</span></h2>${OC.miniList(k, items.slice(0, 50), { ns: K[k].ns, cols: K[k].cols.filter((c) => !c.hidden).slice(0, 3) })}</section>`;
      }).join("") || '<div class="empty"><p class="muted">Aramak için en az bir kaynak türü seçin.</p></div>';
    };
    draw();
    $("#searchQ").addEventListener("input", draw);
    $("#sAll").addEventListener("change", draw);
    $("#smode").addEventListener("click", (e) => { mode = mode === "label" ? "name" : "label"; e.currentTarget.textContent = mode === "label" ? "Label" : "Name"; $("#searchQ").placeholder = mode === "label" ? "app=frontend" : "Search by name..."; draw(); });
    $("#sChips").addEventListener("click", (e) => { const b = e.target.closest("[data-rk]"); if (b) { sel.delete(b.dataset.rk); draw(); } });
    $("#kindBtn").addEventListener("click", (e) => {
      const m = OC.openMenu(e.currentTarget, `<div class="mi-search">${U.ico("search", 12)}<input id="kf" placeholder="Select Resource"></div><div id="kl">${kinds.map((k) => `<label class="mi mi-chk" data-k="${k}"><input type="checkbox" value="${k}" ${sel.has(k) ? "checked" : ""}> ${R.badge(k)} ${esc(k)}</label>`).join("")}</div>`, "k-pop");
      m.addEventListener("change", (ev) => { ev.target.checked ? sel.add(ev.target.value) : sel.delete(ev.target.value); draw(); });
      $("#kf", m).addEventListener("input", (ev) => $$("[data-k]", m).forEach((l) => (l.style.display = l.dataset.k.toLowerCase().indexOf(ev.target.value.toLowerCase()) >= 0 ? "" : "none")));
    });
  };

  /* =================== API EXPLORER =================== */
  P["api-explorer"] = function () {
    const rows = Object.keys(K).filter((k) => K[k].plural && ["Container"].indexOf(k) < 0).map((k) => { const api = K[k].api; const [g, v] = api.indexOf("/") > 0 ? api.split("/") : ["", api]; return { k: k, g: g, v: v, ns: K[k].ns, plural: K[k].plural }; }).concat(db.CustomResourceDefinition.filter((c) => !K[c.spec.names.kind]).map((c) => ({ k: c.spec.names.kind, g: c.spec.group, v: c.spec.versions[0].name, ns: c.spec.scope === "Namespaced", plural: c.spec.names.plural, crd: c.metadata.name }))).sort((a, b) => a.k.localeCompare(b.k));
    $("#page").innerHTML = head("API Explorer", "api-explorer") + `<div class="page-body"><div class="toolbar"><div class="search-box"><input id="apiQ" placeholder="Filter by kind..." autocomplete="off"><kbd>/</kbd></div><select class="sel" id="apiG"><option value="">All groups</option>${Array.from(new Set(rows.map((r) => r.g))).sort().map((g) => `<option value="${esc(g)}">${esc(g || "core")}</option>`).join("")}</select><select class="sel" id="apiS"><option value="">All scopes</option><option value="1">Namespaced</option><option value="0">Cluster</option></select></div><div id="apiT"></div></div>`;
    const draw = () => { const q = $("#apiQ").value.toLowerCase(), g = $("#apiG").value, s = $("#apiS").value; const f = rows.filter((r) => r.k.toLowerCase().indexOf(q) >= 0 && (!$("#apiG").selectedIndex || r.g === g) && (s === "" || String(+r.ns) === s)); $("#apiT").innerHTML = R.table([["Kind"], ["Group", "crd-scope"], ["Version", "crd-scope"], ["Namespaced", "crd-scope"], ["Description"]], f.map((r) => [`<span class="rlink">${R.badge(r.k)}${K[r.k] ? `<a href="${r.ns ? OC.listHref(r.k) : R.href(r.k)}">${esc(r.k)}</a>` : `<a href="#/k8s/cluster/customresourcedefinitions/${esc(r.crd)}">${esc(r.k)}</a>`}</span>`, esc(r.g || "core"), r.v, r.ns ? "true" : "false", `<span class="sm">${K[r.k] && H[K[r.k].help] ? esc(H[K[r.k].help].what.split(". ")[0]) + ". " + R.q(K[r.k].help) : "Özel kaynak (CRD)."}</span>`])); };
    draw();
    ["apiQ", "apiG", "apiS"].forEach((i) => $("#" + i).addEventListener("input", draw));
  };

  /* =================== EVENTS =================== */
  P.events = function () {
    const ns = OC.st.ns;
    let type = "all", kind = "";
    $("#page").innerHTML = head("Events", "event") + `<div class="page-body"><div class="toolbar"><select class="sel" id="evK"><option value="">All types</option>${Array.from(new Set(db.Event.map((e) => e.involvedObject.kind))).sort().map((k) => `<option>${k}</option>`).join("")}</select><select class="sel" id="evT"><option value="all">All types</option><option value="Normal">Normal</option><option value="Warning">Warning</option></select>${R.q("event-type")}<div class="search-box"><input id="evQ" placeholder="Filter events by names or messages..." autocomplete="off"></div></div><div class="ev-head"><span class="stream">${U.ico("play", 10)} Streaming events...</span><span class="muted" id="evC"></span></div><div class="evs" id="evL"></div></div>`;
    const draw = () => {
      const q = $("#evQ").value.toLowerCase();
      const evs = db.Event.filter((e) => (ns === "all" || e.metadata.namespace === ns) && (type === "all" || e.type === type) && (!kind || e.involvedObject.kind === kind) && (!q || (e.involvedObject.name + " " + e.message + " " + e.reason).toLowerCase().indexOf(q) >= 0));
      $("#evC").textContent = "Showing " + Math.min(evs.length, 150) + " of " + evs.length + " events";
      $("#evL").innerHTML = evs.slice(0, 150).map((e) => OC.eventRow(e)).join("") || '<div class="empty-s">No events</div>';
    };
    draw();
    $("#evT").addEventListener("change", (e) => { type = e.target.value; draw(); });
    $("#evK").addEventListener("change", (e) => { kind = e.target.value; draw(); });
    $("#evQ").addEventListener("input", draw);
  };

  /* =================== SOFTWARE CATALOG =================== */
  P.catalog = function (r) {
    const tab = r.sub || "all";
    const types = ["Builder Image", "Template", "Helm Chart", "Operator Backed", "Pipeline", "Container Image"];
    const opTab = tab === "operators";
    $("#page").innerHTML = head("Software Catalog", "software-catalog", { desc: "Kod örnekleri, builder imajları, şablonlar, Helm chart'ları ve Operator'lerden oluşan katalog. Bir öğeye tıklayın ve nasıl kurulacağını öğrenin." }) + `<div class="tabs"><a class="tab ${!opTab ? "on" : ""}" href="#/catalog">All items</a><a class="tab ${opTab ? "on" : ""}" href="#/catalog/operators">Operators</a><span class="tabs-q">${R.q(opTab ? "operator" : "software-catalog")}</span></div><div class="page-body cat"><aside class="cat-side">${opTab ? ["All Items", "AI/Machine Learning", "CI/CD", "Developer Tools", "Integration & Delivery", "Logging & Tracing", "Monitoring", "Networking", "Security", "Storage", "Streaming & Messaging", "Virtualization"].map((c, i) => `<button class="cat-c ${i ? "" : "on"}" data-cc="${i ? esc(c) : ""}">${esc(c)}</button>`).join("") : `<button class="cat-c on" data-cc="">All items</button>` + types.map((t) => `<button class="cat-c" data-cc="${esc(t)}">${esc(t)}</button>`).join("")}</aside><div class="cat-main"><div class="toolbar"><div class="search-box"><input id="catQ" placeholder="Filter by keyword..." autocomplete="off"></div><span class="muted" id="catN"></span></div><div class="tiles" id="tiles"></div></div></div>`;
    let cat = "";
    const draw = () => {
      const q = $("#catQ").value.toLowerCase();
      const list = opTab ? OC.operatorHub.filter((o) => (!cat || o[2] === cat) && o[0].toLowerCase().indexOf(q) >= 0) : OC.catalog.filter((c) => (!cat || c[1] === cat) && (c[0] + c[3]).toLowerCase().indexOf(q) >= 0);
      $("#catN").textContent = list.length + " items";
      $("#tiles").innerHTML = list.map((c, i) => opTab ? `<button class="tile" data-op="${i}">${OC.opIcon(c[0])}<div class="tile-t">${esc(c[0])}</div><div class="muted sm">provided by ${esc(c[1])}</div>${c[3] ? '<span class="pill ok">Installed</span>' : ""}<div class="sm tile-d">${esc(c[2])}</div></button>` : `<button class="tile" data-ci="${i}"><span class="tile-ic">${esc(c[2].slice(0, 2).toUpperCase())}</span><div class="tile-t">${esc(c[0])}</div><div class="muted sm">${esc(c[4])}</div><span class="pill">${esc(c[1])}</span><div class="sm tile-d">${esc(c[3])}</div></button>`).join("");
      $$("[data-ci]").forEach((b) => b.addEventListener("click", () => catModal(list[+b.dataset.ci])));
      $$("[data-op]").forEach((b) => b.addEventListener("click", () => opModal(list[+b.dataset.op])));
    };
    draw();
    $("#catQ").addEventListener("input", draw);
    $$("[data-cc]").forEach((b) => b.addEventListener("click", () => { cat = b.dataset.cc; $$("[data-cc]").forEach((x) => x.classList.toggle("on", x === b)); draw(); }));
  };
  function catModal(c) {
    const cmds = { "Builder Image": "oc new-app " + c[2] + "~https://github.com/ornek/" + c[2] + "-app.git --name=ornek-" + c[2] + "\noc expose service/ornek-" + c[2], Template: "oc new-app --template=" + c[2] + "-persistent -p VOLUME_CAPACITY=5Gi", "Helm Chart": "helm install " + c[2] + " openshift-helm-charts/" + c[2], "Operator Backed": "# Önce Operator kurulur, sonra özel kaynak oluşturulur\noc apply -f " + c[2] + "-instance.yaml", Pipeline: "tkn pipeline start s2i-" + c[2], "Container Image": "oc new-app --image=registry.access.redhat.com/ubi9/httpd-24 --name=ornek\noc expose svc/ornek" };
    const help = { "Builder Image": "s2i", Template: "kubernetes-object", "Helm Chart": "helm", "Operator Backed": "operator", Pipeline: "pipeline", "Container Image": "image" }[c[1]];
    OC.modal(c[0], `<div class="cat-m"><span class="tile-ic lg">${esc(c[2].slice(0, 2).toUpperCase())}</span><div><span class="pill">${esc(c[1])}</span><p>${esc(c[3])}</p><p class="muted sm">Provider: ${esc(c[4])}</p></div></div>${H[help] ? `<p>${esc(H[help].what)}</p>` : ""}<div class="cmd-box"><div class="cmd-h">Komut satırı karşılığı</div><pre class="code">${esc(cmds[c[1]])}</pre></div>`, [["Create", "primary", () => (OC.toast("Simülasyon: " + c[0] + " oluşturuldu sayıldı"), true)], ["Cancel", "secondary"]]);
  }
  function opModal(o) {
    OC.modal(o[0], `<div class="cat-m">${OC.opIcon(o[0])}<div><b>${esc(o[0])}</b><div class="muted sm">provided by ${esc(o[1])} · ${esc(o[2])}</div>${o[3] ? '<span class="pill ok">Installed</span>' : ""}</div></div><p>${esc(H.operator.what)}</p>${R.dl([["Update channel", "stable", "subscription"], ["Installation mode", "All namespaces on the cluster (default)", "install-mode"], ["Installed Namespace", "openshift-operators", "install-mode"], ["Update approval", "Automatic", "subscription"]])}<div class="cmd-box"><div class="cmd-h">YAML karşılığı (Subscription)</div><pre class="code">apiVersion: operators.coreos.com/v1alpha1\nkind: Subscription\nmetadata:\n  name: ${esc(o[0].toLowerCase().replace(/[^a-z0-9]+/g, "-"))}\n  namespace: openshift-operators\nspec:\n  channel: stable\n  name: ${esc(o[0].toLowerCase().replace(/[^a-z0-9]+/g, "-"))}\n  source: redhat-operators\n  sourceNamespace: openshift-marketplace\n  installPlanApproval: Automatic</pre></div>`, [[o[3] ? "View Operator" : "Install", "primary", () => { if (o[3]) OC.go(OC.listHref("ClusterServiceVersion", "all")); else OC.toast("Simülasyon: Operator kurulumu başlatıldı sayıldı"); return true; }], ["Cancel", "secondary"]], null, "wide");
  }

  /* =================== HELM RELEASES =================== */
  P["helm-releases"] = function () {
    const ns = OC.st.ns;
    const list = OC.helmReleases.filter((h) => ns === "all" || h.ns === ns);
    $("#page").innerHTML = head("Helm Releases", "helm-release", { right: `<button class="btn btn-primary sim-act" data-title="Create Helm Release" data-cmd="helm install <ad> <repo>/<chart> -n ${esc(ns === "all" ? "<proje>" : ns)}" data-h2="helm">Create Helm Release</button>` }) + `<div class="page-body">${list.length ? R.table([["Name", "helm-release"], ["Namespace"], ["Revision", "helm-release"], ["Updated"], ["Status"], ["Chart name"], ["Chart version"], ["App version"], [""]], list.map((h) => [`<span class="rlink"><span class="rb rb-helm">HR</span><b>${esc(h.name)}</b></span>`, R.nsLink(h.ns), h.rev, U.ts(U.ago(h.age)), R.status(h.status), esc(h.chart), esc(h.ver), esc(h.app), `<button class="btn btn-link btn-sm sim-act" data-title="Rollback" data-cmd="helm rollback ${esc(h.name)} ${Math.max(1, h.rev - 1)} -n ${esc(h.ns)}" data-h2="helm-release">Rollback</button>`])) : `<div class="empty"><h3>No Helm Releases found</h3><p class="muted">Seçili projede Helm release yok. Üstteki proje seçiciden <b>All Projects</b> seçin. ${R.q("helm")}</p></div>`}</div>`;
  };

  /* =================== OBSERVE =================== */
  P.alerts = function (r) {
    if (r.sub) return alertDetail(decodeURIComponent(r.sub));
    const tab = r.q.tab || "alerts";
    $("#page").innerHTML = head("Alerting", "alerting") + `<div class="tabs"><a class="tab ${tab === "alerts" ? "on" : ""}" href="#/alerts">Alerts</a><a class="tab ${tab === "silences" ? "on" : ""}" href="#/alerts?tab=silences">Silences</a><a class="tab ${tab === "rules" ? "on" : ""}" href="#/alerts?tab=rules">Alerting rules</a><span class="tabs-q">${R.q(tab === "silences" ? "silence" : "alerting")}</span></div><div class="page-body" id="alB"></div>`;
    const el = $("#alB");
    if (tab === "silences") el.innerHTML = `<div class="toolbar"><button class="btn btn-primary sim-act" data-title="Create silence" data-cmd="amtool silence add alertname=Ornek --duration=2h --comment='Bakım'" data-h2="silence">Create silence</button></div>` + R.table([["Name"], ["Firing alerts"], ["State"], ["Ends"], ["Creator"], ["Comment"]], OC.silences.map((s) => [`<span class="mono sm">${esc(s.matchers)}</span>`, "1", R.status(s.state === "Active" ? "Active" : s.state), U.ts(s.ends), esc(s.creator), esc(s.comment)]));
    else if (tab === "rules") el.innerHTML = R.table([["Name"], ["Severity", "alert-severity"], ["Alert state"], ["Source"]], OC.alerts.map((a) => [`<a href="#/alerts/${encodeURIComponent(a.name)}"><b>${esc(a.name)}</b></a>`, sevPill(a.severity), R.status(a.state === "firing" ? "Firing" : a.state === "pending" ? "Pending" : "Silenced"), a.source]));
    else {
      let flt = new Set(["firing"]);
      el.innerHTML = `<div class="toolbar"><button class="btn btn-outline" id="alF">${U.ico("filter", 12)} Filter <i class="caret"></i></button>${R.q("ui-filter")}<div class="search-box"><input id="alQ" placeholder="Search by name..."></div></div><div id="alT"></div>`;
      const draw = () => { const q = $("#alQ").value.toLowerCase(); const l = OC.alerts.filter((a) => (!flt.size || flt.has(a.state)) && a.name.toLowerCase().indexOf(q) >= 0); $("#alT").innerHTML = R.table([["Name"], ["Severity", "alert-severity"], ["State"], ["Source"], ["Namespace"]], l.map((a) => [`<a href="#/alerts/${encodeURIComponent(a.name)}"><b>${esc(a.name)}</b></a><div class="muted sm">${esc(a.summary)}</div>`, sevPill(a.severity), R.status(a.state === "firing" ? "firing" : a.state === "pending" ? "Pending" : "Silenced") + `<div class="muted sm">Since ${U.date(a.since)}</div>`, a.source, R.nsLink(a.ns)]), { empty: "No alerts" }); };
      draw();
      $("#alQ").addEventListener("input", draw);
      $("#alF").addEventListener("click", (e) => { const m = OC.openMenu(e.currentTarget, `<div class="mi-h">Alert State</div>${["firing", "pending", "silenced"].map((s) => `<label class="mi mi-chk"><input type="checkbox" value="${s}" ${flt.has(s) ? "checked" : ""}> ${s[0].toUpperCase() + s.slice(1)}</label>`).join("")}`); m.addEventListener("change", (ev) => { ev.target.checked ? flt.add(ev.target.value) : flt.delete(ev.target.value); draw(); }); });
    }
  };
  const sevPill = (s) => `<span class="sev sev-${s}">${s === "critical" ? U.ico("err", 12) : s === "warning" ? U.ico("warn", 12) : U.ico("info", 12)} ${s[0].toUpperCase() + s.slice(1)}</span>`;
  function alertDetail(name) {
    const a = OC.alerts.find((x) => x.name === name);
    if (!a) return OC.go("#/alerts");
    const expr = { KubePodCrashLooping: 'max_over_time(kube_pod_container_status_waiting_reason{reason="CrashLoopBackOff",job="kube-state-metrics"}[5m]) >= 1', KubePodNotReady: 'sum by (namespace, pod) (max by(namespace, pod) (kube_pod_status_phase{job="kube-state-metrics", phase=~"Pending|Unknown"})) > 0', Watchdog: "vector(1)", KubeJobFailed: 'kube_job_failed{job="kube-state-metrics"} > 0', KubePodNotScheduled: 'kube_pod_status_unschedulable > 0', AlertmanagerReceiversNotConfigured: "cluster:alertmanager_integrations:max == 0", PersistentVolumeClaimPending: 'kube_persistentvolumeclaim_status_phase{phase="Pending"} == 1', SiparisKuyrukBirikmesi: 'rabbitmq_queue_messages{queue="siparis"} > 10000' }[a.name];
    $("#page").innerHTML = head(a.name, "alerting", { crumb: `<nav class="crumb"><a href="#/alerts">Alerts</a><span class="sep">${U.ico("chevr", 10)}</span><span>Alert details</span></nav>`, status: " " + sevPill(a.severity), right: `<button class="btn btn-secondary sim-act" data-title="Silence alert" data-cmd="Silence: alertname=${esc(a.name)}, namespace=${esc(a.ns)} (2 saat)" data-h2="silence">Silence alert</button>` }) + `<div class="page-body"><div class="card mcard wide">${U.spark(U.series(60, 1, 0.05), { h: 140, grid: true, color: "var(--danger)" })}</div>${R.section("Alert details", `<div class="dgrid"><div>${R.dl([["Name", esc(a.name)], ["Severity", sevPill(a.severity), "alert-severity"], ["State", R.status(a.state), "alerting"], ["Namespace", R.nsLink(a.ns)], ["Source", a.source]])}</div><div>${R.dl([["Description", esc(a.desc)], ["Summary", esc(a.summary)], ["Active since", U.ts(a.since)], ["Alerting rule expression", `<pre class="code">${esc(expr || "-")}</pre>`, "metrics"]])}</div></div>`)}${a.pod ? `<a class="btn btn-secondary" href="${R.href("Pod", a.ns, a.pod)}">İlgili Pod'a git: ${esc(a.pod)}</a>` : ""}</div>`;
  }
  P.metrics = function () {
    const qs = [["CPU Usage", 'sum(rate(container_cpu_usage_seconds_total{container!=""}[5m])) by (namespace)'], ["Memory Usage", 'sum(container_memory_working_set_bytes{container!=""}) by (namespace)'], ["Filesystem Usage", "sum(container_fs_usage_bytes) by (namespace)"], ["Receive Bandwidth", "sum(rate(container_network_receive_bytes_total[5m])) by (namespace)"], ["Pod restarts", "sum(increase(kube_pod_container_status_restarts_total[1h])) by (namespace, pod) > 0"]];
    $("#page").innerHTML = head("Metrics", "metrics") + `<div class="page-body"><div class="toolbar"><select class="sel" id="mqSel"><option value="">Insert example query</option>${qs.map((q, i) => `<option value="${i}">${esc(q[0])}</option>`).join("")}</select><span class="grow"></span><button class="btn btn-secondary btn-sm" id="mqAdd">Add query</button><button class="btn btn-primary btn-sm" id="mqRun">Run queries</button></div><textarea id="mq" class="code-in sm" rows="3" spellcheck="false">${esc(qs[0][1])}</textarea><div id="mqR"></div><p class="muted sm">PromQL: Prometheus sorgu dili. <span class="mono">rate()</span> sayaçların saniyelik artışını, <span class="mono">sum by (etiket)</span> gruplamayı yapar. ${R.q("metrics")}</p></div>`;
    const run = () => {
      const nss = OC.userProjects.concat(["openshift-monitoring", "openshift-ingress"]);
      const cols = ["var(--chart1)", "var(--chart2)", "var(--chart3)", "var(--chart4)", "var(--chart5)", "var(--chart6)", "var(--chart7)"];
      const series = nss.map((n, i) => U.series(50, 0.05 + ((n.length * 7) % 10) / 10, 0.05));
      const max = Math.max.apply(null, [].concat.apply([], series)) * 1.1;
      const lines = series.map((s, i) => U.spark(s, { h: 220, max: max, color: cols[i % cols.length] }).replace('<svg class="spark"', '<svg class="spark ov"')).join("");
      $("#mqR").innerHTML = `<div class="card mq-chart"><div class="mq-stack">${lines}</div></div>` + R.table([[""], ["namespace"], ["Value"]], nss.map((n, i) => [`<i class="sw" style="background:${cols[i % cols.length]}"></i>`, esc(n), U.num(series[i][49], 4)]));
    };
    run();
    $("#mqRun").onclick = run;
    $("#mqSel").onchange = (e) => { if (e.target.value !== "") { $("#mq").value = qs[+e.target.value][1]; run(); } };
    $("#mqAdd").onclick = () => OC.toast("Simülasyon: birden fazla sorgu aynı grafikte gösterilebilir");
  };
  P.dashboards = function () {
    const ds = ["Kubernetes / Compute Resources / Cluster", "Kubernetes / Compute Resources / Namespace (Pods)", "Kubernetes / Compute Resources / Node (Pods)", "Kubernetes / Networking / Cluster", "etcd", "API Performance", "Node Exporter / USE Method / Cluster"];
    $("#page").innerHTML = head("Dashboards", "dashboards") + `<div class="page-body"><div class="toolbar"><label>Dashboard <select class="sel" id="dSel">${ds.map((d) => `<option>${esc(d)}</option>`).join("")}</select></label><label>Time range <select class="sel"><option>Last 30 minutes</option><option>Last 1 hour</option><option>Last 6 hours</option></select></label><label>Refresh interval <select class="sel"><option>30 seconds</option><option>Off</option></select></label></div><div class="mgrid" id="dG"></div></div>`;
    const draw = () => { const t = ["CPU Utilisation", "CPU Requests Commitment", "CPU Limits Commitment", "Memory Utilisation", "Memory Requests Commitment", "Memory Limits Commitment"]; $("#dG").innerHTML = t.map((x, i) => `<div class="card stat"><div class="muted sm">${x}</div><div class="stat-v">${U.num(20 + ((i * 17 + $("#dSel").selectedIndex * 9) % 60), 1)}%</div></div>`).join("") + ["CPU Usage", "CPU Quota", "Memory Usage (w/o cache)", "Current Network Usage"].map((x) => `<div class="card mcard"><div class="mcard-h">${x}</div>${U.spark(U.series(50, 30, 10), { h: 130, grid: true })}</div>`).join(""); };
    draw(); $("#dSel").onchange = draw;
  };
  P.targets = function () {
    const t = [["prometheus-k8s", "openshift-monitoring", "Up"], ["node-exporter", "openshift-monitoring", "Up"], ["kube-state-metrics", "openshift-monitoring", "Up"], ["kubelet", "kube-system", "Up"], ["etcd", "openshift-etcd", "Up"], ["router-default", "openshift-ingress", "Up"], ["apiserver", "default", "Up"], ["katalog-api", "eticaret-prod", "Up"], ["katalog-api", "eticaret-test", "Down"], ["siparis-servisi", "eticaret-prod", "Up"]];
    $("#page").innerHTML = head("Metrics Targets", "targets") + `<div class="page-body">${R.table([["Endpoint"], ["Monitor"], ["Status"], ["Namespace"], ["Last Scrape"], ["Scrape Duration"]], t.map(([n, ns, s]) => [`<span class="mono sm">https://10.1${U.ri(28, 35)}.0.${U.ri(2, 250)}:${U.pick(["9091", "9100", "8443", "8080"])}/metrics</span>`, `${R.badge("ServiceMonitor")} ${esc(n)}`, R.status(s), R.nsLink(ns), U.ri(2, 29) + " seconds ago", U.ri(4, 90) + "ms"]))}</div>`;
  };
  K.ServiceMonitor = { abbr: "SM", cls: "rb-op" };

  /* =================== CLUSTER SETTINGS =================== */
  P.settings = function (r) {
    const tab = r.q.tab || "details", cl = OC.cluster;
    const cfgs = [["APIServer", "config.openshift.io", "API sunucusu (audit, TLS, şifreleme)"], ["Authentication", "config.openshift.io", "Kimlik doğrulama tipi"], ["Build", "config.openshift.io", "Build varsayılanları (proxy, env)"], ["Console", "config.openshift.io", "Konsol ayarları"], ["DNS", "config.openshift.io", "Cluster DNS yapılandırması"], ["FeatureGate", "config.openshift.io", "Özellik bayrakları"], ["Image", "config.openshift.io", "Güvenilir/engellenen registry'ler"], ["Infrastructure", "config.openshift.io", "Altyapı sağlayıcı bilgisi"], ["Ingress", "config.openshift.io", "Varsayılan apps alan adı"], ["Network", "config.openshift.io", "Pod/Service ağ CIDR'ları"], ["OAuth", "config.openshift.io", "Kimlik sağlayıcılar (LDAP, OIDC, HTPasswd)"], ["OperatorHub", "config.openshift.io", "Katalog kaynakları"], ["Project", "config.openshift.io", "Proje şablonu"], ["Proxy", "config.openshift.io", "Cluster genel HTTP(S) proxy"], ["Scheduler", "config.openshift.io", "Scheduler profili"], ["Alertmanager", "monitoring", "Uyarı alıcıları ve yönlendirme"]];
    $("#page").innerHTML = head("Cluster Settings", "cluster-settings") + `<div class="tabs">${[["details", "Details", "cluster-version"], ["co", "ClusterOperators", "cluster-operators"], ["config", "Configuration", "cluster-settings"]].map(([id, l]) => `<a class="tab ${tab === id ? "on" : ""}" href="#/settings/cluster?tab=${id}">${l}</a>`).join("")}<span class="tabs-q">${R.q(tab === "co" ? "cluster-operators" : tab === "config" ? "cluster-settings" : "cluster-version")}</span></div><div class="page-body" id="csB"></div>`;
    const el = $("#csB");
    if (tab === "co") el.innerHTML = `<div class="toolbar"><div class="search-box"><input id="coQ" placeholder="Search by name..."></div></div><div id="coT"></div>`, (() => { const d = () => { const q = $("#coQ").value; $("#coT").innerHTML = R.table([["Name"], ["Status", "cluster-operators"], ["Version"], ["Message"]], OC.clusterOperators.filter((c) => c.name.indexOf(q) >= 0).map((c) => [`<span class="rlink"><span class="rb rb-op">CO</span><b>${esc(c.name)}</b></span>`, R.status("Available"), c.version, `<span class="muted sm">${esc(c.message || "-")}</span>`])); }; d(); $("#coQ").oninput = d; })();
    else if (tab === "config") el.innerHTML = R.table([["Configuration resource"], ["Description"]], cfgs.map(([k, g, d]) => [`<span class="rlink"><span class="rb rb-adm">${esc(k.slice(0, 2).toUpperCase())}</span><a href="#" data-nop="1" ${k === "OAuth" ? 'data-h="oauth"' : `class="sim-act" data-title="${esc(k)}" data-cmd="oc edit ${esc(k.toLowerCase())}.${esc(g)} cluster"`}>${esc(k)}</a></span><div class="muted sm">${esc(g)}</div>`, esc(d)]));
    else el.innerHTML = `<div class="card upd-card"><div class="upd-row"><div>${R.dl([["Current version", `<b class="big">${cl.version}</b>`, "cluster-version"], ["Update status", R.status("Up to date") + ' <span class="muted sm">(yeni güncellemeler mevcut)</span>'], ["Channel", `${cl.channel} <button class="btn btn-link btn-sm sim-act" data-title="Update channel" data-cmd="oc adm upgrade channel stable-4.20" data-h2="update-channel">${U.ico("pencil", 11)}</button>`, "update-channel"]])}</div><div class="upd-path"><div class="muted sm">Update path ${R.q("cluster-version")}</div><div class="up-line"><span class="up-dot cur">${cl.version}</span>${cl.updates.map((v) => `<span class="up-seg"></span><span class="up-dot">${v}</span>`).join("")}</div><button class="btn btn-primary sim-act" data-title="Select a version" data-cmd="oc adm upgrade --to=${cl.updates[1]}" data-h2="cluster-version">Select a version</button></div></div><p class="muted sm">Güncelleme sırasında Cluster Version Operator önce control plane bileşenlerini, ardından MachineConfigPool'lar üzerinden node'ları sırayla günceller.</p></div>${R.section("Cluster details", `<div class="dgrid"><div>${R.dl([["Cluster ID", `<span class="mono sm">${cl.id}</span>`, "cluster-id"], ["Desired release image", `<span class="mono sm">quay.io/openshift-release-dev/ocp-release@sha256:${U.hex(24)}…</span>`], ["Cluster version configuration", `<a href="#" data-nop="1" class="sim-act" data-title="ClusterVersion" data-cmd="oc get clusterversion version -o yaml">ClusterVersion version</a>`]])}</div><div>${R.dl([["Cluster autoscaler", `<a href="#" data-nop="1" class="sim-act" data-title="Create ClusterAutoscaler" data-cmd="oc apply -f clusterautoscaler.yaml" data-h2="machineautoscaler">Create autoscaler</a>`, "machineautoscaler"], ["Kubernetes version", cl.k8s], ["Infrastructure", cl.provider + " (" + cl.infraName + ")", "infra-provider"]])}</div></div>`)}${R.section("Update history", R.table([["Version"], ["State"], ["Started"], ["Completed"]], [[cl.version, "Completed", U.ts(U.ago(60 * 24 * 20)), U.ts(U.ago(60 * 24 * 20 - 74))], ["4.20.2", "Completed", U.ts(U.ago(60 * 24 * 52)), U.ts(U.ago(60 * 24 * 52 - 81))], ["4.19.15", "Completed", U.ts(U.ago(60 * 24 * 88)), U.ts(U.ago(60 * 24 * 88 - 96))], ["4.19.9", "Completed", U.ts(U.ago(60 * 24 * 142)), U.ts(U.ago(60 * 24 * 142 - 45))]]), "cluster-version")}`;
  };
  P.plugins = function () {
    const pl = [["pipelines-console-plugin", "Red Hat OpenShift Pipelines", "1.20.1"], ["gitops-plugin", "Red Hat OpenShift GitOps", "1.18.0"], ["odf-console", "OpenShift Data Foundation", "4.20.1"], ["logging-view-plugin", "Logging UI", "6.3.1"], ["monitoring-plugin", "Monitoring", OC.cluster.version], ["networking-console-plugin", "Networking", OC.cluster.version]];
    $("#page").innerHTML = head("Dynamic Plugins", "dynamic-plugins") + `<div class="page-body">${R.table([["Name"], ["Display name"], ["Version"], ["Status"], ["Enabled"]], pl.map(([n, d, v]) => [`<span class="mono">${esc(n)}</span>`, esc(d), v, R.status("Loaded"), R.status("Enabled".replace("Enabled", "Ready")) ]))}</div>`;
  };

  /* =================== ÖĞRENME MERKEZİ =================== */
  P.learn = function (r) {
    const keys = Object.keys(H);
    const cats = Array.from(new Set(keys.map((k) => H[k].cat))).sort((a, b) => a.localeCompare(b, "tr"));
    $("#page").innerHTML = head("Öğrenme Merkezi", "ui-learn", { desc: "OpenShift ve Kubernetes kavramlarının tamamı, Türkçe açıklamalarla. Bir konuya tıklayarak sağ panelde açıklamasını okuyun. Konsolda gezinirken de her (?) simgesi aynı açıklamaları gösterir." }) + `<div class="page-body"><div class="learn-start"><div class="card ls-card"><h3>🚀 Önerilen öğrenme yolu</h3><ol class="lpath">${[["openshift", "OpenShift nedir?"], ["kubernetes-object", "Nesne modeli (spec/status)"], ["project", "Project / Namespace"], ["pod", "Pod"], ["deployment", "Deployment"], ["service", "Service"], ["route", "Route"], ["configmap", "ConfigMap"], ["secret", "Secret"], ["pvc", "PersistentVolumeClaim"], ["statefulset", "StatefulSet"], ["buildconfig", "BuildConfig / S2I"], ["networkpolicy", "NetworkPolicy"], ["role", "RBAC"], ["operator", "Operator"], ["alerting", "İzleme ve uyarılar"]].map(([k, t]) => `<li><button class="btn btn-link" data-h="${k}">${esc(t)}</button></li>`).join("")}</ol></div><div class="card ls-card"><h3>🧪 Deneyerek öğrenin</h3><ul class="lst">${[["#/k8s/ns/eticaret-prod/deployments/frontend", "frontend Deployment'ını ölçekleyin (halkadaki oklar)"], ["#/k8s/ns/eticaret-prod/pods", "Bir Pod'u silin ve controller'ın yenisini oluşturmasını izleyin"], ["#/k8s/ns/eticaret-test/pods", "CrashLoopBackOff durumundaki Pod'un loglarını inceleyin"], ["#/k8s/ns/odeme-api/pods", "Pending durumundaki Pod'un Events sekmesine bakın"], ["#/topology", "Topology görünümünde uygulama mimarisini keşfedin"], ["#/k8s/ns/musteri-portali/buildconfigs/portal-web", "Bir build başlatın ve loglarını izleyin"], ["#/k8s/ns/eticaret-prod/secrets/postgresql", "Secret değerlerini görüntüleyin (Reveal values)"], ["#/alerts", "Firing durumundaki uyarıları inceleyin"]].map(([h, t]) => `<li><a href="${h}">${esc(t)}</a></li>`).join("")}</ul><button class="btn btn-secondary btn-sm" data-tour="1">Rehberli turu yeniden başlat</button></div></div>
      <div class="toolbar"><div class="search-box"><input id="lrQ" placeholder="Konu ara (ör. probe, route, quota)..." autocomplete="off" value="${esc(r.q.q || "")}"><kbd>/</kbd></div><select class="sel" id="lrC"><option value="">Tüm kategoriler (${keys.length} konu)</option>${cats.map((c) => `<option ${r.q.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></div><div id="lrL"></div></div>`;
    const draw = () => {
      const q = $("#lrQ").value.toLowerCase(), c = $("#lrC").value;
      const f = keys.filter((k) => (!c || H[k].cat === c) && (!q || (H[k].t + " " + H[k].what).toLowerCase().indexOf(q) >= 0));
      const by = {}; f.forEach((k) => (by[H[k].cat] = by[H[k].cat] || []).push(k));
      $("#lrL").innerHTML = Object.keys(by).sort((a, b) => a.localeCompare(b, "tr")).map((cat) => `<section class="dsec"><h2 class="dsec-t">${esc(cat)} <span class="muted sm">(${by[cat].length})</span></h2><div class="lgrid">${by[cat].sort((a, b) => H[a].t.localeCompare(H[b].t, "tr")).map((k) => `<button class="lcard" data-h="${k}"><b>${esc(H[k].t)}</b><span class="sm muted">${esc(H[k].what.slice(0, 120))}${H[k].what.length > 120 ? "…" : ""}</span></button>`).join("")}</div></section>`).join("") || '<div class="empty-s">Sonuç yok</div>';
    };
    draw();
    $("#lrQ").addEventListener("input", draw);
    $("#lrC").addEventListener("change", draw);
  };

  /* =================== WEB TERMINAL (oc simülasyonu) =================== */
  const SHORT = { po: "pods", pod: "pods", deploy: "deployments", deployment: "deployments", svc: "services", service: "services", cm: "configmaps", pvc: "persistentvolumeclaims", pv: "persistentvolumes", no: "nodes", node: "nodes", ns: "namespaces", rs: "replicasets", sts: "statefulsets", ds: "daemonsets", cj: "cronjobs", hpa: "horizontalpodautoscalers", dc: "deploymentconfigs", bc: "buildconfigs", is: "imagestreams", sc: "storageclasses", sa: "serviceaccounts", netpol: "networkpolicies", ing: "ingresses", csv: "clusterserviceversions", crd: "customresourcedefinitions", mcp: "machineconfigpools", rc: "replicationcontrollers", pdb: "poddisruptionbudgets", quota: "resourcequotas" };
  const pad = (rows) => { const w = rows[0].map((_, i) => Math.max.apply(null, rows.map((r) => String(r[i]).length))); return rows.map((r) => r.map((c, i) => String(c).padEnd(w[i] + 3)).join("").trimEnd()).join("\n"); };
  function ocCmd(line) {
    const a = line.trim().split(/\s+/);
    let ns = OC.st.ns === "all" ? "eticaret-prod" : OC.st.ns;
    const ni = a.indexOf("-n"); if (ni > 0) { ns = a[ni + 1]; a.splice(ni, 2); }
    const all = a.indexOf("-A") > 0 || a.indexOf("--all-namespaces") > 0;
    const c = a[0] === "kubectl" ? "oc" : a[0];
    if (!c) return "";
    if (c === "help") return "Eğitim terminali – desteklenen komutlar:\n  oc whoami | oc project [ad] | oc projects | oc version | oc status\n  oc get <tür> [ad] [-n ns] [-A] [-o yaml]   (pods, deploy, svc, routes, pvc, nodes, cm, secret, co, events…)\n  oc describe pod <ad>   oc logs <pod>   oc explain <tür>\n  oc adm top nodes | oc adm top pods\n  clear";
    if (c !== "oc") return "bash: " + c + ": command not found  (ipucu: 'help')";
    const sub = a[1];
    if (sub === "whoami") return a[2] === "--show-server" ? OC.cluster.api : "egitim.admin";
    if (sub === "version") return "Client Version: 4.20.4\nKustomize Version: v5.5.0\nServer Version: " + OC.cluster.version + "\nKubernetes Version: " + OC.cluster.k8s;
    if (sub === "project") { if (a[2]) { if (!db.Namespace.some((n) => n.metadata.name === a[2])) return 'error: A project named "' + a[2] + '" does not exist on "' + OC.cluster.api + '".'; OC.st.ns = a[2]; U.store.set("ns", a[2]); return 'Now using project "' + a[2] + '" on server "' + OC.cluster.api + '".'; } return 'Using project "' + ns + '" on server "' + OC.cluster.api + '".'; }
    if (sub === "projects") return "You have access to the following projects and can switch between them with ' project <projectname>':\n\n" + db.Project.map((p) => (p.metadata.name === ns ? "  * " : "    ") + p.metadata.name + ((p.metadata.annotations || {})["openshift.io/display-name"] ? " - " + p.metadata.annotations["openshift.io/display-name"] : "")).join("\n");
    if (sub === "status") return "In project " + ns + " on server " + OC.cluster.api + "\n\n" + db.Deployment.filter((d) => d.metadata.namespace === ns).map((d) => "deployment/" + d.metadata.name + " deploys " + R.cnt(d)[0].image + "\n  deployment #" + d.metadata.annotations["deployment.kubernetes.io/revision"] + " running for " + U.age(d.metadata.creationTimestamp) + " - " + d.status.readyReplicas + "/" + d.spec.replicas + " pods").join("\n\n");
    if (sub === "explain") { const k = OC.byPlural[SHORT[a[2]] || a[2]] || Object.keys(K).find((x) => x.toLowerCase() === (a[2] || "").split(".")[0]); return k ? "KIND:     " + k + "\nVERSION:  " + K[k].api + "\n\nDESCRIPTION:\n     " + ((H[K[k].help] || {}).what || "") : "error: couldn't find resource for \"" + a[2] + "\""; }
    if (sub === "adm" && a[2] === "top") return a[3] === "nodes" ? pad([["NAME", "CPU(cores)", "CPU(%)", "MEMORY(bytes)", "MEMORY(%)"]].concat(db.Node.map((n) => [n.metadata.name, Math.round(n._m.cpu * 1000) + "m", Math.round((n._m.cpu / n._cpu) * 100) + "%", Math.round(n._m.mem) + "Mi", Math.round((n._m.mem / 1024 / n._mem) * 100) + "%"]))) : pad([["NAME", "CPU(cores)", "MEMORY(bytes)"]].concat(db.Pod.filter((p) => p.metadata.namespace === ns && p._m.cpu).map((p) => [p.metadata.name, Math.max(1, Math.round(p._m.cpu * 1000)) + "m", Math.round(p._m.mem) + "Mi"])));
    if (sub === "logs") { const p = db.Pod.find((x) => x.metadata.name === a[2] || (a[2] && a[2].indexOf("/") > 0 && x.metadata.name.indexOf(a[2].split("/")[1]) === 0 && x.metadata.namespace === ns)); return p ? "(Logları görmek için konsolda Pod › Logs sekmesini açın)\nPod: " + p.metadata.name : 'error: pods "' + (a[2] || "") + '" not found'; }
    if (sub === "describe") { const k = OC.byPlural[SHORT[a[2]] || a[2]]; const o = k && OC.find(k, ns, a[3]); if (!o) return "error: kaynak bulunamadı. Kullanım: oc describe pod <ad>"; return "Name:         " + o.metadata.name + "\nNamespace:    " + (o.metadata.namespace || "") + "\nLabels:       " + Object.keys(o.metadata.labels || {}).map((x) => x + "=" + o.metadata.labels[x]).join("\n              ") + "\nCreated:      " + o.metadata.creationTimestamp + (k === "Pod" ? "\nNode:         " + (o.spec.nodeName || "<none>") + "\nStatus:       " + OC.podStatus(o) + "\nIP:           " + (o.status.podIP || "") : "") + "\nEvents:\n  Type    Reason   Age   From   Message\n" + db.Event.filter((e) => e.involvedObject.name === o.metadata.name).slice(0, 6).map((e) => "  " + e.type.padEnd(8) + e.reason.padEnd(18) + U.age(e.lastTimestamp).padEnd(6) + e.source.component.padEnd(20) + e.message.slice(0, 80)).join("\n"); }
    if (sub === "get") {
      let what = a[2]; if (!what) return "You must specify the type of resource to get.";
      if (what === "all") what = "pods";
      if (what === "co" || what === "clusteroperators") return pad([["NAME", "VERSION", "AVAILABLE", "PROGRESSING", "DEGRADED", "SINCE"]].concat(OC.clusterOperators.map((c) => [c.name, c.version, "True", "False", "False", U.age(c.since)])));
      if (what === "clusterversion") return pad([["NAME", "VERSION", "AVAILABLE", "PROGRESSING", "SINCE", "STATUS"], ["version", OC.cluster.version, "True", "False", "20d", "Cluster version is " + OC.cluster.version]]);
      if (what === "events" || what === "ev") return pad([["LAST SEEN", "TYPE", "REASON", "OBJECT", "MESSAGE"]].concat(db.Event.filter((e) => all || e.metadata.namespace === ns).slice(0, 15).map((e) => [U.age(e.lastTimestamp), e.type, e.reason, e.involvedObject.kind.toLowerCase() + "/" + e.involvedObject.name, e.message.slice(0, 70)])));
      const kind = OC.byPlural[SHORT[what] || what] || OC.byPlural[what + "s"];
      if (!kind) return 'error: the server doesn\'t have a resource type "' + what + '"';
      const k = K[kind];
      let items = OC.items(kind).filter((o) => !k.ns || all || o.metadata.namespace === ns);
      if (a[3] && a[3][0] !== "-") items = items.filter((o) => o.metadata.name === a[3]);
      if (!items.length) return k.ns ? "No resources found in " + ns + " namespace." : "No resources found";
      if (a.indexOf("-o") > 0 && a[a.indexOf("-o") + 1] === "yaml") return U.yaml(items[0]);
      const nsCol = all && k.ns ? ["NAMESPACE"] : [];
      const row = (o, cols) => (all && k.ns ? [o.metadata.namespace] : []).concat(cols);
      if (kind === "Pod") return pad([nsCol.concat(["NAME", "READY", "STATUS", "RESTARTS", "AGE"])].concat(items.map((p) => row(p, [p.metadata.name, (p.status.containerStatuses || []).filter((c) => c && c.ready).length + "/" + p.spec.containers.length, OC.podStatus(p), (p.status.containerStatuses || []).reduce((x, c) => x + (c ? c.restartCount : 0), 0), U.age(p.metadata.creationTimestamp)]))));
      if (kind === "Deployment") return pad([nsCol.concat(["NAME", "READY", "UP-TO-DATE", "AVAILABLE", "AGE"])].concat(items.map((d) => row(d, [d.metadata.name, d.status.readyReplicas + "/" + d.spec.replicas, d.status.updatedReplicas, d.status.availableReplicas, U.age(d.metadata.creationTimestamp)]))));
      if (kind === "Service") return pad([nsCol.concat(["NAME", "TYPE", "CLUSTER-IP", "EXTERNAL-IP", "PORT(S)", "AGE"])].concat(items.map((s) => row(s, [s.metadata.name, s.spec.type, s.spec.clusterIP || "<none>", s.spec.type === "LoadBalancer" ? "192.168.20.40" : "<none>", (s.spec.ports || []).map((p) => p.port + (p.nodePort ? ":" + p.nodePort : "") + "/" + p.protocol).join(",") || "<none>", U.age(s.metadata.creationTimestamp)]))));
      if (kind === "Route") return pad([nsCol.concat(["NAME", "HOST/PORT", "PATH", "SERVICES", "PORT", "TERMINATION", "WILDCARD"])].concat(items.map((r) => row(r, [r.metadata.name, r.spec.host, r.spec.path || "", r.spec.to.name, r.spec.port ? r.spec.port.targetPort : "", r.spec.tls ? r.spec.tls.termination + (r.spec.tls.insecureEdgeTerminationPolicy ? "/" + r.spec.tls.insecureEdgeTerminationPolicy : "") : "", "None"]))));
      if (kind === "Node") return pad([["NAME", "STATUS", "ROLES", "AGE", "VERSION"]].concat(items.map((n) => [n.metadata.name, n.spec.unschedulable ? "Ready,SchedulingDisabled" : "Ready", Object.keys(n.metadata.labels).filter((x) => x.indexOf("node-role") === 0).map((x) => x.split("/")[1]).join(","), U.age(n.metadata.creationTimestamp), n.status.nodeInfo.kubeletVersion])));
      if (kind === "PersistentVolumeClaim") return pad([nsCol.concat(["NAME", "STATUS", "VOLUME", "CAPACITY", "ACCESS MODES", "STORAGECLASS", "AGE"])].concat(items.map((p) => row(p, [p.metadata.name, p.status.phase, p.spec.volumeName || "", p.status.capacity ? p.status.capacity.storage : "", p.spec.accessModes.map((m) => m.replace(/[a-z]/g, "")).join(","), p.spec.storageClassName, U.age(p.metadata.creationTimestamp)]))));
      return pad([nsCol.concat(["NAME", "AGE"])].concat(items.map((o) => row(o, [o.metadata.name, U.age(o.metadata.creationTimestamp)]))));
    }
    return 'error: unknown command "' + sub + '" for "oc"  (ipucu: help)';
  }
  OC.webTerminal = function () {
    const d = $("#termDrawer");
    if (d.classList.contains("open")) { d.classList.remove("open"); document.body.classList.remove("term-open"); return; }
    d.innerHTML = `<div class="td-h"><b>${U.ico("cube", 12)} OpenShift command line terminal</b>${R.q("ui-terminal")}<span class="muted sm">Proje: ${esc(OC.st.ns === "all" ? "eticaret-prod" : OC.st.ns)}</span><span class="grow"></span><button class="hp-x" id="tdX" title="Kapat">&#10005;</button></div><div class="term" id="webTerm"></div>`;
    d.classList.add("open"); document.body.classList.add("term-open");
    OC.shell($("#webTerm"), ocCmd, "bash-5.1 ~ $ ");
    $("#tdX").onclick = () => { d.classList.remove("open"); document.body.classList.remove("term-open"); };
  };
})();
