/* OpenShift Eğitim Konsolu – simülasyon verileri
   Gerçek cluster bağlantısı YOKTUR. Aşağıdaki nesneler gerçek Kubernetes/OpenShift
   nesne yapısına (metadata/spec/status) birebir uyacak şekilde üretilir. */
(function () {
  "use strict";
  const OC = window.OC, U = OC.u;
  const { pick, ri, hs, hex, uid, ago } = U;
  const S = (OC.db = {});
  const add = (kind, o) => ((S[kind] = S[kind] || []).push(o), o);

  const CL = (OC.cluster = {
    name: "ocp-egitim",
    id: "7c3e9a51-2f4b-4d8e-9a61-3b2c8d0e5f17",
    api: "https://api.ocp-egitim.egitim.local:6443",
    console: "https://console-openshift-console.apps.ocp-egitim.egitim.local",
    domain: "apps.ocp-egitim.egitim.local",
    version: "4.20.4",
    k8s: "v1.33.5",
    channel: "stable-4.20",
    provider: "VSphere",
    infraName: "ocp-egitim-x7k2p",
    updates: ["4.20.5", "4.20.6"]
  });

  function meta(name, ns, ageMin, labels, ann, extra) {
    const m = { name: name };
    if (ns) m.namespace = ns;
    m.uid = uid();
    m.resourceVersion = String(ri(100000, 9900000));
    m.creationTimestamp = ago(ageMin);
    if (labels && Object.keys(labels).length) m.labels = labels;
    if (ann && Object.keys(ann).length) m.annotations = ann;
    return Object.assign(m, extra || {});
  }
  const owner = (o, ctl) => ({ apiVersion: o.apiVersion, kind: o.kind, name: o.metadata.name, uid: o.metadata.uid, controller: ctl !== false, blockOwnerDeletion: true });
  let evN = 0;
  function ev(obj, reason, msg, ageMin, type, comp, count) {
    evN++;
    const ns = obj.metadata.namespace || "default";
    return add("Event", {
      kind: "Event", apiVersion: "v1",
      metadata: meta(obj.metadata.name + "." + hex(16), ns, ageMin),
      involvedObject: { kind: obj.kind, namespace: obj.metadata.namespace, name: obj.metadata.name, uid: obj.metadata.uid, apiVersion: obj.apiVersion },
      reason: reason, message: msg, type: type || "Normal",
      source: { component: comp || "kubelet" },
      firstTimestamp: ago(ageMin + (count > 1 ? ri(30, 600) : 0)), lastTimestamp: ago(ageMin), count: count || 1
    });
  }

  /* ---------------- Nodes ---------------- */
  const NODES = [
    ["master-0", "master", "192.168.10.11", 8, 32], ["master-1", "master", "192.168.10.12", 8, 32], ["master-2", "master", "192.168.10.13", 8, 32],
    ["worker-0", "worker", "192.168.10.21", 16, 64], ["worker-1", "worker", "192.168.10.22", 16, 64], ["worker-2", "worker", "192.168.10.23", 16, 64],
    ["worker-3", "worker", "192.168.10.24", 16, 64], ["infra-0", "infra", "192.168.10.31", 8, 32]
  ];
  NODES.forEach(([n, role, ip, cpu, mem], i) => {
    const name = n + ".ocp-egitim.egitim.local";
    const lab = { "beta.kubernetes.io/arch": "amd64", "beta.kubernetes.io/os": "linux", "kubernetes.io/arch": "amd64", "kubernetes.io/hostname": name, "kubernetes.io/os": "linux", "node.openshift.io/os_id": "rhcos", "topology.kubernetes.io/zone": "dc1-rack" + ((i % 3) + 1) };
    if (role === "master") { lab["node-role.kubernetes.io/control-plane"] = ""; lab["node-role.kubernetes.io/master"] = ""; }
    else if (role === "infra") { lab["node-role.kubernetes.io/infra"] = ""; lab["node-role.kubernetes.io/worker"] = ""; }
    else lab["node-role.kubernetes.io/worker"] = "";
    const cordon = n === "worker-3";
    const spec = { providerID: "vsphere://4211" + hex(4) + "-" + hex(4) + "-" + hex(4) + "-" + hex(12) };
    if (role === "master") spec.taints = [{ key: "node-role.kubernetes.io/master", effect: "NoSchedule" }];
    if (role === "infra") spec.taints = [{ key: "node-role.kubernetes.io/infra", value: "reserved", effect: "NoSchedule" }];
    if (cordon) { spec.unschedulable = true; spec.taints = [{ key: "node.kubernetes.io/unschedulable", effect: "NoSchedule", timeAdded: ago(95) }]; }
    const ki = mem * 1024 * 1024 - ri(100000, 400000);
    const node = add("Node", {
      kind: "Node", apiVersion: "v1",
      metadata: meta(name, null, 60 * 24 * 142 - i * 3, lab, { "machine.openshift.io/machine": "openshift-machine-api/" + CL.infraName + "-" + n, "machineconfiguration.openshift.io/currentConfig": "rendered-" + (role === "master" ? "master" : "worker") + "-" + hex(32), "machineconfiguration.openshift.io/state": "Done", "volumes.kubernetes.io/controller-managed-attach-detach": "true" }),
      spec: spec,
      status: {
        capacity: { cpu: String(cpu), "ephemeral-storage": "125277164Ki", "hugepages-2Mi": "0", memory: ki + "Ki", pods: "250" },
        allocatable: { cpu: (cpu * 1000 - 500) + "m", "ephemeral-storage": "114381692328", memory: (ki - 1153024) + "Ki", pods: "250" },
        conditions: [
          { type: "MemoryPressure", status: "False", reason: "KubeletHasSufficientMemory", message: "kubelet has sufficient memory available", lastHeartbeatTime: ago(1), lastTransitionTime: ago(60 * 24 * 20) },
          { type: "DiskPressure", status: "False", reason: "KubeletHasNoDiskPressure", message: "kubelet has no disk pressure", lastHeartbeatTime: ago(1), lastTransitionTime: ago(60 * 24 * 20) },
          { type: "PIDPressure", status: "False", reason: "KubeletHasSufficientPID", message: "kubelet has sufficient PID available", lastHeartbeatTime: ago(1), lastTransitionTime: ago(60 * 24 * 20) },
          { type: "Ready", status: "True", reason: "KubeletReady", message: "kubelet is posting ready status", lastHeartbeatTime: ago(1), lastTransitionTime: ago(60 * 24 * 20) }
        ],
        addresses: [{ type: "InternalIP", address: ip }, { type: "Hostname", address: name }],
        nodeInfo: { architecture: "amd64", bootID: uid(), containerRuntimeVersion: "cri-o://1.33.5-3.rhaos4.20.gitd0ea985.el9", kernelVersion: "5.14.0-570.49.1.el9_6.x86_64", kubeProxyVersion: "", kubeletVersion: CL.k8s, machineID: hex(32), operatingSystem: "linux", osImage: "Red Hat Enterprise Linux CoreOS 9.6.20251023-0 (Plow)", systemUUID: uid() }
      },
      _role: role, _short: n, _cpu: cpu, _mem: mem,
      _m: { cpu: role === "master" ? 1.6 + U.rnd() * 1.5 : 2 + U.rnd() * 6, mem: (role === "master" ? 12 : 18) * 1024 + U.rnd() * 14000, fs: 30 + U.rnd() * 30 }
    });
    ev(node, "NodeReady", "Node " + name + " status is now: NodeReady", 60 * 24 * 20, "Normal", "kubelet");
    if (cordon) ev(node, "NodeNotSchedulable", "Node " + name + " status is now: NodeNotSchedulable", 95, "Normal", "kubelet");
  });
  const WORKERS = S.Node.filter((n) => n._role === "worker" && !n.spec.unschedulable);
  const nodeByShort = (s) => S.Node.find((n) => n._short === s);

  /* ---------------- Projects / Namespaces ---------------- */
  const PROJ = [
    ["eticaret-prod", "E-Ticaret (Production)", "Canlı e-ticaret uygulaması: web arayüzü, katalog, sepet ve sipariş servisleri", "ayse.yilmaz", 60 * 24 * 120],
    ["eticaret-test", "E-Ticaret (Test)", "E-ticaret uygulamasının test ortamı", "ayse.yilmaz", 60 * 24 * 90],
    ["odeme-api", "Ödeme Servisleri", "Ödeme geçidi ve sahtecilik tespit servisleri (PCI kapsamı)", "mehmet.demir", 60 * 24 * 75],
    ["musteri-portali", "Müşteri Portalı", "S2I ile kaynak koddan derlenen Node.js müşteri portalı", "zeynep.kaya", 60 * 24 * 40],
    ["veri-analitik", "Veri Analitiği", "Kafka, Jupyter ve periyodik analiz işleri", "can.ozturk", 60 * 24 * 30]
  ];
  const SYS = ["default", "kube-system", "kube-public", "openshift", "openshift-apiserver", "openshift-config", "openshift-console", "openshift-dns", "openshift-etcd", "openshift-image-registry", "openshift-ingress", "openshift-ingress-operator", "openshift-machine-api", "openshift-monitoring", "openshift-operators", "openshift-operator-lifecycle-manager", "openshift-pipelines", "openshift-storage", "openshift-gitops"];
  function mkNs(name, disp, desc, req, age) {
    const ann = { "openshift.io/sa.scc.mcs": "s0:c" + ri(20, 40) + ",c" + ri(1, 19), "openshift.io/sa.scc.supplemental-groups": "10006" + ri(10, 99) + "0000/10000", "openshift.io/sa.scc.uid-range": "10006" + ri(10, 99) + "0000/10000" };
    if (disp) ann["openshift.io/display-name"] = disp;
    if (desc) ann["openshift.io/description"] = desc;
    if (req) ann["openshift.io/requester"] = req;
    const lab = { "kubernetes.io/metadata.name": name, "pod-security.kubernetes.io/audit": "restricted", "pod-security.kubernetes.io/audit-version": "latest", "pod-security.kubernetes.io/warn": "restricted", "pod-security.kubernetes.io/warn-version": "latest" };
    if (/^openshift|^kube/.test(name)) lab["openshift.io/cluster-monitoring"] = "true";
    const ns = add("Namespace", { kind: "Namespace", apiVersion: "v1", metadata: meta(name, null, age, lab, ann), spec: { finalizers: ["kubernetes"] }, status: { phase: "Active" }, _user: !!req });
    add("Project", { kind: "Project", apiVersion: "project.openshift.io/v1", metadata: Object.assign({}, ns.metadata, { uid: ns.metadata.uid }), spec: ns.spec, status: ns.status, _user: !!req });
    // her namespace'te otomatik oluşan nesneler
    const t = age - 1;
    add("ConfigMap", { kind: "ConfigMap", apiVersion: "v1", metadata: meta("kube-root-ca.crt", name, t, null, { "kubernetes.io/description": "Contains a CA bundle that can be used to verify the kube-apiserver when using internal endpoints such as the internal service IP or kubernetes.default.svc. No other usage is guaranteed across distributions of Kubernetes clusters." }), data: { "ca.crt": "-----BEGIN CERTIFICATE-----\nMIIDMjCCAhqgAwIBAgIIK4p2...(kısaltıldı)\n-----END CERTIFICATE-----\n" } });
    add("ConfigMap", { kind: "ConfigMap", apiVersion: "v1", metadata: meta("openshift-service-ca.crt", name, t, null, { "service.beta.openshift.io/inject-cabundle": "true" }), data: { "service-ca.crt": "-----BEGIN CERTIFICATE-----\nMIIDUTCCAjmgAwIBAgIIb1f...(kısaltıldı)\n-----END CERTIFICATE-----\n" } });
    ["builder", "default", "deployer"].forEach((sa) => {
      const dock = sa + "-dockercfg-" + hs(5);
      add("ServiceAccount", { kind: "ServiceAccount", apiVersion: "v1", metadata: meta(sa, name, t, null, { "openshift.io/internal-registry-pull-secret-ref": dock }), imagePullSecrets: [{ name: dock }], secrets: [{ name: dock }] });
      add("Secret", { kind: "Secret", apiVersion: "v1", type: "kubernetes.io/dockercfg", metadata: meta(dock, name, t, null, { "kubernetes.io/service-account.name": sa, "openshift.io/internal-registry-auth-token.service-account": sa }), data: { ".dockercfg": "eyJpbWFnZS1yZWdpc3RyeS5vcGVuc2hpZnQtaW1hZ2UtcmVnaXN0cnkuc3ZjOjUwMDAiOnsidXNlcm5hbWUiOiJzZXJ2aWNlYWNjb3VudCJ9fQ==" } });
    });
    if (req) {
      add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("admin", name, t), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "admin" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "User", name: req }] });
      add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("system:image-pullers", name, t, null, { "openshift.io/description": "Allows all pods in this namespace to pull images from this namespace.  It is auto-managed by a controller; remove subjects to disable." }), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "system:image-puller" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "Group", name: "system:serviceaccounts:" + name }] });
      add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("system:image-builders", name, t), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "system:image-builder" }, subjects: [{ kind: "ServiceAccount", name: "builder", namespace: name }] });
      add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("system:deployers", name, t), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "system:deployer" }, subjects: [{ kind: "ServiceAccount", name: "deployer", namespace: name }] });
    }
  }
  PROJ.forEach((p) => mkNs.apply(null, p));
  SYS.forEach((n, i) => mkNs(n, null, null, null, 60 * 24 * 142 - i));

  /* ---------------- Uygulama üreticisi ---------------- */
  let svcIp = 0;
  const nextSvcIp = () => "172.30." + ri(1, 250) + "." + ri(2, 250) + (svcIp++ ? "" : "");
  const podIp = (node) => "10." + (128 + S.Node.indexOf(node)) + "." + ri(0, 1) + "." + ri(10, 250);

  function containerSpec(a) {
    const c = { name: a.cname || a.name, image: a.image, ports: (a.ports || [a.port]).filter(Boolean).map((p) => ({ containerPort: p, protocol: "TCP" })) };
    if (a.env) c.env = a.env;
    if (a.envFrom) c.envFrom = a.envFrom;
    c.resources = { limits: { cpu: a.limCpu || "500m", memory: a.limMem || "512Mi" }, requests: { cpu: a.reqCpu || "100m", memory: a.reqMem || "256Mi" } };
    if (a.probe !== false && a.port) {
      c.readinessProbe = { httpGet: { path: a.probePath || "/health/ready", port: a.port, scheme: "HTTP" }, initialDelaySeconds: 5, periodSeconds: 10, timeoutSeconds: 1, successThreshold: 1, failureThreshold: 3 };
      c.livenessProbe = { httpGet: { path: a.liveness || "/health/live", port: a.port, scheme: "HTTP" }, initialDelaySeconds: 15, periodSeconds: 20, timeoutSeconds: 1, successThreshold: 1, failureThreshold: 3 };
    }
    if (a.cmd) c.command = a.cmd;
    c.imagePullPolicy = "IfNotPresent";
    c.terminationMessagePath = "/dev/termination-log";
    c.terminationMessagePolicy = "File";
    c.securityContext = { allowPrivilegeEscalation: false, capabilities: { drop: ["ALL"] }, runAsNonRoot: true };
    if (a.mounts) c.volumeMounts = a.mounts.slice();
    return c;
  }

  function mkPod(a, ctrl, podName, hash, node, issue, ageMin) {
    const ns = a.ns;
    const lab = Object.assign({}, a.podLabels);
    if (hash) lab["pod-template-hash"] = hash;
    const sa = a.sa || "default";
    const tokVol = "kube-api-access-" + hs(5);
    const c = containerSpec(a);
    c.volumeMounts = (c.volumeMounts || []).concat([{ name: tokVol, readOnly: true, mountPath: "/var/run/secrets/kubernetes.io/serviceaccount" }]);
    const vols = (a.volumes || []).map((v) => JSON.parse(JSON.stringify(v)));
    if (a.pvcPerPod) vols.unshift({ name: a.pvcPerPod.vol, persistentVolumeClaim: { claimName: a.pvcPerPod.vol + "-" + podName } });
    vols.push({ name: tokVol, projected: { sources: [{ serviceAccountToken: { expirationSeconds: 3607, path: "token" } }, { configMap: { name: "kube-root-ca.crt", items: [{ key: "ca.crt", path: "ca.crt" }] } }, { downwardAPI: { items: [{ path: "namespace", fieldRef: { apiVersion: "v1", fieldPath: "metadata.namespace" } }] } }, { configMap: { name: "openshift-service-ca.crt", items: [{ key: "service-ca.crt", path: "service-ca.crt" }] } }], defaultMode: 420 } });
    const pending = issue === "pending";
    const started = ago(ageMin - 0.3);
    const cid = "cri-o://" + hex(64);
    let cst, phase = "Running", ready = true, restarts = 0, conds;
    if (issue === "crash") {
      restarts = ri(24, 61); ready = false;
      cst = { name: c.name, ready: false, restartCount: restarts, started: false, image: a.image, imageID: a.image.split(":")[0] + "@sha256:" + hex(64), containerID: cid, state: { waiting: { reason: "CrashLoopBackOff", message: "back-off 5m0s restarting failed container=" + c.name + " pod=" + podName + "_" + ns + "(" + hex(8) + ")" } }, lastState: { terminated: { exitCode: 1, reason: "Error", startedAt: ago(7), finishedAt: ago(6.8), containerID: cid } } };
    } else if (issue === "imagepull") {
      ready = false;
      cst = { name: c.name, ready: false, restartCount: 0, started: false, image: a.image, imageID: "", state: { waiting: { reason: "ImagePullBackOff", message: "Back-off pulling image \"" + a.image + "\": ErrImagePull: initializing source docker://" + a.image + ": reading manifest " + a.image.split(":")[1] + " in " + a.image.split(":")[0] + ": manifest unknown" } }, lastState: {} };
    } else if (issue === "completed") {
      phase = "Succeeded"; ready = false;
      cst = { name: c.name, ready: false, restartCount: 0, started: false, image: a.image, imageID: a.image.split(":")[0] + "@sha256:" + hex(64), containerID: cid, state: { terminated: { exitCode: 0, reason: "Completed", startedAt: started, finishedAt: ago(ageMin - 1.5), containerID: cid } }, lastState: {} };
    } else if (issue === "failed") {
      phase = "Failed"; ready = false;
      cst = { name: c.name, ready: false, restartCount: 0, started: false, image: a.image, imageID: a.image.split(":")[0] + "@sha256:" + hex(64), containerID: cid, state: { terminated: { exitCode: 2, reason: "Error", startedAt: started, finishedAt: ago(ageMin - 0.8), containerID: cid } }, lastState: {} };
    } else if (pending) {
      phase = "Pending"; ready = false; cst = null;
    } else {
      restarts = U.rnd() < 0.15 ? ri(1, 3) : 0;
      cst = { name: c.name, ready: true, restartCount: restarts, started: true, image: a.image, imageID: a.image.split(":")[0] + "@sha256:" + hex(64), containerID: cid, state: { running: { startedAt: started } }, lastState: restarts ? { terminated: { exitCode: 137, reason: "OOMKilled", startedAt: ago(ageMin - 1), finishedAt: ago(ri(60, 900)), containerID: "cri-o://" + hex(64) } } : {} };
    }
    if (pending) conds = [{ type: "PodScheduled", status: "False", reason: "Unschedulable", message: "0/8 nodes are available: 1 node(s) were unschedulable, 1 node(s) had untolerated taint {node-role.kubernetes.io/infra: reserved}, 3 node(s) had untolerated taint {node-role.kubernetes.io/master: }, 3 Insufficient memory. preemption: 0/8 nodes are available: 3 No preemption victims found for incoming pod, 5 Preemption is not helpful for scheduling.", lastTransitionTime: ago(ageMin) }];
    else conds = [
      { type: "PodReadyToStartContainers", status: phase === "Running" ? "True" : "False", lastTransitionTime: ago(ageMin - 0.2) },
      { type: "Initialized", status: "True", lastTransitionTime: ago(ageMin) },
      { type: "Ready", status: ready ? "True" : "False", lastTransitionTime: ago(ageMin - 0.4), reason: ready ? undefined : (phase === "Succeeded" ? "PodCompleted" : "ContainersNotReady") },
      { type: "ContainersReady", status: ready ? "True" : "False", lastTransitionTime: ago(ageMin - 0.4), reason: ready ? undefined : (phase === "Succeeded" ? "PodCompleted" : "ContainersNotReady") },
      { type: "PodScheduled", status: "True", lastTransitionTime: ago(ageMin) }
    ].map((x) => (x.reason === undefined && delete x.reason, x));
    const ann = { "k8s.ovn.org/pod-networks": '{"default":{"ip_addresses":["' + "10.x" + '/23"],"role":"primary"}}', "openshift.io/scc": a.scc || "restricted-v2", "seccomp.security.alpha.kubernetes.io/pod": "runtime/default" };
    const ip = pending ? null : podIp(node);
    if (ip) ann["k8s.ovn.org/pod-networks"] = '{"default":{"ip_addresses":["' + ip + '/23"],"mac_address":"0a:58:' + hex(2) + ":" + hex(2) + ":" + hex(2) + ":" + hex(2) + '","gateway_ips":["' + ip.replace(/\.\d+$/, ".1") + '"],"role":"primary"}}';
    ann["k8s.v1.cni.cncf.io/network-status"] = ip ? '[{"name":"ovn-kubernetes","interface":"eth0","ips":["' + ip + '"],"default":true}]' : undefined;
    if (!ip) delete ann["k8s.v1.cni.cncf.io/network-status"];
    const spec = {
      volumes: vols, containers: [c], restartPolicy: a.restart || "Always", terminationGracePeriodSeconds: 30, dnsPolicy: "ClusterFirst",
      serviceAccountName: sa, serviceAccount: sa
    };
    if (!pending) spec.nodeName = node.metadata.name;
    Object.assign(spec, {
      securityContext: { seLinuxOptions: { level: "s0:c27,c4" }, fsGroup: 1000660000, seccompProfile: { type: "RuntimeDefault" } },
      imagePullSecrets: [{ name: sa + "-dockercfg-" + hs(5) }], schedulerName: "default-scheduler",
      tolerations: (a.tolerations || []).concat([{ key: "node.kubernetes.io/not-ready", operator: "Exists", effect: "NoExecute", tolerationSeconds: 300 }, { key: "node.kubernetes.io/unreachable", operator: "Exists", effect: "NoExecute", tolerationSeconds: 300 }, { key: "node.kubernetes.io/memory-pressure", operator: "Exists", effect: "NoSchedule" }]),
      priority: a.priority || 0, enableServiceLinks: true, preemptionPolicy: "PreemptLowerPriority"
    });
    if (a.nodeSelector) spec.nodeSelector = a.nodeSelector;
    if (a.hostname) { spec.hostname = podName; spec.subdomain = a.hostname; }
    const status = { phase: phase, conditions: conds, qosClass: "Burstable" };
    if (!pending) Object.assign(status, { hostIP: node.status.addresses[0].address, hostIPs: [{ ip: node.status.addresses[0].address }], podIP: ip, podIPs: [{ ip: ip }], startTime: ago(ageMin), containerStatuses: [cst] });
    const pod = add("Pod", {
      kind: "Pod", apiVersion: "v1",
      metadata: meta(podName, ns, ageMin, lab, ann, ctrl ? { generateName: podName.replace(/[^-]+$/, ""), ownerReferences: [owner(ctrl)] } : {}),
      spec: spec, status: status,
      _m: { cpu: phase === "Running" && ready ? (a.cpuUse || 0.01) * (0.6 + U.rnd() * 0.8) : 0, mem: phase === "Running" && !pending ? (a.memUse || 120) * (0.8 + U.rnd() * 0.4) : 0 },
      _app: a
    });
    if (!pending) {
      ev(pod, "Scheduled", "Successfully assigned " + ns + "/" + podName + " to " + node.metadata.name, ageMin, "Normal", "default-scheduler");
      ev(pod, "AddedInterface", "Add eth0 [" + ip + "/23] from ovn-kubernetes", ageMin - 0.1, "Normal", "multus");
      if (issue === "imagepull") {
        ev(pod, "Pulling", "Pulling image \"" + a.image + "\"", 3, "Normal", "kubelet", 14);
        ev(pod, "Failed", "Failed to pull image \"" + a.image + "\": reading manifest " + a.image.split(":")[1] + " in " + a.image.split(":")[0] + ": manifest unknown", 3, "Warning", "kubelet", 14);
        ev(pod, "BackOff", "Back-off pulling image \"" + a.image + "\"", 1, "Normal", "kubelet", 52);
      } else {
        ev(pod, "Pulled", "Container image \"" + a.image + "\" already present on machine", ageMin - 0.2, "Normal", "kubelet");
        ev(pod, "Created", "Created container: " + c.name, ageMin - 0.25, "Normal", "kubelet");
        ev(pod, "Started", "Started container " + c.name, ageMin - 0.3, "Normal", "kubelet");
      }
      if (issue === "crash") ev(pod, "BackOff", "Back-off restarting failed container " + c.name + " in pod " + podName + "_" + ns + "(" + pod.metadata.uid + ")", 2, "Warning", "kubelet", restarts * 9);
      if (issue === "crash") ev(pod, "Unhealthy", "Readiness probe failed: Get \"http://" + ip + ":" + a.port + "/health/ready\": dial tcp " + ip + ":" + a.port + ": connect: connection refused", 7, "Warning", "kubelet", restarts * 3);
    } else ev(pod, "FailedScheduling", conds[0].message, 4, "Warning", "default-scheduler", 38);
    return pod;
  }

  function mkSvc(a, opts) {
    opts = opts || {};
    const ip = opts.headless ? "None" : nextSvcIp();
    const svc = add("Service", {
      kind: "Service", apiVersion: "v1",
      metadata: meta(opts.name || a.name, a.ns, a.age, Object.assign({ app: a.name }, a.baseLabels), opts.ann),
      spec: Object.assign({
        clusterIP: ip, clusterIPs: [ip], internalTrafficPolicy: "Cluster", ipFamilies: ["IPv4"], ipFamilyPolicy: "SingleStack",
        ports: (a.svcPorts || [{ name: a.port + "-tcp", port: a.port, targetPort: a.port }]).map((p) => Object.assign({ protocol: "TCP" }, p)),
        selector: a.selector, sessionAffinity: "None", type: opts.type || "ClusterIP"
      }, opts.spec || {}),
      status: { loadBalancer: opts.lb || {} }
    });
    if (opts.type === "NodePort") svc.spec.ports.forEach((p) => (p.nodePort = ri(30000, 32767)));
    if (opts.type === "LoadBalancer") { svc.spec.ports.forEach((p) => (p.nodePort = ri(30000, 32767))); svc.spec.externalTrafficPolicy = "Cluster"; svc.status.loadBalancer = { ingress: [{ ip: "192.168.20.40" }] }; }
    return svc;
  }
  function mkRoute(a, host, tls, path) {
    const r = add("Route", {
      kind: "Route", apiVersion: "route.openshift.io/v1",
      metadata: meta(a.routeName || a.name, a.ns, a.age - 1, Object.assign({ app: a.name }, a.baseLabels), { "openshift.io/host.generated": host ? "false" : "true", "haproxy.router.openshift.io/timeout": "60s" }),
      spec: { host: host || a.name + "-" + a.ns + "." + CL.domain, to: { kind: "Service", name: a.name, weight: 100 }, port: { targetPort: a.port + "-tcp" }, wildcardPolicy: "None" },
      status: {}
    });
    if (path) r.spec.path = path;
    if (tls) r.spec.tls = typeof tls === "object" ? tls : { termination: "edge", insecureEdgeTerminationPolicy: "Redirect" };
    r.status.ingress = [{ host: r.spec.host, routerName: "default", routerCanonicalHostname: "router-default." + CL.domain, wildcardPolicy: "None", conditions: [{ type: "Admitted", status: "True", lastTransitionTime: ago(a.age - 1) }] }];
    return r;
  }

  const SC_DEFAULT = "thin-csi";
  function mkPvc(name, ns, size, ageMin, sc, mode, labels, status) {
    sc = sc || SC_DEFAULT;
    const pvName = "pvc-" + uid();
    const bound = status !== "Pending";
    const pvc = add("PersistentVolumeClaim", {
      kind: "PersistentVolumeClaim", apiVersion: "v1",
      metadata: meta(name, ns, ageMin, labels, bound ? { "pv.kubernetes.io/bind-completed": "yes", "pv.kubernetes.io/bound-by-controller": "yes", "volume.beta.kubernetes.io/storage-provisioner": scProv(sc), "volume.kubernetes.io/storage-provisioner": scProv(sc) } : { "volume.kubernetes.io/storage-provisioner": scProv(sc) }, { finalizers: ["kubernetes.io/pvc-protection"] }),
      spec: { accessModes: [mode || "ReadWriteOnce"], resources: { requests: { storage: size } }, storageClassName: sc, volumeMode: "Filesystem" },
      status: bound ? { phase: "Bound", accessModes: [mode || "ReadWriteOnce"], capacity: { storage: size } } : { phase: "Pending" },
      _used: bound ? parseFloat(size) * (0.15 + U.rnd() * 0.6) : 0
    });
    if (bound) {
      pvc.spec.volumeName = pvName;
      const pv = add("PersistentVolume", {
        kind: "PersistentVolume", apiVersion: "v1",
        metadata: meta(pvName, null, ageMin - 0.1, null, { "pv.kubernetes.io/provisioned-by": scProv(sc), "volume.kubernetes.io/provisioner-deletion-secret-name": "", "volume.kubernetes.io/provisioner-deletion-secret-namespace": "" }, { finalizers: ["external-provisioner.volume.kubernetes.io/finalizer", "kubernetes.io/pv-protection"] }),
        spec: { accessModes: [mode || "ReadWriteOnce"], capacity: { storage: size }, claimRef: { apiVersion: "v1", kind: "PersistentVolumeClaim", name: name, namespace: ns, uid: pvc.metadata.uid }, csi: { driver: scProv(sc), fsType: "ext4", volumeHandle: sc === "thin-csi" ? "file://" + uid() : "0001-0011-openshift-storage-0000000000000001-" + uid() }, persistentVolumeReclaimPolicy: "Delete", storageClassName: sc, volumeMode: "Filesystem" },
        status: { phase: "Bound", lastPhaseTransitionTime: ago(ageMin - 0.1) }
      });
      ev(pvc, "ProvisioningSucceeded", "Successfully provisioned volume " + pvName, ageMin - 0.1, "Normal", scProv(sc) + "_" + "csi-provisioner");
      pvc._pv = pv;
    } else {
      ev(pvc, "ExternalProvisioning", "Waiting for a volume to be created either by the external provisioner '" + scProv(sc) + "' or manually by the system administrator. If volume creation is delayed, please verify that the provisioner is running and correctly registered.", 2, "Normal", "persistentvolume-controller", 44);
    }
    return pvc;
  }
  function scProv(sc) { return sc === "thin-csi" ? "csi.vsphere.vmware.com" : sc === "ocs-storagecluster-cephfs" ? "openshift-storage.cephfs.csi.ceph.com" : "openshift-storage.rbd.csi.ceph.com"; }

  function app(a) {
    a.age = a.age || 60 * 24 * ri(3, 40);
    a.kind = a.kind || "Deployment";
    a.baseLabels = Object.assign({ "app.kubernetes.io/name": a.name, "app.kubernetes.io/component": a.component || a.name, "app.kubernetes.io/instance": a.name }, a.partOf ? { "app.kubernetes.io/part-of": a.partOf } : {}, a.runtime ? { "app.openshift.io/runtime": a.runtime } : {}, a.extraLabels || {});
    a.selector = a.kind === "DeploymentConfig" ? { app: a.name, deploymentconfig: a.name } : { app: a.name };
    a.podLabels = Object.assign({}, a.selector, a.kind === "DeploymentConfig" ? {} : { "app.kubernetes.io/name": a.name });
    const ann = Object.assign({}, a.vcs ? { "app.openshift.io/vcs-uri": a.vcs, "app.openshift.io/vcs-ref": "main" } : {}, a.connects ? { "app.openshift.io/connects-to": JSON.stringify(a.connects.map((n) => ({ apiVersion: "apps/v1", kind: n[1] || "Deployment", name: n[0] }))) } : {});
    const tmpl = { metadata: { labels: a.podLabels, annotations: a.restartedAt ? { "kubectl.kubernetes.io/restartedAt": a.restartedAt } : undefined }, spec: { containers: [containerSpec(a)], restartPolicy: "Always", terminationGracePeriodSeconds: 30, dnsPolicy: "ClusterFirst", schedulerName: "default-scheduler", securityContext: {} } };
    if (!tmpl.metadata.annotations) delete tmpl.metadata.annotations;
    if (a.volumes) tmpl.spec.volumes = a.volumes;
    if (a.sa) tmpl.spec.serviceAccountName = a.sa;
    if (a.nodeSelector) tmpl.spec.nodeSelector = a.nodeSelector;
    if (a.tolerations) tmpl.spec.tolerations = a.tolerations;
    let ctrl, podOwner, hash;
    const issueFor = (i) => (a.issues && a.issues[i]) || null;
    const want = a.replicas;
    const readyN = Array.from({ length: want }, (_, i) => issueFor(i)).filter((x) => !x).length;
    const pickNode = (i) => (a.nodes ? a.nodes[i % a.nodes.length] : WORKERS[(i + a.name.length) % WORKERS.length]);

    if (a.kind === "Deployment") {
      const rev = a.rev || ri(1, 6);
      hash = hs(ri(9, 10));
      ctrl = add("Deployment", {
        kind: "Deployment", apiVersion: "apps/v1",
        metadata: meta(a.name, a.ns, a.age, a.baseLabels, Object.assign({ "deployment.kubernetes.io/revision": String(rev) }, ann), { generation: rev + ri(0, 3) }),
        spec: { replicas: want, selector: { matchLabels: a.selector }, template: tmpl, strategy: a.strategy || { type: "RollingUpdate", rollingUpdate: { maxUnavailable: "25%", maxSurge: "25%" } }, revisionHistoryLimit: 10, progressDeadlineSeconds: 600 },
        status: { observedGeneration: rev, replicas: want, updatedReplicas: want, readyReplicas: readyN, availableReplicas: readyN, unavailableReplicas: want - readyN || undefined, conditions: [{ type: "Available", status: readyN >= Math.max(1, Math.ceil(want * 0.75)) ? "True" : "False", lastUpdateTime: ago(a.age - 1), lastTransitionTime: ago(a.age - 1), reason: readyN >= Math.ceil(want * 0.75) ? "MinimumReplicasAvailable" : "MinimumReplicasUnavailable", message: readyN >= Math.ceil(want * 0.75) ? "Deployment has minimum availability." : "Deployment does not have minimum availability." }, { type: "Progressing", status: "True", lastUpdateTime: ago(a.podAge || 60 * 20), lastTransitionTime: ago(a.age - 1), reason: "NewReplicaSetAvailable", message: "ReplicaSet \"" + a.name + "-" + hash + "\" has successfully progressed." }] },
        _app: a
      });
      if (!ctrl.status.unavailableReplicas) delete ctrl.status.unavailableReplicas;
      for (let r = Math.max(1, rev - 2); r <= rev; r++) {
        const cur = r === rev;
        const h = cur ? hash : hs(10);
        const rs = add("ReplicaSet", {
          kind: "ReplicaSet", apiVersion: "apps/v1",
          metadata: meta(a.name + "-" + h, a.ns, cur ? (a.podAge || 60 * 20) + 1 : a.age - (r * 60 * 24) % a.age, Object.assign({}, a.podLabels, { "pod-template-hash": h }), { "deployment.kubernetes.io/desired-replicas": String(want), "deployment.kubernetes.io/max-replicas": String(want + Math.ceil(want / 4)), "deployment.kubernetes.io/revision": String(r) }, { ownerReferences: [owner(ctrl)] }),
          spec: { replicas: cur ? want : 0, selector: { matchLabels: Object.assign({}, a.selector, { "pod-template-hash": h }) }, template: tmpl },
          status: cur ? { replicas: want, fullyLabeledReplicas: want, readyReplicas: readyN, availableReplicas: readyN, observedGeneration: 1 } : { replicas: 0, observedGeneration: 2 }
        });
        if (cur) { podOwner = rs; ev(ctrl, "ScalingReplicaSet", "Scaled up replica set " + rs.metadata.name + " from 0 to " + want, (a.podAge || 60 * 20) + 1, "Normal", "deployment-controller"); }
        else ev(ctrl, "ScalingReplicaSet", "Scaled down replica set " + rs.metadata.name + " from " + want + " to 0", (a.podAge || 60 * 20) - 2, "Normal", "deployment-controller");
      }
    } else if (a.kind === "DeploymentConfig") {
      const v = a.rev || ri(2, 7);
      ctrl = add("DeploymentConfig", {
        kind: "DeploymentConfig", apiVersion: "apps.openshift.io/v1",
        metadata: meta(a.name, a.ns, a.age, a.baseLabels, ann, { generation: v + 2 }),
        spec: { strategy: { type: "Rolling", rollingParams: { updatePeriodSeconds: 1, intervalSeconds: 1, timeoutSeconds: 600, maxUnavailable: "25%", maxSurge: "25%" }, resources: {}, activeDeadlineSeconds: 21600 }, triggers: [{ type: "ConfigChange" }, { type: "ImageChange", imageChangeParams: { automatic: true, containerNames: [a.name], from: { kind: "ImageStreamTag", namespace: a.ns, name: a.name + ":latest" }, lastTriggeredImage: a.image } }], replicas: want, revisionHistoryLimit: 10, test: false, selector: a.selector, template: tmpl },
        status: { latestVersion: v, observedGeneration: v + 2, replicas: want, updatedReplicas: want, availableReplicas: readyN, unavailableReplicas: want - readyN, readyReplicas: readyN, details: { message: "image change", causes: [{ type: "ImageChange", imageTrigger: { from: { kind: "DockerImage", name: a.image } } }] }, conditions: [{ type: "Available", status: "True", lastUpdateTime: ago(a.age - 1), lastTransitionTime: ago(a.age - 1), message: "Deployment config has minimum availability." }, { type: "Progressing", status: "True", lastUpdateTime: ago(a.podAge || 600), lastTransitionTime: ago(a.podAge || 600), reason: "NewReplicationControllerAvailable", message: "replication controller \"" + a.name + "-" + v + "\" successfully rolled out" }] },
        _app: a
      });
      for (let r = Math.max(1, v - 2); r <= v; r++) {
        const cur = r === v;
        const rc = add("ReplicationController", {
          kind: "ReplicationController", apiVersion: "v1",
          metadata: meta(a.name + "-" + r, a.ns, cur ? (a.podAge || 600) + 1 : a.age - r * 300, Object.assign({}, a.baseLabels, { "openshift.io/deployment-config.name": a.name }), { "openshift.io/deployer-pod.completed-at": ago((a.podAge || 600) - 1), "openshift.io/deployer-pod.name": a.name + "-" + r + "-deploy", "openshift.io/deployment-config.latest-version": String(r), "openshift.io/deployment-config.name": a.name, "openshift.io/deployment.phase": "Complete", "openshift.io/deployment.replicas": String(cur ? want : 0), "openshift.io/deployment.status-reason": r === 1 ? "config change" : "image change" }, { ownerReferences: [owner(ctrl)] }),
          spec: { replicas: cur ? want : 0, selector: Object.assign({}, a.selector, { deployment: a.name + "-" + r }), template: tmpl },
          status: cur ? { replicas: want, fullyLabeledReplicas: want, readyReplicas: readyN, availableReplicas: readyN, observedGeneration: 2 } : { replicas: 0, observedGeneration: 3 }
        });
        if (cur) podOwner = rc;
        ev(ctrl, "DeploymentCreated", "Created new replication controller \"" + rc.metadata.name + "\" for version " + r, cur ? (a.podAge || 600) + 1 : a.age - r * 300, "Normal", "deploymentconfig-controller");
      }
      a.podLabels = Object.assign({}, a.podLabels, { deployment: a.name + "-" + v, deploymentconfig: a.name });
    } else if (a.kind === "StatefulSet") {
      hash = a.name + "-" + hs(10);
      ctrl = add("StatefulSet", {
        kind: "StatefulSet", apiVersion: "apps/v1",
        metadata: meta(a.name, a.ns, a.age, a.baseLabels, ann, { generation: ri(1, 4) }),
        spec: { replicas: want, selector: { matchLabels: a.selector }, template: tmpl, serviceName: a.name + "-headless", podManagementPolicy: "OrderedReady", updateStrategy: { type: "RollingUpdate", rollingUpdate: { partition: 0 } }, revisionHistoryLimit: 10, persistentVolumeClaimRetentionPolicy: { whenDeleted: "Retain", whenScaled: "Retain" }, volumeClaimTemplates: a.pvcPerPod ? [{ apiVersion: "v1", kind: "PersistentVolumeClaim", metadata: { name: a.pvcPerPod.vol }, spec: { accessModes: ["ReadWriteOnce"], storageClassName: a.pvcPerPod.sc || SC_DEFAULT, resources: { requests: { storage: a.pvcPerPod.size } }, volumeMode: "Filesystem" } }] : [] },
        status: { observedGeneration: 2, replicas: want, readyReplicas: readyN, currentReplicas: want, updatedReplicas: want, availableReplicas: readyN, currentRevision: hash, updateRevision: hash, collisionCount: 0 },
        _app: a
      });
      add("ControllerRevision", { kind: "ControllerRevision", apiVersion: "apps/v1", metadata: meta(hash, a.ns, a.age, a.podLabels, null, { ownerReferences: [owner(ctrl)] }), revision: 1 });
      podOwner = ctrl;
      a.hostname = a.name + "-headless";
      mkSvc(a, { name: a.name + "-headless", headless: true, spec: { publishNotReadyAddresses: true } });
    } else if (a.kind === "DaemonSet") {
      hash = String(ri(5000000, 9999999)).slice(0, 7) + hs(3);
      const nodes = a.dsNodes || S.Node;
      ctrl = add("DaemonSet", {
        kind: "DaemonSet", apiVersion: "apps/v1",
        metadata: meta(a.name, a.ns, a.age, a.baseLabels, Object.assign({ "deprecated.daemonset.template.generation": "3" }, ann), { generation: 3 }),
        spec: { selector: { matchLabels: a.selector }, template: tmpl, updateStrategy: { type: "RollingUpdate", rollingUpdate: { maxUnavailable: "10%", maxSurge: 0 } }, revisionHistoryLimit: 10 },
        status: { currentNumberScheduled: nodes.length, numberMisscheduled: 0, desiredNumberScheduled: nodes.length, numberReady: nodes.length, observedGeneration: 3, updatedNumberScheduled: nodes.length, numberAvailable: nodes.length },
        _app: a
      });
      podOwner = ctrl;
      a.replicas = nodes.length;
      a.nodes = nodes;
    }
    a.ctrl = ctrl;
    // Pods
    const pods = [];
    for (let i = 0; i < a.replicas; i++) {
      const pn = a.kind === "StatefulSet" ? a.name + "-" + i : a.kind === "DaemonSet" ? a.name + "-" + hs(5) : a.kind === "DeploymentConfig" ? a.name + "-" + (ctrl.status.latestVersion) + "-" + hs(5) : a.name + "-" + hash + "-" + hs(5);
      if (a.pvcPerPod) mkPvc(a.pvcPerPod.vol + "-" + pn, a.ns, a.pvcPerPod.size, a.age - 0.5, a.pvcPerPod.sc, null, a.podLabels);
      const issue = issueFor(i);
      pods.push(mkPod(a, podOwner, pn, a.kind === "Deployment" ? hash : null, pickNode(i), issue, issue === "crash" ? 60 * 26 : (a.podAge || ri(60 * 3, 60 * 24 * 6)) - i * 0.5));
      if (a.kind === "StatefulSet") ev(ctrl, "SuccessfulCreate", "create Pod " + pn + " in StatefulSet " + a.name + " successful", a.age - i, "Normal", "statefulset-controller");
      else if (a.kind === "Deployment") ev(podOwner, "SuccessfulCreate", "Created pod: " + pn, (a.podAge || 600) - i * 0.5, "Normal", "replicaset-controller");
    }
    a.pods = pods;
    if (a.port && a.svc !== false && a.kind !== "DaemonSet") a.service = mkSvc(a, a.svcOpts);
    if (a.route) a.routeObj = mkRoute(a, a.route === true ? null : a.route, a.tls !== false ? (a.tls || true) : null, a.routePath);
    return a;
  }

  /* ---------------- ConfigMap / Secret yardımcıları ---------------- */
  const cm = (name, ns, data, age, labels) => add("ConfigMap", { kind: "ConfigMap", apiVersion: "v1", metadata: meta(name, ns, age || 60 * 24 * 10, labels), data: data });
  const b64 = (s) => btoa(unescape(encodeURIComponent(s)));
  const secret = (name, ns, type, data, age, labels, ann) => {
    const d = {}; Object.keys(data).forEach((k) => (d[k] = b64(data[k])));
    return add("Secret", { kind: "Secret", apiVersion: "v1", type: type || "Opaque", metadata: meta(name, ns, age || 60 * 24 * 10, labels, ann), data: d });
  };
  const PEM = "-----BEGIN CERTIFICATE-----\nMIIFZTCCA02gAwIBAgIUQ1V0aXRpbS1lZ2l0aW0tc2VydGlmaWthc2kwDQYJKoZI\n...(eğitim amaçlı örnek sertifika)...\n-----END CERTIFICATE-----\n";
  const KEY = "-----BEGIN PRIVATE KEY-----\n(gizli anahtar – eğitim örneği)\n-----END PRIVATE KEY-----\n";

  /* ================= eticaret-prod ================= */
  const EP = "eticaret-prod";
  cm("frontend-nginx-conf", EP, { "nginx.conf": "worker_processes auto;\nevents { worker_connections 1024; }\nhttp {\n  server {\n    listen 8080;\n    root /opt/app-root/src;\n    location /api/ { proxy_pass http://katalog-api:8080/; }\n    location / { try_files $uri /index.html; }\n  }\n}\n" }, 60 * 24 * 30, { app: "frontend" });
  cm("katalog-api-config", EP, { "application.properties": "quarkus.http.port=8080\nquarkus.datasource.jdbc.url=jdbc:postgresql://postgresql:5432/katalog\nquarkus.log.level=INFO\nkatalog.cache.ttl=300\n", LOG_LEVEL: "INFO", CACHE_ENABLED: "true" }, 60 * 24 * 25, { app: "katalog-api" });
  cm("sepet-api-config", EP, { REDIS_HOST: "redis", REDIS_PORT: "6379", SESSION_TIMEOUT: "1800" }, 60 * 24 * 25, { app: "sepet-api" });
  cm("feature-flags", EP, { "flags.json": '{\n  "yeniOdemeSayfasi": true,\n  "kampanyaBanner": false,\n  "oneriMotoru": true\n}\n' }, 60 * 24 * 2);
  secret("postgresql", EP, "Opaque", { "database-name": "katalog", "database-user": "katalog_app", "database-password": "Egt!m-Ornek-Sifre-01" }, 60 * 24 * 60, { app: "postgresql", "template": "postgresql-persistent-template" });
  secret("redis", EP, "Opaque", { "database-password": "redis-ornek-parola" }, 60 * 24 * 60, { app: "redis" });
  secret("shop-tls", EP, "kubernetes.io/tls", { "tls.crt": PEM, "tls.key": KEY }, 60 * 24 * 45);
  secret("quay-pull-secret", EP, "kubernetes.io/dockerconfigjson", { ".dockerconfigjson": '{"auths":{"quay.io":{"auth":"ZWdpdGltOm9ybmVr"}}}' }, 60 * 24 * 60);
  secret("rabbitmq-credentials", EP, "Opaque", { username: "eticaret", password: "rmq-ornek-parola", "erlang-cookie": "ORNEKERLANGCOOKIE" }, 60 * 24 * 60, { app: "rabbitmq" });
  const envDb = [{ name: "DB_HOST", value: "postgresql" }, { name: "DB_NAME", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-name" } } }, { name: "DB_USER", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-user" } } }, { name: "DB_PASSWORD", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-password" } } }];

  const fe = app({ ns: EP, name: "frontend", image: "quay.io/eticaret/frontend:2.4.1", replicas: 3, port: 8080, route: "shop." + CL.domain, tls: { termination: "edge", insecureEdgeTerminationPolicy: "Redirect" }, partOf: "eticaret", runtime: "nginx", component: "frontend", cpuUse: 0.018, memUse: 42, probePath: "/", liveness: "/", rev: 7, podAge: 60 * 31, vcs: "https://git.egitim.local/eticaret/frontend.git", connects: [["katalog-api"], ["sepet-api"]], volumes: [{ name: "nginx-conf", configMap: { name: "frontend-nginx-conf", defaultMode: 420 } }], mounts: [{ name: "nginx-conf", mountPath: "/etc/nginx/nginx.conf", subPath: "nginx.conf" }], reqCpu: "50m", reqMem: "64Mi", limCpu: "250m", limMem: "128Mi", env: [{ name: "API_URL", value: "/api" }, { name: "NODE_ENV", value: "production" }] });
  const kat = app({ ns: EP, name: "katalog-api", image: "quay.io/eticaret/katalog-api:1.12.0", replicas: 2, port: 8080, route: true, routeName: "katalog-api", partOf: "eticaret", runtime: "quarkus", component: "backend", cpuUse: 0.09, memUse: 310, rev: 12, podAge: 60 * 52, connects: [["postgresql", "StatefulSet"]], env: envDb.concat([{ name: "QUARKUS_PROFILE", value: "prod" }]), envFrom: [{ configMapRef: { name: "katalog-api-config" } }], reqMem: "384Mi", limMem: "768Mi", limCpu: "1" });
  app({ ns: EP, name: "sepet-api", image: "quay.io/eticaret/sepet-api:3.0.2", replicas: 2, port: 8080, partOf: "eticaret", runtime: "golang", component: "backend", cpuUse: 0.03, memUse: 38, rev: 5, podAge: 60 * 24 * 2, connects: [["redis", "StatefulSet"], ["rabbitmq", "StatefulSet"]], envFrom: [{ configMapRef: { name: "sepet-api-config" } }], env: [{ name: "REDIS_PASSWORD", valueFrom: { secretKeyRef: { name: "redis", key: "database-password" } } }], reqMem: "64Mi", limMem: "256Mi" });
  app({ ns: EP, name: "siparis-servisi", kind: "DeploymentConfig", image: "image-registry.openshift-image-registry.svc:5000/eticaret-prod/siparis-servisi@sha256:" + hex(64), replicas: 2, port: 8080, partOf: "eticaret", runtime: "spring-boot", component: "backend", cpuUse: 0.05, memUse: 420, rev: 4, podAge: 60 * 24 * 4, connects: [["postgresql", "StatefulSet"], ["rabbitmq", "StatefulSet"]], env: envDb.concat([{ name: "SPRING_PROFILES_ACTIVE", value: "prod" }, { name: "JAVA_OPTS_APPEND", value: "-XX:MaxRAMPercentage=75" }]), reqMem: "512Mi", limMem: "1Gi", limCpu: "1" });
  app({ ns: EP, name: "postgresql", kind: "StatefulSet", image: "registry.redhat.io/rhel9/postgresql-16:1-24", replicas: 1, port: 5432, probe: false, partOf: "eticaret", runtime: "postgresql", component: "database", cpuUse: 0.04, memUse: 260, podAge: 60 * 24 * 18, pvcPerPod: { vol: "data", size: "20Gi", sc: "ocs-storagecluster-ceph-rbd" }, mounts: [{ name: "data", mountPath: "/var/lib/pgsql/data" }], env: [{ name: "POSTGRESQL_USER", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-user" } } }, { name: "POSTGRESQL_PASSWORD", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-password" } } }, { name: "POSTGRESQL_DATABASE", valueFrom: { secretKeyRef: { name: "postgresql", key: "database-name" } } }], reqMem: "512Mi", limMem: "1Gi", limCpu: "1" });
  app({ ns: EP, name: "redis", kind: "StatefulSet", image: "registry.redhat.io/rhel9/redis-7:1-31", replicas: 1, port: 6379, probe: false, partOf: "eticaret", runtime: "redis", component: "cache", cpuUse: 0.008, memUse: 22, podAge: 60 * 24 * 18, pvcPerPod: { vol: "redis-data", size: "2Gi" }, mounts: [{ name: "redis-data", mountPath: "/var/lib/redis/data" }], env: [{ name: "REDIS_PASSWORD", valueFrom: { secretKeyRef: { name: "redis", key: "database-password" } } }], reqMem: "64Mi", limMem: "256Mi" });
  app({ ns: EP, name: "rabbitmq", kind: "StatefulSet", image: "docker.io/library/rabbitmq:3.13-management", replicas: 3, port: 5672, probe: false, partOf: "eticaret", runtime: "rabbitmq", component: "messaging", cpuUse: 0.06, memUse: 180, podAge: 60 * 24 * 9, pvcPerPod: { vol: "rabbitmq-data", size: "5Gi" }, mounts: [{ name: "rabbitmq-data", mountPath: "/var/lib/rabbitmq" }], svcPorts: [{ name: "amqp", port: 5672, targetPort: 5672 }, { name: "management", port: 15672, targetPort: 15672 }], ports: [5672, 15672], envFrom: [{ secretRef: { name: "rabbitmq-credentials" } }] });
  mkPvc("urun-gorselleri", EP, "50Gi", 60 * 24 * 60, "ocs-storagecluster-cephfs", "ReadWriteMany", { app: "frontend" });

  /* HPA / PDB / Ingress / NetworkPolicy / Quota */
  add("HorizontalPodAutoscaler", { kind: "HorizontalPodAutoscaler", apiVersion: "autoscaling/v2", metadata: meta("frontend", EP, 60 * 24 * 20), spec: { scaleTargetRef: { apiVersion: "apps/v1", kind: "Deployment", name: "frontend" }, minReplicas: 3, maxReplicas: 10, metrics: [{ type: "Resource", resource: { name: "cpu", target: { type: "Utilization", averageUtilization: 70 } } }], behavior: { scaleDown: { stabilizationWindowSeconds: 300, policies: [{ type: "Percent", value: 100, periodSeconds: 15 }], selectPolicy: "Max" } } }, status: { currentReplicas: 3, desiredReplicas: 3, currentMetrics: [{ type: "Resource", resource: { name: "cpu", current: { averageUtilization: 34, averageValue: "17m" } } }], lastScaleTime: ago(60 * 31), conditions: [{ type: "AbleToScale", status: "True", reason: "ReadyForNewScale", message: "recommended size matches current size" }, { type: "ScalingActive", status: "True", reason: "ValidMetricFound", message: "the HPA was able to successfully calculate a replica count from cpu resource utilization (percentage of request)" }, { type: "ScalingLimited", status: "True", reason: "TooFewReplicas", message: "the desired replica count is less than the minimum replica count" }] } });
  add("HorizontalPodAutoscaler", { kind: "HorizontalPodAutoscaler", apiVersion: "autoscaling/v2", metadata: meta("katalog-api", EP, 60 * 24 * 18), spec: { scaleTargetRef: { apiVersion: "apps/v1", kind: "Deployment", name: "katalog-api" }, minReplicas: 2, maxReplicas: 6, metrics: [{ type: "Resource", resource: { name: "cpu", target: { type: "Utilization", averageUtilization: 75 } } }, { type: "Resource", resource: { name: "memory", target: { type: "Utilization", averageUtilization: 80 } } }] }, status: { currentReplicas: 2, desiredReplicas: 2, currentMetrics: [{ type: "Resource", resource: { name: "cpu", current: { averageUtilization: 41, averageValue: "41m" } } }, { type: "Resource", resource: { name: "memory", current: { averageUtilization: 79, averageValue: "305Mi" } } }] } });
  add("PodDisruptionBudget", { kind: "PodDisruptionBudget", apiVersion: "policy/v1", metadata: meta("frontend-pdb", EP, 60 * 24 * 20), spec: { minAvailable: 2, selector: { matchLabels: { app: "frontend" } } }, status: { currentHealthy: 3, desiredHealthy: 2, disruptionsAllowed: 1, expectedPods: 3, observedGeneration: 1 } });
  add("PodDisruptionBudget", { kind: "PodDisruptionBudget", apiVersion: "policy/v1", metadata: meta("rabbitmq-pdb", EP, 60 * 24 * 9), spec: { maxUnavailable: 1, selector: { matchLabels: { app: "rabbitmq" } } }, status: { currentHealthy: 3, desiredHealthy: 2, disruptionsAllowed: 1, expectedPods: 3, observedGeneration: 1 } });
  add("Ingress", { kind: "Ingress", apiVersion: "networking.k8s.io/v1", metadata: meta("kampanya", EP, 60 * 24 * 6, { app: "frontend" }, { "route.openshift.io/termination": "edge" }), spec: { ingressClassName: "openshift-default", tls: [{ hosts: ["kampanya." + CL.domain], secretName: "shop-tls" }], rules: [{ host: "kampanya." + CL.domain, http: { paths: [{ path: "/", pathType: "Prefix", backend: { service: { name: "frontend", port: { number: 8080 } } } }] } }] }, status: { loadBalancer: { ingress: [{ hostname: "router-default." + CL.domain }] } } });
  const np = (name, ns, spec, age) => add("NetworkPolicy", { kind: "NetworkPolicy", apiVersion: "networking.k8s.io/v1", metadata: meta(name, ns, age || 60 * 24 * 30), spec: spec });
  [EP, "eticaret-test", "odeme-api", "musteri-portali"].forEach((ns) => {
    np("allow-from-openshift-ingress", ns, { podSelector: {}, ingress: [{ from: [{ namespaceSelector: { matchLabels: { "network.openshift.io/policy-group": "ingress" } } }] }], policyTypes: ["Ingress"] });
    np("allow-same-namespace", ns, { podSelector: {}, ingress: [{ from: [{ podSelector: {} }] }], policyTypes: ["Ingress"] });
    np("allow-from-openshift-monitoring", ns, { podSelector: {}, ingress: [{ from: [{ namespaceSelector: { matchLabels: { "network.openshift.io/policy-group": "monitoring" } } }] }], policyTypes: ["Ingress"] });
  });
  np("postgresql-sadece-backend", EP, { podSelector: { matchLabels: { app: "postgresql" } }, ingress: [{ from: [{ podSelector: { matchLabels: { "app.kubernetes.io/component": "backend" } } }], ports: [{ protocol: "TCP", port: 5432 }] }], policyTypes: ["Ingress"] });
  np("default-deny-all", "odeme-api", { podSelector: {}, policyTypes: ["Ingress", "Egress"] });
  np("odeme-gateway-egress", "odeme-api", { podSelector: { matchLabels: { app: "odeme-gateway" } }, egress: [{ to: [{ ipBlock: { cidr: "10.50.0.0/16" } }], ports: [{ protocol: "TCP", port: 443 }] }, { to: [{ namespaceSelector: { matchLabels: { "kubernetes.io/metadata.name": "openshift-dns" } } }], ports: [{ protocol: "UDP", port: 5353 }] }], policyTypes: ["Egress"] });
  const quota = (name, ns, hard, used) => add("ResourceQuota", { kind: "ResourceQuota", apiVersion: "v1", metadata: meta(name, ns, 60 * 24 * 60), spec: { hard: hard }, status: { hard: hard, used: used } });
  quota("compute-quota", EP, { "requests.cpu": "8", "requests.memory": "16Gi", "limits.cpu": "16", "limits.memory": "32Gi", pods: "50" }, { "requests.cpu": "1950m", "requests.memory": "4672Mi", "limits.cpu": "8250m", "limits.memory": "10624Mi", pods: "16" });
  quota("storage-quota", EP, { "requests.storage": "200Gi", persistentvolumeclaims: "20" }, { "requests.storage": "91Gi", persistentvolumeclaims: "6" });
  quota("compute-quota", "eticaret-test", { "requests.cpu": "2", "requests.memory": "4Gi", pods: "20" }, { "requests.cpu": "400m", "requests.memory": "1Gi", pods: "4" });
  quota("compute-quota", "odeme-api", { "requests.cpu": "6", "requests.memory": "12Gi", "limits.cpu": "12", "limits.memory": "24Gi", pods: "30" }, { "requests.cpu": "1100m", "requests.memory": "3584Mi", "limits.cpu": "5", "limits.memory": "7680Mi", pods: "7" });
  const lr = (ns) => add("LimitRange", { kind: "LimitRange", apiVersion: "v1", metadata: meta(ns + "-limits", ns, 60 * 24 * 60), spec: { limits: [{ type: "Container", default: { cpu: "500m", memory: "512Mi" }, defaultRequest: { cpu: "100m", memory: "256Mi" }, max: { cpu: "2", memory: "4Gi" } }, { type: "Pod", max: { cpu: "4", memory: "8Gi" } }] } });
  [EP, "eticaret-test", "odeme-api", "musteri-portali"].forEach(lr);

  /* Jobs & CronJobs */
  function job(ns, name, image, ageMin, result, cj, cmd) {
    const j = add("Job", {
      kind: "Job", apiVersion: "batch/v1",
      metadata: meta(name, ns, ageMin, { "batch.kubernetes.io/job-name": name, "job-name": name }, cj ? { "batch.kubernetes.io/cronjob-scheduled-timestamp": ago(ageMin) } : null, cj ? { ownerReferences: [owner(cj)] } : {}),
      spec: { parallelism: 1, completions: 1, backoffLimit: 6, completionMode: "NonIndexed", suspend: false, podReplacementPolicy: "TerminatingOrFailed", selector: { matchLabels: { "batch.kubernetes.io/controller-uid": uid() } }, template: { metadata: { labels: { "job-name": name } }, spec: { containers: [{ name: name.replace(/-\d+$/, ""), image: image, command: cmd }], restartPolicy: "OnFailure" } } },
      status: result === "Complete" ? { startTime: ago(ageMin), completionTime: ago(ageMin - 1.6), succeeded: 1, ready: 0, terminating: 0, uncountedTerminatedPods: {}, conditions: [{ type: "SuccessCriteriaMet", status: "True" }, { type: "Complete", status: "True", lastProbeTime: ago(ageMin - 1.6), lastTransitionTime: ago(ageMin - 1.6) }] } : result === "Failed" ? { startTime: ago(ageMin), failed: 7, ready: 0, conditions: [{ type: "FailureTarget", status: "True", reason: "BackoffLimitExceeded" }, { type: "Failed", status: "True", reason: "BackoffLimitExceeded", message: "Job has reached the specified backoff limit", lastTransitionTime: ago(ageMin - 10) }] } : { startTime: ago(ageMin), active: 1, ready: 1 }
    });
    const ja = { ns: ns, name: name, cname: name.replace(/-\d+$/, ""), image: image, podLabels: { "job-name": name, "batch.kubernetes.io/job-name": name }, probe: false, restart: "OnFailure", cpuUse: 0.2, memUse: 200, cmd: cmd };
    mkPod(ja, j, name + "-" + hs(5), null, pick(WORKERS), result === "Complete" ? "completed" : result === "Failed" ? "failed" : null, ageMin);
    ev(j, "SuccessfulCreate", "Created pod: " + name + "-" + hs(5), ageMin, "Normal", "job-controller");
    if (result === "Complete") ev(j, "Completed", "Job completed", ageMin - 1.6, "Normal", "job-controller");
    if (result === "Failed") ev(j, "BackoffLimitExceeded", "Job has reached the specified backoff limit", ageMin - 10, "Warning", "job-controller");
    return j;
  }
  function cronjob(ns, name, schedule, image, lastMin, nRuns, cmd, failLast, suspend) {
    const c = add("CronJob", {
      kind: "CronJob", apiVersion: "batch/v1",
      metadata: meta(name, ns, 60 * 24 * 30),
      spec: { schedule: schedule, timeZone: "Europe/Istanbul", concurrencyPolicy: "Forbid", suspend: !!suspend, successfulJobsHistoryLimit: 3, failedJobsHistoryLimit: 1, startingDeadlineSeconds: 200, jobTemplate: { spec: { backoffLimit: 3, template: { spec: { containers: [{ name: name, image: image, command: cmd }], restartPolicy: "OnFailure" } } } } },
      status: { lastScheduleTime: ago(lastMin), lastSuccessfulTime: ago(lastMin + (failLast ? 1440 : -2)) }
    });
    for (let i = 0; i < nRuns; i++) {
      const t = lastMin + i * (schedule.indexOf("*/") === 0 ? 15 : 1440);
      const jn = name + "-" + Math.floor((U.NOW - t * 60000) / 60000);
      job(ns, jn, image, t, failLast && i === 0 ? "Failed" : "Complete", c, cmd);
      ev(c, "SuccessfulCreate", "Created job " + jn, t, "Normal", "cronjob-controller");
    }
    return c;
  }
  job(EP, "db-migrate-v12", "quay.io/eticaret/katalog-api:1.12.0", 60 * 53, "Complete", null, ["/bin/sh", "-c", "./migrate.sh --target=12"]);
  cronjob(EP, "gece-raporu", "0 2 * * *", "quay.io/eticaret/raporlama:1.3.0", 60 * 8 + 30, 3, ["python", "rapor.py", "--gunluk"]);
  cronjob(EP, "sepet-temizleme", "*/15 * * * *", "registry.redhat.io/openshift4/ose-cli:v4.20", 9, 3, ["/bin/sh", "-c", "oc delete sepet --older-than=24h"]);
  cronjob(EP, "db-yedekleme", "30 1 * * *", "registry.redhat.io/rhel9/postgresql-16:1-24", 60 * 9, 1, ["/bin/sh", "-c", "pg_dump -h postgresql katalog | gzip > /backup/katalog-$(date +%F).sql.gz"], true);

  /* ================= eticaret-test ================= */
  const ET = "eticaret-test";
  cm("katalog-api-config", ET, { LOG_LEVEL: "DEBUG", CACHE_ENABLED: "false" }, 60 * 24 * 20, { app: "katalog-api" });
  secret("postgresql", ET, "Opaque", { "database-name": "katalog", "database-user": "test", "database-password": "test-ornek" }, 60 * 24 * 60);
  app({ ns: ET, name: "frontend", image: "quay.io/eticaret/frontend:2.5.0-rc1", replicas: 1, port: 8080, route: true, partOf: "eticaret", runtime: "nginx", cpuUse: 0.008, memUse: 36, probePath: "/", liveness: "/", podAge: 60 * 5 });
  app({ ns: ET, name: "katalog-api", image: "quay.io/eticaret/katalog-api:1.13.0-SNAPSHOT", replicas: 1, port: 8080, route: true, partOf: "eticaret", runtime: "quarkus", issues: ["crash"], env: envDb, envFrom: [{ configMapRef: { name: "katalog-api-config" } }], connects: [["postgresql", "StatefulSet"]] });
  app({ ns: ET, name: "oneri-motoru", image: "quay.io/eticaret/oneri-motoru:0.9.0-beta", replicas: 1, port: 8000, partOf: "eticaret", runtime: "python", issues: ["imagepull"] });
  app({ ns: ET, name: "postgresql", kind: "StatefulSet", image: "registry.redhat.io/rhel9/postgresql-16:1-24", replicas: 1, port: 5432, probe: false, partOf: "eticaret", runtime: "postgresql", cpuUse: 0.01, memUse: 90, pvcPerPod: { vol: "data", size: "5Gi" }, mounts: [{ name: "data", mountPath: "/var/lib/pgsql/data" }] });
  mkPvc("test-verisi-arsiv", ET, "100Gi", 30, "ocs-storagecluster-cephfs", "ReadWriteMany", null, "Pending");

  /* ================= odeme-api ================= */
  const OD = "odeme-api";
  secret("odeme-gateway-tls", OD, "kubernetes.io/tls", { "tls.crt": PEM, "tls.key": KEY }, 60 * 24 * 30, null, { "service.beta.openshift.io/originating-service-name": "odeme-gateway" });
  secret("banka-api-anahtari", OD, "Opaque", { "api-key": "ornek-banka-api-anahtari-123", "merchant-id": "TR000123456" }, 60 * 24 * 30);
  secret("odeme-db", OD, "Opaque", { "database-user": "odeme", "database-password": "odeme-ornek-parola" }, 60 * 24 * 60);
  cm("fraud-model-config", OD, { "esik-degeri": "0.82", "model-versiyonu": "2026.10", "kurallar.yaml": "kurallar:\n  - ad: yuksek-tutar\n    tutar: 50000\n  - ad: yurtdisi-ip\n    agirlik: 0.4\n" }, 60 * 24 * 12);
  add("ServiceAccount", { kind: "ServiceAccount", apiVersion: "v1", metadata: meta("odeme-gateway", OD, 60 * 24 * 60, { app: "odeme-gateway" }), imagePullSecrets: [{ name: "odeme-gateway-dockercfg-" + hs(5) }] });
  app({ ns: OD, name: "odeme-gateway", image: "quay.io/odeme/gateway:5.2.3", replicas: 3, port: 8443, route: "odeme." + CL.domain, tls: { termination: "reencrypt", insecureEdgeTerminationPolicy: "None" }, partOf: "odeme", runtime: "java", cpuUse: 0.11, memUse: 512, sa: "odeme-gateway", svcOpts: { ann: { "service.beta.openshift.io/serving-cert-secret-name": "odeme-gateway-tls" } }, volumes: [{ name: "tls", secret: { secretName: "odeme-gateway-tls", defaultMode: 420 } }], mounts: [{ name: "tls", mountPath: "/etc/tls", readOnly: true }], envFrom: [{ secretRef: { name: "banka-api-anahtari" } }], reqCpu: "250m", reqMem: "768Mi", limCpu: "1", limMem: "1536Mi", connects: [["fraud-detection"], ["odeme-db", "StatefulSet"]] });
  app({ ns: OD, name: "fraud-detection", image: "quay.io/odeme/fraud-detection:2026.10.1", replicas: 3, port: 9000, partOf: "odeme", runtime: "python", cpuUse: 0.35, memUse: 1400, issues: [null, null, "pending"], reqMem: "3Gi", limMem: "4Gi", reqCpu: "500m", limCpu: "2", envFrom: [{ configMapRef: { name: "fraud-model-config" } }] });
  app({ ns: OD, name: "odeme-db", kind: "StatefulSet", image: "registry.redhat.io/rhel9/postgresql-16:1-24", replicas: 1, port: 5432, probe: false, partOf: "odeme", runtime: "postgresql", cpuUse: 0.03, memUse: 300, pvcPerPod: { vol: "data", size: "40Gi", sc: "ocs-storagecluster-ceph-rbd" }, mounts: [{ name: "data", mountPath: "/var/lib/pgsql/data" }] });
  mkSvc({ ns: OD, name: "odeme-gateway", age: 60 * 24 * 20, port: 8443, selector: { app: "odeme-gateway" }, baseLabels: {} }, { name: "odeme-gateway-nodeport", type: "NodePort" });

  /* ================= musteri-portali (S2I / Builds) ================= */
  const MP = "musteri-portali";
  const isImg = "image-registry.openshift-image-registry.svc:5000/" + MP + "/portal-web";
  cm("portal-ayarlar", MP, { "PORTAL_BASLIK": "Müşteri Portalı", "OTURUM_SURESI": "30m", "DESTEK_EPOSTA": "destek@egitim.local" }, 60 * 24 * 15);
  secret("git-kimlik", MP, "kubernetes.io/basic-auth", { username: "ci-bot", password: "git-ornek-token" }, 60 * 24 * 40, null, { "build.openshift.io/source-secret-match-uri-1": "https://git.egitim.local/*" });
  secret("webhook-secret", MP, "Opaque", { WebHookSecretKey: hex(20) }, 60 * 24 * 40);
  secret("keycloak-admin", MP, "Opaque", { username: "admin", password: "keycloak-ornek" }, 60 * 24 * 40);
  const portal = app({ ns: MP, name: "portal-web", kind: "DeploymentConfig", image: isImg + "@sha256:" + hex(64), replicas: 2, port: 8080, route: "portal." + CL.domain, partOf: "musteri-portali", runtime: "nodejs", cpuUse: 0.02, memUse: 96, rev: 6, podAge: 60 * 3, vcs: "https://git.egitim.local/portal/portal-web.git", envFrom: [{ configMapRef: { name: "portal-ayarlar" } }], connects: [["keycloak", "StatefulSet"]], probePath: "/healthz", liveness: "/healthz" });
  app({ ns: MP, name: "keycloak", kind: "StatefulSet", image: "registry.redhat.io/rhbk/keycloak-rhel9:26.2", replicas: 1, port: 8443, route: "sso." + CL.domain, tls: { termination: "passthrough" }, partOf: "musteri-portali", runtime: "keycloak", cpuUse: 0.05, memUse: 640, probePath: "/health/ready", envFrom: [{ secretRef: { name: "keycloak-admin" } }] });
  const bc = add("BuildConfig", {
    kind: "BuildConfig", apiVersion: "build.openshift.io/v1",
    metadata: meta("portal-web", MP, 60 * 24 * 40, { app: "portal-web", "app.kubernetes.io/part-of": "musteri-portali" }),
    spec: {
      nodeSelector: null, output: { to: { kind: "ImageStreamTag", name: "portal-web:latest" } }, resources: {}, successfulBuildsHistoryLimit: 5, failedBuildsHistoryLimit: 5,
      strategy: { type: "Source", sourceStrategy: { from: { kind: "ImageStreamTag", namespace: "openshift", name: "nodejs:22-ubi9" }, env: [{ name: "NPM_RUN", value: "start" }] } },
      postCommit: {}, source: { type: "Git", git: { uri: "https://git.egitim.local/portal/portal-web.git", ref: "main" }, contextDir: "/", sourceSecret: { name: "git-kimlik" } },
      triggers: [{ type: "Generic", generic: { secretReference: { name: "webhook-secret" } } }, { type: "GitHub", github: { secretReference: { name: "webhook-secret" } } }, { type: "ConfigChange" }, { type: "ImageChange", imageChange: {} }],
      runPolicy: "Serial"
    },
    status: { lastVersion: 7 }
  });
  const BST = [[1, "Complete", 60 * 24 * 40, 3.1], [2, "Complete", 60 * 24 * 30, 2.4], [3, "Failed", 60 * 24 * 21, 0.9], [4, "Complete", 60 * 24 * 21 - 30, 2.2], [5, "Complete", 60 * 24 * 7, 2.6], [6, "Complete", 60 * 3 + 6, 2.3], [7, "Running", 4, 0]];
  BST.forEach(([n, phase, age, dur]) => {
    const b = add("Build", {
      kind: "Build", apiVersion: "build.openshift.io/v1",
      metadata: meta("portal-web-" + n, MP, age, { app: "portal-web", buildconfig: "portal-web", "openshift.io/build-config.name": "portal-web", "openshift.io/build.start-policy": "Serial" }, { "openshift.io/build-config.name": "portal-web", "openshift.io/build.number": String(n), "openshift.io/build.pod-name": "portal-web-" + n + "-build" }, { ownerReferences: [owner(bc)] }),
      spec: { serviceAccount: "builder", source: bc.spec.source, revision: { type: "Git", git: { commit: hex(40), author: { name: pick(["Zeynep Kaya", "Ali Vural", "Elif Şahin"]), email: "dev@egitim.local" }, message: pick(["Giriş sayfası tasarımı güncellendi", "Fatura listesine filtre eklendi", "Bağımlılıklar güncellendi", "Oturum zaman aşımı düzeltildi", "Keycloak entegrasyonu"]) } }, strategy: bc.spec.strategy, output: { to: { kind: "DockerImage", name: isImg + ":latest" }, pushSecret: { name: "builder-dockercfg-" + hs(5) } }, triggeredBy: [{ message: n === 1 ? "Build configuration change" : pick(["GitHub WebHook", "Manually triggered", "Image change"]) }] },
      status: { phase: phase, startTimestamp: ago(age), completionTimestamp: phase === "Running" ? undefined : ago(age - dur), duration: phase === "Running" ? undefined : Math.round(dur * 60e9), outputDockerImageReference: isImg + ":latest", config: { kind: "BuildConfig", namespace: MP, name: "portal-web" }, output: phase === "Complete" ? { to: { imageDigest: "sha256:" + hex(64) } } : undefined, reason: phase === "Failed" ? "GenericBuildFailed" : undefined, message: phase === "Failed" ? "Generic Build failure - check logs for details." : undefined, logSnippet: phase === "Failed" ? "npm ERR! code ERESOLVE\nnpm ERR! ERESOLVE unable to resolve dependency tree" : undefined }
    });
    Object.keys(b.status).forEach((k) => b.status[k] === undefined && delete b.status[k]);
    ev(b, phase === "Failed" ? "BuildFailed" : phase === "Running" ? "BuildStarted" : "BuildCompleted", "Build " + MP + "/portal-web-" + n + (phase === "Failed" ? " failed" : phase === "Running" ? " is now running" : " completed successfully"), phase === "Running" ? age : age - dur, phase === "Failed" ? "Warning" : "Normal", "build-controller");
    if (phase === "Running") mkPod({ ns: MP, name: "portal-web-7-build", cname: "sti-build", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), podLabels: { "openshift.io/build.name": "portal-web-7" }, probe: false, restart: "Never", cpuUse: 0.9, memUse: 780, sa: "builder", scc: "builder" }, b, "portal-web-7-build", null, WORKERS[1], null, age);
  });
  add("ImageStream", { kind: "ImageStream", apiVersion: "image.openshift.io/v1", metadata: meta("portal-web", MP, 60 * 24 * 40, { app: "portal-web" }, { "openshift.io/image.dockerRepositoryCheck": ago(60 * 24 * 40) }), spec: { lookupPolicy: { local: false } }, status: { dockerImageRepository: isImg, publicDockerImageRepository: "default-route-openshift-image-registry." + CL.domain + "/" + MP + "/portal-web", tags: [{ tag: "latest", items: [{ created: ago(60 * 3), dockerImageReference: isImg + "@sha256:" + hex(64), image: "sha256:" + hex(64), generation: 6 }, { created: ago(60 * 24 * 7), dockerImageReference: isImg + "@sha256:" + hex(64), image: "sha256:" + hex(64), generation: 5 }] }, { tag: "v1.4", items: [{ created: ago(60 * 24 * 7), dockerImageReference: isImg + "@sha256:" + hex(64), image: "sha256:" + hex(64), generation: 5 }] }] } });
  add("ImageStream", { kind: "ImageStream", apiVersion: "image.openshift.io/v1", metadata: meta("siparis-servisi", EP, 60 * 24 * 50, { app: "siparis-servisi" }), spec: { lookupPolicy: { local: true } }, status: { dockerImageRepository: "image-registry.openshift-image-registry.svc:5000/eticaret-prod/siparis-servisi", tags: [{ tag: "latest", items: [{ created: ago(60 * 24 * 4), dockerImageReference: "image-registry.openshift-image-registry.svc:5000/eticaret-prod/siparis-servisi@sha256:" + hex(64), image: "sha256:" + hex(64), generation: 4 }] }] } });
  ["nodejs", "python", "java", "golang", "dotnet", "php", "ruby", "httpd", "nginx", "postgresql", "mysql", "redis"].forEach((n, i) => add("ImageStream", { kind: "ImageStream", apiVersion: "image.openshift.io/v1", metadata: meta(n, "openshift", 60 * 24 * 142, { "samples.operator.openshift.io/managed": "true" }, { "openshift.io/display-name": n.charAt(0).toUpperCase() + n.slice(1), "samples.operator.openshift.io/version": CL.version }), spec: { lookupPolicy: { local: false }, tags: [{ name: "latest", from: { kind: "ImageStreamTag", name: "x" } }] }, status: { dockerImageRepository: "image-registry.openshift-image-registry.svc:5000/openshift/" + n, tags: [{ tag: "latest", items: [{ created: ago(60 * 24 * 30), dockerImageReference: "registry.redhat.io/ubi9/" + n + "@sha256:" + hex(64), image: "sha256:" + hex(64), generation: 2 }] }] } }));

  /* Pipelines (Tekton) */
  const pl = add("Pipeline", { kind: "Pipeline", apiVersion: "tekton.dev/v1", metadata: meta("portal-web-build-deploy", MP, 60 * 24 * 25, { "app.kubernetes.io/instance": "portal-web", "pipeline.openshift.io/runtime": "nodejs", "pipeline.openshift.io/type": "kubernetes" }), spec: { params: [{ name: "GIT_REPO", type: "string", default: "https://git.egitim.local/portal/portal-web.git" }, { name: "GIT_REVISION", type: "string", default: "main" }, { name: "IMAGE_NAME", type: "string", default: isImg }], workspaces: [{ name: "workspace" }], tasks: [{ name: "fetch-repository", taskRef: { resolver: "cluster", params: [{ name: "name", value: "git-clone" }, { name: "namespace", value: "openshift-pipelines" }, { name: "kind", value: "task" }] }, workspaces: [{ name: "output", workspace: "workspace" }] }, { name: "unit-test", runAfter: ["fetch-repository"], taskRef: { name: "npm-test" } }, { name: "build", runAfter: ["unit-test"], taskRef: { resolver: "cluster", params: [{ name: "name", value: "s2i-nodejs" }] } }, { name: "deploy", runAfter: ["build"], taskRef: { resolver: "cluster", params: [{ name: "name", value: "openshift-client" }] }, params: [{ name: "SCRIPT", value: "oc rollout status deploy/portal-web" }] }] } });
  const pl2 = add("Pipeline", { kind: "Pipeline", apiVersion: "tekton.dev/v1", metadata: meta("katalog-api-ci", EP, 60 * 24 * 15, { "pipeline.openshift.io/runtime": "java" }), spec: { params: [{ name: "GIT_REPO", type: "string" }], workspaces: [{ name: "source" }, { name: "maven-settings" }], tasks: [{ name: "git-clone", taskRef: { name: "git-clone" } }, { name: "maven-build", runAfter: ["git-clone"], taskRef: { name: "maven" } }, { name: "image-scan", runAfter: ["maven-build"], taskRef: { name: "acs-image-scan" } }, { name: "buildah", runAfter: ["image-scan"], taskRef: { name: "buildah" } }] } });
  [[pl, MP, "Succeeded", 60 * 3 + 10, 6.5], [pl, MP, "Succeeded", 60 * 24 * 2, 7.1], [pl, MP, "Failed", 60 * 24 * 3, 2.2], [pl, MP, "Running", 5, 0], [pl2, EP, "Succeeded", 60 * 52 + 20, 11.3], [pl2, EP, "Succeeded", 60 * 24 * 6, 10.8]].forEach(([p, ns, st, age, dur]) => {
    add("PipelineRun", { kind: "PipelineRun", apiVersion: "tekton.dev/v1", metadata: meta(p.metadata.name + "-" + hs(5), ns, age, { "tekton.dev/pipeline": p.metadata.name, "triggers.tekton.dev/eventlistener": "git-push" }), spec: { pipelineRef: { name: p.metadata.name }, timeouts: { pipeline: "1h0m0s" }, taskRunTemplate: { serviceAccountName: "pipeline" }, workspaces: [{ name: "workspace", volumeClaimTemplate: { spec: { accessModes: ["ReadWriteOnce"], resources: { requests: { storage: "1Gi" } } } } }] }, status: { startTime: ago(age), completionTime: st === "Running" ? undefined : ago(age - dur), conditions: [{ type: "Succeeded", status: st === "Succeeded" ? "True" : st === "Failed" ? "False" : "Unknown", reason: st === "Running" ? "Running" : st, message: st === "Succeeded" ? "Tasks Completed: 4 (Failed: 0, Cancelled 0), Skipped: 0" : st === "Failed" ? "Tasks Completed: 2 (Failed: 1, Cancelled 0), Skipped: 2" : "Tasks Completed: 2 (Failed: 0, Cancelled 0), Incomplete: 2, Skipped: 0" }] }, _st: st, _dur: dur });
  });
  ["git-clone", "buildah", "s2i-nodejs", "s2i-java", "openshift-client", "maven", "tkn"].forEach((t) => add("Task", { kind: "Task", apiVersion: "tekton.dev/v1", metadata: meta(t, "openshift-pipelines", 60 * 24 * 80, { "app.kubernetes.io/version": "0.4", "operator.tekton.dev/operand-name": "openshift-pipelines-addons" }), spec: { description: t + " görevi (OpenShift Pipelines ile birlikte gelir)", params: [], steps: [{ name: "run", image: "registry.redhat.io/openshift-pipelines/pipelines-" + t + "-rhel9:1.20" }] } }));
  add("Task", { kind: "Task", apiVersion: "tekton.dev/v1", metadata: meta("npm-test", MP, 60 * 24 * 25), spec: { workspaces: [{ name: "source" }], steps: [{ name: "test", image: "registry.access.redhat.com/ubi9/nodejs-22", workingDir: "$(workspaces.source.path)", script: "npm ci\nnpm test\n" }] } });

  /* ================= veri-analitik ================= */
  const VA = "veri-analitik";
  app({ ns: VA, name: "kafka", kind: "StatefulSet", image: "registry.redhat.io/amq-streams/kafka-39-rhel9:2.9.0", replicas: 3, port: 9092, probe: false, partOf: "veri-platformu", runtime: "amq", cpuUse: 0.25, memUse: 1500, pvcPerPod: { vol: "data", size: "100Gi", sc: "ocs-storagecluster-ceph-rbd" }, mounts: [{ name: "data", mountPath: "/var/lib/kafka/data" }], svcPorts: [{ name: "tcp-clients", port: 9092, targetPort: 9092 }, { name: "tcp-replication", port: 9091, targetPort: 9091 }], extraLabels: { "strimzi.io/cluster": "analitik-kafka" } });
  app({ ns: VA, name: "jupyter", image: "quay.io/modh/odh-generic-data-science-notebook:v3-2025a", replicas: 1, port: 8888, route: true, partOf: "veri-platformu", runtime: "python", cpuUse: 0.12, memUse: 2100, mounts: [{ name: "notebooks", mountPath: "/opt/app-root/src" }], volumes: [{ name: "notebooks", persistentVolumeClaim: { claimName: "jupyter-notebooks" } }], reqMem: "2Gi", limMem: "4Gi", limCpu: "2" });
  mkPvc("jupyter-notebooks", VA, "20Gi", 60 * 24 * 30, "ocs-storagecluster-cephfs", "ReadWriteMany", { app: "jupyter" });
  cronjob(VA, "satis-analizi", "0 */6 * * *", "quay.io/analitik/spark-job:3.5.1", 60 * 2 + 10, 3, ["/opt/spark/bin/spark-submit", "satis_analizi.py"]);
  cronjob(VA, "eski-veri-arsivleme", "0 4 * * 0", "quay.io/analitik/arsiv:1.0.0", 60 * 24 * 3, 1, ["./arsivle.sh"], false, true);

  /* ================= Sistem bileşenleri ================= */
  const masters = S.Node.filter((n) => n._role === "master");
  const infra = [nodeByShort("infra-0")];
  const ctlTol = [{ key: "node-role.kubernetes.io/master", operator: "Exists", effect: "NoSchedule" }];
  const sys = (o) => app(Object.assign({ probe: false, age: 60 * 24 * 142, podAge: 60 * 24 * ri(9, 20), cpuUse: 0.01, memUse: 80, svc: false }, o));
  sys({ ns: "openshift-console", name: "console", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 8443, svc: true, nodes: masters, tolerations: ctlTol, memUse: 95, extraLabels: { component: "ui" } });
  sys({ ns: "openshift-console", name: "downloads", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 8080, svc: true, nodes: masters, tolerations: ctlTol, memUse: 60 });
  sys({ ns: "openshift-ingress", name: "router-default", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 80, svc: true, nodes: [infra[0], WORKERS[0]], cpuUse: 0.04, memUse: 140, extraLabels: { "ingresscontroller.operator.openshift.io/owning-ingresscontroller": "default" }, tolerations: [{ key: "node-role.kubernetes.io/infra", operator: "Exists", effect: "NoSchedule" }] });
  sys({ ns: "openshift-image-registry", name: "image-registry", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 5000, svc: true, nodes: infra.concat([WORKERS[2]]), memUse: 180 });
  sys({ ns: "openshift-monitoring", name: "prometheus-k8s", kind: "StatefulSet", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 9091, svc: true, nodes: [infra[0], WORKERS[1]], cpuUse: 0.4, memUse: 3200, pvcPerPod: { vol: "prometheus-data", size: "100Gi", sc: "ocs-storagecluster-ceph-rbd" } });
  sys({ ns: "openshift-monitoring", name: "alertmanager-main", kind: "StatefulSet", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 9094, svc: true, nodes: [infra[0], WORKERS[2]], memUse: 70 });
  sys({ ns: "openshift-monitoring", name: "thanos-querier", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 2, port: 9091, svc: true, memUse: 110 });
  sys({ ns: "openshift-monitoring", name: "node-exporter", kind: "DaemonSet", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), port: 9100, memUse: 32, tolerations: [{ operator: "Exists" }] });
  sys({ ns: "openshift-dns", name: "dns-default", kind: "DaemonSet", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), port: 5353, memUse: 38, tolerations: [{ key: "node-role.kubernetes.io/master", operator: "Exists" }, { key: "node-role.kubernetes.io/infra", operator: "Exists" }] });
  sys({ ns: "openshift-dns", name: "node-resolver", kind: "DaemonSet", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), memUse: 12, tolerations: [{ operator: "Exists" }] });
  sys({ ns: "openshift-pipelines", name: "tekton-pipelines-controller", image: "registry.redhat.io/openshift-pipelines/pipelines-controller-rhel9@sha256:" + hex(64), replicas: 1, memUse: 140 });
  sys({ ns: "openshift-gitops", name: "openshift-gitops-server", image: "registry.redhat.io/openshift-gitops-1/argocd-rhel9@sha256:" + hex(64), replicas: 1, port: 8080, svc: true, memUse: 120 });
  sys({ ns: "openshift-operators", name: "gitops-operator-controller-manager", image: "registry.redhat.io/openshift-gitops-1/gitops-rhel9-operator@sha256:" + hex(64), replicas: 1, memUse: 90 });
  sys({ ns: "openshift-storage", name: "ocs-operator", image: "registry.redhat.io/odf4/ocs-rhel9-operator@sha256:" + hex(64), replicas: 1, memUse: 150, nodes: infra, tolerations: [{ key: "node-role.kubernetes.io/infra", operator: "Exists" }] });
  sys({ ns: "openshift-machine-api", name: "machine-api-operator", image: "quay.io/openshift-release-dev/ocp-v4.0-art-dev@sha256:" + hex(64), replicas: 1, nodes: masters, tolerations: ctlTol, memUse: 60 });
  add("Route", { kind: "Route", apiVersion: "route.openshift.io/v1", metadata: meta("console", "openshift-console", 60 * 24 * 142, { app: "console" }), spec: { host: "console-openshift-console." + CL.domain, to: { kind: "Service", name: "console", weight: 100 }, port: { targetPort: "https" }, tls: { termination: "reencrypt", insecureEdgeTerminationPolicy: "Redirect" }, wildcardPolicy: "None" }, status: { ingress: [{ host: "console-openshift-console." + CL.domain, routerName: "default", conditions: [{ type: "Admitted", status: "True" }] }] } });
  add("Route", { kind: "Route", apiVersion: "route.openshift.io/v1", metadata: meta("thanos-querier", "openshift-monitoring", 60 * 24 * 142), spec: { host: "thanos-querier-openshift-monitoring." + CL.domain, to: { kind: "Service", name: "thanos-querier", weight: 100 }, port: { targetPort: "web" }, tls: { termination: "reencrypt", insecureEdgeTerminationPolicy: "Redirect" }, wildcardPolicy: "None" }, status: { ingress: [{ host: "thanos-querier-openshift-monitoring." + CL.domain, routerName: "default", conditions: [{ type: "Admitted", status: "True" }] }] } });
  add("Service", { kind: "Service", apiVersion: "v1", metadata: meta("kubernetes", "default", 60 * 24 * 142, { component: "apiserver", provider: "kubernetes" }), spec: { clusterIP: "172.30.0.1", clusterIPs: ["172.30.0.1"], ports: [{ name: "https", port: 443, protocol: "TCP", targetPort: 6443 }], sessionAffinity: "None", type: "ClusterIP" }, status: { loadBalancer: {} } });
  add("Service", { kind: "Service", apiVersion: "v1", metadata: meta("openshift", "default", 60 * 24 * 142), spec: { type: "ExternalName", externalName: "kubernetes.default.svc.cluster.local", sessionAffinity: "None" }, status: { loadBalancer: {} } });

  /* ---------------- Storage ---------------- */
  const sc = (name, prov, def, params, exp, bind) => add("StorageClass", { kind: "StorageClass", apiVersion: "storage.k8s.io/v1", metadata: meta(name, null, 60 * 24 * 140, null, def ? { "storageclass.kubernetes.io/is-default-class": "true" } : { description: "" }), provisioner: prov, parameters: params, reclaimPolicy: "Delete", allowVolumeExpansion: exp, volumeBindingMode: bind || "Immediate" });
  sc("thin-csi", "csi.vsphere.vmware.com", true, { StoragePolicyName: "openshift-storage-policy-" + CL.infraName }, true, "WaitForFirstConsumer");
  sc("ocs-storagecluster-ceph-rbd", "openshift-storage.rbd.csi.ceph.com", false, { clusterID: "openshift-storage", pool: "ocs-storagecluster-cephblockpool", imageFeatures: "layering,deep-flatten,exclusive-lock,object-map,fast-diff", "csi.storage.k8s.io/fstype": "ext4" }, true);
  sc("ocs-storagecluster-cephfs", "openshift-storage.cephfs.csi.ceph.com", false, { clusterID: "openshift-storage", fsName: "ocs-storagecluster-cephfilesystem" }, true);
  sc("openshift-storage.noobaa.io", "openshift-storage.noobaa.io/obc", false, { bucketclass: "noobaa-default-bucket-class" }, false);
  add("VolumeSnapshotClass", { kind: "VolumeSnapshotClass", apiVersion: "snapshot.storage.k8s.io/v1", metadata: meta("ocs-storagecluster-rbdplugin-snapclass", null, 60 * 24 * 140), driver: "openshift-storage.rbd.csi.ceph.com", deletionPolicy: "Delete", parameters: { clusterID: "openshift-storage" } });
  add("VolumeSnapshotClass", { kind: "VolumeSnapshotClass", apiVersion: "snapshot.storage.k8s.io/v1", metadata: meta("ocs-storagecluster-cephfsplugin-snapclass", null, 60 * 24 * 140), driver: "openshift-storage.cephfs.csi.ceph.com", deletionPolicy: "Delete", parameters: { clusterID: "openshift-storage" } });
  add("VolumeSnapshotClass", { kind: "VolumeSnapshotClass", apiVersion: "snapshot.storage.k8s.io/v1", metadata: meta("csi-vsphere-vsc", null, 60 * 24 * 140, null, { "snapshot.storage.kubernetes.io/is-default-class": "true" }), driver: "csi.vsphere.vmware.com", deletionPolicy: "Delete" });
  ["data-postgresql-0"].forEach((p, i) => [1, 2, 3].forEach((d) => add("VolumeSnapshot", { kind: "VolumeSnapshot", apiVersion: "snapshot.storage.k8s.io/v1", metadata: meta("postgresql-yedek-" + d, EP, 60 * 24 * d), spec: { source: { persistentVolumeClaimName: p }, volumeSnapshotClassName: "ocs-storagecluster-rbdplugin-snapclass" }, status: { boundVolumeSnapshotContentName: "snapcontent-" + uid(), creationTime: ago(60 * 24 * d), readyToUse: true, restoreSize: "20Gi" } })));
  add("ObjectBucketClaim", { kind: "ObjectBucketClaim", apiVersion: "objectbucket.io/v1alpha1", metadata: meta("urun-yedekleri", EP, 60 * 24 * 50), spec: { bucketName: "urun-yedekleri-" + hex(8), storageClassName: "openshift-storage.noobaa.io", generateBucketName: "urun-yedekleri" }, status: { phase: "Bound" } });

  /* ---------------- Operators (CSV) ---------------- */
  const csv = (name, disp, ver, ns, prov, desc, apis, all) => add("ClusterServiceVersion", { kind: "ClusterServiceVersion", apiVersion: "operators.coreos.com/v1alpha1", metadata: meta(name + ".v" + ver, ns, 60 * 24 * ri(20, 120), { ["operators.coreos.com/" + name + "." + ns]: "" }, { "olm.operatorNamespace": ns, "olm.targetNamespaces": all ? "" : ns, capabilities: "Deep Insights", categories: "Integration & Delivery" }), spec: { displayName: disp, version: ver, provider: { name: prov }, description: desc, maturity: "stable", installModes: [{ type: "AllNamespaces", supported: true }], customresourcedefinitions: { owned: apis.map((a) => ({ kind: a[0], name: a[1], version: "v1", displayName: a[0] })) } }, status: { phase: "Succeeded", reason: "InstallSucceeded", message: "install strategy completed with no errors" }, _all: all });
  csv("openshift-pipelines-operator-rh", "Red Hat OpenShift Pipelines", "1.20.1", "openshift-operators", "Red Hat", "Tekton tabanlı, Kubernetes-yerel CI/CD çözümü.", [["TektonConfig", "tektonconfigs.operator.tekton.dev"], ["Pipeline", "pipelines.tekton.dev"], ["PipelineRun", "pipelineruns.tekton.dev"], ["Task", "tasks.tekton.dev"]], true);
  csv("openshift-gitops-operator", "Red Hat OpenShift GitOps", "1.18.0", "openshift-operators", "Red Hat", "Argo CD tabanlı GitOps sürekli teslim.", [["ArgoCD", "argocds.argoproj.io"], ["Application", "applications.argoproj.io"]], true);
  csv("odf-operator", "OpenShift Data Foundation", "4.20.1-rhodf", "openshift-storage", "Red Hat", "Ceph tabanlı blok, dosya ve nesne depolama.", [["StorageCluster", "storageclusters.ocs.openshift.io"], ["StorageSystem", "storagesystems.odf.openshift.io"]]);
  csv("amqstreams", "Streams for Apache Kafka", "2.9.2-0", "openshift-operators", "Red Hat", "Apache Kafka kümelerini yönetir.", [["Kafka", "kafkas.kafka.strimzi.io"], ["KafkaTopic", "kafkatopics.kafka.strimzi.io"], ["KafkaUser", "kafkausers.kafka.strimzi.io"]], true);
  csv("rhbk-operator", "Red Hat build of Keycloak", "26.2.9-opr.1", "musteri-portali", "Red Hat", "Kimlik ve erişim yönetimi (SSO).", [["Keycloak", "keycloaks.k8s.keycloak.org"], ["KeycloakRealmImport", "keycloakrealmimports.k8s.keycloak.org"]]);
  csv("cluster-logging", "Red Hat OpenShift Logging", "6.3.1", "openshift-logging", "Red Hat", "Log toplama ve iletme (Vector).", [["ClusterLogForwarder", "clusterlogforwarders.observability.openshift.io"]]);
  csv("loki-operator", "Loki Operator", "6.3.1", "openshift-operators-redhat", "Red Hat", "Ölçeklenebilir log depolama.", [["LokiStack", "lokistacks.loki.grafana.com"]], true);
  csv("web-terminal", "Web Terminal", "1.13.0", "openshift-operators", "Red Hat", "Konsol içinden oc/kubectl araçlarıyla terminal.", [["DevWorkspace", "devworkspaces.workspace.devfile.io"]], true);
  add("Subscription", { kind: "Subscription", apiVersion: "operators.coreos.com/v1alpha1", metadata: meta("openshift-pipelines-operator-rh", "openshift-operators", 60 * 24 * 100), spec: { channel: "latest", installPlanApproval: "Automatic", name: "openshift-pipelines-operator-rh", source: "redhat-operators", sourceNamespace: "openshift-marketplace" }, status: { currentCSV: "openshift-pipelines-operator-rh.v1.20.1", installedCSV: "openshift-pipelines-operator-rh.v1.20.1", state: "AtLatestKnown" } });

  /* ---------------- CRDs ---------------- */
  [["Pipeline", "tekton.dev", "v1", true], ["PipelineRun", "tekton.dev", "v1", true], ["Task", "tekton.dev", "v1", true], ["TaskRun", "tekton.dev", "v1", true], ["ArgoCD", "argoproj.io", "v1beta1", true], ["Application", "argoproj.io", "v1alpha1", true], ["Kafka", "kafka.strimzi.io", "v1beta2", true], ["KafkaTopic", "kafka.strimzi.io", "v1beta2", true], ["StorageCluster", "ocs.openshift.io", "v1", true], ["ObjectBucketClaim", "objectbucket.io", "v1alpha1", true], ["Keycloak", "k8s.keycloak.org", "v2alpha1", true], ["ClusterVersion", "config.openshift.io", "v1", false], ["ClusterOperator", "config.openshift.io", "v1", false], ["IngressController", "operator.openshift.io", "v1", true], ["MachineConfig", "machineconfiguration.openshift.io", "v1", false], ["MachineConfigPool", "machineconfiguration.openshift.io", "v1", false], ["Machine", "machine.openshift.io", "v1beta1", true], ["MachineSet", "machine.openshift.io", "v1beta1", true], ["ServiceMonitor", "monitoring.coreos.com", "v1", true], ["PrometheusRule", "monitoring.coreos.com", "v1", true], ["VolumeSnapshot", "snapshot.storage.k8s.io", "v1", true], ["ClusterServiceVersion", "operators.coreos.com", "v1alpha1", true], ["Subscription", "operators.coreos.com", "v1alpha1", true], ["UserDefinedNetwork", "k8s.ovn.org", "v1", true], ["SecurityContextConstraints", "security.openshift.io", "v1", false]].forEach(([k, g, v, nsd]) => {
    const pl = k.toLowerCase().replace(/y$/, "ie") + (/s$/.test(k) ? "es" : "s");
    add("CustomResourceDefinition", { kind: "CustomResourceDefinition", apiVersion: "apiextensions.k8s.io/v1", metadata: meta(pl + "." + g, null, 60 * 24 * ri(30, 142)), spec: { group: g, names: { kind: k, listKind: k + "List", plural: pl, singular: k.toLowerCase() }, scope: nsd ? "Namespaced" : "Cluster", versions: [{ name: v, served: true, storage: true, schema: { openAPIV3Schema: { type: "object", description: k + " kaynağının şeması", properties: { spec: { type: "object" }, status: { type: "object" } } } } }] }, status: { acceptedNames: { kind: k, plural: pl }, conditions: [{ type: "Established", status: "True" }, { type: "NamesAccepted", status: "True" }], storedVersions: [v] } });
  });

  /* ---------------- Helm ---------------- */
  add("HelmChartRepository", { kind: "HelmChartRepository", apiVersion: "helm.openshift.io/v1beta1", metadata: meta("openshift-helm-charts", null, 60 * 24 * 142), spec: { name: "OpenShift Helm Charts", connectionConfig: { url: "https://charts.openshift.io" } }, status: { conditions: [{ type: "Ready", status: "True" }] } });
  add("ProjectHelmChartRepository", { kind: "ProjectHelmChartRepository", apiVersion: "helm.openshift.io/v1beta1", metadata: meta("sirket-ici-chartlar", EP, 60 * 24 * 40), spec: { name: "Şirket İçi Chart'lar", connectionConfig: { url: "https://charts.egitim.local/stable" } }, status: { conditions: [{ type: "Ready", status: "True" }] } });
  OC.helmReleases = [
    { name: "nginx-kampanya", ns: EP, rev: 3, chart: "nginx", ver: "15.4.2", app: "1.27.1", status: "deployed", age: 60 * 24 * 6 },
    { name: "redis-test", ns: ET, rev: 1, chart: "redis-persistent", ver: "0.0.3", app: "7", status: "deployed", age: 60 * 24 * 15 },
    { name: "grafana-dashboards", ns: VA, rev: 2, chart: "grafana", ver: "8.5.1", app: "11.3.0", status: "failed", age: 60 * 24 * 2 }
  ];

  /* ---------------- User Management ---------------- */
  [["ayse.yilmaz", "Ayşe Yılmaz", "ldap-kurumsal"], ["mehmet.demir", "Mehmet Demir", "ldap-kurumsal"], ["zeynep.kaya", "Zeynep Kaya", "ldap-kurumsal"], ["can.ozturk", "Can Öztürk", "ldap-kurumsal"], ["ali.vural", "Ali Vural", "ldap-kurumsal"], ["egitim.admin", "Eğitim Yöneticisi", "htpasswd"]].forEach(([u, full, idp], i) => add("User", { kind: "User", apiVersion: "user.openshift.io/v1", metadata: meta(u, null, 60 * 24 * (130 - i * 9)), fullName: full, identities: [idp + ":" + (idp === "htpasswd" ? u : "uid=" + u + ",ou=people,dc=egitim,dc=local")], groups: null }));
  [["platform-yoneticileri", ["egitim.admin", "mehmet.demir"]], ["eticaret-gelistiriciler", ["ayse.yilmaz", "ali.vural"]], ["veri-ekibi", ["can.ozturk"]], ["portal-ekibi", ["zeynep.kaya", "ali.vural"]]].forEach(([g, users]) => add("Group", { kind: "Group", apiVersion: "user.openshift.io/v1", metadata: meta(g, null, 60 * 24 * 100, { "openshift.io/ldap.host": "ldap.egitim.local" }, { "openshift.io/ldap.sync-time": ago(60 * 2), "openshift.io/ldap.uid": "cn=" + g + ",ou=groups,dc=egitim,dc=local" }), users: users }));
  add("ClusterRoleBinding", { kind: "ClusterRoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("platform-yoneticileri-cluster-admin", null, 60 * 24 * 100), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "cluster-admin" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "Group", name: "platform-yoneticileri" }] });
  add("ClusterRoleBinding", { kind: "ClusterRoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("self-provisioners", null, 60 * 24 * 142, null, { "rbac.authorization.kubernetes.io/autoupdate": "true" }), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "self-provisioner" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "Group", name: "system:authenticated:oauth" }] });
  add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("gelistirici-edit", EP, 60 * 24 * 100), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "edit" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "Group", name: "eticaret-gelistiriciler" }] });
  add("RoleBinding", { kind: "RoleBinding", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("denetci-view", OD, 60 * 24 * 60), roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "view" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "User", name: "ali.vural" }] });
  add("Role", { kind: "Role", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("pod-okuyucu", EP, 60 * 24 * 40), rules: [{ apiGroups: [""], resources: ["pods", "pods/log"], verbs: ["get", "list", "watch"] }] });
  add("Role", { kind: "Role", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta("deployment-olceklendirici", EP, 60 * 24 * 40), rules: [{ apiGroups: ["apps"], resources: ["deployments", "deployments/scale"], verbs: ["get", "list", "patch", "update"] }] });
  [["cluster-admin", [{ apiGroups: ["*"], resources: ["*"], verbs: ["*"] }, { nonResourceURLs: ["*"], verbs: ["*"] }]], ["admin", [{ apiGroups: ["", "apps", "batch"], resources: ["*"], verbs: ["*"] }]], ["edit", [{ apiGroups: ["", "apps", "route.openshift.io"], resources: ["pods", "deployments", "services", "routes", "configmaps", "secrets"], verbs: ["create", "delete", "get", "list", "patch", "update", "watch"] }]], ["view", [{ apiGroups: ["", "apps"], resources: ["pods", "deployments", "services", "configmaps"], verbs: ["get", "list", "watch"] }]], ["self-provisioner", [{ apiGroups: ["project.openshift.io"], resources: ["projectrequests"], verbs: ["create"] }]], ["basic-user", [{ apiGroups: ["user.openshift.io"], resources: ["users"], resourceNames: ["~"], verbs: ["get"] }]], ["system:image-puller", [{ apiGroups: ["image.openshift.io"], resources: ["imagestreams/layers"], verbs: ["get"] }]], ["system:image-builder", [{ apiGroups: ["image.openshift.io"], resources: ["imagestreams/layers"], verbs: ["get", "update"] }]], ["system:deployer", [{ apiGroups: [""], resources: ["replicationcontrollers"], verbs: ["*"] }]]].forEach(([n, rules]) => add("ClusterRole", { kind: "ClusterRole", apiVersion: "rbac.authorization.k8s.io/v1", metadata: meta(n, null, 60 * 24 * 142, { "kubernetes.io/bootstrapping": "rbac-defaults" }, { "rbac.authorization.kubernetes.io/autoupdate": "true" }), rules: rules }));
  add("ServiceAccount", { kind: "ServiceAccount", apiVersion: "v1", metadata: meta("pipeline", MP, 60 * 24 * 25), imagePullSecrets: [{ name: "pipeline-dockercfg-" + hs(5) }] });

  /* ---------------- Compute: Machines ---------------- */
  const msets = [["worker-dc1", 2], ["worker-dc2", 2], ["infra", 1]];
  msets.forEach(([m, rep]) => add("MachineSet", { kind: "MachineSet", apiVersion: "machine.openshift.io/v1beta1", metadata: meta(CL.infraName + "-" + m, "openshift-machine-api", 60 * 24 * 142, { "machine.openshift.io/cluster-api-cluster": CL.infraName }, { "machine.openshift.io/memoryMb": m === "infra" ? "32768" : "65536", "machine.openshift.io/vCPU": m === "infra" ? "8" : "16" }), spec: { replicas: rep, selector: { matchLabels: { "machine.openshift.io/cluster-api-machineset": CL.infraName + "-" + m } }, template: { spec: { providerSpec: { value: { apiVersion: "machine.openshift.io/v1beta1", kind: "VSphereMachineProviderSpec", numCPUs: m === "infra" ? 8 : 16, memoryMiB: m === "infra" ? 32768 : 65536, diskGiB: 120, template: CL.infraName + "-rhcos-generated-region-generated-zone", network: { devices: [{ networkName: "VM-Network-OCP" }] }, workspace: { datacenter: "DC1", datastore: "vsanDatastore", server: "vcenter.egitim.local" } } } } } }, status: { replicas: rep, availableReplicas: rep, readyReplicas: rep, fullyLabeledReplicas: rep, observedGeneration: 1 } }));
  S.Node.forEach((n) => add("Machine", { kind: "Machine", apiVersion: "machine.openshift.io/v1beta1", metadata: meta(CL.infraName + "-" + n._short, "openshift-machine-api", 60 * 24 * 142, { "machine.openshift.io/cluster-api-cluster": CL.infraName, "machine.openshift.io/cluster-api-machine-role": n._role, "machine.openshift.io/cluster-api-machine-type": n._role }), spec: { providerID: n.spec.providerID }, status: { phase: "Running", nodeRef: { kind: "Node", name: n.metadata.name, uid: n.metadata.uid }, addresses: n.status.addresses, providerStatus: { instanceState: "poweredOn" } }, _node: n }));
  add("MachineAutoscaler", { kind: "MachineAutoscaler", apiVersion: "autoscaling.openshift.io/v1beta1", metadata: meta("worker-dc1", "openshift-machine-api", 60 * 24 * 60), spec: { minReplicas: 2, maxReplicas: 4, scaleTargetRef: { apiVersion: "machine.openshift.io/v1beta1", kind: "MachineSet", name: CL.infraName + "-worker-dc1" } } });
  add("MachineHealthCheck", { kind: "MachineHealthCheck", apiVersion: "machine.openshift.io/v1beta1", metadata: meta("worker-saglik-kontrolu", "openshift-machine-api", 60 * 24 * 60), spec: { selector: { matchLabels: { "machine.openshift.io/cluster-api-machine-role": "worker" } }, unhealthyConditions: [{ type: "Ready", status: "False", timeout: "300s" }, { type: "Ready", status: "Unknown", timeout: "300s" }], maxUnhealthy: "40%", nodeStartupTimeout: "10m" }, status: { currentHealthy: 4, expectedMachines: 4, remediationsAllowed: 1 } });
  [["master", 3], ["worker", 5]].forEach(([p, n]) => add("MachineConfigPool", { kind: "MachineConfigPool", apiVersion: "machineconfiguration.openshift.io/v1", metadata: meta(p, null, 60 * 24 * 142, { ["machineconfiguration.openshift.io/mco-built-in"]: "", ["pools.operator.machineconfiguration.openshift.io/" + p]: "" }), spec: { machineConfigSelector: { matchLabels: { "machineconfiguration.openshift.io/role": p } }, nodeSelector: { matchLabels: { ["node-role.kubernetes.io/" + p]: "" } }, paused: false, maxUnavailable: 1 }, status: { configuration: { name: "rendered-" + p + "-" + hex(32) }, machineCount: n, readyMachineCount: n, updatedMachineCount: n, degradedMachineCount: 0, conditions: [{ type: "Updated", status: "True", message: "All nodes are updated with MachineConfig rendered-" + p }, { type: "Updating", status: "False" }, { type: "Degraded", status: "False" }] } }));
  ["00-master", "00-worker", "01-master-container-runtime", "01-master-kubelet", "01-worker-container-runtime", "01-worker-kubelet", "97-master-generated-kubelet", "97-worker-generated-kubelet", "99-master-ssh", "99-worker-ssh", "99-worker-chrony-ntp", "rendered-master-" + hex(32), "rendered-worker-" + hex(32)].forEach((m) => add("MachineConfig", { kind: "MachineConfig", apiVersion: "machineconfiguration.openshift.io/v1", metadata: meta(m, null, m.indexOf("chrony") > 0 ? 60 * 24 * 50 : 60 * 24 * 142, { "machineconfiguration.openshift.io/role": /master/.test(m) ? "master" : "worker" }, /^0|^rendered/.test(m) ? { "machineconfiguration.openshift.io/generated-by-controller-version": hex(40) } : null), spec: m.indexOf("chrony") > 0 ? { config: { ignition: { version: "3.4.0" }, storage: { files: [{ path: "/etc/chrony.conf", mode: 420, overwrite: true, contents: { source: "data:text/plain;charset=utf-8;base64,c2VydmVyIG50cC5lZ2l0aW0ubG9jYWwgaWJ1cnN0Cg==" } }] } } } : { config: { ignition: { version: "3.4.0" } }, osImageURL: "" } }));

  /* ---------------- Cluster Operators ---------------- */
  OC.clusterOperators = ["authentication", "baremetal", "cloud-controller-manager", "cloud-credential", "cluster-autoscaler", "config-operator", "console", "control-plane-machine-set", "csi-snapshot-controller", "dns", "etcd", "image-registry", "ingress", "insights", "kube-apiserver", "kube-controller-manager", "kube-scheduler", "kube-storage-version-migrator", "machine-api", "machine-approver", "machine-config", "marketplace", "monitoring", "network", "node-tuning", "olm", "openshift-apiserver", "openshift-controller-manager", "openshift-samples", "operator-lifecycle-manager", "operator-lifecycle-manager-catalog", "operator-lifecycle-manager-packageserver", "service-ca", "storage"].map((n) => ({ name: n, version: CL.version, available: true, progressing: false, degraded: false, since: ago(60 * 24 * ri(5, 20)), message: n === "insights" ? "Insights works as expected" : n === "machine-config" ? "Cluster version is " + CL.version : "" }));

  /* ---------------- Alerts ---------------- */
  OC.alerts = [
    { name: "Watchdog", severity: "none", state: "firing", ns: "openshift-monitoring", since: ago(60 * 24 * 142), source: "Platform", summary: "Alerting altyapısının çalıştığını doğrulayan, sürekli tetiklenen uyarı.", desc: "Bu uyarı her zaman FIRING durumundadır. Alertmanager'a ulaşmadığında uyarı zincirinde sorun olduğu anlaşılır (dead man's switch)." },
    { name: "KubePodCrashLooping", severity: "warning", state: "firing", ns: ET, since: ago(60 * 25), source: "Platform", pod: S.Pod.find((p) => p.metadata.namespace === ET && /^katalog-api/.test(p.metadata.name)).metadata.name, summary: "Pod sürekli yeniden başlıyor (CrashLoopBackOff).", desc: "Pod eticaret-test/katalog-api konteyneri son 15 dakikada sürekli yeniden başlatılıyor." },
    { name: "KubePodNotReady", severity: "warning", state: "firing", ns: ET, since: ago(60 * 2), source: "Platform", summary: "Pod 15 dakikadan uzun süredir hazır değil.", desc: "Pod eticaret-test/oneri-motoru 15 dakikadan uzun süredir non-ready durumda (ImagePullBackOff)." },
    { name: "KubePodNotScheduled", severity: "warning", state: "firing", ns: OD, since: ago(60), source: "Platform", summary: "Pod zamanlanamıyor.", desc: "fraud-detection pod'u için yeterli bellek kaynağına sahip uygun node bulunamadı." },
    { name: "KubeJobFailed", severity: "warning", state: "firing", ns: EP, since: ago(60 * 9), source: "Platform", summary: "Job tamamlanamadı.", desc: "Job eticaret-prod/db-yedekleme backoff limitine ulaştı." },
    { name: "AlertmanagerReceiversNotConfigured", severity: "warning", state: "firing", ns: "openshift-monitoring", since: ago(60 * 24 * 142), source: "Platform", summary: "Alertmanager alıcıları yapılandırılmamış.", desc: "Uyarılar e-posta, Slack veya PagerDuty gibi bir hedefe gönderilmiyor." },
    { name: "PersistentVolumeClaimPending", severity: "info", state: "pending", ns: ET, since: ago(25), source: "User", summary: "PVC bağlanmayı bekliyor.", desc: "test-verisi-arsiv PVC'si 100Gi kapasite için bekliyor." },
    { name: "SiparisKuyrukBirikmesi", severity: "critical", state: "silenced", ns: EP, since: ago(60 * 4), source: "User", summary: "RabbitMQ sipariş kuyruğunda 10.000+ mesaj birikti.", desc: "Kullanıcı tanımlı PrometheusRule ile oluşturulmuş uygulama uyarısı. Bakım nedeniyle susturuldu (silence)." }
  ];
  OC.silences = [{ id: uid(), matchers: "alertname=SiparisKuyrukBirikmesi, namespace=eticaret-prod", state: "Active", ends: new Date(U.NOW + 3600 * 1000 * 2).toISOString(), creator: "ayse.yilmaz", comment: "Planlı RabbitMQ bakımı" }];

  /* ---------------- Catalog ---------------- */
  OC.catalog = [
    ["Node.js", "Builder Image", "nodejs", "Kaynak koddan Node.js uygulaması derleyip çalıştırır (S2I).", "Red Hat"], ["Python", "Builder Image", "python", "Python 3.12 uygulamaları için S2I builder imajı.", "Red Hat"], ["Java (OpenJDK 21)", "Builder Image", "java", "Spring Boot, Quarkus gibi Java uygulamaları için.", "Red Hat"], [".NET 9", "Builder Image", "dotnet", ".NET uygulamalarını derleyip çalıştırır.", "Red Hat"], ["Go", "Builder Image", "golang", "Go uygulamaları için builder imajı.", "Red Hat"],
    ["PostgreSQL", "Template", "postgresql", "Kalıcı depolamalı PostgreSQL veritabanı.", "Red Hat"], ["MySQL", "Template", "mysql", "Kalıcı depolamalı MySQL veritabanı.", "Red Hat"], ["Redis", "Template", "redis", "Kalıcı depolamalı Redis bellek-içi veri deposu.", "Red Hat"], ["Apache HTTP Server", "Builder Image", "httpd", "Statik içerik için Apache httpd.", "Red Hat"], ["Nginx", "Builder Image", "nginx", "Statik içerik ve reverse proxy için Nginx.", "Red Hat"],
    ["Redis (Helm)", "Helm Chart", "redis", "Helm ile Redis kurulumu.", "Partner"], ["Grafana (Helm)", "Helm Chart", "grafana", "Görselleştirme panoları.", "Community"], ["Pipelines – S2I Node.js", "Pipeline", "nodejs", "Git'ten çekip S2I ile derleyen hazır pipeline.", "Red Hat"], ["Streams for Apache Kafka", "Operator Backed", "amq", "Kafka cluster'ı operator ile oluşturur.", "Red Hat"], ["Keycloak", "Operator Backed", "keycloak", "SSO / kimlik doğrulama sunucusu.", "Red Hat"], ["Container Image", "Container Image", "cube", "Bir registry'deki hazır imajı dağıtın.", "Red Hat"]
  ];
  OC.operatorHub = [
    ["Red Hat OpenShift Pipelines", "Red Hat", "CI/CD", true], ["Red Hat OpenShift GitOps", "Red Hat", "CI/CD", true], ["OpenShift Data Foundation", "Red Hat", "Storage", true], ["Streams for Apache Kafka", "Red Hat", "Streaming & Messaging", true], ["Red Hat build of Keycloak", "Red Hat", "Security", true], ["Red Hat OpenShift Logging", "Red Hat", "Logging & Tracing", true], ["Loki Operator", "Red Hat", "Logging & Tracing", true], ["Web Terminal", "Red Hat", "Developer Tools", true],
    ["Red Hat OpenShift Service Mesh 3", "Red Hat", "Networking", false], ["Red Hat Advanced Cluster Security", "Red Hat", "Security", false], ["OpenShift Virtualization", "Red Hat", "Virtualization", false], ["Red Hat OpenShift Serverless", "Red Hat", "Integration & Delivery", false], ["Cert Manager Operator", "Red Hat", "Security", false], ["Red Hat Quay", "Red Hat", "Integration & Delivery", false], ["Compliance Operator", "Red Hat", "Security", false], ["OADP Operator (Yedekleme)", "Red Hat", "Storage", false], ["Red Hat OpenShift AI", "Red Hat", "AI/Machine Learning", false], ["Node Feature Discovery", "Red Hat", "Monitoring", false]
  ];

  /* Sıralama: olaylar en yeni önce */
  S.Event.sort((a, b) => Date.parse(b.lastTimestamp) - Date.parse(a.lastTimestamp));
  OC.userProjects = PROJ.map((p) => p[0]);
})();
