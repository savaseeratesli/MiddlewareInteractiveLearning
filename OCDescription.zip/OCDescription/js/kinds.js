/* OpenShift Eğitim Konsolu – kaynak türleri (sütunlar, detay alanları, sekmeler, işlemler) */
(function () {
  "use strict";
  const OC = window.OC, U = OC.u, H = OC.H, db = OC.db;
  const esc = U.esc;

  /* ---------------- Ortak görüntüleme yardımcıları ---------------- */
  const R = (OC.r = {});
  R.q = (k, cls) => (H[k] ? `<button type="button" class="qh ${cls || ""}" data-h="${k}" aria-label="${esc(H[k].t)} hakkında açıklama" title="Ne işe yarar?">?</button>` : "");
  R.badge = (kind) => { const k = K[kind] || {}; return `<span class="rb ${k.cls || "rb-def"}" title="${esc(kind)}">${esc(k.abbr || kind.slice(0, 2).toUpperCase())}</span>`; };
  R.href = (kind, ns, name, tab) => {
    const k = K[kind]; if (!k) return "#/";
    const base = k.ns ? `#/k8s/ns/${ns}/${k.plural}` : `#/k8s/cluster/${k.plural}`;
    return name ? base + "/" + encodeURIComponent(name) + (tab ? "/" + tab : "") : base;
  };
  R.link = (kind, ns, name, noBadge) => (K[kind] ? `<span class="rlink">${noBadge ? "" : R.badge(kind)}<a href="${R.href(kind, ns, name)}">${esc(name)}</a></span>` : esc(name));
  R.nsLink = (ns) => (ns ? R.link("Namespace", null, ns) : "-");
  const ST = {
    ok: ["Completed", "Succeeded", "Complete", "Bound", "Active", "Ready", "Available", "Accepted", "Established", "Up", "deployed", "True", "Healthy", "InstallSucceeded", "Admitted"],
    sync: ["Running"],
    pend: ["Pending", "ContainerCreating", "Provisioning", "New", "Waiting", "Installing", "Unknown", "pending", "Progressing"],
    err: ["CrashLoopBackOff", "Error", "Failed", "ImagePullBackOff", "ErrImagePull", "OOMKilled", "Lost", "NotReady", "failed", "Degraded", "Down", "CreateContainerConfigError", "BackoffLimitExceeded"],
    warn: ["SchedulingDisabled", "Warning", "Suspended", "firing", "Silenced"],
    ban: ["Terminating", "Cancelled"]
  };
  R.statusIcon = (s) => {
    const t = String(s).split(/[ ,]/)[0];
    if (ST.sync.indexOf(t) >= 0) return U.ico("sync", 13, "st-run");
    if (ST.ok.indexOf(t) >= 0) return U.ico("check", 13);
    if (ST.err.indexOf(t) >= 0) return U.ico("err", 13);
    if (ST.warn.indexOf(t) >= 0) return U.ico("warn", 13);
    if (ST.ban.indexOf(t) >= 0) return U.ico("ban", 13);
    if (ST.pend.indexOf(t) >= 0) return U.ico("pend", 13, "st-pend");
    return U.ico("unknown", 13);
  };
  R.status = (s, help) => `<span class="status">${R.statusIcon(s)}<span>${esc(s)}</span>${help ? R.q(help) : ""}</span>`;
  R.labels = (l, kind) => {
    const keys = Object.keys(l || {});
    if (!keys.length) return '<span class="muted">No labels</span>';
    return `<div class="chips">${keys.map((k) => `<a class="chip" href="#/search?kind=${kind || "Pod"}&q=${encodeURIComponent(k + "=" + l[k])}" title="Bu label ile ara"><span class="ck">${esc(k)}</span>${l[k] !== "" ? "=" + esc(l[k]) : ""}</a>`).join("")}</div>`;
  };
  R.selector = (sel, ns) => {
    const m = sel && (sel.matchLabels || (sel.matchExpressions ? null : sel));
    if (!m || !Object.keys(m).length) return '<span class="muted">No selector</span>';
    const q = Object.keys(m).map((k) => k + "=" + m[k]).join(",");
    return `<a class="selector" href="#/search?kind=Pod&q=${encodeURIComponent(q)}${ns ? "&ns=" + ns : ""}">${U.ico("search", 12)} ${esc(q)}</a>`;
  };
  R.count = (n, w) => (n ? n + " " + w + (n === 1 ? "" : "s") : "No " + w + "s");
  R.dl = (rows) => `<dl class="dl">${rows.filter(Boolean).map(([label, val, help]) => `<div class="dli"><dt>${help && H[help] ? `<button type="button" class="dt-l" data-h="${help}">${esc(label)}</button>` : `<span class="dt-n">${esc(label)}</span>`}${R.q(help)}</dt><dd>${val == null || val === "" ? '<span class="muted">-</span>' : val}</dd></div>`).join("")}</dl>`;
  R.table = (cols, rows, opt) => {
    opt = opt || {};
    if (!rows.length) return `<div class="empty-s">${esc(opt.empty || "Bulunamadı")}</div>`;
    return `<div class="tbl-wrap"><table class="tbl ${opt.cls || ""}"><thead><tr>${cols.map((c) => `<th>${esc(c[0])}${c[1] ? R.q(c[1]) : ""}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c == null || c === "" ? "-" : c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  };
  R.section = (title, body, help, extra) => `<section class="dsec"><h2 class="dsec-t">${esc(title)}${R.q(help)}${extra || ""}</h2>${body}</section>`;
  R.cnt = (o) => (o.spec && o.spec.template && o.spec.template.spec.containers) || (o.spec && o.spec.containers) || [];
  const mem = (s) => { if (!s) return 0; const m = String(s).match(/^([\d.]+)\s*(Ki|Mi|Gi|Ti|K|M|G)?/); if (!m) return 0; const v = parseFloat(m[1]); return { Ki: v / 1024, Mi: v, Gi: v * 1024, Ti: v * 1048576, K: v / 1000 / 1.048576, M: v / 1.048576, G: v * 953.674 }[m[2]] || v / 1048576; };
  R.mem = mem;

  /* ---------------- Pod yardımcıları ---------------- */
  const podStatus = (OC.podStatus = (p) => {
    if (p.metadata.deletionTimestamp) return "Terminating";
    const cs = (p.status.containerStatuses || [])[0];
    if (p.status.phase === "Pending" && !cs) return "Pending";
    if (cs && cs.state.waiting) return cs.state.waiting.reason;
    if (cs && cs.state.terminated) return cs.state.terminated.reason === "Completed" ? "Completed" : cs.state.terminated.reason;
    return p.status.phase;
  });
  const podReady = (p) => { const cs = p.status.containerStatuses || []; return cs.filter((c) => c && c.ready).length + "/" + (p.spec.containers.length); };
  const podRestarts = (p) => (p.status.containerStatuses || []).reduce((a, c) => a + (c ? c.restartCount : 0), 0);
  const ownerOf = (o) => (o.metadata.ownerReferences || [])[0];
  OC.ownerLink = (o) => { const ow = ownerOf(o); return ow ? R.link(ow.kind, o.metadata.namespace, ow.name) : "-"; };
  const selMatch = (sel, lab) => { if (!sel) return false; const m = sel.matchLabels || sel; const keys = Object.keys(m); return keys.length > 0 && keys.every((k) => lab && lab[k] === m[k]); };
  OC.selMatch = selMatch;
  OC.podsOf = (o) => {
    const ns = o.metadata.namespace;
    if (o.kind === "Node") return db.Pod.filter((p) => p.spec.nodeName === o.metadata.name);
    if (o.kind === "Deployment") { const rss = db.ReplicaSet.filter((r) => ownerOf(r) && ownerOf(r).uid === o.metadata.uid).map((r) => r.metadata.uid); return db.Pod.filter((p) => p.metadata.namespace === ns && ownerOf(p) && rss.indexOf(ownerOf(p).uid) >= 0); }
    if (o.kind === "DeploymentConfig") { const rcs = db.ReplicationController.filter((r) => ownerOf(r) && ownerOf(r).uid === o.metadata.uid).map((r) => r.metadata.uid); return db.Pod.filter((p) => ownerOf(p) && rcs.indexOf(ownerOf(p).uid) >= 0); }
    if (o.kind === "CronJob") { const js = db.Job.filter((j) => ownerOf(j) && ownerOf(j).uid === o.metadata.uid).map((j) => j.metadata.uid); return db.Pod.filter((p) => ownerOf(p) && js.indexOf(ownerOf(p).uid) >= 0); }
    if (o.kind === "Service") return db.Pod.filter((p) => p.metadata.namespace === ns && selMatch(o.spec.selector, p.metadata.labels));
    if (o.kind === "PersistentVolumeClaim") return db.Pod.filter((p) => p.metadata.namespace === ns && (p.spec.volumes || []).some((v) => v.persistentVolumeClaim && v.persistentVolumeClaim.claimName === o.metadata.name));
    if (o.kind === "BuildConfig") return [];
    return db.Pod.filter((p) => ownerOf(p) && ownerOf(p).uid === o.metadata.uid);
  };
  const podsSummary = (pods) => { const r = pods.filter((p) => podStatus(p) === "Running" && podReady(p).split("/")[0] === podReady(p).split("/")[1]).length; return r + " of " + pods.length + " pods"; };
  const wlStatus = (o) => {
    const pods = OC.podsOf(o), want = o.kind === "DaemonSet" ? o.status.desiredNumberScheduled : o.spec.replicas;
    const r = pods.filter((p) => podStatus(p) === "Running" && p.status.containerStatuses[0] && p.status.containerStatuses[0].ready).length;
    return `<a class="pods-link ${r < want ? "warnc" : ""}" href="${R.href(o.kind, o.metadata.namespace, o.metadata.name, "pods")}">${r < want ? U.ico("warn", 13) : U.ico("check", 13)} ${r} of ${want} pods</a>`;
  };
  OC.wlStatus = wlStatus;
  const sizeOf = (o) => Object.keys(o.data || {}).length + Object.keys(o.binaryData || {}).length;

  /* ---------------- Ortak sütunlar ---------------- */
  const C = {
    created: { t: "Created", v: (o) => U.ts(o.metadata.creationTimestamp), s: (o) => o.metadata.creationTimestamp, h: "created" },
    labels: { t: "Labels", v: (o) => R.labels(o.metadata.labels, o.kind), h: "labels", cls: "c-labels" },
    owner: { t: "Owner", v: (o) => OC.ownerLink(o), s: (o) => (ownerOf(o) || {}).name, h: "owner" },
    podsel: { t: "Pod selector", v: (o) => R.selector(o.spec.selector, o.metadata.namespace), h: "selector" },
    wl: { t: "Status", v: wlStatus, h: "pod-ring" }
  };

  /* ---------------- Ortak detay sol sütunu ---------------- */
  OC.metaRows = (o, extra) => {
    const m = o.metadata, ann = Object.keys(m.annotations || {}).length;
    return [
      ["Name", esc(m.name), "name"],
      m.namespace ? ["Namespace", R.nsLink(m.namespace), "namespace-field"] : null,
      ["Labels", R.labels(m.labels, o.kind), "labels"]
    ].concat(extra || []).concat([
      ["Annotations", `<a href="#" data-nop="1" class="ann-link" data-ann="1">${R.count(ann, "annotation")}</a>`, "annotations"],
      ["Created at", U.ts(m.creationTimestamp), "created"],
      ["Owner", m.ownerReferences ? OC.ownerLink(o) : "No owner", "owner"]
    ]);
  };
  const tplRows = (o) => { const ps = o.spec.template.spec; return [["Pod selector", R.selector(o.spec.selector, o.metadata.namespace), "selector"], ["Node selector", ps.nodeSelector ? R.labels(ps.nodeSelector) : "No selector", "node-selector"], ["Tolerations", R.count((ps.tolerations || []).length, "toleration"), "tolerations"]]; };

  /* ---------------- Ortak işlemler ---------------- */
  const A = {
    labels: ["Edit labels", (o) => `oc label ${o.kind.toLowerCase()} ${o.metadata.name} anahtar=deger`, "labels"],
    ann: ["Edit annotations", (o) => `oc annotate ${o.kind.toLowerCase()} ${o.metadata.name} anahtar=deger`, "annotations"],
    edit: ["Edit", (o) => `oc edit ${o.kind.toLowerCase()} ${o.metadata.name}`, "tab-yaml"],
    del: ["Delete", (o) => `oc delete ${o.kind.toLowerCase()} ${o.metadata.name}`, null, "danger"]
  };
  const std = (extra) => (extra || []).concat([A.labels, A.ann, A.edit, A.del]);

  /* ---------------- TÜR TANIMLARI ---------------- */
  const K = (OC.K = {});
  const def = (kind, o) => (K[kind] = Object.assign({ kind: kind, label: kind + "s", ns: true, api: "v1", cls: "rb-def", actions: std(), tabs: ["details", "yaml", "events"] }, o));

  def("Pod", {
    plural: "pods", label: "Pods", abbr: "P", cls: "rb-pod", help: "pod",
    cols: [
      { t: "Status", v: (o) => R.status(podStatus(o)), s: podStatus, h: "pod-status", id: "status" },
      { t: "Ready", v: podReady, s: podReady, h: "ready" },
      { t: "Restarts", v: podRestarts, s: podRestarts, h: "restarts" },
      C.owner,
      { t: "Memory", v: (o) => (o._m.mem ? U.mib(o._m.mem) : "-"), s: (o) => o._m.mem, h: "pod-memory" },
      { t: "CPU", v: (o) => (o._m.cpu ? U.num(o._m.cpu, 3) + " cores" : "-"), s: (o) => o._m.cpu, h: "pod-cpu" },
      C.created,
      { t: "Node", v: (o) => (o.spec.nodeName ? R.link("Node", null, o.spec.nodeName) : "-"), s: (o) => o.spec.nodeName, h: "node-field", hidden: true },
      { t: "Labels", v: (o) => R.labels(o.metadata.labels, "Pod"), h: "labels", hidden: true, cls: "c-labels" }
    ],
    filter: { title: "Status", fn: (o) => { const s = podStatus(o); return ["Running", "Pending", "Terminating", "CrashLoopBackOff", "Completed", "Failed"].indexOf(s) >= 0 ? s : s === "ImagePullBackOff" ? "Pending" : s === "Succeeded" ? "Completed" : "Failed"; }, opts: ["Running", "Pending", "Terminating", "CrashLoopBackOff", "Completed", "Failed"] },
    tabs: ["details", "metrics", "yaml", "environment", "logs", "events", "terminal"],
    details: (o) => ({
      l: OC.metaRows(o, [["Node selector", o.spec.nodeSelector ? R.labels(o.spec.nodeSelector) : "No selector", "node-selector"], ["Tolerations", R.count((o.spec.tolerations || []).length, "toleration"), "tolerations"]]),
      r: [["Status", R.status(podStatus(o)), "pod-status"], ["Restart policy", { Always: "Always restart", OnFailure: "Restart on failure", Never: "Never restart" }[o.spec.restartPolicy], "restart-policy"], ["Active deadline seconds", o.spec.activeDeadlineSeconds || "Not configured", "active-deadline"], ["Pod IP", o.status.podIP, "pod-ip"], ["Host IP", o.status.hostIP, "host-ip"], ["Node", o.spec.nodeName ? R.link("Node", null, o.spec.nodeName) : "-", "node-field"], ["Service account", R.link("ServiceAccount", o.metadata.namespace, o.spec.serviceAccountName), "serviceaccount-field"], ["Security context constraint", esc(o.metadata.annotations["openshift.io/scc"]), "pod-scc"], ["QoS class", o.status.qosClass, "qos-class"], ["PodDisruptionBudget", (() => { const p = (db.PodDisruptionBudget || []).find((b) => b.metadata.namespace === o.metadata.namespace && selMatch(b.spec.selector, o.metadata.labels)); return p ? R.link("PodDisruptionBudget", p.metadata.namespace, p.metadata.name) : "No PodDisruptionBudget"; })(), "pdb-field"], ["Receiving Traffic", (() => { const ok = o.status.containerStatuses && o.status.containerStatuses[0] && o.status.containerStatuses[0].ready && db.Service.some((s) => s.metadata.namespace === o.metadata.namespace && selMatch(s.spec.selector, o.metadata.labels)); return ok ? U.ico("check", 13) + " Yes" : U.ico("ban", 13) + " No"; })(), "receiving-traffic"]]
    }),
    sections: (o) => {
      const cs = o.status.containerStatuses || [];
      const crow = o.spec.containers.map((c, i) => { const s = cs[i]; const st = s ? (s.state.running ? "Running" : s.state.waiting ? s.state.waiting.reason : s.state.terminated.reason) : "Waiting"; const ls = s && s.lastState && s.lastState.terminated ? s.lastState.terminated.reason + " (" + s.lastState.terminated.exitCode + ")" : "-"; const term = s && s.state.terminated; return [`<span class="rlink">${R.badge("Container")}<a href="#" data-nop="1" data-h="container">${esc(c.name)}</a></span>`, `<span class="mono">${esc(c.image)}</span>`, R.status(st), ls, s ? s.restartCount : 0, s && s.state.running ? U.ts(s.state.running.startedAt) : term ? U.ts(term.startedAt) : "-", term ? U.ts(term.finishedAt) : "-", term ? term.exitCode : "-"]; });
      const vols = [];
      o.spec.containers.forEach((c) => (c.volumeMounts || []).forEach((m) => { const v = (o.spec.volumes || []).find((x) => x.name === m.name) || {}; const type = v.persistentVolumeClaim ? `${R.badge("PersistentVolumeClaim")}<a href="${R.href("PersistentVolumeClaim", o.metadata.namespace, v.persistentVolumeClaim.claimName)}">${esc(v.persistentVolumeClaim.claimName)}</a>` : v.configMap ? `${R.badge("ConfigMap")}<a href="${R.href("ConfigMap", o.metadata.namespace, v.configMap.name)}">${esc(v.configMap.name)}</a>` : v.secret ? `${R.badge("Secret")}<a href="${R.href("Secret", o.metadata.namespace, v.secret.secretName)}">${esc(v.secret.secretName)}</a>` : v.projected ? "Projected" : v.emptyDir ? "Empty Directory" : "Other"; vols.push([esc(m.name), `<span class="mono">${esc(m.mountPath)}</span>`, m.subPath ? esc(m.subPath) : "No subpath", type, m.readOnly ? "Read-only" : "Read/Write", `${R.badge("Container")}${esc(c.name)}`]); }));
      return R.section("Containers", R.table([["Name", "container"], ["Image", "image"], ["State", "container-state"], ["Last State", "last-state"], ["Restarts", "restarts"], ["Started"], ["Finished"], ["Exit code", "exit-code"]], crow), "container") +
        R.section("Volumes", R.table([["Name", "volumes"], ["Mount path", "mount-path"], ["SubPath", "subpath"], ["Type"], ["Permissions", "volume-permissions"], ["Utilized by"]], vols), "volumes") +
        R.section("Conditions", condTable(o.status.conditions), null);
    },
    actions: [A.labels, A.ann, ["Edit Pod", (o) => "oc edit pod " + o.metadata.name, "tab-yaml"], ["Delete Pod", (o) => "oc delete pod " + o.metadata.name, "owner", "danger", "deletePod"]],
    tpl: { apiVersion: "v1", kind: "Pod", metadata: { name: "ornek-pod", labels: { app: "ornek" } }, spec: { containers: [{ name: "httpd", image: "registry.access.redhat.com/ubi9/httpd-24:latest", ports: [{ containerPort: 8080 }], securityContext: { allowPrivilegeEscalation: false, capabilities: { drop: ["ALL"] } } }], securityContext: { runAsNonRoot: true, seccompProfile: { type: "RuntimeDefault" } } } }
  });
  function condTable(conds) {
    return R.table([["Type"], ["Status"], ["Updated"], ["Reason"], ["Message"]], (conds || []).map((c) => [esc(c.type), esc(c.status), c.lastTransitionTime || c.lastUpdateTime ? U.ts(c.lastTransitionTime || c.lastUpdateTime) : "-", esc(c.reason || "-"), `<span class="msg">${esc(c.message || "-")}</span>`]), { empty: "No conditions" });
  }
  OC.condTable = condTable;

  const wlActions = (k) => [["Edit Pod count", (o) => `oc scale ${k.toLowerCase()}/${o.metadata.name} --replicas=<sayı>`, "replicas", null, "scale"], k === "Deployment" ? ["Pause rollouts", (o) => `oc rollout pause deployment/${o.metadata.name}`, "strategy"] : null, ["Restart rollout", (o) => `oc rollout restart ${k.toLowerCase()}/${o.metadata.name}`, "strategy"], ["Add HorizontalPodAutoscaler", (o) => `oc autoscale ${k.toLowerCase()}/${o.metadata.name} --min=2 --max=5 --cpu-percent=70`, "hpa"], ["Add PodDisruptionBudget", (o) => `oc create poddisruptionbudget ${o.metadata.name}-pdb --selector=app=${o.metadata.name} --min-available=1`, "pdb"], ["Add storage", (o) => `oc set volume ${k.toLowerCase()}/${o.metadata.name} --add --claim-name=<pvc> --mount-path=/data`, "pvc"], k === "Deployment" ? ["Edit update strategy", (o) => `oc patch deployment/${o.metadata.name} -p '{"spec":{"strategy":{"type":"Recreate"}}}'`, "strategy"] : null, ["Edit resource limits", (o) => `oc set resources ${k.toLowerCase()}/${o.metadata.name} --limits=cpu=500m,memory=512Mi`, "requests-limits"]].filter(Boolean).concat([A.labels, A.ann, ["Edit " + k, (o) => `oc edit ${k.toLowerCase()}/${o.metadata.name}`, "tab-yaml"], ["Delete " + k, (o) => `oc delete ${k.toLowerCase()}/${o.metadata.name}`, null, "danger"]]);
  const containersSec = (o) => R.section("Containers", R.table([["Name", "container"], ["Image", "image"], ["Ports", "ports"], ["Requests", "requests-limits"], ["Limits", "requests-limits"]], R.cnt(o).map((c) => [`<span class="rlink">${R.badge("Container")}${esc(c.name)}</span>`, `<span class="mono">${esc(c.image)}</span>`, (c.ports || []).map((p) => p.containerPort + "/" + p.protocol).join(", "), c.resources && c.resources.requests ? `cpu: ${c.resources.requests.cpu}, memory: ${c.resources.requests.memory}` : "-", c.resources && c.resources.limits ? `cpu: ${c.resources.limits.cpu}, memory: ${c.resources.limits.memory}` : "-"])), "container");
  const volsSec = (o) => { const v = o.spec.template.spec.volumes || []; return v.length ? R.section("Volumes", R.table([["Name", "volumes"], ["Type"]], v.map((x) => [esc(x.name), x.persistentVolumeClaim ? "PVC: " + R.link("PersistentVolumeClaim", o.metadata.namespace, x.persistentVolumeClaim.claimName) : x.configMap ? "ConfigMap: " + R.link("ConfigMap", o.metadata.namespace, x.configMap.name) : x.secret ? "Secret: " + R.link("Secret", o.metadata.namespace, x.secret.secretName) : "Other"])), "volumes") : ""; };

  def("Deployment", {
    plural: "deployments", abbr: "D", cls: "rb-wl", api: "apps/v1", help: "deployment",
    cols: [C.wl, C.labels, C.podsel], ring: true,
    tabs: ["details", "metrics", "yaml", "replicasets", "pods", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o, tplRows(o)), r: [["Update strategy", o.spec.strategy.type, "strategy"], ["Max unavailable", o.spec.strategy.rollingUpdate ? o.spec.strategy.rollingUpdate.maxUnavailable + " of " + o.spec.replicas + " pod" : "-", "max-surge"], ["Max surge", o.spec.strategy.rollingUpdate ? o.spec.strategy.rollingUpdate.maxSurge + " greater than " + o.spec.replicas + " pod" : "-", "max-surge"], ["Progress deadline seconds", o.spec.progressDeadlineSeconds + " seconds", "progress-deadline"], ["Min ready seconds", "Not configured"], ["Revision history limit", o.spec.revisionHistoryLimit, "revision-history"], ["Current revision", o.metadata.annotations["deployment.kubernetes.io/revision"], "revision-history"]] }),
    sections: (o) => containersSec(o) + volsSec(o) + R.section("Conditions", condTable(o.status.conditions)),
    actions: wlActions("Deployment"),
    tpl: { apiVersion: "apps/v1", kind: "Deployment", metadata: { name: "ornek", namespace: "eticaret-test" }, spec: { replicas: 3, selector: { matchLabels: { app: "ornek" } }, template: { metadata: { labels: { app: "ornek" } }, spec: { containers: [{ name: "container", image: "registry.access.redhat.com/ubi9/httpd-24:latest", ports: [{ containerPort: 8080, protocol: "TCP" }], resources: { requests: { cpu: "100m", memory: "128Mi" }, limits: { memory: "256Mi" } } }] } }, strategy: { type: "RollingUpdate", rollingUpdate: { maxSurge: "25%", maxUnavailable: "25%" } } } },
    form: [["name", "Name", "text", "ornek-uygulama", "name"], ["image", "Image name", "text", "registry.access.redhat.com/ubi9/httpd-24:latest", "image"], ["replicas", "Replicas", "number", 3, "replicas"], ["port", "Container port", "number", 8080, "ports"], ["strategy", "Strategy type", "select", ["RollingUpdate", "Recreate"], "strategy"], ["cpu", "CPU request", "text", "100m", "requests-limits"], ["memory", "Memory limit", "text", "256Mi", "requests-limits"], ["env", "Environment variable (AD=DEGER)", "text", "LOG_LEVEL=INFO", "env"], ["route", "Create a route", "checkbox", true, "route"]]
  });
  def("DeploymentConfig", {
    plural: "deploymentconfigs", abbr: "DC", cls: "rb-wl", api: "apps.openshift.io/v1", help: "deploymentconfig",
    cols: [C.wl, C.labels, C.podsel], ring: true,
    tabs: ["details", "metrics", "yaml", "replicationcontrollers", "pods", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o, tplRows(o)), r: [["Latest version", o.status.latestVersion, "latest-version"], ["Message", o.status.details ? o.status.details.message : "-"], ["Update strategy", o.spec.strategy.type, "strategy"], ["Timeout", o.spec.strategy.rollingParams.timeoutSeconds + " seconds"], ["Update period", o.spec.strategy.rollingParams.updatePeriodSeconds + " second"], ["Max unavailable", o.spec.strategy.rollingParams.maxUnavailable, "max-surge"], ["Max surge", o.spec.strategy.rollingParams.maxSurge, "max-surge"], ["Triggers", o.spec.triggers.map((t) => t.type).join(", "), "dc-triggers"]] }),
    sections: (o) => `<div class="alert alert-info">${U.ico("info", 16)}<div><b>DeploymentConfig is deprecated</b><p>OpenShift 4.14'ten itibaren DeploymentConfig kullanımdan kaldırılma sürecindedir. Yeni uygulamalar için Deployment kullanın.</p></div>${R.q("deploymentconfig")}</div>` + containersSec(o) + R.section("Conditions", condTable(o.status.conditions)),
    actions: [["Start rollout", (o) => "oc rollout latest dc/" + o.metadata.name, "latest-version"]].concat(wlActions("DeploymentConfig"))
  });
  def("StatefulSet", {
    plural: "statefulsets", abbr: "SS", cls: "rb-wl", api: "apps/v1", help: "statefulset",
    cols: [C.wl, C.labels, C.podsel], ring: true,
    tabs: ["details", "metrics", "yaml", "pods", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o, tplRows(o)), r: [["Service name", R.link("Service", o.metadata.namespace, o.spec.serviceName), "headless-service"], ["Update strategy", o.spec.updateStrategy.type, "strategy"], ["Pod management policy", o.spec.podManagementPolicy, "pod-management-policy"], ["Current revision", esc(o.status.currentRevision)]] }),
    sections: (o) => containersSec(o) + R.section("Volume claim templates", R.table([["Name"], ["Access modes", "access-modes"], ["Size", "capacity"], ["StorageClass", "storage-class-field"]], (o.spec.volumeClaimTemplates || []).map((t) => [esc(t.metadata.name), t.spec.accessModes.join(", "), t.spec.resources.requests.storage, R.link("StorageClass", null, t.spec.storageClassName)]), { empty: "No volume claim templates" }), "volume-claim-templates"),
    actions: wlActions("StatefulSet")
  });
  def("DaemonSet", {
    plural: "daemonsets", abbr: "DS", cls: "rb-wl", api: "apps/v1", help: "daemonset",
    cols: [{ t: "Status", v: (o) => `<a class="pods-link" href="${R.href("DaemonSet", o.metadata.namespace, o.metadata.name, "pods")}">${U.ico("check", 13)} ${o.status.numberReady} of ${o.status.desiredNumberScheduled} pods</a>`, h: "ds-status" }, C.labels, C.podsel],
    tabs: ["details", "metrics", "yaml", "pods", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o, tplRows(o)), r: [["Current count", o.status.currentNumberScheduled, "ds-status"], ["Desired count", o.status.desiredNumberScheduled, "ds-status"], ["Update strategy", o.spec.updateStrategy.type, "strategy"], ["Max unavailable", o.spec.updateStrategy.rollingUpdate.maxUnavailable, "max-surge"]] }),
    sections: (o) => containersSec(o)
  });
  def("ReplicaSet", {
    plural: "replicasets", abbr: "RS", cls: "rb-wl", api: "apps/v1", help: "replicaset",
    cols: [{ t: "Status", v: (o) => `${o.status.readyReplicas || 0} of ${o.spec.replicas} pods`, h: "replicas" }, C.owner, C.created],
    tabs: ["details", "yaml", "pods", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o, [["Pod selector", R.selector(o.spec.selector, o.metadata.namespace), "selector"]]), r: [["Desired replicas", o.spec.replicas, "replicas"], ["Current replicas", o.status.replicas], ["Revision", o.metadata.annotations["deployment.kubernetes.io/revision"], "revision-history"]] }),
    sections: (o) => containersSec(o)
  });
  def("ReplicationController", {
    plural: "replicationcontrollers", abbr: "RC", cls: "rb-wl", help: "replicationcontroller",
    cols: [{ t: "Status", v: (o) => `${o.status.readyReplicas || 0} of ${o.spec.replicas} pods`, h: "replicas" }, { t: "Phase", v: (o) => R.status(o.metadata.annotations["openshift.io/deployment.phase"] || "-") }, C.owner, C.created],
    tabs: ["details", "yaml", "pods", "events"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Phase", R.status(o.metadata.annotations["openshift.io/deployment.phase"])], ["Desired replicas", o.spec.replicas, "replicas"], ["Version", o.metadata.annotations["openshift.io/deployment-config.latest-version"], "latest-version"]] })
  });
  def("ControllerRevision", { plural: "controllerrevisions", abbr: "CR", cls: "rb-wl", api: "apps/v1", help: "controllerrevision", cols: [C.owner, { t: "Revision", v: (o) => o.revision }, C.created] });
  def("Job", {
    plural: "jobs", abbr: "J", cls: "rb-wl", api: "batch/v1", help: "job",
    cols: [{ t: "Completions", v: (o) => `<a href="${R.href("Job", o.metadata.namespace, o.metadata.name, "pods")}">${o.status.succeeded || 0} of ${o.spec.completions}</a>`, h: "completions" }, { t: "Status", v: (o) => R.status(jobStatus(o)), s: (o) => jobStatus(o) }, { t: "Type", v: (o) => (o.spec.parallelism > 1 ? "Parallel" : "Non-parallel") }, C.owner, C.created],
    filter: { title: "Status", fn: (o) => jobStatus(o), opts: ["Running", "Complete", "Failed"] },
    tabs: ["details", "yaml", "pods", "events"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Desired completions", o.spec.completions, "completions"], ["Parallelism", o.spec.parallelism, "completions"], ["Backoff limit", o.spec.backoffLimit, "backoff-limit"], ["Status", R.status(jobStatus(o))], ["Start time", U.ts(o.status.startTime)], ["Completion time", o.status.completionTime ? U.ts(o.status.completionTime) : "-"], ["Succeeded pods", o.status.succeeded || 0], ["Failed pods", o.status.failed || 0]] }),
    sections: (o) => R.section("Conditions", condTable(o.status.conditions)),
    tpl: { apiVersion: "batch/v1", kind: "Job", metadata: { name: "ornek-job" }, spec: { backoffLimit: 4, template: { spec: { restartPolicy: "Never", containers: [{ name: "pi", image: "registry.access.redhat.com/ubi9/perl-536", command: ["perl", "-Mbignum=bpi", "-wle", "print bpi(2000)"] }] } } } }
  });
  function jobStatus(o) { const c = (o.status.conditions || []).find((x) => (x.type === "Complete" || x.type === "Failed") && x.status === "True"); return c ? c.type : "Running"; }
  def("CronJob", {
    plural: "cronjobs", abbr: "CJ", cls: "rb-wl", api: "batch/v1", help: "cronjob",
    cols: [{ t: "Schedule", v: (o) => `<span class="mono">${esc(o.spec.schedule)}</span>`, h: "cron-schedule" }, { t: "Suspend", v: (o) => (o.spec.suspend ? R.status("Suspended") : "False"), h: "suspend" }, { t: "Concurrency policy", v: (o) => o.spec.concurrencyPolicy, h: "concurrency-policy" }, { t: "Starting deadline seconds", v: (o) => o.spec.startingDeadlineSeconds + " seconds", h: "starting-deadline" }, { t: "Last schedule", v: (o) => U.ts(o.status.lastScheduleTime), s: (o) => o.status.lastScheduleTime }],
    tabs: ["details", "yaml", "jobs", "pods", "events"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Schedule", `<span class="mono">${esc(o.spec.schedule)}</span> <span class="muted">(${cronText(o.spec.schedule)})</span>`, "cron-schedule"], ["Time zone", o.spec.timeZone, "cron-schedule"], ["Suspend", String(o.spec.suspend), "suspend"], ["Concurrency policy", o.spec.concurrencyPolicy, "concurrency-policy"], ["Starting deadline seconds", o.spec.startingDeadlineSeconds + " seconds", "starting-deadline"], ["Last schedule time", U.ts(o.status.lastScheduleTime)], ["Successful jobs history limit", o.spec.successfulJobsHistoryLimit, "history-limit"], ["Failed jobs history limit", o.spec.failedJobsHistoryLimit, "history-limit"]] }),
    actions: std([["Start Job", (o) => `oc create job --from=cronjob/${o.metadata.name} ${o.metadata.name}-manuel`, "job"], ["Suspend", (o) => `oc patch cronjob/${o.metadata.name} -p '{"spec":{"suspend":true}}'`, "suspend"]]),
    tpl: { apiVersion: "batch/v1", kind: "CronJob", metadata: { name: "ornek-cronjob" }, spec: { schedule: "0 2 * * *", timeZone: "Europe/Istanbul", concurrencyPolicy: "Forbid", jobTemplate: { spec: { template: { spec: { restartPolicy: "OnFailure", containers: [{ name: "rapor", image: "registry.access.redhat.com/ubi9/ubi-minimal", command: ["/bin/sh", "-c", "date; echo Rapor hazirlandi"] }] } } } } } },
    form: [["name", "Name", "text", "gece-isi", "name"], ["schedule", "Schedule", "text", "0 2 * * *", "cron-schedule"], ["tz", "Time zone", "text", "Europe/Istanbul", "cron-schedule"], ["image", "Image", "text", "registry.access.redhat.com/ubi9/ubi-minimal", "image"], ["policy", "Concurrency policy", "select", ["Forbid", "Allow", "Replace"], "concurrency-policy"]]
  });
  function cronText(s) {
    const p = s.split(" ");
    if (s.indexOf("*/") === 0) return "her " + p[0].slice(2) + " dakikada bir";
    if (p[1].indexOf("*/") === 0) return "her " + p[1].slice(2) + " saatte bir, dakika " + p[0];
    const t = ("0" + p[1]).slice(-2) + ":" + ("0" + p[0]).slice(-2);
    if (p[4] !== "*") return "her " + ["pazar", "pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi"][+p[4]] + " " + t;
    return "her gün " + t;
  }
  OC.cronText = cronText;
  def("HorizontalPodAutoscaler", {
    plural: "horizontalpodautoscalers", abbr: "HPA", cls: "rb-wl", api: "autoscaling/v2", help: "hpa",
    cols: [{ t: "Scale target", v: (o) => R.link(o.spec.scaleTargetRef.kind, o.metadata.namespace, o.spec.scaleTargetRef.name) }, { t: "Min pods", v: (o) => o.spec.minReplicas, h: "replicas" }, { t: "Max pods", v: (o) => o.spec.maxReplicas, h: "replicas" }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [["Scale target", R.link(o.spec.scaleTargetRef.kind, o.metadata.namespace, o.spec.scaleTargetRef.name)], ["Min replicas", o.spec.minReplicas, "replicas"], ["Max replicas", o.spec.maxReplicas, "replicas"], ["Last scale time", o.status.lastScaleTime ? U.ts(o.status.lastScaleTime) : "-"], ["Current replicas", o.status.currentReplicas], ["Desired replicas", o.status.desiredReplicas]] }),
    sections: (o) => R.section("Metrics", R.table([["Type"], ["Current", "hpa-target"], ["Target", "hpa-target"]], o.spec.metrics.map((m, i) => { const cur = (o.status.currentMetrics || [])[i]; return [esc(m.resource.name) + " resource utilization", cur ? cur.resource.current.averageUtilization + "%" : "-", m.resource.target.averageUtilization + "%"]; })), "hpa-target") + R.section("Conditions", condTable(o.status.conditions))
  });
  def("PodDisruptionBudget", {
    plural: "poddisruptionbudgets", abbr: "PDB", cls: "rb-wl", api: "policy/v1", help: "pdb",
    cols: [{ t: "Selector", v: (o) => R.selector(o.spec.selector, o.metadata.namespace), h: "selector" }, { t: "Availability", v: (o) => (o.spec.minAvailable != null ? "Min available " + o.spec.minAvailable : "Max unavailable " + o.spec.maxUnavailable), h: "pdb-values" }, { t: "Allowed disruptions", v: (o) => o.status.disruptionsAllowed, h: "pdb-values" }, C.created],
    details: (o) => ({ l: OC.metaRows(o, [["Selector", R.selector(o.spec.selector, o.metadata.namespace), "selector"]]), r: [[o.spec.minAvailable != null ? "Min available" : "Max unavailable", o.spec.minAvailable != null ? o.spec.minAvailable : o.spec.maxUnavailable, "pdb-values"], ["Allowed disruptions", o.status.disruptionsAllowed, "pdb-values"], ["Current healthy", o.status.currentHealthy], ["Desired healthy", o.status.desiredHealthy], ["Expected pods", o.status.expectedPods]] })
  });

  /* ---- Config ---- */
  def("Secret", {
    plural: "secrets", abbr: "S", cls: "rb-cfg", help: "secret",
    cols: [{ t: "Type", v: (o) => esc(o.type), s: (o) => o.type, h: "secret-type" }, { t: "Size", v: sizeOf, s: sizeOf }, C.created],
    filter: { title: "Type", fn: (o) => (o.type === "kubernetes.io/dockercfg" || o.type === "kubernetes.io/dockerconfigjson" ? "Image" : o.type === "kubernetes.io/tls" ? "TLS" : o.type === "Opaque" ? "Opaque" : o.type === "kubernetes.io/service-account-token" ? "Service account token" : "Source"), opts: ["Image", "Opaque", "Service account token", "Source", "TLS"] },
    details: (o) => ({ l: OC.metaRows(o), r: [["Type", esc(o.type), "secret-type"]] }),
    sections: (o) => R.section("Data", `<div class="secret-data" data-secret="1">${Object.keys(o.data || {}).map((k) => { let v = ""; try { v = decodeURIComponent(escape(atob(o.data[k]))); } catch (e) { v = o.data[k]; } return `<div class="kv"><div class="kv-k">${esc(k)}</div><div class="kv-v"><span class="masked">••••••••••</span><pre class="revealed">${esc(v)}</pre></div></div>`; }).join("")}</div>`, "secret", ` <button class="btn btn-link btn-sm reveal-btn" data-reveal="1">${U.ico("lock", 12)} Reveal values</button>`),
    actions: std([["Add Secret to workload", (o) => `oc set env deploy/<ad> --from=secret/${o.metadata.name}`, "env"]]),
    tpl: { apiVersion: "v1", kind: "Secret", metadata: { name: "ornek-secret" }, type: "Opaque", stringData: { kullanici: "uygulama", parola: "degistir-beni" } },
    form: [["name", "Secret name", "text", "veritabani-kimlik", "name"], ["type", "Secret type", "select", ["Opaque", "kubernetes.io/tls", "kubernetes.io/dockerconfigjson", "kubernetes.io/basic-auth", "kubernetes.io/ssh-auth"], "secret-type"], ["key", "Key", "text", "database-password", "secret"], ["value", "Value", "password", "", "secret"]]
  });
  def("ConfigMap", {
    plural: "configmaps", abbr: "CM", cls: "rb-cfg", help: "configmap",
    cols: [{ t: "Size", v: sizeOf, s: sizeOf, h: "configmap-data" }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [] }),
    sections: (o) => R.section("Data", Object.keys(o.data || {}).map((k) => `<div class="kv"><div class="kv-k">${esc(k)}</div><pre class="kv-v code">${esc(o.data[k])}</pre></div>`).join("") || '<div class="empty-s">No data</div>', "configmap-data") + R.section("Binary data", '<div class="empty-s">No binary data</div>'),
    actions: std([["Add ConfigMap to workload", (o) => `oc set env deploy/<ad> --from=configmap/${o.metadata.name}`, "envfrom"]]),
    tpl: { apiVersion: "v1", kind: "ConfigMap", metadata: { name: "ornek-config" }, data: { LOG_LEVEL: "INFO", "application.properties": "server.port=8080\nfeature.x=true\n" } },
    form: [["name", "Name", "text", "uygulama-ayarlari", "name"], ["key", "Key", "text", "LOG_LEVEL", "configmap-data"], ["value", "Value", "textarea", "INFO", "configmap-data"]]
  });

  /* ---- Networking ---- */
  def("Service", {
    plural: "services", abbr: "S", cls: "rb-net", help: "service",
    cols: [C.labels, C.podsel.v ? { t: "Pod selector", v: (o) => R.selector(o.spec.selector, o.metadata.namespace), h: "selector" } : null, { t: "Location", v: (o) => (o.spec.type === "ExternalName" ? esc(o.spec.externalName) : (o.spec.ports || []).map((p) => `<div class="mono">${esc(o.spec.clusterIP)}:${p.port}</div>`).join("")), h: "cluster-ip" }],
    tabs: ["details", "yaml", "pods", "events"],
    details: (o) => ({ l: OC.metaRows(o, [["Pod selector", R.selector(o.spec.selector, o.metadata.namespace), "selector"], ["Session affinity", o.spec.sessionAffinity, "session-affinity"]]), r: [] }),
    sections: (o) => R.section("Service routing", R.dl([["Hostname", `<span class="mono">${esc(o.metadata.name)}.${esc(o.metadata.namespace)}.svc.cluster.local</span><div class="muted sm">Accessible within the cluster only</div>`, "service"], ["Service address", `<b>Type:</b> ${o.spec.type} ${R.q("service-type")}<br><b>Cluster IP:</b> <span class="mono">${esc(o.spec.clusterIP || "-")}</span>`, "cluster-ip"]]) + R.table([["Name"], ["Port", "target-port"], ["Protocol"], ["Pod port or name", "target-port"]].concat(o.spec.type !== "ClusterIP" ? [["Node port", "target-port"]] : []), (o.spec.ports || []).map((p) => [esc(p.name || "-"), p.port, p.protocol, p.targetPort].concat(o.spec.type !== "ClusterIP" ? [p.nodePort] : [])), { empty: "No ports" }), "service"),
    actions: std([["Edit Pod selector", (o) => `oc set selector svc/${o.metadata.name} app=<yeni>`, "selector"]]),
    tpl: { apiVersion: "v1", kind: "Service", metadata: { name: "ornek" }, spec: { selector: { app: "ornek" }, ports: [{ name: "http", protocol: "TCP", port: 8080, targetPort: 8080 }], type: "ClusterIP" } }
  });
  K.Service.cols = K.Service.cols.filter(Boolean);
  const routeUrl = (o) => (o.spec.tls ? "https://" : "http://") + o.spec.host + (o.spec.path || "");
  def("Route", {
    plural: "routes", abbr: "RT", cls: "rb-net", api: "route.openshift.io/v1", help: "route",
    cols: [{ t: "Status", v: (o) => R.status("Accepted"), h: "route-status" }, { t: "Location", v: (o) => `<a class="ext" href="#" data-nop="1" data-ext="${esc(routeUrl(o))}">${esc(routeUrl(o))} ${U.ico("ext", 11)}</a>`, h: "route-host" }, { t: "Service", v: (o) => R.link("Service", o.metadata.namespace, o.spec.to.name), h: "route-target" }],
    details: (o) => ({ l: OC.metaRows(o, [["Service", R.link("Service", o.metadata.namespace, o.spec.to.name), "route-target"], ["Target port", esc(o.spec.port ? o.spec.port.targetPort : "-"), "target-port"]]), r: [["Location", `<a class="ext" href="#" data-nop="1" data-ext="${esc(routeUrl(o))}">${esc(routeUrl(o))} ${U.ico("ext", 11)}</a>`, "route-host"], ["Status", R.status("Accepted"), "route-status"], ["Host", esc(o.spec.host), "route-host"], ["Path", o.spec.path || "None", "route-path"], ["Router canonical hostname", esc(o.status.ingress && o.status.ingress[0].routerCanonicalHostname || "router-default." + OC.cluster.domain)], ["Weight", o.spec.to.weight, "route-target"]] }),
    sections: (o) => R.section("TLS settings", o.spec.tls ? R.dl([["Termination type", o.spec.tls.termination, "tls-termination"], ["Insecure traffic", o.spec.tls.insecureEdgeTerminationPolicy || "None", "insecure-policy"], ["Certificate", o.spec.tls.certificate ? "Configured" : "Default ingress certificate (*." + OC.cluster.domain + ")", "tls-termination"]]) : '<div class="empty-s">TLS is not enabled.</div>', "tls-termination") + R.section("Router: default", R.dl([["Host", esc(o.spec.host)], ["Wildcard policy", o.spec.wildcardPolicy], ["Admitted", R.status("Admitted"), "route-status"]])),
    actions: std([["Edit Route", (o) => `oc edit route/${o.metadata.name}`, "route"]]),
    tpl: { apiVersion: "route.openshift.io/v1", kind: "Route", metadata: { name: "ornek" }, spec: { host: "ornek-eticaret-test." + OC.cluster.domain, to: { kind: "Service", name: "ornek" }, port: { targetPort: "http" }, tls: { termination: "edge", insecureEdgeTerminationPolicy: "Redirect" } } },
    form: [["name", "Name", "text", "ornek-route", "name"], ["host", "Hostname", "text", "", "route-host"], ["path", "Path", "text", "/", "route-path"], ["service", "Service", "select", ["frontend", "katalog-api", "postgresql"], "route-target"], ["port", "Target port", "text", "8080 → 8080 (TCP)", "target-port"], ["secure", "Secure Route", "checkbox", true, "tls-termination"], ["term", "TLS termination", "select", ["Edge", "Passthrough", "Re-encrypt"], "tls-termination"], ["insecure", "Insecure traffic", "select", ["Redirect", "None", "Allow"], "insecure-policy"]]
  });
  def("Ingress", {
    plural: "ingresses", abbr: "I", cls: "rb-net", api: "networking.k8s.io/v1", help: "ingress", label: "Ingresses",
    cols: [{ t: "Host", v: (o) => o.spec.rules.map((r) => esc(r.host)).join("<br>") }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [["Ingress class", o.spec.ingressClassName], ["TLS secret", o.spec.tls ? R.link("Secret", o.metadata.namespace, o.spec.tls[0].secretName) : "-", "secret-type"]] }),
    sections: (o) => R.section("Ingress rules", R.table([["Host"], ["Path"], ["Path type"], ["Service"], ["Service port"]], [].concat.apply([], o.spec.rules.map((r) => r.http.paths.map((p) => [esc(r.host), p.path, p.pathType, R.link("Service", o.metadata.namespace, p.backend.service.name), p.backend.service.port.number]))))) + `<div class="alert alert-info">${U.ico("info", 16)}<div>OpenShift bu Ingress'i otomatik olarak Route nesnesine dönüştürür (ingress-to-route controller).</div>${R.q("route")}</div>`
  });
  def("NetworkPolicy", {
    plural: "networkpolicies", abbr: "NP", cls: "rb-net", api: "networking.k8s.io/v1", help: "networkpolicy", label: "NetworkPolicies",
    cols: [{ t: "Pod selector", v: (o) => (Object.keys(o.spec.podSelector.matchLabels || {}).length ? R.selector(o.spec.podSelector, o.metadata.namespace) : '<span class="muted">All pods within namespace</span>'), h: "pod-selector" }, { t: "Policy types", v: (o) => (o.spec.policyTypes || []).join(", "), h: "policy-types" }, C.created],
    details: (o) => ({ l: OC.metaRows(o, [["Pod selector", Object.keys(o.spec.podSelector.matchLabels || {}).length ? R.selector(o.spec.podSelector) : "All pods within namespace", "pod-selector"]]), r: [["Policy types", (o.spec.policyTypes || []).join(", "), "policy-types"]] }),
    sections: (o) => {
      const peer = (f) => f.podSelector ? "Pods: " + (Object.keys(f.podSelector.matchLabels || {}).map((k) => k + "=" + f.podSelector.matchLabels[k]).join(",") || "all in namespace") : f.namespaceSelector ? "Namespaces: " + Object.keys(f.namespaceSelector.matchLabels || {}).map((k) => k + "=" + f.namespaceSelector.matchLabels[k]).join(",") : f.ipBlock ? "IP block: " + f.ipBlock.cidr : "-";
      const ing = (o.spec.ingress || []).map((r) => [(r.from || []).map((f) => esc(peer(f))).join("<br>") || "Any", (r.ports || []).map((p) => p.protocol + "/" + p.port).join(", ") || "Any port"]);
      const eg = (o.spec.egress || []).map((r) => [(r.to || []).map((f) => esc(peer(f))).join("<br>") || "Any", (r.ports || []).map((p) => p.protocol + "/" + p.port).join(", ") || "Any port"]);
      return R.section("Ingress rules", (o.spec.policyTypes || []).indexOf("Ingress") >= 0 && !ing.length ? '<div class="alert alert-warn">' + U.ico("warn", 16) + "<div>Bu policy seçili Pod'lara gelen <b>tüm trafiği reddeder</b>.</div></div>" : R.table([["Traffic source"], ["To ports"]], ing, { empty: "Ingress kuralı yok" }), "policy-types") +
        R.section("Egress rules", (o.spec.policyTypes || []).indexOf("Egress") >= 0 && !eg.length ? '<div class="alert alert-warn">' + U.ico("warn", 16) + "<div>Bu policy seçili Pod'lardan çıkan <b>tüm trafiği reddeder</b>.</div></div>" : R.table([["Destination"], ["To ports"]], eg, { empty: "Egress kuralı yok (kısıtlanmıyor)" }), "policy-types");
    },
    tpl: { apiVersion: "networking.k8s.io/v1", kind: "NetworkPolicy", metadata: { name: "allow-from-frontend" }, spec: { podSelector: { matchLabels: { app: "katalog-api" } }, ingress: [{ from: [{ podSelector: { matchLabels: { app: "frontend" } } }], ports: [{ protocol: "TCP", port: 8080 }] }], policyTypes: ["Ingress"] } }
  });
  def("UserDefinedNetwork", { plural: "userdefinednetworks", abbr: "UDN", cls: "rb-net", api: "k8s.ovn.org/v1", help: "udn", cols: [C.created], tpl: { apiVersion: "k8s.ovn.org/v1", kind: "UserDefinedNetwork", metadata: { name: "ozel-ag" }, spec: { topology: "Layer2", layer2: { role: "Primary", subnets: ["10.200.0.0/16"] } } } });

  /* ---- Storage ---- */
  const pvcUsed = (o) => (o._used ? U.num(o._used, 1) + " GiB" : "-");
  def("PersistentVolumeClaim", {
    plural: "persistentvolumeclaims", abbr: "PVC", cls: "rb-sto", help: "pvc", label: "PersistentVolumeClaims",
    cols: [{ t: "Status", v: (o) => R.status(o.status.phase), s: (o) => o.status.phase, h: "pvc-status" }, { t: "PersistentVolumes", v: (o) => (o.spec.volumeName ? R.link("PersistentVolume", null, o.spec.volumeName) : "-"), h: "pv" }, { t: "Capacity", v: (o) => (o.status.capacity ? o.status.capacity.storage : "-"), h: "capacity" }, { t: "Used", v: pvcUsed, h: "capacity" }, { t: "StorageClass", v: (o) => R.link("StorageClass", null, o.spec.storageClassName), h: "storage-class-field" }],
    filter: { title: "Status", fn: (o) => o.status.phase, opts: ["Pending", "Lost", "Bound"] },
    tabs: ["details", "yaml", "events", "pods"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Status", R.status(o.status.phase), "pvc-status"], ["StorageClass", R.link("StorageClass", null, o.spec.storageClassName), "storage-class-field"], ["Requested capacity", o.spec.resources.requests.storage, "capacity"], ["Capacity", o.status.capacity ? o.status.capacity.storage : "-", "capacity"], ["Access modes", o.spec.accessModes.join(", "), "access-modes"], ["Volume mode", o.spec.volumeMode, "volume-mode"], ["PersistentVolume", o.spec.volumeName ? R.link("PersistentVolume", null, o.spec.volumeName) : "-", "pv"]] }),
    sections: (o) => o.status.phase === "Bound" ? R.section("Utilization", `<div class="util"><div class="util-bar"><span style="width:${Math.min(100, (o._used / parseFloat(o.status.capacity.storage)) * 100).toFixed(0)}%"></span></div><div class="muted">${pvcUsed(o)} of ${o.status.capacity.storage} used (${((o._used / parseFloat(o.status.capacity.storage)) * 100).toFixed(0)}%)</div></div>`, "capacity") : `<div class="alert alert-warn">${U.ico("warn", 16)}<div><b>PVC Pending durumda.</b> Provisioner uygun bir volume oluşturamadı veya bekliyor. Events sekmesini kontrol edin.</div>${R.q("pvc-status")}</div>`,
    actions: std([["Expand PVC", (o) => `oc patch pvc/${o.metadata.name} -p '{"spec":{"resources":{"requests":{"storage":"<yeni-boyut>"}}}}'`, "capacity"], ["Create snapshot", (o) => "VolumeSnapshot oluşturur (source: " + o.metadata.name + ")", "volumesnapshot"], ["Clone PVC", (o) => "dataSource: { kind: PersistentVolumeClaim, name: " + o.metadata.name + " }", "pvc"]]),
    tpl: { apiVersion: "v1", kind: "PersistentVolumeClaim", metadata: { name: "ornek-pvc" }, spec: { accessModes: ["ReadWriteOnce"], storageClassName: "thin-csi", resources: { requests: { storage: "5Gi" } }, volumeMode: "Filesystem" } },
    form: [["sc", "StorageClass", "select", ["thin-csi (default)", "ocs-storagecluster-ceph-rbd", "ocs-storagecluster-cephfs"], "storageclass"], ["name", "PersistentVolumeClaim name", "text", "ornek-pvc", "name"], ["mode", "Access mode", "select", ["Single user (RWO)", "Shared access (RWX)", "Read only (ROX)", "Single user pod (RWOP)"], "access-modes"], ["size", "Size", "text", "5Gi", "capacity"], ["vmode", "Volume mode", "select", ["Filesystem", "Block"], "volume-mode"]]
  });
  def("PersistentVolume", {
    plural: "persistentvolumes", abbr: "PV", cls: "rb-sto", ns: false, help: "pv", label: "PersistentVolumes",
    cols: [{ t: "Status", v: (o) => R.status(o.status.phase), h: "pvc-status" }, { t: "Claim", v: (o) => R.link("PersistentVolumeClaim", o.spec.claimRef.namespace, o.spec.claimRef.name) }, { t: "Capacity", v: (o) => o.spec.capacity.storage, h: "capacity" }, { t: "Reclaim policy", v: (o) => o.spec.persistentVolumeReclaimPolicy, h: "reclaim-policy" }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [["Status", R.status(o.status.phase)], ["Claim", R.link("PersistentVolumeClaim", o.spec.claimRef.namespace, o.spec.claimRef.name), "pvc"], ["Capacity", o.spec.capacity.storage, "capacity"], ["Access modes", o.spec.accessModes.join(", "), "access-modes"], ["Reclaim policy", o.spec.persistentVolumeReclaimPolicy, "reclaim-policy"], ["StorageClass", R.link("StorageClass", null, o.spec.storageClassName), "storage-class-field"], ["CSI driver", `<span class="mono">${esc(o.spec.csi.driver)}</span>`, "provisioner"], ["Volume handle", `<span class="mono sm">${esc(o.spec.csi.volumeHandle)}</span>`]] })
  });
  def("StorageClass", {
    plural: "storageclasses", abbr: "SC", cls: "rb-sto", ns: false, api: "storage.k8s.io/v1", help: "storageclass", label: "StorageClasses",
    cols: [{ t: "Provisioner", v: (o) => `<span class="mono">${esc(o.provisioner)}</span>${o.metadata.annotations && o.metadata.annotations["storageclass.kubernetes.io/is-default-class"] ? ' <span class="pill">Default</span>' : ""}`, h: "provisioner" }, { t: "Reclaim policy", v: (o) => o.reclaimPolicy, h: "reclaim-policy" }, { t: "Volume binding mode", v: (o) => o.volumeBindingMode, h: "volume-binding-mode" }],
    details: (o) => ({ l: OC.metaRows(o), r: [["Provisioner", `<span class="mono">${esc(o.provisioner)}</span>`, "provisioner"], ["Reclaim policy", o.reclaimPolicy, "reclaim-policy"], ["Default class", o.metadata.annotations && o.metadata.annotations["storageclass.kubernetes.io/is-default-class"] ? "true" : "false", "storageclass"], ["Volume binding mode", o.volumeBindingMode, "volume-binding-mode"], ["Allow volume expansion", String(o.allowVolumeExpansion), "allow-expansion"]] }),
    sections: (o) => R.section("Parameters", R.table([["Key"], ["Value"]], Object.keys(o.parameters || {}).map((k) => [esc(k), `<span class="mono">${esc(o.parameters[k])}</span>`])))
  });
  def("VolumeSnapshot", {
    plural: "volumesnapshots", abbr: "VS", cls: "rb-sto", api: "snapshot.storage.k8s.io/v1", help: "volumesnapshot",
    cols: [{ t: "Status", v: (o) => R.status(o.status.readyToUse ? "Ready" : "Pending") }, { t: "Size", v: (o) => o.status.restoreSize }, { t: "Source", v: (o) => R.link("PersistentVolumeClaim", o.metadata.namespace, o.spec.source.persistentVolumeClaimName) }, { t: "Snapshot class", v: (o) => R.link("VolumeSnapshotClass", null, o.spec.volumeSnapshotClassName) }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [["Status", R.status(o.status.readyToUse ? "Ready" : "Pending")], ["Size", o.status.restoreSize], ["Source", R.link("PersistentVolumeClaim", o.metadata.namespace, o.spec.source.persistentVolumeClaimName)], ["VolumeSnapshotClass", R.link("VolumeSnapshotClass", null, o.spec.volumeSnapshotClassName), "volumesnapshotclass"], ["VolumeSnapshotContent", esc(o.status.boundVolumeSnapshotContentName)]] }),
    actions: std([["Restore as new PVC", (o) => "dataSource: { kind: VolumeSnapshot, name: " + o.metadata.name + " }", "volumesnapshot"]])
  });
  def("VolumeSnapshotClass", { plural: "volumesnapshotclasses", abbr: "VSC", cls: "rb-sto", ns: false, api: "snapshot.storage.k8s.io/v1", help: "volumesnapshotclass", label: "VolumeSnapshotClasses", cols: [{ t: "Driver", v: (o) => `<span class="mono">${esc(o.driver)}</span>` }, { t: "Deletion policy", v: (o) => o.deletionPolicy }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Driver", esc(o.driver)], ["Deletion policy", o.deletionPolicy]] }) });
  def("ObjectBucketClaim", { plural: "objectbucketclaims", abbr: "OBC", cls: "rb-sto", api: "objectbucket.io/v1alpha1", help: "obc", cols: [{ t: "Status", v: (o) => R.status(o.status.phase) }, { t: "StorageClass", v: (o) => R.link("StorageClass", null, o.spec.storageClassName) }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Status", R.status(o.status.phase)], ["Bucket name", esc(o.spec.bucketName)], ["StorageClass", R.link("StorageClass", null, o.spec.storageClassName)]] }) });

  /* ---- Builds ---- */
  def("BuildConfig", {
    plural: "buildconfigs", abbr: "BC", cls: "rb-bld", api: "build.openshift.io/v1", help: "buildconfig",
    cols: [C.labels, { t: "Last build", v: (o) => { const b = lastBuild(o); return b ? R.link("Build", b.metadata.namespace, b.metadata.name) + " " + R.status(b.status.phase) : "-"; } }, C.created],
    tabs: ["details", "yaml", "builds", "environment", "events"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Type", o.spec.strategy.type, "bc-strategy"], ["Git repository", `<span class="mono">${esc(o.spec.source.git.uri)}</span>`, "bc-source"], ["Git ref", o.spec.source.git.ref, "bc-source"], ["Context dir", o.spec.source.contextDir, "bc-source"], ["Source secret", R.link("Secret", o.metadata.namespace, o.spec.source.sourceSecret.name), "secret-type"], ["Builder image", R.link("ImageStream", "openshift", "nodejs") + ` <span class="mono sm">(${esc(o.spec.strategy.sourceStrategy.from.name)})</span>`, "s2i"], ["Output to", R.link("ImageStream", o.metadata.namespace, o.spec.output.to.name.split(":")[0]) + ` <span class="mono sm">${esc(o.spec.output.to.name)}</span>`, "bc-output"], ["Run policy", o.spec.runPolicy]] }),
    sections: (o) => R.section("Webhooks", R.table([["Type"], ["Webhook URL"], ["Secret"]], o.spec.triggers.filter((t) => t.generic || t.github).map((t) => [t.type, `<span class="mono sm">${esc(OC.cluster.api)}/apis/build.openshift.io/v1/namespaces/${o.metadata.namespace}/buildconfigs/${o.metadata.name}/webhooks/&lt;secret&gt;/${t.type.toLowerCase()}</span>`, R.link("Secret", o.metadata.namespace, "webhook-secret")])), "bc-triggers") + R.section("Triggers", R.table([["Type"]], o.spec.triggers.map((t) => [t.type])), "bc-triggers"),
    actions: std([["Start build", (o) => "oc start-build " + o.metadata.name + " --follow", "build", null, "startBuild"], ["Start last run", (o) => "oc start-build --from-build=" + o.metadata.name + "-" + o.status.lastVersion, "build"]])
  });
  function lastBuild(bc) { return (db.Build || []).filter((b) => b.metadata.namespace === bc.metadata.namespace && b.status.config.name === bc.metadata.name).sort((a, b) => Date.parse(b.metadata.creationTimestamp) - Date.parse(a.metadata.creationTimestamp))[0]; }
  OC.lastBuild = lastBuild;
  def("Build", {
    plural: "builds", abbr: "B", cls: "rb-bld", api: "build.openshift.io/v1", help: "build",
    cols: [{ t: "Status", v: (o) => R.status(o.status.phase), s: (o) => o.status.phase, h: "build-phase" }, C.created],
    filter: { title: "Status", fn: (o) => o.status.phase, opts: ["New", "Pending", "Running", "Complete", "Failed", "Error", "Cancelled"] },
    tabs: ["details", "yaml", "environment", "logs", "events"],
    details: (o) => ({ l: OC.metaRows(o, [["Triggered by", esc(o.spec.triggeredBy[0].message)]]), r: [["Status", R.status(o.status.phase), "build-phase"], ["Build number", o.metadata.annotations["openshift.io/build.number"]], ["Started", U.ts(o.status.startTimestamp)], ["Duration", o.status.duration ? Math.floor(o.status.duration / 60e9) + "m " + Math.round((o.status.duration / 1e9) % 60) + "s" : "Running…"], ["Type", o.spec.strategy.type, "bc-strategy"], ["Git commit", `<span class="mono">${esc(o.spec.revision.git.commit.slice(0, 7))}</span> ${esc(o.spec.revision.git.message)}<div class="muted sm">${esc(o.spec.revision.git.author.name)}</div>`, "bc-source"], ["Output to", `<span class="mono sm">${esc(o.status.outputDockerImageReference)}</span>`, "bc-output"]].concat(o.status.reason ? [["Reason", esc(o.status.reason + ": " + o.status.message)]] : []) }),
    sections: (o) => (o.status.logSnippet ? `<div class="alert alert-danger">${U.ico("err", 16)}<div><b>Build failed</b><pre class="code">${esc(o.status.logSnippet)}</pre></div></div>` : ""),
    actions: std([["Rebuild", (o) => "oc start-build --from-build=" + o.metadata.name, "build"], ["Cancel build", (o) => "oc cancel-build " + o.metadata.name, "build-phase"]])
  });
  def("ImageStream", {
    plural: "imagestreams", abbr: "IS", cls: "rb-bld", api: "image.openshift.io/v1", help: "imagestream",
    cols: [C.labels, { t: "Tags", v: (o) => o.status.tags.length, h: "is-tags" }, C.created],
    details: (o) => ({ l: OC.metaRows(o), r: [["Image repository", `<span class="mono sm">${esc(o.status.dockerImageRepository)}</span>`, "imagestream"], ["Public image repository", o.status.publicDockerImageRepository ? `<span class="mono sm">${esc(o.status.publicDockerImageRepository)}</span>` : "-"], ["Image count", o.status.tags.reduce((a, t) => a + t.items.length, 0)], ["Lookup policy local", String(o.spec.lookupPolicy.local), "lookup-policy"]] }),
    sections: (o) => R.section("Tags", R.table([["Name"], ["From"], ["Identifier"], ["Last updated"]], o.status.tags.map((t) => [esc(t.tag), "-", `<span class="mono sm">${esc(t.items[0].dockerImageReference.split("@")[1] || "").slice(0, 26)}…</span>`, U.ts(t.items[0].created)])), "is-tags")
  });

  /* ---- Pipelines ---- */
  const prStatus = (r) => r._st;
  def("Pipeline", {
    plural: "pipelines", abbr: "PL", cls: "rb-pl", api: "tekton.dev/v1", help: "pipeline",
    cols: [{ t: "Last run", v: (o) => { const r = lastRun(o); return r ? R.link("PipelineRun", r.metadata.namespace, r.metadata.name) : "-"; } }, { t: "Task status", v: (o) => { const r = lastRun(o); return r ? taskBar(r, o) : "-"; } }, { t: "Last run status", v: (o) => { const r = lastRun(o); return r ? R.status(prStatus(r)) : "-"; } }, { t: "Last run time", v: (o) => { const r = lastRun(o); return r ? U.ts(r.status.startTime) : "-"; } }],
    tabs: ["details", "yaml", "pipelineruns", "parameters"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Tasks", o.spec.tasks.length], ["Workspaces", o.spec.workspaces.map((w) => w.name).join(", ")]] }),
    sections: (o) => R.section("Pipeline graph", pipelineGraph(o, lastRun(o)), "pipeline"),
    actions: std([["Start", (o) => "tkn pipeline start " + o.metadata.name + " --use-param-defaults -w name=workspace,volumeClaimTemplateFile=pvc.yaml", "pipelinerun"], ["Start last run", (o) => "tkn pipeline start " + o.metadata.name + " --last", "pipelinerun"]])
  });
  function lastRun(p) { return (db.PipelineRun || []).filter((r) => r.spec.pipelineRef.name === p.metadata.name).sort((a, b) => Date.parse(b.status.startTime) - Date.parse(a.status.startTime))[0]; }
  function taskBar(r, p) { const n = (p || db.Pipeline.find((x) => x.metadata.name === r.spec.pipelineRef.name)).spec.tasks.length; const st = r._st; const ok = st === "Succeeded" ? n : st === "Failed" ? 2 : 2; return `<div class="taskbar" title="${ok}/${n}">${Array.from({ length: n }, (_, i) => `<span class="${i < ok ? (st === "Failed" && i === 1 ? "tb-f" : "tb-ok") : st === "Running" && i === ok ? "tb-run" : st === "Failed" ? "tb-skip" : "tb-pend"}"></span>`).join("")}</div>`; }
  function pipelineGraph(p, run) {
    const st = run ? run._st : null;
    return `<div class="pgraph">${p.spec.tasks.map((t, i) => { const cls = !st ? "" : st === "Succeeded" ? "ok" : st === "Failed" ? (i < 1 ? "ok" : i === 1 ? "fail" : "skip") : i < 2 ? "ok" : i === 2 ? "run" : "pend"; return (i ? '<span class="pg-line"></span>' : "") + `<span class="pg-node ${cls}">${cls === "ok" ? U.ico("check", 12) : cls === "fail" ? U.ico("err", 12) : cls === "run" ? U.ico("sync", 12, "spin") : U.ico("pend", 12)} ${esc(t.name)}</span>`; }).join("")}</div>`;
  }
  OC.taskBar = taskBar; OC.pipelineGraph = pipelineGraph;
  def("PipelineRun", {
    plural: "pipelineruns", abbr: "PLR", cls: "rb-pl", api: "tekton.dev/v1", help: "pipelinerun",
    cols: [{ t: "Status", v: (o) => R.status(prStatus(o)), s: prStatus }, { t: "Task status", v: (o) => taskBar(o) }, { t: "Started", v: (o) => U.ts(o.status.startTime), s: (o) => o.status.startTime }, { t: "Duration", v: (o) => (o._dur ? Math.floor(o._dur) + "m " + Math.round((o._dur % 1) * 60) + "s" : "-") }],
    tabs: ["details", "yaml", "logs", "events"],
    details: (o) => ({ l: OC.metaRows(o), r: [["Status", R.status(prStatus(o))], ["Pipeline", R.link("Pipeline", o.metadata.namespace, o.spec.pipelineRef.name)], ["Message", esc(o.status.conditions[0].message)], ["Service account", o.spec.taskRunTemplate.serviceAccountName], ["Workspace", "VolumeClaimTemplate (1Gi)", "workspace"]] }),
    sections: (o) => R.section("Pipeline Run graph", pipelineGraph(db.Pipeline.find((p) => p.metadata.name === o.spec.pipelineRef.name), o)),
    actions: std([["Rerun", (o) => "tkn pipeline start " + o.spec.pipelineRef.name + " --last", "pipelinerun"], ["Cancel", (o) => "tkn pipelinerun cancel " + o.metadata.name, "pipelinerun"]])
  });
  def("Task", { plural: "tasks", abbr: "T", cls: "rb-pl", api: "tekton.dev/v1", help: "task", cols: [{ t: "Description", v: (o) => esc(o.spec.description || "-") }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Steps", o.spec.steps.length]] }), sections: (o) => R.section("Steps", R.table([["Name"], ["Image"]], o.spec.steps.map((s) => [esc(s.name), `<span class="mono sm">${esc(s.image)}</span>`]))) });

  /* ---- Compute ---- */
  const nodeStatus = (n) => (n.spec.unschedulable ? "Ready, SchedulingDisabled" : "Ready");
  const nodeRoles = (n) => Object.keys(n.metadata.labels).filter((k) => k.indexOf("node-role.kubernetes.io/") === 0).map((k) => k.split("/")[1]).join(", ");
  def("Node", {
    plural: "nodes", abbr: "N", cls: "rb-node", ns: false, help: "node",
    cols: [{ t: "Status", v: (n) => R.status(nodeStatus(n)), s: nodeStatus, h: "node-status" }, { t: "Roles", v: nodeRoles, s: nodeRoles, h: "node-roles" }, { t: "Pods", v: (n) => OC.podsOf(n).length, s: (n) => OC.podsOf(n).length }, { t: "Memory", v: (n) => U.mib(n._m.mem) + " / " + n._mem + " GiB", s: (n) => n._m.mem, h: "pod-memory" }, { t: "CPU", v: (n) => U.num(n._m.cpu, 2) + " / " + n._cpu + " cores", s: (n) => n._m.cpu, h: "pod-cpu" }, { t: "Filesystem", v: (n) => U.num(n._m.fs, 1) + " GiB / 119,5 GiB" }, C.created],
    filter: { title: "Roles", fn: (n) => (n._role === "master" ? "control-plane" : n._role), opts: ["control-plane", "worker", "infra"] },
    tabs: ["details", "metrics", "yaml", "pods", "events"],
    details: (n) => ({ l: OC.metaRows(n, [["Taints", (n.spec.taints || []).length ? (n.spec.taints || []).map((t) => `<div class="mono sm">${esc(t.key)}${t.value ? "=" + esc(t.value) : ""}:${t.effect}</div>`).join("") : "No taints", "taints"], ["Node addresses", n.status.addresses.map((a) => `<div>${a.type}: <span class="mono">${esc(a.address)}</span></div>`).join("")]]).filter((r) => r && r[0] !== "Owner"), r: [["Status", R.status(nodeStatus(n)), "node-status"], ["Roles", nodeRoles(n), "node-roles"], ["Operating system", "Linux"], ["OS image", esc(n.status.nodeInfo.osImage), "kubelet-version"], ["Architecture", n.status.nodeInfo.architecture], ["Kernel version", esc(n.status.nodeInfo.kernelVersion)], ["Container runtime", esc(n.status.nodeInfo.containerRuntimeVersion), "kubelet-version"], ["Kubelet version", n.status.nodeInfo.kubeletVersion, "kubelet-version"], ["Capacity", `CPU: ${n.status.capacity.cpu} · Memory: ${U.mib(mem(n.status.capacity.memory))} · Pods: ${n.status.capacity.pods}`, "node-capacity"], ["Allocatable", `CPU: ${n.status.allocatable.cpu} · Memory: ${U.mib(mem(n.status.allocatable.memory))}`, "node-capacity"], ["Machine", R.link("Machine", "openshift-machine-api", n.metadata.annotations["machine.openshift.io/machine"].split("/")[1])]] }),
    sections: (n) => R.section("Conditions", condTable(n.status.conditions), "node-status"),
    actions: [["Mark as unschedulable", (n) => "oc adm cordon " + n.metadata.name, "node-drain", null, "cordon"], ["Drain node", (n) => "oc adm drain " + n.metadata.name + " --ignore-daemonsets --delete-emptydir-data", "node-drain"], A.labels, A.ann, ["Edit Node", (n) => "oc edit node " + n.metadata.name, "tab-yaml"], ["Delete Node", (n) => "oc delete node " + n.metadata.name, null, "danger"]]
  });
  def("Machine", { plural: "machines", abbr: "M", cls: "rb-node", api: "machine.openshift.io/v1beta1", help: "machine", cols: [{ t: "Phase", v: (o) => R.status(o.status.phase), h: "machine-phase" }, { t: "Provider state", v: (o) => o.status.providerStatus.instanceState }, { t: "Node", v: (o) => R.link("Node", null, o.status.nodeRef.name) }, { t: "Role", v: (o) => o.metadata.labels["machine.openshift.io/cluster-api-machine-role"] }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Phase", R.status(o.status.phase), "machine-phase"], ["Provider state", o.status.providerStatus.instanceState], ["Node", R.link("Node", null, o.status.nodeRef.name)], ["Provider ID", `<span class="mono sm">${esc(o.spec.providerID)}</span>`], ["Machine addresses", o.status.addresses.map((a) => `<div>${a.type}: ${esc(a.address)}</div>`).join("")]] }) });
  def("MachineSet", { plural: "machinesets", abbr: "MS", cls: "rb-node", api: "machine.openshift.io/v1beta1", help: "machineset", cols: [{ t: "Machines", v: (o) => o.status.readyReplicas + " of " + o.spec.replicas + " machines", h: "replicas" }, { t: "Instance", v: (o) => o.metadata.annotations["machine.openshift.io/vCPU"] + " vCPU / " + o.metadata.annotations["machine.openshift.io/memoryMb"] / 1024 + " GiB" }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Desired count", o.spec.replicas, "replicas"], ["Current count", o.status.availableReplicas], ["CPU", o.spec.template.spec.providerSpec.value.numCPUs], ["Memory", o.spec.template.spec.providerSpec.value.memoryMiB + " MiB"], ["Disk", o.spec.template.spec.providerSpec.value.diskGiB + " GiB"], ["vCenter", esc(o.spec.template.spec.providerSpec.value.workspace.server)], ["Datastore", esc(o.spec.template.spec.providerSpec.value.workspace.datastore)]] }), actions: std([["Edit Machine count", (o) => "oc scale machineset " + o.metadata.name + " --replicas=<sayi> -n openshift-machine-api", "machineset"]]) });
  def("MachineAutoscaler", { plural: "machineautoscalers", abbr: "MA", cls: "rb-node", api: "autoscaling.openshift.io/v1beta1", help: "machineautoscaler", cols: [{ t: "Scale target", v: (o) => R.link("MachineSet", o.metadata.namespace, o.spec.scaleTargetRef.name) }, { t: "Min", v: (o) => o.spec.minReplicas }, { t: "Max", v: (o) => o.spec.maxReplicas }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Scale target", R.link("MachineSet", o.metadata.namespace, o.spec.scaleTargetRef.name)], ["Min replicas", o.spec.minReplicas], ["Max replicas", o.spec.maxReplicas]] }) });
  def("MachineHealthCheck", { plural: "machinehealthchecks", abbr: "MHC", cls: "rb-node", api: "machine.openshift.io/v1beta1", help: "mhc", cols: [{ t: "Max unhealthy", v: (o) => o.spec.maxUnhealthy }, { t: "Healthy", v: (o) => o.status.currentHealthy + " / " + o.status.expectedMachines }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Max unhealthy", o.spec.maxUnhealthy], ["Node startup timeout", o.spec.nodeStartupTimeout], ["Expected machines", o.status.expectedMachines], ["Current healthy", o.status.currentHealthy]] }), sections: (o) => R.section("Unhealthy conditions", R.table([["Type"], ["Status"], ["Timeout"]], o.spec.unhealthyConditions.map((c) => [c.type, c.status, c.timeout]))) });
  def("MachineConfig", { plural: "machineconfigs", abbr: "MC", cls: "rb-node", ns: false, api: "machineconfiguration.openshift.io/v1", help: "machineconfig", cols: [{ t: "Generated by controller", v: (o) => (o.metadata.annotations && o.metadata.annotations["machineconfiguration.openshift.io/generated-by-controller-version"] ? `<span class="mono sm">${o.metadata.annotations["machineconfiguration.openshift.io/generated-by-controller-version"].slice(0, 12)}</span>` : "-") }, { t: "Ignition version", v: (o) => o.spec.config.ignition.version }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Role", o.metadata.labels["machineconfiguration.openshift.io/role"], "mcp"], ["Ignition version", o.spec.config.ignition.version]] }) });
  def("MachineConfigPool", { plural: "machineconfigpools", abbr: "MCP", cls: "rb-node", ns: false, api: "machineconfiguration.openshift.io/v1", help: "mcp", cols: [{ t: "Configuration", v: (o) => `<span class="mono sm">${esc(o.status.configuration.name.slice(0, 30))}…</span>` }, { t: "Degraded", v: () => "False" }, { t: "Update status", v: () => R.status("Up to date") }, { t: "Machines", v: (o) => o.status.updatedMachineCount + " / " + o.status.machineCount }, { t: "Paused", v: (o) => String(o.spec.paused) }], details: (o) => ({ l: OC.metaRows(o), r: [["Max unavailable machines", o.spec.maxUnavailable], ["Machine count", o.status.machineCount], ["Ready", o.status.readyMachineCount], ["Updated", o.status.updatedMachineCount], ["Degraded", o.status.degradedMachineCount], ["Paused", String(o.spec.paused)], ["Current configuration", `<span class="mono sm">${esc(o.status.configuration.name)}</span>`]] }), sections: (o) => R.section("Conditions", condTable(o.status.conditions)), actions: std([["Pause updates", (o) => `oc patch mcp/${o.metadata.name} --type merge -p '{"spec":{"paused":true}}'`, "mcp"]]) });

  /* ---- User management ---- */
  def("User", { plural: "users", abbr: "U", cls: "rb-user", ns: false, api: "user.openshift.io/v1", help: "user", cols: [{ t: "Full name", v: (o) => esc(o.fullName) }, { t: "Identities", v: (o) => `<span class="mono sm">${esc(o.identities.join(", "))}</span>` }, C.created], tabs: ["details", "yaml", "rolebindings"], details: (o) => ({ l: OC.metaRows(o), r: [["Full name", esc(o.fullName)], ["Identities", esc(o.identities.join(", ")), "oauth"], ["Groups", db.Group.filter((g) => g.users.indexOf(o.metadata.name) >= 0).map((g) => R.link("Group", null, g.metadata.name)).join(", ") || "-", "group"]] }), actions: std([["Impersonate User", (o) => "oc get pods --as=" + o.metadata.name, "user"]]) });
  def("Group", { plural: "groups", abbr: "G", cls: "rb-user", ns: false, api: "user.openshift.io/v1", help: "group", cols: [{ t: "Users", v: (o) => o.users.length }, C.created], tabs: ["details", "yaml", "rolebindings"], details: (o) => ({ l: OC.metaRows(o), r: [["LDAP sync", o.metadata.annotations ? U.ts(o.metadata.annotations["openshift.io/ldap.sync-time"]) : "-"]] }), sections: (o) => R.section("Users", R.table([["Name"]], o.users.map((u) => [R.link("User", null, u)])), "user"), actions: std([["Add Users", (o) => "oc adm groups add-users " + o.metadata.name + " <kullanici>", "group"]]) });
  def("ServiceAccount", { plural: "serviceaccounts", abbr: "SA", cls: "rb-user", help: "serviceaccount", cols: [{ t: "Secrets", v: (o) => (o.imagePullSecrets || []).length }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [["Image pull secrets", (o.imagePullSecrets || []).map((s) => R.link("Secret", o.metadata.namespace, s.name)).join("<br>"), "secret-type"]] }) });
  const rulesSec = (o) => R.section("Rules", R.table([["Actions", "rbac-verbs"], ["API groups"], ["Resources"]], (o.rules || []).map((r) => [(r.verbs || []).map((v) => `<span class="pill">${esc(v)}</span>`).join(" "), (r.apiGroups || ["(non-resource)"]).map((g) => esc(g || "core")).join(", "), esc((r.resources || r.nonResourceURLs || []).join(", "))])), "rbac-verbs");
  def("Role", { plural: "roles", abbr: "R", cls: "rb-user", api: "rbac.authorization.k8s.io/v1", help: "role", cols: [C.created], tabs: ["details", "yaml", "rolebindings"], details: (o) => ({ l: OC.metaRows(o), r: [] }), sections: rulesSec });
  def("ClusterRole", { plural: "clusterroles", abbr: "CR", cls: "rb-user", ns: false, api: "rbac.authorization.k8s.io/v1", help: "role", cols: [C.created], tabs: ["details", "yaml", "rolebindings"], details: (o) => ({ l: OC.metaRows(o), r: [] }), sections: rulesSec });
  const rbCols = [{ t: "Role ref", v: (o) => R.link(o.roleRef.kind, o.metadata.namespace, o.roleRef.name), h: "role-ref" }, { t: "Subject kind", v: (o) => o.subjects.map((s) => s.kind).join("<br>") }, { t: "Subject name", v: (o) => o.subjects.map((s) => (s.kind === "User" || s.kind === "Group" ? R.link(s.kind, null, s.name, true) : esc(s.name))).join("<br>") }];
  const rbDet = (o) => ({ l: OC.metaRows(o), r: [["Role ref", R.link(o.roleRef.kind, o.metadata.namespace, o.roleRef.name), "role-ref"]] });
  const rbSec = (o) => R.section("Subjects", R.table([["Kind"], ["Name"], ["Namespace"]], o.subjects.map((s) => [s.kind, esc(s.name), s.namespace || "-"])), "role-ref");
  def("RoleBinding", { plural: "rolebindings", abbr: "RB", cls: "rb-user", api: "rbac.authorization.k8s.io/v1", help: "rolebinding", cols: rbCols, details: rbDet, sections: rbSec, actions: std([["Duplicate RoleBinding", (o) => "oc adm policy add-role-to-user " + o.roleRef.name + " <kullanici> -n " + o.metadata.namespace, "rolebinding"]]), tpl: { apiVersion: "rbac.authorization.k8s.io/v1", kind: "RoleBinding", metadata: { name: "ornek-edit" }, roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "edit" }, subjects: [{ apiGroup: "rbac.authorization.k8s.io", kind: "User", name: "ali.vural" }] }, form: [["name", "RoleBinding name", "text", "ornek-edit", "name"], ["role", "Role name", "select", ["admin", "edit", "view", "basic-user"], "role"], ["kind", "Subject", "select", ["User", "Group", "ServiceAccount"], "role-ref"], ["subject", "Subject name", "text", "ali.vural", "role-ref"]] });
  def("ClusterRoleBinding", { plural: "clusterrolebindings", abbr: "CRB", cls: "rb-user", ns: false, api: "rbac.authorization.k8s.io/v1", help: "rolebinding", cols: rbCols, details: rbDet, sections: rbSec });

  /* ---- Administration ---- */
  const projCols = [{ t: "Display name", v: (o) => esc((o.metadata.annotations || {})["openshift.io/display-name"] || "-") }, { t: "Status", v: (o) => R.status(o.status.phase) }, { t: "Requester", v: (o) => ((o.metadata.annotations || {})["openshift.io/requester"] ? R.link("User", null, o.metadata.annotations["openshift.io/requester"], true) : "No requester") }, C.created];
  const projDet = (o) => ({ l: OC.metaRows(o).filter((r) => r && r[0] !== "Owner").concat([["Display name", esc((o.metadata.annotations || {})["openshift.io/display-name"] || "No display name")], ["Description", esc((o.metadata.annotations || {})["openshift.io/description"] || "No description")], ["Requester", esc((o.metadata.annotations || {})["openshift.io/requester"] || "No requester")]]), r: [["Status", R.status(o.status.phase)], ["Default pull secret", "Not configured"], ["Network policy", (db.NetworkPolicy || []).filter((n) => n.metadata.namespace === o.metadata.name).length + " policies", "networkpolicy"], ["Resource quotas", (db.ResourceQuota || []).filter((n) => n.metadata.namespace === o.metadata.name).length || "No ResourceQuotas", "resourcequota"]] });
  def("Namespace", { plural: "namespaces", abbr: "NS", cls: "rb-ns", ns: false, help: "namespace", cols: projCols, tabs: ["details", "yaml", "rolebindings"], details: projDet, actions: std([["Edit default network policy"]]).filter((a) => a[1]), tpl: { apiVersion: "v1", kind: "Namespace", metadata: { name: "yeni-namespace" } } });
  def("Project", { plural: "projects", abbr: "PR", cls: "rb-ns", ns: false, api: "project.openshift.io/v1", help: "project", cols: projCols, tabs: ["overview", "details", "yaml", "workloads", "rolebindings"], details: projDet, tpl: { apiVersion: "project.openshift.io/v1", kind: "Project", metadata: { name: "yeni-proje" } }, form: [["name", "Name", "text", "yeni-proje", "name"], ["display", "Display name", "text", "Yeni Proje", "project"], ["desc", "Description", "textarea", "Proje açıklaması", "project"]] });
  def("ResourceQuota", { plural: "resourcequotas", abbr: "RQ", cls: "rb-adm", help: "resourcequota", cols: [{ t: "Label selector", v: () => '<span class="muted">-</span>' }, C.created], details: (o) => ({ l: OC.metaRows(o), r: [] }), sections: (o) => R.section("Resource quota details", R.table([["Resource type"], ["Capacity", "quota-usage"], ["Used", "quota-usage"], ["Max", "quota-usage"]], Object.keys(o.spec.hard).map((k) => { const u = o.status.used[k] || "0", hv = o.spec.hard[k]; const pct = Math.min(100, (parseQ(u) / parseQ(hv)) * 100); return [`<span class="mono">${esc(k)}</span>`, `<div class="util-bar sm"><span class="${pct > 85 ? "hi" : ""}" style="width:${pct.toFixed(0)}%"></span></div> ${pct.toFixed(0)}%`, esc(u), esc(hv)]; })), "quota-usage"), tpl: { apiVersion: "v1", kind: "ResourceQuota", metadata: { name: "compute-quota" }, spec: { hard: { "requests.cpu": "4", "requests.memory": "8Gi", "limits.cpu": "8", "limits.memory": "16Gi", pods: "20" } } } });
  function parseQ(v) { v = String(v); if (/m$/.test(v)) return parseFloat(v) / 1000; if (/[KMGT]i$/.test(v)) return mem(v); return parseFloat(v); }
  def("LimitRange", { plural: "limitranges", abbr: "LR", cls: "rb-adm", help: "limitrange", cols: [C.created], details: (o) => ({ l: OC.metaRows(o), r: [] }), sections: (o) => R.section("Limits", R.table([["Type"], ["Resource"], ["Min"], ["Max"], ["Default request"], ["Default limit"]], [].concat.apply([], o.spec.limits.map((l) => ["cpu", "memory"].map((r) => [l.type, r, (l.min || {})[r] || "-", (l.max || {})[r] || "-", (l.defaultRequest || {})[r] || "-", (l.default || {})[r] || "-"])))), "limitrange"), tpl: { apiVersion: "v1", kind: "LimitRange", metadata: { name: "varsayilan-limitler" }, spec: { limits: [{ type: "Container", default: { cpu: "500m", memory: "512Mi" }, defaultRequest: { cpu: "100m", memory: "256Mi" } }] } } });
  def("CustomResourceDefinition", { plural: "customresourcedefinitions", abbr: "CRD", cls: "rb-adm", ns: false, api: "apiextensions.k8s.io/v1", help: "crd", label: "CustomResourceDefinitions", cols: [{ t: "Group", v: (o) => esc(o.spec.group), h: "crd-scope" }, { t: "Latest version", v: (o) => o.spec.versions[0].name, h: "crd-scope" }, { t: "Namespaced", v: (o) => String(o.spec.scope === "Namespaced"), h: "crd-scope" }, { t: "Established", v: () => R.status("True") }], tabs: ["details", "yaml", "instances"], details: (o) => ({ l: OC.metaRows(o), r: [["Group", esc(o.spec.group), "crd-scope"], ["Kind", o.spec.names.kind], ["Scope", o.spec.scope, "crd-scope"], ["Versions", o.spec.versions.map((v) => v.name).join(", "), "crd-scope"], ["Plural", o.spec.names.plural]] }), sections: (o) => R.section("Conditions", condTable(o.status.conditions)) });
  def("ClusterServiceVersion", { plural: "clusterserviceversions", abbr: "CSV", cls: "rb-op", api: "operators.coreos.com/v1alpha1", help: "operator", label: "Installed Operators", cols: [], details: (o) => ({ l: OC.metaRows(o), r: [["Provider", esc(o.spec.provider.name)], ["Version", o.spec.version], ["Status", R.status(o.status.phase), "csv-status"], ["Install mode", o._all ? "All namespaces" : "Single namespace", "install-mode"], ["Managed namespaces", o._all ? "All Namespaces" : o.metadata.namespace, "install-mode"]] }), sections: (o) => `<p class="desc">${esc(o.spec.description)}</p>` + R.section("Provided APIs", `<div class="cards api-cards">${o.spec.customresourcedefinitions.owned.map((c) => `<div class="card api-card"><div class="api-card-t">${R.badge("CustomResourceDefinition")} ${esc(c.displayName)}</div><div class="muted sm mono">${esc(c.name)}</div><button class="btn btn-link btn-sm sim-act" data-cmd="oc create -f ${esc(c.kind.toLowerCase())}.yaml" data-title="Create instance">${U.ico("plus", 11)} Create instance</button></div>`).join("")}</div>`, "crd"), tabs: ["details", "yaml", "events"], actions: [["Edit Subscription", (o) => "oc edit subscription -n " + o.metadata.namespace, "subscription"], ["Uninstall Operator", (o) => "oc delete subscription <ad> -n " + o.metadata.namespace + " && oc delete csv " + o.metadata.name + " -n " + o.metadata.namespace, "operator", "danger"]] });
  def("Subscription", { plural: "subscriptions", abbr: "SUB", cls: "rb-op", api: "operators.coreos.com/v1alpha1", help: "subscription", cols: [{ t: "Channel", v: (o) => o.spec.channel }, { t: "Approval", v: (o) => o.spec.installPlanApproval }] });
  def("Event", { plural: "events", abbr: "E", cls: "rb-def", help: "event", cols: [] });
  def("Container", { plural: "containers", abbr: "C", cls: "rb-cont", help: "container", cols: [] });
  def("HelmChartRepository", { plural: "helmchartrepositories", abbr: "HCR", cls: "rb-helm", ns: false, api: "helm.openshift.io/v1beta1", help: "helm-repo", cols: [{ t: "Display name", v: (o) => esc(o.spec.name) }, { t: "URL", v: (o) => `<span class="mono sm">${esc(o.spec.connectionConfig.url)}</span>` }], details: (o) => ({ l: OC.metaRows(o), r: [["URL", esc(o.spec.connectionConfig.url)], ["Disabled", "false"]] }) });
  def("ProjectHelmChartRepository", { plural: "projecthelmchartrepositories", abbr: "PHCR", cls: "rb-helm", api: "helm.openshift.io/v1beta1", help: "helm-repo", cols: [{ t: "Display name", v: (o) => esc(o.spec.name) }, { t: "URL", v: (o) => `<span class="mono sm">${esc(o.spec.connectionConfig.url)}</span>` }], details: (o) => ({ l: OC.metaRows(o), r: [["URL", esc(o.spec.connectionConfig.url)]] }) });

  /* listeler için */
  OC.byPlural = {};
  Object.keys(K).forEach((k) => (OC.byPlural[K[k].plural] = k));
  OC.items = (kind) => db[kind] || [];
  OC.find = (kind, ns, name) => (db[kind] || []).find((o) => o.metadata.name === name && (!K[kind].ns || o.metadata.namespace === ns));
})();
