/* Monitoring (eğitim sekmesi) */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};
  var NODE_COL = ['#edc240', '#afd8f8', '#cb4b4b'];

  function countBy(list, fn) {
    var m = {};
    list.forEach(function (x) { var k = fn(x); m[k] = (m[k] || 0) + 1; });
    return Object.keys(m).map(function (k) { return { label: esc(k), value: m[k] }; }).sort(function (a, b) { return b.value - a.value; });
  }
  function nodeChart(id, title, help, key, unit, fmt) {
    return UI.chart({
      id: id, title: title, help: help, unit: unit, legendCols: 3,
      get: function (range) {
        return { times: SIM.slice(SIM.hist.t, range), series: SIM.S.nodes.map(function (n, i) {
          var a = SIM.hist.n[n.name][key];
          return { key: n.name, label: esc(n.name.replace('rabbit@', '')), color: NODE_COL[i % 3], data: SIM.slice(a, range), value: fmt(a[a.length - 1]) };
        }) };
      }
    });
  }

  P.monitoring = function () {
    var h = ['<h1>Monitoring <span class="sub">(eğitim sekmesi)</span> ' + UI.help('tab-monitoring') + '</h1>'];
    h.push('<div class="edu-note"><b>Bu sekme gerçek Management UI\'da yoktur.</b> RabbitMQ\'da izlenmesi gereken temel metrikleri tek ekranda toplamak için eklenmiştir. Üretim ortamında bu metrikler <b>Prometheus</b> (port 15692) ile toplanıp <b>Grafana</b> dashboard\'larında izlenir ' + UI.help('prometheus') + '</div>');

    h.push(UI.section('Message Rates', UI.block(function () {
      var t = SIM.totals(App.vhost || null), S = SIM.S, vf = SIM.vhostOk;
      var msgs = S.queues.filter(vf).reduce(function (a, q) { return a + q.ready + q.unacked; }, 0);
      function card(k, v, help, sub) { return '<div class="card"><div class="k">' + k + ' ' + UI.help(help) + '</div><div class="v">' + v + (sub ? ' <small>' + sub + '</small>' : '') + '</div></div>'; }
      return '<div class="grid-cards">' +
        card('Publish Rate', U.fmtRate(t.publish), 'rate-publish') +
        card('Deliver Rate', U.fmtRate(t.deliver_manual + t.deliver_auto + t.get_auto + t.get_manual), 'mon-deliver-rate') +
        card('Acknowledge Rate', U.fmtRate(t.ack), 'mon-ack-rate') +
        card('Redeliver Rate', U.fmtRate(t.redeliver), 'mon-redeliver-rate', (t.deliver_manual ? (t.redeliver / t.deliver_manual * 100).toFixed(2) + '% of deliver' : '')) +
        card('Messages (ready + unacked)', U.fmtNum(msgs), 'queued-messages') +
        card('Unroutable (drop)', U.fmtRate(t.drop), 'rate-unroutable-drop') +
        '</div>';
    }) + UI.chart({
      id: 'mon-rates', title: 'Publish / Deliver / Ack / Redeliver', help: 'message-rates', unit: 'rate', legendCols: 2,
      get: function (range) {
        var st = App.vhost ? (SIM.hist.ovv[App.vhost] || SIM.hist.ov) : SIM.hist.ov;
        var del = (st.deliver_manual || []).map(function (v, i) { return v + ((st.deliver_auto || [])[i] || 0); });
        function s(key, label, color, arr, help) { arr = arr || [0]; return { key: key, label: label, color: color, data: SIM.slice(arr, range), value: U.fmtRate(arr[arr.length - 1]), help: help }; }
        return { times: SIM.slice(SIM.hist.t, range), series: [
          s('publish', 'Publish', '#edc240', st.publish, 'rate-publish'), s('deliver', 'Deliver', '#cb4b4b', del, 'mon-deliver-rate'),
          s('ack', 'Acknowledge', '#9440ed', st.ack, 'mon-ack-rate'), s('redeliver', 'Redeliver', '#888', st.redeliver, 'mon-redeliver-rate')
        ] };
      }
    }), { id: 'mon-rates-sec', help: 'message-rates' }));

    h.push(UI.section('Connection Statistics', UI.block(function () {
      var cs = SIM.S.connections.filter(SIM.vhostOk);
      return '<div class="facts-cols">' +
        '<div><h3>Protokole göre ' + UI.help('protocol') + '</h3>' + Charts.hbars(countBy(cs, function (c) { return c.protocol; })) + '</div>' +
        '<div><h3>Node\'a göre ' + UI.help('conn-node') + '</h3>' + Charts.hbars(countBy(cs, function (c) { return c.node; }), {}) + '</div>' +
        '<div><h3>Duruma göre ' + UI.help('conn-state') + '</h3>' + Charts.hbars(countBy(cs, function (c) { return c.l_state || c.state; }).map(function (x) { x.color = x.label === 'running' ? 'var(--green)' : 'var(--warn)'; return x; })) + '</div>' +
        '<div><h3>Kullanıcıya göre</h3>' + Charts.hbars(countBy(cs, function (c) { return c.user; })) + '</div>' +
        '<div><h3>TLS</h3>' + Charts.hbars(countBy(cs, function (c) { return c.ssl ? 'TLS (' + c.ssl_protocol + ')' : (c.protocol.indexOf('Direct') === 0 ? 'direct (yerel)' : 'plain TCP'); })) + '</div>' +
        '</div>';
    }), { id: 'mon-conn', help: 'mon-conn-stats' }));

    h.push(UI.section('Channel Statistics', UI.block(function () {
      var ch = SIM.S.channels.filter(SIM.vhostOk), conns = SIM.S.connections.filter(SIM.vhostOk).length || 1;
      var unacked = ch.reduce(function (a, c) { return a + (c.l_unacked || 0); }, 0);
      var noPrefetch = ch.filter(function (c) { return !c.prefetch && SIM.consumersOnChannel(c.name).length; });
      return UI.facts([
        ['Toplam kanal', ch.length, 'channel'],
        ['Bağlantı başına ortalama', (ch.length / conns).toFixed(2), 'mon-ch-stats'],
        ['Confirm modunda', ch.filter(function (c) { return c.confirm; }).length, 'confirm-mode'],
        ['Transaction modunda', ch.filter(function (c) { return c.transactional; }).length, 'transactional'],
        ['Toplam unacked', U.fmtNum(unacked), 'ch-unacked'],
        ['Prefetch ayarlanmamış consumer kanalları', noPrefetch.length ? '<span class="warn-text">' + noPrefetch.length + '</span> – ' + noPrefetch.map(function (c) { return UI.chLink(c.name); }).join(', ') : '0', 'prefetch']
      ]);
    }), { id: 'mon-ch', help: 'mon-ch-stats' }));

    h.push(UI.section('Queue Statistics', UI.block(function () {
      var qs = SIM.S.queues.filter(SIM.vhostOk);
      var top = qs.slice().sort(function (a, b) { return (b.ready + b.unacked) - (a.ready + a.unacked); }).slice(0, 8);
      var orphan = qs.filter(function (q) { return q.ready > 0 && !SIM.consumersOf(q.vhost, q.name).length && q.type !== 'stream'; });
      return '<div class="facts-cols"><div><h3>Tipe göre ' + UI.help('q-type') + '</h3>' + Charts.hbars(countBy(qs, function (q) { return q.type; }).map(function (x) { x.color = x.label === 'quorum' ? '#2f6d8c' : x.label === 'stream' ? '#8b7a3f' : 'var(--green)'; return x; })) + '</div>' +
        '<div><h3>En çok mesaj biriken kuyruklar ' + UI.help('ready') + '</h3>' + Charts.hbars(top.map(function (q) { return { label: UI.qLink(q.vhost, q.name) + ' <span class="muted small">' + q.type + '</span>', value: q.ready + q.unacked, color: q.type === 'stream' ? '#8b7a3f' : 'var(--green)' }; })) + '</div></div>' +
        '<h3>Consumer\'ı olmayan ve mesaj biriken kuyruklar ' + UI.help('q-consumers') + '</h3>' +
        (orphan.length ? '<table class="list"><thead><tr><th>Queue</th><th>Type</th><th class="r">Ready</th><th>Olası neden</th></tr></thead><tbody>' + orphan.map(function (q) {
          var why = /dlq$/.test(q.name) ? 'DLQ – manuel inceleme bekliyor (beklenen durum)' : q.name === 'orders.retry' ? 'TTL ile gecikmeli retry kuyruğu (beklenen durum)' : q.name === 'orders.unrouted' ? 'Alternate exchange\'e düşen yönlendirilemeyen mesajlar – binding/routing key hatalarını inceleyin' : 'Tüketici servis çalışmıyor olabilir!';
          return '<tr><td>' + UI.qLink(q.vhost, q.name) + '</td><td>' + q.type + '</td><td class="r">' + U.fmtNum(q.ready) + '</td><td>' + why + '</td></tr>';
        }).join('') + '</tbody></table>' : '<p class="muted">Yok.</p>');
    }), { id: 'mon-q', help: 'mon-queue-stats' }));

    if (!App.vhost) {
      h.push(UI.section('Memory Usage', nodeChart('mon-mem', 'Node memory', 'memory', 'mem', 'bytes', U.fmtBytes) + '<p class="muted small">High watermark: ' + U.fmtBytes(SIM.S.nodes[0].mem_limit) + ' (her node için). Ayrıntılı dağılım için node adına tıklayın ' + UI.help('node-memory-breakdown') + '</p>', { id: 'mon-mem-sec', help: 'memory' }));
      h.push(UI.section('Disk Usage', nodeChart('mon-disk', 'Free disk space', 'disk', 'disk', 'bytes', U.fmtBytes) + '<p class="muted small">Disk free limit (low watermark): ' + U.fmtBytes(SIM.S.nodes[0].disk_free_limit) + '</p>', { id: 'mon-disk-sec', help: 'disk' }));
      h.push(UI.section('CPU ve sistem kaynakları', nodeChart('mon-cpu', 'Scheduler utilisation (%)', 'mon-cpu', 'cpu', 'count', function (v) { return v.toFixed(1) + '%'; }) + UI.block(function () {
        return '<table class="list"><thead><tr><th>Node</th><th class="r">Cores</th><th class="r">Run queue ' + UI.help('mon-cpu') + '</th><th class="r">GC / s</th><th class="r">Disk write (ops/s)</th><th class="r">File descriptors</th><th class="r">Erlang processes</th></tr></thead><tbody>' + SIM.S.nodes.map(function (n) {
          return '<tr><td>' + UI.nodeLink(n.name) + '</td><td class="r">' + n.cores + '</td><td class="r">' + n.l_runq + '</td><td class="r">' + U.fmtNum(n.l_gc) + '</td><td class="r">' + n.l_iow.toFixed(1) + '</td><td class="r">' + n.l_fd + ' / ' + n.fd_total + '</td><td class="r">' + U.fmtNum(n.l_proc) + '</td></tr>';
        }).join('') + '</tbody></table>';
      }), { id: 'mon-cpu-sec', help: 'mon-cpu' }));
    }

    h.push(UI.section('Prometheus örnek çıktısı', '<pre class="msg-box" style="white-space:pre;overflow:auto">' + esc(UI.promSample()) + '</pre>', { id: 'mon-prom', closed: true, help: 'prometheus' }));
    return h.join('');
  };

  UI.promSample = function () {
    var t = SIM.totals(null), S = SIM.S;
    return [
      '# HELP rabbitmq_global_messages_received_total Total number of messages received from publishers',
      '# TYPE rabbitmq_global_messages_received_total counter',
      'rabbitmq_global_messages_received_total{protocol="amqp091"} ' + Math.round(t.publish * 86400 * 4.2),
      '# HELP rabbitmq_queue_messages_ready Messages ready to be delivered to consumers',
      '# TYPE rabbitmq_queue_messages_ready gauge',
      'rabbitmq_queue_messages_ready ' + S.queues.reduce(function (a, q) { return a + q.ready; }, 0),
      '# HELP rabbitmq_queue_messages_unacked Messages delivered to consumers but not yet acknowledged',
      'rabbitmq_queue_messages_unacked ' + S.queues.reduce(function (a, q) { return a + q.unacked; }, 0),
      '# HELP rabbitmq_connections Connections currently open',
      'rabbitmq_connections ' + S.connections.length,
      '# HELP rabbitmq_channels Channels currently open',
      'rabbitmq_channels ' + S.channels.length,
      '# HELP rabbitmq_process_resident_memory_bytes Memory used in bytes',
      'rabbitmq_process_resident_memory_bytes ' + Math.round(S.nodes[0].l_mem || S.nodes[0].mem_used),
      '# HELP rabbitmq_resident_memory_limit_bytes Memory high watermark in bytes',
      'rabbitmq_resident_memory_limit_bytes ' + Math.round(S.nodes[0].mem_limit),
      '# HELP rabbitmq_disk_space_available_bytes Disk space available in bytes',
      'rabbitmq_disk_space_available_bytes ' + Math.round(S.nodes[0].l_disk || S.nodes[0].disk_free),
      '# HELP rabbitmq_alarms_memory_used_watermark Is set to 1 when memory alarm is in effect',
      'rabbitmq_alarms_memory_used_watermark ' + (S.nodes[0].alarm_mem ? 1 : 0),
      '# HELP rabbitmq_raft_term_total Current Raft term number',
      'rabbitmq_raft_term_total 4'
    ].join('\n');
  };
})(window);
