/* Yardımcı fonksiyonlar */
(function (w) {
  'use strict';
  var U = {};

  U.esc = function (s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.$ = function (sel, root) { return (root || document).querySelector(sel); };
  U.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  /* Deterministik rastgele (mulberry32) */
  U.rng = function (seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  };
  U.rand = Math.random;
  U.jitter = function (v, pct) {
    if (!v) return 0;
    var r = v * (1 + (Math.random() * 2 - 1) * (pct || 0.15));
    return Math.max(0, r);
  };

  U.fmtNum = function (n) {
    if (n === null || n === undefined || isNaN(n)) return '?';
    n = Math.round(n);
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };
  U.fmtRate = function (n) {
    if (n === null || n === undefined) return '';
    if (n >= 100) return U.fmtNum(n) + '/s';
    return (Math.round(n * 100) / 100).toFixed(2) + '/s';
  };
  U.fmtRateShort = function (n) {
    if (n >= 1000) return (n / 1000).toFixed(1) + 'k/s';
    if (n >= 100) return Math.round(n) + '/s';
    return (Math.round(n * 10) / 10).toFixed(1) + '/s';
  };
  U.fmtBytes = function (b) {
    if (b === null || b === undefined) return '?';
    var u = ['B', 'KiB', 'MiB', 'GiB', 'TiB'], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    if (i === 0) return Math.round(b) + ' B';
    return (b >= 100 ? Math.round(b) : (Math.round(b * 10) / 10)) + ' ' + u[i];
  };
  U.fmtBytesRate = function (b) { return U.fmtBytes(b) + '/s'; };
  U.fmtUptime = function (ms) {
    var s = Math.floor(ms / 1000), d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    if (d > 0) return d + 'd ' + h + 'h';
    if (h > 0) return h + 'h ' + m + 'm';
    return m + 'm ' + (s % 60) + 's';
  };
  U.pad = function (n) { return (n < 10 ? '0' : '') + n; };
  U.fmtDate = function (d) {
    d = d || new Date();
    return d.getFullYear() + '-' + U.pad(d.getMonth() + 1) + '-' + U.pad(d.getDate()) + ' ' +
      U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()) + ':' + U.pad(d.getSeconds());
  };
  U.fmtTime = function (d) { return U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()) + ':' + U.pad(d.getSeconds()); };

  U.enc = function (s) { return encodeURIComponent(s); };
  U.dec = function (s) { try { return decodeURIComponent(s); } catch (e) { return s; } };

  U.uid = function (len) {
    var c = 'abcdefghijklmnopqrstuvwxyz0123456789', s = '';
    for (var i = 0; i < (len || 8); i++) s += c[Math.floor(Math.random() * c.length)];
    return s;
  };
  U.clone = function (o) { return JSON.parse(JSON.stringify(o)); };

  U.store = {
    get: function (k, def) {
      try { var v = w.localStorage.getItem(k); return v === null ? def : JSON.parse(v); } catch (e) { return def; }
    },
    set: function (k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* yok say */ } },
    del: function (k) { try { w.localStorage.removeItem(k); } catch (e) { /* yok say */ } }
  };

  /* Argüman objesini kısa gösterim */
  U.argsInline = function (args) {
    if (!args) return '';
    var keys = Object.keys(args);
    if (!keys.length) return '';
    return '<span class="args">' + keys.map(function (k) {
      var v = args[k];
      return '<span><b>' + U.esc(k) + ':</b> ' + U.esc(typeof v === 'object' ? JSON.stringify(v) : v) + '</span>';
    }).join('') + '</span>';
  };

  /* Topic routing key eşleşmesi (AMQP 0-9-1 topic semantiği) */
  U.topicMatch = function (pattern, key) {
    var p = pattern.split('.'), k = key === '' ? [] : key.split('.');
    function m(pi, ki) {
      if (pi === p.length) return ki === k.length;
      if (p[pi] === '#') {
        for (var j = ki; j <= k.length; j++) if (m(pi + 1, j)) return true;
        return false;
      }
      if (ki === k.length) return false;
      if (p[pi] === '*' || p[pi] === k[ki]) return m(pi + 1, ki + 1);
      return false;
    }
    if (pattern === '') return key === '';
    return m(0, 0);
  };

  /* Değeri tip tahminiyle çöz (form argümanları için) */
  U.parseTyped = function (val, type) {
    if (type === 'number') { var n = Number(val); return isNaN(n) ? val : n; }
    if (type === 'boolean') return String(val).toLowerCase() === 'true';
    if (type === 'list') { try { return JSON.parse(val); } catch (e) { return String(val).split(',').map(function (s) { return s.trim(); }); } }
    return String(val);
  };

  w.U = U;
})(window);
