/* Exchanges listesi / detay + Bindings + Publish */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};
  function vf(x) { return SIM.vhostOk(x.vhost); }

  P.exFeatures = function (e) {
    var f = [];
    if (e.durable) f.push('<abbr class="feat" title="durable: true" data-help="ex-durable">D</abbr>');
    if (e.auto_delete) f.push('<abbr class="feat" title="auto-delete: true" data-help="ex-auto-delete">AD</abbr>');
    if (e.internal) f.push('<abbr class="feat" title="internal: true" data-help="ex-internal">I</abbr>');
    if (Object.keys(e.arguments || {}).length) f.push('<abbr class="feat" title="' + esc(JSON.stringify(e.arguments)) + '" data-help="ex-args">Args</abbr>');
    var p = SIM.policyFor('exchange', e);
    if (p) f.push('<abbr class="feat pol" title="Policy: ' + esc(p.name) + '" data-help="policy">' + esc(p.name) + '</abbr>');
    return f.join('');
  };

  P.exchanges = function () {
    var h = ['<h1>Exchanges ' + UI.help('exchange') + '</h1>'];
    h.push(UI.section('All exchanges (' + SIM.S.exchanges.filter(vf).length + ')', UI.listTable({
      id: 'exchanges', rows: function () { return SIM.S.exchanges.filter(vf); },
      filterText: function (e) { return e.name || 'AMQP default'; },
      cols: [
        { key: 'vhost', label: 'Virtual host', help: 'vhost' },
        { key: 'name', label: 'Name', help: 'ex-name', fixed: true, render: function (e) { return UI.exLink(e.vhost, e.name); } },
        { key: 'type', label: 'Type', help: 'ex-type', render: function (e) { var hk = { direct: 'ex-type-direct', fanout: 'ex-type-fanout', topic: 'ex-type-topic', headers: 'ex-type-headers', 'x-local-random': 'ex-type-local-random' }[e.type]; return esc(e.type) + ' ' + UI.help(hk); } },
        { key: 'features', label: 'Features', nosort: true, render: P.exFeatures },
        { key: 'bindings', label: 'Bindings', hidden: true, cls: 'r', sort: function (e) { return SIM.bindingsFrom(e.vhost, e.name).length; }, render: function (e) { return e.name === '' ? '<span class="muted">implicit</span>' : SIM.bindingsFrom(e.vhost, e.name).length; } },
        { key: 'in', label: 'Message rate in', help: 'ex-rate-in', cls: 'r', sort: function (e) { return e.l_in; }, render: function (e) { return e.rate_in ? U.fmtRate(e.l_in) : ''; } },
        { key: 'out', label: 'Message rate out', help: 'ex-rate-out', cls: 'r', sort: function (e) { return e.l_out; }, render: function (e) { return e.rate_out ? U.fmtRate(e.l_out) : ''; } }
      ]
    }), { id: 'ex-all' }));
    h.push(UI.section('Add a new exchange', addExchangeForm(), { id: 'ex-add', closed: true }));
    h.push('<div class="edu-note"><b>Deneyin:</b> Bir exchange adına tıklayın ve "Publish message" bölümünden mesaj gönderin. Simülasyon mesajın binding kurallarına göre hangi kuyruklara yönlendirildiğini adım adım gösterir. <code>amq.*</code> ve <i>(AMQP default)</i> her vhost\'ta otomatik bulunan sistem exchange\'leridir ' + UI.help('ex-amq') + '</div>');
    return h.join('');
  };

  function addExchangeForm() {
    return '<form data-form="add-exchange"><table class="form">' +
      UI.formRow('Virtual host', UI.vhostSelect('vhost'), 'vhost') +
      UI.formRow('Name', '<input type="text" name="name" placeholder="ör. orders.events">', 'ex-name', true) +
      UI.formRow('Type', UI.select('type', ['direct', 'fanout', 'headers', 'topic', 'x-local-random'], 'direct'), 'ex-type') +
      UI.formRow('Durability', UI.select('durable', [['true', 'Durable'], ['false', 'Transient']], 'true'), 'ex-durable') +
      UI.formRow('Auto delete', UI.select('auto_delete', [['false', 'No'], ['true', 'Yes']], 'false'), 'ex-auto-delete') +
      UI.formRow('Internal', UI.select('internal', [['false', 'No'], ['true', 'Yes']], 'false'), 'ex-internal') +
      UI.formRow('Arguments', UI.kvEditor('args') + UI.argLinks('args', [['Add', [['alternate-exchange', '', 'string', 'alternate-exchange', 'Alternate exchange']]]]), 'ex-args') +
      '</table><button type="submit">Add exchange</button></form>';
  }

  /* ---------------- Exchange detay ---------------- */
  P.exchange = function (vhost, name) {
    if (name === 'amq.default') name = '';
    var e = SIM.exchange(vhost, name);
    if (!e) return P.notFound('Exchange', name);
    var disp = name === '' ? '(AMQP default)' : name;
    var h = ['<h1>Exchange: <b>' + esc(disp) + '</b> <span class="sub">in virtual host ' + esc(vhost) + '</span> ' + UI.help(name === '' ? 'ex-default' : 'exchange') + '</h1>'];
    var p = SIM.policyFor('exchange', e);
    var typeHelp = { direct: 'ex-type-direct', fanout: 'ex-type-fanout', topic: 'ex-type-topic', headers: 'ex-type-headers', 'x-local-random': 'ex-type-local-random' }[e.type];
    h.push(UI.section('Overview', UI.chart({
      id: 'ex-rates', title: 'Message rates', help: 'message-rates', unit: 'rate', legendCols: 1,
      get: function (range) {
        var hh = SIM.hist.e[SIM.qkey(vhost, name)] || { in: [0], out: [0] };
        return { times: SIM.slice(SIM.hist.t, range), series: [
          { key: 'in', label: 'Publish<br>(In)', color: Charts.COLORS.publish, data: SIM.slice(hh.in, range), value: U.fmtRate(hh.in[hh.in.length - 1]), help: 'ex-rate-in' },
          { key: 'out', label: 'Publish<br>(Out)', color: Charts.COLORS.confirm, data: SIM.slice(hh.out, range), value: U.fmtRate(hh.out[hh.out.length - 1]), help: 'ex-rate-out' }
        ] };
      }
    }) + UI.h3('Details') + UI.facts([
      ['Type', esc(e.type), typeHelp],
      ['Features', P.exFeatures(e) || '<span class="muted">(none)</span>', 'q-features'],
      ['Policy', p ? '<a href="#/policies">' + esc(p.name) + '</a>' : '', 'policy'],
      Object.keys(e.arguments).length ? ['Arguments', UI.argsTable(e.arguments), 'ex-args'] : null
    ]), { id: 'ex-ov' }));

    h.push(UI.section('Bindings', name === '' ? '<p>Default exchange\'e her kuyruk otomatik olarak <b>kendi adıyla</b> bağlıdır. Bu binding\'ler örtüktür (implicit), listelenmez ve değiştirilemez. ' + UI.help('ex-default') + '</p>' : UI.block(function () { return bindingsFrom(vhost, name); }) + addBindingForm(vhost, name, 'from'), { id: 'ex-bind', help: 'bindings-section' }));
    h.push(UI.section('Publish message', publishForm(vhost, name, e), { id: 'ex-pub', closed: false, help: 'publish-message' }));
    if (!e.builtin) h.push(UI.section('Delete this exchange', '<form data-form="delete-exchange" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><label><input type="checkbox" name="if_unused"> Yalnızca kullanılmıyorsa (if-unused)</label><br><br><button type="submit" class="danger">Delete</button></form>', { id: 'ex-del', closed: true }));
    else h.push('<p class="muted small">Bu, sistem tarafından oluşturulmuş bir exchange\'dir ve silinemez ' + UI.help('ex-amq') + '</p>');
    return h.join('');
  };

  function bindingRowArgs(b) { return Object.keys(b.arguments).length ? U.argsInline(b.arguments) : ''; }
  function bindingsFrom(vhost, name) {
    var bs = SIM.bindingsFrom(vhost, name);
    var h = '<div class="topo"><span class="node-b"><b>This exchange</b></span><span class="arrow">⇓</span></div>';
    if (!bs.length) return h + '<p class="muted">... no bindings ...</p>';
    return h + '<table class="list"><thead><tr><th>To</th><th>Routing key ' + UI.help('binding-routing-key') + '</th><th>Arguments ' + UI.help('binding-args') + '</th><th></th></tr></thead><tbody>' + bs.map(function (b) {
      return '<tr><td>' + (b.destination_type === 'queue' ? UI.qLink(vhost, b.destination) + ' <span class="muted small">queue</span>' : UI.exLink(vhost, b.destination) + ' <span class="muted small">exchange</span> ' + UI.help('e2e-binding')) + '</td><td>' + esc(b.routing_key) + '</td><td>' + bindingRowArgs(b) + '</td><td>' + unbindBtn(b) + '</td></tr>';
    }).join('') + '</tbody></table>';
  }
  function unbindBtn(b) {
    return '<button class="small" data-action="unbind" data-vhost="' + esc(b.vhost) + '" data-src="' + esc(b.source) + '" data-dst="' + esc(b.destination) + '" data-dtype="' + b.destination_type + '" data-rk="' + esc(b.routing_key) + '" data-args="' + esc(JSON.stringify(b.arguments)) + '">Unbind</button>';
  }
  P.unbindBtn = unbindBtn;
  P.bindingRowArgs = bindingRowArgs;

  function addBindingForm(vhost, name, dir) {
    var ex = dir === 'from';
    return UI.h3(ex ? 'Add binding from this exchange' : 'Add binding to this queue', 'binding') + '<form data-form="add-binding" data-dir="' + dir + '" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><table class="form">' +
      (ex ? UI.formRow(UI.select('dtype', [['queue', 'To queue'], ['exchange', 'To exchange']], 'queue'), '<input type="text" name="target" list="dl-targets-' + esc(name) + '" placeholder="hedef adı">', 'e2e-binding', true) +
        '<datalist id="dl-targets-' + esc(name) + '">' + SIM.S.queues.filter(function (q) { return q.vhost === vhost; }).map(function (q) { return '<option value="' + esc(q.name) + '">'; }).join('') + SIM.S.exchanges.filter(function (e) { return e.vhost === vhost && e.name && e.name !== name; }).map(function (e) { return '<option value="' + esc(e.name) + '">'; }).join('') + '</datalist>'
        : UI.formRow('From exchange', '<input type="text" name="target" list="dl-src-' + esc(name) + '" placeholder="kaynak exchange">', 'exchange', true) +
        '<datalist id="dl-src-' + esc(name) + '">' + SIM.S.exchanges.filter(function (e) { return e.vhost === vhost && e.name; }).map(function (e) { return '<option value="' + esc(e.name) + '">'; }).join('') + '</datalist>') +
      UI.formRow('Routing key', '<input type="text" name="rk">', 'binding-routing-key') +
      UI.formRow('Arguments', UI.kvEditor('bargs') + UI.argLinks('bargs', [['Headers exchange', [['x-match', 'all', 'string', 'x-match', 'x-match']]]]), 'binding-args') +
      '</table><button type="submit">Bind</button></form>';
  }
  P.addBindingForm = addBindingForm;

  function publishForm(vhost, name, e) {
    return '<form data-form="publish" data-vhost="' + esc(vhost) + '" data-ex="' + esc(name) + '">' +
      (e.internal ? '<div class="form-msg warn">Bu exchange <b>internal</b> olduğu için istemciler doğrudan yayın yapamaz ' + UI.help('ex-internal') + '. Denerseniz broker ACCESS_REFUSED döndürür.</div>' : '') +
      '<table class="form">' +
      UI.formRow('Routing key', '<input type="text" name="rk" placeholder="' + (e.type === 'topic' ? 'ör. order.created.tr' : e.type === 'direct' ? (name === '' ? 'kuyruk adı' : 'ör. process') : '(' + e.type + ': yok sayılır)') + '">', 'routing-key') +
      UI.formRow('Headers', UI.kvEditor('headers'), 'msg-headers') +
      UI.formRow('Properties', '<div class="kv-rows">' +
        '<div class="kv">delivery_mode ' + UI.help('delivery-mode') + ' ' + UI.select('delivery_mode', [['2', '2 - Persistent'], ['1', '1 - Non-persistent']], '2') + '</div>' +
        '<div class="kv">content_type <input type="text" name="content_type" value="application/json"></div>' +
        '<div class="kv">priority <input type="number" name="priority" min="0" max="255" style="width:70px"> expiration (ms) <input type="text" name="expiration" style="width:90px"></div>' +
        '<div class="kv">message_id <input type="text" name="message_id"> correlation_id <input type="text" name="correlation_id"></div>' +
        '</div>', 'msg-properties') +
      UI.formRow('Payload', '<textarea name="payload" rows="5">{"orderId": 10231, "status": "created", "total": 349.90}</textarea>', 'payload') +
      UI.formRow('Mandatory', '<label><input type="checkbox" name="mandatory"> mandatory=true (yönlendirilemezse publisher\'a geri dön)</label>', 'rate-unroutable-return') +
      '</table><button type="submit">Publish message</button><div class="publish-result"></div></form>';
  }
  P.publishForm = publishForm;

  P.renderPublishResult = function (res, vhost, exName) {
    if (res.error) return '<div class="form-msg err"><b>Hata:</b> ' + esc(res.error) + '</div>';
    var h = '<div class="form-msg ' + (res.routed ? '' : 'warn') + '"><b>' + (res.routed ? 'Message published.' : 'Message published, but not routed.') + '</b>';
    if (!res.routed) h += '<br>Hiçbir binding eşleşmediği için mesaj düşürüldü (Unroutable). Alternate exchange tanımlayarak bu mesajları yakalayabilirsiniz ' + UI.help('alternate-exchange');
    h += '</div>';
    if (res.trace.length) {
      h += '<div class="msg-box"><h4>Yönlendirme adımları (simülasyon)</h4><table class="list"><thead><tr><th>Exchange</th><th>Binding → hedef</th><th>Sonuç</th></tr></thead><tbody>' + res.trace.map(function (t) {
        if (t.note) return '<tr><td>' + esc(t.ex) + '</td><td colspan="2">' + esc(t.note) + '</td></tr>';
        return '<tr><td>' + esc(t.ex) + '</td><td>' + esc(t.b.routing_key || '(boş)') + ' → ' + esc(t.b.destination) + (t.b.destination_type === 'exchange' ? ' (exchange)' : '') + '</td><td class="' + (t.ok ? 'ok-text' : 'muted') + '">' + (t.ok ? '✔ ' : '✘ ') + esc(t.why) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
    }
    if (res.results.length) {
      h += '<div class="msg-box"><h4>Mesajı alan kuyruklar</h4><ul style="margin:0;padding-left:18px">' + res.results.map(function (r) {
        var link = UI.qLink(r.q.vhost, r.q.name);
        if (r.action === 'delivered') return '<li>' + link + ': kuyruk boştu ve aktif consumer vardı → mesaj <b>hemen consumer\'a teslim edildi</b> (<code>' + esc(r.consumer.consumer_tag) + '</code>). Ready sayısı artmaz.</li>';
        if (r.action === 'stream') return '<li>' + link + ' (stream): mesaj log\'un sonuna eklendi. Stream\'de tüketim mesajı silmez; ' + r.consumers + ' consumer kendi offset\'inden okur.</li>';
        if (r.action === 'overflow') return '<li>' + link + ': kuyruk max-length sınırında → overflow=<b>' + esc(r.overflow) + '</b>' + (r.overflow === 'drop-head' ? ' (en eski mesaj atıldı)' : ' (yeni mesaj reddedildi; confirm modunda publisher nack alır)') + ' ' + UI.help('x-overflow') + '</li>';
        return '<li>' + link + ': kuyruğa eklendi (ready). Önünde <b>' + U.fmtNum(r.ahead) + '</b> mesaj var' + (r.consumers ? ', ' + r.consumers + ' consumer' : ', <b>consumer yok</b> – mesaj kuyrukta bekleyecek') + '. Kuyruk sayfasındaki "Get messages" ile görüntüleyebilirsiniz.</li>';
      }).join('') + '</ul></div>';
    }
    return h;
  };
})(window);
