/* =========================================================================
   Simülasyon başlangıç verileri (seed)
   Bu veriler tamamen örnektir; gerçek bir broker'a bağlanılmaz.
   ========================================================================= */
(function (w) {
  'use strict';

  var NODES = ['rabbit@mq-node-01', 'rabbit@mq-node-02', 'rabbit@mq-node-03'];
  var LISTENER_IP = { 'rabbit@mq-node-01': '10.20.40.11', 'rabbit@mq-node-02': '10.20.40.12', 'rabbit@mq-node-03': '10.20.40.13' };
  var GiB = 1024 * 1024 * 1024, MiB = 1024 * 1024;

  function defaultExchanges(vhost) {
    return [
      { name: '', type: 'direct' },
      { name: 'amq.direct', type: 'direct' },
      { name: 'amq.fanout', type: 'fanout' },
      { name: 'amq.headers', type: 'headers' },
      { name: 'amq.match', type: 'headers' },
      { name: 'amq.rabbitmq.trace', type: 'topic', internal: true },
      { name: 'amq.topic', type: 'topic' }
    ].map(function (e) {
      return {
        vhost: vhost, name: e.name, type: e.type, durable: true, auto_delete: false,
        internal: !!e.internal, arguments: {}, builtin: true, rate_in: 0, rate_out: 0
      };
    });
  }

  function seed() {
    var r = U.rng(20261119);
    function ri(a, b) { return a + Math.floor(r() * (b - a + 1)); }

    var now = Date.now();
    var S = {
      seededAt: now,
      cluster_name: 'MQ_EGITIM_CLUSTER',
      product: 'RabbitMQ',
      version: '4.1.4',
      erlang: '27.3.4.3',
      current_user: 'admin',
      rates_mode: 'basic',
      nodes: [], vhosts: [], users: [], permissions: [], topic_permissions: [],
      exchanges: [], queues: [], bindings: [], connections: [], channels: [], consumers: [],
      policies: [], operator_policies: [], vhost_limits: [], user_limits: [],
      feature_flags: [], deprecated_features: [], fed_upstreams: [], fed_upstream_sets: [], fed_links: [],
      shovels: [], partitions: [], alarms: [], churn: {}
    };

    /* ---------------- Nodes ---------------- */
    var nodeBase = [
      { fd: 65, proc: 684, mem: 126, disk: 49.2, up: 4 * 86400 + 3 * 3600 + 1200, load: 0.42 },
      { fd: 40, proc: 387, mem: 113, disk: 48.7, up: 4 * 86400 + 3 * 3600 + 800, load: 0.31 },
      { fd: 41, proc: 388, mem: 117, disk: 49.0, up: 4 * 86400 + 6 * 3600 + 120, load: 0.28 }
    ];
    NODES.forEach(function (n, i) {
      var b = nodeBase[i];
      S.nodes.push({
        name: n, type: 'disc', running: true, being_drained: false,
        fd_used: b.fd, fd_total: 65536,
        sockets_used: b.fd - 12, sockets_total: 58893,
        proc_used: b.proc, proc_total: 1048576,
        mem_used: b.mem * MiB, mem_limit: 7.5 * GiB, mem_calc: 'rss',
        disk_free: b.disk * GiB, disk_free_limit: 9.3 * GiB, disk_total: 64 * GiB,
        uptime_base: b.up * 1000, cores: 4, run_queue: 0, load: b.load,
        os_pid: String(1180 + i * 17), erlang_full: 'Erlang/OTP 27 [erts-15.2.7.1] [source] [64-bit] [smp:4:4] [ds:4:4:10] [async-threads:1] [jit:ns]',
        config_files: ['/etc/rabbitmq/rabbitmq.conf', '/etc/rabbitmq/advanced.config'],
        log_files: ['/var/log/rabbitmq/' + n + '.log'],
        db_dir: '/var/lib/rabbitmq/mnesia/' + n,
        enabled_plugins: ['rabbitmq_management', 'rabbitmq_federation_management', 'rabbitmq_shovel_management', 'rabbitmq_prometheus', 'rabbitmq_stream_management'],
        cpu_util: 8 + i * 3, gc_per_s: 1400 + i * 120, io_read: 0.0, io_write: 12 + i * 3,
        net_ticktime: 60
      });
    });

    /* ---------------- Virtual hosts ---------------- */
    S.vhosts = [
      { name: '/', description: 'Varsayılan virtual host', tags: [], default_queue_type: 'classic', tracing: false, protected: false },
      { name: 'orders', description: 'Sipariş yaşam döngüsü (order-api, fulfillment)', tags: ['prod', 'core'], default_queue_type: 'quorum', tracing: false, protected: true },
      { name: 'payments', description: 'Ödeme ve iade akışları', tags: ['prod', 'pci'], default_queue_type: 'quorum', tracing: false, protected: true },
      { name: 'notifications', description: 'E-posta / SMS / Push bildirimleri', tags: ['prod'], default_queue_type: 'quorum', tracing: false, protected: false },
      { name: 'analytics', description: 'Clickstream ve olay toplama (stream ağırlıklı)', tags: ['analytics'], default_queue_type: 'stream', tracing: true, protected: false }
    ];

    /* ---------------- Users ---------------- */
    S.users = [
      { name: 'admin', tags: ['administrator'], has_password: true },
      { name: 'ops-team', tags: ['policymaker'], has_password: true },
      { name: 'monitoring', tags: ['monitoring'], has_password: true },
      { name: 'analytics-reader', tags: ['management'], has_password: true },
      { name: 'order-service', tags: [], has_password: true },
      { name: 'payment-service', tags: [], has_password: true },
      { name: 'notification-service', tags: [], has_password: true },
      { name: 'analytics-writer', tags: [], has_password: true },
      { name: 'iot-gateway', tags: [], has_password: true },
      { name: 'legacy-billing', tags: [], has_password: true },
      { name: 'federation-user', tags: [], has_password: true },
      { name: 'shovel-user', tags: [], has_password: true },
      { name: 'cert-client-01', tags: [], has_password: false }
    ];
    S.users.forEach(function (u) { u.hashing = 'rabbit_password_hashing_sha256'; });

    function perm(user, vhost, c, wr, rd) { S.permissions.push({ user: user, vhost: vhost, configure: c, write: wr, read: rd }); }
    S.vhosts.forEach(function (v) { perm('admin', v.name, '.*', '.*', '.*'); perm('ops-team', v.name, '.*', '.*', '.*'); perm('monitoring', v.name, '', '', '.*'); });
    perm('analytics-reader', 'analytics', '', '', '.*');
    perm('order-service', 'orders', '^orders\\..*', '^orders\\..*', '^orders\\..*');
    perm('payment-service', 'payments', '^payments\\..*', '^payments\\..*', '^payments\\..*');
    perm('payment-service', 'orders', '', '^orders\\.events$', '');
    perm('notification-service', 'notifications', '^(notifications\\..*|amq\\.gen.*)', '^notifications\\..*', '^(notifications\\..*|amq\\.gen.*)');
    perm('analytics-writer', 'analytics', '^analytics\\..*', '^analytics\\..*', '^analytics\\..*');
    perm('iot-gateway', '/', '^mqtt-subscription-.*', '^amq\\.topic$', '^(amq\\.topic|mqtt-subscription-.*)');
    perm('legacy-billing', '/', '^app\\..*', '^app\\..*', '^app\\..*');
    perm('federation-user', '/', '^federation:.*', '^federat.*', '^federat.*');
    perm('shovel-user', '/', '', '', '^legacy\\..*');
    perm('shovel-user', 'orders', '', '^orders\\.events$', '');

    S.topic_permissions = [
      { user: 'iot-gateway', vhost: '/', exchange: 'amq.topic', write: '^devices\\.{client_id}\\..*', read: '^devices\\.{client_id}\\..*|^broadcast\\..*' },
      { user: 'payment-service', vhost: 'orders', exchange: 'orders.events', write: '^order\\.paid\\..*', read: '' }
    ];

    /* ---------------- Exchanges ---------------- */
    S.vhosts.forEach(function (v) { S.exchanges = S.exchanges.concat(defaultExchanges(v.name)); });
    function ex(vhost, name, type, opts) {
      opts = opts || {};
      S.exchanges.push({
        vhost: vhost, name: name, type: type, durable: opts.durable !== false, auto_delete: !!opts.auto_delete,
        internal: !!opts.internal, arguments: opts.arguments || {}, builtin: false,
        rate_in: opts.rin || 0, rate_out: opts.rout || 0
      });
    }
    ex('orders', 'orders.events', 'topic', { rin: 14.6, rout: 29.0, arguments: { 'alternate-exchange': 'orders.unrouted' } });
    ex('orders', 'orders.commands', 'direct', { rin: 3.2, rout: 3.2 });
    ex('orders', 'orders.dlx', 'fanout', { rin: 0.2, rout: 0.2 });
    ex('orders', 'orders.unrouted', 'fanout', { rin: 0.0, rout: 0.0 });
    ex('payments', 'payments.commands', 'direct', { rin: 6.4, rout: 6.4 });
    ex('payments', 'payments.events', 'topic', { rin: 6.1, rout: 6.1 });
    ex('payments', 'payments.routing', 'headers', { rin: 1.2, rout: 1.2 });
    ex('payments', 'payments.dlx', 'fanout', { rin: 0.0, rout: 0.0 });
    ex('notifications', 'notifications.broadcast', 'fanout', { rin: 8.8, rout: 26.4 });
    ex('notifications', 'notifications.internal', 'topic', { internal: true, rin: 2.0, rout: 2.0 });
    ex('analytics', 'analytics.ingest', 'topic', { rin: 182.0, rout: 182.0 });
    ex('analytics', 'analytics.workers', 'x-local-random', { rin: 4.0, rout: 4.0 });
    ex('/', 'app.logs', 'fanout', { rin: 2.4, rout: 2.4 });
    ex('/', 'federated.orders', 'topic', { rin: 0.9, rout: 0.9 });

    /* ---------------- Queues ---------------- */
    function q(vhost, name, type, o) {
      o = o || {};
      var leader = o.node || NODES[ri(0, 2)];
      var members = type === 'classic' ? [leader] : NODES.slice();
      S.queues.push({
        vhost: vhost, name: name, type: type,
        durable: o.durable !== false, auto_delete: !!o.auto_delete, exclusive: !!o.exclusive,
        arguments: o.arguments || (type === 'classic' ? {} : { 'x-queue-type': type }),
        node: leader, members: members, online: members.slice(),
        state: o.state || 'running',
        ready: o.ready || 0, unacked: o.unacked || 0,
        r_pub: o.pub || 0, r_del: o.del || 0, r_ack: o.ack !== undefined ? o.ack : (o.del || 0), r_redeliver: o.redel || 0, r_get: 0,
        memory: o.memory || (type === 'classic' ? ri(20, 90) * 1024 : ri(400, 2200) * 1024),
        bytes: o.bytes || 0,
        sac: !!o.sac, created_at: now - ri(2, 40) * 86400000,
        owner: o.owner || null,
        messages: [], seq: 0
      });
    }
    q('orders', 'orders.created', 'quorum', { ready: 12, unacked: 30, pub: 8.4, del: 8.3, node: NODES[0], arguments: { 'x-queue-type': 'quorum', 'x-delivery-limit': 10 } });
    q('orders', 'orders.paid', 'quorum', { ready: 3, unacked: 18, pub: 5.2, del: 5.2, node: NODES[1] });
    q('orders', 'orders.shipped', 'quorum', { ready: 0, unacked: 4, pub: 1.9, del: 1.9, node: NODES[2] });
    q('orders', 'orders.cancelled', 'quorum', { ready: 1842, unacked: 0, pub: 0.6, del: 0, node: NODES[0] });
    q('orders', 'orders.dlq', 'quorum', { ready: 37, unacked: 0, pub: 0.02, del: 0, node: NODES[1], arguments: { 'x-queue-type': 'quorum', 'x-message-ttl': 1209600000 } });
    q('orders', 'orders.unrouted', 'quorum', { ready: 3, node: NODES[2] });
    q('orders', 'orders.retry', 'classic', { ready: 6, pub: 0.2, del: 0, node: NODES[0], arguments: { 'x-message-ttl': 30000, 'x-dead-letter-exchange': 'orders.events', 'x-dead-letter-routing-key': 'order.created.retry' } });
    q('orders', 'orders.audit', 'stream', { ready: 2450113, pub: 14.6, del: 14.6, node: NODES[2], bytes: 1.9 * GiB, memory: 512 * 1024, arguments: { 'x-queue-type': 'stream', 'x-max-age': '30D', 'x-stream-max-segment-size-bytes': 52428800 } });
    q('payments', 'payments.process', 'quorum', { ready: 0, unacked: 1, pub: 6.4, del: 6.4, sac: true, node: NODES[0], arguments: { 'x-queue-type': 'quorum', 'x-single-active-consumer': true } });
    q('payments', 'payments.refund', 'quorum', { ready: 2, unacked: 2, pub: 0.8, del: 0.8, node: NODES[2] });
    q('payments', 'payments.priority', 'classic', { ready: 0, unacked: 1, pub: 1.2, del: 1.2, node: NODES[1], arguments: { 'x-max-priority': 10 } });
    q('payments', 'payments.dlq', 'quorum', { ready: 5, node: NODES[1] });
    q('payments', 'payments.ledger', 'stream', { ready: 884920, pub: 6.1, del: 6.1, node: NODES[0], bytes: 640 * MiB, memory: 380 * 1024, arguments: { 'x-queue-type': 'stream', 'x-max-length-bytes': 21474836480 } });
    q('notifications', 'notifications.email', 'quorum', { ready: 48, unacked: 20, pub: 8.8, del: 8.6, redel: 0.1, node: NODES[1] });
    q('notifications', 'notifications.sms', 'quorum', { ready: 0, unacked: 6, pub: 8.8, del: 8.8, node: NODES[2] });
    q('notifications', 'notifications.push', 'classic', { ready: 2, unacked: 10, pub: 8.8, del: 8.8, node: NODES[0], arguments: { 'x-max-length': 50000, 'x-overflow': 'drop-head' } });
    q('notifications', 'notifications.temp', 'classic', { ready: 14, durable: false, node: NODES[0] });
    q('notifications', 'amq.gen-Vq3eYb8kZp0mRjL2w9xT1A', 'classic', { exclusive: true, auto_delete: true, durable: false, pub: 2.0, del: 2.0, node: NODES[2], owner: 'notif-2' });
    q('analytics', 'analytics.clickstream', 'stream', { ready: 18734220, pub: 162.0, del: 0, node: NODES[1], bytes: 14.2 * GiB, memory: 720 * 1024, arguments: { 'x-queue-type': 'stream', 'x-max-age': '7D', 'x-stream-filter-size-bytes': 32 } });
    q('analytics', 'analytics.aggregator', 'quorum', { ready: 240, unacked: 50, pub: 20.0, del: 19.4, node: NODES[2] });
    q('/', 'app.logs.archive', 'classic', { ready: 0, unacked: 3, pub: 2.4, del: 2.4, node: NODES[0] });
    q('/', 'legacy.orders', 'classic', { ready: 12480, unacked: 250, pub: 0, del: 9.5, node: NODES[1] });
    q('/', 'mqtt-subscription-iot-gateway-01qos1', 'classic', { ready: 0, unacked: 0, pub: 0.5, del: 0.5, node: NODES[0], auto_delete: false, arguments: { 'x-expires': 86400000 } });

    /* ---------------- Bindings ---------------- */
    function b(vhost, src, dst, rk, args, dtype) {
      S.bindings.push({ vhost: vhost, source: src, destination: dst, destination_type: dtype || 'queue', routing_key: rk || '', arguments: args || {} });
    }
    b('orders', 'orders.events', 'orders.created', 'order.created.#');
    b('orders', 'orders.events', 'orders.paid', 'order.paid.*');
    b('orders', 'orders.events', 'orders.shipped', 'order.shipped.*');
    b('orders', 'orders.events', 'orders.cancelled', 'order.cancelled.*');
    b('orders', 'orders.events', 'orders.audit', 'order.#');
    b('orders', 'orders.unrouted', 'orders.unrouted', '');
    b('orders', 'orders.commands', 'orders.created', 'create-order');
    b('orders', 'orders.dlx', 'orders.dlq', '');
    b('payments', 'payments.commands', 'payments.process', 'process');
    b('payments', 'payments.commands', 'payments.refund', 'refund');
    b('payments', 'payments.events', 'payments.ledger', 'payment.#');
    b('payments', 'payments.routing', 'payments.priority', '', { 'x-match': 'all', 'tier': 'gold', 'region': 'tr' });
    b('payments', 'payments.routing', 'payments.process', '', { 'x-match': 'any', 'tier': 'standard', 'channel': 'web' });
    b('payments', 'payments.dlx', 'payments.dlq', '');
    b('notifications', 'notifications.broadcast', 'notifications.email', '');
    b('notifications', 'notifications.broadcast', 'notifications.sms', '');
    b('notifications', 'notifications.broadcast', 'notifications.push', '');
    b('notifications', 'notifications.broadcast', 'notifications.internal', '', {}, 'exchange');
    b('notifications', 'notifications.internal', 'notifications.temp', 'audit.#');
    b('notifications', 'notifications.internal', 'amq.gen-Vq3eYb8kZp0mRjL2w9xT1A', 'reply.*');
    b('analytics', 'analytics.ingest', 'analytics.clickstream', 'click.#');
    b('analytics', 'analytics.ingest', 'analytics.aggregator', '*.aggregate');
    b('analytics', 'analytics.workers', 'analytics.aggregator', '');
    b('/', 'app.logs', 'app.logs.archive', '');
    b('/', 'amq.topic', 'mqtt-subscription-iot-gateway-01qos1', 'devices.iot-gateway-01.#');
    b('/', 'federated.orders', 'legacy.orders', 'order.#');

    /* ---------------- Connections / Channels / Consumers ---------------- */
    var portSeq = 33810;
    function conn(o) {
      var node = o.node;
      var port = (portSeq += ri(300, 1900));
      var lip = LISTENER_IP[node];
      var lport = o.tls ? 5671 : (o.protocol.indexOf('MQTT') === 0 ? 1883 : 5672);
      var name = o.direct ? o.client_name : (o.ip + ':' + port + ' -> ' + lip + ':' + lport);
      var c = {
        name: name, node: node, user: o.user, vhost: o.vhost, protocol: o.protocol,
        state: o.state || 'running', ssl: !!o.tls, ssl_protocol: o.tls ? 'tlsv1.3' : null,
        ssl_cipher: o.tls ? 'TLS_AES_256_GCM_SHA384' : null, peer_cert_subject: o.peer_cert || null,
        peer_host: o.direct ? null : o.ip, peer_port: o.direct ? null : port, host: o.direct ? null : lip, port: o.direct ? null : lport,
        auth_mechanism: o.auth || (o.direct ? 'none' : 'PLAIN'),
        connected_at: now - ri(60, 300000) * 1000,
        frame_max: 131072, channel_max: 2047, timeout: o.protocol.indexOf('AMQP 0-9-1') === 0 ? 60 : null,
        container_id: o.container_id || '',
        client_properties: o.cp || {},
        recv_rate: o.recv || 0, send_rate: o.send || 0,
        recv_oct: ri(1, 900) * MiB, send_oct: ri(1, 400) * MiB,
        reductions: ri(10000, 900000), gc_heap: ri(20, 900) * 1024,
        channels_n: 0, short_id: o.id
      };
      S.connections.push(c);
      return c;
    }
    function chan(c, number, o) {
      o = o || {};
      var ch = {
        name: c.name + ' (' + number + ')', number: number, connection: c.name, node: c.node, user: c.user, vhost: c.vhost,
        state: o.state || 'running', confirm: !!o.confirm, transactional: !!o.tx,
        prefetch: o.prefetch || 0, global_prefetch: o.global_prefetch || 0,
        unacked: o.unacked || 0, unconfirmed: o.unconfirmed || 0, uncommitted: 0,
        r_pub: o.pub || 0, r_confirm: o.confirm ? (o.pub || 0) : 0, r_unroutable: o.unroutable || 0,
        r_deliver: o.del || 0, r_ack: o.ack !== undefined ? o.ack : (o.del || 0), r_redeliver: 0, r_get: 0,
        idle_since: (o.pub || o.del) ? null : now - ri(10, 900) * 1000,
        publishes_to: o.publishes || []
      };
      c.channels_n++;
      S.channels.push(ch);
      return ch;
    }
    function cons(ch, qvhost, qname, o) {
      o = o || {};
      S.consumers.push({
        vhost: qvhost, queue: qname, channel: ch.name, connection: ch.connection, consumer_tag: o.tag || ('amq.ctag-' + U.uid(22)),
        ack_required: o.ack !== false, exclusive: !!o.exclusive, prefetch_count: ch.prefetch,
        active: o.active !== false, activity_status: o.status || 'up', arguments: o.args || {}
      });
    }
    function dotnetCp(app, ver) {
      return { connection_name: app, product: 'RabbitMQ .NET Client', version: ver || '7.1.2', platform: '.NET', information: 'https://www.rabbitmq.com/dotnet.html',
        copyright: 'Copyright (c) 2007-2025 Broadcom.', capabilities: { publisher_confirms: true, exchange_exchange_bindings: true, 'basic.nack': true, consumer_cancel_notify: true, 'connection.blocked': true, authentication_failure_close: true } };
    }
    function javaCp(app) {
      return { connection_name: app, product: 'RabbitMQ', version: '5.25.0', platform: 'Java', information: 'Licensed under the MPL. See https://www.rabbitmq.com/',
        capabilities: { publisher_confirms: true, exchange_exchange_bindings: true, 'basic.nack': true, consumer_cancel_notify: true, 'connection.blocked': true, authentication_failure_close: true } };
    }

    // order-api: 3 instance x (publisher + consumer)
    [1, 2, 3].forEach(function (i) {
      var node = NODES[(i - 1) % 3];
      var pc = conn({ ip: '10.20.31.1' + i, node: node, user: 'order-service', vhost: 'orders', protocol: 'AMQP 0-9-1', cp: dotnetCp('order-api-' + i + ' (publisher)'), recv: 2100 + i * 90, send: 46, id: 'order-pub-' + i });
      chan(pc, 1, { confirm: true, pub: 4.9, unconfirmed: i === 2 ? 3 : 0, publishes: [['orders', 'orders.events']] });
      var cc = conn({ ip: '10.20.31.1' + i, node: node, user: 'order-service', vhost: 'orders', protocol: 'AMQP 0-9-1', cp: dotnetCp('order-api-' + i + ' (consumer)'), recv: 140, send: 2600 + i * 70, id: 'order-con-' + i });
      var ch1 = chan(cc, 1, { prefetch: 20, unacked: 10, del: 2.8 });
      var ch2 = chan(cc, 2, { prefetch: 10, unacked: 6, del: 1.7 });
      cons(ch1, 'orders', 'orders.created');
      cons(ch2, 'orders', 'orders.paid');
      if (i === 1) { var ch3 = chan(cc, 3, { prefetch: 5, unacked: 4, del: 1.9 }); cons(ch3, 'orders', 'orders.shipped'); }
    });
    // payment-worker: 2 instance
    [1, 2].forEach(function (i) {
      var node = NODES[i];
      var c = conn({ ip: '10.20.32.2' + i, node: node, user: 'payment-service', vhost: 'payments', protocol: 'AMQP 0-9-1', cp: javaCp('payment-worker-' + i), recv: 900, send: 1800, id: 'pay-' + i });
      var ch1 = chan(c, 1, { prefetch: 1, unacked: i === 1 ? 1 : 0, del: i === 1 ? 6.4 : 0 });
      cons(ch1, 'payments', 'payments.process', { active: i === 1, status: i === 1 ? 'single_active' : 'waiting' });
      var ch2 = chan(c, 2, { prefetch: 5, unacked: 1, del: 0.4 });
      cons(ch2, 'payments', 'payments.refund');
      var ch3 = chan(c, 3, { confirm: true, pub: 3.05, publishes: [['payments', 'payments.events']] });
      if (i === 1) { var ch4 = chan(c, 4, { prefetch: 1, unacked: 1, del: 1.2 }); cons(ch4, 'payments', 'payments.priority', { args: { 'x-priority': 5 } }); }
    });
    var cpay = conn({ ip: '10.20.32.30', node: NODES[0], user: 'payment-service', vhost: 'payments', protocol: 'AMQP 0-9-1', cp: javaCp('payment-gateway'), recv: 650, send: 50, id: 'pay-gw' });
    chan(cpay, 1, { confirm: true, pub: 6.4, publishes: [['payments', 'payments.commands']] });
    chan(cpay, 2, { tx: true, pub: 1.2, publishes: [['payments', 'payments.routing']] });

    // notification-service: 2 instance (Spring AMQP / Java)
    [1, 2].forEach(function (i) {
      var node = NODES[(i + 1) % 3];
      var c = conn({ ip: '10.20.33.4' + i, node: node, user: 'notification-service', vhost: 'notifications', protocol: 'AMQP 0-9-1', cp: javaCp('notification-service#' + i + ' (SpringAMQP)'), recv: 300, send: 3900, id: 'notif-' + i });
      var a = chan(c, 1, { prefetch: 250, unacked: 10, del: 4.3 });
      cons(a, 'notifications', 'notifications.email');
      var bch = chan(c, 2, { prefetch: 250, unacked: 3, del: 4.4 });
      cons(bch, 'notifications', 'notifications.sms');
      var cch = chan(c, 3, { prefetch: 100, unacked: 5, del: 4.4 });
      cons(cch, 'notifications', 'notifications.push');
      if (i === 2) {
        var dch = chan(c, 4, { prefetch: 0, del: 2.0, pub: 8.8, publishes: [['notifications', 'notifications.broadcast']] });
        cons(dch, 'notifications', 'amq.gen-Vq3eYb8kZp0mRjL2w9xT1A', { ack: false, exclusive: true });
      }
    });

    // analytics: AMQP 1.0 istemcileri
    var an1 = conn({ ip: '10.20.34.51', node: NODES[1], user: 'analytics-writer', vhost: 'analytics', protocol: 'AMQP 1.0', container_id: 'analytics-ingest-7f9c', cp: { product: 'rabbitmq-amqp-dotnet-client', version: '0.4.0', platform: '.NET 8' }, recv: 61000, send: 210, id: 'an-1' });
    chan(an1, 1, { pub: 182.0, confirm: true, publishes: [['analytics', 'analytics.ingest']] });
    var an2 = conn({ ip: '10.20.34.52', node: NODES[2], user: 'analytics-writer', vhost: 'analytics', protocol: 'AMQP 1.0', container_id: 'analytics-aggregator-1a22', cp: { product: 'rabbitmq-amqp-java-client', version: '0.6.0', platform: 'Java 21' }, recv: 800, send: 7400, id: 'an-2' });
    var an2c = chan(an2, 1, { prefetch: 100, unacked: 50, del: 19.4 });
    cons(an2c, 'analytics', 'analytics.aggregator', { tag: 'attach-0' });

    // IoT: MQTT 5.0
    [1, 2, 3].forEach(function (i) {
      conn({ ip: '172.16.8.' + (100 + i), node: NODES[0], user: 'iot-gateway', vhost: '/', protocol: 'MQTT 5-0', cp: { client_id: 'iot-gateway-0' + i }, recv: 120, send: i === 1 ? 64 : 0, id: 'iot-' + i });
    });
    // legacy billing (python pika, TLS + x509)
    var lg = conn({ ip: '10.30.1.77', node: NODES[2], user: 'legacy-billing', vhost: '/', protocol: 'AMQP 0-9-1', tls: true, cp: { connection_name: 'legacy-billing', product: 'Pika Python Client Library', version: '1.3.2', platform: 'Python 3.11.9' }, recv: 820, send: 412, id: 'legacy-1' });
    chan(lg, 1, { pub: 2.4, publishes: [['/', 'app.logs']] });
    var lgc = chan(lg, 2, { prefetch: 10, unacked: 3, del: 2.4 });
    cons(lgc, '/', 'app.logs.archive');
    var cert = conn({ ip: '10.30.1.90', node: NODES[1], user: 'cert-client-01', vhost: '/', protocol: 'AMQP 0-9-1', tls: true, auth: 'EXTERNAL', peer_cert: 'CN=cert-client-01,OU=Billing,O=Example', cp: { connection_name: 'report-generator', product: 'RabbitMQ', version: '5.25.0', platform: 'Java' }, recv: 20, send: 0, id: 'cert-1' });
    chan(cert, 1, { state: 'idle' });

    // Report generator: stream tüketicisi (AMQP 0-9-1 üzerinden)
    var rg = conn({ ip: '10.20.35.61', node: NODES[2], user: 'order-service', vhost: 'orders', protocol: 'AMQP 0-9-1', cp: dotnetCp('order-audit-reader'), recv: 60, send: 5100, id: 'rg-1' });
    var rgc = chan(rg, 1, { prefetch: 500, unacked: 0, del: 14.6, ack: 14.6 });
    cons(rgc, 'orders', 'orders.audit', { args: { 'x-stream-offset': 'last' } });
    var rg2 = conn({ ip: '10.20.35.62', node: NODES[0], user: 'payment-service', vhost: 'payments', protocol: 'AMQP 0-9-1', cp: javaCp('ledger-projector'), recv: 50, send: 2100, id: 'rg-2' });
    var rg2c = chan(rg2, 1, { prefetch: 200, del: 6.1 });
    cons(rg2c, 'payments', 'payments.ledger', { args: { 'x-stream-offset': 'first' } });

    // Federation link (Direct 0-9-1)
    var fl = conn({ direct: true, client_name: 'Federation link (upstream: dc2-orders, policy: federate-orders)', node: NODES[0], user: 'federation-user', vhost: '/', protocol: 'Direct 0-9-1', cp: { connection_name: 'Federation link (upstream: dc2-orders, policy: federate-orders)', product: 'RabbitMQ Federation', version: '4.1.4', platform: 'Erlang/OTP 27.3.4.3' }, recv: 0, send: 0, id: 'fed-1' });
    chan(fl, 1, { confirm: true, pub: 0.9, publishes: [['/', 'federated.orders']] });
    // Shovel (Direct 0-9-1)
    var sh1 = conn({ direct: true, client_name: 'Shovel legacy-orders-migration', node: NODES[1], user: 'shovel-user', vhost: '/', protocol: 'Direct 0-9-1', cp: { connection_name: 'Shovel legacy-orders-migration', product: 'RabbitMQ Shovel', version: '4.1.4' }, id: 'sh-1' });
    var sh1c = chan(sh1, 1, { prefetch: 1000, unacked: 250, del: 9.5 });
    cons(sh1c, '/', 'legacy.orders', { tag: 'amq.ctag-shovel-legacy' });
    var sh2 = conn({ direct: true, client_name: 'Shovel legacy-orders-migration (dest)', node: NODES[1], user: 'shovel-user', vhost: 'orders', protocol: 'Direct 0-9-1', cp: { connection_name: 'Shovel legacy-orders-migration', product: 'RabbitMQ Shovel', version: '4.1.4' }, id: 'sh-2' });
    chan(sh2, 1, { confirm: true, pub: 9.5, publishes: [['orders', 'orders.events']] });
    // Blocked publisher örneği
    var bl = conn({ ip: '10.20.36.70', node: NODES[2], user: 'notification-service', vhost: 'notifications', protocol: 'AMQP 0-9-1', state: 'flow', cp: javaCp('bulk-mailer'), recv: 98000, send: 120, id: 'bulk-1' });
    chan(bl, 1, { pub: 30.5, state: 'flow', publishes: [['notifications', 'notifications.broadcast']] });

    /* ---------------- Policies ---------------- */
    S.policies = [
      { vhost: 'orders', name: 'orders-qq-defaults', pattern: '^orders\\.(created|paid|shipped|cancelled)$', apply_to: 'quorum_queues', priority: 10,
        definition: { 'dead-letter-exchange': 'orders.dlx', 'dead-letter-strategy': 'at-least-once', 'overflow': 'reject-publish', 'delivery-limit': 10 } },
      { vhost: 'orders', name: 'orders-retry-ttl', pattern: '^orders\\.retry$', apply_to: 'classic_queues', priority: 20,
        definition: { 'message-ttl': 30000, 'dead-letter-exchange': 'orders.events' } },
      { vhost: 'orders', name: 'audit-retention', pattern: '^orders\\.audit$', apply_to: 'streams', priority: 0,
        definition: { 'max-age': '30D', 'stream-max-segment-size-bytes': 52428800 } },
      { vhost: 'payments', name: 'payments-limits', pattern: '^payments\\.(process|refund)$', apply_to: 'queues', priority: 5,
        definition: { 'max-length': 100000, 'overflow': 'reject-publish', 'dead-letter-exchange': 'payments.dlx' } },
      { vhost: 'analytics', name: 'clickstream-retention', pattern: '^analytics\\.clickstream$', apply_to: 'streams', priority: 0,
        definition: { 'max-age': '7D', 'max-length-bytes': 53687091200 } },
      { vhost: '/', name: 'federate-orders', pattern: '^federated\\.', apply_to: 'exchanges', priority: 0,
        definition: { 'federation-upstream-set': 'all' } },
      { vhost: 'notifications', name: 'notif-expiry', pattern: '^notifications\\.temp$', apply_to: 'queues', priority: 0,
        definition: { 'expires': 3600000, 'max-length': 10000 } }
    ];
    S.operator_policies = [
      { vhost: 'notifications', name: 'op-safety-net', pattern: '.*', apply_to: 'queues', priority: 0,
        definition: { 'max-length-bytes': 2147483648, 'delivery-limit': 50 } },
      { vhost: '/', name: 'op-max-length', pattern: '.*', apply_to: 'queues', priority: 0,
        definition: { 'max-length': 1000000 } }
    ];

    /* ---------------- Limits ---------------- */
    S.vhost_limits = [
      { vhost: 'analytics', value: { 'max-connections': 200, 'max-queues': 50 } },
      { vhost: 'notifications', value: { 'max-queues': 200 } }
    ];
    S.user_limits = [
      { user: 'iot-gateway', value: { 'max-connections': 5000, 'max-channels': 1 } },
      { user: 'legacy-billing', value: { 'max-connections': 10, 'max-channels': 20 } }
    ];

    /* ---------------- Feature flags (4.1.x) ---------------- */
    function ff(name, state, stability, desc) { S.feature_flags.push({ name: name, state: state, stability: stability, provided_by: name.indexOf('mqtt') >= 0 ? 'rabbitmq_mqtt' : (name.indexOf('stream') === 0 && name !== 'stream_queue' ? 'rabbit' : 'rabbit'), desc: desc }); }
    ff('classic_mirrored_queue_version', 'enabled', 'required', 'Support setting version for classic mirrored queues');
    ff('classic_queue_type_delivery_support', 'enabled', 'required', 'Bug fix for classic queue deliveries using mixed versions');
    ff('direct_exchange_routing_v2', 'enabled', 'required', 'v2 direct exchange routing implementation');
    ff('drop_unroutable_metric', 'enabled', 'required', 'Count unroutable publishes to be dropped in stats');
    ff('empty_basic_get_metric', 'enabled', 'required', 'Count AMQP `basic.get` on empty queues in stats');
    ff('feature_flags_v2', 'enabled', 'required', 'Feature flags subsystem V2');
    ff('implicit_default_bindings', 'enabled', 'required', 'Default bindings are now implicit, instead of being stored in the database');
    ff('listener_records_in_ets', 'enabled', 'required', 'Store listener records in ETS instead of Mnesia');
    ff('maintenance_mode_status', 'enabled', 'required', 'Maintenance mode status');
    ff('quorum_queue', 'enabled', 'required', 'Support queues of type `quorum`');
    ff('stream_queue', 'enabled', 'required', 'Support queues of type `stream`');
    ff('stream_single_active_consumer', 'enabled', 'required', 'Single active consumer for streams');
    ff('stream_filtering', 'enabled', 'required', 'Support for stream filtering.');
    ff('tracking_records_in_ets', 'enabled', 'required', 'Store tracking records in ETS instead of Mnesia');
    ff('user_limits', 'enabled', 'required', 'Configure connection and channel limits for a user');
    ff('virtual_host_metadata', 'enabled', 'required', 'Virtual host metadata (description, tags, etc)');
    ff('message_containers', 'enabled', 'required', 'Support for message containers.');
    ff('restart_streams', 'enabled', 'required', 'Support for restarting streams with optional preferred next leader argument.');
    ff('stream_update_config_command', 'enabled', 'required', 'A new internal command that is used to update streams as part of a policy.');
    ff('message_containers_deaths_v2', 'enabled', 'stable', 'Bug fix for dead letter cycle detection');
    ff('quorum_queue_non_voters', 'enabled', 'stable', 'Allows new quorum queue members to be added as non voters initially.');
    ff('rabbitmq_4.0.0', 'enabled', 'stable', 'Allows rolling upgrades from 3.13.x to 4.0.x');
    ff('rabbitmq_4.1.0', 'enabled', 'stable', 'Allows rolling upgrades to 4.1.x');
    ff('stream_sac_coordinator_unblock_group', 'enabled', 'stable', 'Bug fix to unblock a group of consumers in a super stream partition');
    ff('rabbit_exchange_type_local_random', 'enabled', 'stable', 'Local random exchange');
    ff('mqtt_v5', 'enabled', 'stable', 'Support MQTT 5.0');
    ff('delete_ra_cluster_mqtt_node', 'enabled', 'stable', 'Delete Ra cluster mqtt_node since MQTT client IDs are tracked locally');
    ff('khepri_db', 'disabled', 'stable', 'New Raft-based metadata store (Khepri). Enabling it is irreversible.');

    /* ---------------- Deprecated features (4.1.x) ---------------- */
    S.deprecated_features = [
      { name: 'amqp_address_v1', phase: 'permitted_by_default', used: false, desc: 'AMQP 1.0 client sent a v1 address format. Use v2 address format (/exchanges/:exchange/:routing-key, /queues/:queue).' },
      { name: 'amqp_filter_set_bug', phase: 'permitted_by_default', used: false, desc: 'Compatibility with filter-set encoding bug of some AMQP 1.0 clients.' },
      { name: 'classic_queue_mirroring', phase: 'removed', used: false, desc: 'Classic mirrored queues were removed in RabbitMQ 4.0. Use quorum queues or streams for replication.' },
      { name: 'global_qos', phase: 'permitted_by_default', used: false, desc: 'Global QoS (basic.qos with global=true) on quorum queues is not supported and is deprecated.' },
      { name: 'management_metrics_collection', phase: 'permitted_by_default', used: false, desc: 'Metrics collection by the management plugin. Prometheus is the recommended alternative.' },
      { name: 'queue_master_locator', phase: 'permitted_by_default', used: false, desc: 'queue-master-locator is deprecated; use queue-leader-locator.' },
      { name: 'ram_node_type', phase: 'permitted_by_default', used: false, desc: 'RAM nodes are deprecated. Use disc nodes only.' },
      { name: 'transient_nonexcl_queues', phase: 'permitted_by_default', used: true, desc: 'Transient (non-durable) non-exclusive queues are deprecated; use durable or exclusive queues.' }
    ];

    /* ---------------- Federation ---------------- */
    S.fed_upstreams = [
      { vhost: '/', name: 'dc2-orders', uri: 'amqps://federation-user@dc2-mq.example.local:5671/%2F', prefetch_count: 1000, reconnect_delay: 5, ack_mode: 'on-confirm',
        trust_user_id: false, exchange: 'orders.events', max_hops: 1, expires: 3600000, message_ttl: null, queue: '', consumer_tag: '', bind_nowait: false, queue_type: 'classic' },
      { vhost: '/', name: 'dc3-orders', uri: 'amqps://federation-user@dc3-mq.example.local:5671/%2F', prefetch_count: 1000, reconnect_delay: 10, ack_mode: 'on-confirm',
        trust_user_id: false, exchange: 'orders.events', max_hops: 1, expires: 3600000, message_ttl: null, queue: '', consumer_tag: '', bind_nowait: false, queue_type: 'quorum' }
    ];
    S.fed_upstream_sets = [];
    S.fed_links = [
      { node: NODES[0], exchange: 'federated.orders', queue: null, upstream: 'dc2-orders', type: 'exchange', vhost: '/', status: 'running', local_connection: 'Federation link (upstream: dc2-orders, policy: federate-orders)', uri: 'amqps://dc2-mq.example.local:5671/%2F', last_changed: now - 3 * 86400000, error: '' },
      { node: NODES[0], exchange: 'federated.orders', queue: null, upstream: 'dc3-orders', type: 'exchange', vhost: '/', status: 'error', local_connection: '', uri: 'amqps://dc3-mq.example.local:5671/%2F', last_changed: now - 420000,
        error: '{auth_failure,"ACCESS_REFUSED - Login was refused using authentication mechanism PLAIN. For details see the broker logfile."}' }
    ];

    /* ---------------- Shovels ---------------- */
    S.shovels = [
      { vhost: '/', name: 'legacy-orders-migration', type: 'dynamic', state: 'running', node: NODES[1],
        src_protocol: 'amqp091', src_uri: 'amqp://shovel-user@/%2F', src_queue: 'legacy.orders', src_exchange: '', src_exchange_key: '', src_prefetch: 1000, src_delete_after: 'never',
        dest_protocol: 'amqp091', dest_uri: 'amqp://shovel-user@/orders', dest_queue: '', dest_exchange: 'orders.events', dest_exchange_key: 'order.created.legacy',
        ack_mode: 'on-confirm', add_forward_headers: true, reconnect_delay: 5, timestamp: now - 86400000 * 2, forwarded: 1880422, pending: 0 },
      { vhost: 'analytics', name: 'clickstream-to-dwh', type: 'dynamic', state: 'running', node: NODES[2],
        src_protocol: 'amqp10', src_uri: 'amqp://shovel-user@localhost', src_address: '/queues/analytics.aggregator', src_queue: '', src_prefetch: 500, src_delete_after: 'never',
        dest_protocol: 'amqp10', dest_uri: 'amqps://dwh-ingest:****@dwh-broker.example.local:5671', dest_address: '/exchanges/dwh.raw/clickstream', dest_queue: '', dest_exchange: '',
        ack_mode: 'on-publish', add_forward_headers: false, reconnect_delay: 5, timestamp: now - 86400000 * 9, forwarded: 9210331, pending: 12 },
      { vhost: 'payments', name: 'dlq-replay', type: 'dynamic', state: 'terminated', node: NODES[0],
        src_protocol: 'amqp091', src_uri: 'amqp://', src_queue: 'payments.dlq', src_exchange: '', src_prefetch: 100, src_delete_after: 'queue-length',
        dest_protocol: 'amqp091', dest_uri: 'amqp://', dest_queue: '', dest_exchange: 'payments.commands', dest_exchange_key: 'process',
        ack_mode: 'on-confirm', add_forward_headers: false, reconnect_delay: 5, timestamp: now - 3600000 * 5, forwarded: 214, pending: 0,
        reason: 'Shovel completed: src-delete-after=queue-length reached (214 messages)' },
      { vhost: '/', name: 'static-log-forwarder', type: 'static', state: 'starting', node: NODES[2],
        src_protocol: 'amqp091', src_uri: 'amqp://', src_queue: 'app.logs.archive', src_exchange: '', src_prefetch: 100, src_delete_after: 'never',
        dest_protocol: 'amqp091', dest_uri: 'amqps://logs.example.local', dest_queue: '', dest_exchange: 'central.logs', dest_exchange_key: '',
        ack_mode: 'on-confirm', add_forward_headers: false, reconnect_delay: 5, timestamp: now - 15000, forwarded: 0, pending: 0 }
    ];

    S.churn = { conn_created: 0.12, conn_closed: 0.10, ch_created: 0.35, ch_closed: 0.33, q_declared: 0.05, q_created: 0.01, q_deleted: 0.01 };

    S.ports = [
      { protocol: 'amqp', bound_to: '::', port: 5672 },
      { protocol: 'amqp/ssl', bound_to: '::', port: 5671 },
      { protocol: 'clustering', bound_to: '::', port: 25672 },
      { protocol: 'http', bound_to: '::', port: 15672 },
      { protocol: 'http/prometheus', bound_to: '::', port: 15692 },
      { protocol: 'mqtt', bound_to: '::', port: 1883 },
      { protocol: 'stream', bound_to: '::', port: 5552 }
    ];
    S.contexts = [
      { context: 'RabbitMQ Management', bound_to: '0.0.0.0', port: 15672, ssl: false, path: '/' },
      { context: 'RabbitMQ Prometheus', bound_to: '0.0.0.0', port: 15692, ssl: false, path: '/' }
    ];

    return S;
  }

  w.SEED = seed;
  w.SIM_NODES = NODES;
})(window);
