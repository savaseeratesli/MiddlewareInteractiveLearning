/* =========================================================================
   Uygulama çekirdeği: header, menü, yönlendirme (hash router), olaylar, yenileme
   ========================================================================= */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES;
  var App = w.App = {
    vhost: U.store.get('rmq-edu-vhost', ''),
    refresh: U.store.get('rmq-edu-refresh', 5),
    lastRefresh: new Date(),
    route: null
  };

  var LOGO = '<svg viewBox="0 0 32 32" aria-hidden="true"><path fill="#ff6600" d="M30 13.2h-8.6a1.2 1.2 0 0 1-1.2-1.2V3.2A1.2 1.2 0 0 0 19 2h-3.4a1.2 1.2 0 0 0-1.2 1.2v8.5c0 .7-.5 1.3-1.2 1.3H10c-.7 0-1.2-.6-1.2-1.3V3.2A1.2 1.2 0 0 0 7.6 2H3.2A1.2 1.2 0 0 0 2 3.2v25.6A1.2 1.2 0 0 0 3.2 30h26.6a1.2 1.2 0 0 0 1.2-1.2V14.4a1.2 1.2 0 0 0-1-1.2zm-5.3 9.9c0 .7-.6 1.3-1.3 1.3h-3c-.7 0-1.2-.6-1.2-1.3v-3c0-.7.5-1.3 1.2-1.3h3c.7 0 1.3.6 1.3 1.3z"/></svg>';

  /* ---------------- Rotalar ---------------- */
  var ROUTES = [
    [/^\/?$/, 'overview', function () { return P.overview(); }],
    [/^\/connections$/, 'connections', function () { return P.connections(); }],
    [/^\/connections\/([^/]+)$/, 'connections', function (m) { return P.connection(U.dec(m[1])); }],
    [/^\/channels$/, 'channels', function () { return P.channels(); }],
    [/^\/channels\/([^/]+)$/, 'channels', function (m) { return P.channel(U.dec(m[1])); }],
    [/^\/exchanges$/, 'exchanges', function () { return P.exchanges(); }],
    [/^\/exchanges\/([^/]+)\/([^/]+)$/, 'exchanges', function (m) { return P.exchange(U.dec(m[1]), U.dec(m[2])); }],
    [/^\/queues$/, 'queues', function () { return P.queues(); }],
    [/^\/queues\/([^/]+)\/([^/]+)$/, 'queues', function (m) { return P.queue(U.dec(m[1]), U.dec(m[2])); }],
    [/^\/admin$/, 'admin', function () { return P.users(); }],
    [/^\/users$/, 'admin', function () { return P.users(); }],
    [/^\/users\/([^/]+)$/, 'admin', function (m) { return P.userPage(U.dec(m[1])); }],
    [/^\/vhosts$/, 'admin', function () { return P.vhosts(); }],
    [/^\/vhosts\/([^/]+)$/, 'admin', function (m) { return P.vhostPage(U.dec(m[1])); }],
    [/^\/feature-flags$/, 'admin', function () { return P.featureFlags(); }],
    [/^\/deprecated-features$/, 'admin', function () { return P.deprecatedFeatures(); }],
    [/^\/policies$/, 'admin', function () { return P.policies(); }],
    [/^\/limits$/, 'admin', function () { return P.limits(); }],
    [/^\/cluster$/, 'admin', function () { return P.cluster(); }],
    [/^\/federation$/, 'admin', function () { return P.federation(); }],
    [/^\/federation-upstreams$/, 'admin', function () { return P.federationUpstreams(); }],
    [/^\/shovels$/, 'admin', function () { return P.shovels(); }],
    [/^\/dynamic-shovels$/, 'admin', function () { return P.dynamicShovels(); }],
    [/^\/nodes\/([^/]+)$/, 'overview', function (m) { return P.node(U.dec(m[1])); }],
    [/^\/monitoring$/, 'monitoring', function () { return P.monitoring(); }],
    [/^\/login$/, 'login', function () { return loginPage(); }]
  ];
  var TABS = [['overview', 'Overview', '#/'], ['connections', 'Connections', '#/connections'], ['channels', 'Channels', '#/channels'], ['exchanges', 'Exchanges', '#/exchanges'], ['queues', 'Queues and Streams', '#/queues'], ['admin', 'Admin', '#/admin'], ['monitoring', 'Monitoring', '#/monitoring', true]];
  var TITLES = { overview: 'Overview', connections: 'Connections', channels: 'Channels', exchanges: 'Exchanges', queues: 'Queues and Streams', admin: 'Admin', monitoring: 'Monitoring', login: 'Login' };

  function loggedOut() { try { return w.sessionStorage.getItem('rmq-edu-logout') === '1'; } catch (e) { return false; } }
  function setLoggedOut(v) { try { if (v) w.sessionStorage.setItem('rmq-edu-logout', '1'); else w.sessionStorage.removeItem('rmq-edu-logout'); } catch (e) { /* */ } }

  function loginPage() {
    return '<div class="loginbox"><div class="logo" style="margin-bottom:16px">' + LOGO + 'RabbitMQ<sup>TM</sup></div>' +
      '<div class="edu-note">Bu bir <b>eğitim simülasyonudur</b>. Gerçek Management UI\'da burada kullanıcı adı ve parola (veya OAuth 2.0 ile giriş) istenir. Simülasyonda kimlik bilgisi istenmez ve hiçbir bilgi gönderilmez. ' + UI.help('current-user') + '</div>' +
      '<form data-form="login"><table class="form">' + UI.formRow('Username', UI.select('user', SIM.S.users.filter(function (u) { return u.tags.length; }).map(function (u) { return [u.name, u.name + ' (' + u.tags.join(', ') + ')']; }), 'admin'), 'user-tags') +
      '</table><button type="submit">Login (simülasyon)</button></form></div>';
  }

  /* ---------------- Header / Banner / Menü ---------------- */
  function renderHeader() {
    var S = SIM.S;
    var vopts = [['', 'All']].concat(S.vhosts.map(function (v) { return [v.name, v.name]; }));
    document.getElementById('header').innerHTML =
      '<div class="logo-wrap"><a class="logo" href="#/" title="Overview">' + LOGO + 'RabbitMQ<sup>TM</sup></a>' +
      '<div class="ver-badges"><span class="badge-ver" title="RabbitMQ sürümü">RabbitMQ ' + esc(S.version) + '</span>' + UI.help('version') +
      '<span class="badge-ver" title="Erlang/OTP sürümü">Erlang ' + esc(S.erlang) + '</span>' + UI.help('erlang') +
      '<span class="badge-sim" data-help="sim-mode" title="Bu arayüz bir eğitim simülasyonudur">EĞİTİM SİMÜLASYONU</span></div></div>' +
      (loggedOut() ? '' : '<div class="hdr-right">' +
        '<div class="row">Refreshed <span id="refreshed">' + U.fmtDate(App.lastRefresh) + '</span> ' + UI.select('refresh', [[5, 'Refresh every 5 seconds'], [10, 'Refresh every 10 seconds'], [30, 'Refresh every 30 seconds'], [0, 'Do not refresh']], App.refresh, 'data-hdr="refresh"') + ' ' + UI.help('refresh') + '</div>' +
        '<div class="row">Virtual host ' + UI.select('vhost', vopts, App.vhost, 'data-hdr="vhost"') + ' ' + UI.help('vhost-select') + '</div>' +
        '<div class="row">Cluster <b>' + esc(S.cluster_name) + '</b> ' + UI.help('cluster-name') + '</div>' +
        '<div class="row">User <b>' + esc(S.current_user) + '</b> <button class="small" data-action="logout">Log out</button> ' + UI.help('current-user') + '</div>' +
        '</div>');
  }
  function renderBanner() {
    var used = SIM.deprecatedInUse(), alarms = SIM.alarms(), h = '';
    if (alarms.length) h += '<div class="deprecated" style="background:#b02a26">⚠ Resource alarm: ' + alarms.map(function (a) { return esc(a.type) + ' alarm on ' + esc(a.node); }).join(', ') + ' — publishers are blocked. <a href="#/cluster">[Cluster]</a> ' + UI.help('memory-alarm') + '</div>';
    if (used.length) h += '<div class="deprecated">⚠ Deprecated features are being used. <a href="#/deprecated-features">[Learn more]</a> ' + UI.help('deprecated-banner') + '</div>';
    var el = document.getElementById('banner');
    if (el.innerHTML !== h) el.innerHTML = h;
  }
  function renderMenu(tab) {
    document.getElementById('menu').innerHTML = loggedOut() ? '' : '<button type="button" class="menu-toggle" data-action="menu-toggle">☰ ' + esc(TITLES[tab] || 'Menu') + '</button><ul id="tabs">' + TABS.map(function (t) {
      return '<li' + (t[3] ? ' class="edu"' : '') + '><a href="' + t[2] + '"' + (t[0] === tab ? ' class="selected"' : '') + (t[3] ? ' title="Eğitim amaçlı ek sekme (gerçek UI\'da yoktur)"' : '') + '>' + t[1] + '</a></li>';
    }).join('') + '</ul>';
  }
  function renderFooter() {
    document.getElementById('footer').innerHTML = '<div>RabbitMQ Management UI <b>eğitim simülasyonu</b> · Gerçek bir broker\'a bağlanmaz · Veriler örnektir</div>' +
      '<div><a data-action="help-index">Rehber / Sözlük</a><a data-help="sim-mode">Bu site hakkında</a><a href="https://www.rabbitmq.com/docs" target="_blank" rel="noopener">RabbitMQ Docs</a><a data-action="theme">Tema: ' + (document.documentElement.getAttribute('data-theme') === 'light' ? 'Açık' : 'Koyu') + '</a><a data-action="reset-sim">Simülasyonu sıfırla</a></div>';
  }

  /* ---------------- Render ---------------- */
  App.render = function (keepScroll) {
    var y = w.scrollY;
    var hash = (location.hash || '#/').replace(/^#/, '');
    var path = hash.split('?')[0];
    if (loggedOut() && path !== '/login') { location.hash = '#/login'; return; }
    var html = null, tab = 'overview';
    for (var i = 0; i < ROUTES.length; i++) {
      var m = path.match(ROUTES[i][0]);
      if (m) { tab = ROUTES[i][1]; UI.clearBlocks(); try { html = ROUTES[i][2](m); } catch (e) { html = '<h1>Hata</h1><pre>' + esc(e.stack || e) + '</pre>'; if (w.console) console.error(e); } break; }
    }
    if (html === null) { UI.clearBlocks(); html = P.notFound('Sayfa', path); }
    App.route = path;
    renderHeader(); renderBanner(); renderMenu(tab); renderFooter();
    document.getElementById('main').innerHTML = html;
    document.title = 'RabbitMQ Management: ' + (TITLES[tab] || '');
    initForms();
    w.scrollTo(0, keepScroll ? y : 0);
  };

  function initForms() {
    var t = U.$('form[data-form="add-queue"] select[name=type]');
    if (t) updateQueueTypeHint(t);
  }
  function updateQueueTypeHint(sel) {
    var form = sel.closest('form');
    var vh = SIM.vhostObj(U.$('[name=vhost]', form).value);
    var type = sel.value === 'default' ? (vh ? vh.default_queue_type : 'classic') : sel.value;
    var hint = U.$('[data-qt-hint]', form);
    if (hint) hint.innerHTML = sel.value === 'default' ? 'Bu vhost için varsayılan: <b>' + esc(type) + '</b> ' + UI.help('vhost-default-qt') : '';
    U.$$('[data-only]', form).forEach(function (r) { r.style.display = r.getAttribute('data-only') === type ? '' : 'none'; });
  }

  App.tick = function () {
    SIM.tick();
    App.lastRefresh = new Date();
    var r = document.getElementById('refreshed'); if (r) r.textContent = U.fmtDate(App.lastRefresh);
    renderBanner();
    UI.refreshBlocks();
  };

  /* ---------------- Olaylar ---------------- */
  function onClick(e) {
    var t = e.target;
    var hl = t.closest('[data-help-link]');
    if (hl) { e.preventDefault(); UI.openHelp(hl.getAttribute('data-help-link')); return; }
    var hp = t.closest('[data-help]');
    if (hp && !t.closest('[data-action="chart-toggle"]')) { e.preventDefault(); e.stopPropagation(); UI.openHelp(hp.getAttribute('data-help')); return; }
    var srt = t.closest('th[data-tblsort]');
    if (srt) { UI.tableEvent(srt); return; }
    var a = t.closest('[data-action]');
    if (!a) return;
    var act = a.getAttribute('data-action'), d = a.dataset;
    switch (act) {
      case 'help-close': UI.closeHelp(); break;
      case 'help-back': UI.helpBack(); break;
      case 'help-index': UI.openHelp('__index'); break;
      case 'menu-toggle': U.$('#tabs').classList.toggle('open'); break;
      case 'toggle-sec':
        var sec = a.parentNode; sec.classList.toggle('closed');
        var prefs = U.store.get('rmq-edu-sec', {}); prefs[sec.getAttribute('data-sec')] = sec.classList.contains('closed'); U.store.set('rmq-edu-sec', prefs);
        break;
      case 'chart-toggle':
        var cs = UI.chartState[d.chart] = UI.chartState[d.chart] || {}; cs.hidden = cs.hidden || {};
        cs.hidden[d.series] = !cs.hidden[d.series]; UI.saveChartState(); UI.refreshBlockContaining(a); break;
      case 'chart-range':
        var st = UI.chartState[d.chart] = UI.chartState[d.chart] || {};
        UI.modal('Grafik zaman aralığı', UI.select('range', UI.RANGES.map(function (r) { return [r[0], r[1]]; }), st.range || 60) + ' ' + UI.help('chart-range'), function (root) {
          st.range = parseInt(U.$('select', root).value, 10); UI.saveChartState(); App.render(true);
        }, 'Uygula');
        break;
      case 'colsel': UI.columnSelector(d.tbl); break;
      case 'reset-stats':
        UI.confirm('Reset stats', (d.node ? '<b>' + esc(d.node) + '</b> node\'unun' : '<b>Tüm cluster\'ın</b>') + ' istatistik veritabanı sıfırlanacak. Mesajlar, kuyruklar ve bağlantılar etkilenmez. ' + UI.help('reset-stats'), function () {
          SIM.buildHistory(); UI.refreshBlocks(); UI.toast('İstatistikler sıfırlandı' + (d.node ? ' (' + esc(d.node) + ')' : ' (all nodes)') + '.');
        }, 'Reset');
        break;
      case 'arg-add':
        UI.kvAdd(a.closest('form'), d.kvname, d.key, d.val, d.type); break;
      case 'set-tag':
        var inp = U.$('input[name=tags]', a.closest('form'));
        if (!d.tag) inp.value = '';
        else { var tags = inp.value.split(',').map(function (s) { return s.trim(); }).filter(Boolean); if (tags.indexOf(d.tag) < 0) tags.push(d.tag); inp.value = tags.join(', '); }
        break;
      case 'unbind':
        if (SIM.removeBinding(d.vhost, d.src, d.dst, d.dtype, d.rk, d.args)) UI.toast('Binding kaldırıldı: <b>' + esc(d.src) + '</b> → <b>' + esc(d.dst) + '</b> (' + esc(d.rk || 'routing key yok') + ')');
        UI.refreshBlocks(); break;
      case 'clear-perm': SIM.clearPermission(d.user, d.vhost); UI.toast('İzin temizlendi: ' + esc(d.user) + ' @ ' + esc(d.vhost)); App.render(true); break;
      case 'clear-tperm': SIM.clearTopicPermission(d.user, d.vhost, d.ex); UI.toast('Topic izni temizlendi.'); App.render(true); break;
      case 'toggle-tracing': var on = SIM.toggleTracing(d.vhost); UI.toast('Tracing ' + (on ? '<b>açıldı</b> – amq.rabbitmq.trace exchange\'ine tüm mesajların kopyası yayınlanır (performans etkisi!)' : 'kapatıldı') + '.', on ? 'warn' : ''); App.render(true); break;
      case 'enable-ff':
        if (d.name === 'khepri_db') {
          UI.confirm('khepri_db etkinleştir', 'Khepri metadata deposunu etkinleştirmek <b>geri alınamaz</b>. Gerçek ortamda önce staging\'de test edin. ' + UI.help('khepri'), function () { SIM.enableFeatureFlag('khepri_db'); UI.toast('khepri_db etkinleştirildi (simülasyon). Metadata artık Raft tabanlı Khepri\'de.'); App.render(true); }, 'Enable');
        } else { var n = SIM.enableFeatureFlag(d.name); UI.toast(n + ' feature flag etkinleştirildi.', '', 'Feature flag\'ler etkinleştirildikten sonra devre dışı bırakılamaz.'); App.render(true); }
        break;
      case 'delete-policy':
        UI.confirm('Policy sil', '<b>' + esc(d.name) + '</b> silinsin mi? Eşleşen nesneler bir sonraki uygun policy\'ye (varsa) geçer.', function () { SIM.deletePolicy(d.vhost, d.name, !!d.op); UI.toast('Policy silindi: ' + esc(d.name)); App.render(true); }, 'Delete');
        break;
      case 'clear-limit': SIM.clearLimit(d.kind, d.who, d.key); UI.toast('Limit kaldırıldı.'); App.render(true); break;
      case 'sim-alarm':
        var nn = SIM.node(d.node), cur = !!nn['alarm_' + d.type];
        SIM.setAlarm(d.node, d.type, !cur); SIM.tick();
        UI.toast(cur ? 'Alarm kaldırıldı, publisher\'lar serbest bırakıldı.' : '<b>' + (d.type === 'mem' ? 'Memory' : 'Disk') + ' alarm</b> tetiklendi: tüm cluster\'da publisher bağlantıları bloklandı.', cur ? '' : 'err');
        App.render(true); break;
      case 'sim-node':
        var node = SIM.node(d.node);
        SIM.setNodeRunning(d.node, !node.running); SIM.tick();
        UI.toast(node.running ? esc(d.node) + ' yeniden başlatıldı.' : esc(d.node) + ' durduruldu. Classic kuyrukları down, quorum kuyruk leader\'ları taşındı.', node.running ? '' : 'warn');
        App.render(true); break;
      case 'delete-upstream': UI.confirm('Upstream sil', esc(d.name) + ' silinsin mi? İlgili federation link\'leri kapanır.', function () { SIM.deleteUpstream(d.vhost, d.name); UI.toast('Upstream silindi.'); App.render(true); }, 'Delete'); break;
      case 'restart-shovel': if (SIM.restartShovel(d.vhost, d.name)) { UI.toast('Shovel yeniden başlatılıyor: ' + esc(d.name)); UI.refreshBlocks(); } break;
      case 'delete-shovel': UI.confirm('Shovel sil', esc(d.name) + ' silinsin mi?', function () { SIM.deleteShovel(d.vhost, d.name); UI.toast('Shovel silindi.'); App.render(true); }, 'Delete'); break;
      case 'theme':
        var light = document.documentElement.getAttribute('data-theme') !== 'light';
        document.documentElement.setAttribute('data-theme', light ? 'light' : 'dark'); U.store.set('rmq-edu-theme', light ? 'light' : 'dark'); renderFooter(); UI.refreshBlocks(); break;
      case 'reset-sim':
        UI.confirm('Simülasyonu sıfırla', 'Yaptığınız tüm değişiklikler (eklenen kuyruklar, mesajlar, kullanıcılar, policy\'ler...) silinip başlangıç verilerine dönülecek.', function () {
          SIM.reset(); ['rmq-edu-sec', 'rmq-edu-charts'].forEach(U.store.del); UI.chartState = {}; App.render(); UI.toast('Simülasyon başlangıç durumuna döndürüldü.');
        }, 'Sıfırla');
        break;
      case 'logout': setLoggedOut(true); location.hash = '#/login'; break;
    }
  }

  function onInput(e) {
    var t = e.target;
    if (t.matches('[data-tblact="filter"]')) { UI.tableEvent(t); return; }
    if (t.matches('[data-help-search]')) {
      var body = document.getElementById('help-body'); var v = t.value;
      body.innerHTML = UI.helpIndexHtml(v);
      var s = U.$('[data-help-search]', body); s.focus(); s.setSelectionRange(v.length, v.length);
      return;
    }
    if (t.matches('.kv-k, .kv-v')) UI.kvEnsureEmptyRow(t.closest('.kv-rows'));
  }
  function onChange(e) {
    var t = e.target;
    if (t.matches('[data-tblact="regex"], [data-tblact="page"], [data-tblact="pagesize"]')) { UI.tableEvent(t); return; }
    if (t.matches('[data-hdr="refresh"]')) { App.refresh = parseInt(t.value, 10); U.store.set('rmq-edu-refresh', App.refresh); return; }
    if (t.matches('[data-hdr="vhost"]')) { App.vhost = t.value; U.store.set('rmq-edu-vhost', App.vhost); App.render(true); return; }
    if (t.matches('form[data-form="add-queue"] select[name=type], form[data-form="add-queue"] select[name=vhost]')) updateQueueTypeHint(U.$('select[name=type]', t.closest('form')));
  }
  function onKey(e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.help, [data-help-link]')) { e.preventDefault(); e.target.click(); }
    if (e.key === 'Escape') UI.closeHelp();
  }

  /* ---------------- Form gönderimleri ---------------- */
  function val(f, n) { var el = f.elements[n]; return el ? (el.type === 'checkbox' ? el.checked : el.value) : undefined; }
  function bool(f, n) { return val(f, n) === 'true' || val(f, n) === true; }

  var FORMS = {
    'add-exchange': function (f) {
      var o = { vhost: val(f, 'vhost'), name: val(f, 'name').trim(), type: val(f, 'type'), durable: bool(f, 'durable'), auto_delete: bool(f, 'auto_delete'), internal: bool(f, 'internal'), arguments: UI.kvRead(f, 'args') };
      var r = SIM.addExchange(o);
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast('Exchange <b>' + esc(o.name) + '</b> (' + esc(o.type) + ') oluşturuldu.', '', 'HTTP API karşılığı: PUT /api/exchanges/' + U.enc(o.vhost) + '/' + U.enc(o.name) + ' — simülasyon, gerçek istek gönderilmedi.');
      App.render(true);
    },
    'add-queue': function (f) {
      var o = { vhost: val(f, 'vhost'), name: val(f, 'name').trim(), type: val(f, 'type'), durable: bool(f, 'durable'), auto_delete: bool(f, 'auto_delete'), node: val(f, 'node'), arguments: UI.kvRead(f, 'qargs') };
      var r = SIM.addQueue(o);
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      var warn = !o.durable && r.type === 'classic' ? ' <b>Uyarı:</b> transient (non-durable) non-exclusive kuyruklar 4.x\'te deprecated\'dır.' : '';
      UI.toast('Queue <b>' + esc(o.name) + '</b> (' + esc(r.type) + ') oluşturuldu.' + warn, warn ? 'warn' : '', 'HTTP API karşılığı: PUT /api/queues/' + U.enc(o.vhost) + '/' + U.enc(o.name) + ' — simülasyon, gerçek istek gönderilmedi.');
      App.render(true);
    },
    'add-binding': function (f) {
      var dir = f.dataset.dir, vhost = f.dataset.vhost, name = f.dataset.name, target = val(f, 'target').trim();
      if (!target) return UI.formMsg(f, 'Hedef/kaynak adı zorunludur.', 'err');
      var o = dir === 'from' ? { vhost: vhost, source: name, destination: target, destination_type: val(f, 'dtype'), routing_key: val(f, 'rk'), arguments: UI.kvRead(f, 'bargs') }
        : { vhost: vhost, source: target, destination: name, destination_type: 'queue', routing_key: val(f, 'rk'), arguments: UI.kvRead(f, 'bargs') };
      var r = SIM.addBinding(o);
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast('Binding eklendi: <b>' + esc(o.source) + '</b> → <b>' + esc(o.destination) + '</b>' + (o.routing_key ? ' (routing key: ' + esc(o.routing_key) + ')' : ''));
      App.render(true);
    },
    'publish': function (f) {
      var props = { delivery_mode: parseInt(val(f, 'delivery_mode'), 10), content_type: val(f, 'content_type') };
      ['priority', 'expiration', 'message_id', 'correlation_id'].forEach(function (k) { var v = val(f, k); if (v) props[k] = k === 'priority' ? parseInt(v, 10) : v; });
      var res = SIM.publish(f.dataset.vhost, f.dataset.ex, val(f, 'rk'), props, UI.kvRead(f, 'headers'), val(f, 'payload'), val(f, 'mandatory'));
      U.$('.publish-result', f).innerHTML = P.renderPublishResult(res, f.dataset.vhost, f.dataset.ex);
      UI.refreshBlocks();
    },
    'get-messages': function (f) {
      var res = SIM.getMessages(f.dataset.vhost, f.dataset.name, parseInt(val(f, 'count'), 10), val(f, 'ackmode'));
      U.$('.get-result', f).innerHTML = P.renderMessages(res, val(f, 'encoding'));
      UI.refreshBlocks();
    },
    'move-messages': function (f) {
      var r = SIM.moveMessages(f.dataset.vhost, f.dataset.name, val(f, 'dest').trim());
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast(U.fmtNum(r.moved) + ' mesaj taşındı → ' + esc(val(f, 'dest')) + '. (Geçici shovel "Move from ' + esc(f.dataset.name) + '" oluşturuldu ve tamamlandı.)');
      App.render(true);
    },
    'delete-queue': function (f) {
      var v = f.dataset.vhost, n = f.dataset.name;
      UI.confirm('Queue sil', '<b>' + esc(n) + '</b> kuyruğu, içindeki tüm mesajlar ve binding\'lerle birlikte silinecek. Emin misiniz?', function () {
        var r = SIM.deleteQueue(v, n, { ifUnused: val(f, 'if_unused'), ifEmpty: val(f, 'if_empty') });
        if (r.error) { UI.toast(esc(r.error), 'err'); return; }
        UI.toast('Queue <b>' + esc(n) + '</b> silindi (' + U.fmtNum(r.messages) + ' mesaj, ' + r.consumers + ' consumer iptal edildi).');
        location.hash = '#/queues';
      }, 'Delete');
    },
    'purge-queue': function (f) {
      var v = f.dataset.vhost, n = f.dataset.name;
      UI.confirm('Purge', '<b>' + esc(n) + '</b> kuyruğundaki tüm ready mesajlar kalıcı olarak silinecek (dead-letter edilmez).', function () {
        var c = SIM.purge(v, n); SIM.tick();
        UI.toast('Queue <b>' + esc(n) + '</b>: ' + U.fmtNum(c) + ' mesaj purge edildi.');
        App.render(true);
      }, 'Purge');
    },
    'delete-exchange': function (f) {
      var v = f.dataset.vhost, n = f.dataset.name;
      UI.confirm('Exchange sil', '<b>' + esc(n) + '</b> exchange\'i ve tüm binding\'leri silinecek.', function () {
        var r = SIM.deleteExchange(v, n, val(f, 'if_unused'));
        if (r.error) { UI.toast(esc(r.error), 'err'); return; }
        UI.toast('Exchange <b>' + esc(n) + '</b> silindi (' + r.bindings + ' binding kaldırıldı).');
        location.hash = '#/exchanges';
      }, 'Delete');
    },
    'close-conn': function (f) {
      var n = f.dataset.name, reason = val(f, 'reason');
      UI.confirm('Force Close', 'Bağlantı kapatılacak ve istemciye şu gerekçe iletilecek:<br><code>CONNECTION_FORCED - ' + esc(reason) + '</code>', function () {
        var r = SIM.closeConnection(n);
        UI.toast('Bağlantı kapatıldı. ' + r.channels + ' kanal kapandı' + (r.removedQueues.length ? '; exclusive/auto-delete kuyruklar silindi: ' + r.removedQueues.map(esc).join(', ') : '') + '. Unacked mesajlar kuyruğa geri döndü.');
        location.hash = '#/connections';
      }, 'Force Close');
    },
    'add-user': function (f) {
      var name = val(f, 'name').trim(), nopw = val(f, 'pwmode') === 'nopassword';
      if (!nopw && val(f, 'password') !== val(f, 'password2')) return UI.formMsg(f, 'Parolalar eşleşmiyor.', 'err');
      var tags = val(f, 'tags').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      var r = SIM.addUser({ name: name, tags: tags, has_password: !nopw && !!val(f, 'password') });
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast('Kullanıcı <b>' + esc(name) + '</b> oluşturuldu. Henüz hiçbir vhost\'a izni yok – kullanıcı sayfasından izin verin.', '', 'Parola hiçbir yere gönderilmedi veya kaydedilmedi.');
      location.hash = '#/users/' + U.enc(name);
    },
    'update-user': function (f) {
      SIM.setUserTags(f.dataset.name, val(f, 'tags').split(',').map(function (s) { return s.trim(); }).filter(Boolean));
      UI.toast('Kullanıcı güncellendi: ' + esc(f.dataset.name)); App.render(true);
    },
    'delete-user': function (f) {
      var n = f.dataset.name;
      if (n === SIM.S.current_user) return UI.formMsg(f, 'Oturum açmış olduğunuz kullanıcıyı silemezsiniz.', 'err');
      UI.confirm('Kullanıcı sil', '<b>' + esc(n) + '</b> silinecek ve açık bağlantıları kapatılacak.', function () { var r = SIM.deleteUser(n); UI.toast('Kullanıcı silindi. ' + r.closed + ' bağlantı kapatıldı.'); location.hash = '#/users'; }, 'Delete');
    },
    'set-perm': function (f) {
      var o = { user: val(f, 'user'), vhost: val(f, 'vhost'), configure: val(f, 'configure'), write: val(f, 'write'), read: val(f, 'read') };
      try { new RegExp(o.configure); new RegExp(o.write); new RegExp(o.read); } catch (e) { return UI.formMsg(f, 'Geçersiz regex: ' + esc(e.message), 'err'); }
      SIM.setPermission(o); UI.toast('İzin ayarlandı: <b>' + esc(o.user) + '</b> @ ' + esc(o.vhost)); App.render(true);
    },
    'set-tperm': function (f) {
      SIM.setTopicPermission({ user: val(f, 'user'), vhost: val(f, 'vhost'), exchange: val(f, 'exchange'), write: val(f, 'write'), read: val(f, 'read') });
      UI.toast('Topic izni ayarlandı.'); App.render(true);
    },
    'add-vhost': function (f) {
      var o = { name: val(f, 'name').trim(), description: val(f, 'description'), tags: val(f, 'tags').split(',').map(function (s) { return s.trim(); }).filter(Boolean), default_queue_type: val(f, 'dqt') };
      var r = SIM.addVhost(o);
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast('Virtual host <b>' + esc(o.name) + '</b> oluşturuldu. Varsayılan exchange\'ler eklendi ve <b>' + esc(SIM.S.current_user) + '</b> kullanıcısına tam yetki verildi.');
      App.render(true);
    },
    'delete-vhost': function (f) {
      var n = f.dataset.name;
      UI.confirm('Vhost sil', '<b>' + esc(n) + '</b> ve içindeki her şey silinecek. Geri alınamaz!', function () { var r = SIM.deleteVhost(n); if (App.vhost === n) { App.vhost = ''; U.store.set('rmq-edu-vhost', ''); } UI.toast('Vhost silindi. ' + r.connections + ' bağlantı kapatıldı.'); location.hash = '#/vhosts'; }, 'Delete');
    },
    'set-policy': function (f) {
      var op = !!f.dataset.op;
      var o = { vhost: val(f, 'vhost'), name: val(f, 'name').trim(), pattern: val(f, 'pattern'), apply_to: val(f, 'apply_to'), priority: parseInt(val(f, 'priority'), 10) || 0, definition: UI.kvRead(f, op ? 'opdef' : 'pdef') };
      if (!o.name || !o.pattern) return UI.formMsg(f, 'Name ve Pattern zorunludur.', 'err');
      try { new RegExp(o.pattern); } catch (e) { return UI.formMsg(f, 'Geçersiz regex: ' + esc(e.message), 'err'); }
      if (!Object.keys(o.definition).length) return UI.formMsg(f, 'Definition en az bir anahtar içermelidir.', 'err');
      var bad = Object.keys(o.definition).filter(function (k) { return /^ha-|^queue-mode$|^queue-master-locator$/.test(k); });
      if (bad.length) return UI.formMsg(f, 'Bu anahtarlar RabbitMQ 4.x\'te geçersiz/kaldırılmış: <code>' + bad.map(esc).join(', ') + '</code>. ' + UI.help('ha'), 'err');
      SIM.setPolicy(o, op);
      var n = SIM.S.queues.filter(function (q) { return (op ? SIM.opPolicyFor('queue', q) : SIM.policyFor('queue', q)) === o; }).length + SIM.S.exchanges.filter(function (e) { return !op && SIM.policyFor('exchange', e) === o; }).length;
      UI.toast((op ? 'Operator policy' : 'Policy') + ' <b>' + esc(o.name) + '</b> kaydedildi – şu anda ' + n + ' nesneye uygulanıyor.');
      App.render(true);
    },
    'set-limit': function (f) {
      SIM.setLimit(f.dataset.kind, val(f, 'who'), val(f, 'key'), parseInt(val(f, 'value'), 10));
      UI.toast('Limit ayarlandı: ' + esc(val(f, 'who')) + ' → ' + esc(val(f, 'key')) + ' = ' + esc(val(f, 'value'))); App.render(true);
    },
    'cluster-name': function (f) { var n = val(f, 'name').trim(); if (!n) return; SIM.setClusterName(n); UI.toast('Cluster adı güncellendi: <b>' + esc(n) + '</b>'); App.render(true); },
    'add-upstream': function (f) {
      var o = { vhost: val(f, 'vhost'), name: val(f, 'name').trim(), uri: val(f, 'uri').trim(), prefetch_count: parseInt(val(f, 'prefetch'), 10) || 1000, reconnect_delay: parseInt(val(f, 'reconnect'), 10) || 5, ack_mode: val(f, 'ack_mode'), trust_user_id: bool(f, 'trust'), exchange: val(f, 'exchange'), max_hops: parseInt(val(f, 'max_hops'), 10) || 1, expires: parseInt(val(f, 'expires'), 10) || null, message_ttl: parseInt(val(f, 'ttl'), 10) || null, queue: val(f, 'queue'), consumer_tag: val(f, 'ctag'), queue_type: val(f, 'queue_type') };
      if (!o.name || !o.uri) return UI.formMsg(f, 'Name ve URI zorunludur.', 'err');
      if (!/^amqps?:\/\//.test(o.uri)) return UI.formMsg(f, 'URI amqp:// veya amqps:// ile başlamalıdır.', 'err');
      o.uri = o.uri.replace(/\/\/([^:@/]+):[^@/]+@/, '//$1:****@');
      SIM.addUpstream(o); UI.toast('Upstream <b>' + esc(o.name) + '</b> eklendi. Kullanılması için bir policy ile (federation-upstream / federation-upstream-set) exchange veya kuyruklara bağlanmalıdır.'); App.render(true);
    },
    'add-shovel': function (f) {
      var o = { vhost: val(f, 'vhost'), name: val(f, 'name').trim(), src_protocol: val(f, 'src_protocol'), src_uri: val(f, 'src_uri'), src_queue: val(f, 'src_kind') === 'queue' ? val(f, 'src_name') : '', src_exchange: val(f, 'src_kind') === 'exchange' ? val(f, 'src_name') : '', src_exchange_key: val(f, 'src_key'), src_prefetch: parseInt(val(f, 'prefetch'), 10) || 1000, src_delete_after: val(f, 'delete_after'),
        dest_protocol: val(f, 'dest_protocol'), dest_uri: val(f, 'dest_uri'), dest_queue: val(f, 'dest_kind') === 'queue' ? val(f, 'dest_name') : '', dest_exchange: val(f, 'dest_kind') === 'exchange' ? val(f, 'dest_name') : '', dest_exchange_key: val(f, 'dest_key'), add_forward_headers: bool(f, 'fwd'), reconnect_delay: parseInt(val(f, 'reconnect'), 10) || 5, ack_mode: val(f, 'ack_mode') };
      if (!o.name || !val(f, 'src_name') || !val(f, 'dest_name')) return UI.formMsg(f, 'Name, kaynak ve hedef zorunludur.', 'err');
      o.src_uri = o.src_uri.replace(/\/\/([^:@/]+):[^@/]+@/, '//$1:****@'); o.dest_uri = o.dest_uri.replace(/\/\/([^:@/]+):[^@/]+@/, '//$1:****@');
      var r = SIM.addShovel(o);
      if (r.error) return UI.formMsg(f, esc(r.error), 'err');
      UI.toast('Shovel <b>' + esc(o.name) + '</b> oluşturuldu (state: starting → running). Shovel Status sayfasından izleyebilirsiniz.'); App.render(true);
    },
    'export-defs': function (f) {
      var json = P.definitions(val(f, 'vhost'));
      try {
        var blob = new Blob([json], { type: 'application/json' }), a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = val(f, 'filename') || 'definitions.json'; document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        UI.toast('Definitions dosyası indirildi (simüle edilen topoloji).', '', 'Gerçek karşılığı: GET /api/definitions veya rabbitmqctl export_definitions');
      } catch (e) { UI.modal('Definitions', '<pre class="json">' + esc(json) + '</pre>'); }
    },
    'import-defs': function (f) {
      var file = f.elements.file.files[0];
      if (!file) return UI.formMsg(f, 'Bir JSON dosyası seçin.', 'err');
      var rd = new FileReader();
      rd.onload = function () {
        try {
          var d = JSON.parse(rd.result);
          var parts = ['users', 'vhosts', 'permissions', 'policies', 'queues', 'exchanges', 'bindings', 'parameters'].filter(function (k) { return Array.isArray(d[k]); }).map(function (k) { return k + ': ' + d[k].length; });
          UI.formMsg(f, '<b>Dosya geçerli.</b> İçerik: ' + esc(parts.join(', ') || '(tanınan alan yok)') + '<br>Simülasyonda içe aktarma topolojiyi değiştirmez; gerçek ortamda nesneler oluşturulur/güncellenirdi.', '');
        } catch (e) { UI.formMsg(f, 'Geçersiz JSON: ' + esc(e.message), 'err'); }
      };
      rd.readAsText(file);
    },
    'login': function (f) { SIM.S.current_user = val(f, 'user'); SIM.save(); setLoggedOut(false); location.hash = '#/'; }
  };

  function onSubmit(e) {
    var f = e.target.closest('form[data-form]');
    if (!f) return;
    e.preventDefault();
    var h = FORMS[f.getAttribute('data-form')];
    if (h) h(f);
  }

  /* ---------------- Başlatma ---------------- */
  App.start = function () {
    var theme = U.store.get('rmq-edu-theme', 'dark');
    document.documentElement.setAttribute('data-theme', theme);
    SIM.init();
    document.addEventListener('click', onClick);
    document.addEventListener('input', onInput);
    document.addEventListener('change', onChange);
    document.addEventListener('submit', onSubmit);
    document.addEventListener('keydown', onKey);
    w.addEventListener('hashchange', function () { App.render(); });
    App.render();
    var last = Date.now();
    setInterval(function () {
      if (!App.refresh || document.hidden) return;
      if (Date.now() - last >= App.refresh * 1000) { last = Date.now(); App.tick(); }
    }, 500);
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.start); else App.start();
})(window);
