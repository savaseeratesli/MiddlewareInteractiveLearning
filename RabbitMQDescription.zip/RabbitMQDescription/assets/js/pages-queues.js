/* Queues and Streams listesi / detay */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};
  function vf(x) { return SIM.vhostOk(x.vhost); }

  P.qFeatures = function (q) {
    var f = [];
    if (q.durable) f.push('<abbr class="feat" title="durable: true" data-help="q-durable">D</abbr>');
    if (q.auto_delete) f.push('<abbr class="feat" title="auto-delete: true" data-help="q-auto-delete">AD</abbr>');
    if (q.exclusive) f.push('<abbr class="feat" title="exclusive: true" data-help="q-exclusive">Excl</abbr>');
    var a = Object.keys(q.arguments || {}).filter(function (k) { return k !== 'x-queue-type'; });
    if (a.length) f.push('<abbr class="feat" title="' + esc(a.map(function (k) { return k + ': ' + JSON.stringify(q.arguments[k]); }).join('\n')) + '" data-help="q-args">Args</abbr>');
    var p = SIM.policyFor('queue', q), op = SIM.opPolicyFor('queue', q);
    if (p) f.push('<abbr class="feat pol" title="Policy: ' + esc(p.name) + '" data-help="policy">' + esc(p.name) + '</abbr>');
    if (op) f.push('<abbr class="feat opol" title="Operator policy: ' + esc(op.name) + '" data-help="operator-policy">' + esc(op.name) + '</abbr>');
    return f.join('');
  };
  P.qType = function (q) {
    return '<abbr class="feat type-' + q.type + '" data-help="queue-type-' + q.type + '" title="' + q.type + ' queue">' + q.type + '</abbr>';
  };
  function rate(v, base) { return base ? U.fmtRate(v || 0) : ''; }

  P.queues = function () {
    var h = ['<h1>Queues and Streams ' + UI.help('queue') + '</h1>'];
    h.push(UI.section('All queues (' + SIM.S.queues.filter(vf).length + ')', UI.listTable({
      id: 'queues', rows: function () { return SIM.S.queues.filter(vf); },
      cols: [
        { key: 'vhost', label: 'Virtual host', group: 'Overview', help: 'vhost' },
        { key: 'name', label: 'Name', group: 'Overview', help: 'q-name', fixed: true, render: function (q) { return UI.qLink(q.vhost, q.name); } },
        { key: 'type', label: 'Type', group: 'Overview', help: 'q-type', render: P.qType },
        { key: 'features', label: 'Features', group: 'Overview', help: 'q-features', nosort: true, render: P.qFeatures },
        { key: 'state', label: 'State', group: 'Overview', help: 'q-state', render: function (q) { return UI.state(q.state === 'running' && !q.l_pub && !q.l_del && q.type === 'classic' ? 'idle' : q.state); } },
        { key: 'node', label: 'Node / Leader', group: 'Overview', hidden: true, help: 'q-members' },
        { key: 'consumers', label: 'Consumers', group: 'Overview', hidden: true, help: 'q-consumers', cls: 'r', sort: function (q) { return SIM.consumersOf(q.vhost, q.name).length; }, render: function (q) { return SIM.consumersOf(q.vhost, q.name).length; } },
        { key: 'ready', label: 'Ready', group: 'Messages', help: 'q-ready', cls: 'r', render: function (q) { return U.fmtNum(q.ready); } },
        { key: 'unacked', label: 'Unacked', group: 'Messages', help: 'q-unacked', cls: 'r', render: function (q) { return U.fmtNum(q.unacked); } },
        { key: 'total', label: 'Total', group: 'Messages', help: 'q-total', cls: 'r', sort: function (q) { return q.ready + q.unacked; }, render: function (q) { return U.fmtNum(q.ready + q.unacked); } },
        { key: 'memory', label: 'Memory', group: 'Messages', hidden: true, help: 'q-memory', cls: 'r', sort: function (q) { return q.l_mem; }, render: function (q) { return U.fmtBytes(q.l_mem || q.memory); } },
        { key: 'in', label: 'incoming', group: 'Message rates', help: 'q-rate-in', cls: 'r', sort: function (q) { return q.l_pub; }, render: function (q) { return rate(q.l_pub, q.r_pub); } },
        { key: 'del', label: 'deliver / get', group: 'Message rates', help: 'q-rate-deliver', cls: 'r', sort: function (q) { return q.l_del; }, render: function (q) { return rate(q.l_del, q.r_del); } },
        { key: 'ack', label: 'ack', group: 'Message rates', help: 'q-rate-ack', cls: 'r', sort: function (q) { return q.l_ack; }, render: function (q) { return rate(q.l_ack, q.r_del); } },
        { key: 'redel', label: 'redelivered', group: 'Message rates', hidden: true, help: 'rate-redelivered', cls: 'r', render: function (q) { return rate(q.l_redel, q.r_redeliver); } }
      ]
    }), { id: 'q-all' }));
    h.push(UI.section('Add a new queue', addQueueForm(), { id: 'q-add', closed: true }));
    h.push('<div class="edu-note"><b>Kuyruk tipleri:</b> <span class="feat type-classic">classic</span> tek node, replikasyonsuz ' + UI.help('queue-type-classic') + ' · <span class="feat type-quorum">quorum</span> Raft ile replike, veri güvenliği ' + UI.help('queue-type-quorum') + ' · <span class="feat type-stream">stream</span> silinmeyen log, replay ' + UI.help('queue-type-stream') + '</div>');
    return h.join('');
  };

  function addQueueForm() {
    var nodes = SIM.S.nodes.map(function (n) { return n.name; });
    return '<form data-form="add-queue"><table class="form">' +
      UI.formRow('Virtual host', UI.vhostSelect('vhost'), 'vhost') +
      UI.formRow('Type', UI.select('type', [['default', 'Default for virtual host'], ['classic', 'Classic'], ['quorum', 'Quorum'], ['stream', 'Stream']], 'default'), 'q-type', false, '<span data-qt-hint></span>') +
      UI.formRow('Name', '<input type="text" name="name" placeholder="ör. orders.created">', 'q-name', true) +
      UI.formRow('Durability', UI.select('durable', [['true', 'Durable'], ['false', 'Transient']], 'true'), 'q-durable') +
      '<tr data-only="classic"><th><label>Node:</label>' + UI.help('q-node') + '</th><td>' + UI.select('node', nodes, nodes[0]) + '</td></tr>' +
      UI.formRow('Auto delete', UI.select('auto_delete', [['false', 'No'], ['true', 'Yes']], 'false'), 'q-auto-delete') +
      UI.formRow('Arguments', UI.kvEditor('qargs') + UI.argLinks('qargs', [
        ['Add (tüm tipler)', [['x-expires', '86400000', 'number', 'x-expires', 'Auto expire'], ['x-message-ttl', '60000', 'number', 'x-message-ttl', 'Message TTL'], ['x-overflow', 'reject-publish', 'string', 'x-overflow', 'Overflow behaviour'], ['x-single-active-consumer', 'true', 'boolean', 'x-single-active-consumer', 'Single active consumer'], ['x-dead-letter-exchange', '', 'string', 'x-dead-letter-exchange', 'Dead letter exchange'], ['x-dead-letter-routing-key', '', 'string', 'x-dead-letter-routing-key', 'Dead letter routing key'], ['x-max-length', '100000', 'number', 'x-max-length', 'Max length'], ['x-max-length-bytes', '1073741824', 'number', 'x-max-length-bytes', 'Max length bytes'], ['x-queue-leader-locator', 'balanced', 'string', 'x-queue-leader-locator', 'Leader locator']]],
        ['Classic', [['x-max-priority', '10', 'number', 'x-max-priority', 'Maximum priority']]],
        ['Quorum', [['x-delivery-limit', '20', 'number', 'x-delivery-limit', 'Delivery limit'], ['x-quorum-initial-group-size', '3', 'number', 'x-quorum-initial-group-size', 'Initial cluster size'], ['x-dead-letter-strategy', 'at-least-once', 'string', 'x-dead-letter-strategy', 'Dead letter strategy']]],
        ['Stream', [['x-max-age', '7D', 'string', 'x-max-age', 'Max time retention'], ['x-stream-max-segment-size-bytes', '52428800', 'number', 'x-stream-max-segment-size-bytes', 'Max segment size in bytes'], ['x-stream-filter-size-bytes', '16', 'number', 'x-stream-filter-size-bytes', 'Filter size (per chunk) in bytes'], ['x-initial-cluster-size', '3', 'number', 'x-quorum-initial-group-size', 'Initial cluster size']]]
      ]), 'q-args') +
      '</table><button type="submit">Add queue</button></form>';
  }

  /* ---------------- Queue detay ---------------- */
  P.queue = function (vhost, name) {
    var q = SIM.queue(vhost, name);
    if (!q) return P.notFound('Queue', name);
    var key = SIM.qkey(vhost, name);
    var isStream = q.type === 'stream';
    var h = ['<h1>' + (isStream ? 'Stream' : 'Queue') + ' <b>' + esc(name) + '</b> <span class="sub">in virtual host ' + esc(vhost) + '</span> ' + UI.help('queue-type-' + q.type) + '</h1>'];

    var store = function () { return SIM.hist.q[key] || { ready: [0], unacked: [0], total: [0] }; };
    var ov = P.queuedChart('q-queued', store, 'Queued messages', 'queued-messages') +
      UI.chart({
        id: 'q-rates', title: 'Message rates', help: 'message-rates', unit: 'rate', legendCols: 2,
        get: function (range) {
          var e = store();
          function s(k, label, color, hk) { var a = e[k] || [0]; return { key: k, label: label, color: color, data: SIM.slice(a, range), value: U.fmtRate(a[a.length - 1]), help: hk }; }
          return { times: SIM.slice(SIM.hist.t, range), series: [
            s('publish', 'Publish', Charts.COLORS.publish, 'q-rate-in'), s('deliver', 'Deliver<br>(manual ack)', Charts.COLORS.deliver_manual, 'q-rate-deliver'),
            s('ack', 'Consumer<br>ack', Charts.COLORS.ack, 'q-rate-ack'), s('redeliver', 'Redelivered', Charts.COLORS.redeliver, 'rate-redelivered')
          ] };
        }
      }) + UI.h3('Details') + UI.block(function () { return queueDetails(q); });
    h.push(UI.section('Overview', ov, { id: 'q-ov' }));

    var cons = SIM.consumersOf(vhost, name);
    h.push(UI.section('Consumers (' + cons.length + ')', cons.length ? P.consumerTable(cons, 'queue') + (q.sac ? '<p class="muted small">Bu kuyrukta Single Active Consumer açık: yalnızca <b>single_active</b> durumundaki consumer mesaj alır ' + UI.help('x-single-active-consumer') + '</p>' : '') : '<p class="muted">... no consumers ...</p>' + (q.ready > 0 ? '<div class="form-msg warn">Bu kuyrukta mesaj birikiyor ama hiç consumer yok. Gerçek bir ortamda bu genellikle tüketici servisin çalışmadığını gösterir.</div>' : ''), { id: 'q-cons', help: 'consumer', closed: !cons.length }));

    h.push(UI.section('Bindings', UI.block(function () { return queueBindings(q); }) + P.addBindingForm(vhost, name, 'to'), { id: 'q-bind', help: 'bindings-section' }));
    h.push(UI.section('Publish message', '<p class="muted small">Buradan yayınlanan mesaj <b>default exchange</b> üzerinden, routing key = kuyruk adı olacak şekilde gönderilir ' + UI.help('ex-default') + '</p>' + P.publishForm(vhost, '', { internal: false, type: 'direct' }).replace('name="rk" placeholder="kuyruk adı"', 'name="rk" value="' + esc(name) + '" readonly'), { id: 'q-pub', closed: true, help: 'publish-message' }));
    h.push(UI.section('Get messages', isStream ? '<div class="form-msg warn">Stream\'ler basic.get ile okunamaz. Stream\'ler bir consumer ile, <code>x-stream-offset</code> argümanı ve prefetch ayarlanarak okunur ' + UI.help('x-stream-offset') + '</div>' :
      '<p class="warn-text small">Uyarı: Ack mode "Automatic ack" veya "Reject requeue false" seçilirse mesajlar kuyruktan kalıcı olarak çıkarılır (simülasyonda).</p>' +
      '<form data-form="get-messages" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><table class="form">' +
      UI.formRow('Ack Mode', UI.select('ackmode', [['ack_requeue_true', 'Nack message requeue true'], ['ack_requeue_false', 'Automatic ack'], ['reject_requeue_true', 'Reject requeue true'], ['reject_requeue_false', 'Reject requeue false']], 'ack_requeue_true'), 'ack-mode') +
      UI.formRow('Encoding', UI.select('encoding', [['auto', 'Automatic string/base64'], ['base64', 'base64']], 'auto'), 'get-encoding') +
      UI.formRow('Messages', '<input type="number" name="count" value="1" min="1" max="50" style="width:70px">') +
      '</table><button type="submit">Get Message(s)</button><div class="get-result"></div></form>', { id: 'q-get', closed: true, help: 'get-messages' }));
    if (!isStream) {
      h.push(UI.section('Move messages', '<form data-form="move-messages" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><p class="muted small">Shovel eklentisi ile bu kuyruktaki ready mesajları aynı vhost\'taki başka bir kuyruğa taşınır ' + UI.help('move-messages') + '</p><table class="form">' +
        UI.formRow('Destination queue', '<input type="text" name="dest" list="dl-move" placeholder="hedef kuyruk">', 'move-messages', true) +
        '</table><datalist id="dl-move">' + SIM.S.queues.filter(function (x) { return x.vhost === vhost && x.name !== name; }).map(function (x) { return '<option value="' + esc(x.name) + '">'; }).join('') + '</datalist><button type="submit">Move messages</button></form>', { id: 'q-move', closed: true, help: 'move-messages' }));
    }
    h.push(UI.section('Delete', '<form data-form="delete-queue" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><label><input type="checkbox" name="if_unused"> if-unused (consumer yoksa)</label> &nbsp; <label><input type="checkbox" name="if_empty"> if-empty (mesaj yoksa)</label><br><br><button type="submit" class="danger">Delete ' + (isStream ? 'Stream' : 'Queue') + '</button> ' + UI.help('delete-queue') + '</form>', { id: 'q-del', closed: true, help: 'delete-queue' }));
    if (!isStream) h.push(UI.section('Purge', '<form data-form="purge-queue" data-vhost="' + esc(vhost) + '" data-name="' + esc(name) + '"><button type="submit" class="danger">Purge Messages</button> ' + UI.help('purge') + '</form>', { id: 'q-purge', closed: true, help: 'purge' }));
    h.push(UI.section('Runtime Metrics (Advanced)', UI.block(function () {
      return UI.facts([
        ['Process memory', U.fmtBytes(q.l_mem || q.memory), 'q-memory'],
        isStream ? ['Segment size on disk', U.fmtBytes(q.bytes + q.ready * 120)] : ['Message bytes (ready)', U.fmtBytes(q.ready * 380)],
        ['Reductions', U.fmtNum(Math.round(q.ready * 3 + 12000 + Math.random() * 400))],
        q.type === 'quorum' ? ['Raft term', 4] : null,
        q.type === 'quorum' ? ['Raft commit index', U.fmtNum(Math.round(q.ready * 1.4 + 88123))] : null,
        isStream ? ['Committed offset', U.fmtNum(q.ready - 1)] : null,
        ['Created', U.fmtDate(new Date(q.created_at))]
      ]);
    }), { id: 'q-rt', closed: true }));
    return h.join('');
  };

  function queueDetails(q) {
    var p = SIM.policyFor('queue', q), op = SIM.opPolicyFor('queue', q), eff = SIM.effectiveDefinition('queue', q);
    var cons = SIM.consumersOf(q.vhost, q.name);
    var isRep = q.type !== 'classic';
    var left = UI.facts([
      ['Type', P.qType(q), 'q-type'],
      ['Features', P.qFeatures(q) || '<span class="muted">(none)</span>', 'q-features'],
      ['Policy', p ? '<a href="#/policies">' + esc(p.name) + '</a>' : '', 'policy'],
      ['Operator policy', op ? '<a href="#/policies">' + esc(op.name) + '</a>' : '', 'operator-policy'],
      ['Effective policy definition', Object.keys(eff).length ? UI.argsTable(eff) : '', 'effective-policy'],
      Object.keys(q.arguments).length ? ['Arguments', UI.argsTable(q.arguments), 'q-args'] : null,
      q.exclusive ? ['Exclusive owner', q.owner ? esc(q.owner) : '', 'q-exclusive'] : null
    ]);
    var mid = UI.facts([
      ['State', UI.state(q.state), 'q-state'],
      ['Consumers', cons.length, 'q-consumers'],
      [isRep ? 'Leader' : 'Node', UI.nodeLink(q.node), isRep ? 'q-members' : 'q-node'],
      isRep ? ['Members', q.members.map(UI.nodeLink).join('<br>'), 'q-members'] : null,
      isRep ? ['Online', q.online.map(UI.nodeLink).join('<br>'), 'q-members'] : null,
      q.type !== 'stream' ? ['Consumer capacity', cons.length ? (85 + Math.floor(Math.random() * 15)) + '%' : '0%', 'consumer-capacity'] : null
    ]);
    var right = '<table class="list"><thead><tr><th></th><th class="r">Total</th><th class="r">Ready</th><th class="r">Unacked</th>' + (q.type === 'classic' ? '<th class="r">In memory</th><th class="r">Persistent</th><th class="r">Transient</th>' : '') + '</tr></thead><tbody>' +
      '<tr><th>Messages ' + UI.help('total') + '</th><td class="r">' + U.fmtNum(q.ready + q.unacked) + '</td><td class="r">' + U.fmtNum(q.ready) + '</td><td class="r">' + U.fmtNum(q.unacked) + '</td>' + (q.type === 'classic' ? '<td class="r">' + U.fmtNum(Math.min(q.ready, 2048)) + '</td><td class="r">' + (q.durable ? U.fmtNum(q.ready + q.unacked) : 0) + '</td><td class="r">' + (q.durable ? 0 : U.fmtNum(q.ready + q.unacked)) + '</td>' : '') + '</tr>' +
      '<tr><th>Message body bytes</th><td class="r">' + U.fmtBytes((q.ready + q.unacked) * 380) + '</td><td class="r">' + U.fmtBytes(q.ready * 380) + '</td><td class="r">' + U.fmtBytes(q.unacked * 380) + '</td>' + (q.type === 'classic' ? '<td></td><td></td><td></td>' : '') + '</tr>' +
      '<tr><th>Process memory ' + UI.help('q-memory') + '</th><td class="r" colspan="3">' + U.fmtBytes(q.l_mem || q.memory) + '</td>' + (q.type === 'classic' ? '<td></td><td></td><td></td>' : '') + '</tr></tbody></table>';
    return '<div class="facts-cols">' + left + mid + right + '</div>';
  }

  function queueBindings(q) {
    var bs = SIM.bindingsTo(q.vhost, q.name, 'queue');
    var h = '<table class="list"><thead><tr><th>From</th><th>Routing key ' + UI.help('binding-routing-key') + '</th><th>Arguments ' + UI.help('binding-args') + '</th><th></th></tr></thead><tbody>' +
      '<tr><td>' + UI.exLink(q.vhost, '') + '</td><td>' + esc(q.name) + '</td><td></td><td><span class="muted small">(Default exchange binding)</span> ' + UI.help('ex-default') + '</td></tr>' +
      bs.map(function (b) { return '<tr><td>' + UI.exLink(q.vhost, b.source) + '</td><td>' + esc(b.routing_key) + '</td><td>' + P.bindingRowArgs(b) + '</td><td>' + P.unbindBtn(b) + '</td></tr>'; }).join('') +
      '</tbody></table><div class="topo"><span class="arrow">⇓</span><span class="node-b"><b>This queue</b></span></div>';
    return h;
  }

  P.renderMessages = function (res, encoding) {
    if (res.error) return '<div class="form-msg err">' + esc(res.error) + '</div>';
    if (!res.messages.length) return '<div class="form-msg warn">Queue is empty. (Get (empty) sayacı arttı ' + UI.help('rate-get-empty') + ')</div>';
    var h = '<div class="form-msg">' + res.messages.length + ' mesaj alındı. ' + (res.requeued ? 'Mesajlar kuyruğa <b>geri kondu</b> (redelivered=true olarak işaretlendi).' : 'Mesajlar kuyruktan <b>çıkarıldı</b>.') +
      (res.deadLettered && res.deadLettered.length ? ' Dead-letter edildi → ' + res.deadLettered.map(esc).join(', ') + ' ' + UI.help('dlx') : '') + ' Kalan ready: ' + U.fmtNum(res.remaining) + '</div>';
    res.messages.forEach(function (m, i) {
      var body = m.payload;
      var enc = 'string';
      if (encoding === 'base64') { try { body = btoa(unescape(encodeURIComponent(body))); } catch (e) { /* */ } enc = 'base64'; }
      var props = Object.assign({}, m.properties);
      var headers = props.headers || {}; delete props.headers;
      h += '<div class="msg-box"><h4>Message ' + (i + 1) + (m.user ? ' <span class="small muted">(sizin yayınladığınız)</span>' : '') + '</h4>' + UI.facts([
        ['The server reported ' + U.fmtNum(m.message_count) + ' messages remaining.', ''],
        ['Exchange', m.exchange === '' ? '(AMQP default)' : esc(m.exchange)],
        ['Routing Key', esc(m.routing_key)],
        ['Redelivered', m.redelivered ? '●' : '○', 'rate-redelivered'],
        ['Properties', UI.argsTable(props), 'msg-properties'],
        Object.keys(headers).length ? ['Headers', '<span class="json">' + esc(JSON.stringify(headers, null, 1)) + '</span>' + (headers['x-death'] ? ' ' + UI.help('dlx') : ''), 'msg-headers'] : null,
        ['Payload', U.fmtNum(m.payload.length) + ' bytes · Encoding: ' + enc, 'payload']
      ]) + '<pre>' + esc(body) + '</pre></div>';
    });
    return h;
  };
})(window);
