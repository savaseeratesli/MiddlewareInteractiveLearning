/* =========================================================================
   Simülasyon motoru: durum, canlı istatistikler, geçmiş ve yönetim işlemleri.
   HİÇBİR gerçek broker'a bağlanılmaz. Tüm işlemler tarayıcı belleğindedir.
   ========================================================================= */
(function (w) {
  'use strict';
  var STORE_KEY = 'rmq-edu-sim-state-v1';
  var HIST_LEN = 721;      // 1 saat (5 sn aralıklarla)
  var STEP = 5000;

  var SIM = { S: null, hist: null, lastTick: Date.now(), pendingPub: 0, pendingGet: 0, pendingEmptyGet: 0, pendingDrop: 0, pendingReturn: 0 };

  function qkey(vhost, name) { return vhost + '\u0001' + name; }
  SIM.qkey = qkey;

  /* ---------------- Kalıcılık ---------------- */
  SIM.save = function () {
    var copy = {};
    Object.keys(SIM.S).forEach(function (k) { copy[k] = SIM.S[k]; });
    U.store.set(STORE_KEY, copy);
  };
  SIM.reset = function () { U.store.del(STORE_KEY); SIM.init(true); };

  SIM.init = function (fresh) {
    var saved = fresh ? null : U.store.get(STORE_KEY, null);
    SIM.S = saved && saved.version ? saved : SEED();
    SIM.S.queues.forEach(prepQueue);
    SIM.buildHistory();
  };

  function prepQueue(q) {
    if (q.mid === undefined) {
      q.front = []; q.tail = [];
      q.mid = q.ready || 0;
      q.base = q.ready || 0;
      q.base_unacked = q.unacked || 0;
    }
    q.ready = q.front.length + q.mid + q.tail.length;
  }

  /* ---------------- Sorgular ---------------- */
  SIM.vhostOk = function (v) { var sel = w.App ? App.vhost : ''; return !sel || sel === v; };
  SIM.queue = function (vhost, name) { return SIM.S.queues.filter(function (q) { return q.vhost === vhost && q.name === name; })[0]; };
  SIM.exchange = function (vhost, name) { return SIM.S.exchanges.filter(function (e) { return e.vhost === vhost && e.name === name; })[0]; };
  SIM.connection = function (name) { return SIM.S.connections.filter(function (c) { return c.name === name; })[0]; };
  SIM.channel = function (name) { return SIM.S.channels.filter(function (c) { return c.name === name; })[0]; };
  SIM.node = function (name) { return SIM.S.nodes.filter(function (n) { return n.name === name; })[0]; };
  SIM.user = function (name) { return SIM.S.users.filter(function (u) { return u.name === name; })[0]; };
  SIM.vhostObj = function (name) { return SIM.S.vhosts.filter(function (v) { return v.name === name; })[0]; };
  SIM.consumersOf = function (vhost, name) { return SIM.S.consumers.filter(function (c) { return c.vhost === vhost && c.queue === name; }); };
  SIM.channelsOf = function (conn) { return SIM.S.channels.filter(function (c) { return c.connection === conn; }); };
  SIM.consumersOnChannel = function (ch) { return SIM.S.consumers.filter(function (c) { return c.channel === ch; }); };
  SIM.bindingsFrom = function (vhost, ex) { return SIM.S.bindings.filter(function (b) { return b.vhost === vhost && b.source === ex; }); };
  SIM.bindingsTo = function (vhost, dest, dtype) { return SIM.S.bindings.filter(function (b) { return b.vhost === vhost && b.destination === dest && b.destination_type === dtype; }); };

  SIM.queueTotal = function (q) { return q.ready + q.unacked; };

  /* Policy eşleşmesi */
  function applies(p, kind, obj) {
    var a = p.apply_to;
    if (kind === 'exchange') return a === 'exchanges' || a === 'all';
    if (a === 'all' || a === 'queues') return true;
    if (a === 'classic_queues') return obj.type === 'classic';
    if (a === 'quorum_queues') return obj.type === 'quorum';
    if (a === 'streams') return obj.type === 'stream';
    return false;
  }
  function matchList(list, kind, obj) {
    return list.filter(function (p) {
      if (p.vhost !== obj.vhost || !applies(p, kind, obj)) return false;
      try { return new RegExp(p.pattern).test(obj.name); } catch (e) { return false; }
    }).sort(function (a, b) { return b.priority - a.priority; });
  }
  SIM.policyFor = function (kind, obj) { return matchList(SIM.S.policies, kind, obj)[0] || null; };
  SIM.opPolicyFor = function (kind, obj) { return kind === 'exchange' ? null : (matchList(SIM.S.operator_policies, kind, obj)[0] || null); };
  SIM.effectiveDefinition = function (kind, obj) {
    var p = SIM.policyFor(kind, obj), op = SIM.opPolicyFor(kind, obj), eff = {};
    if (p) Object.keys(p.definition).forEach(function (k) { eff[k] = p.definition[k]; });
    if (op) Object.keys(op.definition).forEach(function (k) {
      var v = op.definition[k];
      if (eff[k] !== undefined && typeof v === 'number' && typeof eff[k] === 'number') eff[k] = Math.min(v, eff[k]); else eff[k] = v;
    });
    return eff;
  };

  SIM.deprecatedInUse = function () {
    var used = {};
    SIM.S.queues.forEach(function (q) { if (!q.durable && !q.exclusive && q.type === 'classic') used.transient_nonexcl_queues = true; });
    SIM.S.channels.forEach(function (c) { if (c.global_prefetch > 0) used.global_qos = true; });
    SIM.S.deprecated_features.forEach(function (f) { f.used = !!used[f.name]; });
    return Object.keys(used);
  };

  SIM.alarms = function () {
    var a = [];
    SIM.S.nodes.forEach(function (n) {
      if (n.alarm_mem) a.push({ node: n.name, type: 'memory' });
      if (n.alarm_disk) a.push({ node: n.name, type: 'disk' });
    });
    return a;
  };

  /* ---------------- Canlı değerler ---------------- */
  function j(v, p) { return U.jitter(v, p === undefined ? 0.12 : p); }

  SIM.tick = function () {
    var S = SIM.S, dt = STEP / 1000;
    var alarm = SIM.alarms().length > 0;
    S.queues.forEach(function (q) {
      var cons = SIM.consumersOf(q.vhost, q.name);
      var active = cons.filter(function (c) { return c.active; }).length;
      q.l_pub = alarm ? 0 : j(q.r_pub);
      q.l_del = active ? j(q.r_del) : 0;
      q.l_ack = active ? Math.min(q.l_del, j(q.r_ack)) : 0;
      q.l_redel = q.r_redeliver ? j(q.r_redeliver, 0.6) : 0;
      if (q.type === 'stream') {
        q.mid += Math.round(q.l_pub * dt);
      } else if (active && q.r_del > 0) {
        // tüketici var: kullanıcı mesajları tüketilir, birikim taban değer etrafında dalgalanır
        q.tail = []; q.front = q.front.slice(0, 0);
        var target = Math.max(0, Math.round(q.base + (Math.random() * 2 - 1) * Math.max(1.5, q.base * 0.25)));
        q.mid = target;
      } else if (!active && q.r_pub > 0 && !alarm) {
        var add = Math.round(q.l_pub * dt * (0.6 + Math.random() * 0.8));
        q.mid += add; q.base += add;
      }
      q.ready = q.front.length + q.mid + q.tail.length;
      q.unacked = active ? Math.max(0, Math.round(q.base_unacked + (Math.random() * 2 - 1) * Math.max(1, q.base_unacked * 0.2))) : 0;
      if (q.type === 'stream') q.unacked = 0;
      q.l_mem = Math.round(q.memory * (0.9 + Math.random() * 0.2) + q.ready * (q.type === 'classic' ? 28 : q.type === 'quorum' ? 40 : 0.02));
    });
    S.exchanges.forEach(function (e) { e.l_in = alarm ? 0 : j(e.rate_in); e.l_out = alarm ? 0 : j(e.rate_out); });
    S.connections.forEach(function (c) {
      var blocked = alarm && (c.recv_rate > 200);
      c.l_state = blocked ? 'blocked' : c.state;
      c.l_recv = blocked ? 0 : j(c.recv_rate, 0.35);
      c.l_send = j(c.send_rate, 0.35);
      c.recv_oct += c.l_recv * dt; c.send_oct += c.l_send * dt;
    });
    S.channels.forEach(function (ch) {
      ch.l_pub = alarm ? 0 : j(ch.r_pub); ch.l_confirm = ch.confirm ? ch.l_pub : 0;
      ch.l_del = j(ch.r_deliver); ch.l_ack = j(ch.r_ack);
      ch.l_unacked = ch.unacked ? Math.max(0, Math.round(ch.unacked * (0.7 + Math.random() * 0.5))) : 0;
      if (ch.prefetch) ch.l_unacked = Math.min(ch.l_unacked, ch.prefetch * Math.max(1, SIM.consumersOnChannel(ch.name).length));
      ch.l_unconfirmed = ch.unconfirmed ? Math.round(Math.random() * ch.unconfirmed * 2) : 0;
    });
    S.nodes.forEach(function (n, i) {
      n.l_mem = n.alarm_mem ? n.mem_limit * 1.03 : n.mem_used * (0.97 + Math.random() * 0.06);
      n.l_disk = n.alarm_disk ? n.disk_free_limit * 0.8 : n.disk_free - (Math.random() * 30 * 1024 * 1024);
      n.l_fd = n.fd_used + Math.round(Math.random() * 3);
      n.l_proc = n.proc_used + Math.round(Math.random() * 12);
      n.l_cpu = Math.max(1, j(n.cpu_util, 0.3));
      n.l_runq = Math.random() < 0.85 ? 0 : 1;
      n.l_gc = j(n.gc_per_s, 0.2);
      n.l_iow = j(n.io_write, 0.4);
    });
    SIM.pushHistory();
    SIM.pendingPub = 0; SIM.pendingGet = 0; SIM.pendingEmptyGet = 0; SIM.pendingDrop = 0; SIM.pendingReturn = 0;
  };

  SIM.totals = function (vhostFilter) {
    var t = { ready: 0, unacked: 0, publish: 0, confirm: 0, deliver_manual: 0, deliver_auto: 0, ack: 0, redeliver: 0, get_manual: 0, get_auto: 0, get_empty: 0, ret: 0, drop: 0 };
    SIM.S.queues.forEach(function (q) {
      if (vhostFilter && q.vhost !== vhostFilter) return;
      t.ready += q.ready; t.unacked += q.unacked;
      t.redeliver += q.l_redel || 0;
    });
    SIM.S.channels.forEach(function (ch) {
      if (vhostFilter && ch.vhost !== vhostFilter) return;
      t.publish += ch.l_pub || 0; t.confirm += ch.l_confirm || 0;
      var auto = SIM.consumersOnChannel(ch.name).some(function (c) { return !c.ack_required; });
      if (auto) t.deliver_auto += ch.l_del || 0; else { t.deliver_manual += ch.l_del || 0; t.ack += ch.l_ack || 0; }
    });
    t.publish += SIM.pendingPub / (STEP / 1000);
    t.get_auto += SIM.pendingGet / (STEP / 1000);
    t.get_empty += SIM.pendingEmptyGet / (STEP / 1000);
    t.drop += SIM.pendingDrop / (STEP / 1000);
    t.ret += SIM.pendingReturn / (STEP / 1000);
    t.total = t.ready + t.unacked;
    return t;
  };

  /* ---------------- Geçmiş ---------------- */
  function ring(arr, v) { arr.push(v); if (arr.length > HIST_LEN) arr.shift(); }
  SIM.buildHistory = function () {
    var S = SIM.S;
    SIM.hist = { t: [], ov: {}, ovv: {}, q: {}, c: {}, n: {}, e: {} };
    // Geriye dönük sentetik geçmiş: tick'i hızlıca çalıştırıp zaman damgalarını geriye kaydır
    var now = Date.now();
    var snapshot = JSON.stringify(S.queues.map(function (q) { return [q.mid, q.base]; }));
    for (var i = HIST_LEN - 1; i >= 0; i--) {
      SIM.tick();
      SIM.hist.t[SIM.hist.t.length - 1] = now - i * STEP;
    }
    // stream ve birikimli kuyrukların değerlerini geri al (sentetik geçmiş sırasında arttılar)
    var snap = JSON.parse(snapshot);
    S.queues.forEach(function (q, idx) {
      var dm = q.mid - snap[idx][0];
      q.mid = snap[idx][0]; q.base = snap[idx][1];
      q.ready = q.front.length + q.mid + q.tail.length;
      var h = SIM.hist.q[qkey(q.vhost, q.name)];
      if (h && dm > 0) {
        // geçmiş verisini mevcut değere göre ölçekle
        var cur = q.ready;
        var last = h.ready[h.ready.length - 1] || 1;
        h.ready = h.ready.map(function (v) { return Math.max(0, Math.round(cur - (last - v))); });
      }
    });
    // overview ready/total serilerini tekrar hesapla (basit: oransal ölçek)
    rebuildOverviewCounts();
  };
  function rebuildOverviewCounts() {
    var hist = SIM.hist, len = hist.t.length;
    function recompute(store, filter) {
      var ready = [], unacked = [];
      for (var i = 0; i < len; i++) {
        var r = 0, u = 0;
        SIM.S.queues.forEach(function (q) {
          if (filter && q.vhost !== filter) return;
          var h = hist.q[qkey(q.vhost, q.name)];
          if (!h) return;
          r += h.ready[i] || 0; u += h.unacked[i] || 0;
        });
        ready.push(r); unacked.push(u);
      }
      store.ready = ready; store.unacked = unacked; store.total = ready.map(function (v, i) { return v + unacked[i]; });
    }
    recompute(hist.ov, null);
    Object.keys(hist.ovv).forEach(function (vh) { recompute(hist.ovv[vh], vh); });
  }

  SIM.pushHistory = function () {
    var S = SIM.S, h = SIM.hist;
    ring(h.t, Date.now());
    function pushTotals(store, filter) {
      var t = SIM.totals(filter);
      Object.keys(t).forEach(function (k) { store[k] = store[k] || []; ring(store[k], t[k]); });
    }
    pushTotals(h.ov, null);
    S.vhosts.forEach(function (v) { h.ovv[v.name] = h.ovv[v.name] || {}; pushTotals(h.ovv[v.name], v.name); });
    S.queues.forEach(function (q) {
      var k = qkey(q.vhost, q.name);
      var e = h.q[k] = h.q[k] || { ready: [], unacked: [], total: [], publish: [], deliver: [], ack: [], redeliver: [] };
      ring(e.ready, q.ready); ring(e.unacked, q.unacked); ring(e.total, q.ready + q.unacked);
      ring(e.publish, q.l_pub || 0); ring(e.deliver, q.l_del || 0); ring(e.ack, q.l_ack || 0); ring(e.redeliver, q.l_redel || 0);
    });
    S.exchanges.forEach(function (x) {
      var k = qkey(x.vhost, x.name);
      var e = h.e[k] = h.e[k] || { in: [], out: [] };
      ring(e.in, x.l_in || 0); ring(e.out, x.l_out || 0);
    });
    S.connections.forEach(function (c) {
      var e = h.c[c.name] = h.c[c.name] || { recv: [], send: [] };
      ring(e.recv, c.l_recv || 0); ring(e.send, c.l_send || 0);
    });
    S.nodes.forEach(function (n) {
      var e = h.n[n.name] = h.n[n.name] || { mem: [], disk: [], fd: [], proc: [], cpu: [], runq: [] };
      ring(e.mem, n.l_mem); ring(e.disk, n.l_disk); ring(e.fd, n.l_fd); ring(e.proc, n.l_proc); ring(e.cpu, n.l_cpu); ring(e.runq, n.l_runq);
    });
  };

  /* Seçilen aralığa göre son N noktayı al (gerekirse seyrelt) */
  SIM.slice = function (arr, rangeSec) {
    var n = Math.round(rangeSec / (STEP / 1000)) + 1;
    var a = arr.slice(-n);
    if (a.length > 150) {
      var f = Math.ceil(a.length / 150), out = [];
      for (var i = 0; i < a.length; i += f) out.push(a[i]);
      if (out[out.length - 1] !== a[a.length - 1]) out.push(a[a.length - 1]);
      return out;
    }
    return a;
  };

  /* ---------------- Yönlendirme (routing) ---------------- */
  SIM.route = function (vhost, exName, rk, headers, trace, visited) {
    visited = visited || {};
    trace = trace || [];
    var key = exName;
    if (visited[key]) return [];
    visited[key] = true;
    if (exName === '') {
      var q = SIM.queue(vhost, rk);
      trace.push({ ex: '(AMQP default)', note: q ? 'routing key "' + rk + '" = kuyruk adı → ' + rk : 'routing key ile aynı adda kuyruk yok' });
      return q ? [q] : [];
    }
    var ex = SIM.exchange(vhost, exName);
    if (!ex) return [];
    var bs = SIM.bindingsFrom(vhost, exName), matched = [];
    bs.forEach(function (b) {
      var ok = false, why = '';
      switch (ex.type) {
        case 'direct': ok = b.routing_key === rk; why = '"' + b.routing_key + '" ' + (ok ? '=' : '≠') + ' "' + rk + '"'; break;
        case 'fanout': ok = true; why = 'fanout: routing key yok sayılır'; break;
        case 'x-local-random': ok = true; why = 'local random'; break;
        case 'topic': ok = U.topicMatch(b.routing_key, rk); why = 'desen "' + b.routing_key + '" ' + (ok ? 'eşleşti' : 'eşleşmedi'); break;
        case 'headers':
          var mode = (b.arguments['x-match'] || 'all'), keys = Object.keys(b.arguments).filter(function (k) { return mode.indexOf('-with-x') > 0 ? k !== 'x-match' : k.indexOf('x-') !== 0; });
          var hits = keys.filter(function (k) { return headers && String(headers[k]) === String(b.arguments[k]); }).length;
          ok = keys.length === 0 ? (mode.indexOf('all') === 0) : (mode.indexOf('any') === 0 ? hits > 0 : hits === keys.length);
          why = 'x-match=' + mode + ', ' + hits + '/' + keys.length + ' header eşleşti'; break;
      }
      trace.push({ ex: exName, b: b, ok: ok, why: why });
      if (ok) matched.push(b);
    });
    if (ex.type === 'x-local-random' && matched.length > 1) matched = [matched[Math.floor(Math.random() * matched.length)]];
    var result = [];
    matched.forEach(function (b) {
      if (b.destination_type === 'queue') { var qq = SIM.queue(vhost, b.destination); if (qq) result.push(qq); }
      else result = result.concat(SIM.route(vhost, b.destination, rk, headers, trace, visited));
    });
    if (!result.length) {
      var ae = (ex.arguments && ex.arguments['alternate-exchange']) || (SIM.effectiveDefinition('exchange', ex)['alternate-exchange']);
      if (ae && SIM.exchange(vhost, ae)) {
        trace.push({ ex: exName, note: 'Eşleşme yok → alternate-exchange "' + ae + '"' });
        result = SIM.route(vhost, ae, rk, headers, trace, visited);
      }
    }
    var seen = {};
    return result.filter(function (q) { var k = q.name; if (seen[k]) return false; seen[k] = true; return true; });
  };

  /* ---------------- Mesaj üretimi ---------------- */
  var seqId = 1000;
  function sampleBody(q, i) {
    var n = q.name, id = 10000 + Math.floor(Math.random() * 90000);
    if (n.indexOf('orders') === 0 || n.indexOf('legacy.orders') === 0) return JSON.stringify({ orderId: id, customerId: 'C-' + (2000 + i), status: n.split('.')[1] || 'created', total: +(Math.random() * 900 + 50).toFixed(2), currency: 'TRY', items: Math.ceil(Math.random() * 4), ts: new Date(Date.now() - i * 61000).toISOString() });
    if (n.indexOf('payments') === 0) return JSON.stringify({ paymentId: 'PAY-' + id, orderId: id - 7, amount: +(Math.random() * 900 + 50).toFixed(2), method: ['card', 'eft', 'wallet'][i % 3], tier: ['gold', 'standard'][i % 2] });
    if (n.indexOf('notifications') === 0) return JSON.stringify({ to: 'user' + id + '@example.com', template: ['order-confirmation', 'shipping-update', 'password-reset'][i % 3], locale: 'tr-TR' });
    if (n.indexOf('analytics') === 0) return JSON.stringify({ event: 'click', page: '/urun/' + id, sessionId: U.uid(12), ts: Date.now() - i * 1000 });
    if (n.indexOf('app.logs') === 0) return '2026-11-19T15:52:' + U.pad(i % 60) + 'Z INFO  billing-job finished batch ' + id;
    if (n.indexOf('mqtt') === 0) return JSON.stringify({ deviceId: 'iot-gateway-01', temp: +(20 + Math.random() * 5).toFixed(1), hum: Math.round(40 + Math.random() * 20) });
    return 'message #' + i;
  }
  function synthMessage(q, i) {
    var dlq = /dlq$/.test(q.name);
    var src = q.name.replace(/\.dlq$/, '.created');
    var headers = {};
    if (dlq) headers['x-death'] = [{ count: 1, reason: i % 3 === 0 ? 'rejected' : 'delivery_limit', queue: src, time: Math.floor(Date.now() / 1000) - i * 3600, exchange: q.vhost + '.events', 'routing-keys': ['order.created.tr'] }];
    if (q.name === 'orders.retry') headers['x-retry-count'] = (i % 3) + 1;
    if (q.name === 'legacy.orders') headers['x-source'] = 'legacy-erp';
    return {
      exchange: dlq ? q.vhost + '.dlx' : (q.vhost === '/' ? '' : q.vhost + '.events'),
      routing_key: dlq ? src : q.name.replace(/s?$/, '').replace('orders.', 'order.') + '.tr',
      redelivered: false, payload: sampleBody(q, i), payload_encoding: 'string',
      properties: { delivery_mode: 2, content_type: q.name.indexOf('app.logs') === 0 ? 'text/plain' : 'application/json', message_id: U.uid(8) + '-' + U.uid(4) + '-' + U.uid(4) + '-' + U.uid(12), timestamp: Math.floor(Date.now() / 1000) - i * 60, headers: headers },
      seq: ++seqId
    };
  }

  /* ---------------- Yönetim işlemleri (simülasyon) ---------------- */
  SIM.publish = function (vhost, exName, rk, props, headers, payload, mandatory) {
    var ex = exName === '' ? { internal: false } : SIM.exchange(vhost, exName);
    if (!ex) return { error: 'NOT_FOUND - no exchange \'' + exName + '\' in vhost \'' + vhost + '\'' };
    if (ex.internal) return { error: 'ACCESS_REFUSED - cannot publish to internal exchange \'' + exName + '\' in vhost \'' + vhost + '\'' };
    var trace = [];
    var queues = SIM.route(vhost, exName, rk, headers, trace);
    SIM.pendingPub++;
    var res = { routed: queues.length > 0, trace: trace, results: [] };
    if (!queues.length) { if (mandatory) SIM.pendingReturn++; else SIM.pendingDrop++; }
    queues.forEach(function (q) {
      var msg = { exchange: exName, routing_key: rk, redelivered: false, payload: payload, payload_encoding: 'string', properties: U.clone(props || {}), seq: ++seqId, user: true };
      msg.properties.headers = headers || {};
      var cons = SIM.consumersOf(q.vhost, q.name).filter(function (c) { return c.active; });
      var eff = SIM.effectiveDefinition('queue', q);
      var maxLen = q.arguments['x-max-length'] || eff['max-length'];
      if (q.type === 'stream') {
        q.tail.push(msg); if (q.tail.length > 50) q.tail.shift(); q.mid += 0; q.ready = q.front.length + q.mid + q.tail.length;
        res.results.push({ q: q, action: 'stream', consumers: cons.length });
      } else if (cons.length && q.ready === 0) {
        res.results.push({ q: q, action: 'delivered', consumer: cons[Math.floor(Math.random() * cons.length)] });
      } else if (maxLen && q.ready >= maxLen) {
        var ov = q.arguments['x-overflow'] || eff.overflow || 'drop-head';
        res.results.push({ q: q, action: 'overflow', overflow: ov });
      } else {
        q.tail.push(msg); q.base++;
        q.ready = q.front.length + q.mid + q.tail.length;
        res.results.push({ q: q, action: 'enqueued', ahead: q.ready - 1, consumers: cons.length });
      }
    });
    SIM.save();
    return res;
  };

  SIM.getMessages = function (vhost, name, count, ackmode) {
    var q = SIM.queue(vhost, name);
    if (!q) return { error: 'Queue not found' };
    if (q.type === 'stream') return { error: 'Stream\'ler basic.get desteklemez. Stream\'leri bir consumer (x-stream-offset) ile okuyun.' };
    var out = [], i;
    count = Math.max(1, Math.min(count || 1, 50));
    while (q.front.length < count && q.mid > 0) { q.front.push(synthMessage(q, q.front.length + 1)); q.mid--; }
    while (q.front.length < count && q.tail.length) q.front.push(q.tail.shift());
    var take = q.front.slice(0, count);
    if (!take.length) { SIM.pendingEmptyGet++; return { messages: [], remaining: q.ready }; }
    var requeue = ackmode === 'ack_requeue_true' || ackmode === 'reject_requeue_true';
    for (i = 0; i < take.length; i++) {
      var m = U.clone(take[i]);
      m.message_count = q.ready - i - 1;
      out.push(m);
      take[i].redelivered = requeue ? true : take[i].redelivered;
    }
    if (!requeue) {
      q.front.splice(0, take.length);
      q.base = Math.max(0, q.base - take.length);
    }
    q.ready = q.front.length + q.mid + q.tail.length;
    SIM.pendingGet += take.length;
    var dead = [];
    if (ackmode === 'reject_requeue_false') {
      var eff = SIM.effectiveDefinition('queue', q);
      var dlx = q.arguments['x-dead-letter-exchange'] || eff['dead-letter-exchange'];
      if (dlx !== undefined) {
        take.forEach(function (m) {
          var rk2 = q.arguments['x-dead-letter-routing-key'] || eff['dead-letter-routing-key'] || m.routing_key;
          var targets = SIM.route(q.vhost, dlx, rk2, {}, []);
          targets.forEach(function (t) {
            if (t === q) return;
            var dm = U.clone(m); dm.redelivered = false;
            dm.properties.headers = dm.properties.headers || {};
            dm.properties.headers['x-death'] = [{ count: 1, reason: 'rejected', queue: q.name, exchange: m.exchange, 'routing-keys': [m.routing_key], time: Math.floor(Date.now() / 1000) }];
            t.tail.push(dm); t.base++; t.ready = t.front.length + t.mid + t.tail.length;
            dead.push(t.name);
          });
        });
      }
    }
    SIM.save();
    return { messages: out, requeued: requeue, deadLettered: dead, remaining: q.ready };
  };

  SIM.purge = function (vhost, name) {
    var q = SIM.queue(vhost, name); if (!q) return 0;
    var n = q.ready;
    q.front = []; q.tail = []; q.mid = 0; q.base = 0; q.ready = 0;
    SIM.save(); return n;
  };

  SIM.addQueue = function (o) {
    if (SIM.queue(o.vhost, o.name)) return { error: 'PRECONDITION_FAILED: \'' + o.name + '\' adında bir kuyruk bu vhost\'ta zaten var.' };
    if (!o.name) return { error: 'Kuyruk adı boş olamaz.' };
    if (/^amq\./.test(o.name)) return { error: 'ACCESS_REFUSED - queue name \'' + o.name + '\' contains reserved prefix \'amq.*\'' };
    var vh = SIM.vhostObj(o.vhost);
    var type = o.type === 'default' ? (vh ? vh.default_queue_type : 'classic') : o.type;
    if ((type === 'quorum' || type === 'stream') && (!o.durable || o.auto_delete)) return { error: 'PRECONDITION_FAILED - invalid property \'' + (o.auto_delete ? 'auto-delete' : 'non-durable') + '\' for queue \'' + o.name + '\' (' + type + ' queues must be durable and cannot be auto-delete)' };
    var args = o.arguments || {};
    if (type !== 'classic') args['x-queue-type'] = type;
    var node = o.node || SIM.S.nodes[0].name;
    var q = {
      vhost: o.vhost, name: o.name, type: type, durable: !!o.durable, auto_delete: !!o.auto_delete, exclusive: false,
      arguments: args, node: node, members: type === 'classic' ? [node] : SIM.S.nodes.map(function (n) { return n.name; }).slice(0, args['x-quorum-initial-group-size'] || args['x-initial-cluster-size'] || 3),
      state: 'running', ready: 0, unacked: 0, r_pub: 0, r_del: 0, r_ack: 0, r_redeliver: 0, r_get: 0,
      memory: type === 'classic' ? 14000 : 180000, bytes: 0, sac: !!args['x-single-active-consumer'], created_at: Date.now(), owner: null, messages: [], user_created: true
    };
    q.online = q.members.slice();
    prepQueue(q);
    SIM.S.queues.push(q);
    SIM.save();
    return { ok: true, q: q, type: type };
  };

  SIM.deleteQueue = function (vhost, name, opts) {
    var q = SIM.queue(vhost, name); if (!q) return { error: 'not found' };
    opts = opts || {};
    var cons = SIM.consumersOf(vhost, name);
    if (opts.ifUnused && cons.length) return { error: 'PRECONDITION_FAILED - queue \'' + name + '\' in use (' + cons.length + ' consumer)' };
    if (opts.ifEmpty && q.ready + q.unacked > 0) return { error: 'PRECONDITION_FAILED - queue \'' + name + '\' not empty (' + (q.ready + q.unacked) + ' messages)' };
    SIM.S.queues = SIM.S.queues.filter(function (x) { return x !== q; });
    SIM.S.bindings = SIM.S.bindings.filter(function (b) { return !(b.vhost === vhost && b.destination === name && b.destination_type === 'queue'); });
    SIM.S.consumers = SIM.S.consumers.filter(function (c) { return !(c.vhost === vhost && c.queue === name); });
    SIM.save();
    return { ok: true, consumers: cons.length, messages: q.ready + q.unacked };
  };

  SIM.addExchange = function (o) {
    if (!o.name) return { error: 'Exchange adı boş olamaz.' };
    if (/^amq\./.test(o.name)) return { error: 'ACCESS_REFUSED - exchange name \'' + o.name + '\' contains reserved prefix \'amq.*\'' };
    if (SIM.exchange(o.vhost, o.name)) return { error: 'PRECONDITION_FAILED: \'' + o.name + '\' adında bir exchange zaten var.' };
    SIM.S.exchanges.push({ vhost: o.vhost, name: o.name, type: o.type, durable: !!o.durable, auto_delete: !!o.auto_delete, internal: !!o.internal, arguments: o.arguments || {}, builtin: false, rate_in: 0, rate_out: 0, user_created: true });
    SIM.save();
    return { ok: true };
  };
  SIM.deleteExchange = function (vhost, name, ifUnused) {
    var ex = SIM.exchange(vhost, name); if (!ex) return { error: 'not found' };
    if (ex.builtin) return { error: 'ACCESS_REFUSED - operation not permitted on the default exchange / amq.* exchanges' };
    var bs = SIM.S.bindings.filter(function (b) { return b.vhost === vhost && (b.source === name || (b.destination === name && b.destination_type === 'exchange')); });
    if (ifUnused && bs.length) return { error: 'PRECONDITION_FAILED - exchange \'' + name + '\' in use (' + bs.length + ' binding)' };
    SIM.S.exchanges = SIM.S.exchanges.filter(function (x) { return x !== ex; });
    SIM.S.bindings = SIM.S.bindings.filter(function (b) { return bs.indexOf(b) < 0; });
    SIM.save();
    return { ok: true, bindings: bs.length };
  };

  SIM.addBinding = function (o) {
    if (o.source === '') return { error: 'ACCESS_REFUSED - operation not permitted on the default exchange' };
    if (!SIM.exchange(o.vhost, o.source)) return { error: 'NOT_FOUND - no exchange \'' + o.source + '\' in vhost \'' + o.vhost + '\'' };
    if (o.destination_type === 'queue' && !SIM.queue(o.vhost, o.destination)) return { error: 'NOT_FOUND - no queue \'' + o.destination + '\' in vhost \'' + o.vhost + '\'' };
    if (o.destination_type === 'exchange' && !SIM.exchange(o.vhost, o.destination)) return { error: 'NOT_FOUND - no exchange \'' + o.destination + '\' in vhost \'' + o.vhost + '\'' };
    var dup = SIM.S.bindings.some(function (b) { return b.vhost === o.vhost && b.source === o.source && b.destination === o.destination && b.destination_type === o.destination_type && b.routing_key === o.routing_key && JSON.stringify(b.arguments) === JSON.stringify(o.arguments || {}); });
    if (dup) return { error: 'Bu binding zaten mevcut (AMQP\'de idempotent: tekrar eklemek değişiklik yapmaz).' };
    SIM.S.bindings.push({ vhost: o.vhost, source: o.source, destination: o.destination, destination_type: o.destination_type, routing_key: o.routing_key || '', arguments: o.arguments || {} });
    SIM.save();
    return { ok: true };
  };
  SIM.removeBinding = function (vhost, source, dest, dtype, rk, argsJson) {
    var before = SIM.S.bindings.length;
    SIM.S.bindings = SIM.S.bindings.filter(function (b) {
      return !(b.vhost === vhost && b.source === source && b.destination === dest && b.destination_type === dtype && b.routing_key === rk && JSON.stringify(b.arguments) === argsJson);
    });
    SIM.save();
    return before !== SIM.S.bindings.length;
  };

  SIM.closeConnection = function (name) {
    var c = SIM.connection(name); if (!c) return null;
    var chans = SIM.channelsOf(name).map(function (x) { return x.name; });
    var requeued = 0, removedQ = [];
    SIM.S.consumers.filter(function (k) { return chans.indexOf(k.channel) >= 0; }).forEach(function (k) {
      var q = SIM.queue(k.vhost, k.queue);
      if (q && q.type !== 'stream') { requeued += q.base_unacked ? 1 : 0; }
    });
    SIM.S.consumers = SIM.S.consumers.filter(function (k) { return chans.indexOf(k.channel) < 0; });
    SIM.S.channels = SIM.S.channels.filter(function (x) { return x.connection !== name; });
    SIM.S.connections = SIM.S.connections.filter(function (x) { return x !== c; });
    // exclusive kuyruklar bağlantıyla birlikte silinir
    SIM.S.queues.filter(function (q) { return q.exclusive && q.owner === c.short_id; }).forEach(function (q) { removedQ.push(q.name); SIM.deleteQueue(q.vhost, q.name); });
    // tüketicisi kalmayan kuyruklarda unacked → ready (redelivery)
    SIM.S.queues.forEach(function (q) {
      if (!SIM.consumersOf(q.vhost, q.name).length && q.base_unacked) { q.mid += q.base_unacked; q.base += q.base_unacked; q.base_unacked = 0; q.r_redeliver = 0; }
      if (!SIM.consumersOf(q.vhost, q.name).length && q.auto_delete) { removedQ.push(q.name); SIM.deleteQueue(q.vhost, q.name); }
    });
    // SAC: bekleyen consumer aktif olur
    SIM.S.queues.filter(function (q) { return q.sac; }).forEach(function (q) {
      var cs = SIM.consumersOf(q.vhost, q.name);
      if (cs.length && !cs.some(function (k) { return k.active; })) { cs[0].active = true; cs[0].activity_status = 'single_active'; }
    });
    SIM.save();
    return { channels: chans.length, removedQueues: removedQ };
  };

  /* Admin */
  SIM.addUser = function (o) {
    if (!o.name) return { error: 'Kullanıcı adı zorunludur.' };
    if (SIM.user(o.name)) return { error: 'Bu kullanıcı zaten var. (Gerçek UI\'da aynı adla ekleme parolayı/tag\'leri günceller.)' };
    SIM.S.users.push({ name: o.name, tags: o.tags || [], has_password: !!o.has_password, hashing: 'rabbit_password_hashing_sha256' });
    SIM.save(); return { ok: true };
  };
  SIM.deleteUser = function (name) {
    SIM.S.users = SIM.S.users.filter(function (u) { return u.name !== name; });
    SIM.S.permissions = SIM.S.permissions.filter(function (p) { return p.user !== name; });
    SIM.S.topic_permissions = SIM.S.topic_permissions.filter(function (p) { return p.user !== name; });
    var closed = SIM.S.connections.filter(function (c) { return c.user === name; }).map(function (c) { return c.name; });
    closed.forEach(SIM.closeConnection);
    SIM.save(); return { closed: closed.length };
  };
  SIM.setUserTags = function (name, tags) { var u = SIM.user(name); if (u) { u.tags = tags; SIM.save(); } };
  SIM.setPermission = function (o) {
    SIM.S.permissions = SIM.S.permissions.filter(function (p) { return !(p.user === o.user && p.vhost === o.vhost); });
    SIM.S.permissions.push({ user: o.user, vhost: o.vhost, configure: o.configure, write: o.write, read: o.read });
    SIM.save();
  };
  SIM.clearPermission = function (user, vhost) { SIM.S.permissions = SIM.S.permissions.filter(function (p) { return !(p.user === user && p.vhost === vhost); }); SIM.save(); };
  SIM.setTopicPermission = function (o) {
    SIM.S.topic_permissions = SIM.S.topic_permissions.filter(function (p) { return !(p.user === o.user && p.vhost === o.vhost && p.exchange === o.exchange); });
    SIM.S.topic_permissions.push(o); SIM.save();
  };
  SIM.clearTopicPermission = function (user, vhost, ex) { SIM.S.topic_permissions = SIM.S.topic_permissions.filter(function (p) { return !(p.user === user && p.vhost === vhost && p.exchange === ex); }); SIM.save(); };

  SIM.addVhost = function (o) {
    if (!o.name) return { error: 'Vhost adı zorunludur.' };
    if (SIM.vhostObj(o.name)) return { error: 'Bu vhost zaten var.' };
    SIM.S.vhosts.push({ name: o.name, description: o.description || '', tags: o.tags || [], default_queue_type: o.default_queue_type || 'classic', tracing: false, protected: false });
    // yeni vhost için varsayılan exchange'ler
    ['', 'amq.direct', 'amq.fanout', 'amq.headers', 'amq.match', 'amq.rabbitmq.trace', 'amq.topic'].forEach(function (n) {
      var t = n === '' || n === 'amq.direct' ? 'direct' : n === 'amq.fanout' ? 'fanout' : n === 'amq.topic' || n === 'amq.rabbitmq.trace' ? 'topic' : 'headers';
      SIM.S.exchanges.push({ vhost: o.name, name: n, type: t, durable: true, auto_delete: false, internal: n === 'amq.rabbitmq.trace', arguments: {}, builtin: true, rate_in: 0, rate_out: 0 });
    });
    // oluşturan kullanıcıya otomatik tam yetki (gerçek UI davranışı)
    SIM.setPermission({ user: SIM.S.current_user, vhost: o.name, configure: '.*', write: '.*', read: '.*' });
    SIM.save(); return { ok: true };
  };
  SIM.deleteVhost = function (name) {
    var S = SIM.S;
    var conns = S.connections.filter(function (c) { return c.vhost === name; }).map(function (c) { return c.name; });
    conns.forEach(SIM.closeConnection);
    S.vhosts = S.vhosts.filter(function (v) { return v.name !== name; });
    ['exchanges', 'queues', 'bindings', 'permissions', 'topic_permissions', 'policies', 'operator_policies', 'vhost_limits', 'fed_upstreams', 'shovels', 'consumers'].forEach(function (k) {
      S[k] = S[k].filter(function (x) { return x.vhost !== name; });
    });
    SIM.save(); return { connections: conns.length };
  };
  SIM.toggleTracing = function (name) { var v = SIM.vhostObj(name); if (v) { v.tracing = !v.tracing; SIM.save(); return v.tracing; } };

  SIM.setPolicy = function (o, operator) {
    var list = operator ? 'operator_policies' : 'policies';
    SIM.S[list] = SIM.S[list].filter(function (p) { return !(p.vhost === o.vhost && p.name === o.name); });
    SIM.S[list].push(o); SIM.save();
  };
  SIM.deletePolicy = function (vhost, name, operator) {
    var list = operator ? 'operator_policies' : 'policies';
    SIM.S[list] = SIM.S[list].filter(function (p) { return !(p.vhost === vhost && p.name === name); }); SIM.save();
  };
  SIM.setLimit = function (kind, who, key, value) {
    var list = kind === 'vhost' ? SIM.S.vhost_limits : SIM.S.user_limits, f = kind === 'vhost' ? 'vhost' : 'user';
    var e = list.filter(function (x) { return x[f] === who; })[0];
    if (!e) { e = {}; e[f] = who; e.value = {}; list.push(e); }
    e.value[key] = value; SIM.save();
  };
  SIM.clearLimit = function (kind, who, key) {
    var list = kind === 'vhost' ? SIM.S.vhost_limits : SIM.S.user_limits, f = kind === 'vhost' ? 'vhost' : 'user';
    list.forEach(function (e) { if (e[f] === who) delete e.value[key]; });
    if (kind === 'vhost') SIM.S.vhost_limits = list.filter(function (e) { return Object.keys(e.value).length; });
    else SIM.S.user_limits = list.filter(function (e) { return Object.keys(e.value).length; });
    SIM.save();
  };
  SIM.enableFeatureFlag = function (name) {
    var n = 0;
    SIM.S.feature_flags.forEach(function (f) { if ((name === 'all' && f.stability !== 'experimental') || f.name === name) { if (f.state !== 'enabled') n++; f.state = 'enabled'; } });
    SIM.save(); return n;
  };
  SIM.setClusterName = function (n) { SIM.S.cluster_name = n; SIM.save(); };
  SIM.setAlarm = function (node, type, on) {
    var n = SIM.node(node); if (!n) return;
    n['alarm_' + type] = on; SIM.save();
  };
  SIM.setNodeRunning = function (node, on) {
    var n = SIM.node(node); if (!n) return;
    n.running = on;
    SIM.S.queues.forEach(function (q) {
      if (q.type === 'classic' && q.node === node) q.state = on ? 'running' : 'down';
      if (q.type !== 'classic') {
        q.online = q.members.filter(function (m) { var nn = SIM.node(m); return nn && nn.running; });
        if (q.node === node && !on && q.online.length) q.node = q.online[0];
        q.state = q.online.length > q.members.length / 2 ? 'running' : 'minority';
      }
    });
    SIM.save();
  };

  SIM.addUpstream = function (o) {
    SIM.S.fed_upstreams = SIM.S.fed_upstreams.filter(function (u) { return !(u.vhost === o.vhost && u.name === o.name); });
    SIM.S.fed_upstreams.push(o); SIM.save();
  };
  SIM.deleteUpstream = function (vhost, name) {
    SIM.S.fed_upstreams = SIM.S.fed_upstreams.filter(function (u) { return !(u.vhost === vhost && u.name === name); });
    SIM.S.fed_links = SIM.S.fed_links.filter(function (l) { return !(l.vhost === vhost && l.upstream === name); });
    SIM.save();
  };
  SIM.addShovel = function (o) {
    if (SIM.S.shovels.some(function (s) { return s.vhost === o.vhost && s.name === o.name; })) return { error: 'Bu adda bir shovel zaten var.' };
    o.state = 'starting'; o.type = 'dynamic'; o.node = SIM.S.nodes[Math.floor(Math.random() * SIM.S.nodes.length)].name; o.timestamp = Date.now(); o.forwarded = 0; o.pending = 0;
    SIM.S.shovels.push(o); SIM.save();
    setTimeout(function () { o.state = 'running'; SIM.save(); }, 4000);
    return { ok: true };
  };
  SIM.deleteShovel = function (vhost, name) { SIM.S.shovels = SIM.S.shovels.filter(function (s) { return !(s.vhost === vhost && s.name === name); }); SIM.save(); };
  SIM.restartShovel = function (vhost, name) {
    var s = SIM.S.shovels.filter(function (x) { return x.vhost === vhost && x.name === name; })[0];
    if (!s || s.type === 'static') return false;
    s.state = 'starting'; s.reason = ''; s.timestamp = Date.now(); SIM.save();
    setTimeout(function () { s.state = 'running'; SIM.save(); }, 3000);
    return true;
  };
  SIM.moveMessages = function (vhost, src, dest) {
    var q = SIM.queue(vhost, src), d = SIM.queue(vhost, dest);
    if (!q || !d) return { error: 'Kaynak veya hedef kuyruk bulunamadı.' };
    var n = q.ready;
    d.mid += q.mid; d.tail = d.tail.concat(q.front, q.tail); d.base += n; d.ready = d.front.length + d.mid + d.tail.length;
    q.front = []; q.tail = []; q.mid = 0; q.base = 0; q.ready = 0;
    SIM.S.shovels.push({ vhost: vhost, name: 'Move from ' + src, type: 'dynamic', state: 'terminated', node: q.node, src_protocol: 'amqp091', src_uri: 'amqp:///' + U.enc(vhost), src_queue: src, src_prefetch: 1000, src_delete_after: 'queue-length', dest_protocol: 'amqp091', dest_uri: 'amqp:///' + U.enc(vhost), dest_queue: dest, dest_exchange: '', ack_mode: 'on-confirm', add_forward_headers: false, reconnect_delay: 5, timestamp: Date.now(), forwarded: n, pending: 0, reason: 'Shovel completed: src-delete-after=queue-length reached (' + n + ' messages)' });
    SIM.save();
    return { ok: true, moved: n };
  };

  SIM.uptime = function (n) { return n.uptime_base + (Date.now() - SIM.S.seededAt); };

  w.SIM = SIM;
})(window);
