/* Overview ve Node detay sayfaları */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};
  var COL = Charts.COLORS;

  function ovStore() { return App.vhost ? (SIM.hist.ovv[App.vhost] || SIM.hist.ov) : SIM.hist.ov; }

  P.queuedChart = function (id, store, title, help) {
    return UI.chart({
      id: id, title: title || 'Queued messages', help: help || 'queued-messages', legendCols: 3,
      get: function (range) {
        var st = store();
        var last = function (k) { var a = st[k] || [0]; return a[a.length - 1]; };
        return {
          times: SIM.slice(SIM.hist.t, range),
          series: [
            { key: 'ready', label: 'Ready', color: COL.ready, data: SIM.slice(st.ready || [], range), value: U.fmtNum(last('ready')), help: 'ready' },
            { key: 'unacked', label: 'Unacked', color: COL.unacked, data: SIM.slice(st.unacked || [], range), value: U.fmtNum(last('unacked')), help: 'unacked' },
            { key: 'total', label: 'Total', color: COL.total, data: SIM.slice(st.total || [], range), value: U.fmtNum(last('total')), help: 'total' }
          ]
        };
      }
    });
  };

  P.overview = function () {
    var h = ['<h1>Overview ' + UI.help('tab-overview') + '</h1>'];
    var totals = P.queuedChart('ov-queued', ovStore) +
      UI.chart({
        id: 'ov-rates', title: 'Message rates', help: 'message-rates', unit: 'rate', legendCols: 3,
        get: function (range) {
          var st = ovStore();
          function s(key, label, help) {
            var a = st[key] || [0];
            return { key: key, label: label, color: COL[key], data: SIM.slice(a, range), value: U.fmtRate(a[a.length - 1]), help: help };
          }
          return {
            times: SIM.slice(SIM.hist.t, range), series: [
              s('publish', 'Publish', 'rate-publish'), s('confirm', 'Publisher<br>confirm', 'rate-confirm'), s('deliver_manual', 'Deliver<br>(manual<br>ack)', 'rate-deliver-manual'),
              s('deliver_auto', 'Deliver<br>(auto ack)', 'rate-deliver-auto'), s('ack', 'Consumer<br>ack', 'rate-consumer-ack'), s('redeliver', 'Redelivered', 'rate-redelivered'),
              s('get_manual', 'Get<br>(manual<br>ack)', 'rate-get-manual'), s('get_auto', 'Get (auto<br>ack)', 'rate-get-auto'), s('get_empty', 'Get<br>(empty)', 'rate-get-empty'),
              s('ret', 'Unroutable<br>(return)', 'rate-unroutable-return'), s('drop', 'Unroutable<br>(drop)', 'rate-unroutable-drop')
            ]
          };
        }
      }) +
      UI.h3('Global counts', 'global-counts') +
      UI.block(function () {
        var S = SIM.S, vf = SIM.vhostOk;
        var n = {
          conn: S.connections.filter(function (x) { return vf(x.vhost); }).length,
          ch: S.channels.filter(function (x) { return vf(x.vhost); }).length,
          ex: S.exchanges.filter(function (x) { return vf(x.vhost); }).length,
          q: S.queues.filter(function (x) { return vf(x.vhost); }).length,
          cons: S.consumers.filter(function (x) { return vf(x.vhost); }).length
        };
        return '<div class="counts-row">' +
          '<a class="btn-count" href="#/connections">Connections: <b>' + n.conn + '</b></a>' +
          '<a class="btn-count" href="#/channels">Channels: <b>' + n.ch + '</b></a>' +
          '<a class="btn-count" href="#/exchanges">Exchanges: <b>' + n.ex + '</b></a>' +
          '<a class="btn-count" href="#/queues">Queues: <b>' + n.q + '</b></a>' +
          '<a class="btn-count" href="#/queues" title="Consumer listesi kuyruk detay sayfalarındadır">Consumers: <b>' + n.cons + '</b></a> ' + UI.help('consumer') + '</div>';
      });
    h.push(UI.section('Totals', totals, { id: 'ov-totals' }));

    if (!App.vhost) {
      h.push(UI.section('Nodes', P.nodesTable(), { id: 'ov-nodes', help: 'nodes' }));
    }
    h.push(UI.section('Churn statistics', P.churn(), { id: 'ov-churn', closed: true, help: 'churn' }));
    h.push(UI.section('Ports and contexts', P.ports(), { id: 'ov-ports', closed: true, help: 'ports' }));
    h.push(UI.section('Export definitions', P.exportDefs(), { id: 'ov-export', closed: true, help: 'definitions-export' }));
    h.push(UI.section('Import definitions', P.importDefs(), { id: 'ov-import', closed: true, help: 'definitions-import' }));
    return h.join('');
  };

  P.nodeBars = {
    fd: function (n) {
      var pct = n.l_fd / n.fd_total;
      return '<div class="bar' + (pct < 0.8 ? ' full' : '') + '"><div class="fill' + (pct > 0.9 ? ' err' : pct > 0.8 ? ' warn' : '') + '" style="width:' + (pct >= 0.8 ? pct * 100 : 0) + '%"></div><span>' + U.fmtNum(n.l_fd) + '</span></div><div class="bar-sub">' + n.fd_total + ' available</div>';
    },
    proc: function (n) {
      return '<div class="bar full"><span>' + U.fmtNum(n.l_proc) + '</span></div><div class="bar-sub">' + n.proc_total + ' available</div>';
    },
    mem: function (n) {
      var alarm = n.alarm_mem || n.l_mem >= n.mem_limit;
      return '<div class="bar' + (alarm ? '' : ' full') + '">' + (alarm ? '<div class="fill err" style="width:100%"></div>' : '') + '<span>' + U.fmtBytes(n.l_mem) + '</span></div><div class="bar-sub' + (alarm ? ' err-text' : '') + '">' + (alarm ? '<b>memory alarm</b> · ' : '') + U.fmtBytes(n.mem_limit) + ' high watermark</div>';
    },
    disk: function (n) {
      var alarm = n.alarm_disk || n.l_disk <= n.disk_free_limit;
      var pct = Math.min(100, n.disk_free_limit / n.l_disk * 100);
      return '<div class="bar' + (alarm ? '' : ' full') + '">' + (alarm ? '<div class="fill err" style="width:100%"></div>' : '<div class="fill disk" style="width:' + pct.toFixed(0) + '%"></div>') + '<span>' + U.fmtBytes(n.l_disk) + '</span></div><div class="bar-sub' + (alarm ? ' err-text' : '') + '">' + (alarm ? '<b>disk alarm</b> · ' : '') + U.fmtBytes(n.disk_free_limit) + ' low watermark</div>';
    }
  };

  P.nodesTable = function () {
    return UI.listTable({
      id: 'nodes', paginate: false, rows: function () { return SIM.S.nodes; },
      cols: [
        { key: 'name', label: 'Name', render: function (n) { return '<a class="namepill" href="#/nodes/' + U.enc(n.name) + '">' + esc(n.name) + '</a>'; } },
        { key: 'fd', label: 'File descriptors', help: 'fd', nosort: true, render: function (n) { return n.running ? P.nodeBars.fd(n) : ''; } },
        { key: 'proc', label: 'Erlang processes', help: 'erlang-processes', nosort: true, render: function (n) { return n.running ? P.nodeBars.proc(n) : ''; } },
        { key: 'mem', label: 'Memory', help: 'memory', nosort: true, render: function (n) { return n.running ? P.nodeBars.mem(n) : ''; } },
        { key: 'disk', label: 'Disk space', help: 'disk', nosort: true, render: function (n) { return n.running ? P.nodeBars.disk(n) : ''; } },
        { key: 'uptime', label: 'Uptime', help: 'uptime', sort: function (n) { return SIM.uptime(n); }, render: function (n) { return n.running ? U.fmtUptime(SIM.uptime(n)) : '<span class="err-text"><b>Node not running</b></span>'; } },
        { key: 'cores', label: 'Cores', help: 'cores' },
        { key: 'info', label: 'Info', nosort: true, render: function (n) {
          if (!n.running) return '';
          return '<abbr class="info-b" title="Message rates mode: basic" data-help="info-rates-mode">basic</abbr><abbr class="info-b" title="' + n.enabled_plugins.length + ' explicitly enabled plugins: ' + esc(n.enabled_plugins.join(', ')) + '" data-help="info-plugins">' + n.enabled_plugins.length + '</abbr><abbr class="info-b" title="Memory calculation strategy: rss" data-help="info-mem-calc">rss</abbr>';
        } },
        { key: 'reset', label: 'Reset stats', help: 'reset-stats', nosort: true, render: function (n) { return '<button class="small" data-action="reset-stats" data-node="' + esc(n.name) + '">This node</button> <button class="small" data-action="reset-stats">All nodes</button>'; } },
        { key: 'run_queue', label: 'Run queue', hidden: true, render: function (n) { return n.l_runq; } },
        { key: 'sockets', label: 'Sockets', hidden: true, render: function (n) { return n.sockets_used + ' / ' + n.sockets_total; } },
        { key: 'os_pid', label: 'OS PID', hidden: true }
      ]
    });
  };

  P.churn = function () {
    return UI.block(function () {
      var c = SIM.S.churn;
      function v(x) { return U.fmtRate(U.jitter(x, 0.4)); }
      return '<div class="facts-cols">' +
        UI.facts([['Connection operations', ''], ['Created', v(c.conn_created)], ['Closed', v(c.conn_closed)]]) +
        UI.facts([['Channel operations', ''], ['Created', v(c.ch_created)], ['Closed', v(c.ch_closed)]]) +
        UI.facts([['Queue operations', ''], ['Declared', v(c.q_declared)], ['Created', v(c.q_created)], ['Deleted', v(c.q_deleted)]]) + '</div>' +
        '<div class="edu-note"><b>İpucu:</b> Sağlıklı bir sistemde churn değerleri düşüktür. Connection "Created" oranı publish oranına yakınsa bir uygulama her mesaj için yeni bağlantı açıyordur.</div>';
    });
  };

  P.ports = function () {
    var S = SIM.S;
    var rows = [];
    S.nodes.forEach(function (n) { S.ports.forEach(function (p) { rows.push('<tr><td>' + esc(p.protocol) + '</td><td>' + esc(n.name) + '</td><td>' + esc(p.bound_to) + '</td><td class="r">' + p.port + '</td></tr>'); }); });
    var ctx = [];
    S.nodes.forEach(function (n) { S.contexts.forEach(function (c) { ctx.push('<tr><td>' + esc(c.context) + '</td><td>' + esc(n.name) + '</td><td>' + c.bound_to + '</td><td class="r">' + c.port + '</td><td class="c">' + UI.bool(c.ssl) + '</td><td>' + c.path + '</td></tr>'); }); });
    return '<h3>Listening ports ' + UI.help('ports') + '</h3><table class="list"><thead><tr><th>Protocol</th><th>Node</th><th>Bound to</th><th class="r">Port</th></tr></thead><tbody>' + rows.join('') + '</tbody></table>' +
      '<h3>Web contexts</h3><table class="list"><thead><tr><th>Context</th><th>Node</th><th>Bound to</th><th class="r">Port</th><th>SSL</th><th>Path</th></tr></thead><tbody>' + ctx.join('') + '</tbody></table>';
  };

  P.definitions = function (vhost) {
    var S = SIM.S;
    function vf(x) { return !vhost || x.vhost === vhost; }
    var d = {
      rabbit_version: S.version, rabbitmq_version: S.version, product_name: 'RabbitMQ', product_version: S.version,
      users: vhost ? undefined : S.users.map(function (u) { return { name: u.name, password_hash: '<hash>', hashing_algorithm: u.hashing, tags: u.tags, limits: {} }; }),
      vhosts: vhost ? undefined : S.vhosts.map(function (v) { return { name: v.name, description: v.description, tags: v.tags, default_queue_type: v.default_queue_type, metadata: { description: v.description, tags: v.tags, default_queue_type: v.default_queue_type } }; }),
      permissions: vhost ? undefined : S.permissions,
      topic_permissions: vhost ? undefined : S.topic_permissions,
      parameters: S.fed_upstreams.filter(vf).map(function (u) { return { vhost: u.vhost, component: 'federation-upstream', name: u.name, value: { uri: u.uri, exchange: u.exchange, 'max-hops': u.max_hops, 'ack-mode': u.ack_mode, 'prefetch-count': u.prefetch_count, expires: u.expires } }; })
        .concat(S.shovels.filter(function (s) { return s.type === 'dynamic' && vf(s); }).map(function (s) { return { vhost: s.vhost, component: 'shovel', name: s.name, value: { 'src-protocol': s.src_protocol, 'src-uri': s.src_uri, 'src-queue': s.src_queue || undefined, 'dest-protocol': s.dest_protocol, 'dest-uri': s.dest_uri, 'dest-exchange': s.dest_exchange || undefined, 'ack-mode': s.ack_mode } }; })),
      global_parameters: vhost ? undefined : [{ name: 'cluster_name', value: S.cluster_name }],
      policies: S.policies.filter(vf).map(function (p) { return { vhost: p.vhost, name: p.name, pattern: p.pattern, 'apply-to': p.apply_to, definition: p.definition, priority: p.priority }; }),
      queues: S.queues.filter(function (q) { return vf(q) && !q.exclusive; }).map(function (q) { return { name: q.name, vhost: q.vhost, durable: q.durable, auto_delete: q.auto_delete, arguments: q.arguments }; }),
      exchanges: S.exchanges.filter(function (e) { return vf(e) && !e.builtin; }).map(function (e) { return { name: e.name, vhost: e.vhost, type: e.type, durable: e.durable, auto_delete: e.auto_delete, internal: e.internal, arguments: e.arguments }; }),
      bindings: S.bindings.filter(vf).map(function (b) { return { source: b.source, vhost: b.vhost, destination: b.destination, destination_type: b.destination_type, routing_key: b.routing_key, arguments: b.arguments }; })
    };
    return JSON.stringify(d, null, 2);
  };
  P.exportDefs = function () {
    var d = new Date();
    var fname = 'rabbit_mq-node-01_' + d.getFullYear() + '-' + U.pad(d.getMonth() + 1) + '-' + U.pad(d.getDate()) + '.json';
    return '<form data-form="export-defs"><table class="form">' +
      UI.formRow('Filename for download', '<input type="text" name="filename" value="' + fname + '">') +
      UI.formRow('Virtual host', UI.select('vhost', [['', 'All']].concat(SIM.S.vhosts.map(function (v) { return [v.name, v.name]; })), App.vhost || '')) +
      '</table><button type="submit">Download broker definitions</button> ' + UI.help('definitions-export') +
      '<p class="muted small">Simülasyondaki topoloji, gerçek RabbitMQ definitions formatında JSON olarak indirilir (parola hash\'leri yer tutucudur).</p></form>';
  };
  P.importDefs = function () {
    return '<form data-form="import-defs"><table class="form">' +
      UI.formRow('Definitions file', '<input type="file" name="file" accept=".json,application/json">', null, true) +
      UI.formRow('Virtual host', UI.select('vhost', [['', 'All']].concat(SIM.S.vhosts.map(function (v) { return [v.name, v.name]; })), '')) +
      '</table><button type="submit">Upload broker definitions</button> ' + UI.help('definitions-import') + '</form>';
  };

  /* ---------------- Node detay ---------------- */
  P.node = function (name) {
    var n = SIM.node(name);
    if (!n) return P.notFound('Node', name);
    var h = ['<h1>Node <b>' + esc(n.name) + '</b> ' + UI.help('nodes') + '</h1>'];
    if (!n.running) h.push('<div class="form-msg err"><b>Node not running.</b> Bu node simülasyonda durdurulmuş (Admin → Cluster). Classic kuyrukları "down", quorum kuyruk leader\'ları diğer node\'lara taşınmıştır.</div>');
    h.push(UI.section('Overview', UI.block(function () {
      return '<div class="facts-cols">' + UI.facts([
        ['Uptime', n.running ? U.fmtUptime(SIM.uptime(n)) : '-', 'uptime'],
        ['RabbitMQ version', SIM.S.version, 'version'],
        ['Erlang version', SIM.S.erlang, 'erlang'],
        ['Type', 'disc', 'cluster'],
        ['Cores', n.cores, 'cores'],
        ['OS pid', n.os_pid],
        ['Net ticktime', n.net_ticktime + 's', 'net-ticktime'],
        ['Rates mode', 'basic', 'info-rates-mode'],
        ['Memory calculation strategy', n.mem_calc, 'info-mem-calc']
      ]) + '<table class="list"><thead><tr><th>File descriptors ' + UI.help('fd') + '</th><th>Erlang processes ' + UI.help('erlang-processes') + '</th><th>Memory ' + UI.help('memory') + '</th><th>Disk space ' + UI.help('disk') + '</th></tr></thead><tbody><tr>' +
        (n.running ? '<td>' + P.nodeBars.fd(n) + '</td><td>' + P.nodeBars.proc(n) + '</td><td>' + P.nodeBars.mem(n) + '</td><td>' + P.nodeBars.disk(n) + '</td>' : '<td colspan="4" class="empty">Node not running</td>') +
        '</tr></tbody></table></div>';
    }), { id: 'node-ov' }));

    h.push(UI.section('Memory details', UI.block(function () { return memBreakdown(n); }), { id: 'node-mem', help: 'node-memory-breakdown' }));

    h.push(UI.section('Advanced', UI.chart({
      id: 'node-mem-chart-' + n.name, title: 'Memory usage', help: 'memory', unit: 'bytes', legendCols: 1,
      get: function (range) {
        var e = SIM.hist.n[n.name];
        return { times: SIM.slice(SIM.hist.t, range), series: [{ key: 'mem', label: 'Used', color: '#edc240', data: SIM.slice(e.mem, range), value: U.fmtBytes(e.mem[e.mem.length - 1]) }] };
      }
    }) + UI.chart({
      id: 'node-proc-chart-' + n.name, title: 'Erlang processes / File descriptors', help: 'erlang-processes', legendCols: 1,
      get: function (range) {
        var e = SIM.hist.n[n.name];
        return { times: SIM.slice(SIM.hist.t, range), series: [
          { key: 'proc', label: 'Processes', color: '#afd8f8', data: SIM.slice(e.proc, range), value: U.fmtNum(e.proc[e.proc.length - 1]) },
          { key: 'fd', label: 'File desc.', color: '#cb4b4b', data: SIM.slice(e.fd, range), value: U.fmtNum(e.fd[e.fd.length - 1]) }
        ] };
      }
    }), { id: 'node-adv', closed: true }));

    h.push(UI.section('Plugins', '<table class="list"><thead><tr><th>Name</th><th>Version</th><th>Description</th></tr></thead><tbody>' + [
      ['rabbitmq_management', 'RabbitMQ Management Console'], ['rabbitmq_management_agent', 'RabbitMQ Management Agent'], ['rabbitmq_web_dispatch', 'RabbitMQ Web Dispatcher'],
      ['rabbitmq_federation', 'RabbitMQ Federation'], ['rabbitmq_federation_management', 'RabbitMQ Federation Management'], ['rabbitmq_shovel', 'Data Shovel for RabbitMQ'],
      ['rabbitmq_shovel_management', 'Shovel Status'], ['rabbitmq_prometheus', 'Prometheus metrics for RabbitMQ'], ['rabbitmq_stream', 'RabbitMQ Stream'],
      ['rabbitmq_stream_management', 'RabbitMQ Stream Management'], ['rabbitmq_mqtt', 'RabbitMQ MQTT Adapter'], ['amqp_client', 'RabbitMQ AMQP Client']
    ].map(function (p) { return '<tr><td>' + p[0] + '</td><td>' + SIM.S.version + '</td><td>' + p[1] + '</td></tr>'; }).join('') + '</tbody></table>' +
      '<p class="muted small">Açıkça etkinleştirilenler: ' + esc(n.enabled_plugins.join(', ')) + ' ' + UI.help('info-plugins') + '</p>', { id: 'node-plugins', closed: true }));

    h.push(UI.section('Config, log and data files', UI.facts([
      ['Config file', n.config_files.map(esc).join('<br>'), 'config-files'],
      ['Log file', n.log_files.map(esc).join('<br>')],
      ['Database directory', esc(n.db_dir)],
      ['Erlang runtime', '<span class="small mono">' + esc(n.erlang_full) + '</span>', 'erlang']
    ]), { id: 'node-files', closed: true }));
    return h.join('');
  };

  function memBreakdown(n) {
    var total = n.l_mem || n.mem_used;
    var parts = [
      ['Connection readers', 0.035, '#9e6b2f'], ['Connection writers', 0.012, '#c08a46'], ['Connection channels', 0.05, '#d9a86a'], ['Connection other', 0.06, '#e8c690'],
      ['Quorum queues', 0.13, '#2f6d8c'], ['Classic queues', 0.025, '#4c8fb1'], ['Stream queues', 0.04, '#6b5a1f'], ['Stream replicas', 0.02, '#8b7a3f'], ['Queue workers', 0.01, '#7fb5d1'],
      ['Binaries', 0.11, '#cb4b4b'], ['Metadata store', 0.04, '#4da74d'], ['Management DB', 0.07, '#9440ed'], ['Plugins', 0.03, '#b88df2'],
      ['Other ETS tables', 0.05, '#666'], ['Code', 0.09, '#888'], ['Atoms', 0.01, '#999'], ['Other system', 0.12, '#aaa'], ['Allocated unused', 0.048, '#555']
    ];
    var bar = parts.map(function (p) { return '<div title="' + p[0] + ': ' + U.fmtBytes(total * p[1]) + '" style="width:' + (p[1] * 100).toFixed(2) + '%;background:' + p[2] + '"></div>'; }).join('');
    var leg = parts.map(function (p) { return '<div><span class="sw" style="background:' + p[2] + '"></span>' + p[0] + '<span class="v">' + U.fmtBytes(total * p[1]) + ' (' + (p[1] * 100).toFixed(1) + '%)</span></div>'; }).join('');
    return '<p>Toplam: <b>' + U.fmtBytes(total) + '</b> / high watermark ' + U.fmtBytes(n.mem_limit) + '</p><div class="mem-bar">' + bar + '</div><div class="mem-legend">' + leg + '</div>';
  }

  P.notFound = function (kind, name) {
    return '<h1>' + esc(kind) + ' bulunamadı</h1><p>"' + esc(name) + '" mevcut değil. Silinmiş veya hiç oluşturulmamış olabilir.</p><p><a href="#/">Overview\'a dön</a></p>';
  };
})(window);
