/* =========================================================================
   Yardım içerikleri – Bölüm 1: Temel kavramlar, Overview, Connections, Channels
   Alanlar:
     t    : başlık            term : İngilizce/teknik terim
     cat  : kategori          what : Nedir?
     role : RabbitMQ içindeki görevi
     use  : Ne amaçla kullanılır?
     when : Ne zaman kullanılmalı? (string veya dizi)
     benefit : Sağladığı fayda
     ex   : Teknik örnek (kod)  note : sürüm/uyarı notu
     rel  : ilişkili konular
   ========================================================================= */
(function (w) {
  'use strict';
  var H = w.HELP = w.HELP || {};
  function h(k, o) { H[k] = o; }

  /* ========================= TEMEL KAVRAMLAR ========================= */
  h('connection', {
    t: 'Connections', term: 'Bağlantı (TCP / AMQP connection)', cat: 'Temel kavramlar',
    what: 'Bir istemci uygulamasının (publisher veya consumer) RabbitMQ node\'una açtığı uzun ömürlü ağ bağlantısıdır. AMQP 0-9-1, AMQP 1.0, MQTT, STOMP veya RabbitMQ Stream protokolü üzerinden kurulabilir.',
    role: 'Kimlik doğrulama (authentication), virtual host seçimi, heartbeat ve TLS gibi işlemler bağlantı seviyesinde yapılır. Bir bağlantı, hangi kullanıcının hangi vhost\'a hangi node üzerinden bağlandığını belirler. AMQP 0-9-1\'de bağlantının içinde birden çok <b>channel</b> çalışır.',
    use: 'Uygulamaların broker ile iletişim kurabilmesi için zorunludur. Management UI\'daki Connections sekmesi; hangi uygulamanın, hangi IP/port üzerinden, hangi protokol ve kullanıcıyla bağlı olduğunu, ne kadar trafik ürettiğini ve durumunu (running, blocked, flow) gösterir.',
    when: ['Bir servisin broker\'a gerçekten bağlanıp bağlanmadığını kontrol ederken', 'Bağlantı sızıntısı (connection leak) şüphesinde – bağlantı sayısı sürekli artıyorsa', 'Memory/disk alarmı sırasında hangi publisher\'ların <code>blocked</code> olduğunu görmek için', 'Bir istemciyi zorla kapatmak (Force close) gerektiğinde'],
    benefit: 'Bağlantı başına trafik, kanal sayısı ve client properties bilgisi ile sorunlu istemcileri hızlıca tespit edersiniz. <b>En iyi uygulama:</b> her uygulama süreci az sayıda uzun ömürlü bağlantı açmalı; her mesaj için yeni bağlantı açmak ciddi performans kaybıdır.',
    ex: `// .NET (RabbitMQ.Client 7.x)
var factory = new ConnectionFactory {
    HostName = "mq-node-01", VirtualHost = "orders",
    UserName = "order-service", Password = "***",
    ClientProvidedName = "order-api-1 (publisher)"   // UI'da Name kolonunda görünür
};
await using var conn = await factory.CreateConnectionAsync();`,
    rel: ['channel', 'conn-state', 'heartbeat', 'client-properties', 'protocol']
  });

  h('channel', {
    t: 'Channels', term: 'Kanal (AMQP 0-9-1 channel)', cat: 'Temel kavramlar',
    what: 'Tek bir TCP bağlantısı içinde açılan hafif, mantıksal oturumlardır. AMQP 0-9-1 protokolünde publish, consume, declare, ack gibi tüm işlemler bir channel üzerinden yapılır.',
    role: 'Bir bağlantıyı çoklamak (multiplexing) için kullanılır; böylece tek TCP bağlantısı üzerinden birden fazla bağımsız iş akışı yürütülebilir. Prefetch (QoS), publisher confirm ve transaction modları channel seviyesinde ayarlanır.',
    use: 'Uygulama içinde farklı iş parçacıkları (thread) veya farklı tüketiciler için ayrı channel açmak yaygındır. UI\'da her channel için prefetch, unacked, unconfirmed ve mesaj oranları izlenir.',
    when: ['Consumer\'ların prefetch ayarını ve unacked birikmesini kontrol ederken', 'Publisher confirm kullanılıp kullanılmadığını (Mode: C) doğrularken', 'Kanal sızıntısı (channel leak) şüphesinde – kanal sayısı bağlantı sayısından çok hızlı artıyorsa'],
    benefit: 'Bağlantı açmaktan çok daha ucuzdur. Doğru kullanıldığında az sayıda bağlantı ile yüksek paralellik sağlar.',
    ex: `// Her consumer için ayrı channel ve prefetch
var ch = await conn.CreateChannelAsync();
await ch.BasicQosAsync(prefetchSize: 0, prefetchCount: 20, global: false);`,
    note: 'Channel\'lar çoğu istemci kütüphanesinde thread-safe değildir; aynı channel\'ı eşzamanlı birden çok thread\'den kullanmayın. AMQP 1.0, MQTT ve Stream protokollerinde channel kavramı yoktur (AMQP 1.0\'da session/link vardır).',
    rel: ['connection', 'prefetch', 'ch-mode', 'ch-unacked']
  });

  h('exchange', {
    t: 'Exchanges', term: 'Exchange (yönlendirici)', cat: 'Temel kavramlar',
    what: 'Publisher\'ların mesaj gönderdiği varlıktır. Exchange mesajı saklamaz; mesajı <b>binding</b> kurallarına göre bir veya daha fazla queue\'ya (ya da başka exchange\'e) yönlendirir.',
    role: 'RabbitMQ\'nun yönlendirme (routing) motorudur. Tipine göre (direct, fanout, topic, headers, x-local-random) routing key veya header\'lara bakarak hedefleri belirler. Eşleşen hedef yoksa mesaj düşürülür (unroutable) ya da <code>mandatory</code> bayrağı ile publisher\'a geri döner veya alternate exchange\'e gider.',
    use: 'Üretici ile tüketiciyi birbirinden ayırmak (decoupling) için kullanılır. Publisher yalnızca exchange adını ve routing key\'i bilir; hangi kuyruklara gittiğini bilmek zorunda değildir.',
    when: ['Bir olayı birden çok servise dağıtmak (fanout / topic)', 'Komutları tek bir hedefe yönlendirmek (direct)', 'Mesaj özelliklerine göre içerik tabanlı yönlendirme (headers)'],
    benefit: 'Yeni bir tüketici eklemek için publisher kodunu değiştirmeden sadece yeni bir queue ve binding eklemek yeterlidir.',
    ex: `// "orders.events" topic exchange'ine yayın
await ch.BasicPublishAsync(exchange: "orders.events",
    routingKey: "order.created.tr", body: payload);`,
    rel: ['ex-type-direct', 'ex-type-fanout', 'ex-type-topic', 'ex-type-headers', 'binding', 'alternate-exchange']
  });

  h('queue', {
    t: 'Queues and Streams', term: 'Kuyruk (Queue) ve Stream', cat: 'Temel kavramlar',
    what: 'Mesajların tüketilene kadar saklandığı sıralı (FIFO) veri yapısıdır. RabbitMQ 4.x\'te üç tip vardır: <b>Classic</b>, <b>Quorum</b> ve <b>Stream</b>.',
    role: 'Exchange tarafından yönlendirilen mesajları tutar ve consumer\'lara dağıtır (round-robin, prefetch sınırı dahilinde). Consumer mesajı <b>ack</b>\'leyene kadar mesaj <i>unacked</i> durumundadır; ack gelmeden bağlantı koparsa mesaj yeniden kuyruğa döner (redelivery).',
    use: 'İş yükünü tamponlamak (buffer), servisleri asenkron hale getirmek, yük dengelemek (competing consumers) ve geçici arızalarda mesaj kaybını önlemek için kullanılır.',
    when: ['Arka plan işleri (job queue), sipariş/ödeme gibi güvenilir iş akışları → <b>Quorum</b>', 'Geçici, yüksek hızlı, replikasyon gerektirmeyen veriler, exclusive/reply kuyrukları → <b>Classic</b>', 'Mesajı birden çok kez okuma, tekrar oynatma (replay), çok büyük hacim → <b>Stream</b>'],
    benefit: 'Üretici ile tüketici hızları farklı olsa bile sistem çalışmaya devam eder; tüketici çöktüğünde mesajlar kuyrukta bekler.',
    ex: `// Quorum queue tanımlama
await ch.QueueDeclareAsync("orders.created", durable: true,
    exclusive: false, autoDelete: false,
    arguments: new Dictionary<string, object?> { ["x-queue-type"] = "quorum" });`,
    rel: ['queue-type-classic', 'queue-type-quorum', 'queue-type-stream', 'ready', 'unacked', 'consumer']
  });

  h('binding', {
    t: 'Bindings', term: 'Binding (bağlama kuralı)', cat: 'Temel kavramlar',
    what: 'Bir exchange ile bir queue (veya başka bir exchange) arasındaki yönlendirme kuralıdır. "Bu exchange\'e gelen ve şu koşula uyan mesajları şu hedefe gönder" anlamına gelir.',
    role: 'Exchange tipine göre <b>routing key</b> (direct/topic) veya <b>arguments</b> (headers) ile eşleşme kriterini tanımlar. Binding olmadan exchange mesajı hiçbir yere iletemez.',
    use: 'Tüketicinin hangi mesajları almak istediğini tanımlamak için. Örneğin yalnızca <code>order.paid.*</code> olaylarını almak.',
    when: ['Yeni bir servis bir olay akışına abone olacaksa', 'Exchange-to-exchange (E2E) topolojilerle katmanlı yönlendirme kurarken', 'Dead letter exchange ile DLQ arasında bağlantı kurarken'],
    benefit: 'Yönlendirme mantığı uygulama kodundan çıkıp broker topolojisine taşınır; çalışma anında değiştirilebilir.',
    ex: `await ch.QueueBindAsync(queue: "orders.paid",
    exchange: "orders.events", routingKey: "order.paid.*");`,
    note: 'Default exchange ("") için her queue otomatik olarak kendi adıyla bağlıdır; bu binding silinemez ve UI\'da "(Default exchange binding)" olarak gösterilir.',
    rel: ['binding-routing-key', 'binding-args', 'e2e-binding', 'ex-default']
  });

  h('consumer', {
    t: 'Consumers', term: 'Tüketici', cat: 'Temel kavramlar',
    what: 'Bir kuyruğa abone olup (<code>basic.consume</code>) mesajları push yöntemiyle alan uygulama bileşenidir.',
    role: 'Kuyruktaki mesajları işler ve işlem başarılıysa <b>ack</b>, başarısızsa <b>nack/reject</b> gönderir. Bir kuyrukta birden çok consumer varsa RabbitMQ mesajları aralarında round-robin dağıtır (competing consumers).',
    use: 'İş yükünü yatay ölçeklemek için aynı kuyruğa birden çok consumer bağlanır. UI\'da consumer tag, channel, prefetch, ack modu ve aktiflik durumu görülür.',
    when: ['Kuyrukta "Ready" sayısı sürekli artıyorsa consumer sayısını artırmayı düşünün', 'Consumers: 0 olan kuyruklar genellikle bir servisin çöktüğünü gösterir', 'Sıralamanın kritik olduğu durumlarda Single Active Consumer kullanın'],
    benefit: 'Push modeli (basic.consume) polling\'e (basic.get) göre çok daha verimlidir ve düşük gecikme sağlar.',
    ex: `var consumer = new AsyncEventingBasicConsumer(ch);
consumer.ReceivedAsync += async (_, ea) => {
    await HandleAsync(ea.Body);
    await ch.BasicAckAsync(ea.DeliveryTag, multiple: false);
};
await ch.BasicConsumeAsync("orders.created", autoAck: false, consumer);`,
    rel: ['ack-required', 'prefetch', 'sac', 'consumer-tag', 'activity-status']
  });

  h('publisher', {
    t: 'Publishers', term: 'Yayıncı / Üretici', cat: 'Temel kavramlar',
    what: 'RabbitMQ\'ya mesaj gönderen uygulamadır. Mesajlar her zaman bir exchange\'e (adı boş olan default exchange dahil) gönderilir, doğrudan kuyruğa değil.',
    role: 'Mesajı routing key, properties (delivery_mode, content_type, headers, message_id...) ve body ile birlikte exchange\'e iletir. Güvenilirlik için <b>publisher confirms</b> kullanır.',
    use: 'Olay yayınlama (event), komut gönderme (command) ve RPC istekleri için. UI\'da publisher\'lar ayrı bir sekmede değil; Channels sekmesindeki <i>publish</i> oranlarından ve Connections sekmesindeki <i>From client</i> trafiğinden izlenir.',
    when: ['Mesaj kaybının kabul edilemediği durumlarda confirm modunu açın', 'Yönlendirilemeyen mesajları fark etmek için <code>mandatory=true</code> veya alternate exchange kullanın', 'Memory/disk alarmında publisher\'lar <b>blocked</b> olur; bunu <code>connection.blocked</code> bildirimiyle yakalayın'],
    benefit: 'Doğru yapılandırılmış bir publisher (confirm + persistent mesaj + durable kuyruk) mesajların broker\'a ulaştığını garanti eder.',
    ex: `await using var ch = await conn.CreateChannelAsync(
    new CreateChannelOptions(publisherConfirmationsEnabled: true,
                             publisherConfirmationTrackingEnabled: true));
var props = new BasicProperties { Persistent = true, ContentType = "application/json" };
await ch.BasicPublishAsync("orders.events", "order.created.tr", true, props, body);`,
    rel: ['rate-confirm', 'confirm-mode', 'delivery-mode', 'alternate-exchange', 'conn-state']
  });

  h('vhost', {
    t: 'Virtual Hosts', term: 'Sanal host (vhost)', cat: 'Temel kavramlar',
    what: 'RabbitMQ içinde exchange, queue, binding, policy, kullanıcı izinleri gibi kaynakları mantıksal olarak ayıran izole alanlardır. Bir broker içinde birden çok "mini broker" gibi düşünülebilir.',
    role: 'Her bağlantı tek bir vhost\'a bağlanır. Farklı vhost\'lardaki aynı isimli kuyruklar birbirinden tamamen bağımsızdır. Yetkiler (permissions) vhost bazında verilir; limitler (max-connections, max-queues) vhost bazında konabilir.',
    use: 'Çok kiracılı (multi-tenant) yapılarda, ortamları (dev/test) veya iş alanlarını (orders, payments) ayırmak için kullanılır.',
    when: ['Farklı ekiplerin/uygulamaların kaynaklarını ve yetkilerini izole etmek istediğinizde', 'Bir alanın kaynak tüketimini limitlerle sınırlamak istediğinizde', 'Aynı kuyruk adlarının farklı bağlamlarda çakışmasını önlemek için'],
    benefit: 'Güvenlik (en az yetki ilkesi), yönetim kolaylığı ve kaynak izolasyonu sağlar. 4.x\'te her vhost için <b>default queue type</b> belirlenebilir.',
    ex: `rabbitmqctl add_vhost payments --description "Ödeme akışları" \\
    --default-queue-type quorum --tags prod,pci
rabbitmqctl set_permissions -p payments payment-service "^payments\\..*" "^payments\\..*" "^payments\\..*"`,
    note: 'Vhost adı "/" olan varsayılan vhost, URL\'lerde <code>%2F</code> olarak kodlanır.',
    rel: ['permissions', 'vhost-default-qt', 'limits-vhost', 'vhost-select']
  });

  h('user', {
    t: 'Users', term: 'Kullanıcılar ve yetkilendirme', cat: 'Temel kavramlar',
    what: 'RabbitMQ\'ya bağlanan uygulamaların ve yöneticilerin kimlikleridir. Her kullanıcının parola (hash olarak saklanır) veya sertifika tabanlı kimliği, <b>tag</b>\'leri ve vhost bazlı <b>permission</b>\'ları vardır.',
    role: 'Kimlik doğrulama (authentication) ile kim olduğunuzu, yetkilendirme (authorization) ile ne yapabileceğinizi belirler. Tag\'ler Management UI/HTTP API erişimini; permission\'lar ise AMQP kaynaklarına (configure/write/read) erişimi kontrol eder.',
    use: 'Her uygulama için ayrı kullanıcı oluşturup yalnızca ihtiyacı olan vhost ve kaynaklara izin vermek için.',
    when: ['Yeni bir servis devreye alınırken', 'Yetkileri en az yetki prensibine göre daraltırken', 'LDAP / OAuth 2.0 / x509 sertifika gibi harici kimlik doğrulama entegrasyonlarında'],
    benefit: 'Bir uygulamanın hatası veya ele geçirilmesi diğer alanları etkilemez. Bağlantıları kullanıcı adına göre izlemek sorun tespitini kolaylaştırır.',
    ex: `rabbitmqctl add_user order-service 'S3cr3t!'
rabbitmqctl set_user_tags ops-team policymaker
rabbitmqctl set_permissions -p orders order-service "^orders\\..*" "^orders\\..*" "^orders\\..*"`,
    note: '<code>guest</code> kullanıcısı varsayılan olarak yalnızca localhost\'tan bağlanabilir (<code>loopback_users</code>). Üretimde silinmesi veya devre dışı bırakılması önerilir.',
    rel: ['user-tags', 'permissions', 'topic-permissions', 'limits-user']
  });

  h('policy', {
    t: 'Policies', term: 'Politikalar', cat: 'Temel kavramlar',
    what: 'Ad deseni (regex pattern) ile eşleşen queue ve/veya exchange\'lere çalışma anında ayar uygulayan kurallardır (TTL, max-length, dead-lettering, federation, stream retention vb.).',
    role: 'Uygulama kodunu değiştirmeden ve kuyrukları yeniden oluşturmadan davranış değiştirmeyi sağlar. Bir nesneye aynı anda yalnızca <b>bir</b> policy uygulanır: eşleşenlerden <b>priority</b> değeri en yüksek olan. Operator policy\'ler ise bunun üzerine ek bir güvenlik katmanı olarak birleşir.',
    use: 'Kuyruk argümanlarını (x-*) koda gömmek yerine merkezi ve değiştirilebilir şekilde yönetmek için kullanılır. RabbitMQ ekibi de ayarların mümkün olduğunca policy ile verilmesini önerir.',
    when: ['Tüm sipariş kuyruklarına DLX ve delivery-limit uygulamak', 'Stream\'lerin saklama süresini (max-age) belirlemek', 'Exchange\'leri federation\'a dahil etmek', 'Kuyruk uzunluğunu sınırlamak (max-length + overflow)'],
    benefit: 'Topolojiyi bozmadan, canlı ortamda anında değişiklik yapılabilir; tutarlı ve denetlenebilir yapılandırma sağlar.',
    ex: `rabbitmqctl set_policy -p orders orders-qq-defaults \\
  '^orders\\.(created|paid)$' \\
  '{"dead-letter-exchange":"orders.dlx","delivery-limit":10}' \\
  --apply-to quorum_queues --priority 10`,
    note: 'Bazı argümanlar (ör. <code>x-queue-type</code>, <code>x-max-priority</code>) policy ile değiştirilemez; bunlar yalnızca kuyruk oluşturulurken verilir. Argüman ve policy aynı ayarı veriyorsa genellikle argüman (veya daha kısıtlayıcı değer) geçerli olur.',
    rel: ['policy-pattern', 'policy-apply-to', 'policy-priority', 'policy-definition', 'operator-policy']
  });

  h('federation', {
    t: 'Federation', term: 'Federation eklentisi', cat: 'Temel kavramlar',
    what: 'Farklı broker\'lar veya cluster\'lar arasında (genellikle WAN/farklı veri merkezleri) exchange ya da queue seviyesinde mesaj aktarımı sağlayan eklentidir (<code>rabbitmq_federation</code>).',
    role: 'Downstream (yerel) broker, upstream (uzak) broker\'a AMQP 0-9-1 bağlantısı açar. <b>Exchange federation</b>\'da upstream\'deki exchange\'e yayınlanan mesajlar downstream exchange\'e kopyalanır. <b>Queue federation</b>\'da ise downstream kuyrukta consumer varken ve mesaj yokken upstream kuyruktan mesaj çekilir.',
    use: 'Coğrafi olarak dağıtık sistemlerde, gevşek bağlı (loosely coupled) ve gecikmeye toleranslı mesaj paylaşımı için.',
    when: ['Veri merkezleri arasında olay dağıtımı', 'Clustering\'in uygun olmadığı yüksek gecikmeli ağlar', 'Farklı sürüm/yönetim alanındaki broker\'ları bağlarken'],
    benefit: 'Cluster\'dan farklı olarak ağ kesintilerine dayanıklıdır; broker\'lar bağımsız kalır ve bağlantı geri geldiğinde aktarım devam eder.',
    ex: `rabbitmqctl set_parameter federation-upstream dc2-orders \\
 '{"uri":"amqps://federation-user:***@dc2-mq:5671","exchange":"orders.events","max-hops":1}'
rabbitmqctl set_policy federate-orders "^federated\\." \\
 '{"federation-upstream-set":"all"}' --apply-to exchanges`,
    rel: ['fed-upstream', 'fed-links', 'shovel', 'cluster']
  });

  h('shovel', {
    t: 'Shovel', term: 'Shovel eklentisi', cat: 'Temel kavramlar',
    what: 'Bir kaynaktan (queue/exchange) mesajları okuyup başka bir hedefe (aynı veya farklı broker\'daki exchange/queue) güvenilir şekilde taşıyan "kürek" eklentisidir (<code>rabbitmq_shovel</code>).',
    role: 'Kendi içinde bir consumer ve publisher gibi çalışır: kaynaktan consume eder, hedefe publish eder ve onaylandıktan sonra (ack-mode: on-confirm) kaynağa ack gönderir. AMQP 0-9-1 ve AMQP 1.0 protokollerini destekler.',
    use: 'Veri taşıma (migration), broker\'lar arası köprü kurma, mesajları bir kuyruktan diğerine aktarma (ör. DLQ\'dan yeniden işleme).',
    when: ['Eski bir broker\'dan yenisine geçişte (blue/green migration)', 'DLQ\'daki mesajları ana kuyruğa geri taşırken', 'Federation\'ın sağlamadığı esneklik (farklı protokol, nokta-atışı taşıma) gerektiğinde'],
    benefit: 'Federation\'a göre daha düşük seviyeli ve daha esnektir; kaynak ve hedef tamamen sizin kontrolünüzdedir.',
    ex: `rabbitmqctl set_parameter shovel legacy-orders-migration \\
 '{"src-protocol":"amqp091","src-uri":"amqp://","src-queue":"legacy.orders",
   "dest-protocol":"amqp091","dest-uri":"amqp:///orders","dest-exchange":"orders.events",
   "ack-mode":"on-confirm"}'`,
    rel: ['shovel-type', 'shovel-ack-mode', 'shovel-delete-after', 'federation', 'move-messages']
  });

  h('cluster', {
    t: 'Clustering', term: 'RabbitMQ Cluster', cat: 'Temel kavramlar',
    what: 'Birden çok RabbitMQ node\'unun Erlang dağıtık sistemi üzerinden birleşerek tek bir mantıksal broker gibi davranmasıdır.',
    role: 'Kullanıcılar, vhost\'lar, exchange\'ler, bindings, policy\'ler gibi <b>metadata</b> tüm node\'lara kopyalanır. Kuyruk içerikleri ise kuyruk tipine bağlıdır: classic kuyruk tek bir node\'da yaşar; quorum queue ve stream birden çok node\'a replike edilir. İstemci herhangi bir node\'a bağlanıp tüm kuyruklara erişebilir.',
    use: 'Yüksek erişilebilirlik, yük dağıtımı ve kapasite artırımı için. Node\'lar 25672 (inter-node) ve 4369 (epmd) portları üzerinden haberleşir, ortak <b>Erlang cookie</b> kullanır.',
    when: ['Tek node arızasında hizmetin devam etmesi gerekiyorsa (en az 3 node önerilir)', 'Düşük gecikmeli LAN içinde (WAN için federation/shovel tercih edin)'],
    benefit: 'Quorum queue\'lar ile birlikte kullanıldığında bir node kaybında veri kaybı olmadan hizmet sürer.',
    ex: `# node-02 ve node-03'ü node-01'e katma
rabbitmqctl stop_app
rabbitmqctl join_cluster rabbit@mq-node-01
rabbitmqctl start_app
rabbitmqctl cluster_status`,
    note: '4.x ile birlikte metadata deposu olarak Raft tabanlı <b>Khepri</b> (khepri_db feature flag) desteklenir; Mnesia\'nın ağ bölünmesi (partition) sorunlarını ortadan kaldırmayı hedefler. Cluster node sayısı tek sayı (3, 5, 7) olmalıdır.',
    rel: ['ha', 'nodes', 'partitions', 'khepri', 'cluster-name']
  });

  h('ha', {
    t: 'High Availability', term: 'Yüksek erişilebilirlik ve veri sürekliliği', cat: 'Temel kavramlar',
    what: 'Bir veya daha fazla node arızalandığında mesajların kaybolmaması ve hizmetin kesintisiz devam etmesi için kullanılan mekanizmaların bütünüdür.',
    role: 'RabbitMQ 4.x\'te HA, <b>Quorum Queue</b> ve <b>Stream</b>\'lerin Raft tabanlı replikasyonu ile sağlanır. Bir quorum queue\'nun leader\'ı çökerse, kalan çoğunluk (majority) yeni bir leader seçer ve kuyruk çalışmaya devam eder. 3 üyeli bir kuyruk 1, 5 üyeli bir kuyruk 2 üyenin kaybına dayanır.',
    use: 'Kritik iş akışlarında (sipariş, ödeme) veri kaybını önlemek için uçtan uca güvenilirlik zinciri kurulmalıdır: durable quorum queue + persistent mesaj + publisher confirms + manual consumer ack + istemcide otomatik yeniden bağlanma.',
    when: ['Kaybedilmesi kabul edilemeyen mesajlarda', 'Bakım (rolling upgrade) sırasında kesinti istenmediğinde – node\'ları maintenance mode ile sırayla alın'],
    benefit: 'Planlı/plansız node kesintilerinde hizmet ve veri sürekliliği.',
    ex: `# Bir node'u bakım moduna alma (kuyruk leader'larını taşır, istemcileri diğer node'lara yönlendirir)
rabbitmq-upgrade drain
# Quorum kuyruklarının çoğunluğu kaybetmeden node kapatılabilir mi?
rabbitmq-diagnostics check_if_node_is_quorum_critical`,
    note: '<b>Önemli sürüm farkı:</b> Classic Mirrored Queues (ha-mode, ha-params, ha-sync-mode policy\'leri) RabbitMQ <b>4.0 ile tamamen kaldırılmıştır</b>. Eski dokümanlarda görülen "ha-mode: all" policy\'leri 4.x\'te çalışmaz; yerine quorum queue kullanılmalıdır.',
    rel: ['queue-type-quorum', 'cluster', 'q-members', 'confirm-mode', 'ack-required']
  });

  h('message', {
    t: 'Message', term: 'Mesaj yapısı', cat: 'Temel kavramlar',
    what: 'RabbitMQ\'da taşınan veri birimidir: <b>routing key</b>, <b>properties</b> (meta veriler) ve <b>payload/body</b> (bayt dizisi) bölümlerinden oluşur.',
    role: 'Broker payload içeriğine bakmaz; yönlendirme yalnızca exchange, routing key ve (headers exchange için) header\'lar üzerinden yapılır.',
    use: 'Properties alanı ile içerik tipi (content_type), kalıcılık (delivery_mode), öncelik (priority), TTL (expiration), korelasyon (correlation_id, reply_to) gibi bilgiler taşınır.',
    when: ['RPC (request/reply) senaryosunda reply_to ve correlation_id kullanın', 'Idempotent tüketici için message_id kullanın'],
    benefit: 'Standart properties sayesinde farklı dillerdeki istemciler birlikte çalışabilir.',
    ex: `delivery_mode = 2          // persistent
content_type  = application/json
message_id    = 7f6c1d0e-...
headers       = { "x-tenant": "tr", "x-retry": 0 }
body          = {"orderId":10231,"total":349.90}`,
    rel: ['delivery-mode', 'msg-properties', 'msg-headers', 'routing-key']
  });

  h('routing-key', {
    t: 'Routing Key', term: 'Yönlendirme anahtarı', cat: 'Temel kavramlar',
    what: 'Publisher\'ın mesajla birlikte gönderdiği, exchange\'in yönlendirme kararında kullandığı metindir (en fazla 255 bayt).',
    role: 'Direct exchange\'de binding key ile birebir eşleşir; topic exchange\'de nokta (.) ile ayrılmış kelimeler halinde <code>*</code> ve <code>#</code> joker karakterleriyle eşleşir; fanout ve headers exchange\'lerde dikkate alınmaz.',
    use: 'Mesajın türünü/konusunu belirtmek için: <code>order.created.tr</code>, <code>payment.refund.completed</code>.',
    when: ['Hiyerarşik olay adlandırmasında (alan.olay.bölge)'],
    benefit: 'İyi tasarlanmış routing key şeması, yeni tüketicilerin sadece ilgilendiği alt kümeye abone olmasını sağlar.',
    ex: `order.created.tr   → "order.created.#" ✔   "order.*" ✘   "order.*.tr" ✔`,
    rel: ['ex-type-topic', 'binding-routing-key']
  });

  /* ========================= HEADER / GENEL ========================= */
  h('sim-mode', {
    t: 'Eğitim Simülasyonu', term: 'Bu arayüz hakkında', cat: 'Arayüz',
    what: 'Bu site, RabbitMQ 4.1.x Management UI\'nın görünümünü ve davranışını taklit eden <b>eğitim amaçlı bir simülasyondur</b>. Gerçek bir broker\'a bağlanmaz, hiçbir HTTP API veya AMQP isteği göndermez.',
    role: 'Gördüğünüz tüm node, kuyruk, bağlantı ve oranlar tarayıcınızda üretilen örnek verilerdir. "Add queue", "Publish message", "Purge" gibi işlemler yalnızca tarayıcı belleğinde (localStorage) simüle edilir.',
    use: 'Arayüzü güvenle keşfetmek, her alanın yanındaki <b>?</b> ikonuna tıklayarak RabbitMQ kavramlarını öğrenmek için kullanın. Exchange sayfalarından mesaj yayınlayıp hangi kuyruklara yönlendirildiğini görmek iyi bir başlangıçtır.',
    when: ['Yaptığınız değişiklikleri sıfırlamak için sayfa altındaki "Simülasyonu sıfırla" bağlantısını kullanın.', 'Tüm konuları görmek için sayfa altındaki "Rehber / Sözlük" bağlantısını kullanın.'],
    benefit: 'Üretim ortamını riske atmadan RabbitMQ yönetimini öğrenme imkânı.'
  });

  h('version', {
    t: 'RabbitMQ sürümü', term: 'RabbitMQ 4.1.4', cat: 'Arayüz',
    what: 'Cluster\'da çalışan RabbitMQ sunucu sürümüdür.',
    role: 'Hangi özelliklerin mevcut olduğunu belirler. 4.0 ile: classic mirrored queue\'lar kaldırıldı, AMQP 1.0 çekirdeğe native olarak eklendi, Khepri desteklendi, quorum queue\'ya varsayılan delivery-limit (20) geldi. 4.1 ile: AMQP 1.0 filtreleri, yeni Kubernetes peer discovery, performans iyileştirmeleri geldi.',
    use: 'Sürüm uyumluluğunu, yükseltme planlamasını ve dokümantasyon seçimini doğru yapmak için.',
    when: ['Dokümantasyon okurken her zaman çalışan sürüme ait sayfaya bakın', 'Rolling upgrade öncesi tüm feature flag\'lerin etkin olduğunu doğrulayın'],
    benefit: 'Eski sürümlere ait (ör. ha-mode) yapılandırmaların yanlışlıkla uygulanmasını önler.',
    ex: `rabbitmqctl version
rabbitmq-diagnostics server_version`
  });
  h('erlang', {
    t: 'Erlang/OTP sürümü', term: 'Erlang 27.3.4.3', cat: 'Arayüz',
    what: 'RabbitMQ\'nun üzerinde çalıştığı Erlang/OTP çalışma zamanının (BEAM sanal makinesi) sürümüdür.',
    role: 'RabbitMQ Erlang ile yazılmıştır; süreç yönetimi, dağıtık iletişim (clustering), bellek yönetimi ve TLS gibi altyapıyı Erlang sağlar. Her RabbitMQ sürümü belirli Erlang sürüm aralıklarını destekler (4.1 için Erlang 26.2 – 27.x).',
    use: 'Uyumluluk matrisi kontrolü ve performans/güvenlik yamaları için.',
    when: ['RabbitMQ yükseltmesi öncesi', 'TLS veya performans sorunlarında'],
    benefit: 'Doğru Erlang sürümü kararlılık ve güvenlik açısından kritiktir.',
    ex: 'rabbitmq-diagnostics erlang_version'
  });
  h('refresh', {
    t: 'Refresh interval', term: 'Otomatik yenileme', cat: 'Arayüz',
    what: 'Management UI\'nın istatistikleri ne sıklıkla HTTP API\'den yeniden çekeceğini belirler.',
    role: 'Her yenilemede UI, <code>/api/overview</code>, <code>/api/queues</code> gibi uç noktaları sorgular. Bu simülasyonda değerler tarayıcıda yeniden hesaplanır.',
    use: 'Canlı izlemede kısa, büyük ortamlarda (binlerce kuyruk) daha uzun aralık seçmek için.',
    when: ['Çok sayıda kuyruk/bağlantı varsa yenileme sıklığını düşürün veya kapatın; management plugin\'in yükünü azaltır'],
    benefit: 'Broker üzerindeki istatistik sorgulama yükünü kontrol etmenizi sağlar.'
  });
  h('vhost-select', {
    t: 'Virtual host filtresi', term: 'Virtual host: All', cat: 'Arayüz',
    what: 'Liste sayfalarında (Connections, Channels, Exchanges, Queues) yalnızca seçilen virtual host\'a ait nesnelerin gösterilmesini sağlar.',
    role: 'Yalnızca görüntüleme filtresidir; yetkileri veya bağlantıları değiştirmez.',
    use: 'Çok vhost\'lu ortamlarda ilgilendiğiniz alana odaklanmak için.',
    benefit: 'Kalabalık listelerde aradığınızı daha hızlı bulursunuz.',
    rel: ['vhost']
  });
  h('cluster-name', {
    t: 'Cluster name', term: 'Cluster adı', cat: 'Cluster',
    what: 'Cluster\'ı insanlar ve araçlar için tanımlayan isimdir. Varsayılan olarak ilk node\'un adından türetilir.',
    role: 'Federation ve shovel bağlantılarında, monitoring etiketlerinde ve UI başlığında kimlik olarak kullanılır. Federation, mesaj döngülerini engellemek için cluster adını <code>x-received-from</code> başlığında kullanır.',
    use: 'Birden çok cluster yönetiliyorsa (TEST, PROD, DR) hangisinde olduğunuzu net görmek için.',
    when: ['Kurulum sonrası anlamlı bir isim verin', 'Federation kurulan cluster\'ların adlarının birbirinden farklı olduğundan emin olun'],
    benefit: 'Yanlış ortamda işlem yapma riskini azaltır.',
    ex: 'rabbitmqctl set_cluster_name MQ_EGITIM_CLUSTER',
    rel: ['cluster']
  });
  h('current-user', {
    t: 'Oturum açan kullanıcı', term: 'User / Log out', cat: 'Arayüz',
    what: 'Management UI\'ya giriş yapmış olan kullanıcıdır. UI\'da görebildikleriniz bu kullanıcının <b>tag</b>\'lerine ve vhost izinlerine bağlıdır.',
    role: 'administrator tag\'i olan kullanıcı tüm sekmeleri görür; management tag\'li kullanıcı yalnızca erişimi olan vhost\'ları görür; Admin sekmesi gizlenir.',
    use: 'Yetki testleri yaparken farklı kullanıcılarla giriş yaparak görünürlüğü kontrol edebilirsiniz.',
    rel: ['user-tags']
  });
  h('deprecated-banner', {
    t: 'Deprecated features are being used', term: 'Kullanımdan kaldırılan özellik uyarısı', cat: 'Arayüz',
    what: 'Cluster\'da, gelecekteki bir sürümde kaldırılacak (deprecated) bir özelliğin şu anda kullanıldığını bildiren sarı banner\'dır.',
    role: 'RabbitMQ 3.13 ile gelen "deprecated features" alt sistemi, kullanılan eski özellikleri izler. Bu simülasyonda <code>notifications.temp</code> isimli <b>non-durable, non-exclusive</b> (transient) bir kuyruk olduğu için <code>transient_nonexcl_queues</code> özelliği "in use" olarak işaretlenmiştir.',
    use: 'Yükseltme öncesi uyumsuzlukları erkenden tespit etmek için. Detaylar Admin → Deprecated Features sayfasındadır.',
    when: ['Bu banner görünüyorsa bir sonraki büyük sürüme geçmeden önce ilgili kullanımı düzeltin'],
    benefit: 'Yükseltme sonrası sürpriz hataları (özellik kapatıldığında istemci bağlantılarının reddedilmesi gibi) önler.',
    ex: `rabbitmq-diagnostics list_deprecated_features --used
# Bir özelliğin kapatılmış haliyle test etmek için (rabbitmq.conf):
deprecated_features.permit.transient_nonexcl_queues = false`,
    rel: ['deprecated-features', 'q-durable', 'q-exclusive']
  });

  /* ========================= SEKME (TAB) AÇIKLAMALARI ========================= */
  h('tab-overview', { t: 'Overview sekmesi', cat: 'Arayüz', what: 'Cluster\'ın genel sağlık durumunun özetidir: kuyruktaki toplam mesajlar, mesaj oranları, global sayılar, node kaynak kullanımları, port/listener bilgileri ve tanım (definition) dışa/içe aktarımı.', use: 'Bir sorun olduğunda ilk bakılacak ekrandır: alarm var mı, mesajlar birikiyor mu, oranlar normal mi?', rel: ['queued-messages', 'message-rates', 'nodes'] });
  h('tab-monitoring', {
    t: 'Monitoring (eğitim sekmesi)', term: 'Not: Gerçek UI\'da bu sekme yoktur', cat: 'Monitoring',
    what: 'Bu sekme eğitim amacıyla eklenmiştir. Gerçek RabbitMQ Management UI\'da ayrı bir "Monitoring" sekmesi bulunmaz; buradaki bilgiler Overview, node detay ve kuyruk detay sayfalarına dağılmıştır. Üretimde kapsamlı izleme için <b>Prometheus + Grafana</b> önerilir.',
    role: 'Mesaj oranları, bağlantı/kanal/kuyruk istatistikleri, bellek, disk ve CPU/sistem kaynaklarını tek ekranda toplar.',
    use: 'Bir RabbitMQ ortamında hangi metriklerin izlenmesi gerektiğini öğrenmek için.',
    note: 'RabbitMQ 4.x\'te management plugin\'in metrik toplama özelliği (<code>management_metrics_collection</code>) deprecated olarak işaretlenmiştir. Uzun vadede metrikler için <code>rabbitmq_prometheus</code> (port 15692) kullanılmalıdır.',
    rel: ['prometheus', 'message-rates', 'memory']
  });

  /* ========================= OVERVIEW ========================= */
  h('queued-messages', {
    t: 'Queued messages', term: 'Kuyruktaki mesajlar (tüm kuyruklar)', cat: 'Overview',
    what: 'Seçili vhost (veya tüm vhost\'lar) içindeki tüm kuyruklarda bekleyen mesajların toplamını zaman içinde gösteren grafiktir.',
    role: 'Üç seri içerir: <b>Ready</b> (teslim edilmeyi bekleyen), <b>Unacked</b> (teslim edilmiş ama onaylanmamış) ve <b>Total</b> (ikisinin toplamı).',
    use: 'Tüketicilerin üreticilere yetişip yetişemediğini anlamak için. Sürekli artan Ready → consumer yetersiz veya durmuş; sürekli artan Unacked → consumer\'lar mesajı alıp ack göndermiyor.',
    when: ['Kapasite planlamasında ve olay (incident) sırasında ilk bakılacak grafiklerdendir'],
    benefit: 'Birikmeyi erken fark ederek memory alarmına ve disk dolmasına gitmeden önlem alırsınız.',
    note: 'Stream mesajları tüketilince silinmediği için Ready değerlerine eklenir ve toplamı büyük gösterebilir.',
    rel: ['ready', 'unacked', 'total', 'chart-range']
  });
  h('ready', { t: 'Ready', term: 'Teslime hazır mesajlar', cat: 'Kuyruk metrikleri',
    what: 'Kuyrukta bekleyen ve henüz hiçbir consumer\'a teslim edilmemiş mesaj sayısıdır.',
    role: 'Bir consumer\'ın prefetch kapasitesi boşaldığında RabbitMQ bu mesajlardan birini teslim eder.',
    use: 'Kuyruk birikmesini (backlog) ölçmek için temel metriktir.',
    when: ['Ready sürekli artıyorsa: consumer sayısını artırın, işlem süresini kısaltın veya üretimi yavaşlatın', 'Consumer yokken Ready artıyorsa ilgili servis muhtemelen çökmüştür'],
    benefit: 'Sistem gecikmesinin (latency) doğrudan göstergesidir.',
    rel: ['unacked', 'total', 'consumer'] });
  h('unacked', { t: 'Unacked', term: 'Onay bekleyen mesajlar', cat: 'Kuyruk metrikleri',
    what: 'Bir consumer\'a teslim edilmiş ama henüz <b>ack</b> / <b>nack</b> / <b>reject</b> yanıtı alınmamış mesaj sayısıdır.',
    role: 'Bu mesajlar consumer\'a "ödünç verilmiş" durumdadır. Consumer channel\'ı veya bağlantısı kapanırsa mesajlar otomatik olarak kuyruğa geri döner ve <code>redelivered=true</code> ile tekrar teslim edilir.',
    use: 'Consumer\'ların mesajları gerçekten işleyip işlemediğini görmek için. Unacked üst sınırı = consumer sayısı × prefetch.',
    when: ['Unacked değeri prefetch toplamına dayanıp kalıyorsa consumer takılmış (stuck) olabilir', 'Prefetch = 0 (sınırsız) ise unacked çok büyüyüp consumer belleğini tüketebilir'],
    benefit: 'Takılan veya ack göndermeyi unutan tüketicileri tespit etmeyi sağlar.',
    note: 'Quorum queue\'larda consumer ack için varsayılan zaman aşımı <code>consumer_timeout</code> = 30 dakikadır; aşılırsa channel kapatılır.',
    rel: ['ready', 'prefetch', 'ack-required'] });
  h('total', { t: 'Total', term: 'Toplam mesaj', cat: 'Kuyruk metrikleri', what: 'Ready + Unacked toplamıdır; kuyrukta o anda sorumluluğu broker\'da olan tüm mesajları ifade eder.', use: 'Kuyruk boyutunu (ve dolaylı olarak bellek/disk ihtiyacını) değerlendirmek için.', rel: ['ready', 'unacked'] });
  h('chart-range', { t: 'Grafik zaman aralığı', term: 'last minute / last hour ...', cat: 'Overview',
    what: 'Grafiğin gösterdiği zaman penceresidir (last minute, last ten minutes, last hour, last eight hours, last day).',
    role: 'Management plugin örnekleri belirli aralıklarla saklar; uzun aralıklar daha seyrek örneklerle gösterilir. Saklama süreleri <code>management.sample_retention_policies</code> ile ayarlanır.',
    use: 'Anlık dalgalanma ile uzun vadeli eğilimi ayırt etmek için.' });
  h('message-rates', {
    t: 'Message rates', term: 'Mesaj oranları (msg/s)', cat: 'Overview',
    what: 'Cluster genelinde saniye başına mesaj işlem oranlarını gösteren grafiktir: publish, confirm, deliver, ack, redeliver, get ve unroutable.',
    role: 'Mesaj akışının sağlığını gösterir. Normal bir sistemde publish ≈ deliver ≈ ack yaklaşık dengededir.',
    use: 'Throughput (verim) ölçmek, darboğazları ve anormallikleri (ör. ani redeliver artışı) yakalamak için.',
    when: ['Publish > Deliver ise kuyruklar büyür', 'Redelivered yüksekse consumer\'lar hata alıp mesajı geri bırakıyor olabilir (poison message)', 'Unroutable > 0 ise binding eksikliği veya hatalı routing key vardır'],
    benefit: 'Uygulama seviyesindeki sorunları broker tarafından görmeyi sağlar.',
    note: 'Oranların gösterimi <code>management.rates_mode</code> ayarına bağlıdır (basic/detailed/none).',
    rel: ['rate-publish', 'rate-deliver-manual', 'rate-consumer-ack', 'rate-redelivered', 'rate-unroutable-drop']
  });
  h('rate-publish', { t: 'Publish', term: 'Yayın oranı', cat: 'Mesaj oranları', what: 'Publisher\'ların broker\'a saniyede gönderdiği mesaj sayısıdır (exchange\'lere giren mesajlar).', use: 'Sisteme giren yükü ölçmek için.', when: ['Beklenmedik ani artışlar bir istemcinin döngüye girdiğini gösterebilir'], rel: ['publisher', 'rate-confirm'] });
  h('rate-confirm', { t: 'Publisher confirm', term: 'Yayın onay oranı', cat: 'Mesaj oranları',
    what: 'Broker\'ın confirm modundaki publisher\'lara saniyede gönderdiği onay (basic.ack) sayısıdır.',
    role: 'Bir mesaj confirm edildiğinde broker, mesajın sorumluluğunu aldığını garanti eder (quorum queue için çoğunluk node\'a yazılmış; persistent mesaj için diske alınmış olur).',
    use: 'Publisher\'ların güvenilir yayın yapıp yapmadığını görmek için. Publish oranı > 0 ama confirm = 0 ise publisher\'lar confirm kullanmıyor demektir.',
    benefit: 'Mesaj kaybına karşı uçtan uca güvence sağlar.',
    rel: ['confirm-mode', 'publisher'] });
  h('rate-deliver-manual', { t: 'Deliver (manual ack)', cat: 'Mesaj oranları', what: 'basic.consume ile abone olmuş ve <b>manuel ack</b> kullanan consumer\'lara saniyede teslim edilen mesaj sayısıdır.', role: 'Güvenilir tüketimin göstergesidir; bu mesajlar ack gelene kadar unacked kalır.', rel: ['ack-required', 'rate-consumer-ack'] });
  h('rate-deliver-auto', { t: 'Deliver (auto ack)', cat: 'Mesaj oranları', what: '<b>autoAck=true</b> (no-ack) modundaki consumer\'lara teslim edilen mesaj oranıdır.', role: 'Mesaj gönderildiği anda broker tarafından silinir; consumer çökerse mesaj kaybolur.', when: ['Yalnızca kaybın tolere edilebildiği, yüksek hız gerektiren durumlarda (telemetri, log) kullanın'], rel: ['ack-required'] });
  h('rate-consumer-ack', { t: 'Consumer ack', cat: 'Mesaj oranları', what: 'Consumer\'ların saniyede gönderdiği ack (onay) sayısıdır.', role: 'Ack gelen mesaj kuyruktan kalıcı olarak silinir.', use: 'Deliver (manual) ile karşılaştırıldığında consumer\'ların işlem hızını gösterir. Ack < Deliver ise unacked birikir.', rel: ['unacked', 'rate-deliver-manual'] });
  h('rate-redelivered', { t: 'Redelivered', term: 'Yeniden teslim', cat: 'Mesaj oranları',
    what: 'Daha önce teslim edilmiş, ancak ack alınmadan kuyruğa geri dönmüş ve tekrar teslim edilen mesajların oranıdır.',
    role: 'Consumer bağlantısı koptuğunda, <code>basic.nack/reject(requeue=true)</code> çağrıldığında veya channel kapandığında oluşur. Mesajda <code>redelivered</code> bayrağı true olur.',
    use: 'Sürekli yüksek redeliver oranı "poison message" (işlenemeyen mesaj) döngüsüne işaret eder.',
    when: ['Quorum queue\'larda <b>delivery-limit</b> ile sonsuz döngüyü önleyin ve mesajı DLQ\'ya gönderin'],
    rel: ['x-delivery-limit', 'dlx'] });
  h('rate-get-manual', { t: 'Get (manual ack)', cat: 'Mesaj oranları', what: '<code>basic.get</code> (polling) ile, manuel ack kullanılarak çekilen mesaj oranıdır.', role: 'Her get isteği ayrı bir round-trip gerektirir.', when: ['Üretimde basic.get yerine basic.consume tercih edin; polling verimsizdir'], rel: ['get-messages'] });
  h('rate-get-auto', { t: 'Get (auto ack)', cat: 'Mesaj oranları', what: 'basic.get ile otomatik ack modunda çekilen mesaj oranıdır. Management UI\'daki "Get messages" işlemi de bu metriğe yansıyabilir.', rel: ['get-messages'] });
  h('rate-get-empty', { t: 'Get (empty)', cat: 'Mesaj oranları', what: 'Boş bir kuyruğa yapılan basic.get isteklerinin oranıdır (dönen mesaj yok).', role: '<code>empty_basic_get_metric</code> feature flag ile eklenmiştir.', use: 'Yüksek değer, gereksiz polling yapan istemcileri gösterir; CPU ve ağ israfıdır.', rel: ['rate-get-manual'] });
  h('rate-unroutable-return', { t: 'Unroutable (return)', cat: 'Mesaj oranları', what: '<code>mandatory=true</code> bayrağıyla yayınlanan ama hiçbir kuyruğa yönlendirilemeyen ve <code>basic.return</code> ile publisher\'a geri gönderilen mesajların oranıdır.', use: 'Publisher yönlendirme hatalarını fark etsin istiyorsanız mandatory kullanın.', rel: ['alternate-exchange', 'rate-unroutable-drop'] });
  h('rate-unroutable-drop', { t: 'Unroutable (drop)', cat: 'Mesaj oranları', what: 'Hiçbir binding ile eşleşmeyen ve mandatory olmadığı için <b>sessizce düşürülen</b> mesajların oranıdır.', role: '<code>drop_unroutable_metric</code> feature flag ile eklenmiştir.', use: 'Sıfırdan büyükse mesaj kaybediyorsunuz demektir: eksik binding, yanlış routing key veya yanlış exchange.', when: ['Alternate exchange tanımlayarak bu mesajları yakalayın'], rel: ['alternate-exchange'] });
  h('global-counts', { t: 'Global counts', term: 'Genel nesne sayıları', cat: 'Overview',
    what: 'Cluster\'daki (veya seçili vhost\'taki) toplam Connections, Channels, Exchanges, Queues ve Consumers sayısıdır.',
    role: 'Kaynak tüketiminin kaba bir göstergesidir; her bağlantı, kanal ve kuyruk bellek ve Erlang process kullanır.',
    use: 'Butonlara tıklayarak ilgili listeye gidebilirsiniz. Ani artışlar bağlantı/kanal sızıntısına (leak) işaret eder.',
    when: ['Deploy sonrası bağlantı sayısının beklenen seviyede olduğunu doğrulamak için'],
    rel: ['churn'] });
  h('nodes', { t: 'Nodes', term: 'Cluster node\'ları', cat: 'Cluster',
    what: 'Cluster\'ı oluşturan RabbitMQ sunucularının (Erlang node) listesidir. Her node <code>rabbit@hostname</code> biçiminde adlandırılır.',
    role: 'Tablo, her node için file descriptor, Erlang process, memory, disk space, uptime ve çekirdek sayısını gösterir. Kırmızı/sarı değerler kaynak alarmı veya yaklaşan bir sınırı gösterir.',
    use: 'Node adına tıklayarak node detay sayfasına (bellek dağılımı, config dosyaları, eklentiler) gidebilirsiniz.',
    when: ['Bir node "Node not running" görünüyorsa cluster çoğunluğu ve quorum kuyrukları risk altındadır'],
    rel: ['fd', 'erlang-processes', 'memory', 'disk', 'cluster'] });
  h('fd', { t: 'File descriptors', term: 'Dosya tanımlayıcıları', cat: 'Node kaynakları',
    what: 'İşletim sisteminin bir sürece tanıdığı açık dosya/soket tutamacı (handle) sayısıdır. RabbitMQ\'da her istemci bağlantısı en az bir file descriptor kullanır; dosyalar da kullanır.',
    role: 'Limit dolarsa node yeni bağlantı kabul edemez. Alt satırda işletim sisteminin izin verdiği üst sınır (ulimit) gösterilir.',
    use: 'Beklenen bağlantı sayısına göre ulimit ayarını planlamak için. Üretim için en az 65536 önerilir.',
    when: ['Kullanım %80\'e yaklaşıyorsa limiti yükseltin veya bağlantı sayısını azaltın'],
    ex: `# systemd ile limit
[Service]
LimitNOFILE=65536
# Windows'ta limit, ERL_MAX_PORTS ortam değişkeniyle belirlenir.`,
    rel: ['sockets', 'connection'] });
  h('sockets', { t: 'Socket descriptors', cat: 'Node kaynakları', what: 'File descriptor\'ların ağ soketleri için kullanılan kısmıdır. Eski sürümlerde ayrıca gösterilirdi; güncel sürümlerde file descriptor sayısı içinde değerlendirilir.', rel: ['fd'] });
  h('erlang-processes', { t: 'Erlang processes', term: 'Erlang süreçleri', cat: 'Node kaynakları',
    what: 'Node üzerinde çalışan hafif Erlang süreçlerinin sayısıdır (işletim sistemi süreci değildir).',
    role: 'Her bağlantı, kanal, kuyruk ve consumer birden çok Erlang süreci kullanır. Varsayılan limit 1.048.576\'dır.',
    use: 'Çok sayıda kuyruk veya kanal oluşturan uygulamaları tespit etmek için.',
    when: ['Limit dolarsa node yeni nesne oluşturamaz; <code>+P</code> Erlang bayrağıyla (RABBITMQ_SERVER_ERL_ARGS) artırılabilir'],
    benefit: 'Kaynak tüketen kanal/kuyruk sızıntılarını görmeyi sağlar.' });
  h('memory', { t: 'Memory', term: 'Bellek kullanımı ve high watermark', cat: 'Node kaynakları',
    what: 'Node\'un kullandığı bellek miktarı ve altında gösterilen <b>high watermark</b> (bellek alarm eşiği) değeridir.',
    role: 'Kullanım high watermark\'ı aştığında <b>memory alarm</b> tetiklenir ve cluster genelindeki tüm publisher bağlantıları <b>blocked</b> durumuna geçer (consumer\'lar çalışmaya devam eder). Böylece broker\'ın bellek yetersizliğinden çökmesi engellenir.',
    use: 'Varsayılan eşik <code>vm_memory_high_watermark.relative = 0.6</code> (RAM\'in %60\'ı). Konteynerlerde mutlak değer kullanmak önerilir.',
    when: ['Bellek kullanımı sürekli eşiğe yaklaşıyorsa: kuyruk birikmelerini giderin, bağlantı sayısını azaltın, RAM ekleyin'],
    ex: `# rabbitmq.conf
vm_memory_high_watermark.relative = 0.6
# veya
vm_memory_high_watermark.absolute = 6GB`,
    note: 'Bellek hesaplama stratejisi (rss / allocated / legacy) <code>vm_memory_calculation_strategy</code> ile ayarlanır; varsayılan <b>rss</b>\'dir.',
    rel: ['memory-alarm', 'info-mem-calc', 'conn-state'] });
  h('disk', { t: 'Disk space', term: 'Boş disk alanı ve low watermark', cat: 'Node kaynakları',
    what: 'RabbitMQ veri dizininin bulunduğu diskteki boş alan ve altında gösterilen <b>disk free limit</b> (low watermark) değeridir.',
    role: 'Boş alan bu limitin altına düşerse <b>disk alarm</b> tetiklenir ve tüm publisher\'lar bloklanır. Bu, disk tamamen dolup veri bozulmasını engellemek içindir.',
    use: 'Varsayılan limit yalnızca 50 MB\'dır; üretimde çok daha yüksek bir değer (ör. RAM kadar veya birkaç GB) önerilir.',
    when: ['Stream\'ler ve büyük kuyruklar kullanılıyorsa disk kapasitesini düzenli izleyin'],
    ex: `# rabbitmq.conf
disk_free_limit.absolute = 10GB
# veya RAM'e göre:
disk_free_limit.relative = 1.0`,
    rel: ['disk-alarm', 'queue-type-stream'] });
  h('uptime', { t: 'Uptime', cat: 'Node kaynakları', what: 'Node\'un son başlatılmasından bu yana geçen süredir (d = gün, h = saat).', use: 'Beklenmedik yeniden başlatmaları (crash, OOM) tespit etmek için. Node\'lardan biri diğerlerinden çok kısa uptime\'a sahipse yakın zamanda yeniden başlamıştır.' });
  h('cores', { t: 'Cores', cat: 'Node kaynakları', what: 'Erlang VM\'in kullanabildiği mantıksal CPU çekirdeği sayısıdır.', role: 'Erlang, her çekirdek için bir scheduler çalıştırır. Quorum queue\'lar ve TLS yoğun CPU kullanır.', use: 'Kapasite planlaması için; üretim node\'ları için en az 4 çekirdek önerilir.' });
  h('info-rates-mode', { t: 'Info: basic', term: 'Message rates mode', cat: 'Node kaynakları',
    what: 'Node bilgi sütunundaki <b>basic</b> etiketi, management plugin\'in mesaj oranı toplama modunu gösterir.',
    role: '<code>basic</code>: oranlar kuyruk/kanal/exchange bazında toplanır. <code>detailed</code>: kanal-kuyruk-exchange çiftleri bazında ayrıntılı oranlar (yüksek maliyet). <code>none</code>: oran toplanmaz.',
    ex: 'management.rates_mode = basic', rel: ['message-rates'] });
  h('info-plugins', { t: 'Info: plugin sayısı', cat: 'Node kaynakları', what: 'Node\'da açıkça etkinleştirilmiş (enabled_plugins dosyasında listelenen) eklenti sayısıdır.', role: 'Bu simülasyonda: rabbitmq_management, rabbitmq_federation_management, rabbitmq_shovel_management, rabbitmq_prometheus, rabbitmq_stream_management. Bağımlılıklar otomatik etkinleşir.', ex: `rabbitmq-plugins list -E
rabbitmq-plugins enable rabbitmq_shovel_management` });
  h('info-mem-calc', { t: 'Info: rss', term: 'Memory calculation strategy', cat: 'Node kaynakları', what: 'Bellek kullanımının nasıl hesaplandığını gösterir. <b>rss</b>: işletim sisteminin raporladığı resident set size (varsayılan ve önerilen). <b>allocated</b>: Erlang bellek ayırıcılarından alınan değer.', ex: 'vm_memory_calculation_strategy = rss', rel: ['memory'] });
  h('reset-stats', { t: 'Reset stats', cat: 'Overview', what: 'Management plugin\'in tuttuğu istatistik verilerini (grafik geçmişi ve sayaçlar) sıfırlar. <b>This node</b> yalnızca o node\'un, <b>All nodes</b> tüm cluster\'ın istatistiklerini sıfırlar.', role: 'Mesajları, kuyrukları veya bağlantıları etkilemez; yalnızca istatistik veritabanını temizler.', when: ['İstatistik veritabanı aşırı bellek kullanıyorsa veya bir testi temiz sayaçlarla başlatmak istiyorsanız'] });
  h('churn', { t: 'Churn statistics', term: 'Oluşturma/kapatma oranları', cat: 'Overview',
    what: 'Bağlantıların, kanalların ve kuyrukların saniyede ne kadar sık oluşturulup kapatıldığını gösterir.',
    role: 'Yüksek churn, broker için pahalıdır (kimlik doğrulama, metadata işlemleri, TCP handshake).',
    use: 'Her mesaj için bağlantı/kanal açıp kapatan hatalı istemci kalıplarını (anti-pattern) tespit etmek için.',
    when: ['Connection churn yüksekse istemcide bağlantı havuzu (pool) veya uzun ömürlü bağlantı kullanın'] });
  h('ports', { t: 'Ports and contexts', term: 'Listener\'lar', cat: 'Overview',
    what: 'Node\'ların dinlediği protokol portları (listeners) ve HTTP context\'leridir.',
    role: '<b>5672</b> AMQP, <b>5671</b> AMQP over TLS, <b>25672</b> inter-node/CLI, <b>4369</b> epmd, <b>15672</b> Management UI/HTTP API, <b>15692</b> Prometheus, <b>1883/8883</b> MQTT, <b>61613</b> STOMP, <b>5552</b> Stream protokolü.',
    use: 'Firewall ve load balancer yapılandırmasında hangi portların açılması gerektiğini görmek için.',
    ex: `listeners.tcp.default = 5672
listeners.ssl.default = 5671
management.tcp.port   = 15672` });
  h('definitions-export', { t: 'Export definitions', cat: 'Overview',
    what: 'Cluster\'ın tüm topolojisini (users, vhosts, permissions, exchanges, queues, bindings, policies, parameters) JSON dosyası olarak dışa aktarır. <b>Mesajlar dahil değildir.</b>',
    use: 'Yedekleme, ortamlar arası topoloji kopyalama, GitOps ile versiyonlama ve felaket kurtarma için.',
    ex: `rabbitmqctl export_definitions /tmp/definitions.json
# rabbitmq.conf ile açılışta yükleme:
definitions.import_backend = local_filesystem
definitions.local.path = /etc/rabbitmq/definitions.json`,
    rel: ['definitions-import'] });
  h('definitions-import', { t: 'Import definitions', cat: 'Overview', what: 'Daha önce dışa aktarılmış bir definitions JSON dosyasını cluster\'a yükler. Var olan nesneler güncellenir, yenileri eklenir; mevcut olup dosyada olmayan nesneler silinmez.', when: ['Yeni bir cluster kurulumunda topolojiyi hızlıca oluşturmak için'], note: 'Bu simülasyonda içe aktarma gerçek bir işlem yapmaz.', rel: ['definitions-export'] });
  h('memory-alarm', { t: 'Memory alarm', cat: 'Cluster', what: 'Bir node\'un bellek kullanımı high watermark\'ı aştığında tetiklenen kaynak alarmıdır.', role: 'Alarm <b>cluster geneline</b> yayılır: tüm node\'lardaki publisher bağlantıları bloklanır. Consumer\'lar çalışmaya devam eder, böylece kuyruklar boşalarak bellek serbest kalır.', use: 'İstemciler <code>connection.blocked</code> / <code>connection.unblocked</code> bildirimleriyle bu durumu algılayabilir.', ex: 'rabbitmq-diagnostics alarms', rel: ['memory', 'conn-state'] });
  h('disk-alarm', { t: 'Disk alarm', cat: 'Cluster', what: 'Boş disk alanı disk_free_limit\'in altına düştüğünde tetiklenen kaynak alarmıdır.', role: 'Memory alarmı gibi tüm publisher\'ları bloklar. Disk temizlenene veya limit düzeltilene kadar sürer.', ex: 'rabbitmq-diagnostics check_local_alarms', rel: ['disk'] });

  /* ========================= CONNECTIONS ========================= */
  h('conn-name', { t: 'Connection Name', cat: 'Connections',
    what: 'Bağlantının adıdır. Varsayılan olarak <code>istemci_ip:port -> sunucu_ip:port</code> biçimindedir. İstemci <code>connection_name</code> client property\'si gönderirse bu ad da gösterilir.',
    use: 'Hangi uygulamanın hangi bağlantıyı açtığını anlamak için istemcide anlamlı bir bağlantı adı verin.',
    ex: `// .NET: ClientProvidedName = "order-api-1 (publisher)"
// Java : factory.newConnection("payment-worker-1")
// Python pika: ConnectionParameters(client_properties={"connection_name": "legacy-billing"})`,
    rel: ['client-properties'] });
  h('conn-node', { t: 'Node', cat: 'Connections', what: 'İstemcinin bağlı olduğu cluster node\'udur.', role: 'İstemci hangi node\'a bağlanırsa bağlansın tüm kuyruklara erişebilir; ancak kuyruk leader\'ı başka node\'daysa mesajlar node\'lar arası iletilir (ek ağ trafiği).', use: 'Bağlantıların node\'lar arasında dengeli dağılıp dağılmadığını kontrol etmek için (load balancer doğrulaması).' });
  h('container-id', { t: 'Container ID', cat: 'Connections', what: 'AMQP 1.0 protokolünde istemcinin kendini tanıttığı benzersiz kimliktir (container-id). AMQP 0-9-1 bağlantılarında boştur.', note: 'RabbitMQ 4.0 ile AMQP 1.0 çekirdeğe native olarak eklenmiştir; ayrı eklenti gerekmez.', rel: ['protocol'] });
  h('conn-user', { t: 'User name', cat: 'Connections', what: 'Bağlantının kimlik doğrulamasında kullanılan RabbitMQ kullanıcısıdır.', use: 'Hangi uygulamanın hangi kimlikle bağlandığını ve yetki sorunlarını anlamak için.', rel: ['user'] });
  h('conn-state', { t: 'State', term: 'Bağlantı durumu', cat: 'Connections',
    what: 'Bağlantının anlık durumudur.',
    role: '<b>running</b>: normal çalışıyor. <b>flow</b>: credit-based flow control devrede – publisher, broker\'ın işleyebileceğinden hızlı yayın yaptığı için geçici olarak yavaşlatılıyor. <b>blocking</b>: kaynak alarmı var, bağlantı henüz yayın yapmadı. <b>blocked</b>: kaynak alarmı nedeniyle yayın yapan bağlantı durduruldu. <b>closing/closed</b>: kapanıyor.',
    use: 'Kısa süreli "flow" normaldir; sürekli flow, darboğaz göstergesidir (disk I/O, CPU, kuyruk leader\'ı).',
    when: ['Blocked bağlantılar görüyorsanız Overview\'daki memory/disk alarmlarını kontrol edin'],
    rel: ['memory-alarm', 'disk-alarm'] });
  h('ssl-tls', { t: 'SSL / TLS', cat: 'Connections',
    what: 'Bağlantının TLS ile şifrelenip şifrelenmediğini gösterir (● evet, ○ hayır).',
    role: 'TLS ile kimlik bilgileri ve mesaj içerikleri ağda şifreli taşınır. x509 istemci sertifikaları ile <b>EXTERNAL</b> mekanizması kullanılarak parolasız kimlik doğrulaması yapılabilir.',
    use: 'Veri merkezi dışına çıkan veya hassas veri (PCI, KVKK) taşıyan tüm bağlantılarda TLS kullanın.',
    ex: `listeners.ssl.default = 5671
ssl_options.cacertfile = /etc/rabbitmq/ca.pem
ssl_options.certfile   = /etc/rabbitmq/server.pem
ssl_options.keyfile    = /etc/rabbitmq/server.key
ssl_options.verify     = verify_peer
ssl_options.versions.1 = tlsv1.3
ssl_options.versions.2 = tlsv1.2`,
    rel: ['auth-mechanism'] });
  h('protocol', { t: 'Protocol', cat: 'Connections',
    what: 'Bağlantının kullandığı mesajlaşma protokolüdür.',
    role: '<b>AMQP 0-9-1</b>: RabbitMQ\'nun klasik ana protokolü. <b>AMQP 1.0</b>: 4.0\'dan itibaren native, standart ISO protokolü. <b>MQTT 3.1/3.1.1/5.0</b>: IoT cihazları. <b>STOMP</b>: metin tabanlı, web istemcileri. <b>Direct 0-9-1</b>: Federation/Shovel gibi broker içi eklentilerin ağ kullanmayan yerel bağlantıları. <b>RabbitMQ Stream</b>: yüksek performanslı stream protokolü (ayrı "Stream Connections" sekmesinde görünür).',
    use: 'Doğru protokol, istemci ekosistemine ve kullanım senaryosuna göre seçilir.' });
  h('conn-channels', { t: 'Channels (bağlantı başına)', cat: 'Connections', what: 'Bu bağlantı üzerinde açık olan kanal sayısıdır.', when: ['Tek bir bağlantıda yüzlerce/binlerce kanal varsa kanal sızıntısı olabilir; <code>channel_max</code> (varsayılan 2047) sınırına dikkat edin'], rel: ['channel'] });
  h('from-client', { t: 'From client', term: 'İstemciden gelen trafik', cat: 'Connections', what: 'İstemciden broker\'a saniyede gelen bayt miktarıdır (publish edilen mesajlar, ack\'ler, heartbeat\'ler).', use: 'Yoğun publisher\'ları bulmak için sıralayın.' });
  h('to-client', { t: 'To client', term: 'İstemciye giden trafik', cat: 'Connections', what: 'Broker\'dan istemciye saniyede giden bayt miktarıdır (consumer\'a teslim edilen mesajlar, confirm\'ler).', use: 'Yoğun consumer\'ları bulmak için.' });
  h('client-ip', { t: 'Client IP / Port', cat: 'Connections', what: 'Bağlantının geldiği istemci adresi (peer host) ve kaynak portudur.', use: 'Bir bağlantının hangi sunucudan/podtan geldiğini bulmak için. Load balancer arkasında PROXY protocol etkin değilse load balancer IP\'si görünür.', ex: 'proxy_protocol = true   # rabbitmq.conf' });
  h('heartbeat', { t: 'Heartbeat', cat: 'Connections',
    what: 'Bağlantının canlı olduğunu doğrulamak için iki taraf arasında periyodik olarak gönderilen küçük çerçevelerdir. Değer saniye cinsinden müzakere edilen zaman aşımıdır.',
    role: 'Belirtilen sürenin ~2 katı boyunca trafik olmazsa bağlantı ölü kabul edilip kapatılır; böylece yarım açık (half-open) TCP bağlantıları temizlenir.',
    use: 'Varsayılan sunucu önerisi 60 saniyedir. 5 saniyenin altındaki değerler yanlış alarmlara neden olabilir.',
    ex: 'heartbeat = 60   # rabbitmq.conf' });
  h('auth-mechanism', { t: 'Authentication mechanism', cat: 'Connections', what: 'Bağlantının kullandığı SASL kimlik doğrulama mekanizmasıdır.', role: '<b>PLAIN / AMQPLAIN</b>: kullanıcı adı + parola. <b>EXTERNAL</b>: TLS istemci sertifikası (rabbitmq_auth_mechanism_ssl). <b>ANONYMOUS</b>: 4.0+ ile AMQP 1.0 için. OAuth 2.0 ile token parola alanında taşınır.', ex: `auth_mechanisms.1 = PLAIN
auth_mechanisms.2 = EXTERNAL` });
  h('client-properties', { t: 'Client properties', cat: 'Connections', what: 'İstemci kütüphanesinin bağlantı sırasında broker\'a bildirdiği bilgilerdir: ürün adı, sürüm, platform, desteklediği yetenekler (capabilities) ve connection_name.', role: '<code>capabilities</code> içinde publisher_confirms, consumer_cancel_notify, connection.blocked gibi özelliklerin desteklenip desteklenmediği belirtilir.', use: 'Eski/güncel olmayan istemci kütüphanelerini tespit etmek ve sorun giderme için.' });
  h('frame-max', { t: 'Frame max / Channel max', cat: 'Connections', what: '<b>frame_max</b>: tek bir AMQP çerçevesinin maksimum boyutu (varsayılan 131072 bayt). <b>channel_max</b>: bağlantı başına izin verilen maksimum kanal sayısı (varsayılan 2047).', role: 'Bağlantı kurulurken istemci ve sunucu tarafından müzakere edilir. Büyük mesajlar birden çok çerçeveye bölünür.' });
  h('close-connection', { t: 'Close this connection', term: 'Bağlantıyı zorla kapatma', cat: 'Connections',
    what: 'Bağlantıyı broker tarafından kapatır ve istemciye verilen gerekçe (reason) metnini iletir.',
    role: 'Bağlantıya ait tüm kanallar kapanır; unacked mesajlar kuyruğa geri döner (redeliver). Exclusive kuyruklar silinir.',
    when: ['Hatalı davranan, takılmış veya yetkisiz bir istemciyi sistemden çıkarmak için', 'İstemcinin otomatik yeniden bağlanmasını (recovery) test etmek için'],
    ex: `rabbitmqctl close_connection "<connection pid>" "maintenance"
rabbitmqctl close_all_user_connections order-service "rotate credentials"`,
    note: 'Bu simülasyonda işlem yalnızca tarayıcıda gerçekleşir.' });
  h('pagination', { t: 'Pagination / Filter', term: 'Sayfalama ve filtre', cat: 'Arayüz',
    what: 'Liste sayfalarında sonuçları sayfalara böler ve ada göre filtreler.',
    role: 'Gerçek UI\'da filtre ve sayfalama sunucu tarafında (HTTP API <code>?page=1&page_size=100&name=...&use_regex=true</code>) yapılır; büyük listelerde performans için önemlidir.',
    use: 'Filter kutusuna yazdığınız metin ada göre (büyük/küçük harf duyarsız) arar. <b>Regex</b> seçiliyse metin düzenli ifade olarak yorumlanır (ör. <code>^orders\\.(paid|created)$</code>).',
    rel: ['regex', 'column-selector'] });
  h('regex', { t: 'Regex', cat: 'Arayüz', what: 'Filtre metnini düzenli ifade (regular expression) olarak yorumlar.', ex: `^orders\\.      → "orders." ile başlayanlar
\\.dlq$         → ".dlq" ile bitenler
payments|orders  → ikisinden birini içerenler` });
  h('column-selector', { t: '+/- (Sütun seçici)', cat: 'Arayüz', what: 'Tabloda hangi sütunların gösterileceğini seçmenizi sağlar. Seçim tarayıcıda saklanır.', use: 'Ek metrikleri (ör. TLS detayları, timeout, client properties) görmek veya tabloyu sadeleştirmek için.' });

  /* ========================= CHANNELS ========================= */
  h('ch-name', { t: 'Channel', cat: 'Channels', what: 'Kanalın adıdır: ait olduğu bağlantının adı ve parantez içinde kanal numarası (channel number). Kanal numarası bağlantı içinde benzersizdir ve 1\'den başlar.', rel: ['channel'] });
  h('ch-mode', { t: 'Mode', term: 'C = confirm, T = transactional', cat: 'Channels',
    what: 'Kanalın yayın güvenilirlik modunu gösterir. <b>C</b>: publisher confirm modu açık. <b>T</b>: AMQP transaction (tx.select) modu açık. Boş: hiçbiri.',
    role: 'Confirm modunda broker her mesajı asenkron olarak onaylar. Transaction modunda <code>tx.commit</code> çağrılana kadar yayınlar ve ack\'ler bekletilir.',
    when: ['Güvenilir yayın için confirm modunu tercih edin', 'Transaction modu çok yavaştır (her commit senkron ve diske yazma gerektirir); yeni uygulamalarda önerilmez'],
    rel: ['confirm-mode', 'transactional'] });
  h('confirm-mode', { t: 'Publisher Confirms', cat: 'Channels',
    what: 'Broker\'ın, yayınlanan her mesajın sorumluluğunu aldığını publisher\'a <code>basic.ack</code> ile bildirdiği mekanizmadır. İşlenemeyen mesajlar için <code>basic.nack</code> gönderilir.',
    role: 'Persistent mesajlar için ack, mesaj diske yazıldıktan (quorum queue\'larda çoğunluk tarafından kabul edildikten) sonra gönderilir.',
    use: 'At-least-once teslim garantisi için şarttır. Nack veya zaman aşımında publisher mesajı yeniden göndermelidir.',
    benefit: 'Transaction\'a göre çok daha yüksek verimle güvenilir yayın sağlar.',
    ex: `channel.confirmSelect();             // Java
channel.basicPublish("orders.events", "order.created.tr", props, body);
channel.waitForConfirmsOrDie(5_000);`,
    rel: ['rate-confirm', 'unconfirmed'] });
  h('transactional', { t: 'Transactions (tx)', cat: 'Channels', what: 'AMQP 0-9-1\'in tx.select / tx.commit / tx.rollback komutlarıyla sunduğu işlem modudur.', role: 'Commit edilene kadar yayınlanan mesajlar kuyruğa girmez. RabbitMQ\'da transaction\'lar yalnızca tek kanal/tek kuyruk kapsamında atomiktir; dağıtık (XA) transaction değildir.', when: ['Mümkünse publisher confirms kullanın; transaction verimi 250 kata kadar düşürebilir'], rel: ['confirm-mode'] });
  h('ch-state', { t: 'State (kanal)', cat: 'Channels', what: 'Kanalın durumu: <b>running</b> (aktif), <b>idle</b> (bir süredir işlem yok), <b>flow</b> (flow control altında), <b>closing</b>.', rel: ['conn-state'] });
  h('unconfirmed', { t: 'Unconfirmed', cat: 'Channels', what: 'Confirm modundaki bir kanalda yayınlanmış ama henüz broker tarafından onaylanmamış (ack/nack beklenen) mesaj sayısıdır.', use: 'Sürekli yüksekse broker yavaş onaylıyordur (disk I/O, quorum replikasyon gecikmesi) veya publisher çok fazla bekleyen mesaj biriktiriyordur.', when: ['Publisher tarafında "in-flight" mesaj sayısını sınırlamak iyi bir uygulamadır'], rel: ['confirm-mode'] });
  h('prefetch', { t: 'Prefetch Count', term: 'basic.qos', cat: 'Channels',
    what: 'Bir consumer\'a aynı anda ack\'lenmemiş olarak gönderilebilecek maksimum mesaj sayısıdır.',
    role: 'RabbitMQ\'da <code>basic.qos(global=false)</code> her consumer için ayrı limit uygular (UI\'da "Prefetch"). <code>global=true</code> ise limiti kanal genelinde paylaştırır (UI\'da "Global prefetch").',
    use: 'Consumer\'ın aşırı mesajla boğulmasını engeller ve yükü consumer\'lar arasında dengeli dağıtır. 0 = sınırsız (önerilmez).',
    when: ['Uzun süren işler için düşük (1–10), hızlı işlemler için daha yüksek (100–300) değerler kullanın', 'Ölçüm yaparak ayarlayın: çok düşük → düşük throughput, çok yüksek → dengesiz dağılım ve bellek kullanımı'],
    benefit: 'Doğru prefetch hem verimi hem de adil dağıtımı optimize eder.',
    ex: `channel.basicQos(20);          // consumer başına 20
await ch.BasicQosAsync(0, 20, false);`,
    note: '4.x\'te quorum queue\'lar için global QoS desteklenmez; <code>global_qos</code> deprecated olarak işaretlenmiştir.',
    rel: ['unacked', 'consumer'] });
  h('global-prefetch', { t: 'Global prefetch', cat: 'Channels', what: 'basic.qos(global=true) ile kanal genelindeki tüm consumer\'lar için paylaşılan unacked limitidir.', note: 'Deprecated (<code>global_qos</code>); quorum queue\'larla çalışmaz. Consumer başına prefetch kullanın.', rel: ['prefetch'] });
  h('ch-unacked', { t: 'Unacked (kanal)', cat: 'Channels', what: 'Bu kanal üzerinden teslim edilmiş ve henüz ack\'lenmemiş mesaj sayısıdır. Değer, kanaldaki consumer\'ların prefetch toplamını aşamaz.', rel: ['unacked', 'prefetch'] });
  h('uncommitted', { t: 'Uncommitted', cat: 'Channels', what: 'Transaction modundaki bir kanalda commit edilmemiş mesaj ve ack sayısıdır.', rel: ['transactional'] });

  w.HELP_CATS = ['Temel kavramlar', 'Arayüz', 'Overview', 'Mesaj oranları', 'Kuyruk metrikleri', 'Node kaynakları', 'Connections', 'Channels', 'Exchanges', 'Queues', 'Queue arguments', 'Bindings', 'Admin', 'Policies', 'Cluster', 'Federation', 'Shovel', 'Monitoring'];
})(window);
