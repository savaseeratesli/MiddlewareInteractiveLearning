/* Connections ve Channels sayfaları */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};

  function vf(x) { return SIM.vhostOk(x.vhost); }

  /* ---------------- Connections listesi ---------------- */
  P.connections = function () {
    return '<h1>Connections ' + UI.help('connection') + '</h1>' + UI.section('All connections (' + SIM.S.connections.filter(vf).length + ')', UI.listTable({
      id: 'connections', rows: function () { return SIM.S.connections.filter(vf); },
      filterText: function (c) { return c.name + ' ' + (c.client_properties.connection_name || ''); },
      cols: [
        { key: 'vhost', label: 'Virtual host', group: 'Overview', help: 'vhost' },
        { key: 'name', label: 'Name', group: 'Overview', help: 'conn-name', fixed: true, render: function (c) {
          var cn = c.client_properties.connection_name;
          return UI.connLink(c.name) + (cn && cn !== c.name ? '<div class="small muted">' + esc(cn) + '</div>' : '');
        } },
        { key: 'node', label: 'Node', group: 'Overview', help: 'conn-node' },
        { key: 'container_id', label: 'Container ID', group: 'Overview', help: 'container-id' },
        { key: 'user', label: 'User name', group: 'Overview', help: 'conn-user', cls: 'c' },
        { key: 'state', label: 'State', group: 'Overview', help: 'conn-state', sort: function (c) { return c.l_state; }, render: function (c) { return UI.state(c.l_state || c.state); } },
        { key: 'ssl', label: 'SSL / TLS', group: 'Details', help: 'ssl-tls', cls: 'c', render: function (c) { return UI.bool(c.ssl); } },
        { key: 'ssl_protocol', label: 'TLS version', group: 'Details', hidden: true, render: function (c) { return c.ssl_protocol || ''; } },
        { key: 'protocol', label: 'Protocol', group: 'Details', help: 'protocol' },
        { key: 'auth', label: 'Auth mechanism', group: 'Details', hidden: true, help: 'auth-mechanism', render: function (c) { return esc(c.auth_mechanism); } },
        { key: 'client', label: 'Client', group: 'Details', hidden: true, help: 'client-properties', render: function (c) { return esc((c.client_properties.product || '') + ' ' + (c.client_properties.version || '')); } },
        { key: 'timeout', label: 'Heartbeat', group: 'Details', hidden: true, help: 'heartbeat', render: function (c) { return c.timeout ? c.timeout + 's' : ''; } },
        { key: 'connected_at', label: 'Connected at', group: 'Details', hidden: true, render: function (c) { return U.fmtDate(new Date(c.connected_at)); } },
        { key: 'channels_n', label: 'Channels', group: 'Details', help: 'conn-channels', cls: 'r', sort: function (c) { return SIM.channelsOf(c.name).length; }, render: function (c) { return SIM.channelsOf(c.name).length; } },
        { key: 'peer', label: 'Client IP:Port', group: 'Network', hidden: true, help: 'client-ip', render: function (c) { return c.peer_host ? esc(c.peer_host + ':' + c.peer_port) : '<span class="muted">direct</span>'; } },
        { key: 'recv', label: 'From client', group: 'Network', help: 'from-client', sort: function (c) { return c.l_recv; }, render: function (c) { return U.fmtBytesRate(c.l_recv || 0); } },
        { key: 'send', label: 'To client', group: 'Network', help: 'to-client', sort: function (c) { return c.l_send; }, render: function (c) { return U.fmtBytesRate(c.l_send || 0); } }
      ]
    }), { id: 'conn-all' });
  };

  /* ---------------- Connection detay ---------------- */
  P.connection = function (name) {
    var c = SIM.connection(name);
    if (!c) return P.notFound('Connection', name) + '<p class="muted">Bağlantı kapatılmış olabilir. İstemciler genellikle otomatik olarak yeniden bağlanır (automatic recovery).</p>';
    var h = ['<h1>Connection <b>' + esc(c.name) + '</b> ' + UI.help('connection') + '</h1>'];
    var cp = c.client_properties;
    h.push(UI.section('Overview', UI.chart({
      id: 'conn-rates', title: 'Data rates', help: 'from-client', unit: 'bytes', legendCols: 1,
      get: function (range) {
        var e = SIM.hist.c[c.name] || { recv: [0], send: [0] };
        return { times: SIM.slice(SIM.hist.t, range), series: [
          { key: 'recv', label: 'From client', color: Charts.COLORS.recv, data: SIM.slice(e.recv, range), value: U.fmtBytesRate(e.recv[e.recv.length - 1]), help: 'from-client' },
          { key: 'send', label: 'To client', color: Charts.COLORS.send, data: SIM.slice(e.send, range), value: U.fmtBytesRate(e.send[e.send.length - 1]), help: 'to-client' }
        ] };
      }
    }) + UI.h3('Details') + '<div class="facts-cols">' + UI.facts([
      ['Virtual host', UI.vhostLink(c.vhost), 'vhost'],
      ['Username', UI.userLink(c.user), 'conn-user'],
      ['Protocol', esc(c.protocol), 'protocol'],
      ['Connected at', U.fmtDate(new Date(c.connected_at))],
      ['Authentication', esc(c.auth_mechanism), 'auth-mechanism'],
      c.container_id ? ['Container ID', esc(c.container_id), 'container-id'] : null
    ]) + UI.block(function () {
      return UI.facts([
        ['Node', UI.nodeLink(c.node), 'conn-node'],
        ['State', UI.state(c.l_state || c.state), 'conn-state'],
        ['Heartbeat', c.timeout ? c.timeout + 's' : '–', 'heartbeat'],
        ['Frame max', c.protocol.indexOf('AMQP 0-9-1') === 0 ? U.fmtNum(c.frame_max) + ' bytes' : '–', 'frame-max'],
        ['Channel limit', c.protocol.indexOf('AMQP 0-9-1') === 0 ? c.channel_max + ' channels' : '–', 'frame-max'],
        ['Client', c.peer_host ? esc(c.peer_host + ':' + c.peer_port) : '<span class="muted">Direct (broker içi)</span>', 'client-ip'],
        ['Server', c.host ? esc(c.host + ':' + c.port) : '–']
      ]);
    }) + '</div>' + (c.ssl ? UI.h3('SSL / TLS', 'ssl-tls') + UI.facts([['Protocol', c.ssl_protocol], ['Cipher', c.ssl_cipher], ['Peer certificate', c.peer_cert_subject || '<span class="muted">(yok – sunucu tarafı TLS)</span>']]) : ''), { id: 'conn-ov' }));

    var chs = SIM.channelsOf(c.name);
    h.push(UI.section('Channels (' + chs.length + ')', chs.length ? UI.listTable({
      id: 'conn-channels', paginate: false, colsel: false, rows: function () { return SIM.channelsOf(c.name); },
      cols: channelCols().filter(function (x) { return ['vhost', 'user'].indexOf(x.key) < 0; })
    }) : '<p class="muted">' + (c.protocol.indexOf('MQTT') === 0 || c.protocol === 'AMQP 1.0' ? 'Bu protokolde AMQP 0-9-1 anlamında kanal bulunmaz (MQTT\'de oturum, AMQP 1.0\'da session/link kullanılır).' : 'Açık kanal yok.') + '</p>', { id: 'conn-ch', help: 'channel' }));

    h.push(UI.section('Client properties', clientProps(cp), { id: 'conn-cp', help: 'client-properties' }));
    h.push(UI.section('Runtime Metrics (Advanced)', UI.facts([
      ['Bytes received', U.fmtBytes(c.recv_oct)], ['Bytes sent', U.fmtBytes(c.send_oct)],
      ['Reductions', U.fmtNum(c.reductions)], ['GC heap', U.fmtBytes(c.gc_heap)]
    ]), { id: 'conn-rt', closed: true }));
    h.push(UI.section('Close this connection', '<form data-form="close-conn" data-name="' + esc(c.name) + '"><table class="form">' +
      UI.formRow('Reason', '<input type="text" name="reason" value="Closed via management plugin">', 'close-connection') +
      '</table><button type="submit" class="danger">Force Close</button></form>', { id: 'conn-close', closed: true, help: 'close-connection' }));
    return h.join('');
  };

  function clientProps(cp) {
    var rows = [];
    Object.keys(cp).forEach(function (k) {
      var v = cp[k];
      if (k === 'capabilities') {
        rows.push(['capabilities', '<table class="facts">' + Object.keys(v).map(function (x) { return '<tr><th>' + esc(x) + ':</th><td>' + v[x] + '</td></tr>'; }).join('') + '</table>']);
      } else rows.push([esc(k), esc(v)]);
    });
    return rows.length ? UI.facts(rows) : '<p class="muted">İstemci özellik bildirmedi.</p>';
  }

  /* ---------------- Channels ---------------- */
  function channelCols() {
    return [
      { key: 'name', label: 'Channel', group: 'Overview', help: 'ch-name', fixed: true, render: function (c) { return UI.chLink(c.name); } },
      { key: 'node', label: 'Node', group: 'Overview', hidden: true },
      { key: 'vhost', label: 'Virtual host', group: 'Overview', help: 'vhost' },
      { key: 'user', label: 'User name', group: 'Overview', help: 'conn-user' },
      { key: 'mode', label: 'Mode', group: 'Overview', help: 'ch-mode', cls: 'c', sort: function (c) { return (c.confirm ? 'C' : '') + (c.transactional ? 'T' : ''); }, render: function (c) {
        return (c.confirm ? '<abbr title="Confirm">C</abbr>' : '') + (c.transactional ? '<abbr title="Transactional">T</abbr>' : '');
      } },
      { key: 'state', label: 'State', group: 'Overview', help: 'ch-state', render: function (c) { var st = c.state === 'running' && !c.l_pub && !c.l_del ? 'idle' : c.state; return UI.state(st); } },
      { key: 'unconfirmed', label: 'Unconfirmed', group: 'Details', help: 'unconfirmed', cls: 'r', render: function (c) { return c.confirm ? U.fmtNum(c.l_unconfirmed || 0) : ''; } },
      { key: 'prefetch', label: 'Prefetch', group: 'Details', help: 'prefetch', cls: 'r', render: function (c) { return c.prefetch || (SIM.consumersOnChannel(c.name).length ? '<span class="muted">0 (∞)</span>' : ''); } },
      { key: 'unacked', label: 'Unacked', group: 'Details', help: 'ch-unacked', cls: 'r', sort: function (c) { return c.l_unacked; }, render: function (c) { return U.fmtNum(c.l_unacked || 0); } },
      { key: 'global_prefetch', label: 'Global prefetch', group: 'Details', hidden: true, help: 'global-prefetch', cls: 'r', render: function (c) { return c.global_prefetch || ''; } },
      { key: 'consumers', label: 'Consumers', group: 'Details', hidden: true, cls: 'r', render: function (c) { return SIM.consumersOnChannel(c.name).length; } },
      { key: 'pub', label: 'publish', group: 'Message rates', help: 'rate-publish', cls: 'r', sort: function (c) { return c.l_pub; }, render: function (c) { return c.r_pub ? U.fmtRate(c.l_pub) : ''; } },
      { key: 'confirm', label: 'confirm', group: 'Message rates', help: 'rate-confirm', cls: 'r', render: function (c) { return c.confirm ? U.fmtRate(c.l_confirm) : ''; } },
      { key: 'unroutable', label: 'unroutable (drop)', group: 'Message rates', help: 'rate-unroutable-drop', cls: 'r', render: function (c) { return c.r_pub ? U.fmtRate(0) : ''; } },
      { key: 'del', label: 'deliver / get', group: 'Message rates', help: 'rate-deliver-manual', cls: 'r', sort: function (c) { return c.l_del; }, render: function (c) { return c.r_deliver ? U.fmtRate(c.l_del) : ''; } },
      { key: 'ack', label: 'ack', group: 'Message rates', help: 'rate-consumer-ack', cls: 'r', render: function (c) { var auto = SIM.consumersOnChannel(c.name).some(function (k) { return !k.ack_required; }); return c.r_deliver && !auto ? U.fmtRate(c.l_ack) : ''; } }
    ];
  }

  P.channels = function () {
    return '<h1>Channels ' + UI.help('channel') + '</h1>' + UI.section('All channels (' + SIM.S.channels.filter(vf).length + ')', UI.listTable({
      id: 'channels', rows: function () { return SIM.S.channels.filter(vf); }, cols: channelCols()
    }), { id: 'ch-all' }) + '<div class="edu-note"><b>İpucu:</b> <b>Mode</b> sütununda <b>C</b> görünen kanallar publisher confirm kullanır. Prefetch boş ve consumer\'ı olan kanallar sınırsız (0) prefetch ile çalışır – bu, consumer belleğini tüketebilir.</div>';
  };

  P.channel = function (name) {
    var c = SIM.channel(name);
    if (!c) return P.notFound('Channel', name);
    var h = ['<h1>Channel <b>' + esc(c.name) + '</b> ' + UI.help('channel') + '</h1>'];
    h.push(UI.section('Overview', UI.chart({
      id: 'ch-rates', title: 'Message rates', help: 'message-rates', unit: 'rate', legendCols: 2,
      get: function (range) {
        var times = SIM.slice(SIM.hist.t, range);
        function fake(base) { return times.map(function () { return U.jitter(base, 0.15); }); }
        return { times: times, series: [
          { key: 'publish', label: 'Publish', color: Charts.COLORS.publish, data: fake(c.r_pub), value: U.fmtRate(c.l_pub || 0), help: 'rate-publish' },
          { key: 'confirm', label: 'Confirm', color: Charts.COLORS.confirm, data: fake(c.confirm ? c.r_pub : 0), value: U.fmtRate(c.l_confirm || 0), help: 'rate-confirm' },
          { key: 'deliver_manual', label: 'Deliver', color: Charts.COLORS.deliver_manual, data: fake(c.r_deliver), value: U.fmtRate(c.l_del || 0), help: 'rate-deliver-manual' },
          { key: 'ack', label: 'Ack', color: Charts.COLORS.ack, data: fake(c.r_ack), value: U.fmtRate(c.l_ack || 0), help: 'rate-consumer-ack' }
        ] };
      }
    }) + UI.h3('Details') + '<div class="facts-cols">' + UI.facts([
      ['Connection', UI.connLink(c.connection), 'connection'],
      ['Node', UI.nodeLink(c.node), 'conn-node'],
      ['Virtual host', UI.vhostLink(c.vhost), 'vhost'],
      ['Username', UI.userLink(c.user), 'conn-user'],
      ['Mode', (c.confirm ? 'Confirm' : '') + (c.transactional ? 'Transactional' : '') || '<span class="muted">(none)</span>', 'ch-mode']
    ]) + UI.block(function () {
      return UI.facts([
        ['State', UI.state(c.state), 'ch-state'],
        ['Prefetch count', c.prefetch, 'prefetch'],
        ['Global prefetch count', c.global_prefetch, 'global-prefetch'],
        ['Messages unacknowledged', U.fmtNum(c.l_unacked || 0), 'ch-unacked'],
        ['Messages unconfirmed', U.fmtNum(c.l_unconfirmed || 0), 'unconfirmed'],
        ['Messages uncommitted', c.transactional ? Math.round(Math.random() * 3) : 0, 'uncommitted'],
        ['Acks uncommitted', 0, 'uncommitted']
      ]);
    }) + '</div>', { id: 'ch-ov' }));

    var cons = SIM.consumersOnChannel(c.name);
    h.push(UI.section('Consumers (' + cons.length + ')', cons.length ? consumerTable(cons, 'channel') : '<p class="muted">Bu kanalda consumer yok.</p>', { id: 'ch-cons', help: 'consumer' }));
    var pubs = c.publishes_to || [];
    h.push(UI.section('Publishes to exchanges', pubs.length ? '<table class="list"><thead><tr><th>Virtual host</th><th>Exchange</th><th class="r">publish</th>' + (c.confirm ? '<th class="r">confirm</th>' : '') + '</tr></thead><tbody>' + pubs.map(function (p) {
      return '<tr><td>' + esc(p[0]) + '</td><td>' + UI.exLink(p[0], p[1]) + '</td><td class="r">' + U.fmtRate(c.l_pub || 0) + '</td>' + (c.confirm ? '<td class="r">' + U.fmtRate(c.l_confirm || 0) + '</td>' : '') + '</tr>';
    }).join('') + '</tbody></table><p class="muted small">Exchange bazlı oranlar gerçek UI\'da yalnızca <code>rates_mode = detailed</code> iken gösterilir.</p>' : '<p class="muted">Bu kanal yayın yapmıyor (yalnızca tüketim).</p>', { id: 'ch-pub', help: 'publisher' }));
    return h.join('');
  };

  function consumerTable(cons, mode) {
    return '<table class="list"><thead><tr>' + (mode === 'queue' ? '<th>Channel ' + UI.help('channel') + '</th>' : '<th>Queue ' + UI.help('queue') + '</th>') +
      '<th>Consumer tag ' + UI.help('consumer-tag') + '</th><th>Ack required ' + UI.help('ack-required') + '</th><th>Exclusive</th><th>Prefetch count ' + UI.help('prefetch') + '</th><th>Active</th><th>Activity status ' + UI.help('activity-status') + '</th><th>Arguments</th></tr></thead><tbody>' +
      cons.map(function (k) {
        return '<tr><td>' + (mode === 'queue' ? UI.chLink(k.channel) : UI.qLink(k.vhost, k.queue)) + '</td><td>' + esc(k.consumer_tag) + '</td><td class="c">' + UI.bool(k.ack_required) + '</td><td class="c">' + UI.bool(k.exclusive) + '</td><td class="r">' + k.prefetch_count + '</td><td class="c">' + UI.bool(k.active) + '</td><td>' + esc(k.activity_status) + '</td><td>' + U.argsInline(k.arguments) +
          (k.arguments['x-priority'] !== undefined ? ' ' + UI.help('consumer-priority') : '') + (k.arguments['x-stream-offset'] !== undefined ? ' ' + UI.help('x-stream-offset') : '') + '</td></tr>';
      }).join('') + '</tbody></table>';
  }
  P.consumerTable = consumerTable;
})(window);
