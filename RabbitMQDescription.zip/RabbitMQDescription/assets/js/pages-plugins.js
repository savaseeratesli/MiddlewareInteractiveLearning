/* Federation ve Shovel eklenti sayfaları */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};
  function vf(x) { return SIM.vhostOk(x.vhost); }
  function ago(ms) { return U.fmtUptime(Date.now() - ms) + ' önce'; }

  /* ---------------- Federation Status ---------------- */
  P.federation = function () {
    var links = SIM.S.fed_links.filter(vf);
    var h = '<h1>Federation Status ' + UI.help('fed-links') + '</h1>' +
      '<div class="topo"><span class="node-b">dc2-mq / dc3-mq<br><span class="small muted">upstream</span></span><span class="arrow">── AMQP 0-9-1 (5671/TLS) ──▶</span><span class="node-b">' + esc(SIM.S.cluster_name) + '<br><span class="small muted">downstream (bu cluster)</span></span> ' + UI.help('federation') + '</div>' +
      UI.section('Running Links', links.length ? '<table class="list"><thead><tr><th>Upstream ' + UI.help('fed-upstream') + '</th><th>URI ' + UI.help('fed-uri') + '</th><th>Virtual host</th><th>Exchange / Queue ' + UI.help('fed-type') + '</th><th>State ' + UI.help('fed-links') + '</th><th>Inbound message rate</th><th>Last changed</th><th>Error</th></tr></thead><tbody>' + links.map(function (l) {
        return '<tr><td>' + esc(l.upstream) + '</td><td class="mono small">' + esc(l.uri) + '</td><td>' + esc(l.vhost) + '</td><td>' + (l.exchange ? UI.exLink(l.vhost, l.exchange) + ' <span class="muted small">exchange</span>' : UI.qLink(l.vhost, l.queue) + ' <span class="muted small">queue</span>') + '</td><td>' + UI.state(l.status === 'error' ? 'down' : l.status) + (l.status === 'error' ? ' <span class="err-text">error</span>' : '') + '</td><td class="r">' + (l.status === 'running' ? U.fmtRate(U.jitter(0.9)) : '') + '</td><td>' + ago(l.last_changed) + '</td><td class="err-text small" style="white-space:normal;max-width:380px">' + esc(l.error) + '</td></tr>';
      }).join('') + '</tbody></table>' : '<p class="muted">... no links ...</p>', { id: 'fed-links' }) +
      '<div class="edu-note"><b>Nasıl çalışıyor?</b> <code>federate-orders</code> policy\'si <code>^federated\\.</code> desenine uyan exchange\'lere <code>federation-upstream-set: all</code> uygular. Bu yüzden <code>federated.orders</code> exchange\'i için tanımlı her upstream\'e bir link açılır. <b>dc3-orders</b> link\'i kimlik doğrulama hatası veriyor – gerçek hayatta upstream\'deki <code>federation-user</code> parolası/izinleri kontrol edilmelidir. ' + UI.help('policy') + '</div>';
    return P.adminWrap('federation', h);
  };

  /* ---------------- Federation Upstreams ---------------- */
  P.federationUpstreams = function () {
    var ups = SIM.S.fed_upstreams.filter(vf);
    var h = '<h1>Federation Upstreams ' + UI.help('fed-upstream') + '</h1>' +
      UI.section('Upstreams', ups.length ? '<table class="list"><thead><tr><th>Virtual Host</th><th>Name</th><th>URI ' + UI.help('fed-uri') + '</th><th>Prefetch Count ' + UI.help('fed-prefetch') + '</th><th>Reconnect Delay</th><th>Ack mode ' + UI.help('fed-ack-mode') + '</th><th>Trust User-ID ' + UI.help('fed-trust-user-id') + '</th><th>Exchange ' + UI.help('fed-exchange') + '</th><th>Max Hops ' + UI.help('fed-max-hops') + '</th><th>Expiry ' + UI.help('fed-expires') + '</th><th>Queue type</th><th></th></tr></thead><tbody>' + ups.map(function (u) {
        return '<tr><td>' + esc(u.vhost) + '</td><td><b>' + esc(u.name) + '</b></td><td class="mono small">' + esc(u.uri) + '</td><td class="r">' + u.prefetch_count + '</td><td class="r">' + u.reconnect_delay + 's</td><td>' + esc(u.ack_mode) + '</td><td class="c">' + UI.bool(u.trust_user_id) + '</td><td>' + esc(u.exchange) + '</td><td class="r">' + u.max_hops + '</td><td class="r">' + (u.expires ? U.fmtNum(u.expires) + ' ms' : '') + '</td><td>' + esc(u.queue_type || 'classic') + '</td><td><button class="small" data-action="delete-upstream" data-vhost="' + esc(u.vhost) + '" data-name="' + esc(u.name) + '">Delete</button></td></tr>';
      }).join('') + '</tbody></table>' : '<p class="muted">... no upstreams ...</p>', { id: 'fu-all' }) +
      UI.section('Add a new upstream', '<form data-form="add-upstream"><table class="form">' +
        UI.formRow('Virtual host', UI.vhostSelect('vhost'), 'vhost') +
        UI.formRow('Name', '<input type="text" name="name">', null, true) +
        '<tr><th colspan="2" style="text-align:left;padding-top:10px"><b>General parameters</b></th></tr>' +
        UI.formRow('URI', '<input type="text" name="uri" placeholder="amqps://user@remote-host:5671/%2F">', 'fed-uri', true, 'Parola içermeyen örnek URI kullanın; simülasyonda hiçbir bağlantı kurulmaz.') +
        UI.formRow('Prefetch count', '<input type="number" name="prefetch" value="1000">', 'fed-prefetch') +
        UI.formRow('Reconnect delay', '<input type="number" name="reconnect" value="5"> s') +
        UI.formRow('Acknowledgement Mode', UI.select('ack_mode', ['on-confirm', 'on-publish', 'no-ack'], 'on-confirm'), 'fed-ack-mode') +
        UI.formRow('Trust User-ID', UI.select('trust', [['false', 'No'], ['true', 'Yes']], 'false'), 'fed-trust-user-id') +
        '<tr><th colspan="2" style="text-align:left;padding-top:10px"><b>Federated exchanges parameters</b> ' + UI.help('fed-type') + '</th></tr>' +
        UI.formRow('Exchange', '<input type="text" name="exchange">', 'fed-exchange') +
        UI.formRow('Max hops', '<input type="number" name="max_hops" value="1">', 'fed-max-hops') +
        UI.formRow('Expires', '<input type="number" name="expires"> ms', 'fed-expires') +
        UI.formRow('Message TTL', '<input type="number" name="ttl"> ms', 'fed-expires') +
        UI.formRow('Queue Type', UI.select('queue_type', ['classic', 'quorum'], 'classic'), 'q-type') +
        '<tr><th colspan="2" style="text-align:left;padding-top:10px"><b>Federated queues parameter</b></th></tr>' +
        UI.formRow('Queue', '<input type="text" name="queue">', 'fed-exchange') +
        UI.formRow('Consumer tag', '<input type="text" name="ctag">', 'consumer-tag') +
        '</table><button type="submit">Add upstream</button></form>', { id: 'fu-add', closed: true });
    return P.adminWrap('federation-upstreams', h);
  };

  /* ---------------- Shovel Status ---------------- */
  function srcDesc(s) { return esc(s.src_protocol) + ' · ' + (s.src_queue ? 'queue: <b>' + esc(s.src_queue) + '</b>' : s.src_address ? 'address: <b>' + esc(s.src_address) + '</b>' : 'exchange: <b>' + esc(s.src_exchange) + '</b>'); }
  function dstDesc(s) { return esc(s.dest_protocol) + ' · ' + (s.dest_queue ? 'queue: <b>' + esc(s.dest_queue) + '</b>' : s.dest_address ? 'address: <b>' + esc(s.dest_address) + '</b>' : 'exchange: <b>' + esc(s.dest_exchange) + '</b>' + (s.dest_exchange_key ? ' (key: ' + esc(s.dest_exchange_key) + ')' : '')); }
  P.shovels = function () {
    var h = '<h1>Shovel Status ' + UI.help('shovel') + '</h1>' +
      UI.section('Shovels', UI.block(function () {
        var list = SIM.S.shovels.filter(vf);
        if (!list.length) return '<p class="muted">... no shovels ...</p>';
        return '<table class="list"><thead><tr><th>Name</th><th>Virtual host</th><th>Type ' + UI.help('shovel-type') + '</th><th>State ' + UI.help('shovel-state') + '</th><th>Node</th><th>Source ' + UI.help('shovel-src') + '</th><th>Source URI</th><th>Destination ' + UI.help('shovel-dest') + '</th><th>Destination URI</th><th class="r">Forwarded</th><th class="r">Pending</th><th>Last changed</th><th></th></tr></thead><tbody>' + list.map(function (s) {
          return '<tr><td><b>' + esc(s.name) + '</b></td><td>' + esc(s.vhost) + '</td><td>' + esc(s.type) + '</td><td>' + UI.state(s.state) + (s.reason ? '<div class="small muted" style="white-space:normal;max-width:240px">' + esc(s.reason) + '</div>' : '') + '</td><td>' + esc(s.node) + '</td><td>' + srcDesc(s) + '</td><td class="mono small">' + esc(s.src_uri) + '</td><td>' + dstDesc(s) + '</td><td class="mono small">' + esc(s.dest_uri) + '</td><td class="r">' + U.fmtNum(s.forwarded + (s.state === 'running' ? Math.round((Date.now() - SIM.S.seededAt) / 100) : 0)) + '</td><td class="r">' + s.pending + '</td><td>' + ago(s.timestamp) + '</td><td>' + (s.type === 'dynamic' ? '<button class="small" data-action="restart-shovel" data-vhost="' + esc(s.vhost) + '" data-name="' + esc(s.name) + '">Restart</button>' : '<span class="muted small">static</span>') + '</td></tr>';
        }).join('') + '</tbody></table>';
      }), { id: 'sh-all' }) +
      '<div class="edu-note"><b>Örnekler:</b> <code>legacy-orders-migration</code> eski kuyruktaki siparişleri yeni topolojiye taşıyor; <code>clickstream-to-dwh</code> AMQP 1.0 ile harici bir broker\'a köprü kuruyor; <code>dlq-replay</code> <code>src-delete-after: queue-length</code> ile DLQ\'yu bir kez boşaltıp kendini sonlandırdı ' + UI.help('shovel-delete-after') + '</div>';
    return P.adminWrap('shovels', h);
  };

  /* ---------------- Shovel Management ---------------- */
  P.dynamicShovels = function () {
    var list = SIM.S.shovels.filter(function (s) { return s.type === 'dynamic' && vf(s); });
    var h = '<h1>Dynamic Shovels ' + UI.help('shovel-type') + '</h1>' +
      UI.section('Shovels', list.length ? '<table class="list"><thead><tr><th>Virtual Host</th><th>Name</th><th>Source</th><th>Destination</th><th>Ack mode ' + UI.help('shovel-ack-mode') + '</th><th>Prefetch ' + UI.help('shovel-prefetch') + '</th><th>Auto-delete ' + UI.help('shovel-delete-after') + '</th><th>Forward headers ' + UI.help('shovel-forward-headers') + '</th><th></th></tr></thead><tbody>' + list.map(function (s) {
        return '<tr><td>' + esc(s.vhost) + '</td><td><b>' + esc(s.name) + '</b></td><td>' + srcDesc(s) + '<div class="mono small muted">' + esc(s.src_uri) + '</div></td><td>' + dstDesc(s) + '<div class="mono small muted">' + esc(s.dest_uri) + '</div></td><td>' + esc(s.ack_mode) + '</td><td class="r">' + s.src_prefetch + '</td><td>' + esc(s.src_delete_after) + '</td><td class="c">' + UI.bool(s.add_forward_headers) + '</td><td><button class="small" data-action="delete-shovel" data-vhost="' + esc(s.vhost) + '" data-name="' + esc(s.name) + '">Delete</button></td></tr>';
      }).join('') + '</tbody></table>' : '<p class="muted">... no shovels ...</p>', { id: 'ds-all' }) +
      UI.section('Add a new shovel', '<form data-form="add-shovel"><table class="form">' +
        UI.formRow('Virtual host', UI.vhostSelect('vhost'), 'vhost') +
        UI.formRow('Name', '<input type="text" name="name">', null, true) +
        '<tr><th colspan="2" style="text-align:left;padding-top:10px"><b>Source</b> ' + UI.help('shovel-src') + '</th></tr>' +
        UI.formRow('Protocol', UI.select('src_protocol', [['amqp091', 'AMQP 0.9.1'], ['amqp10', 'AMQP 1.0']], 'amqp091'), 'shovel-protocol') +
        UI.formRow('URI', '<input type="text" name="src_uri" value="amqp://">', 'fed-uri', true, '<code>amqp://</code> = yerel broker, varsayılan vhost') +
        UI.formRow(UI.select('src_kind', [['queue', 'Queue'], ['exchange', 'Exchange']], 'queue'), '<input type="text" name="src_name">', 'shovel-src', true) +
        UI.formRow('Routing key (exchange ise)', '<input type="text" name="src_key">') +
        UI.formRow('Prefetch count', '<input type="number" name="prefetch" value="1000">', 'shovel-prefetch') +
        UI.formRow('Auto-delete', UI.select('delete_after', [['never', 'Never'], ['queue-length', 'After initial length transferred']], 'never'), 'shovel-delete-after') +
        '<tr><th colspan="2" style="text-align:left;padding-top:10px"><b>Destination</b> ' + UI.help('shovel-dest') + '</th></tr>' +
        UI.formRow('Protocol', UI.select('dest_protocol', [['amqp091', 'AMQP 0.9.1'], ['amqp10', 'AMQP 1.0']], 'amqp091'), 'shovel-protocol') +
        UI.formRow('URI', '<input type="text" name="dest_uri" value="amqp://">', 'fed-uri', true) +
        UI.formRow(UI.select('dest_kind', [['queue', 'Queue'], ['exchange', 'Exchange']], 'exchange'), '<input type="text" name="dest_name">', 'shovel-dest', true) +
        UI.formRow('Routing key (exchange ise)', '<input type="text" name="dest_key" placeholder="boş: orijinal korunur">') +
        UI.formRow('Add forwarding headers', UI.select('fwd', [['false', 'No'], ['true', 'Yes']], 'false'), 'shovel-forward-headers') +
        UI.formRow('Reconnect delay', '<input type="number" name="reconnect" value="5"> s', 'shovel-reconnect') +
        UI.formRow('Acknowledgement mode', UI.select('ack_mode', [['on-confirm', 'On confirm'], ['on-publish', 'On publish'], ['no-ack', 'No ack']], 'on-confirm'), 'shovel-ack-mode') +
        '</table><button type="submit">Add shovel</button></form>', { id: 'ds-add', closed: true });
    return P.adminWrap('dynamic-shovels', h);
  };
})(window);
