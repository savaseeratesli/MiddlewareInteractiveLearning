/* Admin bölümü: Users, Virtual Hosts, Feature Flags, Deprecated Features, Policies, Limits, Cluster */
(function (w) {
  'use strict';
  var esc = U.esc, P = w.PAGES = w.PAGES || {};

  var MENU = [
    ['users', 'Users', 'user'], ['vhosts', 'Virtual Hosts', 'vhost'], ['feature-flags', 'Feature Flags', 'feature-flags'],
    ['deprecated-features', 'Deprecated Features', 'deprecated-features'], ['policies', 'Policies', 'policy'], ['limits', 'Limits', 'limits-vhost'],
    ['cluster', 'Cluster', 'cluster'],
    ['grp', 'Plugins'],
    ['federation', 'Federation Status', 'fed-links'], ['federation-upstreams', 'Federation Upstreams', 'fed-upstream'],
    ['shovels', 'Shovel Status', 'shovel'], ['dynamic-shovels', 'Shovel Management', 'shovel-type']
  ];
  P.adminWrap = function (sel, content) {
    return '<div class="with-rhs"><div id="rhs"><ul>' + MENU.map(function (m) {
      if (m[0] === 'grp') return '<li class="grp">' + m[1] + '</li>';
      return '<li><a href="#/' + m[0] + '"' + (m[0] === sel ? ' class="selected"' : '') + '><span>' + m[1] + '</span></a></li>';
    }).join('') + '</ul></div><div class="lhs">' + content + '</div></div>';
  };

  /* ---------------- Users ---------------- */
  function canAccess(u) { return SIM.S.permissions.filter(function (p) { return p.user === u; }).map(function (p) { return p.vhost; }); }
  P.users = function () {
    var h = '<h1>Users ' + UI.help('user') + '</h1>' + UI.section('All users (' + SIM.S.users.length + ')', UI.listTable({
      id: 'users', rows: function () { return SIM.S.users; },
      cols: [
        { key: 'name', label: 'Name', fixed: true, render: function (u) { return UI.userLink(u.name); } },
        { key: 'tags', label: 'Tags', help: 'user-tags', sort: function (u) { return u.tags.join(','); }, render: function (u) { return esc(u.tags.join(', ')); } },
        { key: 'access', label: 'Can access virtual hosts', help: 'permissions', nosort: true, render: function (u) { var v = canAccess(u.name); return v.length ? v.map(esc).join(', ') : '<span class="muted">No access</span>'; } },
        { key: 'has_password', label: 'Has password', cls: 'c', render: function (u) { return UI.bool(u.has_password) + (u.has_password ? '' : ' <span class="small muted">(x509 / EXTERNAL)</span>'); } }
      ]
    }), { id: 'users-all' }) + UI.section('Add a user', userForm(), { id: 'user-add', closed: true }) +
      '<div class="edu-note"><b>Not:</b> Varsayılan <code>guest</code> kullanıcısı bu simülasyonda silinmiş durumdadır – üretim ortamları için önerilen uygulama budur ' + UI.help('user') + '</div>';
    return P.adminWrap('users', h);
  };
  function tagLinks() {
    return '<div class="args-quick">Set: ' + ['administrator', 'monitoring', 'policymaker', 'management', 'impersonator'].map(function (t) {
      return '<a data-action="set-tag" data-tag="' + t + '">' + t.charAt(0).toUpperCase() + t.slice(1).replace('istrator', '') + '</a>';
    }).join(' | ') + ' | <a data-action="set-tag" data-tag="">None</a> ' + UI.help('user-tags') + '</div>';
  }
  function userForm(u) {
    return '<form data-form="' + (u ? 'update-user' : 'add-user') + '"' + (u ? ' data-name="' + esc(u.name) + '"' : '') + '><table class="form">' +
      (u ? '' : UI.formRow('Username', '<input type="text" name="name" autocomplete="off">', 'user', true)) +
      UI.formRow('Password', UI.select('pwmode', [['password', 'Password'], ['nopassword', 'No password']], 'password') + '<br><input type="password" name="password" autocomplete="new-password" placeholder="(simülasyon – saklanmaz)"><br><input type="password" name="password2" autocomplete="new-password" placeholder="(tekrar)">', null, !u,
        'Simülasyonda parola hiçbir yere gönderilmez ve saklanmaz. Gerçek RabbitMQ parolayı hash\'leyerek (SHA-256) saklar.') +
      UI.formRow('Tags', '<input type="text" name="tags" value="' + esc(u ? u.tags.join(', ') : '') + '">' + tagLinks(), 'user-tags') +
      '</table><button type="submit">' + (u ? 'Update user' : 'Add user') + '</button></form>';
  }

  P.userPage = function (name) {
    var u = SIM.user(name);
    if (!u) return P.adminWrap('users', P.notFound('User', name));
    var perms = SIM.S.permissions.filter(function (p) { return p.user === name; });
    var tperms = SIM.S.topic_permissions.filter(function (p) { return p.user === name; });
    var lim = SIM.S.user_limits.filter(function (l) { return l.user === name; })[0];
    var conns = SIM.S.connections.filter(function (c) { return c.user === name; });
    var h = '<h1>User <b>' + esc(name) + '</b> ' + UI.help('user') + '</h1>' +
      UI.section('Overview', UI.facts([
        ['Tags', esc(u.tags.join(', ')) || '<span class="muted">(none – UI erişimi yok)</span>', 'user-tags'],
        ['Can log in with password', UI.bool(u.has_password)],
        ['Password hashing', esc(u.hashing)],
        ['Open connections', conns.length ? conns.length + ' · ' + conns.slice(0, 3).map(function (c) { return UI.connLink(c.name); }).join(', ') + (conns.length > 3 ? ' …' : '') : '0', 'connection'],
        ['Limits', lim ? U.argsInline(lim.value) : '', 'limits-user']
      ]), { id: 'user-ov' }) +
      UI.section('Permissions', permTable(perms, 'user') + permForm({ user: name }), { id: 'user-perm', help: 'permissions' }) +
      UI.section('Topic permissions', topicPermTable(tperms, 'user') + topicPermForm({ user: name }), { id: 'user-tperm', help: 'topic-permissions' }) +
      UI.section('Update this user', userForm(u), { id: 'user-upd', closed: true }) +
      UI.section('Delete this user', '<form data-form="delete-user" data-name="' + esc(name) + '"><p>Kullanıcıyı silmek, bu kullanıcıyla açık olan tüm bağlantıları da kapatır.</p><button type="submit" class="danger">Delete</button></form>', { id: 'user-del', closed: true });
    return P.adminWrap('users', h);
  };

  function permTable(perms, mode) {
    if (!perms.length) return '<p class="muted">... no permissions ...</p>';
    return '<table class="list"><thead><tr><th>' + (mode === 'user' ? 'Virtual host' : 'User') + '</th><th>Configure regexp ' + UI.help('permissions') + '</th><th>Write regexp</th><th>Read regexp</th><th></th></tr></thead><tbody>' + perms.map(function (p) {
      return '<tr><td>' + (mode === 'user' ? UI.vhostLink(p.vhost) : UI.userLink(p.user)) + '</td><td class="mono">' + esc(p.configure) + '</td><td class="mono">' + esc(p.write) + '</td><td class="mono">' + esc(p.read) + '</td><td><button class="small" data-action="clear-perm" data-user="' + esc(p.user) + '" data-vhost="' + esc(p.vhost) + '">Clear</button></td></tr>';
    }).join('') + '</tbody></table>';
  }
  function permForm(fix) {
    return UI.h3('Set permission', 'permissions') + '<form data-form="set-perm"><table class="form">' +
      (fix.user ? '<input type="hidden" name="user" value="' + esc(fix.user) + '">' + UI.formRow('Virtual Host', UI.vhostSelect('vhost')) : '<input type="hidden" name="vhost" value="' + esc(fix.vhost) + '">' + UI.formRow('User', UI.select('user', SIM.S.users.map(function (u) { return u.name; })))) +
      UI.formRow('Configure regexp', '<input type="text" name="configure" value=".*">', 'permissions') +
      UI.formRow('Write regexp', '<input type="text" name="write" value=".*">') +
      UI.formRow('Read regexp', '<input type="text" name="read" value=".*">') +
      '</table><button type="submit">Set permission</button></form>';
  }
  function topicPermTable(perms, mode) {
    if (!perms.length) return '<p class="muted">... no topic permissions ...</p>';
    return '<table class="list"><thead><tr><th>' + (mode === 'user' ? 'Virtual host' : 'User') + '</th><th>Exchange</th><th>Write regexp</th><th>Read regexp</th><th></th></tr></thead><tbody>' + perms.map(function (p) {
      return '<tr><td>' + (mode === 'user' ? UI.vhostLink(p.vhost) : UI.userLink(p.user)) + '</td><td>' + esc(p.exchange) + '</td><td class="mono">' + esc(p.write) + '</td><td class="mono">' + esc(p.read) + '</td><td><button class="small" data-action="clear-tperm" data-user="' + esc(p.user) + '" data-vhost="' + esc(p.vhost) + '" data-ex="' + esc(p.exchange) + '">Clear</button></td></tr>';
    }).join('') + '</tbody></table>';
  }
  function topicPermForm(fix) {
    return UI.h3('Set topic permission', 'topic-permissions') + '<form data-form="set-tperm"><table class="form">' +
      (fix.user ? '<input type="hidden" name="user" value="' + esc(fix.user) + '">' + UI.formRow('Virtual Host', UI.vhostSelect('vhost')) : '<input type="hidden" name="vhost" value="' + esc(fix.vhost) + '">' + UI.formRow('User', UI.select('user', SIM.S.users.map(function (u) { return u.name; })))) +
      UI.formRow('Exchange', UI.select('exchange', SIM.S.exchanges.filter(function (e) { return e.type === 'topic' && (!fix.vhost || e.vhost === fix.vhost); }).map(function (e) { return e.name; }).filter(function (v, i, a) { return a.indexOf(v) === i; }), 'amq.topic')) +
      UI.formRow('Write regexp', '<input type="text" name="write" value=".*">') +
      UI.formRow('Read regexp', '<input type="text" name="read" value=".*">') +
      '</table><button type="submit">Set topic permission</button></form>';
  }

  /* ---------------- Virtual hosts ---------------- */
  function vhStats(v) {
    var r = 0, u = 0, pub = 0, del = 0, recv = 0, send = 0;
    SIM.S.queues.forEach(function (q) { if (q.vhost === v) { r += q.ready; u += q.unacked; del += q.l_del || 0; } });
    SIM.S.channels.forEach(function (c) { if (c.vhost === v) pub += c.l_pub || 0; });
    SIM.S.connections.forEach(function (c) { if (c.vhost === v) { recv += c.l_recv || 0; send += c.l_send || 0; } });
    return { ready: r, unacked: u, pub: pub, del: del, recv: recv, send: send };
  }
  P.vhosts = function () {
    var h = '<h1>Virtual Hosts ' + UI.help('vhost') + '</h1>' + UI.section('All virtual hosts', UI.listTable({
      id: 'vhosts', rows: function () { return SIM.S.vhosts; },
      cols: [
        { key: 'name', label: 'Name', group: 'Overview', fixed: true, render: function (v) { return UI.vhostLink(v.name); } },
        { key: 'users', label: 'Users', group: 'Overview', help: 'permissions', nosort: true, render: function (v) { return SIM.S.permissions.filter(function (p) { return p.vhost === v.name; }).map(function (p) { return esc(p.user); }).join(', '); } },
        { key: 'state', label: 'State', group: 'Overview', help: 'vhost-cluster-state', render: function () { return UI.state('running'); } },
        { key: 'description', label: 'Description', group: 'Overview', help: 'vhost-tags', hidden: true },
        { key: 'tags', label: 'Tags', group: 'Overview', hidden: true, render: function (v) { return esc(v.tags.join(', ')); } },
        { key: 'default_queue_type', label: 'Default queue type', group: 'Overview', help: 'vhost-default-qt' },
        { key: 'tracing', label: 'Tracing', group: 'Overview', hidden: true, help: 'vhost-tracing', render: function (v) { return UI.bool(v.tracing); } },
        { key: 'ready', label: 'Ready', group: 'Messages', cls: 'r', sort: function (v) { return vhStats(v.name).ready; }, render: function (v) { return U.fmtNum(vhStats(v.name).ready); } },
        { key: 'unacked', label: 'Unacked', group: 'Messages', cls: 'r', render: function (v) { return U.fmtNum(vhStats(v.name).unacked); } },
        { key: 'total', label: 'Total', group: 'Messages', cls: 'r', render: function (v) { var s = vhStats(v.name); return U.fmtNum(s.ready + s.unacked); } },
        { key: 'recv', label: 'From client', group: 'Network', cls: 'r', render: function (v) { return U.fmtBytesRate(vhStats(v.name).recv); } },
        { key: 'send', label: 'To client', group: 'Network', cls: 'r', render: function (v) { return U.fmtBytesRate(vhStats(v.name).send); } },
        { key: 'pub', label: 'publish', group: 'Message rates', cls: 'r', render: function (v) { return U.fmtRate(vhStats(v.name).pub); } },
        { key: 'del', label: 'deliver / get', group: 'Message rates', cls: 'r', render: function (v) { return U.fmtRate(vhStats(v.name).del); } }
      ]
    }), { id: 'vh-all' }) + UI.section('Add a new virtual host', '<form data-form="add-vhost"><table class="form">' +
      UI.formRow('Name', '<input type="text" name="name">', 'vhost', true) +
      UI.formRow('Description', '<input type="text" name="description">', 'vhost-tags') +
      UI.formRow('Tags', '<input type="text" name="tags" placeholder="virgülle ayırın">', 'vhost-tags') +
      UI.formRow('Default Queue Type', UI.select('dqt', [['classic', 'Classic'], ['quorum', 'Quorum'], ['stream', 'Stream']], 'quorum'), 'vhost-default-qt') +
      '</table><button type="submit">Add virtual host</button></form>', { id: 'vh-add', closed: true });
    return P.adminWrap('vhosts', h);
  };
  P.vhostPage = function (name) {
    var v = SIM.vhostObj(name);
    if (!v) return P.adminWrap('vhosts', P.notFound('Virtual host', name));
    var lim = SIM.S.vhost_limits.filter(function (l) { return l.vhost === name; })[0];
    var store = function () { return SIM.hist.ovv[name] || {}; };
    var h = '<h1>Virtual Host <b>' + esc(name) + '</b> ' + UI.help('vhost') + '</h1>' +
      UI.section('Overview', P.queuedChart('vh-queued', store) + UI.h3('Details') + UI.facts([
        ['Description', esc(v.description), 'vhost-tags'],
        ['Tags', esc(v.tags.join(', ')), 'vhost-tags'],
        ['Default queue type', esc(v.default_queue_type), 'vhost-default-qt'],
        ['Tracing', (v.tracing ? '<b class="warn-text">ON</b>' : 'off') + ' <button class="small" data-action="toggle-tracing" data-vhost="' + esc(name) + '">' + (v.tracing ? 'Disable' : 'Enable') + ' tracing</button>', 'vhost-tracing'],
        ['Limits', lim ? U.argsInline(lim.value) : '', 'limits-vhost'],
        ['Deletion protection', v.protected ? '● (protected)' : '○']
      ]) + UI.h3('Cluster state', 'vhost-cluster-state') + '<table class="list"><tbody>' + SIM.S.nodes.map(function (n) { return '<tr><td>' + UI.nodeLink(n.name) + '</td><td>' + UI.state(n.running ? 'running' : 'stopped') + '</td></tr>'; }).join('') + '</tbody></table>', { id: 'vh-ov' }) +
      UI.section('Permissions', permTable(SIM.S.permissions.filter(function (p) { return p.vhost === name; }), 'vhost') + permForm({ vhost: name }), { id: 'vh-perm', help: 'permissions' }) +
      UI.section('Topic permissions', topicPermTable(SIM.S.topic_permissions.filter(function (p) { return p.vhost === name; }), 'vhost') + topicPermForm({ vhost: name }), { id: 'vh-tperm', closed: true, help: 'topic-permissions' }) +
      UI.section('Delete this vhost', '<form data-form="delete-vhost" data-name="' + esc(name) + '">' + (v.protected ? '<div class="form-msg warn">Bu vhost <b>silme korumalı</b> (deletion protection). Gerçek RabbitMQ\'da önce <code>rabbitmqctl disable_vhost_deletion_protection ' + esc(name) + '</code> gerekir.</div>' : '') +
        '<p>Vhost silindiğinde içindeki tüm exchange, queue (mesajlarıyla), binding, policy ve izinler silinir; bağlantılar kapatılır. <b>Geri alınamaz.</b></p><button type="submit" class="danger"' + (v.protected || name === '/' ? ' disabled' : '') + '>Delete this virtual host</button></form>', { id: 'vh-del', closed: true });
    return P.adminWrap('vhosts', h);
  };

  /* ---------------- Feature Flags ---------------- */
  P.featureFlags = function () {
    var ff = SIM.S.feature_flags;
    function tbl(list) {
      return '<table class="list"><thead><tr><th>Name</th><th>State</th><th>Description</th></tr></thead><tbody>' + list.map(function (f) {
        return '<tr><td>' + esc(f.name) + (f.name === 'khepri_db' ? ' ' + UI.help('khepri') : '') + '</td><td>' + (f.state === 'enabled' ? '<span class="status-green">Enabled</span>' : '<button class="small" data-action="enable-ff" data-name="' + esc(f.name) + '">Enable</button>') + '</td><td>' + esc(f.desc) + '</td></tr>';
      }).join('') + '</tbody></table>';
    }
    var stable = ff.filter(function (f) { return f.stability === 'stable'; });
    var req = ff.filter(function (f) { return f.stability === 'required'; });
    var exp = ff.filter(function (f) { return f.stability === 'experimental'; });
    var disabled = stable.filter(function (f) { return f.state !== 'enabled'; }).length;
    var h = '<h1>Feature Flags ' + UI.help('feature-flags') + '</h1>' +
      (disabled ? '<div class="form-msg warn">' + disabled + ' stable feature flag devre dışı. Bir sonraki sürüme yükseltmeden önce tüm stable flag\'lerin etkinleştirilmesi gerekir. <button class="small" data-action="enable-ff" data-name="all">Enable all stable feature flags</button></div>' : '') +
      UI.section('Feature Flags (stable)', tbl(stable), { id: 'ff-stable', help: 'ff-stability' }) +
      (exp.length ? UI.section('Experimental Feature Flags', tbl(exp), { id: 'ff-exp' }) : '') +
      UI.section('Required Feature Flags (' + req.length + ')', '<p class="muted small">Required flag\'ler her zaman etkindir ve devre dışı bırakılamaz ' + UI.help('ff-stability') + '</p>' + tbl(req), { id: 'ff-req', closed: true });
    return P.adminWrap('feature-flags', h);
  };

  P.deprecatedFeatures = function () {
    SIM.deprecatedInUse();
    var list = SIM.S.deprecated_features;
    var used = list.filter(function (f) { return f.used; });
    var h = '<h1>Deprecated Features ' + UI.help('deprecated-features') + '</h1>' +
      (used.length ? '<div class="form-msg warn"><b>Deprecated features in use:</b> ' + used.map(function (f) { return '<code>' + esc(f.name) + '</code>'; }).join(', ') +
        (used.some(function (f) { return f.name === 'transient_nonexcl_queues'; }) ? '<br>→ Neden: <a href="#/queues/notifications/notifications.temp">notifications.temp</a> kuyruğu durable değil ve exclusive değil. Kuyruğu silip durable (veya exclusive) olarak yeniden oluşturursanız uyarı kaybolur.' : '') + '</div>' : '<div class="form-msg">Şu anda kullanılan deprecated özellik yok.</div>') +
      UI.section('All deprecated features', '<table class="list"><thead><tr><th>Name</th><th>Deprecation phase ' + UI.help('deprecated-features') + '</th><th>In use</th><th>Description</th></tr></thead><tbody>' + list.map(function (f) {
        return '<tr><td>' + esc(f.name) + '</td><td>' + esc(f.phase) + '</td><td class="c">' + (f.used ? '<b class="warn-text">● yes</b>' : '○') + '</td><td style="white-space:normal;max-width:520px">' + esc(f.desc) + '</td></tr>';
      }).join('') + '</tbody></table>', { id: 'df-all' });
    return P.adminWrap('deprecated-features', h);
  };

  /* ---------------- Policies ---------------- */
  var APPLY = [['all', 'Exchanges and queues'], ['exchanges', 'Exchanges'], ['queues', 'Queues [All types]'], ['classic_queues', 'Queues [Classic]'], ['quorum_queues', 'Queues [Quorum]'], ['streams', 'Streams']];
  function applyLabel(a) { var x = APPLY.filter(function (p) { return p[0] === a; })[0]; return x ? x[1] : a; }
  function policyTable(list, operator) {
    if (!list.length) return '<p class="muted">... no policies ...</p>';
    return '<table class="list"><thead><tr><th>Virtual Host</th><th>Name</th><th>Pattern ' + UI.help('policy-pattern') + '</th><th>Apply to ' + UI.help('policy-apply-to') + '</th><th>Definition ' + UI.help('policy-definition') + '</th><th>Priority ' + UI.help('policy-priority') + '</th><th>Matches</th><th></th></tr></thead><tbody>' + list.filter(function (p) { return SIM.vhostOk(p.vhost); }).map(function (p) {
      var matches = SIM.S.queues.filter(function (q) { return (operator ? SIM.opPolicyFor('queue', q) : SIM.policyFor('queue', q)) === p; }).map(function (q) { return UI.qLink(q.vhost, q.name); })
        .concat(SIM.S.exchanges.filter(function (e) { return !operator && SIM.policyFor('exchange', e) === p; }).map(function (e) { return UI.exLink(e.vhost, e.name); }));
      return '<tr><td>' + esc(p.vhost) + '</td><td><b>' + esc(p.name) + '</b></td><td class="mono">' + esc(p.pattern) + '</td><td>' + esc(applyLabel(p.apply_to)) + '</td><td>' + UI.argsTable(p.definition) + '</td><td class="r">' + p.priority + '</td><td class="small" style="white-space:normal;max-width:260px">' + (matches.join(', ') || '<span class="muted">eşleşen yok</span>') + '</td>' +
        '<td><button class="small" data-action="delete-policy" data-vhost="' + esc(p.vhost) + '" data-name="' + esc(p.name) + '"' + (operator ? ' data-op="1"' : '') + '>Delete</button></td></tr>';
    }).join('') + '</tbody></table>';
  }
  function policyForm(operator) {
    var groups = operator ? [
      ['Queues', [['expires', '3600000', 'number', 'x-expires', 'Auto expire'], ['message-ttl', '60000', 'number', 'x-message-ttl', 'Message TTL'], ['max-length', '100000', 'number', 'x-max-length', 'Max length'], ['max-length-bytes', '1073741824', 'number', 'x-max-length-bytes', 'Max length bytes'], ['delivery-limit', '50', 'number', 'x-delivery-limit', 'Delivery limit'], ['target-group-size', '3', 'number', 'q-members', 'Target group size']]]
    ] : [
      ['Queues [All types]', [['max-length', '100000', 'number', 'x-max-length', 'Max length'], ['max-length-bytes', '1073741824', 'number', 'x-max-length-bytes', 'Max length bytes'], ['overflow', 'reject-publish', 'string', 'x-overflow', 'Overflow behaviour'], ['expires', '3600000', 'number', 'x-expires', 'Auto expire'], ['message-ttl', '60000', 'number', 'x-message-ttl', 'Message TTL'], ['dead-letter-exchange', '', 'string', 'x-dead-letter-exchange', 'Dead letter exchange'], ['dead-letter-routing-key', '', 'string', 'x-dead-letter-routing-key', 'Dead letter routing key'], ['queue-leader-locator', 'balanced', 'string', 'x-queue-leader-locator', 'Leader locator']]],
      ['Queues [Quorum]', [['delivery-limit', '20', 'number', 'x-delivery-limit', 'Delivery limit'], ['dead-letter-strategy', 'at-least-once', 'string', 'x-dead-letter-strategy', 'Dead letter strategy'], ['target-group-size', '3', 'number', 'q-members', 'Target group size']]],
      ['Streams', [['max-age', '7D', 'string', 'x-max-age', 'Max age'], ['stream-max-segment-size-bytes', '52428800', 'number', 'x-stream-max-segment-size-bytes', 'Max segment size in bytes'], ['stream-filter-size-bytes', '16', 'number', 'x-stream-filter-size-bytes', 'Filter size']]],
      ['Exchanges', [['alternate-exchange', '', 'string', 'alternate-exchange', 'Alternate exchange']]],
      ['Federation', [['federation-upstream-set', 'all', 'string', 'fed-upstream', 'Federation upstream set'], ['federation-upstream', '', 'string', 'fed-upstream', 'Federation upstream']]]
    ];
    return '<form data-form="set-policy"' + (operator ? ' data-op="1"' : '') + '><table class="form">' +
      UI.formRow('Virtual host', UI.vhostSelect('vhost'), 'vhost') +
      UI.formRow('Name', '<input type="text" name="name">', null, true) +
      UI.formRow('Pattern', '<input type="text" name="pattern" placeholder="^orders\\.">', 'policy-pattern', true) +
      UI.formRow('Apply to', UI.select('apply_to', operator ? [['queues', 'Queues [All types]'], ['classic_queues', 'Queues [Classic]'], ['quorum_queues', 'Queues [Quorum]'], ['streams', 'Streams']] : APPLY, 'queues'), 'policy-apply-to') +
      UI.formRow('Priority', '<input type="number" name="priority" value="0" style="width:80px">', 'policy-priority') +
      UI.formRow('Definition', UI.kvEditor(operator ? 'opdef' : 'pdef') + UI.argLinks(operator ? 'opdef' : 'pdef', groups), 'policy-definition', true) +
      '</table><button type="submit">Add / update ' + (operator ? 'operator ' : '') + 'policy</button></form>';
  }
  P.policies = function () {
    var h = '<h1>Policies ' + UI.help('policy') + '</h1>' +
      UI.section('User policies', policyTable(SIM.S.policies, false), { id: 'pol-user', help: 'policy' }) +
      UI.section('Add / update a policy', policyForm(false), { id: 'pol-add', closed: true }) +
      UI.section('Operator policies', policyTable(SIM.S.operator_policies, true), { id: 'pol-op', help: 'operator-policy' }) +
      UI.section('Add / update an operator policy', policyForm(true), { id: 'opol-add', closed: true }) +
      '<div class="edu-note"><b>Sürüm notu:</b> RabbitMQ 4.x\'te <code>ha-mode</code>, <code>ha-params</code>, <code>ha-sync-mode</code> (classic mirroring) ve <code>queue-mode: lazy</code> anahtarları artık geçerli değildir ' + UI.help('ha') + '</div>';
    return P.adminWrap('policies', h);
  };

  /* ---------------- Limits ---------------- */
  P.limits = function () {
    function tbl(list, kind) {
      if (!list.length) return '<p class="muted">... no limits ...</p>';
      return '<table class="list"><thead><tr><th>' + (kind === 'vhost' ? 'Virtual host' : 'User') + '</th><th>Limit</th><th class="r">Value</th><th></th></tr></thead><tbody>' + list.map(function (l) {
        var who = l[kind];
        return Object.keys(l.value).map(function (k) {
          return '<tr><td>' + (kind === 'vhost' ? UI.vhostLink(who) : UI.userLink(who)) + '</td><td>' + esc(k) + '</td><td class="r">' + U.fmtNum(l.value[k]) + '</td><td><button class="small" data-action="clear-limit" data-kind="' + kind + '" data-who="' + esc(who) + '" data-key="' + esc(k) + '">Clear</button></td></tr>';
        }).join('');
      }).join('') + '</tbody></table>';
    }
    var h = '<h1>Limits ' + UI.help('limits-vhost') + '</h1>' +
      UI.section('Virtual host limits', tbl(SIM.S.vhost_limits, 'vhost') + UI.h3('Set / update a virtual host limit', 'limits-vhost') + '<form data-form="set-limit" data-kind="vhost"><table class="form">' +
        UI.formRow('Virtual host', UI.vhostSelect('who')) + UI.formRow('Limit', UI.select('key', ['max-connections', 'max-queues'])) + UI.formRow('Value', '<input type="number" name="value" min="0" value="100">') +
        '</table><button type="submit">Set / update limit</button></form>', { id: 'lim-vh', help: 'limits-vhost' }) +
      UI.section('User limits', tbl(SIM.S.user_limits, 'user') + UI.h3('Set / update a user limit', 'limits-user') + '<form data-form="set-limit" data-kind="user"><table class="form">' +
        UI.formRow('User', UI.select('who', SIM.S.users.map(function (u) { return u.name; }))) + UI.formRow('Limit', UI.select('key', ['max-connections', 'max-channels'])) + UI.formRow('Value', '<input type="number" name="value" min="0" value="100">') +
        '</table><button type="submit">Set / update limit</button></form>', { id: 'lim-user', help: 'limits-user' });
    return P.adminWrap('limits', h);
  };

  /* ---------------- Cluster ---------------- */
  P.cluster = function () {
    var h = '<h1>Cluster ' + UI.help('cluster') + '</h1>' +
      UI.section('Cluster name', '<form data-form="cluster-name"><table class="form">' + UI.formRow('Cluster name', '<input type="text" name="name" value="' + esc(SIM.S.cluster_name) + '">', 'cluster-name') + '</table><button type="submit">Update</button></form>' +
        '<p class="muted small">Cluster adı istemcilere ve diğer cluster\'lara (federation, shovel) kendini tanıtmak için kullanılır.</p>', { id: 'cl-name', help: 'cluster-name' }) +
      UI.section('Cluster Status', UI.block(clusterStatus), { id: 'cl-status', help: 'cluster-status' }) +
      UI.section('Nodes', UI.block(nodeHealth), { id: 'cl-nodes', help: 'node-health' }) +
      UI.section('Network Partitions', UI.block(function () {
        return (SIM.S.partitions.length ? '<div class="form-msg err">Network partition detected!</div>' : '<div class="form-msg">Network partition tespit edilmedi. Tüm node\'lar birbirini görüyor.</div>') +
          UI.facts([['Partition handling', 'pause_minority', 'partitions'], ['Metadata store', SIM.S.feature_flags.some(function (f) { return f.name === 'khepri_db' && f.state === 'enabled'; }) ? 'Khepri (Raft)' : 'Mnesia', 'khepri']]);
      }), { id: 'cl-part', help: 'partitions' }) +
      UI.section('Arıza ve alarm simülasyonu (eğitim)', simControls(), { id: 'cl-sim', edu: true });
    return P.adminWrap('cluster', h);
  };
  function clusterStatus() {
    var S = SIM.S, running = S.nodes.filter(function (n) { return n.running; });
    var alarms = SIM.alarms();
    var minority = S.queues.filter(function (q) { return q.state === 'minority' || q.state === 'down'; });
    var overall = !alarms.length && running.length === S.nodes.length ? '<b class="status-green">Healthy</b>' : running.length > S.nodes.length / 2 ? '<b class="status-yellow">Degraded</b>' : '<b class="status-red">Critical</b>';
    return '<div class="grid-cards">' +
      '<div class="card"><div class="k">Overall ' + UI.help('cluster-status') + '</div><div class="v">' + overall + '</div></div>' +
      '<div class="card"><div class="k">Running nodes ' + UI.help('running-nodes') + '</div><div class="v">' + running.length + ' <small>/ ' + S.nodes.length + ' disc nodes</small></div></div>' +
      '<div class="card"><div class="k">Resource alarms ' + UI.help('memory-alarm') + '</div><div class="v ' + (alarms.length ? 'status-red' : '') + '">' + alarms.length + '</div>' + alarms.map(function (a) { return '<div class="small err-text">' + a.type + ' alarm @ ' + esc(a.node) + '</div>'; }).join('') + '</div>' +
      '<div class="card"><div class="k">Network partitions ' + UI.help('partitions') + '</div><div class="v">' + S.partitions.length + '</div></div>' +
      '<div class="card"><div class="k">Unavailable queues ' + UI.help('q-state') + '</div><div class="v ' + (minority.length ? 'status-red' : '') + '">' + minority.length + '</div>' + minority.slice(0, 4).map(function (q) { return '<div class="small">' + UI.qLink(q.vhost, q.name) + ' (' + q.state + ')</div>'; }).join('') + '</div>' +
      '<div class="card"><div class="k">Quorum queues ' + UI.help('queue-type-quorum') + '</div><div class="v">' + S.queues.filter(function (q) { return q.type === 'quorum'; }).length + ' <small>replicated ×3</small></div></div>' +
      '</div>' + UI.facts([['Cluster name', esc(S.cluster_name), 'cluster-name'], ['RabbitMQ version', S.version, 'version'], ['Erlang version', S.erlang, 'erlang'], ['Disc nodes', S.nodes.map(function (n) { return UI.nodeLink(n.name); }).join(', ')], ['Running nodes', running.map(function (n) { return UI.nodeLink(n.name); }).join(', '), 'running-nodes']]);
  }
  function nodeHealth() {
    return '<table class="list"><thead><tr><th>Node</th><th>State</th><th>Uptime</th><th>ping</th><th>check_local_alarms ' + UI.help('node-health') + '</th><th>check_port_connectivity</th><th>quorum critical ' + UI.help('maintenance-mode') + '</th><th>Memory alarm ' + UI.help('memory-alarm') + '</th><th>Disk alarm ' + UI.help('disk-alarm') + '</th><th>Leaders</th></tr></thead><tbody>' + SIM.S.nodes.map(function (n) {
      var ok = '<span class="status-green">✔ ok</span>', bad = '<span class="status-red">✘ fail</span>';
      var leaders = SIM.S.queues.filter(function (q) { return q.node === n.name && q.type !== 'classic'; }).length;
      var others = SIM.S.nodes.filter(function (x) { return x !== n && x.running; }).length;
      var critical = n.running && SIM.S.queues.some(function (q) { return q.type !== 'classic' && q.members.indexOf(n.name) >= 0 && q.online.length - 1 <= q.members.length / 2; });
      return '<tr><td>' + UI.nodeLink(n.name) + '</td><td>' + UI.state(n.running ? 'running' : 'stopped') + '</td><td>' + (n.running ? U.fmtUptime(SIM.uptime(n)) : '–') + '</td><td>' + (n.running ? ok : bad) + '</td><td>' + (n.running ? (n.alarm_mem || n.alarm_disk ? bad : ok) : '–') + '</td><td>' + (n.running ? ok : '–') + '</td><td>' + (n.running ? (critical ? '<span class="status-yellow">⚠ critical</span>' : ok) : '–') + '</td><td>' + (n.alarm_mem ? '<b class="status-red">ALARM</b>' : 'off') + '</td><td>' + (n.alarm_disk ? '<b class="status-red">ALARM</b>' : 'off') + '</td><td class="r">' + leaders + '</td></tr>';
    }).join('') + '</tbody></table>';
  }
  function simControls() {
    return '<p>Bu bölüm gerçek UI\'da bulunmaz; RabbitMQ\'nun arıza ve kaynak alarmlarına nasıl tepki verdiğini görmeniz için eklenmiştir. Değişiklikler Overview, Connections ve Queues sayfalarına yansır.</p>' +
      '<table class="list"><thead><tr><th>Node</th><th>Memory alarm</th><th>Disk alarm</th><th>Node durumu</th></tr></thead><tbody>' + SIM.S.nodes.map(function (n) {
        return '<tr><td>' + esc(n.name) + '</td><td><button class="small ' + (n.alarm_mem ? 'danger' : '') + '" data-action="sim-alarm" data-node="' + esc(n.name) + '" data-type="mem">' + (n.alarm_mem ? 'Alarmı kaldır' : 'Memory alarm tetikle') + '</button></td>' +
          '<td><button class="small ' + (n.alarm_disk ? 'danger' : '') + '" data-action="sim-alarm" data-node="' + esc(n.name) + '" data-type="disk">' + (n.alarm_disk ? 'Alarmı kaldır' : 'Disk alarm tetikle') + '</button></td>' +
          '<td><button class="small ' + (n.running ? '' : 'danger') + '" data-action="sim-node" data-node="' + esc(n.name) + '">' + (n.running ? 'Node\'u durdur' : 'Node\'u başlat') + '</button></td></tr>';
      }).join('') + '</tbody></table>' +
      '<div class="edu-note"><b>Gözlemleyin:</b> Memory/disk alarmı tetiklendiğinde publish oranları sıfıra düşer ve yayın yapan bağlantılar <b>blocked</b> olur (Connections). Bir node durdurulduğunda o node\'daki classic kuyruklar <b>down</b> olur, quorum kuyruklar ise kalan çoğunlukla çalışmaya devam eder. İki node durdurulursa quorum kuyruklar <b>minority</b> durumuna düşer.</div>';
  }
})(window);
