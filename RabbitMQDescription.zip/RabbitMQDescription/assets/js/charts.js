/* Basit SVG çizgi grafik üretici – RabbitMQ Management UI (flot) görünümünü taklit eder */
(function (w) {
  'use strict';

  var C = {};

  function niceMax(v) {
    if (v <= 0) return 1;
    var e = Math.pow(10, Math.floor(Math.log10(v)));
    var m = v / e;
    var n = m <= 1 ? 1 : m <= 2 ? 2 : m <= 4 ? 4 : m <= 5 ? 5 : 10;
    return n * e;
  }
  function yLabel(v, unit) {
    var s;
    if (unit === 'bytes') return U.fmtBytes(v);
    if (v >= 1e6) s = (v / 1e6).toFixed(v % 1e6 === 0 ? 0 : 1) + 'M';
    else if (v >= 1e3) s = (v / 1e3).toFixed(v % 1e3 === 0 ? 0 : 1) + 'k';
    else if (v >= 10) s = String(Math.round(v));
    else s = v.toFixed(1);
    return s + (unit === 'rate' ? ' /s' : '');
  }

  /**
   * opts: { width, height, times:[ms], series:[{color, data:[n], hidden}], unit: 'count'|'rate'|'bytes', stack:false, maxHint }
   */
  C.line = function (opts) {
    var W = opts.width || 360, Hh = opts.height || 75;
    var padL = opts.unit === 'bytes' ? 56 : 34, padR = 4, padT = 4, padB = 16;
    var tw = W + padL + padR, th = Hh + padT + padB;
    var times = opts.times || [];
    var n = times.length;
    var series = (opts.series || []).filter(function (s) { return !s.hidden; });
    var max = 0;
    series.forEach(function (s) { s.data.forEach(function (v) { if (v > max) max = v; }); });
    if (opts.maxHint && opts.maxHint > max) max = opts.maxHint;
    max = niceMax(max * 1.05);

    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + tw + '" height="' + th + '" viewBox="0 0 ' + tw + ' ' + th + '" role="img">');
    out.push('<rect x="' + padL + '" y="' + padT + '" width="' + W + '" height="' + Hh + '" fill="var(--chart-bg)" stroke="var(--chart-grid)" stroke-width="1"/>');

    // dikey ızgara + zaman etiketleri
    if (n > 1) {
      var t0 = times[0], t1 = times[n - 1], span = t1 - t0 || 1;
      var step = span <= 70000 ? 10000 : span <= 700000 ? 120000 : span <= 4000000 ? 600000 : 3600000;
      var first = Math.ceil(t0 / step) * step;
      for (var t = first; t <= t1; t += step) {
        var x = padL + (t - t0) / span * W;
        out.push('<line x1="' + x.toFixed(1) + '" y1="' + padT + '" x2="' + x.toFixed(1) + '" y2="' + (padT + Hh) + '" stroke="var(--chart-grid)" stroke-width="0.8" opacity="0.9"/>');
        out.push('<text class="axis" x="' + x.toFixed(1) + '" y="' + (th - 3) + '" text-anchor="middle">' + U.fmtTime(new Date(t)) + '</text>');
      }
    }
    // yatay ara çizgiler (y etiketleri)
    var ticks = Hh >= 70 ? 4 : 2;
    for (var i = 0; i <= ticks; i++) {
      var yv = max * i / ticks, y = padT + Hh - (yv / max) * Hh;
      out.push('<text class="axis" x="' + (padL - 3) + '" y="' + (y + 3).toFixed(1) + '" text-anchor="end">' + yLabel(yv, opts.unit) + '</text>');
    }
    // seriler
    series.forEach(function (s) {
      if (!s.data.length) return;
      var pts = [];
      var m = s.data.length;
      for (var j = 0; j < m; j++) {
        var xx = padL + (m === 1 ? W : (j / (m - 1)) * W);
        var yy = padT + Hh - Math.min(1, s.data[j] / max) * Hh;
        pts.push(xx.toFixed(1) + ',' + yy.toFixed(1));
      }
      if (opts.fill) {
        out.push('<polygon points="' + padL + ',' + (padT + Hh) + ' ' + pts.join(' ') + ' ' + (padL + W) + ',' + (padT + Hh) + '" fill="' + s.color + '" opacity="0.18"/>');
      }
      out.push('<polyline points="' + pts.join(' ') + '" fill="none" stroke="' + s.color + '" stroke-width="1.6" stroke-linejoin="round"/>');
    });
    out.push('</svg>');
    return out.join('');
  };

  /* Basit yatay bar grafik (top N) */
  C.hbars = function (items, opts) {
    opts = opts || {};
    var max = 0;
    items.forEach(function (it) { if (it.value > max) max = it.value; });
    max = max || 1;
    return '<table class="facts facts-l" style="min-width:420px">' + items.map(function (it) {
      var pct = Math.max(1, it.value / max * 100);
      return '<tr><th style="text-align:left;max-width:260px;overflow:hidden;text-overflow:ellipsis">' + it.label + '</th><td style="width:260px">' +
        '<div style="background:' + (it.color || 'var(--green)') + ';height:12px;width:' + pct.toFixed(1) + '%;display:inline-block;vertical-align:middle"></div>' +
        ' <span class="small">' + (opts.fmt ? opts.fmt(it.value) : U.fmtNum(it.value)) + '</span></td></tr>';
    }).join('') + '</table>';
  };

  C.COLORS = {
    ready: '#edc240', unacked: '#afd8f8', total: '#cb4b4b',
    publish: '#edc240', confirm: '#afd8f8', deliver_manual: '#cb4b4b', deliver_auto: '#4da74d',
    ack: '#9440ed', redeliver: '#666666', get_manual: '#8c8cff', get_auto: '#7d7dd8', get_empty: '#a46a6a',
    ret: '#5f7c8a', drop: '#e8e8a0',
    recv: '#edc240', send: '#afd8f8'
  };

  w.Charts = C;
})(window);
