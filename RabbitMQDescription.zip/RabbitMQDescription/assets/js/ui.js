/* Arayüz yardımcıları: yardım ikonları/paneli, bölümler, tablolar, grafikler, modal, toast */
(function (w) {
  'use strict';
  var esc = U.esc;
  var UI = { blocks: {}, tables: {}, chartState: U.store.get('rmq-edu-charts', {}), blockSeq: 0 };

  /* ---------------- Yardım (?) ---------------- */
  UI.help = function (key) {
    if (!key) return '';
    return '<span class="help" role="button" tabindex="0" data-help="' + esc(key) + '" title="Bu nedir? (açıklamayı aç)">?</span>';
  };
  var helpHistory = [];
  UI.openHelp = function (key, noPush) {
    var body = document.getElementById('help-body');
    var panel = document.getElementById('help-panel');
    var overlay = document.getElementById('help-overlay');
    if (!noPush) helpHistory.push(key);
    U.$$('.help.active').forEach(function (e) { e.classList.remove('active'); });
    U.$$('.help[data-help="' + key + '"]').forEach(function (e) { e.classList.add('active'); });
    body.innerHTML = key === '__index' ? UI.helpIndexHtml('') : UI.helpHtml(key);
    body.scrollTop = 0;
    panel.classList.add('open'); panel.setAttribute('aria-hidden', 'false');
    if (w.innerWidth < 900) overlay.classList.add('open');
    if (key === '__index') { var s = U.$('.hp-search', body); if (s) s.focus(); }
  };
  UI.closeHelp = function () {
    document.getElementById('help-panel').classList.remove('open');
    document.getElementById('help-overlay').classList.remove('open');
    U.$$('.help.active').forEach(function (e) { e.classList.remove('active'); });
    helpHistory = [];
  };
  UI.helpBack = function () {
    helpHistory.pop();
    var k = helpHistory[helpHistory.length - 1];
    if (k) UI.openHelp(k, true); else UI.openHelp('__index', true);
  };
  function list(v) {
    if (Array.isArray(v)) return '<ul>' + v.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>';
    return '<p>' + v + '</p>';
  }
  UI.helpHtml = function (key) {
    var h = HELP[key];
    var nav = '<div class="hp-nav">' + (helpHistory.length > 1 ? '<button type="button" class="dark" data-action="help-back">← Geri</button>' : '') +
      '<button type="button" class="dark" data-action="help-index">Tüm konular</button></div>';
    if (!h) return nav + '<h2>' + esc(key) + '</h2><p class="muted">Bu öğe için henüz açıklama eklenmemiş.</p>';
    var s = [nav, '<h2>' + h.t + '</h2>'];
    if (h.term || h.cat) s.push('<div class="hp-term">' + (h.term ? h.term : '') + (h.term && h.cat ? ' · ' : '') + (h.cat ? esc(h.cat) : '') + '</div>');
    function sec(title, v) { if (v) s.push('<div class="hp-sec"><h5>' + title + '</h5>' + list(v) + '</div>'); }
    sec('Nedir?', h.what);
    sec('RabbitMQ içindeki görevi', h.role);
    sec('Ne amaçla kullanılır?', h.use);
    sec('Ne zaman kullanılmalı?', h.when);
    sec('Sağladığı fayda', h.benefit);
    if (h.ex) s.push('<div class="hp-sec"><h5>Teknik örnek</h5><pre><code>' + esc(h.ex) + '</code></pre></div>');
    if (h.note) s.push('<div class="hp-note"><b>Not:</b> ' + h.note + '</div>');
    if (h.rel && h.rel.length) {
      s.push('<div class="hp-related"><div class="muted small" style="margin-bottom:6px">İlgili konular</div>' + h.rel.filter(function (r) { return HELP[r]; }).map(function (r) {
        return '<a data-help-link="' + esc(r) + '">' + HELP[r].t + '</a>';
      }).join('') + '</div>');
    }
    return s.join('');
  };
  UI.helpIndexHtml = function (q) {
    var cats = {};
    var ql = (q || '').toLowerCase();
    Object.keys(HELP).forEach(function (k) {
      var h = HELP[k];
      if (ql) {
        var hay = (h.t + ' ' + (h.term || '') + ' ' + (h.what || '') + ' ' + k).toLowerCase().replace(/<[^>]+>/g, '');
        if (hay.indexOf(ql) < 0) return;
      }
      (cats[h.cat || 'Diğer'] = cats[h.cat || 'Diğer'] || []).push(k);
    });
    var order = (w.HELP_CATS || []).concat(Object.keys(cats).filter(function (c) { return (w.HELP_CATS || []).indexOf(c) < 0; }));
    var html = '<h2>RabbitMQ Rehberi / Sözlük</h2><div class="hp-term">' + Object.keys(HELP).length + ' konu · arayüzde her <span class="help">?</span> ikonuna tıklayarak da açabilirsiniz</div>' +
      '<input type="text" class="hp-search" placeholder="Konu ara (ör. prefetch, quorum, DLX)…" value="' + esc(q || '') + '" data-help-search>' +
      '<div class="hp-index">';
    order.forEach(function (c) {
      if (!cats[c]) return;
      html += '<div class="cat">' + esc(c) + '</div>';
      cats[c].forEach(function (k) { html += '<a data-help-link="' + esc(k) + '">' + HELP[k].t + (HELP[k].term ? '<small>' + HELP[k].term.replace(/<[^>]+>/g, '') + '</small>' : '') + '</a>'; });
    });
    if (!Object.keys(cats).length) html += '<p class="muted">Sonuç bulunamadı.</p>';
    return html + '</div>';
  };

  /* ---------------- Yapı taşları ---------------- */
  UI.section = function (title, body, o) {
    o = o || {};
    var id = o.id || ('sec-' + title.replace(/[^a-z0-9]+/gi, '-').toLowerCase());
    var closedPref = U.store.get('rmq-edu-sec', {})[id];
    var closed = closedPref === undefined ? !!o.closed : closedPref;
    return '<div class="section' + (closed ? ' closed' : '') + (o.edu ? ' edu' : '') + '" data-sec="' + esc(id) + '">' +
      '<div class="sec-h" data-action="toggle-sec">' + title + (o.help ? ' ' + UI.help(o.help) : '') + '</div>' +
      '<div class="sec-b">' + body + '</div></div>';
  };
  UI.h3 = function (title, help, pill) { return '<h3>' + title + (pill ? ' <span class="pill" ' + (pill.attr || '') + '>' + pill.text + '</span>' : '') + (help ? ' ' + UI.help(help) : '') + '</h3>'; };
  UI.facts = function (rows, cls) {
    return '<table class="facts ' + (cls || '') + '">' + rows.filter(Boolean).map(function (r) {
      return '<tr><th>' + r[0] + (r[2] ? ' ' + UI.help(r[2]) : '') + '</th><td>' + (r[1] === undefined || r[1] === null || r[1] === '' ? '<span class="muted">–</span>' : r[1]) + '</td></tr>';
    }).join('') + '</table>';
  };
  UI.state = function (s) { return '<span class="state ' + esc(s) + '">' + esc(s) + '</span>'; };
  UI.bool = function (b) { return b ? '●' : '○'; };
  UI.vhostLink = function (v) { return '<a href="#/vhosts/' + U.enc(v) + '">' + esc(v) + '</a>'; };
  UI.qLink = function (v, n) { return '<a href="#/queues/' + U.enc(v) + '/' + U.enc(n) + '">' + esc(n) + '</a>'; };
  UI.exLink = function (v, n) { return '<a href="#/exchanges/' + U.enc(v) + '/' + U.enc(n === '' ? 'amq.default' : n) + '">' + (n === '' ? '(AMQP default)' : esc(n)) + '</a>'; };
  UI.connLink = function (n) { return '<a href="#/connections/' + U.enc(n) + '">' + esc(n) + '</a>'; };
  UI.chLink = function (n) { return '<a href="#/channels/' + U.enc(n) + '">' + esc(n) + '</a>'; };
  UI.nodeLink = function (n) { return '<a href="#/nodes/' + U.enc(n) + '">' + esc(n) + '</a>'; };
  UI.userLink = function (n) { return '<a href="#/users/' + U.enc(n) + '">' + esc(n) + '</a>'; };

  UI.json = function (o) { return '<span class="json">' + esc(JSON.stringify(o, null, 1).replace(/\n\s*/g, ' ')) + '</span>'; };
  UI.argsTable = function (args) {
    var ks = Object.keys(args || {});
    if (!ks.length) return '';
    return '<table class="facts">' + ks.map(function (k) {
      var hk = HELP[k] ? k : (HELP['x-' + k] ? 'x-' + k : null);
      return '<tr><th>' + esc(k) + (hk ? ' ' + UI.help(hk) : '') + ':</th><td>' + esc(typeof args[k] === 'object' ? JSON.stringify(args[k]) : args[k]) + '</td></tr>';
    }).join('') + '</table>';
  };

  /* ---------------- Canlı bloklar ---------------- */
  UI.block = function (fn, tag) {
    var id = 'lb' + (++UI.blockSeq);
    UI.blocks[id] = fn;
    return '<' + (tag || 'div') + ' data-live="' + id + '">' + fn() + '</' + (tag || 'div') + '>';
  };
  UI.refreshBlocks = function () {
    var ae = document.activeElement, fk = ae && ae.getAttribute && ae.getAttribute('data-focus'), sel = null;
    if (fk && ae.selectionStart !== undefined) { try { sel = [ae.selectionStart, ae.selectionEnd]; } catch (e) { sel = null; } }
    U.$$('[data-live]').forEach(function (el) {
      var fn = UI.blocks[el.getAttribute('data-live')];
      if (fn) el.innerHTML = fn();
    });
    if (fk) {
      var el = U.$('[data-focus="' + fk + '"]');
      if (el) { el.focus(); if (sel) { try { el.setSelectionRange(sel[0], sel[1]); } catch (e) { /* */ } } }
    }
  };
  UI.refreshBlockContaining = function (el) {
    var host = el.closest('[data-live]');
    if (!host) return;
    var fn = UI.blocks[host.getAttribute('data-live')];
    if (fn) host.innerHTML = fn();
  };
  UI.clearBlocks = function () { UI.blocks = {}; };   // tablo durumları (sıralama/filtre) sayfalar arası korunur

  /* ---------------- Grafikler ---------------- */
  var RANGES = [[60, 'last minute'], [600, 'last ten minutes'], [3600, 'last hour']];
  UI.rangeLabel = function (id) { var r = (UI.chartState[id] || {}).range || 60; return RANGES.filter(function (x) { return x[0] === r; })[0][1]; };
  /**
   * cfg: { id, title, help, unit, height, width, get: function() -> { times, series:[{key,label,color,data,value,help}] }, legendCols }
   */
  UI.chart = function (cfg) {
    var st = UI.chartState[cfg.id] = UI.chartState[cfg.id] || {};
    var head = UI.h3(cfg.title, cfg.help, { text: UI.rangeLabel(cfg.id), attr: 'data-action="chart-range" data-chart="' + esc(cfg.id) + '" title="Zaman aralığını değiştir"' });
    return head + UI.block(function () {
      var range = st.range || 60;
      var d = cfg.get(range);
      var hidden = st.hidden || {};
      var series = d.series.map(function (s) { return { color: s.color, data: s.data, hidden: !!hidden[s.key] }; });
      var svg = Charts.line({ width: cfg.width || 355, height: cfg.height || 75, times: d.times, series: series, unit: cfg.unit || 'count', fill: cfg.fill });
      var per = cfg.legendCols || 3, cols = [];
      for (var i = 0; i < d.series.length; i += per) cols.push(d.series.slice(i, i + per));
      var lg = '<div class="legend">' + cols.map(function (col) {
        return '<div class="lg-col">' + col.map(function (s) {
          return '<div class="lg-lbl' + (hidden[s.key] ? ' off' : '') + '" data-action="chart-toggle" data-chart="' + esc(cfg.id) + '" data-series="' + esc(s.key) + '" title="Seriyi gizle/göster">' + s.label + '</div>' +
            '<div class="lg-val"><span class="sw" style="background:' + s.color + '"></span>' + s.value + (s.help ? ' ' + UI.help(s.help) : '') + '</div>';
        }).join('') + '</div>';
      }).join('') + '</div>';
      return '<div class="chart-row"><div class="chart-box">' + svg + '</div>' + lg + '</div>';
    });
  };
  UI.saveChartState = function () { U.store.set('rmq-edu-charts', UI.chartState); };
  UI.RANGES = RANGES;

  /* ---------------- Liste tabloları ---------------- */
  /**
   * cfg: { id, rows: fn()->[], cols:[{key,label,group,help,render(row),sort(row),cls,hidden}], filterText(row), title?, empty }
   */
  UI.listTable = function (cfg) {
    var defaults = { page: 1, filter: '', regex: false, pageSize: 100, sort: cfg.defaultSort || null, dir: cfg.defaultDir || 'asc' };
    var saved = U.store.get('rmq-edu-tbl-' + cfg.id, {});
    var st = UI.tables[cfg.id] = UI.tables[cfg.id] || { s: Object.assign({}, defaults, { hidden: saved.hidden || null, pageSize: saved.pageSize || 100 }), cfg: cfg };
    st.cfg = cfg;
    return UI.block(function () { return renderTable(cfg.id); });
  };
  function visibleCols(st) {
    var hidden = st.s.hidden;
    return st.cfg.cols.filter(function (c) { return hidden ? hidden.indexOf(c.key) < 0 : !c.hidden; });
  }
  function renderTable(id) {
    var st = UI.tables[id], cfg = st.cfg, s = st.s;
    var rows = cfg.rows();
    var total = rows.length;
    var err = '';
    if (s.filter) {
      var test;
      if (s.regex) { try { var re = new RegExp(s.filter, 'i'); test = function (t) { return re.test(t); }; } catch (e) { err = 'Geçersiz regex'; test = function () { return true; }; } }
      else { var f = s.filter.toLowerCase(); test = function (t) { return t.toLowerCase().indexOf(f) >= 0; }; }
      rows = rows.filter(function (r) { return test(cfg.filterText ? cfg.filterText(r) : (r.name || '')); });
    }
    if (s.sort) {
      var col = cfg.cols.filter(function (c) { return c.key === s.sort; })[0];
      if (col) {
        var fn = col.sort || function (r) { return r[col.key]; };
        rows = rows.slice().sort(function (a, b) {
          var x = fn(a), y = fn(b);
          if (typeof x === 'string' || typeof y === 'string') { x = String(x).toLowerCase(); y = String(y).toLowerCase(); }
          return (x > y ? 1 : x < y ? -1 : 0) * (s.dir === 'asc' ? 1 : -1);
        });
      }
    }
    var pages = Math.max(1, Math.ceil(rows.length / s.pageSize));
    if (s.page > pages) s.page = pages;
    var pageRows = rows.slice((s.page - 1) * s.pageSize, s.page * s.pageSize);
    var cols = visibleCols(st);
    var h = [];
    if (cfg.paginate !== false) {
      h.push('<div class="pagination"><div class="pg-h">Pagination ' + UI.help('pagination') + '</div><div class="pg-row"><div class="pg-left">Page <select data-tbl="' + id + '" data-tblact="page">');
      for (var p = 1; p <= pages; p++) h.push('<option' + (p === s.page ? ' selected' : '') + '>' + p + '</option>');
      h.push('</select> of ' + pages + ' &nbsp;- Filter: <input type="text" name="filter" data-tbl="' + id + '" data-tblact="filter" data-focus="flt-' + id + '" value="' + esc(s.filter) + '" autocomplete="off">' +
        ' <label><input type="checkbox" data-tbl="' + id + '" data-tblact="regex"' + (s.regex ? ' checked' : '') + '> Regex</label> ' + UI.help('regex') +
        (err ? ' <span class="err-text">' + err + '</span>' : '') + '</div>' +
        '<div class="pg-right">Displaying ' + rows.length + ' item' + (rows.length === 1 ? '' : 's') + (rows.length !== total ? ' (filtered from ' + total + ')' : '') + ' , page size up to: <input type="number" name="pagesize" min="1" max="500" data-tbl="' + id + '" data-tblact="pagesize" data-focus="ps-' + id + '" value="' + s.pageSize + '"></div></div></div>');
    }
    // başlıklar
    var hasGroups = cols.some(function (c) { return c.group; });
    h.push('<div class="tbl-row"><div class="tbl-wrap"><table class="list"><thead>');
    if (hasGroups) {
      h.push('<tr>');
      var g = null, span = 0, out = [];
      cols.forEach(function (c, i) {
        var cg = c.group || '';
        if (i === 0) { g = cg; span = 1; } else if (cg === g) span++; else { out.push([g, span]); g = cg; span = 1; }
      });
      out.push([g, span]);
      out.forEach(function (x) { h.push('<th class="grp" colspan="' + x[1] + '">' + esc(x[0]) + '</th>'); });
      h.push('</tr>');
    }
    h.push('<tr>');
    cols.forEach(function (c) {
      var sorted = s.sort === c.key ? ' sorted-' + s.dir : '';
      h.push('<th class="' + (c.nosort ? '' : 'sortable') + sorted + (c.cls ? ' ' + c.cls : '') + '"' + (c.nosort ? '' : ' data-tbl="' + id + '" data-tblsort="' + esc(c.key) + '"') + '>' + c.label + (c.help ? ' ' + UI.help(c.help) : '') + '</th>');
    });
    h.push('</tr></thead><tbody>');
    if (!pageRows.length) h.push('<tr><td class="empty" colspan="' + cols.length + '">' + (cfg.empty || 'No items') + '</td></tr>');
    pageRows.forEach(function (r) {
      h.push('<tr>');
      cols.forEach(function (c) { h.push('<td' + (c.cls ? ' class="' + c.cls + '"' : '') + '>' + (c.render ? c.render(r) : esc(r[c.key])) + '</td>'); });
      h.push('</tr>');
    });
    h.push('</tbody></table></div>');
    if (cfg.colsel !== false) h.push('<div class="tbl-colsel"><button type="button" class="btn-mini" data-action="colsel" data-tbl="' + id + '" title="Sütunları seç">+/-</button> ' + UI.help('column-selector') + '</div>');
    h.push('</div>');
    return h.join('');
  }
  UI.tableEvent = function (el, type) {
    var id = el.getAttribute('data-tbl'), st = UI.tables[id];
    if (!st) return;
    var act = el.getAttribute('data-tblact'), sortKey = el.getAttribute('data-tblsort');
    if (sortKey) {
      if (st.s.sort === sortKey) st.s.dir = st.s.dir === 'asc' ? 'desc' : 'asc'; else { st.s.sort = sortKey; st.s.dir = 'asc'; }
    } else if (act === 'filter') { st.s.filter = el.value; st.s.page = 1; }
    else if (act === 'regex') { st.s.regex = el.checked; }
    else if (act === 'page') { st.s.page = parseInt(el.value, 10) || 1; }
    else if (act === 'pagesize') { var v = parseInt(el.value, 10); if (!v || v < 1) return; st.s.pageSize = Math.min(500, v); persistTbl(id); }
    else return;
    UI.refreshBlockContaining(el.closest('[data-live]') ? el : document.body);
    if (act === 'filter' || act === 'pagesize') {
      var f = U.$('[data-focus="' + (act === 'filter' ? 'flt-' : 'ps-') + id + '"]');
      if (f) { f.focus(); try { var l = f.value.length; f.setSelectionRange(l, l); } catch (e) { /* number input */ } }
    }
  };
  function persistTbl(id) { var st = UI.tables[id]; U.store.set('rmq-edu-tbl-' + id, { hidden: st.s.hidden, pageSize: st.s.pageSize }); }
  UI.columnSelector = function (id) {
    var st = UI.tables[id]; if (!st) return;
    var vis = visibleCols(st).map(function (c) { return c.key; });
    var groups = {};
    st.cfg.cols.forEach(function (c) { (groups[c.group || 'Columns'] = groups[c.group || 'Columns'] || []).push(c); });
    var body = '<div class="colsel-list">' + Object.keys(groups).map(function (g) {
      return '<div class="colsel-grp"><b>' + esc(g) + '</b>' + groups[g].map(function (c) {
        return '<label><input type="checkbox" value="' + esc(c.key) + '"' + (vis.indexOf(c.key) >= 0 ? ' checked' : '') + (c.fixed ? ' disabled' : '') + '> ' + c.label.replace(/<[^>]+>/g, '') + '</label>';
      }).join('') + '</div>';
    }).join('') + '</div>';
    UI.modal('Sütunları seç', body, function (root) {
      var checked = U.$$('input[type=checkbox]', root).filter(function (i) { return i.checked; }).map(function (i) { return i.value; });
      st.s.hidden = st.cfg.cols.map(function (c) { return c.key; }).filter(function (k) { return checked.indexOf(k) < 0; });
      persistTbl(id);
      UI.refreshBlocks();
    }, 'Uygula');
  };

  /* ---------------- Modal / Toast ---------------- */
  UI.modal = function (title, bodyHtml, onOk, okText, danger) {
    var root = document.getElementById('modal-root');
    root.innerHTML = '<div class="modal-bg" data-modal-bg><div class="modal" role="dialog" aria-modal="true"><h4>' + title + '</h4><div class="modal-body">' + bodyHtml + '</div>' +
      '<div class="actions"><button type="button" class="dark" data-modal="cancel">İptal</button>' + (onOk ? '<button type="button" class="' + (danger ? 'danger' : '') + '" data-modal="ok">' + (okText || 'Tamam') + '</button>' : '') + '</div></div></div>';
    var bg = U.$('[data-modal-bg]', root);
    function close() { root.innerHTML = ''; document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    bg.addEventListener('click', function (e) {
      var m = e.target.getAttribute('data-modal');
      if (e.target === bg || m === 'cancel') close();
      if (m === 'ok') { var keep = onOk && onOk(U.$('.modal', root)); if (keep !== false) close(); }
    });
    var ok = U.$('[data-modal="ok"]', root); if (ok) ok.focus();
  };
  UI.confirm = function (title, text, onOk, okText) { UI.modal(title, '<p>' + text + '</p>', function () { onOk(); }, okText || 'Evet', true); };
  UI.toast = function (msg, type, sub) {
    var root = document.getElementById('toast-root');
    var el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.innerHTML = msg + '<small>' + (sub || 'Simülasyon: gerçek bir broker\'a hiçbir istek gönderilmedi.') + '</small>';
    root.appendChild(el);
    setTimeout(function () { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(function () { el.remove(); }, 320); }, 4600);
  };
  UI.formMsg = function (form, html, type) {
    var box = U.$('.form-msg-host', form);
    if (!box) { box = document.createElement('div'); box.className = 'form-msg-host'; form.insertBefore(box, form.firstChild); }
    box.innerHTML = '<div class="form-msg ' + (type || '') + '">' + html + '</div>';
  };

  /* ---------------- Formlar ---------------- */
  UI.formRow = function (label, input, help, mandatory, hint) {
    return '<tr><th><label>' + label + (mandatory ? '<span class="mand">*</span>' : '') + ':</label>' + (help ? UI.help(help) : '') + '</th><td>' + input + (hint ? '<div class="hint">' + hint + '</div>' : '') + '</td></tr>';
  };
  UI.select = function (name, opts, sel, attrs) {
    return '<select name="' + name + '" ' + (attrs || '') + '>' + opts.map(function (o) {
      var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o;
      return '<option value="' + esc(v) + '"' + (String(v) === String(sel) ? ' selected' : '') + '>' + esc(l) + '</option>';
    }).join('') + '</select>';
  };
  UI.vhostSelect = function (name, sel) {
    return UI.select(name || 'vhost', SIM.S.vhosts.map(function (v) { return v.name; }), sel || (App.vhost || '/'));
  };
  /* Anahtar-değer (arguments/headers) editörü */
  UI.kvEditor = function (name, rows) {
    rows = rows && rows.length ? rows : [['', '', 'string']];
    return '<div class="kv-rows" data-kv="' + name + '">' + rows.map(kvRow).join('') + '</div>';
  };
  function kvRow(r) {
    return '<div class="kv"><input type="text" class="kv-k" placeholder="anahtar" value="' + esc(r[0]) + '"> = <input type="text" class="kv-v" placeholder="değer" value="' + esc(r[1]) + '"> ' +
      UI.select('kvt', [['string', 'String'], ['number', 'Number'], ['boolean', 'Boolean'], ['list', 'List']], r[2] || 'string', 'class="kv-t"') + '</div>';
  }
  UI.kvEnsureEmptyRow = function (container) {
    var rows = U.$$('.kv', container);
    var last = rows[rows.length - 1];
    if (last && (U.$('.kv-k', last).value || U.$('.kv-v', last).value)) {
      container.insertAdjacentHTML('beforeend', kvRow(['', '', 'string']));
    }
  };
  UI.kvRead = function (form, name) {
    var c = U.$('[data-kv="' + name + '"]', form), out = {};
    if (!c) return out;
    U.$$('.kv', c).forEach(function (r) {
      var k = U.$('.kv-k', r).value.trim(), v = U.$('.kv-v', r).value, t = U.$('.kv-t', r).value;
      if (k) out[k] = U.parseTyped(v, t);
    });
    return out;
  };
  UI.kvAdd = function (form, name, key, val, type) {
    var c = U.$('[data-kv="' + name + '"]', form);
    var rows = U.$$('.kv', c), target = null;
    rows.forEach(function (r) { if (!target && U.$('.kv-k', r).value === key) target = r; });
    if (!target) rows.forEach(function (r) { if (!target && !U.$('.kv-k', r).value) target = r; });
    if (!target) { c.insertAdjacentHTML('beforeend', kvRow(['', '', 'string'])); var all = U.$$('.kv', c); target = all[all.length - 1]; }
    U.$('.kv-k', target).value = key;
    U.$('.kv-v', target).value = val === undefined ? '' : val;
    U.$('.kv-t', target).value = type || 'string';
    UI.kvEnsureEmptyRow(c);
    U.$('.kv-v', target).focus();
  };
  UI.argLinks = function (form, groups) {
    // groups: [[label, [[argKey, default, type, helpKey], ...]]]
    return '<div class="args-quick">' + groups.map(function (g) {
      return '<div><span class="grp-label">' + g[0] + ':</span>' + g[1].map(function (a) {
        return '<a data-action="arg-add" data-kvname="' + form + '" data-key="' + esc(a[0]) + '" data-val="' + esc(a[1]) + '" data-type="' + (a[2] || 'string') + '">' + esc(a[4] || a[0]) + '</a>' + (a[3] ? UI.help(a[3]) : '') + ' | ';
      }).join('').replace(/ \| $/, '') + '</div>';
    }).join('') + '</div>';
  };

  w.UI = UI;
})(window);
