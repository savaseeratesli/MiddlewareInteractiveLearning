/* =========================================================================
   Yardım içerikleri – Bölüm 2: Exchanges, Queues, Bindings, Admin, Cluster,
   Federation, Shovel, Monitoring
   ========================================================================= */
(function (w) {
  'use strict';
  var H = w.HELP = w.HELP || {};
  function h(k, o) { H[k] = o; }

  /* ========================= EXCHANGES ========================= */
  h('ex-name', { t: 'Exchange Name', cat: 'Exchanges', what: 'Exchange\'in vhost içinde benzersiz adıdır. <code>amq.</code> ile başlayan adlar sistem için ayrılmıştır; istemciler bu önekle exchange oluşturamaz.', use: 'Alan.amaç biçiminde anlamlı adlar seçin: <code>orders.events</code>, <code>payments.commands</code>.' });
  h('ex-type', { t: 'Exchange Type', cat: 'Exchanges', what: 'Exchange\'in mesajları nasıl yönlendireceğini belirleyen algoritmadır. Oluşturulduktan sonra değiştirilemez.', role: '<b>direct</b>: routing key birebir eşleşme. <b>fanout</b>: bağlı tüm kuyruklara kopya. <b>topic</b>: joker karakterli desen eşleşmesi. <b>headers</b>: header değerlerine göre. <b>x-local-random</b> (4.0+): publisher\'ın bağlı olduğu node\'daki kuyruklardan rastgele birine. Eklentilerle <b>x-consistent-hash</b>, <b>x-delayed-message</b> gibi tipler eklenebilir.', rel: ['ex-type-direct', 'ex-type-fanout', 'ex-type-topic', 'ex-type-headers', 'ex-type-local-random'] });
  h('ex-type-direct', { t: 'Direct exchange', cat: 'Exchanges',
    what: 'Mesajı, routing key\'i binding key ile <b>birebir aynı</b> olan kuyruklara yönlendirir.',
    role: 'Birden fazla kuyruk aynı key ile bağlıysa her birine kopya gider. Tek kuyruk ve birden çok consumer ile iş dağıtımı (work queue) yapılır.',
    use: 'Komut tabanlı mesajlaşma: <code>process</code>, <code>refund</code> gibi belirli işleri belirli kuyruklara göndermek.',
    when: ['Hedefin önceden net olarak bilindiği komut/görev mesajlarında'],
    ex: `payments.commands (direct)
  ├─ "process" → payments.process
  └─ "refund"  → payments.refund
publish(routingKey: "refund") → yalnızca payments.refund`,
    rel: ['ex-default', 'binding-routing-key'] });
  h('ex-type-fanout', { t: 'Fanout exchange', cat: 'Exchanges',
    what: 'Routing key\'i <b>yok sayarak</b> mesajın bir kopyasını bağlı tüm kuyruklara (ve exchange\'lere) gönderir.',
    role: 'Yayın/abone (pub/sub) yayın modelidir; en hızlı yönlendirme tipidir.',
    use: 'Bir olayı ilgilenen tüm servislere duyurmak: önbellek temizleme, bildirim dağıtımı, log toplama.',
    ex: `notifications.broadcast (fanout)
  ├─ notifications.email
  ├─ notifications.sms
  └─ notifications.push      → her mesaj 3 kuyruğa kopyalanır`,
    rel: ['exchange'] });
  h('ex-type-topic', { t: 'Topic exchange', cat: 'Exchanges',
    what: 'Routing key\'i nokta ile ayrılmış kelimeler olarak ele alır ve binding desenleriyle eşleştirir. <code>*</code> tam olarak bir kelimeyle, <code>#</code> sıfır veya daha fazla kelimeyle eşleşir.',
    role: 'Hiyerarşik olay akışlarında esnek abonelik sağlar. <code>#</code> ile bağlanan kuyruk tüm mesajları alır (fanout gibi); joker içermeyen desen direct gibi davranır.',
    use: 'Olay tabanlı mimarilerde (event-driven) farklı servislerin farklı olay alt kümelerine abone olması.',
    ex: `routing key: order.paid.tr
  "order.paid.*"   ✔   "order.#"   ✔   "#"   ✔
  "order.*"        ✘   "*.paid.tr" ✔   "order.created.#" ✘`,
    rel: ['routing-key', 'topic-permissions'] });
  h('ex-type-headers', { t: 'Headers exchange', cat: 'Exchanges',
    what: 'Routing key yerine mesajın <b>headers</b> özelliğindeki anahtar-değer çiftlerine göre yönlendirme yapar.',
    role: 'Binding arguments içinde <code>x-match</code> belirtilir: <b>all</b> (tüm header\'lar eşleşmeli, varsayılan), <b>any</b> (en az biri eşleşmeli), <b>all-with-x</b> / <b>any-with-x</b> (x- ile başlayan header\'lar da dahil edilir).',
    use: 'Birden çok niteliğe göre içerik tabanlı yönlendirme (ör. tier=gold ve region=tr).',
    when: ['Routing key ile ifade edilemeyen çok boyutlu kurallarda. Basit senaryolarda topic exchange daha performanslıdır.'],
    ex: `binding: { "x-match": "all", "tier": "gold", "region": "tr" }
headers { tier: "gold", region: "tr" }  → ✔
headers { tier: "gold" }                → ✘ (all)`,
    rel: ['x-match', 'binding-args'] });
  h('ex-type-local-random', { t: 'Local random exchange', term: 'x-local-random (4.0+)', cat: 'Exchanges',
    what: 'RabbitMQ 4.0 ile gelen bu tip, mesajı publisher\'ın bağlı olduğu <b>node üzerindeki</b> bağlı kuyruklardan rastgele seçilen <b>bir</b> tanesine yönlendirir.',
    role: 'Node\'lar arası ağ atlamasını (hop) önleyerek en düşük gecikmeyi sağlar. Routing key dikkate alınmaz.',
    use: 'Request/reply (RPC) servislerinde, her node\'da çalışan worker\'ların kendi yerel kuyruklarından istek alması.',
    note: 'Genellikle exclusive veya node-local classic kuyruklarla birlikte kullanılır. <code>rabbit_exchange_type_local_random</code> feature flag gerektirir.' });
  h('ex-default', { t: 'Default exchange (AMQP default)', cat: 'Exchanges',
    what: 'Adı boş string ("") olan, önceden tanımlı direct exchange\'dir. Her kuyruk otomatik olarak <b>kendi adıyla</b> bu exchange\'e bağlıdır.',
    role: 'Bu sayede <code>publish(exchange: "", routingKey: "kuyruk_adı")</code> ile doğrudan kuyruğa mesaj gönderilebilir. Bu exchange silinemez ve ona açıkça binding eklenemez.',
    use: 'Basit point-to-point senaryolar ve RPC yanıtları (reply_to kuyruğu) için.',
    ex: `channel.basicPublish("", "orders.created", props, body);`,
    rel: ['exchange', 'binding'] });
  h('ex-amq', { t: 'amq.* exchanges', cat: 'Exchanges', what: 'Her vhost\'ta otomatik oluşturulan standart exchange\'lerdir: <b>amq.direct</b>, <b>amq.fanout</b>, <b>amq.topic</b>, <b>amq.headers</b>, <b>amq.match</b> (headers) ve <b>amq.rabbitmq.trace</b> (firehose tracer için internal topic).', role: 'MQTT ve STOMP eklentileri varsayılan olarak <b>amq.topic</b> kullanır.', note: 'Bu exchange\'ler silinemez.' });
  h('ex-trace', { t: 'amq.rabbitmq.trace', term: 'Firehose tracer', cat: 'Exchanges', what: 'Tracing açık olan vhost\'larda broker\'a giren (publish.#) ve çıkan (deliver.#) her mesajın kopyasının yayınlandığı internal topic exchange\'dir.', use: 'Hata ayıklama için geçici olarak açılır; yüksek trafik altında performansı ciddi düşürür.', ex: `rabbitmqctl trace_on -p analytics
rabbitmqctl trace_off -p analytics`, rel: ['vhost-tracing'] });
  h('ex-durable', { t: 'Durable (D)', cat: 'Exchanges', what: 'Durable exchange broker yeniden başlatıldığında silinmez. Transient (non-durable) exchange ise yeniden başlatmada kaybolur.', use: 'Üretim topolojisindeki tüm exchange\'ler durable olmalıdır.', rel: ['q-durable'] });
  h('ex-auto-delete', { t: 'Auto delete (AD)', cat: 'Exchanges', what: 'Auto-delete exchange, kendisine bağlı <b>son binding</b> kaldırıldığında otomatik silinir (en az bir kez binding almış olmalıdır).', when: ['Geçici, dinamik topolojilerde'], rel: ['q-auto-delete'] });
  h('ex-internal', { t: 'Internal (I)', cat: 'Exchanges', what: 'Internal exchange\'e istemciler doğrudan mesaj yayınlayamaz; yalnızca başka bir exchange\'den exchange-to-exchange binding ile mesaj alabilir.', use: 'Katmanlı yönlendirme topolojilerinde ara exchange\'leri dış kullanıma kapatmak için.', rel: ['e2e-binding'] });
  h('ex-args', { t: 'Arguments (exchange)', cat: 'Exchanges', what: 'Exchange\'e özel isteğe bağlı ayarlardır. En yaygın olanı <code>alternate-exchange</code>\'dir. Eklenti tiplerinde ek argümanlar bulunur (ör. x-delayed-type).', rel: ['alternate-exchange'] });
  h('alternate-exchange', { t: 'Alternate exchange', term: 'AE', cat: 'Exchanges',
    what: 'Bir exchange\'in hiçbir binding ile eşleşmeyen (unroutable) mesajlarını göndereceği yedek exchange\'dir.',
    role: 'Mesaj kaybını önler: yönlendirilemeyen mesaj sessizce düşürülmek yerine AE\'ye (genellikle fanout) ve oradan bir "unrouted" kuyruğa gider.',
    use: 'Yanlış routing key veya eksik binding hatalarını yakalamak ve incelemek için.',
    ex: `// argument ile
args["alternate-exchange"] = "orders.unrouted";
// veya policy ile (önerilen)
rabbitmqctl set_policy AE "^orders\\.events$" '{"alternate-exchange":"orders.unrouted"}' --apply-to exchanges`,
    rel: ['rate-unroutable-drop'] });
  h('ex-rate-in', { t: 'Message rate in', cat: 'Exchanges', what: 'Exchange\'e saniyede yayınlanan mesaj sayısıdır.', rel: ['rate-publish'] });
  h('ex-rate-out', { t: 'Message rate out', cat: 'Exchanges', what: 'Exchange\'in saniyede hedeflere (kuyruklar/exchange\'ler) yönlendirdiği mesaj sayısıdır. Fanout\'ta bir mesaj birden çok hedefe gittiği için "out" değeri "in"den büyük olabilir; unroutable mesajlar varsa küçük olabilir.' });
  h('publish-message', { t: 'Publish message', cat: 'Exchanges',
    what: 'Management UI üzerinden exchange\'e (veya kuyruk sayfasından default exchange aracılığıyla kuyruğa) test mesajı yayınlar.',
    role: 'UI arka planda HTTP API\'nin <code>POST /api/exchanges/{vhost}/{name}/publish</code> uç noktasını kullanır. Yanıt olarak mesajın yönlendirilip yönlendirilmediği (routed: true/false) döner.',
    use: 'Binding\'leri ve routing key desenlerini test etmek için idealdir. Bu simülasyonda mesaj gerçekten simüle edilen kuyruklara yönlendirilir; hangi kuyruklara gittiğini görebilirsiniz.',
    when: ['Üretimde dikkatli kullanın; uygulama tüketicileri test mesajını gerçek iş olarak işleyebilir'],
    rel: ['delivery-mode', 'msg-headers', 'msg-properties'] });
  h('delivery-mode', { t: 'Delivery mode', cat: 'Exchanges',
    what: 'Mesajın kalıcılığını belirten özelliktir: <b>1 = Non-persistent</b>, <b>2 = Persistent</b>.',
    role: 'Classic kuyruklarda persistent mesajlar diske yazılır ve yeniden başlatmada korunur (kuyruk da durable olmalı). Quorum queue ve stream\'ler her mesajı zaten replike eder ve diske yazar.',
    use: 'Kaybı kabul edilemeyen mesajları persistent gönderin.' });
  h('msg-headers', { t: 'Headers', cat: 'Exchanges', what: 'Mesaja eklenen özel anahtar-değer çiftleridir. Headers exchange yönlendirmesinde ve uygulama meta verilerinde (tenant, trace-id, retry sayısı) kullanılır.', note: 'RabbitMQ dead-lettering sırasında <code>x-death</code>, federation <code>x-received-from</code>, shovel <code>x-shovelled</code> header\'larını ekler.' });
  h('msg-properties', { t: 'Properties', cat: 'Exchanges', what: 'AMQP standart mesaj özellikleridir: <code>content_type</code>, <code>content_encoding</code>, <code>priority</code>, <code>correlation_id</code>, <code>reply_to</code>, <code>expiration</code> (ms, mesaj bazlı TTL), <code>message_id</code>, <code>timestamp</code>, <code>type</code>, <code>user_id</code>, <code>app_id</code>.', note: '<code>user_id</code> verilirse broker bunun bağlantı kullanıcısıyla aynı olduğunu doğrular (impersonator tag hariç).' });
  h('payload', { t: 'Payload', cat: 'Exchanges', what: 'Mesajın gövdesidir (body). Broker için yalnızca bir bayt dizisidir; JSON, Protobuf, Avro, düz metin olabilir.', when: ['Büyük dosyaları mesaj içinde göndermek yerine nesne depolamaya koyup referansını gönderin (claim-check deseni). Önerilen üst sınır birkaç MB\'tır; varsayılan max_message_size 16 MiB\'tır.'] });

  /* ========================= QUEUES ========================= */
  h('q-name', { t: 'Queue Name', cat: 'Queues', what: 'Kuyruğun vhost içindeki benzersiz adıdır (en fazla 255 bayt). Boş ad ile tanımlanan kuyruklara broker <code>amq.gen-...</code> biçiminde rastgele bir ad verir (server-named queue).', note: '<code>amq.</code> öneki sistem için ayrılmıştır.' });
  h('q-type', { t: 'Type', term: 'Queue type', cat: 'Queues', what: 'Kuyruğun tipini gösterir: <b>classic</b>, <b>quorum</b> veya <b>stream</b>. Tip yalnızca oluşturulurken <code>x-queue-type</code> argümanıyla (veya vhost\'un default queue type\'ı ile) belirlenir ve sonradan değiştirilemez.', rel: ['queue-type-classic', 'queue-type-quorum', 'queue-type-stream', 'vhost-default-qt'] });
  h('queue-type-classic', { t: 'Classic Queue', cat: 'Queues',
    what: 'RabbitMQ\'nun geleneksel, <b>replike edilmeyen</b>, tek node üzerinde yaşayan kuyruk tipidir.',
    role: '4.0 itibarıyla yalnızca <b>v2</b> depolama motoru (CQv2) kullanılır. Mesajlar ihtiyaç halinde diske yazılır (eski "lazy" mod 3.12\'den beri gereksizdir). Öncelik (x-max-priority), exclusive ve auto-delete gibi tüm özellikleri destekler.',
    use: 'Geçici, kaybı tolere edilebilir veya yüksek hız gerektiren iş yükleri; exclusive/reply-to kuyrukları; öncelikli kuyruklar.',
    when: ['Veri güvenliği kritik değilse veya kuyruk geçiciyse', 'Node kaybında kuyruğun geçici olarak erişilemez olması kabul edilebiliyorsa'],
    benefit: 'Düşük kaynak kullanımı ve düşük gecikme.',
    note: '<b>Classic mirrored queues 4.0\'da kaldırıldı.</b> Replikasyon gerekiyorsa quorum queue kullanın.',
    rel: ['queue-type-quorum', 'x-max-priority'] });
  h('queue-type-quorum', { t: 'Quorum Queue', cat: 'Queues',
    what: '<b>Raft</b> uzlaşı algoritması ile birden çok node\'a replike edilen, dayanıklı (durable) ve veri güvenliğine odaklanan modern kuyruk tipidir.',
    role: 'Bir <b>leader</b> ve birden çok <b>follower</b> üyesi vardır. Bir mesaj, üyelerin çoğunluğu (ör. 3\'te 2) diske yazdığında confirm edilir. Leader çökerse kalan çoğunluk yeni leader seçer. Varsayılan üye sayısı 3\'tür (<code>x-quorum-initial-group-size</code>).',
    use: 'Sipariş, ödeme gibi kaybı kabul edilemeyen iş kuyrukları. RabbitMQ\'nun replike kuyruklar için önerdiği varsayılan tiptir.',
    when: ['Veri güvenliği ve yüksek erişilebilirlik gerektiğinde', 'Poison message koruması gerektiğinde (delivery-limit)'],
    benefit: 'Node kaybında veri kaybı yok; zehirli mesaj koruması; at-least-once dead-lettering; 4.0+ ile iki seviyeli mesaj önceliği (normal / high).',
    ex: `args["x-queue-type"] = "quorum";
args["x-delivery-limit"] = 10;      // 4.0+ varsayılan 20
args["x-quorum-initial-group-size"] = 3;`,
    note: 'Quorum queue\'lar her zaman durable\'dır; exclusive veya non-durable olamaz. 4.0 ile varsayılan <b>delivery-limit = 20</b> olarak belirlendi (öncesinde sınırsızdı).',
    rel: ['ha', 'q-members', 'x-delivery-limit', 'x-dead-letter-strategy'] });
  h('queue-type-stream', { t: 'Stream', cat: 'Queues',
    what: 'Mesajları silmeden saklayan, <b>append-only log</b> yapısında, replike edilen veri yapısıdır. Tüketim yıkıcı (destructive) değildir; birden çok consumer aynı mesajı istediği konumdan (offset) tekrar tekrar okuyabilir.',
    role: 'Mesajlar segment dosyalarına yazılır ve saklama politikasına göre (<code>x-max-age</code>, <code>x-max-length-bytes</code>) eski segmentler silinir. Native <b>Stream protokolü</b> (port 5552) ile çok yüksek throughput sağlanır; AMQP 0-9-1/1.0 ile de tüketilebilir.',
    use: 'Olay kaydı (event log), denetim (audit), replay, fan-out\'un çok sayıda consumer ile yapılması, çok büyük birikimler.',
    when: ['Aynı mesajı birden çok bağımsız uygulamanın okuması gerektiğinde', 'Geçmiş mesajları yeniden oynatma (replay) gerektiğinde', 'Milyonlarca mesajlık birikimlerde'],
    benefit: 'Çok yüksek verim, düşük bellek kullanımı (mesajlar diskte), zaman tabanlı geri sarma. Super Streams ile partition\'lama ve Single Active Consumer desteği.',
    ex: `args["x-queue-type"] = "stream";
args["x-max-age"] = "7D";
// AMQP ile tüketim: prefetch zorunlu + offset
channel.basicQos(500);
channel.basicConsume("orders.audit", false,
    Map.of("x-stream-offset", "first"), consumer);`,
    note: 'Stream\'lerde ack, mesajı silmez; yalnızca kredi (flow control) için kullanılır. UI\'daki "Get messages" stream\'ler için kullanılamaz.',
    rel: ['x-max-age', 'x-stream-offset', 'x-stream-max-segment-size-bytes', 'x-stream-filter-size-bytes'] });
  h('q-state', { t: 'State (kuyruk)', cat: 'Queues', what: 'Kuyruğun çalışma durumudur.', role: '<b>running</b>: normal. <b>idle</b>: bir süredir aktivite yok (classic). <b>flow</b>: kuyruk süreci flow control altında. <b>minority</b>: quorum queue çoğunluk üyeye ulaşamıyor – yazma yapılamaz. <b>down</b>: kuyruğun bulunduğu node erişilemez. <b>stopped / crashed</b>: kuyruk süreci durmuş/çökmüş.', rel: ['q-members'] });
  h('q-features', { t: 'Features', cat: 'Queues', what: 'Kuyruğun özelliklerini kısaltmalarla gösterir: <b>D</b> durable, <b>AD</b> auto-delete, <b>Excl</b> exclusive, <b>Args</b> ek argümanlar var, mor kutu: uygulanan <b>policy</b>, kırmızı kutu: <b>operator policy</b>. Üzerine gelerek detayı görebilirsiniz.', rel: ['q-durable', 'q-auto-delete', 'q-exclusive', 'policy'] });
  h('q-durable', { t: 'Durable', cat: 'Queues',
    what: 'Durable kuyruğun tanımı (metadata) broker yeniden başlatıldığında korunur. Transient kuyruk ise yeniden başlatmada silinir.',
    role: 'Kuyruğun durable olması mesajların da kalıcı olduğu anlamına gelmez: classic kuyruklarda mesajların da <b>persistent</b> (delivery_mode=2) gönderilmesi gerekir. Quorum queue ve stream\'ler her zaman durable\'dır.',
    note: '4.x\'te <b>non-durable ve non-exclusive</b> (transient) kuyruklar deprecated\'dır (<code>transient_nonexcl_queues</code>). Geçici kuyruk gerekiyorsa exclusive kuyruk kullanın.',
    rel: ['delivery-mode', 'deprecated-banner'] });
  h('q-auto-delete', { t: 'Auto delete', cat: 'Queues', what: 'Auto-delete kuyruk, en az bir consumer\'a sahip olduktan sonra <b>son consumer</b> aboneliği iptal ettiğinde otomatik silinir.', role: 'Hiç consumer almamış bir auto-delete kuyruk silinmez; bunun için <code>x-expires</code> kullanın.', rel: ['x-expires', 'q-exclusive'] });
  h('q-exclusive', { t: 'Exclusive', cat: 'Queues', what: 'Exclusive kuyruk yalnızca onu oluşturan bağlantı tarafından kullanılabilir ve o bağlantı kapandığında silinir.', role: 'Diğer bağlantılar bu kuyruğa erişemez (RESOURCE_LOCKED hatası alır). Yalnızca classic kuyruklar exclusive olabilir.', use: 'RPC yanıt kuyrukları, geçici pub/sub abonelikleri (her consumer kendi geçici kuyruğunu açar).', ex: `var q = await ch.QueueDeclareAsync("", durable: false, exclusive: true, autoDelete: true);
// q.QueueName → "amq.gen-Vq3eYb8kZp0..."` });
  h('q-args', { t: 'Arguments (x-arguments)', cat: 'Queues', what: 'Kuyruk oluşturulurken verilen isteğe bağlı ayarlardır (TTL, uzunluk sınırı, DLX, tip vb.).', role: 'Argümanlar kuyruk tanımının parçasıdır; sonradan değiştirmek için kuyruğu silip yeniden oluşturmak gerekir. Bu yüzden mümkün olan ayarların <b>policy</b> ile verilmesi önerilir. Aynı kuyruk farklı argümanlarla yeniden declare edilirse <code>PRECONDITION_FAILED</code> hatası alınır.', rel: ['policy', 'x-message-ttl', 'x-max-length', 'x-dead-letter-exchange'] });
  h('q-ready', { t: 'Messages: Ready', cat: 'Queues', what: 'Bu kuyrukta teslim edilmeyi bekleyen mesaj sayısı.', rel: ['ready'] });
  h('q-unacked', { t: 'Messages: Unacked', cat: 'Queues', what: 'Bu kuyruktan teslim edilmiş ancak ack\'lenmemiş mesaj sayısı.', rel: ['unacked'] });
  h('q-total', { t: 'Messages: Total', cat: 'Queues', what: 'Ready + Unacked. Stream\'lerde saklanan toplam mesaj sayısını (offset aralığını) gösterir.', rel: ['total'] });
  h('q-rate-in', { t: 'incoming', cat: 'Queues', what: 'Kuyruğa saniyede eklenen (exchange\'den yönlendirilen) mesaj sayısı.' });
  h('q-rate-deliver', { t: 'deliver / get', cat: 'Queues', what: 'Kuyruktan saniyede consumer\'lara teslim edilen (deliver) ve basic.get ile çekilen mesaj toplamı.' });
  h('q-rate-ack', { t: 'ack', cat: 'Queues', what: 'Kuyruk için saniyede alınan consumer ack sayısı.' });
  h('q-consumers', { t: 'Consumers', cat: 'Queues', what: 'Kuyruğa abone olan consumer sayısı.', when: ['Mesaj biriken ama consumer\'ı 0 olan kuyruklar alarm kuralı olarak izlenmelidir'], rel: ['consumer'] });
  h('consumer-capacity', { t: 'Consumer capacity', term: 'eski adı: consumer utilisation', cat: 'Queues', what: 'Kuyruğun, consumer\'lara mesajı anında teslim edebildiği zamanın oranıdır (%0–100).', role: '%100\'e yakınsa consumer\'lar mesajları hemen alabiliyor demektir. Düşükse consumer\'lar prefetch limiti, ağ veya yavaş işlem nedeniyle yetişemiyor.', when: ['Düşük değerde prefetch\'i artırmayı veya consumer eklemeyi düşünün'] });
  h('q-memory', { t: 'Memory (kuyruk)', cat: 'Queues', what: 'Kuyruk sürecinin (ve quorum\'da Raft durumunun) kullandığı bellek miktarıdır.', role: 'Classic ve quorum kuyruklar mesajları gerektiğinde diske taşır; stream\'ler mesajları her zaman diskte tutar, bellek kullanımı düşüktür.' });
  h('q-members', { t: 'Leader / Members / Online', cat: 'Queues',
    what: 'Replike kuyruklarda (quorum, stream) kuyruğun hangi node\'larda kopyasının bulunduğunu gösterir. <b>Leader</b>: yazma ve teslimin yapıldığı ana üye. <b>Members</b>: tüm replikalar. <b>Online</b>: şu anda erişilebilir replikalar.',
    role: 'Online üye sayısı çoğunluğun altına düşerse quorum queue <b>minority</b> durumuna geçer ve yeni mesaj kabul etmez.',
    use: 'Leader\'ların node\'lar arasında dengeli dağıldığından emin olun; aksi halde bir node aşırı yüklenir.',
    ex: `rabbitmq-queues rebalance quorum
rabbitmq-queues add_member -p orders orders.created rabbit@mq-node-04
rabbitmq-queues grow rabbit@mq-node-04 all`,
    rel: ['queue-type-quorum', 'ha'] });
  h('q-node', { t: 'Node (classic)', cat: 'Queues', what: 'Classic kuyruğun yaşadığı tek node\'dur. Bu node kapanırsa kuyruk (durable ise) node geri gelene kadar erişilemez (state: down).', note: 'Kuyruğun hangi node\'da oluşturulacağını <code>x-queue-leader-locator</code> belirler.', rel: ['x-queue-leader-locator'] });

  /* ---------- Queue arguments ---------- */
  h('x-message-ttl', { t: 'Message TTL', term: 'x-message-ttl', cat: 'Queue arguments',
    what: 'Kuyruktaki mesajların milisaniye cinsinden maksimum yaşam süresidir. Süresi dolan mesajlar silinir veya DLX tanımlıysa dead-letter edilir (reason: <code>expired</code>).',
    use: 'Belirli bir süre sonra anlamını yitiren mesajlar (fiyat güncellemesi, OTP) ve gecikmeli yeniden deneme (retry) desenleri.',
    ex: `args["x-message-ttl"] = 30000;   // 30 sn
// Policy anahtarı: "message-ttl"
// Mesaj bazlı TTL: properties.expiration = "60000"`,
    note: 'Mesaj bazlı TTL\'de classic kuyruklar süresi dolan mesajları yalnızca kuyruk başına geldiklerinde temizler.',
    rel: ['dlx', 'x-expires'] });
  h('x-expires', { t: 'Auto expire', term: 'x-expires', cat: 'Queue arguments', what: 'Kuyruğun kendisinin, kullanılmadığı (consumer yok, get yok, yeniden declare yok) süre sonunda (ms) otomatik silinmesini sağlar.', use: 'Terk edilmiş geçici kuyrukların birikmesini önlemek için (ör. MQTT abonelik kuyrukları).', ex: 'args["x-expires"] = 86400000;   // 1 gün', rel: ['q-auto-delete'] });
  h('x-max-length', { t: 'Max length', term: 'x-max-length', cat: 'Queue arguments', what: 'Kuyrukta tutulabilecek maksimum <b>ready</b> mesaj sayısıdır. Aşıldığında <code>x-overflow</code> davranışı uygulanır.', use: 'Bellek ve disk kullanımını sınırlamak, tüketici çöktüğünde sınırsız birikmeyi önlemek için.', ex: 'args["x-max-length"] = 100000;   // policy: "max-length"', rel: ['x-overflow', 'x-max-length-bytes'] });
  h('x-max-length-bytes', { t: 'Max length bytes', term: 'x-max-length-bytes', cat: 'Queue arguments', what: 'Kuyruktaki ready mesajların toplam gövde boyutu (bayt) için üst sınırdır. Stream\'lerde ise toplam saklama boyutunu belirler ve eski segmentler silinir.', ex: 'args["x-max-length-bytes"] = 1073741824;   // 1 GiB', rel: ['x-max-length'] });
  h('x-overflow', { t: 'Overflow behaviour', term: 'x-overflow', cat: 'Queue arguments',
    what: 'Kuyruk uzunluk sınırına ulaştığında ne yapılacağını belirler.',
    role: '<b>drop-head</b> (varsayılan): en eski mesaj silinir/dead-letter edilir. <b>reject-publish</b>: yeni mesajlar reddedilir (confirm modunda publisher nack alır). <b>reject-publish-dlx</b>: yeni mesaj reddedilir ve dead-letter edilir (yalnızca classic).',
    when: ['Veri kaybı istenmiyorsa ve publisher geri basınç (back-pressure) almalıysa <b>reject-publish</b>', 'En güncel veri önemliyse (ör. sensör) <b>drop-head</b>'],
    note: 'Quorum queue\'larda <code>dead-letter-strategy: at-least-once</code> kullanmak için overflow <b>reject-publish</b> olmalıdır.',
    rel: ['x-max-length', 'x-dead-letter-strategy'] });
  h('dlx', { t: 'Dead Lettering', term: 'DLX / DLQ kavramı', cat: 'Queue arguments',
    what: 'İşlenemeyen veya süresi dolan mesajların silinmek yerine bir <b>dead letter exchange</b>\'e (DLX) ve oradan genellikle bir <b>dead letter queue</b>\'ya (DLQ) yönlendirilmesidir.',
    role: 'Bir mesaj şu durumlarda dead-letter edilir: <code>rejected</code> (nack/reject, requeue=false), <code>expired</code> (TTL), <code>maxlen</code> (uzunluk aşımı), <code>delivery_limit</code> (quorum queue delivery-limit aşımı). Broker mesaja <code>x-death</code> header\'ı ekler (sebep, kuyruk, sayaç).',
    use: 'Hatalı mesajları izole etmek, incelemek ve gerektiğinde yeniden işlemek (shovel ile replay) için.',
    ex: `orders.created ──(reject / delivery-limit)──▶ orders.dlx ──"orders.created"──▶ orders.dlq
x-death: [{ reason: "delivery_limit", queue: "orders.created", count: 1 }]`,
    rel: ['x-dead-letter-exchange', 'x-dead-letter-routing-key', 'x-dead-letter-strategy', 'x-delivery-limit'] });
  h('x-dead-letter-exchange', { t: 'Dead letter exchange', term: 'x-dead-letter-exchange', cat: 'Queue arguments', what: 'Bu kuyruktan dead-letter edilen mesajların gönderileceği exchange\'in adıdır.', ex: 'args["x-dead-letter-exchange"] = "orders.dlx";   // policy: "dead-letter-exchange"', rel: ['dlx'] });
  h('x-dead-letter-routing-key', { t: 'Dead letter routing key', term: 'x-dead-letter-routing-key', cat: 'Queue arguments', what: 'Dead-letter edilen mesajın DLX\'e gönderilirken kullanacağı routing key\'dir. Belirtilmezse mesajın orijinal routing key\'i korunur.', rel: ['dlx'] });
  h('x-dead-letter-strategy', { t: 'Dead letter strategy', term: 'x-dead-letter-strategy (quorum)', cat: 'Queue arguments',
    what: 'Quorum queue\'larda dead-lettering\'in güvenilirlik seviyesidir.',
    role: '<b>at-most-once</b> (varsayılan): mesaj DLX\'e gönderilir ama hedefte onaylanması beklenmez – kaybolabilir. <b>at-least-once</b>: mesaj, hedef kuyruk tarafından onaylanana kadar kaynak kuyrukta tutulur.',
    when: ['DLQ\'daki mesajlar iş açısından kritikse at-least-once kullanın'],
    note: 'at-least-once için <code>overflow: reject-publish</code> zorunludur; aksi halde at-most-once\'a düşer.',
    rel: ['dlx', 'x-overflow'] });
  h('x-delivery-limit', { t: 'Delivery limit', term: 'x-delivery-limit (quorum)', cat: 'Queue arguments',
    what: 'Bir mesajın en fazla kaç kez teslim edilebileceğidir. Limit aşılırsa mesaj silinir veya DLX tanımlıysa dead-letter edilir (reason: <code>delivery_limit</code>).',
    role: '<b>Poison message</b> (zehirli mesaj) koruması sağlar: consumer\'ı sürekli çökerten bir mesajın sonsuz döngüye girmesini engeller. Teslim sayısı mesaj header\'ında <code>x-delivery-count</code> olarak görülür.',
    note: 'RabbitMQ <b>4.0 ile varsayılan delivery-limit 20</b> olarak ayarlandı. Sınırsız teslim için -1 verilebilir (önerilmez).',
    ex: 'args["x-delivery-limit"] = 10;   // policy: "delivery-limit"',
    rel: ['rate-redelivered', 'dlx'] });
  h('x-single-active-consumer', { t: 'Single active consumer', term: 'x-single-active-consumer (SAC)', cat: 'Queue arguments',
    what: 'Kuyrukta birden çok consumer olsa bile aynı anda yalnızca <b>bir</b> tanesinin mesaj almasını sağlar. Diğerleri <i>waiting</i> durumunda bekler.',
    role: 'Aktif consumer bağlantıyı kaybederse bekleyenlerden biri otomatik olarak aktif olur (failover).',
    use: 'Mesaj <b>sırasının</b> kesinlikle korunması gereken senaryolar (ör. hesap hareketleri) ve yüksek erişilebilir tekil işlemciler.',
    ex: 'args["x-single-active-consumer"] = true;',
    note: 'Yalnızca kuyruk oluşturulurken argüman olarak verilebilir; policy ile ayarlanamaz.',
    rel: ['activity-status'] });
  h('sac', { t: 'Single Active Consumer', cat: 'Queues', what: 'Bkz. x-single-active-consumer. Bu kuyrukta aynı anda yalnızca bir consumer aktiftir; diğerleri yedekte bekler.', rel: ['x-single-active-consumer'] });
  h('x-max-priority', { t: 'Maximum priority', term: 'x-max-priority (classic)', cat: 'Queue arguments',
    what: 'Classic kuyruğu öncelikli kuyruk yapar ve desteklenen en yüksek öncelik seviyesini belirler (1–255; 1–10 arası önerilir).',
    role: 'Mesajın <code>priority</code> property\'si yüksek olanlar önce teslim edilir. Her öncelik seviyesi ek bellek/CPU maliyeti getirir.',
    note: 'Quorum queue\'lar 4.0\'dan itibaren x-max-priority olmadan iki seviyeli öncelik destekler: priority 0–4 normal, 5 ve üzeri yüksek.',
    ex: 'args["x-max-priority"] = 10;\nprops.Priority = 8;' });
  h('x-queue-leader-locator', { t: 'Leader locator', term: 'x-queue-leader-locator', cat: 'Queue arguments', what: 'Yeni kuyruğun leader\'ının (classic için tek node\'unun) hangi node\'a yerleştirileceğini belirler.', role: '<b>client-local</b> (varsayılan): kuyruğu declare eden istemcinin bağlı olduğu node. <b>balanced</b>: en az kuyruk leader\'ına sahip node (çok kuyrukta rastgele seçim).', note: 'Eski <code>x-queue-master-locator</code> argümanı deprecated\'dır (<code>queue_master_locator</code>).', ex: 'queue_leader_locator = balanced   # rabbitmq.conf' });
  h('x-quorum-initial-group-size', { t: 'Initial cluster size', term: 'x-quorum-initial-group-size', cat: 'Queue arguments', what: 'Quorum queue oluşturulurken kaç replika ile başlatılacağını belirler (varsayılan 3, cluster node sayısını aşamaz). Stream\'ler için karşılığı <code>x-initial-cluster-size</code>\'dır.', when: ['5 node\'lu cluster\'da daha yüksek dayanıklılık için 5 verilebilir'], rel: ['q-members'] });
  h('x-max-age', { t: 'Max age (stream)', term: 'x-max-age', cat: 'Queue arguments', what: 'Stream\'deki mesajların saklanacağı maksimum süredir. Birimler: Y, M, D, h, m, s (ör. <code>7D</code>, <code>12h</code>).', role: 'Saklama segment bazında uygulanır: bir segmentteki <b>tüm</b> mesajlar süreyi aştığında segment silinir.', ex: 'args["x-max-age"] = "7D";   // policy: "max-age"', rel: ['queue-type-stream', 'x-stream-max-segment-size-bytes'] });
  h('x-stream-max-segment-size-bytes', { t: 'Max segment size', term: 'x-stream-max-segment-size-bytes', cat: 'Queue arguments', what: 'Stream segment dosyalarının maksimum boyutudur (varsayılan 500 MB). Saklama (retention) segment bazında yapıldığı için daha küçük segmentler daha hassas silme sağlar.', ex: 'args["x-stream-max-segment-size-bytes"] = 52428800;   // 50 MB' });
  h('x-stream-filter-size-bytes', { t: 'Stream filter size', term: 'x-stream-filter-size-bytes', cat: 'Queue arguments', what: 'Stream filtreleme (3.13+) için her chunk\'ta tutulan Bloom filter boyutudur (16–255 bayt, varsayılan 16).', role: 'Publisher mesaja bir filter değeri (ör. bölge) ekler; consumer yalnızca ilgili değerleri içeren chunk\'ları alır, ağ trafiği azalır.', ex: `// publisher: x-stream-filter-value = "tr"
// consumer : x-stream-filter = ["tr"], x-stream-match-unfiltered = false` });
  h('x-stream-offset', { t: 'Stream offset', term: 'x-stream-offset (consumer argümanı)', cat: 'Queue arguments', what: 'Stream consumer\'ının okumaya nereden başlayacağını belirler.', role: '<b>first</b>: en eski mesajdan. <b>last</b>: son chunk\'tan. <b>next</b>: yalnızca yeni mesajlar (varsayılan). <b>sayı</b>: belirli offset. <b>timestamp</b>: belirli zamandan. <b>interval</b> (ör. "1h"): son 1 saatten.', use: 'Replay, yeni bir servisi geçmiş verilerle başlatma.', rel: ['queue-type-stream'] });

  /* ---------- Queue operations ---------- */
  h('get-messages', { t: 'Get messages', cat: 'Queues',
    what: 'Kuyruktan belirtilen sayıda mesajı UI üzerinden çekip içeriğini gösterir (arka planda basic.get benzeri işlem).',
    role: '<b>Ack mode</b> seçimine göre mesajlar kuyruğa geri konur veya silinir.',
    use: 'Mesaj içeriğini incelemek, DLQ\'daki hatalı mesajları analiz etmek için.',
    when: ['Üretimde dikkatli olun: "Automatic ack" veya "Reject requeue false" seçenekleri mesajı kalıcı olarak kuyruktan çıkarır'],
    note: 'Gerçek UI\'da bu işlem bir "üretim aracı" değil, hata ayıklama aracıdır. Stream\'lerde kullanılamaz.',
    rel: ['ack-mode', 'rate-get-manual'] });
  h('ack-mode', { t: 'Ack Mode', cat: 'Queues',
    what: 'Get messages işleminde çekilen mesajlara ne olacağını belirler.',
    role: '<b>Nack message requeue true</b>: mesaj kuyruğa geri konur (redelivered=true olur) – güvenli inceleme. <b>Automatic ack</b>: mesaj kuyruktan silinir. <b>Reject requeue true</b>: geri konur. <b>Reject requeue false</b>: mesaj silinir veya DLX varsa dead-letter edilir.',
    when: ['Sadece bakmak istiyorsanız her zaman "Nack message requeue true" kullanın'] });
  h('get-encoding', { t: 'Encoding', cat: 'Queues', what: '<b>Auto string / base64</b>: payload geçerli UTF-8 ise metin, değilse base64 gösterilir. <b>base64</b>: her zaman base64.' });
  h('purge', { t: 'Purge Messages', cat: 'Queues',
    what: 'Kuyruktaki tüm <b>ready</b> mesajları kalıcı olarak siler. Unacked mesajlar etkilenmez.',
    role: 'Kuyruk tanımı, binding\'ler ve consumer\'lar korunur; yalnızca içerik temizlenir. Silinen mesajlar dead-letter <b>edilmez</b>.',
    when: ['Test ortamlarında veya geri dönüşü olmayan bozuk mesaj yığınlarında. Üretimde geri alınamaz!'],
    ex: `rabbitmqctl purge_queue -p orders orders.cancelled
# HTTP API: DELETE /api/queues/orders/orders.cancelled/contents` });
  h('delete-queue', { t: 'Delete Queue', cat: 'Queues',
    what: 'Kuyruğu, içindeki mesajlar ve binding\'leriyle birlikte siler. Bağlı consumer\'lar <code>basic.cancel</code> bildirimi alır.',
    role: 'İsteğe bağlı koşullar: <b>if-unused</b> (consumer yoksa sil), <b>if-empty</b> (mesaj yoksa sil).',
    when: ['Artık kullanılmayan kuyrukları temizlerken. Uygulama kuyruğu yeniden declare ediyorsa kuyruk tekrar oluşur.'],
    ex: 'rabbitmqctl delete_queue -p orders orders.retry --if-empty' });
  h('move-messages', { t: 'Move messages', cat: 'Queues', what: 'Shovel eklentisi kullanarak bu kuyruktaki mesajları başka bir kuyruğa taşır. Arka planda geçici bir dinamik shovel oluşturulur (<code>src-delete-after: queue-length</code>).', use: 'DLQ\'daki mesajları hata düzeltildikten sonra ana kuyruğa geri taşımak için.', note: 'rabbitmq_shovel_management eklentisi etkin olmalıdır.', rel: ['shovel'] });
  h('consumer-tag', { t: 'Consumer tag', cat: 'Queues', what: 'Bir kanal içinde consumer\'ı tanımlayan benzersiz etikettir. İstemci belirtmezse broker <code>amq.ctag-...</code> biçiminde üretir.', use: 'basic.cancel ile aboneliği iptal ederken ve logları ilişkilendirirken kullanılır.' });
  h('ack-required', { t: 'Ack required', cat: 'Queues', what: 'Consumer\'ın manuel ack kullanıp kullanmadığını gösterir. <b>●</b> manuel ack (güvenilir), <b>○</b> autoAck (mesaj gönderildiği anda silinir).', when: ['İş açısından önemli mesajlarda her zaman manuel ack kullanın; ack\'i işlem tamamlandıktan sonra gönderin'], rel: ['unacked'] });
  h('activity-status', { t: 'Activity status', cat: 'Queues', what: 'Consumer\'ın teslimat durumudur. <b>up</b>: normal aktif. <b>single_active</b>: SAC kuyruğundaki aktif consumer. <b>waiting</b>: SAC\'de yedekte bekleyen. <b>suspected_down</b>: quorum queue, consumer\'ın node\'una ulaşamıyor.', rel: ['x-single-active-consumer'] });
  h('consumer-priority', { t: 'Consumer priority', term: 'x-priority (consumer argümanı)', cat: 'Queues', what: 'Aynı kuyruktaki consumer\'lar arasında yüksek önceliklilerin mesajları önce almasını sağlar. Düşük öncelikliler yalnızca yüksek öncelikliler meşgulken (prefetch dolu) mesaj alır.', ex: 'channel.basicConsume(q, false, Map.of("x-priority", 5), consumer);' });

  /* ========================= BINDINGS ========================= */
  h('binding-routing-key', { t: 'Routing key (binding)', term: 'Binding key', cat: 'Bindings', what: 'Binding oluşturulurken verilen eşleşme anahtarı veya desenidir. Direct\'te birebir, topic\'te * ve # joker karakterleriyle eşleşir; fanout ve headers\'ta yok sayılır.', rel: ['routing-key', 'ex-type-topic'] });
  h('binding-args', { t: 'Arguments (binding)', cat: 'Bindings', what: 'Binding\'e özel argümanlardır. Headers exchange\'de eşleşme kriterleri (<code>x-match</code> + header değerleri) burada tanımlanır. Bazı eklentiler (consistent-hash) ağırlık gibi değerleri routing key alanında kullanır.', rel: ['x-match'] });
  h('x-match', { t: 'x-match', cat: 'Bindings', what: 'Headers exchange binding\'lerinde eşleşme kuralı: <b>all</b> (tüm değerler eşleşmeli), <b>any</b> (en az biri), <b>all-with-x</b> / <b>any-with-x</b> (x- önekli header\'ları da karşılaştırır).', rel: ['ex-type-headers'] });
  h('e2e-binding', { t: 'Exchange-to-exchange binding', cat: 'Bindings', what: 'Bir exchange\'i başka bir exchange\'e bağlamaktır (RabbitMQ\'nun AMQP 0-9-1 uzantısı). Kaynak exchange\'e gelen ve binding ile eşleşen mesajlar hedef exchange\'e iletilir ve orada yeniden yönlendirilir.', use: 'Katmanlı topolojiler: genel bir olay exchange\'inden alan bazlı exchange\'lere dağıtım.', ex: 'channel.exchangeBind("notifications.internal", "notifications.broadcast", "");', rel: ['ex-internal'] });
  h('bindings-section', { t: 'Bindings', cat: 'Bindings', what: 'Bu exchange\'in hedeflerini (This exchange → kuyruklar/exchange\'ler) veya bu kuyruğun kaynaklarını (exchange\'ler → This queue) listeler. Buradan yeni binding eklenebilir veya mevcutlar kaldırılabilir (Unbind).', rel: ['binding'] });

  /* ========================= ADMIN ========================= */
  h('tab-admin', { t: 'Admin', cat: 'Admin', what: 'Kullanıcılar, virtual host\'lar, feature flag\'ler, deprecated özellikler, policy\'ler, limitler, cluster ayarları ve eklenti sayfalarının (Federation, Shovel) bulunduğu yönetim bölümüdür. Yalnızca <b>administrator</b> (ve kısmen policymaker) tag\'li kullanıcılar görebilir.' });
  h('user-tags', { t: 'Tags', term: 'Kullanıcı tag\'leri', cat: 'Admin',
    what: 'Kullanıcının Management UI ve HTTP API\'de neler yapabileceğini belirleyen rollerdir. AMQP kaynak erişimini değil, yönetim erişimini kontrol eder.',
    role: '<b>(yok)</b>: UI\'ya giremez, yalnızca mesajlaşma. <b>management</b>: erişebildiği vhost\'lardaki nesneleri görür/yönetir. <b>policymaker</b>: management + erişebildiği vhost\'larda policy ve parametre yönetimi. <b>monitoring</b>: management + tüm vhost\'lardaki bağlantı/kanal ve node istatistiklerini görür. <b>administrator</b>: her şey (kullanıcı, vhost, izin yönetimi dahil). <b>impersonator</b>: mesajlarda başka bir user_id kullanabilir.',
    when: ['Uygulama kullanıcılarına tag vermeyin', 'İzleme araçlarına (Prometheus exporter, Zabbix) monitoring tag\'i verin'],
    ex: 'rabbitmqctl set_user_tags monitoring monitoring' });
  h('permissions', { t: 'Permissions', term: 'Configure / Write / Read', cat: 'Admin',
    what: 'Bir kullanıcının belirli bir vhost içindeki kaynaklara (exchange, queue) erişimini regex desenleriyle tanımlar.',
    role: '<b>Configure</b>: kaynak oluşturma/silme (declare, delete). <b>Write</b>: exchange\'e publish etme; queue\'ya binding eklerken hedef kuyruğa yazma. <b>Read</b>: kuyruktan consume/get, purge; binding eklerken kaynak exchange\'den okuma. Boş string <code>""</code> hiçbir izin vermez, <code>.*</code> tümüne izin verir.',
    use: 'En az yetki ilkesiyle uygulamaları sadece kendi kaynaklarına erişebilir hale getirmek için.',
    ex: `# order-service yalnızca "orders." ile başlayan kaynaklara erişebilir
rabbitmqctl set_permissions -p orders order-service "^orders\\..*" "^orders\\..*" "^orders\\..*"
# Server-named exclusive kuyruklar için amq.gen.* izni de gerekebilir`,
    note: 'İzin desenleri tam eşleşme olarak değerlendirilir (^ ve $ önerilir). Default exchange için izin adı "amq.default"tur.',
    rel: ['topic-permissions', 'user'] });
  h('topic-permissions', { t: 'Topic permissions', cat: 'Admin',
    what: 'Topic exchange\'lerde, kullanıcının hangi <b>routing key</b>\'lerle yayın yapabileceğini (write) ve hangi desenlerle binding/abone olabileceğini (read) regex ile kısıtlar.',
    role: 'Normal permission\'ların üzerine ek bir katmandır. <code>{username}</code>, <code>{vhost}</code> ve MQTT için <code>{client_id}</code> değişkenleri kullanılabilir.',
    use: 'MQTT/IoT senaryolarında her cihazın yalnızca kendi topic\'ine yazmasını sağlamak için.',
    ex: `rabbitmqctl set_topic_permissions -p / iot-gateway amq.topic \\
  "^devices\\.{client_id}\\..*" "^devices\\.{client_id}\\..*"` });
  h('vhost-default-qt', { t: 'Default queue type', cat: 'Admin', what: 'Bu vhost\'ta <code>x-queue-type</code> belirtilmeden oluşturulan kuyrukların alacağı tiptir (classic, quorum, stream).', role: 'Uygulama kodunu değiştirmeden tüm yeni kuyrukların quorum olmasını sağlamak için kullanılır.', note: '3.13/4.x ile eklenmiştir. Mevcut kuyrukları değiştirmez.', ex: 'rabbitmqctl update_vhost_metadata orders --default-queue-type quorum' });
  h('vhost-tags', { t: 'Vhost description / tags', cat: 'Admin', what: 'Virtual host\'a eklenen açıklama ve etiketlerdir (metadata). Davranışı etkilemez; organizasyon ve otomasyon araçları için kullanılır.' });
  h('vhost-tracing', { t: 'Tracing', cat: 'Admin', what: 'Vhost için firehose tracer\'ın açık olup olmadığını gösterir. Açıksa tüm mesajların kopyaları amq.rabbitmq.trace exchange\'ine yayınlanır.', note: 'Performansı ciddi düşürür; yalnızca kısa süreli hata ayıklamada kullanın. rabbitmq_tracing eklentisi ile dosyaya kaydedilebilir.', rel: ['ex-trace'] });
  h('vhost-cluster-state', { t: 'Cluster state (vhost)', cat: 'Admin', what: 'Vhost\'un her node\'da çalışıp çalışmadığını gösterir. Bir node\'da vhost süreci durursa (ör. disk hatası) "stopped" görünür.', ex: 'rabbitmqctl restart_vhost -p orders' });
  h('policy-pattern', { t: 'Pattern', cat: 'Policies', what: 'Policy\'nin hangi kuyruk/exchange adlarına uygulanacağını belirleyen düzenli ifadedir (regex).', ex: `^orders\\.         → orders. ile başlayanlar
^orders\\.(paid|created)$  → yalnızca iki kuyruk
.*                 → hepsi`, note: 'Desen tam ad eşleşmesi gerektirmez; kesin eşleşme için ^ ve $ kullanın.' });
  h('policy-apply-to', { t: 'Apply to', cat: 'Policies', what: 'Policy\'nin hangi nesne tiplerine uygulanacağı: <b>Exchanges and queues</b> (all), <b>Exchanges</b>, <b>Queues</b> (tüm tipler), <b>Classic Queues</b>, <b>Quorum Queues</b>, <b>Streams</b>.', note: 'Kuyruk tipine özel seçenekler 3.12+ ile gelmiştir; tipe özel anahtarların yanlış kuyruklara uygulanmasını önler.' });
  h('policy-priority', { t: 'Priority', cat: 'Policies', what: 'Bir nesneyle birden çok policy eşleşirse hangisinin uygulanacağını belirler: <b>en yüksek priority</b> kazanır. Policy\'ler birleştirilmez; yalnızca biri geçerli olur.', when: ['Genel bir policy (priority 0) ve daha spesifik bir istisna (priority 10) tanımlayabilirsiniz; istisna, genel policy\'nin tüm anahtarlarını içermelidir'] });
  h('policy-definition', { t: 'Definition', cat: 'Policies', what: 'Policy\'nin uyguladığı anahtar-değer ayarlarıdır (JSON).', role: 'Kuyruklar: max-length, max-length-bytes, overflow, message-ttl, expires, dead-letter-exchange, dead-letter-routing-key, dead-letter-strategy, delivery-limit, queue-leader-locator, max-age, stream-max-segment-size-bytes, initial-cluster-size... Exchanges: alternate-exchange. Federation: federation-upstream, federation-upstream-set.', note: 'ha-mode, ha-params, ha-sync-mode, queue-mode=lazy gibi anahtarlar 4.x\'te geçersizdir.' });
  h('operator-policy', { t: 'Operator policies', cat: 'Policies',
    what: 'Operatörlerin (platform ekibinin) kullanıcı policy\'lerinin üzerine zorunlu güvenlik sınırları koymasını sağlayan özel policy türüdür.',
    role: 'Normal policy\'den farklı olarak <b>birleştirilir</b>: aynı anahtar hem kullanıcı policy\'sinde hem operator policy\'sinde varsa, sayısal değerlerde <b>daha küçük (daha kısıtlayıcı)</b> olan uygulanır. Yalnızca sınırlı anahtarlar desteklenir: expires, message-ttl, max-length, max-length-bytes, delivery-limit, max-in-memory-length/bytes (eski), target-group-size.',
    use: 'Çok kiracılı ortamlarda kiracıların sınırsız kuyruk büyütmesini engellemek için.',
    ex: `rabbitmqctl set_operator_policy -p notifications op-safety-net ".*" \\
  '{"max-length-bytes":2147483648,"delivery-limit":50}' --apply-to queues` });
  h('effective-policy', { t: 'Effective policy definition', cat: 'Policies', what: 'Kuyruğa fiilen uygulanan, kullanıcı policy\'si ve operator policy\'sinin birleşiminden oluşan nihai ayarlardır.' });
  h('limits-vhost', { t: 'Virtual host limits', cat: 'Admin', what: 'Bir vhost için kaynak üst sınırlarıdır: <b>max-connections</b> (toplam bağlantı) ve <b>max-queues</b> (toplam kuyruk). Limit aşıldığında yeni bağlantı/kuyruk reddedilir.', use: 'Çok kiracılı ortamlarda bir kiracının cluster\'ı tüketmesini önlemek için.', ex: `rabbitmqctl set_vhost_limits -p analytics '{"max-connections":200,"max-queues":50}'` });
  h('limits-user', { t: 'User limits', cat: 'Admin', what: 'Bir kullanıcı için cluster genelinde <b>max-connections</b> ve <b>max-channels</b> (bağlantı başına değil, toplam) sınırlarıdır.', ex: `rabbitmqctl set_user_limits iot-gateway '{"max-connections":5000,"max-channels":1}'` });
  h('feature-flags', { t: 'Feature Flags', cat: 'Admin',
    what: 'Cluster\'daki tüm node\'ların belirli bir yeni özelliği desteklediğini ve kullanmaya hazır olduğunu işaretleyen bayraklardır.',
    role: 'Karışık sürümlü cluster\'larda (rolling upgrade sırasında) yeni özelliklerin, tüm node\'lar yükseltilmeden etkinleşmesini engeller. Bir flag etkinleştirildikten sonra <b>devre dışı bırakılamaz</b>.',
    use: 'Yükseltme sonrası tüm stable flag\'leri etkinleştirin; bir sonraki büyük sürüme geçmeden önce bu zorunludur (o sürümde "required" olacaklardır).',
    ex: `rabbitmqctl list_feature_flags
rabbitmqctl enable_feature_flag all`,
    rel: ['ff-stability', 'khepri'] });
  h('ff-stability', { t: 'Stability', cat: 'Admin', what: '<b>Required</b>: zorunlu; her zaman etkin, kapatılamaz (önceki sürümlerden gelen olgun özellikler). <b>Stable</b>: kararlı, etkinleştirilmesi önerilir. <b>Experimental</b>: deneysel; üretimde kullanılmamalı.', rel: ['feature-flags'] });
  h('khepri', { t: 'khepri_db', term: 'Khepri metadata store', cat: 'Admin',
    what: 'Mnesia\'nın yerini almak üzere geliştirilen, <b>Raft</b> tabanlı yeni metadata veritabanıdır (kullanıcılar, vhost\'lar, kuyruk tanımları, binding\'ler vb.).',
    role: 'Ağ bölünmelerinde (network partition) Mnesia\'daki tutarsızlık sorunlarını, Raft\'ın çoğunluk temelli tutarlılığıyla çözer. 4.0\'dan itibaren tam desteklenir.',
    when: ['Etkinleştirmeden önce staging\'de test edin; işlem geri alınamaz'],
    ex: 'rabbitmqctl enable_feature_flag khepri_db',
    note: 'Bu simülasyonda khepri_db devre dışı (disabled) gösterilmiştir; 4.1\'de isteğe bağlıdır.' });
  h('deprecated-features', { t: 'Deprecated Features', cat: 'Admin',
    what: 'Gelecek sürümlerde kaldırılacak özelliklerin listesi ve bu cluster\'da kullanılıp kullanılmadığıdır.',
    role: 'Her özellik bir <b>deprecation phase</b> içindedir: <b>permitted_by_default</b> (çalışır, uyarı loglanır) → <b>denied_by_default</b> (varsayılan kapalı, config ile açılabilir) → <b>disconnected</b> (kod var ama kullanılamaz) → <b>removed</b> (tamamen kaldırıldı).',
    use: 'Yükseltme öncesi uyumluluk kontrolü.',
    ex: `rabbitmq-diagnostics list_deprecated_features
# Erken test için özelliği kapatma:
deprecated_features.permit.global_qos = false`,
    rel: ['deprecated-banner'] });
  h('cluster-status', { t: 'Cluster Status', cat: 'Cluster', what: 'Cluster\'daki disk node\'ları, çalışan node\'lar, alarmlar, ağ bölünmeleri ve bakım modu durumunun özetidir.', ex: 'rabbitmqctl cluster_status', rel: ['running-nodes', 'partitions', 'node-health'] });
  h('running-nodes', { t: 'Running Nodes', cat: 'Cluster', what: 'Şu anda çalışan ve cluster\'a bağlı node\'lardır. Kayıtlı ama çalışmayan node\'lar "disc nodes" listesinde olup "running" listesinde yer almaz.', role: 'Çalışmayan bir node, replike kuyrukların çoğunluk hesabını etkiler.' });
  h('node-health', { t: 'Node Health', term: 'Sağlık kontrolleri', cat: 'Cluster',
    what: 'Node\'un sağlıklı olup olmadığını gösteren kontrollerdir.',
    role: 'Önerilen kontroller (hafiften ağıra): <code>ping</code>, <code>check_running</code>, <code>check_local_alarms</code>, <code>check_port_connectivity</code>, <code>check_virtual_hosts</code>, <code>check_if_node_is_quorum_critical</code>.',
    use: 'Load balancer / Kubernetes readiness probe\'larında ve izleme sistemlerinde.',
    ex: `rabbitmq-diagnostics -q ping
rabbitmq-diagnostics -q check_local_alarms
# HTTP API: GET /api/health/checks/alarms
#           GET /api/health/checks/node-is-quorum-critical` });
  h('partitions', { t: 'Network Partitions', term: 'Ağ bölünmesi (split-brain)', cat: 'Cluster',
    what: 'Cluster node\'larının bir kısmının ağ sorunları nedeniyle birbirini görememesi durumudur.',
    role: 'Mnesia tabanlı metadata ile çalışan cluster\'larda davranış <code>cluster_partition_handling</code> ile belirlenir: <b>ignore</b> (varsayılan, hiçbir şey yapma), <b>pause_minority</b> (azınlıktaki node\'lar kendini durdurur – önerilen), <b>autoheal</b> (bölünme bitince kazanan taraf seçilir, diğerleri yeniden başlar). Quorum queue ve stream\'ler Raft sayesinde çoğunluk tarafında çalışmaya devam eder.',
    when: ['Partition görüldüğünde azınlık tarafındaki node\'ları yeniden başlatmak gerekebilir'],
    ex: 'cluster_partition_handling = pause_minority   # rabbitmq.conf',
    note: 'Khepri etkinleştirildiğinde metadata tutarlılığı Raft ile sağlanır ve partition_handling ayarları metadata için geçerliliğini yitirir.' });
  h('maintenance-mode', { t: 'Maintenance mode', term: 'Node drain', cat: 'Cluster', what: 'Bir node\'u planlı bakım için hazırlar: istemci bağlantıları kapatılır, yeni bağlantılar reddedilir, quorum queue leader\'ları diğer node\'lara taşınır.', ex: `rabbitmq-upgrade drain     # bakıma al
rabbitmq-upgrade revive    # geri al` });
  h('net-ticktime', { t: 'net_ticktime', cat: 'Cluster', what: 'Erlang node\'larının birbirinin erişilebilirliğini kontrol ettiği süredir (varsayılan 60 sn). Bu sürenin ~1.25 katı boyunca yanıt alınamazsa node "down" kabul edilir.' });
  h('node-memory-breakdown', { t: 'Memory details', term: 'Bellek dağılımı', cat: 'Node kaynakları', what: 'Node belleğinin bileşenlere göre dağılımıdır: bağlantı süreçleri, kanallar, kuyruklar (classic/quorum/stream), binary\'ler (mesaj gövdeleri), metadata deposu, management DB, plugin\'ler, ETS tabloları, kod, atom\'lar ve ayrılmış ama kullanılmayan bellek.', use: 'Bellek alarmının nedenini bulmak için: yüksek "Binaries" büyük mesajlar/birikme, yüksek "Connection readers/writers" çok bağlantı, yüksek "Quorum queues" çok sayıda veya büyük quorum kuyruğu gösterir.', ex: 'rabbitmq-diagnostics memory_breakdown --unit mb' });
  h('config-files', { t: 'Config files', cat: 'Node kaynakları', what: 'Node\'un okuduğu yapılandırma dosyalarıdır. <b>rabbitmq.conf</b>: sysctl/ini benzeri ana yapılandırma. <b>advanced.config</b>: Erlang terimleri ile ileri ayarlar. <b>enabled_plugins</b>: etkin eklentiler. Windows\'ta varsayılan konum <code>%APPDATA%\\RabbitMQ</code>\'dur.', ex: 'rabbitmq-diagnostics status   # dosya konumlarını gösterir' });

  /* ========================= FEDERATION ========================= */
  h('fed-upstream', { t: 'Federation Upstreams', cat: 'Federation',
    what: 'Federation\'ın mesaj alacağı uzak broker\'ların tanımıdır (runtime parameter: <code>federation-upstream</code>).',
    role: 'Bir upstream, bağlantı URI\'si ve davranış ayarlarını içerir. Upstream tek başına bir şey yapmaz; bir <b>policy</b> ile exchange/queue\'lara bağlanması gerekir (<code>federation-upstream</code> veya <code>federation-upstream-set</code> anahtarı).',
    ex: `rabbitmqctl set_parameter federation-upstream dc2-orders \\
 '{"uri":"amqps://user:pass@dc2-mq:5671/%2F","exchange":"orders.events",
   "max-hops":1,"ack-mode":"on-confirm","prefetch-count":1000,"expires":3600000}'`,
    rel: ['federation', 'fed-uri', 'fed-ack-mode', 'fed-max-hops'] });
  h('fed-uri', { t: 'URI', cat: 'Federation', what: 'Upstream broker\'ın AMQP URI\'sidir: <code>amqp(s)://kullanıcı:parola@host:port/vhost</code>. Birden çok URI verilirse bağlantı kurulamadığında sırayla denenir. TLS parametreleri sorgu dizesiyle verilebilir (<code>?cacertfile=...&verify=verify_peer</code>).' });
  h('fed-ack-mode', { t: 'Ack mode (federation)', cat: 'Federation', what: '<b>on-confirm</b> (varsayılan, en güvenli): mesaj downstream\'de confirm edildikten sonra upstream\'e ack gönderilir. <b>on-publish</b>: downstream\'e yayınlanınca ack. <b>no-ack</b>: ack yok, en hızlı ama kayıp riski var.' });
  h('fed-max-hops', { t: 'Max hops', cat: 'Federation', what: 'Bir mesajın federation zinciri boyunca kaç broker geçebileceğidir (varsayılan 1). Döngüsel topolojilerde mesajların sonsuz dolaşmasını engeller.' });
  h('fed-expires', { t: 'Expires / Message TTL (upstream)', cat: 'Federation', what: '<b>expires</b>: exchange federation\'da upstream tarafında oluşturulan geçici kuyruğun, bağlantı koptuktan sonra ne kadar (ms) yaşayacağı. <b>message-ttl</b>: bu kuyruktaki mesajların TTL\'i. Bağlantı uzun süre koparsa upstream\'de sınırsız birikmeyi önler.' });
  h('fed-prefetch', { t: 'Prefetch count (federation)', cat: 'Federation', what: 'Federation link\'inin upstream\'den aynı anda onaylanmamış olarak alabileceği maksimum mesaj sayısıdır (varsayılan 1000).' });
  h('fed-trust-user-id', { t: 'Trust user-id', cat: 'Federation', what: 'Upstream\'den gelen mesajlardaki user_id değerinin doğrulanmadan kabul edilip edilmeyeceğidir. Varsayılan false (güvenli).' });
  h('fed-exchange', { t: 'Exchange / Queue (upstream)', cat: 'Federation', what: 'Upstream\'deki hedef exchange veya kuyruk adıdır. Boş bırakılırsa downstream\'deki federated nesne ile aynı ad kullanılır.' });
  h('fed-links', { t: 'Federation Status (links)', cat: 'Federation',
    what: 'Policy\'ler ile oluşturulmuş aktif federation link\'lerinin durumudur. Her (federated nesne × upstream) çifti bir link\'tir.',
    role: '<b>running</b>: çalışıyor. <b>starting</b>: bağlanıyor. <b>error</b>: hata (Error sütununda neden – kimlik doğrulama, DNS, TLS). <b>shutdown</b>: kapatıldı.',
    use: 'Veri merkezleri arası aktarımın sağlıklı olduğunu doğrulamak için.',
    ex: 'rabbitmqctl federation_status\nrabbitmqctl restart_federation_link <link-id>' });
  h('fed-type', { t: 'Exchange vs Queue federation', cat: 'Federation', what: '<b>Exchange federation</b>: upstream exchange\'e yayınlanan mesajlar downstream exchange\'e kopyalanır (pub/sub dağıtımı). <b>Queue federation</b>: downstream kuyrukta consumer kapasitesi varsa upstream kuyruktan mesaj çekilir (yük paylaşımı); mesajlar kopyalanmaz, taşınır.' });

  /* ========================= SHOVEL ========================= */
  h('shovel-type', { t: 'Shovel type', term: 'Static / Dynamic', cat: 'Shovel', what: '<b>Dynamic</b> shovel\'lar çalışma anında runtime parameter olarak (UI, CLI, HTTP API) oluşturulur ve cluster metadata\'sında saklanır. <b>Static</b> shovel\'lar <code>advanced.config</code> dosyasında tanımlanır, değiştirmek için node yeniden başlatılmalıdır.', when: ['Çoğu senaryoda dynamic shovel tercih edin'] });
  h('shovel-state', { t: 'State (shovel)', cat: 'Shovel', what: '<b>starting</b>: bağlantılar kuruluyor. <b>running</b>: mesaj taşıyor. <b>terminated</b>: durdu (hata veya delete-after koşulu tamamlandı – Reason sütununa bakın). Hata durumunda shovel reconnect-delay süresi sonunda yeniden dener.' });
  h('shovel-protocol', { t: 'Source / Destination protocol', cat: 'Shovel', what: 'Kaynak ve hedef için kullanılan protokol: <b>amqp091</b> (AMQP 0-9-1) veya <b>amqp10</b> (AMQP 1.0). AMQP 1.0 ile RabbitMQ dışındaki broker\'lara (ör. Azure Service Bus, ActiveMQ) köprü kurulabilir.' });
  h('shovel-src', { t: 'Source', cat: 'Shovel', what: 'Mesajların okunacağı yerdir. Kaynak bir <b>queue</b> ise doğrudan tüketilir; bir <b>exchange</b> ise shovel geçici bir kuyruk oluşturup verilen routing key ile bağlar.', rel: ['shovel-delete-after'] });
  h('shovel-dest', { t: 'Destination', cat: 'Shovel', what: 'Mesajların yayınlanacağı yerdir: bir exchange (+ isteğe bağlı routing key; boşsa orijinal korunur) veya bir queue (default exchange üzerinden).' });
  h('shovel-ack-mode', { t: 'Acknowledgement mode', cat: 'Shovel', what: '<b>on-confirm</b>: hedef broker confirm ettikten sonra kaynağa ack (en güvenli, varsayılan). <b>on-publish</b>: hedefe yayınlanınca ack. <b>no-ack</b>: kaynaktan autoAck ile tüketir – en hızlı, kayıp riski en yüksek.' });
  h('shovel-delete-after', { t: 'Auto-delete (src-delete-after)', cat: 'Shovel', what: 'Shovel\'ın ne zaman kendini sileceğini belirler. <b>never</b>: sürekli çalışır. <b>queue-length</b>: başlangıçtaki kuyruk uzunluğu kadar mesaj taşıyınca durur (UI\'daki "Move messages" bunu kullanır). <b>sayı</b>: belirtilen sayıda mesajdan sonra durur.' });
  h('shovel-prefetch', { t: 'Prefetch count (shovel)', cat: 'Shovel', what: 'Shovel\'ın kaynaktan aynı anda onaylanmamış olarak alabileceği mesaj sayısı (varsayılan 1000).' });
  h('shovel-forward-headers', { t: 'Add forwarding headers', cat: 'Shovel', what: 'Etkinse taşınan mesajlara <code>x-shovelled</code> header\'ı eklenir (shovel adı, kaynak/hedef bilgisi). Mesajın nereden geldiğini izlemek için kullanılır.' });
  h('shovel-reconnect', { t: 'Reconnect delay', cat: 'Shovel', what: 'Bağlantı koptuğunda veya hata oluştuğunda shovel\'ın yeniden bağlanmayı denemeden önce bekleyeceği süre (saniye, varsayılan 5).' });

  /* ========================= MONITORING ========================= */
  h('prometheus', { t: 'Prometheus & Grafana', cat: 'Monitoring',
    what: '<code>rabbitmq_prometheus</code> eklentisi, node metriklerini Prometheus formatında <b>15692</b> portunda yayınlar. RabbitMQ ekibinin hazır Grafana dashboard\'ları vardır (RabbitMQ-Overview, Quorum Queues Raft, Erlang Distribution).',
    role: 'Management UI\'daki istatistikler kısa süreli ve node belleğinde tutulur; Prometheus ise uzun süreli saklama, alarm kuralları ve çoklu cluster görünümü sağlar.',
    use: 'Üretim izleme ve alarmlama için önerilen yöntemdir.',
    ex: `rabbitmq-plugins enable rabbitmq_prometheus
curl -s http://mq-node-01:15692/metrics | head
# Kuyruk bazlı ayrıntılı metrikler:
curl -s http://mq-node-01:15692/metrics/detailed?family=queue_coarse_metrics`,
    note: 'management_metrics_collection 4.x\'te deprecated olarak işaretlendi; gelecekte Management UI\'daki bazı grafikler kaldırılabilir.' });
  h('mon-deliver-rate', { t: 'Deliver Rate', cat: 'Monitoring', what: 'Consumer\'lara saniyede teslim edilen mesaj sayısı (manual + auto ack, get dahil). Publish oranıyla karşılaştırılarak sistemin dengede olup olmadığı anlaşılır.', rel: ['rate-deliver-manual'] });
  h('mon-ack-rate', { t: 'Acknowledge Rate', cat: 'Monitoring', what: 'Saniyedeki consumer ack sayısı. Deliver (manual) ile arasındaki fark unacked birikmesini gösterir.', rel: ['rate-consumer-ack'] });
  h('mon-redeliver-rate', { t: 'Redeliver Rate', cat: 'Monitoring', what: 'Saniyedeki yeniden teslim sayısı. Toplam teslimin %1\'inden fazlası genellikle uygulama hatasına işaret eder.', rel: ['rate-redelivered'] });
  h('mon-conn-stats', { t: 'Connection Statistics', cat: 'Monitoring', what: 'Bağlantıların protokol, node, kullanıcı ve durum dağılımıdır. Dengesiz node dağılımı load balancer sorununu; çok sayıda blocked/flow bağlantı kaynak sorununu gösterir.' });
  h('mon-ch-stats', { t: 'Channel Statistics', cat: 'Monitoring', what: 'Kanal sayıları, mod dağılımı (confirm / tx / none) ve toplam unacked. Bağlantı başına ortalama kanal sayısının çok yüksek olması kanal sızıntısının belirtisidir.' });
  h('mon-queue-stats', { t: 'Queue Statistics', cat: 'Monitoring', what: 'Kuyruk tipi dağılımı ve en çok mesaj biriken kuyruklar. Consumer\'ı olmayan ve mesaj biriken kuyruklar öncelikli incelenmelidir.' });
  h('mon-cpu', { t: 'CPU ve sistem kaynakları', cat: 'Monitoring', what: 'Erlang scheduler kullanımı, run queue (çalışmayı bekleyen süreç kuyruğu), garbage collection ve disk I/O.', role: 'Sürekli yüksek run queue, CPU\'nun yetersiz olduğunu gösterir. Quorum queue\'lar ve TLS CPU yoğundur; disk I/O gecikmesi quorum/stream yazma performansını doğrudan etkiler.', ex: `rabbitmq-diagnostics runtime_thread_stats
rabbitmq-diagnostics observer     # top benzeri canlı görünüm` });
})(window);
