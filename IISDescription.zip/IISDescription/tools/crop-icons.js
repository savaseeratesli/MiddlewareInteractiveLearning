// PNG decode -> crop -> transparent background -> PNG encode (no dependencies)
const fs = require("fs"), zlib = require("zlib"), path = require("path");
const SRC = process.argv[2], OUT = process.argv[3];

function decode(file) {
  const b = fs.readFileSync(file); let p = 8, w, h, ct, idat = [];
  while (p < b.length) {
    const len = b.readUInt32BE(p), type = b.toString("ascii", p + 4, p + 8), data = b.subarray(p + 8, p + 8 + len);
    if (type === "IHDR") { w = data.readUInt32BE(0); h = data.readUInt32BE(4); ct = data[9]; if (data[8] !== 8 || data[12]) throw "unsupported"; }
    if (type === "IDAT") idat.push(data);
    p += 12 + len;
  }
  const bpp = ct === 6 ? 4 : ct === 2 ? 3 : (() => { throw "ct " + ct; })();
  const raw = zlib.inflateSync(Buffer.concat(idat)), stride = w * bpp, px = Buffer.alloc(w * h * 4);
  let prev = Buffer.alloc(stride), cur = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)], line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? cur[i - bpp] : 0, up = prev[i], c = i >= bpp ? prev[i - bpp] : 0; let v = line[i];
      if (f === 1) v += a; else if (f === 2) v += up; else if (f === 3) v += (a + up) >> 1;
      else if (f === 4) { const pp = a + up - c, pa = Math.abs(pp - a), pb = Math.abs(pp - up), pc = Math.abs(pp - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? up : c; }
      cur[i] = v & 255;
    }
    for (let x = 0; x < w; x++) { const o = (y * w + x) * 4; px[o] = cur[x * bpp]; px[o + 1] = cur[x * bpp + 1]; px[o + 2] = cur[x * bpp + 2]; px[o + 3] = bpp === 4 ? cur[x * bpp + 3] : 255; }
    [prev, cur] = [cur, prev];
  }
  return { w, h, px };
}
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc = (buf) => { let c = -1; for (const x of buf) c = CRC[(c ^ x) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function chunk(t, d) { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); }
function encode(w, h, px) {
  const raw = Buffer.alloc(h * (w * 4 + 1));
  for (let y = 0; y < h; y++) { raw[y * (w * 4 + 1)] = 0; px.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4); }
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ih), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]);
}
function crop(img, x0, y0, w, h, transparent) {
  const px = Buffer.alloc(w * h * 4);
  for (let y = 0; y < h; y++) img.px.copy(px, y * w * 4, ((y0 + y) * img.w + x0) * 4, ((y0 + y) * img.w + x0 + w) * 4);
  if (transparent) { // flood fill near-white background from the border
    const seen = new Uint8Array(w * h), st = [];
    const light = (i) => px[i * 4] >= 236 && px[i * 4 + 1] >= 236 && px[i * 4 + 2] >= 236;
    for (let x = 0; x < w; x++) st.push(x, (h - 1) * w + x); for (let y = 0; y < h; y++) st.push(y * w, y * w + w - 1);
    while (st.length) { const i = st.pop(); if (seen[i] || !light(i)) continue; seen[i] = 1; const x = i % w, y = (i / w) | 0; if (x) st.push(i - 1); if (x < w - 1) st.push(i + 1); if (y) st.push(i - w); if (y < h - 1) st.push(i + w); }
    for (let i = 0; i < w * h; i++) {
      if (seen[i]) { px[i * 4 + 3] = 0; continue; }
      // soften anti-aliased light pixels touching the background
      const x = i % w, y = (i / w) | 0; let nb = 0; for (const j of [i - 1, i + 1, i - w, i + w]) if (j >= 0 && j < w * h && Math.abs((j % w) - x) <= 1 && seen[j]) nb++;
      if (nb) { const m = Math.min(px[i * 4], px[i * 4 + 1], px[i * 4 + 2]); if (m > 200) px[i * 4 + 3] = Math.round(255 * (255 - m) / 55); }
    }
  }
  return encode(w, h, px);
}

const imgs = {}; const I = (n) => imgs[n] || (imgs[n] = decode(path.join(SRC, n + ".png")));
const jobs = [];
const F = (file, top, ids, start) => ids.forEach((id, i) => id && jobs.push(["f-" + id, file, 203 + 50 * (i + (start || 0)), top, 24, 24, true]));
F("2", 121, ["netauthz", "netcomp", "neterr", "netglob", "nettrust", "appset", "connstr", "machkey", "pages", "providers", "session", "smtp"]);
F("2", 187, ["ftpauth", "ftpauthz", "ftpdir", "ftpfw", "ftpip", "ftplog", "ftplogon", "ftpmsg", "ftpreq", "ftpssl", "ftpiso"]);
F("2", 253, ["asp", "authc", "authz", "cgi", "compress", "defdoc", "dirbrowse", "errpages", "frt", "fastcgi", "handlers", "redirect", "headers", "iprestr", "isapicgi", "isapifilt", "logging", "mime", "modules", "outcache", "reqfilt", "certs", "rewrite", "webdav"]);
F("2", 303, ["workers"]);
F("2", 369, ["centralcert", "config", "delegation", "mgrperm", "mgrusers", "mgmtsvc", "sharedcfg"]);
F("4", 125, ["netprof", "netroles", null, "netusers"], 4);
F("4", 191, ["ssl"], 19);
const S = (n, f, x, y, w, h, t) => jobs.push([n, f, x, y, w, h, t !== false]);
S("t-start", "2", 16, 88, 14, 13); S("t-server", "4", 16, 100, 14, 14); S("t-pools", "2", 28, 110, 14, 14); S("t-sites", "2", 27, 122, 14, 14); S("t-site", "2", 38, 135, 14, 14);
S("t-pool", "3", 193, 144, 13, 13);
S("h-server", "2", 189, 63, 22, 22); S("h-pools", "3", 190, 62, 22, 22); S("h-site", "4", 189, 66, 22, 22);
S("a-restart", "2", 1466, 87, 13, 13); S("a-start", "2", 1466, 101, 13, 13); S("a-stop", "2", 1466, 114, 13, 13); S("a-wpi", "2", 1465, 163, 13, 13); S("a-help", "2", 1465, 184, 13, 13);
S("a-explore", "4", 1465, 76, 13, 13); S("a-basic", "4", 1465, 133, 13, 13); S("a-browse", "4", 1465, 252, 13, 13); S("a-add", "3", 1467, 73, 13, 13);
S("v-features", "2", 185, 932, 13, 13); S("v-content", "2", 251, 932, 13, 13);
S("b-go", "2", 299, 92, 14, 13); S("b-showall", "2", 334, 92, 15, 13); S("b-view", "2", 503, 92, 22, 13);
S("s-toolbar", "2", 1, 72, 72, 15, false); S("s-nav", "3", 2, 16, 37, 18, false); S("s-navr", "3", 1519, 16, 76, 18, false); S("s-addr", "2", 55, 19, 14, 14, false); S("s-title", "2", 2, 2, 13, 13);

fs.mkdirSync(OUT, { recursive: true });
for (const [n, f, x, y, w, h, t] of jobs) fs.writeFileSync(path.join(OUT, n + ".png"), crop(I(f), x, y, w, h, t));
console.log("wrote", jobs.length, "icons");

// sample colours for CSS
const px = (f, x, y) => { const im = I(f), o = (y * im.w + x) * 4; return "#" + [0, 1, 2].map((k) => im.px[o + k].toString(16).padStart(2, "0")).join(""); };
const samples = { title: ["2", 300, 8], addrTop: ["2", 600, 17], addrMid: ["2", 600, 25], addrBot: ["2", 600, 33], addrBox: ["2", 300, 25], addrBorder: ["2", 52, 25], menu: ["2", 300, 45], paneHdr: ["2", 100, 62], paneHdrB: ["2", 100, 68], tb: ["2", 100, 78], mainBg: ["2", 181, 300], frame: ["2", 186, 300], groupText: ["2", 205, 113], groupLine: ["2", 700, 112], filter: ["2", 600, 98], actLink: ["2", 1486, 94], actHdr: ["2", 1500, 63], status: ["2", 300, 956], tabbar: ["2", 600, 938], selRow: ["2", 150, 105], selPg: ["6", 100, 705], pgCat: ["6", 400, 33], pgGutter: ["6", 14, 60], pgLine: ["6", 200, 54], descBg: ["6", 300, 900], dlgBg: ["6", 300, 940], ttl: ["5", 300, 10] };
console.log(JSON.stringify(Object.fromEntries(Object.entries(samples).map(([k, v]) => [k, px(...v)]))));
