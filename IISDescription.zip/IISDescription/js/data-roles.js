/* Sunucu Yöneticisi > Add Roles and Features > Web Server (IIS) > Role Services
   n: ad, d: açıklama, f: IIS Yöneticisi'nde ilgili özellik kimlikleri, c: alt öğeler */
IIS.roleServices = {
  n: "Web Server (IIS)", d: "Web Server (IIS) rolü; web sitelerini, web uygulamalarını ve servisleri barındırmak için güvenilir, yönetilebilir ve ölçeklenebilir bir web uygulama altyapısı sağlar. Rol, ihtiyaç duyduğunuz bileşenleri tek tek seçebileceğiniz 'rol hizmetlerinden' (role services) oluşur. Yalnızca gereken bileşenleri kurmak saldırı yüzeyini küçültür. Bir rol hizmeti kurulduğunda IIS Yöneticisi'nde ilgili özellik simgesi belirir.",
  c: [
    { n: "Web Server", d: "HTML sayfalarını, statik dosyaları ve dinamik uygulamaları sunmak için temel web sunucusu işlevleri. HTTP özellikleri, sağlık ve tanılama, performans, güvenlik ve uygulama geliştirme alt grupları vardır.", c: [
      { n: "Common HTTP Features", d: "Statik içerik sunma, varsayılan belge, dizin listeleme, hata sayfaları ve yönlendirme gibi standart HTTP işlevlerini sağlayan temel bileşenler.", c: [
        { n: "Default Document", d: "Kullanıcı URL'de dosya adı belirtmediğinde (ör. https://site.com/) sunulacak varsayılan dosyayı (index.html, default.aspx...) yapılandırmanızı sağlar.", f: ["defdoc"] },
        { n: "Directory Browsing", d: "Varsayılan belge bulunmadığında kullanıcının bir klasörün içeriğini (dosya listesini) görmesine izin verir. Kurulu olsa bile varsayılan olarak devre dışıdır.", f: ["dirbrowse"] },
        { n: "HTTP Errors", d: "HTTP hata mesajlarının (404, 500...) özelleştirilmesini sağlar. Kullanıcıya özel hata sayfası mı yoksa ayrıntılı hata mı gösterileceğini belirlersiniz.", f: ["errpages"] },
        { n: "Static Content", d: "HTML, resim, CSS, JavaScript gibi statik dosyaların sunulmasını sağlar. Bu bileşen kurulu değilse .html sayfaları bile sunulamaz! MIME türleri bu bileşenle birlikte gelir.", f: ["mime"] },
        { n: "HTTP Redirection", d: "İsteklerin başka bir URL'ye yönlendirilmesini sağlar (301/302/307). Basit site taşıma senaryoları için kullanılır.", f: ["redirect"] },
        { n: "WebDAV Publishing", d: "Web Distributed Authoring and Versioning: dosyaların HTTP üzerinden yayımlanması, kilitlenmesi ve düzenlenmesi. DİKKAT: REST API (PUT/DELETE) kullanan uygulamalarda 405 hatasına yol açabilir.", f: ["webdav"] }
      ] },
      { n: "Health and Diagnostics", d: "Sunucuyu, siteleri ve uygulamaları izlemek, yönetmek ve sorunlarını gidermek için altyapı sağlar.", c: [
        { n: "HTTP Logging", d: "Bu sunucudaki web sitelerinin etkinliğini (her isteği) W3C, IIS veya NCSA biçiminde günlüğe yazar. Sorun giderme için neredeyse her sunucuda kurulmalıdır.", f: ["logging"] },
        { n: "Custom Logging", d: "IIS'in ürettiğinden farklı bir biçimde günlük tutmak için özel günlük modüllerinin (COM bileşeni) kullanılmasını sağlar.", f: ["logging"] },
        { n: "Logging Tools", d: "Günlük dosyalarını yönetmek ve günlüğe yazma işlerini otomatikleştirmek için altyapı ve betikler (Logging Utility ActiveX kontrolü).", f: ["logging"] },
        { n: "ODBC Logging", d: "Günlükleri dosya yerine ODBC uyumlu bir veritabanına (ör. SQL Server) yazmayı sağlar. Yoğun trafikte performansı düşürebilir.", f: ["logging"] },
        { n: "Request Monitor", d: "Sunucu, site ve uygulama sağlığını izlemek için o an çalışan istekleri gösterir. IIS Yöneticisi'nde Worker Processes > View Current Requests özelliğini sağlar. Takılan/yavaş istekleri bulmak için çok değerlidir.", f: ["workers"] },
        { n: "Tracing", d: "Başarısız İstek İzleme (FREB) altyapısını sağlar. Hata veren veya uzun süren isteklerin IIS hattındaki her adımını XML olarak kaydeder.", f: ["frt"] }
      ] },
      { n: "Performance", d: "Çıktı önbellekleme ve sıkıştırma ile içerik sunumunu hızlandıran bileşenler.", c: [
        { n: "Static Content Compression", d: "Statik dosyaları (CSS, JS, HTML) sıkıştırıp sıkıştırılmış kopyayı önbellekte tutar. Bant genişliğini azaltır, CPU maliyeti çok düşüktür.", f: ["compress"] },
        { n: "Dynamic Content Compression", d: "Dinamik yanıtları (ASP.NET, PHP çıktıları, JSON) her istekte sıkıştırır. Daha fazla CPU kullanır ama sayfa boyutunu ciddi azaltır.", f: ["compress"] }
      ] },
      { n: "Security", d: "Kimlik doğrulama, yetkilendirme ve istek filtreleme gibi güvenlik bileşenleri.", c: [
        { n: "Request Filtering", d: "Gelen tüm istekleri kurallara göre süzer: tehlikeli uzantılar, gizli klasörler (bin, App_Data), çok uzun URL'ler, büyük dosyalar vb. Varsayılan olarak kuruludur ve KALDIRILMAMALIDIR.", f: ["reqfilt"] },
        { n: "Basic Authentication", d: "Kullanıcı adı ve parolanın Base64 ile gönderildiği temel kimlik doğrulama. Şifreleme sağlamaz; mutlaka HTTPS ile kullanılmalıdır.", f: ["authc"] },
        { n: "Centralized SSL Certificate Support", d: "SSL sertifikalarının bir dosya paylaşımında merkezi olarak tutulmasını sağlar (Centralized Certificate Store). Web çiftliklerinde sertifika yönetimini kolaylaştırır.", f: ["centralcert"] },
        { n: "Client Certificate Mapping Authentication", d: "İstemci sertifikalarını Active Directory hesaplarıyla (bire bir veya çoka bir) eşleyerek kimlik doğrulama yapar.", f: ["authc", "ssl"] },
        { n: "Digest Authentication", d: "Parolanın karma (hash) değerini Windows domain denetleyicisine göndererek kimlik doğrulama yapar. Basic'ten daha güvenlidir ama nadiren kullanılır.", f: ["authc"] },
        { n: "IIS Client Certificate Mapping Authentication", d: "İstemci sertifikalarını IIS yapılandırmasında tanımlı Windows hesaplarıyla eşler (AD gerektirmez). Ayarları Configuration Editor üzerinden yapılır.", f: ["authc", "config"] },
        { n: "IP and Domain Restrictions", d: "İstemci IP adresine veya domain adına göre erişime izin verir/reddeder. Dinamik IP kısıtlaması (çok sık istek yapan IP'yi engelleme) da bu bileşenle gelir.", f: ["iprestr"] },
        { n: "URL Authorization", d: "Kullanıcı ve rollere göre URL erişim kuralları tanımlamayı sağlar (IIS Authorization Rules). Tüm içerik türleri için çalışır.", f: ["authz"] },
        { n: "Windows Authentication", d: "NTLM veya Kerberos ile Windows domain kullanıcılarının otomatik kimlik doğrulaması. Intranet uygulamaları için idealdir.", f: ["authc"] }
      ] },
      { n: "Application Development", d: "Web uygulamaları geliştirmek ve barındırmak için altyapı: ASP.NET, Klasik ASP, CGI, ISAPI, WebSocket vb.", c: [
        { n: ".NET Extensibility 3.5", d: ".NET Framework 3.5 (CLR 2.0) tabanlı yönetilen modüllerin IIS istek hattına katılmasını sağlar. Eski .NET 2.0/3.5 uygulamaları için gereklidir.", f: ["modules"] },
        { n: ".NET Extensibility 4.8", d: ".NET Framework 4.x yönetilen modüllerinin (IHttpModule) ve işleyicilerinin (IHttpHandler) IIS hattında çalışmasını sağlar. ASP.NET 4.8'in ön koşuludur.", f: ["modules", "handlers"] },
        { n: "Application Initialization", d: "Uygulamanın ilk istek gelmeden önce 'ısıtılmasını' (preload) sağlar. Havuz Start Mode = AlwaysRunning ve site Preload Enabled = True ile birlikte kullanılır; ilk istekteki gecikmeyi ortadan kaldırır.", f: ["config"] },
        { n: "ASP", d: "Klasik ASP (Active Server Pages, VBScript/JScript) desteği. Eski .asp uygulamaları için gerekir; ISAPI Extensions bileşenini de kurar.", f: ["asp"] },
        { n: "ASP.NET 3.5", d: ".NET Framework 3.5 ile ASP.NET Web Forms/MVC uygulamaları için destek. Windows Server'da kurulum kaynağı (sources\\sxs) gerekebilir.", f: ["netcomp", "pages"] },
        { n: "ASP.NET 4.8", d: ".NET Framework 4.8 ile ASP.NET (Web Forms, MVC, Web API) uygulamalarını çalıştırır. IIS Yöneticisi'ndeki ASP.NET grubundaki simgelerin (.NET Compilation, Session State, Machine Key...) çoğu bu bileşenle gelir. Not: ASP.NET Core için ayrıca 'Hosting Bundle' kurulmalıdır.", f: ["netcomp", "session", "machkey", "appset", "connstr"] },
        { n: "CGI", d: "Common Gateway Interface desteği. Ayrıca FastCGI'ı da kurar; PHP ve Python gibi dillerin IIS üzerinde çalıştırılması için gereklidir.", f: ["cgi", "fastcgi"] },
        { n: "ISAPI Extensions", d: "ISAPI uzantılarının (DLL tabanlı dinamik içerik işleyicileri) çalışmasını sağlar. Klasik ASP ve Classic moddaki ASP.NET bunu kullanır.", f: ["isapicgi", "handlers"] },
        { n: "ISAPI Filters", d: "Her istekte çalışan ISAPI filtrelerinin (DLL) kullanılmasını sağlar.", f: ["isapifilt"] },
        { n: "Server Side Includes", d: "SSI: .shtml/.stm sayfalarında <!--#include file=\"...\"--> gibi yönergelerle başka dosya içeriklerinin sunucu tarafında sayfaya eklenmesini sağlar.", f: ["handlers"] },
        { n: "WebSocket Protocol", d: "WebSocket (ws://, wss://) protokolü desteği. SignalR, canlı bildirim ve sohbet uygulamaları için gereklidir. Kurulu değilse SignalR uzun yoklama (long polling) moduna düşer.", f: ["config"] }
      ] }
    ] },
    { n: "FTP Server", d: "FTP Server, web siteleri için dosya aktarımı (yükleme/indirme) sağlar. IIS Yöneticisi'nde FTP özellik grubunu ekler.", c: [
      { n: "FTP Service", d: "Microsoft FTP Service hizmetini (ftpsvc) kurar. FTP siteleri oluşturmanızı, kimlik doğrulama, yetkilendirme, SSL ve kullanıcı yalıtımı ayarlamanızı sağlar.", f: ["ftpauth", "ftpauthz", "ftpssl", "ftpiso", "ftpfw", "ftpmsg"] },
      { n: "FTP Extensibility", d: "Özel kimlik doğrulama, yetkilendirme, günlük ve ev klasörü sağlayıcıları (.NET ile yazılmış) kullanılmasını sağlar. IIS Manager kullanıcılarıyla FTP girişi için gereklidir.", f: ["ftpauth"] }
    ] },
    { n: "Management Tools", d: "IIS'i yerel ve uzaktan yönetmek için araçlar: IIS Yöneticisi, komut satırı betikleri, PowerShell modülü ve uzaktan yönetim hizmeti.", c: [
      { n: "IIS Management Console", d: "Şu an gördüğünüz grafik arayüz: Internet Information Services (IIS) Manager (inetmgr.exe). Web sunucusunu yerel veya uzaktan yönetmenizi sağlar.", f: ["config"] },
      { n: "IIS 6 Management Compatibility", d: "IIS 6 dönemi API'lerini ve araçlarını kullanan eski betiklerin ve uygulamaların IIS 10 üzerinde çalışabilmesi için uyumluluk katmanı.", c: [
        { n: "IIS 6 Metabase Compatibility", d: "IIS 6 metabase API'lerini (ADSI, ABO) kullanan uygulamaların IIS 10 yapılandırmasını okuyup yazabilmesini sağlar. Bazı eski kurulum programları (ör. eski SharePoint, Exchange bileşenleri) bunu gerektirir." },
        { n: "IIS 6 Management Console", d: "IIS 6 Yöneticisi konsolu. Günümüzde yalnızca IIS 6 SMTP sanal sunucusunu yönetmek için kullanılır." },
        { n: "IIS 6 Scripting Tools", d: "IIS 6 dönemi yönetim betikleri (iisweb.vbs, iisvdir.vbs gibi) ve ADSI/WMI tabanlı otomasyon desteği." },
        { n: "IIS 6 WMI Compatibility", d: "IIS 6 WMI sağlayıcısı (root\\MicrosoftIISv1) desteği. Eski WMI betikleri için gereklidir." }
      ] },
      { n: "IIS Management Scripts and Tools", d: "IIS'i komut satırından yönetmek için araçlar: appcmd.exe, IIS PowerShell modülleri (WebAdministration, IISAdministration) ve WMI sağlayıcısı. Otomasyon için kurulması önerilir.", f: ["config"] },
      { n: "Management Service", d: "Web Management Service (WMSVC): başka bir bilgisayardaki IIS Yöneticisi'nin veya Web Deploy'un bu sunucuya uzaktan bağlanmasını sağlar (port 8172). Feature Delegation, IIS Manager Users ve IIS Manager Permissions özellikleri de bununla anlam kazanır.", f: ["mgmtsvc", "mgrusers", "mgrperm", "delegation"] }
    ] }
  ]
};

IIS.wizardSteps = [
  ["Before You Begin", "Sihirbaz hakkında bilgi: yönetici parolasının güçlü olduğundan, ağ ayarlarının (statik IP) yapıldığından ve güncellemelerin yüklendiğinden emin olmanız önerilir."],
  ["Installation Type", "Role-based or feature-based installation (tek sunucuya rol/özellik kurma) veya Remote Desktop Services installation seçilir. IIS için ilk seçenek kullanılır."],
  ["Server Selection", "Kurulumun yapılacağı sunucu veya sanal sabit disk (VHD) seçilir. Sunucu havuzundaki uzak sunuculara da kurulum yapılabilir."],
  ["Server Roles", "Kurulacak roller seçilir. Web Server (IIS) burada işaretlenir; işaretlenince gerekli yönetim araçlarını da eklemek için bir pencere açılır."],
  ["Features", "Role bağlı olmayan Windows özellikleri (.NET Framework 3.5/4.8, Telnet Client, Windows Process Activation Service vb.) seçilir."],
  ["Web Server Role (IIS)", "IIS rolü hakkında bilgilendirme sayfası."],
  ["Role Services", "IIS'in hangi bileşenlerinin (rol hizmetlerinin) kurulacağının seçildiği sayfa – şu an buradasınız. Her öğeyi seçtiğinizde sağda açıklaması görünür."],
  ["Confirmation", "Kurulacak tüm bileşenlerin özeti. 'Restart the destination server automatically if required' seçeneği burada işaretlenir. Install ile kurulum başlar."],
  ["Results", "Kurulumun ilerlemesi ve sonucu gösterilir."]
];
