/* IIS Yardım Masası – Özellik (Feature) sayfaları ve açıklamaları
   lv: "all" = sunucu + site + uygulama düzeyi, "server" = yalnızca sunucu, "site" = site ve altı
   Alan tipleri: c = onay kutusu, t = metin, s = açılır liste, r = seçenek düğmeleri, l = bilgi satırı */
(function () {
  const r = (h, ...c) => ({ h, c });
  const c = (n, v, h) => ["c", n, v, h];
  const t = (n, v, h) => ["t", n, v, h];
  const s = (n, v, opts, h) => ["s", n, v, h, opts];
  const rd = (n, v, opts, h) => ["r", n, v, h, opts]; // opts: [[ad, açıklama], ...]
  const l = (n, v, h) => ["l", n, v, h];

  const A = { // ortak eylemler
    add: (x, h) => ["Add" + (x ? " " + x : "") + "...", "➕", h || "Listeye yeni bir öğe ekler."],
    edit: (h) => ["Edit...", "📝", h || "Seçili öğeyi düzenler."],
    remove: (h) => ["Remove", "❌", h || "Seçili öğeyi kaldırır. Öğe üst düzeyden miras alınmışsa (Entry Type = Inherited), bu düzeyde <remove> etiketiyle devre dışı bırakılır."],
    apply: ["Apply", "✔️", "Sayfadaki değişiklikleri yapılandırma dosyasına (web.config veya applicationHost.config) kaydeder. Apply'a basmadan sayfadan çıkarsanız değişiklikler kaybolur."],
    cancel: ["Cancel", "↩️", "Kaydedilmemiş değişiklikleri geri alır ve sayfayı son kaydedilmiş hâline döndürür."],
    revert: ["Revert to Parent", "⤴️", "Bu düzeyde yapılmış özel ayarları siler; ayar tekrar üst düzeyden (sunucu/site) miras alınır."],
    feat: ["Edit Feature Settings...", "⚙️", "Özelliğin genel (liste öğelerinden bağımsız) ayarlarını düzenler."]
  };

  IIS.groups = [
    ["ASP.NET", "ASP.NET (.NET Framework) uygulamalarına özgü ayarlar. Bu ayarlar web.config içindeki <system.web>, <appSettings>, <connectionStrings> bölümlerine yazılır. ASP.NET Core uygulamaları bu ayarların çoğunu kullanmaz (onlar appsettings.json kullanır)."],
    ["FTP", "FTP sunucusu (Microsoft FTP Service) ayarları. Dosya aktarımı için kullanılır; web sitesinden bağımsız çalışabilir veya bir web sitesine FTP bağlaması (Add FTP Publishing) eklenerek aynı klasör FTP ile yönetilebilir. Ayarlar applicationHost.config içindeki <system.ftpServer> ve site/<ftpServer> bölümlerine yazılır."],
    ["IIS", "IIS web sunucusunun kendi özellikleri: kimlik doğrulama, sıkıştırma, hata sayfaları, günlük, işleyiciler, modüller vb. Ayarlar <system.webServer> bölümüne yazılır ve tüm teknolojiler (ASP.NET, PHP, statik dosyalar) için geçerlidir."],
    ["Management", "IIS'in yönetimine ilişkin araçlar: yapılandırma düzenleyici, özellik yetkilendirme (delegation), paylaşılan yapılandırma, uzaktan yönetim hizmeti."]
  ];

  IIS.features = [
  /* ===================== ASP.NET ===================== */
  { id: "netauthz", n: ".NET Authorization Rules", g: "ASP.NET", ic: "🛡️", lv: "all",
    d: "ASP.NET'in URL yetkilendirme kurallarıdır (<system.web><authorization>). Hangi kullanıcıların veya rollerin içeriğe erişebileceğini allow/deny kurallarıyla belirler. Yalnızca ASP.NET tarafından işlenen isteklere uygulanır (Classic modda statik dosyalara uygulanmaz). IIS düzeyindeki kurallar için 'Authorization Rules' özelliğini kullanın.",
    cfg: "system.web/authorization",
    list: { cols: [["Mode", "Kuralın türü: Allow (izin ver) veya Deny (reddet)."], ["Users", "Kuralın uygulandığı kullanıcılar. * = tüm kullanıcılar, ? = anonim (giriş yapmamış) kullanıcılar, veya belirli kullanıcı adları."], ["Roles", "Kuralın uygulandığı roller (ör. Admins). Role Manager etkin olmalıdır."], ["Verbs", "Kuralın uygulandığı HTTP metotları (GET, POST...). Boş = hepsi."], ["Entry Type", "Local: bu düzeyde tanımlı. Inherited: üst düzeyden miras alınmış."]],
      rows: [r("Varsayılan kural: herkese izin ver. Kurallar YUKARIDAN AŞAĞIYA değerlendirilir ve ilk eşleşen kural uygulanır.", "Allow", "*", "", "", "Inherited"),
             r("Anonim kullanıcıları reddeden örnek kural. Forms kimlik doğrulama ile birlikte kullanılırsa giriş yapmayan kullanıcı login sayfasına yönlendirilir.", "Deny", "?", "", "", "Local")] },
    acts: [A.add("Allow Rule", "Yeni bir izin verme kuralı ekler."), A.add("Deny Rule", "Yeni bir reddetme kuralı ekler."), A.edit(), A.remove(), ["Move Up", "⬆️", "Kuralı yukarı taşır. ASP.NET kurallarında sıra önemlidir; ilk eşleşen kural kazanır."], ["Move Down", "⬇️", "Kuralı aşağı taşır."]] },

  { id: "netcomp", n: ".NET Compilation", g: "ASP.NET", ic: "⚙️", lv: "all",
    d: "ASP.NET sayfa ve kodlarının nasıl derleneceğini belirler (<system.web><compilation>): hata ayıklama modu, hedef framework, varsayılan dil, derleme toplu işleme (batch) ayarları ve referans edilen derlemeler.",
    cfg: "system.web/compilation",
    grid: [
      { cat: "Assemblies", props: [["Assemblies", "(Collection)", "Derleme sırasında referans verilecek ek .NET derlemelerinin (DLL) listesi. Genellikle GAC'taki derlemeler buraya eklenir.", "compilation/assemblies"]] },
      { cat: "Batch", props: [
        ["Batch Compilations", "True", "True ise aynı klasördeki sayfalar tek tek değil toplu halde derlenir; ilk istekte biraz yavaş ama sonraki sayfalar hızlı açılır.", "@batch"],
        ["Maximum File Size", "1000", "Toplu derlemeye alınacak en büyük kaynak dosya boyutu (KB).", "@maxBatchGeneratedFileSize"],
        ["Maximum Size of Batch", "1000", "Bir toplu derlemedeki en fazla dosya sayısı.", "@maxBatchSize"],
        ["Time-out", "00:15:00", "Toplu derleme için azami süre. Aşılırsa derleme tek tek dosya moduna düşer.", "@batchTimeout"]] },
      { cat: "Behavior", props: [
        ["Debug", "False", "True ise derlemeler hata ayıklama sembolleriyle yapılır, zaman aşımları uzar, önbellekleme ve optimizasyonlar kapanır. ÜRETİMDE MUTLAKA False olmalıdır – performansı ciddi düşürür ve bilgi sızdırabilir.", "@debug"],
        ["Number of Recompiles", "15", "Uygulama yeniden başlatılmadan önce yapılabilecek dinamik yeniden derleme sayısı. Aşılınca AppDomain yeniden başlatılır.", "@numRecompilesBeforeAppRestart"],
        ["Url Line Pragmas", "False", "Derleyici hata satırlarını fiziksel yol yerine URL ile göstersin mi.", "@urlLinePragmas"],
        ["Visual Basic Explicit", "True", "VB kodunda değişkenlerin açıkça tanımlanmasını zorunlu kılar (Option Explicit).", "@explicit"],
        ["Visual Basic Strict", "False", "VB için Option Strict; örtük tür dönüşümlerini yasaklar.", "@strict"]] },
      { cat: "General", props: [
        ["Default Language", "vb", "Sayfada dil belirtilmemişse kullanılacak varsayılan derleme dili (vb veya c#).", "@defaultLanguage"],
        ["Target Framework", "4.8", "Uygulamanın hedeflediği .NET Framework sürümü.", "@targetFramework"],
        ["Temporary Directory", "", "Derlenmiş dosyaların yazılacağı geçici klasör. Boş ise 'Temporary ASP.NET Files' kullanılır.", "@tempDirectory"]] }
    ], acts: [A.apply, A.cancel] },

  { id: "neterr", n: ".NET Error Pages", g: "ASP.NET", ic: "⚠️", lv: "all",
    d: "ASP.NET'in özel hata sayfalarıdır (<system.web><customErrors>). Bir ASP.NET hatası veya belirli bir HTTP durum kodu oluştuğunda kullanıcıya gösterilecek sayfayı belirler. IIS seviyesindeki 'Error Pages' ile karıştırmayın; o tüm istekler için geçerlidir.",
    cfg: "system.web/customErrors",
    list: { cols: [["Status Code", "Yakalanacak HTTP durum kodu (ör. 404, 500)."], ["Redirect", "Hata oluştuğunda yönlendirilecek URL."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("404 hatasında NotFound.aspx sayfasına yönlendirme örneği.", "404", "~/Errors/NotFound.aspx", "Local"), r("500 hatası için genel hata sayfası.", "500", "~/Errors/Error.aspx", "Local")] },
    acts: [A.add(), A.edit(), A.remove(), ["Edit Feature Settings...", "⚙️", "Mode: On (herkese özel sayfa), Off (herkese detaylı ASP.NET hatası – GÜVENSİZ), RemoteOnly (uzak kullanıcılara özel sayfa, sunucunun kendisinde detaylı hata – önerilen varsayılan). Ayrıca Default Page ve Redirect Mode (ResponseRedirect / ResponseRewrite) seçilir."]] },

  { id: "netglob", n: ".NET Globalization", g: "ASP.NET", ic: "🌍", lv: "all",
    d: "Uygulamanın kültür (dil/bölge) ve karakter kodlaması ayarlarıdır (<system.web><globalization>). Tarih, sayı ve para birimi biçimlendirmesini ve istek/yanıt kodlamasını etkiler.",
    cfg: "system.web/globalization",
    grid: [
      { cat: "Culture", props: [
        ["Culture", "Invariant Language (Invariant Country)", "Tarih, sayı, para biçimlendirmesi için kullanılacak kültür. Ör. tr-TR seçilirse 1.234,56 ve 18.11.2026 biçimi kullanılır. 'auto' tarayıcının Accept-Language başlığına göre seçer.", "@culture"],
        ["Enable Client Based Culture", "False", "True ise kültür, tarayıcının dil tercihine göre otomatik belirlenir (culture=\"auto\").", "@enableClientBasedCulture"],
        ["UI Culture", "Invariant Language (Invariant Country)", "Kaynak (.resx) dosyalarından hangi dildeki metinlerin yükleneceğini belirler.", "@uiCulture"]] },
      { cat: "Encoding", props: [
        ["File", "Windows-1252", "Disk üzerindeki .aspx/.ascx dosyalarının okunacağı kodlama. Türkçe karakter sorunlarında utf-8 yapılmalıdır.", "@fileEncoding"],
        ["Requests", "utf-8", "Gelen isteklerin (form verisi, sorgu dizesi) kodlaması.", "@requestEncoding"],
        ["Response Headers", "utf-8", "Yanıt başlıklarının kodlaması.", "@responseHeaderEncoding"],
        ["Responses", "utf-8", "Yanıt gövdesinin kodlaması (Content-Type charset).", "@responseEncoding"]] }
    ], acts: [A.apply, A.cancel] },

  { id: "netprof", n: ".NET Profile", g: "ASP.NET", ic: "👤", lv: "site",
    d: "ASP.NET Profile özelliğinin özelliklerini tanımlar (<system.web><profile>). Kullanıcıya özel verileri (tema tercihi, dil vb.) bir sağlayıcı (genellikle SQL) aracılığıyla saklamak için kullanılır.",
    cfg: "system.web/profile",
    list: { cols: [["Name", "Profil özelliğinin adı (kodda Profile.TercihEdilenTema olarak erişilir)."], ["Data Type", "Özelliğin .NET veri türü."], ["Default Value", "Değer atanmamışsa kullanılacak varsayılan."], ["Read Only", "Özellik salt okunur mu."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Kullanıcının tercih ettiği temayı saklayan örnek profil özelliği.", "PreferredTheme", "System.String", "Light", "False", "Local")] },
    acts: [["Add Property...", "➕", "Yeni profil özelliği ekler."], ["Add Group...", "📁", "Özellikleri gruplamak için bir profil grubu ekler."], A.remove(), A.feat] },

  { id: "netroles", n: ".NET Roles", g: "ASP.NET", ic: "👥", lv: "site",
    d: "ASP.NET Role Manager ile tanımlanan rolleri (grupları) yönetir. Roller, .NET Authorization Rules içinde kullanılarak yetkilendirme yapılır. Kullanılabilmesi için varsayılan bir rol sağlayıcısı (Providers) ayarlanmış olmalıdır.",
    cfg: "system.web/roleManager",
    list: { cols: [["Name", "Rolün adı."], ["Users", "Bu roldeki kullanıcı sayısı."]],
      rows: [r("Örnek rol: yöneticiler.", "Admins", "2"), r("Örnek rol: editörler.", "Editors", "5")] },
    acts: [["Add...", "➕", "Yeni rol ekler."], ["Rename", "✏️", "Rolü yeniden adlandırır."], A.remove(), ["Set Default Provider...", "⚙️", "Rollerin saklanacağı varsayılan sağlayıcıyı (AspNetSqlRoleProvider, AspNetWindowsTokenRoleProvider vb.) seçer."], ["Disable", "⛔", "Role Manager özelliğini devre dışı bırakır (enabled=false)."]] },

  { id: "nettrust", n: ".NET Trust Levels", g: "ASP.NET", ic: "🔏", lv: "all",
    d: "ASP.NET uygulamasının Code Access Security (CAS) güven düzeyini belirler (<system.web><trust>). Paylaşımlı barındırmada uygulamaların dosya sistemi, kayıt defteri, ağ gibi kaynaklara erişimini kısıtlamak için kullanılırdı. .NET 4 ve sonrasında Medium Trust artık güvenlik sınırı olarak önerilmemektedir; yalıtım için ayrı havuz kullanın.",
    cfg: "system.web/trust",
    form: [{ sec: "Trust level", f: [
      s("Trust level", "Full (internal)", ["Full (internal)", "High (web_hightrust.config)", "Medium (web_mediumtrust.config)", "Low (web_lowtrust.config)", "Minimal (web_minimaltrust.config)"], "Full: kısıtlama yok (varsayılan). High/Medium/Low/Minimal: sırasıyla artan kısıtlamalar. Ör. Medium trust'ta uygulama yalnızca kendi klasörüne yazabilir, kayıt defterine erişemez."),
      c("Process identity for impersonation", false, "Kimliğe bürünme (impersonation) kullanılırken CAS kontrolleri için süreç kimliğinin kullanılıp kullanılmayacağı.")] }],
    acts: [A.apply, A.cancel] },

  { id: "netusers", n: ".NET Users", g: "ASP.NET", ic: "🧑‍💻", lv: "site",
    d: "ASP.NET Membership sağlayıcısı ile saklanan kullanıcıları (Forms kimlik doğrulama kullanıcıları) yönetir. Windows kullanıcıları DEĞİLDİR; genellikle bir SQL veritabanında (aspnetdb) tutulurlar.",
    cfg: "system.web/membership",
    list: { cols: [["Name", "Kullanıcı adı."], ["E-mail", "Kullanıcının e-posta adresi."], ["Created", "Hesabın oluşturulma tarihi."], ["Last Logon", "Son başarılı oturum açma zamanı."]],
      rows: [r("Örnek Membership kullanıcısı.", "ayse", "ayse@firma.com", "02.03.2026", "17.11.2026 14:22")] },
    acts: [["Add...", "➕", "Yeni Membership kullanıcısı ekler (ad, e-posta, parola, güvenlik sorusu)."], A.edit(), A.remove(), ["Set Default Provider...", "⚙️", "Kullanıcıların saklanacağı varsayılan Membership sağlayıcısını seçer."]] },

  { id: "appset", n: "Application Settings", g: "ASP.NET", ic: "🔑", lv: "all",
    d: "web.config içindeki <appSettings> anahtar/değer çiftleridir. Uygulama kodu bu değerleri ConfigurationManager.AppSettings[\"Anahtar\"] ile okur. Ortama göre değişen ayarlar (API adresi, özellik bayrakları) için kullanılır.",
    cfg: "appSettings",
    list: { cols: [["Name", "Ayarın anahtarı (kodda okunurken kullanılır)."], ["Value", "Ayarın değeri (her zaman metin olarak saklanır)."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek: Uygulamanın çağırdığı servis adresi.", "ApiBaseUrl", "https://api.firma.local/", "Local"), r("Örnek: Özellik bayrağı.", "EnableNewCheckout", "true", "Local"), r("ASP.NET'in kendi ayarı: Doğrulamasız (unobtrusive) istemci doğrulamasını açar.", "UnobtrusiveJavaScriptEnabled", "true", "Local")] },
    acts: [A.add(), A.edit(), A.remove()] },

  { id: "connstr", n: "Connection Strings", g: "ASP.NET", ic: "🗄️", lv: "all",
    d: "Veritabanı bağlantı dizelerini yönetir (<connectionStrings>). Kod ConfigurationManager.ConnectionStrings[\"Ad\"] ile okur. Parola içeren bağlantı dizelerini korumak için aspnet_regiis -pe ile şifreleme yapılabilir veya Windows (Integrated Security) kimlik doğrulaması tercih edilmelidir.",
    cfg: "connectionStrings",
    list: { cols: [["Name", "Bağlantı dizesinin adı."], ["Connection String", "Sunucu, veritabanı ve kimlik bilgilerini içeren dize."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Machine.config'den miras gelen varsayılan SQL Express bağlantısı (ASP.NET Membership için).", "LocalSqlServer", "data source=.\\SQLEXPRESS;Integrated Security=SSPI;...", "Inherited"), r("Örnek uygulama veritabanı bağlantısı. Integrated Security=SSPI olduğundan havuz kimliğiyle bağlanır.", "AppDb", "Server=SQL01;Database=Shop;Integrated Security=SSPI", "Local")] },
    acts: [A.add(), A.edit(), A.remove()] },

  { id: "machkey", n: "Machine Key", g: "ASP.NET", ic: "🗝️", lv: "all",
    d: "ASP.NET'in ViewState, Forms Authentication bileti, anti-forgery token gibi verileri şifrelemek ve imzalamak için kullandığı anahtarlardır (<system.web><machineKey>). Web çiftliğinde (birden fazla sunucu / yük dengeleyici) TÜM sunucularda AYNI anahtar elle ayarlanmalıdır; aksi halde 'Validation of viewstate MAC failed' hataları ve oturum düşmeleri yaşanır.",
    cfg: "system.web/machineKey",
    form: [
      { sec: "Encryption method", f: [
        s("Encryption method", "HMACSHA256", ["MD5", "SHA1", "3DES", "AES", "HMACSHA256", "HMACSHA384", "HMACSHA512"], "Verilerin bütünlüğünü doğrulamak (imzalamak) için kullanılan algoritma (validation). HMACSHA256 veya üstü önerilir."),
        s("Decryption method", "Auto", ["Auto", "DES", "3DES", "AES"], "Verilerin şifrelenmesi için kullanılan algoritma. Auto genellikle AES kullanır.")] },
      { sec: "Validation key", f: [
        c("Automatically generate at runtime", true, "Anahtar çalışma zamanında otomatik üretilir. Tek sunucu için uygundur; web çiftliğinde kapatılmalıdır."),
        c("Generate a unique key for each application", true, "Her uygulama için farklı anahtar türetilir (IsolateApps)."),
        t("Validation key", "", "Elle anahtar girmek için. Sağdaki 'Generate Keys' eylemi rastgele anahtar üretir.")] },
      { sec: "Decryption key", f: [
        c("Automatically generate at runtime", true, "Şifreleme anahtarını otomatik üretir."),
        c("Generate a unique key for each application", true, "Her uygulama için ayrı şifreleme anahtarı."),
        t("Decryption key", "", "Elle şifreleme anahtarı girmek için.")] }],
    acts: [A.apply, A.cancel, ["Generate Keys", "🎲", "Rastgele, güçlü Validation ve Decryption anahtarları üretir. Web çiftliğinde bu anahtarları tüm sunuculara kopyalayın."]] },

  { id: "pages", n: "Pages and Controls", g: "ASP.NET", ic: "📄", lv: "all",
    d: "ASP.NET Web Forms sayfalarının ve kontrollerinin varsayılan davranışlarını ayarlar (<system.web><pages>): ViewState, tema, ana sayfa (master page), oturum durumu, istek doğrulama vb. Ayrıca kayıtlı özel kontrolleri (register controls) yönetir.",
    cfg: "system.web/pages",
    form: [
      { sec: "Behavior", f: [
        c("Buffer", true, "Sayfa çıktısı tamamlanana kadar yanıt arabelleğe alınır."),
        c("Enable View State", true, "Sayfa durumunun gizli __VIEWSTATE alanında saklanıp saklanmayacağı. Kapatmak sayfa boyutunu küçültür ancak bazı kontroller çalışmaz."),
        c("Enable Authenticated View State", true, "ViewState'in Machine Key ile imzalanmasını (MAC) sağlar. GÜVENLİK İÇİN KAPATILMAMALIDIR."),
        c("Validate Request", true, "Formlarda ve sorgu dizesinde <script> gibi tehlikeli girdileri algılayıp reddeder (XSS koruması)."),
        s("Enable Session State", "True", ["True", "ReadOnly", "False"], "Sayfaların oturum durumuna erişimi. ReadOnly, oturum kilitlenmesini azaltır.")] },
      { sec: "General", f: [
        t("Master Page File", "", "Sayfalara varsayılan olarak uygulanacak ana sayfa (.master)."),
        t("Theme", "", "Uygulamaya uygulanacak varsayılan App_Themes teması."),
        t("Style Sheet Theme", "", "Sayfa öğelerinde geçersiz kılınabilen stil teması."),
        t("Base Type for Pages", "System.Web.UI.Page", "Sayfaların türetileceği temel sınıf."),
        t("Base Type for User Controls", "System.Web.UI.UserControl", "Kullanıcı kontrollerinin temel sınıfı.")] }],
    acts: [A.apply, A.cancel, ["Register Controls", "🧩", "Sayfalarda <%@ Register %> yazmadan kullanılabilecek özel kontrolleri ve etiket önekini kaydeder."]] },

  { id: "providers", n: "Providers", g: "ASP.NET", ic: "🔌", lv: "all",
    d: "ASP.NET Membership (.NET Users), Roles (.NET Roles) ve Profile özelliklerinin verileri nereden okuyacağını belirleyen sağlayıcıları yönetir. Ör. SqlMembershipProvider verileri SQL Server'da saklar.",
    cfg: "system.web/membership/providers",
    list: { cols: [["Name", "Sağlayıcının adı."], ["Type", "Sağlayıcı sınıfı."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("machine.config'den gelen varsayılan SQL Membership sağlayıcısı (LocalSqlServer bağlantısını kullanır).", "AspNetSqlMembershipProvider", "SqlMembershipProvider", "Inherited")] },
    acts: [["Feature: .NET Users / .NET Roles / .NET Profile", "🔽", "Sayfanın üst kısmındaki açılır listeden hangi özelliğin sağlayıcılarını görüntülediğinizi seçersiniz."], A.add(), A.edit(), ["Rename", "✏️", "Sağlayıcıyı yeniden adlandırır."], A.remove()] },

  { id: "session", n: "Session State", g: "ASP.NET", ic: "🧾", lv: "all",
    d: "ASP.NET oturum durumunun (Session[\"...\"]) nerede saklanacağını ve oturum kimliği çerezinin nasıl yönetileceğini ayarlar (<system.web><sessionState>).",
    cfg: "system.web/sessionState",
    form: [
      { sec: "Session State Mode Settings", f: [
        rd("Session state mode", "In process", [
          ["Not enabled", "Oturum durumu tamamen kapalı."],
          ["In process", "Oturum verisi w3wp.exe belleğinde tutulur. EN HIZLI ama havuz geri dönüşümünde/yeniden başlatmada veya web garden/web çiftliğinde KAYBOLUR."],
          ["Custom", "Özel bir oturum sağlayıcısı (ör. Redis Session State Provider) kullanılır."],
          ["State Server", "Oturumlar ayrı bir Windows hizmetinde (ASP.NET State Service, port 42424) tutulur. Havuz geri dönüşümünden etkilenmez; birden fazla sunucu paylaşabilir."],
          ["SQL Server", "Oturumlar SQL Server veritabanında tutulur (aspnet_regsql ile hazırlanır). En dayanıklı ancak en yavaş seçenektir."]], "Oturum verisinin saklanacağı yer."),
        t("Connection string (State Server / SQL)", "tcpip=loopback:42424", "State Server veya SQL Server modunda bağlantı bilgisi."),
        t("Time-out (in seconds)", "10", "State Server / SQL sunucusuna bağlantı zaman aşımı.")] },
      { sec: "Cookie Settings", f: [
        s("Mode", "Use Cookies", ["Auto Detect", "Use Cookies", "Use Device Profile", "Use URI"], "Oturum kimliğinin istemcide nasıl taşınacağı. Use URI (cookieless) oturum kimliğini URL'ye ekler – güvenlik açısından ÖNERİLMEZ."),
        t("Name", "ASP.NET_SessionId", "Oturum çerezinin adı."),
        t("Time-out (in minutes)", "20", "Kullanıcıdan istek gelmezse oturumun kaç dakika sonra sona ereceği."),
        c("Regenerate expired session ID", true, "Süresi dolmuş bir oturum kimliği geldiğinde yeni kimlik üretilir.")] },
      { sec: "", f: [c("Use hosting identity for impersonation", true, "State/SQL sunucusuna bağlanırken kimliğe bürünülen kullanıcı yerine süreç kimliği kullanılır.")] }],
    acts: [A.apply, A.cancel] },

  { id: "smtp", n: "SMTP E-mail", g: "ASP.NET", ic: "✉️", lv: "all",
    d: "ASP.NET uygulamalarının System.Net.Mail.SmtpClient ile e-posta gönderirken kullanacağı varsayılan SMTP ayarlarıdır (<system.net><mailSettings>). Kodda sunucu belirtilmezse bu değerler kullanılır.",
    cfg: "system.net/mailSettings/smtp",
    form: [{ sec: "", f: [
      t("E-mail address", "noreply@firma.com", "Gönderen (From) adresi."),
      rd("Delivery method", "Deliver e-mail to SMTP server", [["Deliver e-mail to SMTP server", "E-postalar belirtilen SMTP sunucusuna gönderilir."], ["Store e-mail in pickup directory", "E-postalar .eml dosyası olarak bir klasöre yazılır (test ortamı veya yerel SMTP hizmeti için)."]], "E-postanın nasıl teslim edileceği."),
      t("SMTP Server", "smtp.firma.com", "SMTP sunucu adresi."),
      c("Use localhost", false, "Yerel makinedeki SMTP hizmetini kullanır."),
      t("Port", "25", "SMTP portu. TLS için genellikle 587 kullanılır."),
      rd("Authentication Settings", "Not required", [["Not required", "Kimlik doğrulama yok."], ["Basic", "Kullanıcı adı ve parola ile kimlik doğrulama."], ["Windows", "Süreç kimliği ile Windows kimlik doğrulaması."]], "SMTP sunucusuna kimlik doğrulama yöntemi.")] }],
    acts: [A.apply, A.cancel] },


  /* ===================== FTP ===================== */
  { id: "ftpauth", n: "FTP Authentication", g: "FTP", ic: "🔐", lv: "server",
    d: "FTP kullanıcılarının kimliğinin nasıl doğrulanacağını belirler. Web sitesi kimlik doğrulamasından tamamen ayrıdır. Anonymous (anonim) ve Basic (Windows kullanıcı adı/parola) yerleşik yöntemlerdir; Custom Providers ile IIS Manager kullanıcıları, ASP.NET Membership veya özel sağlayıcılar eklenebilir. DİKKAT: Basic FTP kimlik doğrulamasında parola düz metin gider; FTP SSL Settings ile FTPS zorunlu kılınmalıdır.",
    cfg: "system.ftpServer/security/authentication",
    list: { cols: [["Name", "Kimlik doğrulama yöntemi."], ["Status", "Enabled / Disabled."], ["Type", "Built-In (yerleşik) veya Custom (özel sağlayıcı)."]],
      rows: [r("Anonim FTP: kullanıcı adı 'anonymous' ile parola sormadan giriş. Herkese açık indirme sunucuları içindir; yazma izni ASLA verilmemelidir.", "Anonymous Authentication", "Disabled", "Built-In"),
             r("Windows (yerel veya domain) hesaplarıyla giriş. Kullanıcının FTP klasöründe NTFS izni de olmalıdır.", "Basic Authentication", "Enabled", "Built-In"),
             r("IIS Manager kullanıcılarıyla (Windows hesabı olmadan) FTP girişi. Management Service ayarlarında IIS Manager credentials izinli olmalıdır.", "IisManagerAuth", "Disabled", "Custom")] },
    acts: [["Enable", "✅", "Seçili yöntemi etkinleştirir."], ["Disable", "⛔", "Seçili yöntemi devre dışı bırakır."], ["Edit...", "📝", "Anonymous için kullanılacak hesap (varsayılan IUSR), Basic için varsayılan domain gibi ayarları düzenler."], ["Custom Providers...", "🧩", "Özel kimlik doğrulama sağlayıcılarını (IisManagerAuth, AspNetAuth veya kendi yazdığınız .NET sağlayıcı) ekler/etkinleştirir. FTP Extensibility rol hizmeti gerekir."]] },

  { id: "ftpauthz", n: "FTP Authorization Rules", g: "FTP", ic: "🚦", lv: "server",
    d: "Kimliği doğrulanmış FTP kullanıcılarının hangi klasörlerde Read (indirme/listeleme) ve Write (yükleme/silme) yapabileceğini belirler. Yetkilendirme kuralı ile NTFS izni birlikte değerlendirilir; ikisinin de izin vermesi gerekir.",
    cfg: "system.ftpServer/security/authorization",
    list: { cols: [["Mode", "Allow veya Deny."], ["Users", "Kullanıcılar: * (herkes), ? (anonim) veya belirli kullanıcılar."], ["Roles", "Windows grupları."], ["Permissions", "Read, Write veya Read, Write."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek: Web geliştiricileri grubuna okuma ve yazma izni.", "Allow", "", "FIRMA\\WebDevs", "Read, Write", "Local")] },
    acts: [A.add("Allow Rule"), A.add("Deny Rule"), A.edit(), A.remove()] },

  { id: "ftpdir", n: "FTP Directory Browsing", g: "FTP", ic: "🗂️", lv: "server",
    d: "FTP istemcilerine gönderilen klasör listesinin biçimini belirler (LIST komutunun çıktısı).",
    cfg: "system.ftpServer/directoryBrowse",
    form: [
      { sec: "Directory Listing Style", f: [rd("Directory listing style", "MS-DOS", [["MS-DOS", "Windows/DOS tarzı liste: 11-18-26  02:15PM  <DIR>  klasor"], ["UNIX", "UNIX tarzı liste: drwxrwxrwx 1 owner group 0 Nov 18 14:15 klasor. Bazı FTP istemcileri (eski Linux araçları) bu biçimi daha iyi ayrıştırır."]], "Listeleme biçimi.")] },
      { sec: "Directory Listing Options", f: [
        c("Virtual directories", false, "Sanal dizinleri de listede gösterir. Kapalıysa sanal dizinler vardır ama listede görünmez (adını bilen girebilir)."),
        c("Available bytes", false, "Diskte kullanılabilir boş alanı gösterir (disk kotası varsa kota kalanını)."),
        c("Four-digit years", false, "Tarihleri 4 haneli yıl ile gösterir (2026).")] }],
    acts: [A.apply, A.cancel] },

  { id: "ftpfw", n: "FTP Firewall Support", g: "FTP", ic: "🧱", lv: "server",
    d: "Pasif mod FTP'nin güvenlik duvarı / NAT arkasında çalışabilmesi için gerekli ayarlar. FTP iki kanal kullanır: kontrol kanalı (port 21) ve veri kanalı. Pasif modda veri kanalı için sunucu rastgele bir port açar; bu port aralığının güvenlik duvarında açık olması gerekir. 'Listeleme yapılamıyor / 425 Can't open data connection' hatalarının ana sebebi burasıdır.",
    cfg: "system.ftpServer/firewallSupport",
    form: [{ sec: "", f: [
      t("Data Channel Port Range", "50000-50100", "Pasif modda veri kanalı için kullanılacak port aralığı. 0-0 = Windows dinamik portları (49152-65535). Aralık güvenlik duvarında açılmalıdır. Değişiklikten sonra Microsoft FTP Service yeniden başlatılmalıdır."),
      t("External IP Address of Firewall", "203.0.113.10", "Sunucu NAT arkasındaysa istemciye PASV yanıtında bildirilecek dış (public) IP. Boş bırakılırsa sunucunun iç IP'si bildirilir ve dışarıdan bağlanan istemciler veri kanalını açamaz.")] }],
    acts: [A.apply, A.cancel] },

  { id: "ftpip", n: "FTP IP Address and Domain Restrictions", g: "FTP", ic: "🚫", lv: "server",
    d: "FTP sunucusuna bağlanabilecek istemci IP adreslerini veya domain adlarını kısıtlar. Ör. FTP'ye yalnızca ofis IP'sinden veya yalnızca bir iş ortağının IP aralığından erişim.",
    cfg: "system.ftpServer/security/ipSecurity",
    list: { cols: [["Mode", "Allow veya Deny."], ["Requestor", "IP adresi veya aralığı."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek: iş ortağının IP aralığına izin.", "Allow", "198.51.100.0 (255.255.255.0)", "Local")] },
    acts: [A.add("Allow Entry"), A.add("Deny Entry"), A.remove(), ["Edit Feature Settings...", "⚙️", "Listede olmayan istemcilerin erişimi (Allow/Deny) ve domain adına göre kısıtlamanın etkinleştirilmesi."], ["View Ordered List...", "📋", "Kuralları sırasıyla gösterir."]] },

  { id: "ftplog", n: "FTP Logging", g: "FTP", ic: "📒", lv: "server",
    d: "FTP oturumlarının ve komutlarının (USER, PASS, STOR, RETR, DELE...) günlüğe yazılmasını ayarlar. Varsayılan klasör: %SystemDrive%\\inetpub\\logs\\LogFiles\\FTPSVC<ID>. Kim hangi dosyayı yükledi/sildi sorusunun yanıtı burada bulunur.",
    cfg: "system.ftpServer/log",
    form: [
      { sec: "One log file per", f: [s("One log file per", "Site", ["Server", "Site"], "Tüm FTP siteleri için tek günlük mü, her site için ayrı mı.")] },
      { sec: "Log File", f: [["b", "Select W3C Fields...", "", "Yazılacak alanlar: date, time, c-ip, cs-username, s-ip, s-port, cs-method (FTP komutu), cs-uri-stem (dosya), sc-status (FTP durum kodu: 226 başarılı, 530 giriş başarısız, 550 dosya yok/izin yok), sc-win32-status, x-session (oturum kimliği)."], t("Directory", "%SystemDrive%\\inetpub\\logs\\LogFiles", "Günlük klasörü."), s("Encoding", "UTF-8", ["UTF-8", "ANSI"], "Kodlama.")] },
      { sec: "Log File Rollover", f: [rd("Schedule", "Daily", [["Hourly", "Saatlik."], ["Daily", "Günlük."], ["Weekly", "Haftalık."], ["Monthly", "Aylık."]], "Yeni dosyaya geçiş zamanlaması."), c("Use local time for file naming and rollover", false, "İşaretsizse UTC kullanılır.")] }],
    acts: [A.apply, A.cancel, ["Disable", "⛔", "FTP günlüğünü kapatır."]] },

  { id: "ftplogon", n: "FTP Logon Attempt Restrictions", g: "FTP", ic: "⏳", lv: "server",
    d: "Kaba kuvvet (brute-force) parola saldırılarına karşı koruma. Belirli bir süre içinde çok sayıda başarısız giriş yapan IP adresini otomatik olarak engeller. İnternete açık her FTP sunucusunda etkinleştirilmesi önerilir.",
    cfg: "system.ftpServer/security/authentication/denyByFailure",
    form: [{ sec: "", f: [
      rd("Logon attempt restrictions", "Enable", [["Disable", "Koruma kapalı."], ["Enable", "Sınır aşıldığında IP engellenir (bağlantı reddedilir)."], ["Write to the log only", "Engellemez, yalnızca günlüğe yazar – önce etkisini görmek için test modu."]], "Koruma modu."),
      t("Maximum number of failed login attempts", "4", "Belirtilen süre içinde izin verilen en fazla başarısız giriş."),
      t("Time period (in seconds)", "30", "Başarısız girişlerin sayıldığı zaman penceresi. Engelleme bu süre kadar sürer.")] }],
    acts: [A.apply, A.cancel] },

  { id: "ftpmsg", n: "FTP Messages", g: "FTP", ic: "💬", lv: "server",
    d: "FTP istemcisine gösterilen karşılama, çıkış ve hata mesajlarını özelleştirir. Varsayılan banner 'Microsoft FTP Service' bilgisini içerir; güvenlik için gizlenmesi önerilir.",
    cfg: "system.ftpServer/messages",
    form: [
      { sec: "Message Behavior", f: [
        c("Suppress default banner", true, "Bağlantıda gösterilen '220 Microsoft FTP Service' sunucu tanıtım satırını gizler (sunucu yazılımını ifşa etmez)."),
        c("Support user variables in messages", false, "Mesajlarda %UserName%, %BytesSent%, %SessionID% gibi değişkenlerin kullanılmasına izin verir."),
        c("Show detailed messages for local requests", false, "Sunucunun kendisinden bağlanılınca ayrıntılı hata mesajları gösterir.")] },
      { sec: "Message Text", f: [
        t("Banner", "Yetkisiz erişim yasaktır.", "Kullanıcı giriş yapmadan önce gösterilen mesaj."),
        t("Welcome", "Hoş geldiniz %UserName%", "Başarılı girişten sonra gösterilen mesaj."),
        t("Exit", "Güle güle", "Oturum kapanırken gösterilen mesaj."),
        t("Maximum connections", "Sunucu meşgul, lütfen daha sonra deneyin.", "Eşzamanlı bağlantı sınırına ulaşıldığında gösterilen mesaj.")] }],
    acts: [A.apply, A.cancel] },

  { id: "ftpreq", n: "FTP Request Filtering", g: "FTP", ic: "🧹", lv: "server",
    d: "FTP için güvenlik filtresi: belirli dosya uzantılarının yüklenmesini/indirilmesini, gizli klasörleri, URL dizelerini ve FTP komutlarını engeller. Ör. FTP ile .exe veya .config dosyası yüklenmesini engellemek.",
    cfg: "system.ftpServer/security/requestFiltering",
    list: { cols: [["File Name Extension", "Uzantı. Diğer sekmeler: Hidden Segments, Denied URL Sequences, Commands."], ["Allowed", "True: izin, False: engelle."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek: yürütülebilir dosya yüklenmesini engelle.", ".exe", "False", "Local"), r("Örnek: yapılandırma dosyalarını engelle.", ".config", "False", "Local")] },
    acts: [["Allow File Name Extension...", "✅", "Bir uzantıya izin verir."], ["Deny File Name Extension...", "⛔", "Bir uzantıyı engeller."], A.remove(), ["Edit Feature Settings...", "⚙️", "Allow unlisted file name extensions, allow unlisted commands, allow high-bit characters ve request limits (en büyük içerik uzunluğu, en uzun URL, en uzun komut)."]] },

  { id: "ftpssl", n: "FTP SSL Settings", g: "FTP", ic: "🔒", lv: "server",
    d: "FTPS (FTP over SSL/TLS) ayarları. FTP varsayılan olarak kullanıcı adı, parola ve dosyaları ŞİFRESİZ gönderir. Burada sertifika seçip SSL'i zorunlu kılarak kontrol ve veri kanallarını şifrelersiniz. (SFTP farklı bir protokoldür – SSH tabanlıdır – ve IIS tarafından desteklenmez.)",
    cfg: "ftpServer/security/ssl",
    form: [{ sec: "", f: [
      s("SSL Certificate", "intranet-2026", ["Not Selected", "intranet-2026", "shop-wildcard", "WMSvc-SHA2-WIN-IIS01"], "FTPS için kullanılacak sertifika (Server Certificates'ta yüklü olmalı)."),
      rd("SSL Policy", "Require SSL connections", [["Allow SSL connections", "İstemci isterse SSL kullanılır, istemezse şifresiz bağlantıya da izin verilir."], ["Require SSL connections", "Tüm bağlantılarda SSL zorunludur (önerilen)."], ["Custom", "Kontrol kanalı ve veri kanalı için ayrı ayrı ilke (Advanced...): ör. yalnızca kimlik bilgileri şifrelensin."]], "SSL kullanım ilkesi."),
      ["b", "Advanced...", "", "Custom ilkede kontrol kanalı (Allow / Require / Require only for credentials / Deny) ve veri kanalı (Allow / Require / Deny) ayarları."],
      c("Use 128-bit encryption for SSL connections", false, "SSL bağlantılarında en az 128 bit şifreleme zorunlu olur.")] }],
    acts: [A.apply, A.cancel] },

  { id: "ftpiso", n: "FTP User Isolation", g: "FTP", ic: "👤", lv: "server",
    d: "Her FTP kullanıcısının giriş yaptığında hangi klasörde başlayacağını ve diğer kullanıcıların klasörlerini görüp göremeyeceğini belirler. Çok müşterili (hosting) senaryolarda kullanıcıların birbirinin dosyalarına erişmesini engeller.",
    cfg: "system.applicationHost/sites/site/ftpServer/userIsolation",
    form: [{ sec: "", f: [
      rd("Do not isolate users. Start users in:", "FTP root directory", [["FTP root directory", "Tüm kullanıcılar FTP sitesinin kök klasöründe başlar; izinler dahilinde her yeri gezebilir."], ["User name directory", "Kullanıcı adıyla aynı klasör varsa orada başlar, yoksa kökte. Yalıtım YOKTUR, üst klasöre çıkabilir."]], "Yalıtımsız modlar."),
      rd("Isolate users. Restrict users to the following directory:", "", [["User name directory (disable global virtual directories)", "Kullanıcı yalnızca kendi klasörünü görür: LocalUser\\<kullanıcı> (yerel hesap), <Domain>\\<kullanıcı> (domain hesabı), LocalUser\\Public (anonim). Genel sanal dizinler erişilemez."], ["User name physical directory (enable global virtual directories)", "Yukarıdakiyle aynı ama FTP sitesi düzeyindeki sanal dizinler tüm kullanıcılara görünür."], ["FTP home directory configured in Active Directory", "Kullanıcının ev klasörü AD'deki msIIS-FTPRoot ve msIIS-FTPDir özniteliklerinden okunur."]], "Yalıtımlı modlar.")] }],
    acts: [A.apply, A.cancel] },

  /* ===================== IIS ===================== */
  { id: "asp", n: "ASP", g: "IIS", ic: "📜", lv: "all",
    d: "Klasik ASP (Active Server Pages, .asp – VBScript) uygulamalarının ayarlarıdır (<system.webServer><asp>). ASP.NET ile ilgisi yoktur. Eski uygulamalar için hata ayıklama, oturum, önbellek ve limit ayarlarını içerir.",
    cfg: "system.webServer/asp",
    grid: [
      { cat: "Behavior", props: [
        ["Code Page", "0", "Dinamik içerik için varsayılan kod sayfası. 0 = sistem varsayılanı. Türkçe için 1254, UTF-8 için 65001.", "@codePage"],
        ["Enable Buffering", "True", "ASP çıktısının tamamı hazırlanana kadar arabelleğe alınması.", "@bufferingOn"],
        ["Enable Chunked Encoding", "True", "HTTP 1.1 chunked transfer kodlamasının kullanılması.", "@enableChunkedEncoding"],
        ["Enable HTML Fallback", "True", "İstek kuyruğu doluysa aynı adlı _asp.htm statik dosyasının gösterilmesi.", "@enableAspHtmlFallback"],
        ["Enable Parent Paths", "False", "include dosyalarında '../' kullanımına izin verir. Güvenlik nedeniyle varsayılan kapalıdır; eski uygulamalarda sık 'ASP 0131' hatasının sebebidir.", "@enableParentPaths"],
        ["Locale ID", "0", "Tarih/sayı biçimi için yerel ayar (LCID). Türkçe için 1055.", "@lcid"],
        ["Restart On Config Change", "True", "Yapılandırma değişince ASP uygulamasının yeniden başlatılması.", "limits/@..."]] },
      { cat: "Limits Properties", props: [
        ["Client Connection Test Interval", "00:00:03", "Kuyrukta bekleyen isteğin istemcisinin hâlâ bağlı olup olmadığının kontrol aralığı.", "limits/@queueConnectionTestTime"],
        ["Maximum Requesting Entity Body Limit", "200000", "ASP isteğinin gövdesinin en büyük boyutu (bayt). Büyük dosya yüklemelerinde 'Request object error ASP 0104' alınıyorsa artırılır.", "limits/@maxRequestEntityAllowed"],
        ["Queue Length", "3000", "ASP isteği kuyruğunun en fazla uzunluğu.", "limits/@requestQueueMax"],
        ["Response Buffering Limit", "4194304", "Yanıt arabelleğinin en büyük boyutu (bayt, varsayılan 4 MB). Büyük dosya indirmelerinde artırılabilir.", "limits/@bufferingLimit"],
        ["Script Time-out", "00:01:30", "Bir ASP betiğinin çalışabileceği en uzun süre.", "limits/@scriptTimeout"],
        ["Threads Per Processor Limit", "25", "İşlemci başına ASP iş parçacığı sayısı.", "limits/@processorThreadMax"]] },
      { cat: "Compilation – Debugging Properties", props: [
        ["Enable Client-side Debugging", "False", "İstemci tarafı hata ayıklamayı etkinleştirir.", "@appAllowClientDebug"],
        ["Enable Server-side Debugging", "False", "Sunucu tarafı ASP hata ayıklama. Üretimde kapalı olmalı – performansı düşürür (tek iş parçacığı).", "@appAllowDebugging"],
        ["Log Errors to NT Log", "False", "ASP hatalarının Windows olay günlüğüne yazılması.", "@logErrorRequests"],
        ["Send Errors To Browser", "False", "ASP hata ayrıntılarının (satır numarası, mesaj) tarayıcıya gönderilmesi. Geliştirmede faydalı, üretimde GÜVENLİK RİSKİ.", "@scriptErrorSentToBrowser"],
        ["Script Language", "VBScript", "Varsayılan betik dili.", "@scriptLanguage"]] },
      { cat: "Services – Session Properties", props: [
        ["Enable Session State", "True", "Klasik ASP oturum durumunu etkinleştirir.", "session/@allowSessionState"],
        ["Maximum Sessions", "4294967295", "Aynı anda en fazla oturum sayısı.", "session/@max"],
        ["Time-out", "00:20:00", "Oturum zaman aşımı.", "session/@timeout"]] },
      { cat: "Services – Caching Properties", props: [
        ["Cache Directory Path", "%SystemDrive%\\inetpub\\temp\\ASP Compiled Templates", "Derlenmiş ASP şablonlarının disk önbelleği klasörü.", "cache/@diskTemplateCacheDirectory"],
        ["Maximum Disk Cached Files", "2000", "Diskte önbelleklenecek en fazla derlenmiş dosya.", "cache/@maxDiskTemplateCacheFiles"],
        ["Script File Cache Size", "500", "Bellekte önbelleklenecek ASP dosyası sayısı.", "cache/@scriptFileCacheSize"]] }
    ], acts: [A.apply, A.cancel] },

  { id: "authc", n: "Authentication", g: "IIS", ic: "🔐", lv: "all",
    d: "İstemcinin KİM olduğunun nasıl doğrulanacağını belirler. Birden fazla yöntem aynı anda etkin olabilir. Bir yöntemi seçip sağdaki Enable/Disable ile açıp kapatırsınız. Not: Anonymous ve Windows Authentication aynı anda açıksa tarayıcı önce anonim dener; yetki yoksa Windows'a geçer.",
    cfg: "system.webServer/security/authentication",
    list: { cols: [["Name", "Kimlik doğrulama yöntemi."], ["Status", "Enabled / Disabled."], ["Response Type", "Kimlik doğrulama istenirken istemciye dönülen yanıt türü (ör. HTTP 401 Challenge = tarayıcı kullanıcı adı/parola penceresi açar)."]],
      rows: [
        r("Anonim Kimlik Doğrulama: kullanıcıdan kimlik istemez. İstekler IUSR hesabı ile veya (önerilen) 'Application pool identity' ile işlenir. Herkese açık siteler için açık olmalıdır. Edit ile hangi kimliğin kullanılacağı seçilir.", "Anonymous Authentication", "Enabled", ""),
        r("ASP.NET Kimliğe Bürünme: ASP.NET kodu, havuz kimliği yerine kimliği doğrulanmış kullanıcının (veya belirtilen bir hesabın) kimliğiyle çalışır. Integrated pipeline'da Windows auth ile kullanılırken validateIntegratedModeConfiguration hatalarına dikkat.", "ASP.NET Impersonation", "Disabled", ""),
        r("Temel Kimlik Doğrulama: kullanıcı adı/parola Base64 ile (ŞİFRESİZ) gönderilir. Yalnızca HTTPS ile kullanılmalıdır. Windows hesapları ile doğrulanır.", "Basic Authentication", "Disabled", "HTTP 401 Challenge"),
        r("İstemci Sertifikası Eşleme: Active Directory'deki hesaplarla eşleşen istemci sertifikaları ile kimlik doğrulama. SSL Settings'te 'Require' veya 'Accept' gerektirir.", "Client Certificate Mapping Authentication", "Disabled", ""),
        r("Digest (Özet) Kimlik Doğrulama: parolayı karma (hash) olarak gönderir. Bir domain denetleyicisi gerektirir. Günümüzde nadiren kullanılır.", "Digest Authentication", "Disabled", "HTTP 401 Challenge"),
        r("Forms Kimlik Doğrulama (ASP.NET): kimliği doğrulanmamış kullanıcıyı bir HTML giriş sayfasına (login.aspx) yönlendirir; başarılı girişte .ASPXAUTH çerezi verilir. Edit ile login URL ve çerez zaman aşımı ayarlanır.", "Forms Authentication", "Disabled", "HTTP 302 Login/Redirect"),
        r("Windows Kimlik Doğrulama: Kerberos veya NTLM ile domain kullanıcılarını otomatik tanır (tek oturum açma). Intranet uygulamaları için idealdir. Providers ile Negotiate/NTLM sırası, Advanced Settings ile Extended Protection ve Kernel-mode authentication ayarlanır.", "Windows Authentication", "Disabled", "HTTP 401 Challenge")] },
    acts: [["Enable", "✅", "Seçili kimlik doğrulama yöntemini etkinleştirir."], ["Disable", "⛔", "Seçili yöntemi devre dışı bırakır."], ["Edit...", "📝", "Seçili yöntemin ayarlarını düzenler (Anonymous: kullanılacak kimlik; Basic: varsayılan domain ve realm; Forms: login URL ve zaman aşımı)."], ["Providers...", "🔧", "(Windows Authentication) Negotiate (Kerberos, NTLM'e düşer) ve NTLM sağlayıcılarının sırasını belirler."], ["Advanced Settings...", "⚙️", "(Windows Authentication) Extended Protection ve Kernel-mode authentication. Kernel-mode açıkken Kerberos için SPN'ler makine hesabına kaydedilir; özel havuz hesabı kullanılıyorsa useAppPoolCredentials ayarı gerekir."]] },

  { id: "authz", n: "Authorization Rules", g: "IIS", ic: "🚦", lv: "all",
    d: "IIS URL Yetkilendirme kurallarıdır (<system.webServer><security><authorization>). Kimliği doğrulanmış kullanıcının içeriğe ERİŞİP ERİŞEMEYECEĞİNİ belirler. .NET Authorization'dan farkı: tüm içerik türlerine (statik, PHP vb.) uygulanır ve Deny kuralları her zaman Allow kurallarından önce değerlendirilir (sıra önemsizdir). 'URL Authorization' rol hizmeti kurulu olmalıdır.",
    cfg: "system.webServer/security/authorization",
    list: { cols: [["Mode", "Allow veya Deny."], ["Users", "Kullanıcılar: * (herkes), ? (anonim), belirli kullanıcı adları."], ["Roles", "Windows grupları veya ASP.NET rolleri."], ["Verbs", "HTTP metotları."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Varsayılan kural: tüm kullanıcılara izin verilir.", "Allow", "All Users", "", "", "Inherited")] },
    acts: [A.add("Allow Rule"), A.add("Deny Rule"), A.edit(), A.remove()] },

  { id: "cgi", n: "CGI", g: "IIS", ic: "🧮", lv: "all",
    d: "CGI (Common Gateway Interface) uygulamalarının ayarları (<system.webServer><cgi>). Her CGI isteği ayrı bir süreç başlatır; PHP gibi diller için performans nedeniyle FastCGI tercih edilir.",
    cfg: "system.webServer/cgi",
    grid: [{ cat: "Behavior", props: [
      ["Impersonate User", "True", "True ise CGI süreci kimliği doğrulanmış kullanıcının kimliğiyle çalışır.", "@createProcessAsUser"],
      ["Time-out (hh:mm:ss)", "00:15:00", "CGI sürecinin en uzun çalışma süresi; aşılırsa sonlandırılır.", "@timeout"],
      ["Use New Console For Each Invocation", "False", "Her CGI çağrısı için yeni konsol oluşturulması.", "@createCGIWithNewConsole"]] }],
    acts: [A.apply, A.cancel] },

  { id: "compress", n: "Compression", g: "IIS", ic: "🗜️", lv: "all",
    d: "Yanıtların gzip/deflate (ve uygun modülle Brotli) ile sıkıştırılarak gönderilmesini sağlar. Sayfa boyutunu %60-80 azaltır, bant genişliğinden tasarruf eder ve sayfaları hızlandırır. Bedeli biraz CPU kullanımıdır.",
    cfg: "system.webServer/urlCompression + httpCompression",
    form: [
      { sec: "", f: [
        c("Enable dynamic content compression", true, "ASP.NET, PHP gibi dinamik olarak üretilen yanıtları (HTML, JSON) her istekte sıkıştırır. 'Dynamic Content Compression' rol hizmeti kurulu olmalıdır. CPU yükü yüksekse (%90 üstü) IIS sıkıştırmayı geçici olarak bırakır."),
        c("Enable static content compression", true, "CSS, JS, HTML gibi statik dosyaları sıkıştırıp sıkıştırılmış kopyayı diskte önbellekler; sonraki isteklerde hazır kopya gönderilir.")] },
      { sec: "Static Compression", f: [
        c("Only compress files larger than (in bytes)", true, "Çok küçük dosyaların sıkıştırılması fayda sağlamaz; bu eşiğin altındakiler sıkıştırılmaz."),
        t("Size (bytes)", "2700", "Sıkıştırma için minimum dosya boyutu (varsayılan 2700 bayt)."),
        t("Cache directory", "%SystemDrive%\\inetpub\\temp\\IIS Temporary Compressed Files", "Sıkıştırılmış statik dosyaların saklandığı klasör."),
        c("Per application pool disk space limit (in MB)", true, "Önbellek klasörünün havuz başına en fazla boyutu."),
        t("Limit (MB)", "100", "Havuz başına disk kotası.")] }],
    acts: [A.apply, A.cancel] },

  { id: "defdoc", n: "Default Document", g: "IIS", ic: "📃", lv: "all",
    d: "Kullanıcı bir klasör adresi istediğinde (ör. https://site.com/ veya /urunler/) dosya adı belirtilmemişse hangi dosyanın sunulacağını belirler. Liste YUKARIDAN AŞAĞIYA taranır, ilk bulunan dosya döner. Sık kullanılanı en üste koymak disk aramalarını azaltır.",
    cfg: "system.webServer/defaultDocument",
    list: { cols: [["Name", "Varsayılan belge dosya adı."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Klasik varsayılan belge.", "Default.htm", "Inherited"), r("", "Default.asp", "Inherited"), r("", "index.htm", "Inherited"), r("", "index.html", "Inherited"), r("IIS 5 dönemi uyumluluk için.", "iisstart.htm", "Inherited"), r("ASP.NET Web Forms varsayılan sayfası.", "default.aspx", "Inherited"), r("PHP uygulamaları için eklenmiş örnek.", "index.php", "Local")] },
    acts: [A.add(), A.remove(), ["Move Up", "⬆️", "Belgeyi listede yukarı taşır (önceliğini artırır)."], ["Move Down", "⬇️", "Belgeyi aşağı taşır."], ["Disable", "⛔", "Varsayılan belge özelliğini tamamen kapatır. Kapalıyken klasör istenirse Directory Browsing açık değilse 403.14 hatası alınır."], A.revert] },

  { id: "dirbrowse", n: "Directory Browsing", g: "IIS", ic: "🗂️", lv: "all",
    d: "Varsayılan belge bulunamadığında klasör içeriğinin (dosya listesinin) tarayıcıda gösterilmesini sağlar. Güvenlik nedeniyle varsayılan KAPALIDIR; açık olması dosya yapınızı ifşa eder. Kapalıyken klasör istenirse HTTP 403.14 - Forbidden döner.",
    cfg: "system.webServer/directoryBrowse",
    form: [{ sec: "Listede gösterilecek bilgiler", f: [
      c("Time", true, "Dosyanın son değiştirilme saatini gösterir."),
      c("Size", true, "Dosya boyutunu gösterir."),
      c("Extension", true, "Dosya uzantısını gösterir."),
      c("Date", true, "Son değiştirilme tarihini gösterir."),
      c("Long date", false, "Tarihi uzun biçimde (ör. Çarşamba, 18 Kasım 2026) gösterir.")] }],
    acts: [A.apply, A.cancel, ["Enable", "✅", "Dizin listelemeyi etkinleştirir (<directoryBrowse enabled=\"true\"/>)."], ["Disable", "⛔", "Dizin listelemeyi kapatır (önerilen)."]] },

  { id: "errpages", n: "Error Pages", g: "IIS", ic: "🚧", lv: "all",
    d: "IIS düzeyinde HTTP hata kodları (401, 403, 404, 500...) için gösterilecek sayfaları belirler (<system.webServer><httpErrors>). ASP.NET, PHP, statik tüm içerik için çalışır. 'Edit Feature Settings' ile detaylı (detailed) hata mı yoksa özel (custom) sayfa mı gösterileceği seçilir.",
    cfg: "system.webServer/httpErrors",
    list: { cols: [["Status Code", "HTTP durum kodu."], ["Path", "Gösterilecek dosya veya yönlendirilecek URL."], ["Type", "File (statik dosya içeriği), Execute URL (sunucu tarafında başka URL çalıştırılır, ör. /Error.aspx), Redirect (302 yönlendirme)."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("401 Unauthorized: kimlik doğrulama başarısız veya gerekli.", "401", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\401.htm", "File", "Inherited"),
             r("403 Forbidden: erişim yasak (izin yok, dizin listeleme kapalı vb.).", "403", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\403.htm", "File", "Inherited"),
             r("404 Not Found: dosya bulunamadı. Alt durum kodları (404.0, 404.3 MIME eksik, 404.7 uzantı engelli...) sorun giderme için çok önemlidir.", "404", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\404.htm", "File", "Inherited"),
             r("405 Method Not Allowed: HTTP metoduna (ör. PUT, DELETE) izin verilmiyor. Genellikle WebDAV modülü bu hataya neden olur.", "405", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\405.htm", "File", "Inherited"),
             r("500 Internal Server Error: sunucu tarafında hata. 500.19 = yapılandırma hatası (bozuk web.config), 500.21 = modül tanınmıyor, 500.30 = ASP.NET Core başlatılamadı.", "500", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\500.htm", "File", "Inherited"),
             r("502 Bad Gateway: ARR/ters vekil veya ASP.NET Core arka uç yanıt vermedi.", "502", "%SystemDrive%\\inetpub\\custerr\\<LANGUAGE-TAG>\\502.htm", "File", "Inherited")] },
    acts: [A.add(), ["Change Status Code...", "🔢", "Seçili girdinin durum kodunu değiştirir."], A.edit(), A.remove(), ["Edit Feature Settings...", "⚙️", "Error Responses: 'Custom error pages' (herkese özel sayfa), 'Detailed errors' (herkese ayrıntılı hata – GÜVENSİZ), 'Detailed errors for local requests and custom error pages for remote requests' (varsayılan, önerilen: sunucunun kendisinde ayrıntılı hata görüp sorunu giderebilirsiniz). Ayrıca varsayılan sayfa yolu buradan ayarlanır."]] },

  { id: "frt", n: "Failed Request Tracing Rules", g: "IIS", ic: "🧾", lv: "all",
    d: "Başarısız İstek İzleme (FREB) kuralları. Belirli koşullara (durum kodu, süre, olay önem derecesi) uyan isteklerin IIS hattındaki HER ADIMINI ayrıntılı XML dosyasına kaydeder. 'Neden 500 alıyorum, hangi modül yavaş?' sorularının en güçlü yanıt aracıdır. Sitenin Failed Request Tracing ayarının da Enabled olması gerekir.",
    cfg: "system.webServer/tracing/traceFailedRequests",
    list: { cols: [["Path", "İzlenecek içerik (ör. *, *.aspx)."], ["Associated Provider(s)", "İzleme sağlayıcıları: WWW Server, ASP, ASPNET, ISAPI Extension."], ["Status Code(s)", "Hangi durum kodlarında kayıt alınacağı (ör. 500, 400-599)."], ["Time Taken", "Bu süreden uzun süren istekler kaydedilir (yavaşlık analizi)."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek kural: tüm isteklerde 500 hatası veya 10 saniyeden uzun süre olursa kayıt al.", "*", "WWW Server, ASPNET", "500", "00:00:10", "Local")] },
    acts: [A.add("", "Kural ekleme sihirbazı: içerik → koşullar (durum kodu/süre/önem) → sağlayıcılar ve ayrıntı düzeyi."), A.edit(), A.remove(), ["Edit Site Tracing...", "⚙️", "Sitenin izleme ayarlarını açar: Enable, klasör ve en fazla dosya sayısı."]] },

  { id: "handlers", n: "Handler Mappings", g: "IIS", ic: "🧭", lv: "all",
    d: "Hangi URL/uzantı isteğinin hangi işleyici (handler) tarafından işleneceğini belirler. Ör. *.aspx → PageHandlerFactory, *.php → FastCGI (php-cgi.exe), * → StaticFile. Liste yukarıdan aşağıya taranır; ilk eşleşen işleyici kullanılır. 'View Ordered List' ile sıra görülebilir.",
    cfg: "system.webServer/handlers",
    list: { cols: [["Name", "İşleyici eşlemesinin adı."], ["Path", "Eşleşecek URL deseni (*.aspx, *, WebResource.axd)."], ["State", "Enabled/Disabled – ilgili modül veya izinlere göre."], ["Path Type", "Unspecified, File, Directory veya File or Folder. 'File' seçilirse fiziksel dosya yoksa 404 döner."], ["Handler", "İsteği işleyen bileşen (modül veya .NET tipi)."], ["Entry Type", "Local veya Inherited."]],
      rows: [
        r("ASP.NET Web Forms sayfalarının işleyicisi (Integrated mod, .NET 4).", "PageHandlerFactory-Integrated-4.0", "*.aspx", "Enabled", "Unspecified", "System.Web.UI.PageHandlerFactory", "Inherited"),
        r("ASP.NET MVC / Web API gibi uzantısız URL'leri ASP.NET'e yönlendiren işleyici.", "ExtensionlessUrlHandler-Integrated-4.0", "*.", "Enabled", "Unspecified", "System.Web.Handlers.TransferRequestHandler", "Inherited"),
        r("ASP.NET Core Module V2 – ASP.NET Core uygulamalarını barındırır (in-process veya out-of-process). web.config içinde aspNetCore öğesiyle birlikte gelir.", "aspNetCore", "*", "Enabled", "Unspecified", "AspNetCoreModuleV2", "Local"),
        r("PHP dosyalarını FastCGI üzerinden php-cgi.exe'ye ileten eşleme.", "PHP_via_FastCGI", "*.php", "Enabled", "File or Folder", "FastCgiModule", "Inherited"),
        r("Klasik ASP sayfaları için ISAPI işleyicisi.", "ASPClassic", "*.asp", "Enabled", "File", "IsapiModule", "Inherited"),
        r("Eşleşmeyen diğer tüm istekleri (resim, css, js) karşılayan son işleyici. Statik dosyaları sunar; MIME türü tanımlı değilse 404.3 döner.", "StaticFile", "*", "Enabled", "File or Folder", "StaticFileModule, DefaultDocumentModule, DirectoryListingModule", "Inherited")] },
    acts: [["Add Managed Handler...", "➕", "Yönetilen (.NET) bir IHttpHandler sınıfını bir yola eşler (yalnızca Integrated mod)."], ["Add Script Map...", "➕", "Bir uzantıyı bir yürütülebilir dosyaya veya ISAPI DLL'ine eşler (ör. *.php → php-cgi.exe)."], ["Add Wildcard Script Map...", "➕", "Tüm istekleri (*) bir ISAPI'ye yönlendirir."], ["Add Module Mapping...", "➕", "Bir yolu yerel bir modüle eşler (ör. FastCgiModule)."], A.edit(), A.remove(), ["Edit Feature Permissions...", "🔐", "İşleyicilerin hangi erişim izinleriyle çalışacağı: Read (statik dosyalar), Script (ASP, ASP.NET), Execute (exe/dll). Script kapalıysa .aspx sayfaları çalışmaz."], ["View Ordered List...", "📋", "Eşlemeleri değerlendirme sırasıyla gösterir ve sırayı değiştirmeye izin verir."]] },

  { id: "redirect", n: "HTTP Redirect", g: "IIS", ic: "↪️", lv: "all",
    d: "Bu siteye/klasöre gelen istekleri başka bir adrese yönlendirir (<system.webServer><httpRedirect>). Basit, kalıcı taşımalar için uygundur; koşullu ve desen tabanlı yönlendirmeler için URL Rewrite kullanın. 'HTTP Redirection' rol hizmeti kurulu olmalıdır.",
    cfg: "system.webServer/httpRedirect",
    form: [{ sec: "", f: [
      c("Redirect requests to this destination", false, "Yönlendirmeyi etkinleştirir."),
      t("Destination", "https://www.yenisite.com", "Hedef adres."),
      c("Redirect all requests to exact destination (instead of relative to destination)", false, "İşaretliyse /urun/1 dahil tüm istekler tam olarak hedefe gider. İşaretsizse yol korunur: /urun/1 → hedef/urun/1."),
      c("Only redirect requests to content in this directory (not subdirectories)", false, "Yalnızca bu klasördeki içeriği yönlendirir, alt klasörleri değil."),
      s("Status code", "Found (302)", ["Permanent (301)", "Found (302)", "Temporary (307)", "Permanent Redirect (308)"], "301: kalıcı taşındı (SEO değerini aktarır, tarayıcı önbellekler). 302: geçici. 307: geçici, HTTP metodu korunur. 308: kalıcı, metot korunur.")] }],
    acts: [A.apply, A.cancel] },

  { id: "headers", n: "HTTP Response Headers", g: "IIS", ic: "🏷️", lv: "all",
    d: "Tüm yanıtlara eklenecek özel HTTP başlıklarını yönetir (<system.webServer><httpProtocol><customHeaders>). Güvenlik başlıkları (X-Content-Type-Options, Content-Security-Policy, X-Frame-Options) eklemek veya X-Powered-By gibi bilgi sızdıran başlıkları kaldırmak için kullanılır.",
    cfg: "system.webServer/httpProtocol/customHeaders",
    list: { cols: [["Name", "Başlık adı."], ["Value", "Başlık değeri."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Varsayılan olarak eklenen ve sunucu teknolojisini ifşa eden başlık. Güvenlik taramalarında genellikle KALDIRILMASI önerilir.", "X-Powered-By", "ASP.NET", "Inherited"),
             r("Tarayıcının MIME türü tahmini (sniffing) yapmasını engeller.", "X-Content-Type-Options", "nosniff", "Local"),
             r("Sitenin başka sitelerde iframe içinde gösterilmesini engeller (clickjacking koruması).", "X-Frame-Options", "SAMEORIGIN", "Local")] },
    acts: [A.add(), A.edit(), A.remove(), ["Set Common Headers...", "⚙️", "HTTP keep-alive'ı etkinleştirme ve içerik sona erme (Expire Web content: hemen / belirli süre sonra / belirli tarihte – Cache-Control başlığı) ayarları."]] },

  { id: "iprestr", n: "IP Address and Domain Restrictions", g: "IIS", ic: "🚫", lv: "all",
    d: "İstemcinin IP adresine (veya domain adına) göre erişime izin verir ya da reddeder. Ör. yönetim paneline yalnızca ofis IP'lerinden erişim. 'Edit Dynamic Restriction Settings' ile kaba kuvvet/DoS koruması için çok sık istek yapan IP'ler otomatik engellenebilir. 'IP and Domain Restrictions' rol hizmeti gerekir.",
    cfg: "system.webServer/security/ipSecurity",
    list: { cols: [["Mode", "Allow veya Deny."], ["Requestor", "IP adresi, IP aralığı (IP + maske) veya domain adı."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Ofis ağına izin veren örnek kural.", "Allow", "192.168.10.0 (255.255.255.0)", "Local"), r("Belirli bir saldırgan IP'yi engelleyen örnek kural.", "Deny", "203.0.113.45", "Local")] },
    acts: [A.add("Allow Entry"), A.add("Deny Entry"), A.remove(), ["Edit Feature Settings...", "⚙️", "Belirtilmeyen istemcilerin erişimi (Allow/Deny), domain adına göre kısıtlamayı etkinleştirme (DNS ters sorgusu – yavaştır), proxy modu (X-Forwarded-For'a göre) ve reddetme eylemi türü (Unauthorized 401, Forbidden 403, Not Found 404, Abort)."], ["Edit Dynamic Restriction Settings...", "⏱️", "Eşzamanlı istek sayısı veya belirli süre içindeki istek sayısı aşılırsa IP'yi otomatik reddeder. Logging Only modu ile önce test edilebilir."], ["View Ordered List...", "📋", "Kuralları değerlendirme sırasıyla gösterir."]] },

  { id: "isapifilt", n: "ISAPI Filters", g: "IIS", ic: "🧪", lv: "all",
    d: "ISAPI filtreleri, her istekte çalışan yerel (native) DLL'lerdir; isteği/yanıtı değiştirebilirler. Eski teknolojidir; günümüzde yerini IIS modüllerine bırakmıştır. Bazı eski ürünler (ör. ISAPI_Rewrite, eski SSO çözümleri) hâlâ kullanır.",
    cfg: "system.webServer/isapiFilters",
    list: { cols: [["Name", "Filtrenin adı."], ["Executable", "Filtre DLL'inin yolu."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("ASP.NET 4.0 (64 bit) ISAPI filtresi – Classic modda çerezsiz oturumlar için kullanılır.", "ASP.Net_4.0_64bit", "%windir%\\Microsoft.NET\\Framework64\\v4.0.30319\\aspnet_filter.dll", "Inherited")] },
    acts: [A.add(), A.edit(), ["Rename", "✏️", "Filtreyi yeniden adlandırır."], A.remove(), ["View Ordered List...", "📋", "Filtrelerin çalışma sırasını gösterir."]] },

  { id: "logging", n: "Logging", g: "IIS", ic: "📒", lv: "all",
    d: "IIS'in her isteği hangi biçimde, nereye ve hangi alanlarla günlüğe yazacağını belirler. Varsayılan konum: %SystemDrive%\\inetpub\\logs\\LogFiles\\W3SVC<SiteID>. Sorun giderme, güvenlik incelemesi ve trafik analizi için temel kaynaktır.",
    cfg: "system.applicationHost/log + sites/site/logFile",
    form: [
      { sec: "One log file per", f: [s("One log file per", "Site", ["Server", "Site"], "Sunucu düzeyinde: tüm siteler tek dosyaya mı (Server), yoksa her site kendi klasörüne mi (Site) yazsın.")] },
      { sec: "Log File", f: [
        s("Format", "W3C", ["IIS", "NCSA", "W3C", "Custom"], "W3C: alanları seçilebilen, en yaygın ve analiz araçlarının desteklediği biçim. IIS ve NCSA sabit alanlıdır. Custom: özel bir günlük modülü."),
        ["b", "Select Fields...", "", "W3C biçiminde hangi alanların yazılacağı: date, time, s-ip, cs-method, cs-uri-stem, cs-uri-query, s-port, cs-username, c-ip, cs(User-Agent), cs(Referer), sc-status, sc-substatus, sc-win32-status, time-taken. Ayrıca Bytes Sent/Received ve özel alanlar (ör. X-Forwarded-For başlığı – yük dengeleyici arkasında gerçek istemci IP'si için) eklenebilir."],
        t("Directory", "%SystemDrive%\\inetpub\\logs\\LogFiles", "Günlük dosyalarının ana klasörü. Sistem diskinin dolmaması için ayrı bir diske taşınması önerilir."),
        s("Encoding", "UTF-8", ["UTF-8", "ANSI"], "Günlük dosyasının karakter kodlaması.")] },
      { sec: "Log Event Destination", f: [rd("Destination", "Log file only", [["Log file only", "Yalnızca dosyaya yazılır."], ["ETW event only", "Yalnızca Event Tracing for Windows'a gönderilir (gerçek zamanlı izleme araçları için)."], ["Both log file and ETW event", "Her ikisine de yazılır."]], "Günlük olaylarının hedefi.")] },
      { sec: "Log File Rollover", f: [
        rd("Schedule", "Daily", [["Hourly", "Her saat yeni dosya."], ["Daily", "Her gün yeni dosya (u_exYYMMDD.log)."], ["Weekly", "Haftalık."], ["Monthly", "Aylık."]], "Yeni günlük dosyasına geçme zamanlaması."),
        c("Maximum file size (in bytes)", false, "Zaman yerine dosya boyutuna göre yeni dosyaya geçer."),
        c("Do not create new log files", false, "Tek bir dosyaya sürekli yazar."),
        c("Use local time for file naming and rollover", false, "İşaretsizse dosya adları ve geçiş UTC saatine göredir! Günlükteki saatler de varsayılan olarak UTC'dir – Türkiye için 3 saat fark olur.")] }],
    acts: [A.apply, A.cancel, ["Disable", "⛔", "Bu düzey için günlüğe yazmayı kapatır. Önerilmez."], ["View Log Files...", "📂", "Günlük klasörünü Gezgin'de açar."]] },

  { id: "mime", n: "MIME Types", g: "IIS", ic: "🧷", lv: "all",
    d: "Statik dosya uzantılarının hangi Content-Type ile sunulacağını belirler. IIS, MIME türü TANIMLI OLMAYAN uzantıları güvenlik gereği SUNMAZ ve 404.3 hatası verir. Ör. .webp, .woff2, .json, .apk gibi uzantılar eksikse buradan eklenir.",
    cfg: "system.webServer/staticContent",
    list: { cols: [["Extension", "Dosya uzantısı."], ["MIME Type", "Tarayıcıya gönderilecek Content-Type değeri."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("", ".css", "text/css", "Inherited"), r("", ".html", "text/html", "Inherited"), r("", ".js", "application/javascript", "Inherited"), r("", ".json", "application/json", "Inherited"), r("", ".png", "image/png", "Inherited"), r("", ".svg", "image/svg+xml", "Inherited"), r("Modern resim biçimi; eski IIS sürümlerinde eklemek gerekir.", ".webp", "image/webp", "Local"), r("Web fontu.", ".woff2", "font/woff2", "Inherited"), r("Bilinmeyen tüm dosyalar için genel ikili veri; indirme olarak sunulur. Dikkat: tüm uzantıları açmak hassas dosyaları sunabilir.", ".apk", "application/vnd.android.package-archive", "Local")] },
    acts: [A.add(), A.edit(), A.remove(), ["Set Common Headers...", "⚙️", "(clientCache) statik içeriğin tarayıcıda ne kadar süre önbelleğe alınacağı."]] },

  { id: "modules", n: "Modules", g: "IIS", ic: "🧱", lv: "all",
    d: "IIS istek hattında çalışan bileşenlerdir. Native modüller (DLL) sunucu düzeyinde kayıtlıdır (kimlik doğrulama, sıkıştırma, statik dosya, günlük...). Managed modüller .NET sınıflarıdır (FormsAuthentication, Session, UrlRoutingModule...). Kullanılmayan modülleri kaldırmak saldırı yüzeyini ve bellek kullanımını azaltır.",
    cfg: "system.webServer/modules + globalModules",
    list: { cols: [["Name", "Modül adı."], ["Code", "Native modül için DLL yolu, managed modül için .NET tipi."], ["Module Type", "Native veya Managed."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Anonim kimlik doğrulama modülü.", "AnonymousAuthenticationModule", "%windir%\\System32\\inetsrv\\authanon.dll", "Native", "Inherited"),
             r("Statik dosyaları sunan modül.", "StaticFileModule", "%windir%\\System32\\inetsrv\\static.dll", "Native", "Inherited"),
             r("Dinamik sıkıştırma modülü.", "DynamicCompressionModule", "%windir%\\System32\\inetsrv\\compdyn.dll", "Native", "Inherited"),
             r("URL Rewrite modülü (ayrıca indirilir).", "RewriteModule", "%SystemRoot%\\system32\\inetsrv\\rewrite.dll", "Native", "Inherited"),
             r("ASP.NET Core Module V2.", "AspNetCoreModuleV2", "%ProgramFiles%\\IIS\\Asp.Net Core Module\\V2\\aspnetcorev2.dll", "Native", "Inherited"),
             r("ASP.NET oturum durumu modülü.", "Session", "System.Web.SessionState.SessionStateModule", "Managed", "Inherited"),
             r("Forms kimlik doğrulama modülü.", "FormsAuthentication", "System.Web.Security.FormsAuthenticationModule", "Managed", "Inherited"),
             r("WebDAV modülü – PUT/DELETE isteklerini yakalayıp Web API'de 405 hatasına neden olabilir; kullanılmıyorsa kaldırılması önerilir.", "WebDAVModule", "%SystemRoot%\\System32\\inetsrv\\webdav.dll", "Native", "Inherited")] },
    acts: [["Add Managed Module...", "➕", "Bir .NET IHttpModule sınıfını hatta ekler. 'Invoke only for requests to ASP.NET applications or managed handlers' seçeneği (preCondition=managedHandler) işaretliyse statik dosyalarda çalışmaz."], ["Configure Native Modules...", "⚙️", "Sunucuda kayıtlı (globalModules) yerel modülleri bu düzeyde etkinleştirir veya yeni bir native DLL kaydeder."], A.edit(), ["Lock / Unlock", "🔒", "Modülün alt düzeylerde kaldırılmasını engeller/serbest bırakır."], A.remove(), ["View Ordered List...", "📋", "Modüllerin çalışma sırasını gösterir."]] },

  { id: "outcache", n: "Output Caching", g: "IIS", ic: "⚡", lv: "all",
    d: "Yanıtları bellekte önbelleğe alarak aynı istek tekrar geldiğinde uygulamayı çalıştırmadan doğrudan döndürür. Kernel cache (HTTP.sys) ve user-mode cache olmak üzere iki katman vardır. Dinamik ama sık değişmeyen sayfalarda büyük performans kazancı sağlar.",
    cfg: "system.webServer/caching",
    list: { cols: [["Extension", "Önbellek kuralının uygulandığı uzantı."], ["User-mode Policy", "IIS (user-mode) önbellek ilkesi: Until change (dosya değişene kadar), At time intervals (belirli süre), Prevent all caching."], ["Kernel-mode Policy", "HTTP.sys önbellek ilkesi; en hızlıdır ama kimlik doğrulamalı içeriği önbelleklemez."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Örnek: .aspx sayfalarını 30 saniye önbellekle, sorgu dizesindeki 'id' değerine göre ayrı kopyalar tut.", ".aspx", "Cache for 00:00:30 (vary by query: id)", "Do not cache", "Local")] },
    acts: [A.add(), A.edit(), A.remove(), ["Edit Feature Settings...", "⚙️", "Enable cache / Enable kernel cache onay kutuları, en büyük önbellek boyutu (MB) ve önbelleklenecek en büyük yanıt boyutu (bayt)."]] },

  { id: "reqfilt", n: "Request Filtering", g: "IIS", ic: "🧹", lv: "all",
    d: "Güvenlik amaçlı istek filtreleme (<system.webServer><security><requestFiltering>). Belirli uzantıları, URL dizelerini, HTTP metotlarını, gizli segmentleri (App_Data, bin, web.config) engeller ve istek boyutu sınırlarını uygular. Engellenen istekler 404.x alt kodlarıyla reddedilir (404.7 uzantı, 404.8 gizli segment, 404.13 içerik çok büyük, 404.14 URL çok uzun, 404.15 sorgu dizesi çok uzun).",
    cfg: "system.webServer/security/requestFiltering",
    list: { cols: [["File Name Extension", "Uzantı (File Name Extensions sekmesi). Diğer sekmeler: Rules, Hidden Segments, URL, HTTP Verbs, Headers, Query Strings."], ["Allowed", "True: izin ver, False: engelle."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Yapılandırma dosyaları dışarıdan indirilemez.", ".config", "False", "Inherited"), r("Kaynak kodlar sunulmaz.", ".cs", "False", "Inherited"), r("Veritabanı dosyaları.", ".mdb", "False", "Inherited"), r("Proje dosyaları.", ".csproj", "False", "Inherited"), r("Örnek: yedek dosyalarının indirilmesini engelleyen yerel kural.", ".bak", "False", "Local")] },
    acts: [["Allow File Name Extension...", "✅", "Bir uzantıya açıkça izin verir."], ["Deny File Name Extension...", "⛔", "Bir uzantıyı engeller (404.7)."], A.remove(), ["Edit Feature Settings...", "⚙️", "Allow unlisted file name extensions/verbs, allow high-bit characters, allow double escaping (URL'de %25 gibi çift kodlamaya izin – varsayılan kapalı, 404.11), ve İSTEK SINIRLARI: Maximum allowed content length (varsayılan 30000000 bayt ≈ 28.6 MB – büyük dosya yüklemeleri için artırılır; ASP.NET'te ayrıca maxRequestLength gerekir), Maximum URL length (4096), Maximum query string (2048)."]] },

  { id: "ssl", n: "SSL Settings", g: "IIS", ic: "🔒", lv: "site",
    d: "Bu site/uygulama için HTTPS zorunluluğunu ve istemci sertifikası davranışını belirler. Kullanılabilmesi için sitede bir https bağlaması (sertifika ile) tanımlı olmalıdır.",
    cfg: "system.webServer/security/access/@sslFlags",
    form: [{ sec: "", f: [
      c("Require SSL", true, "İşaretliyse içeriğe yalnızca HTTPS ile erişilebilir; HTTP isteklerine 403.4 (SSL required) döner. Otomatik yönlendirme YAPMAZ; HTTP→HTTPS yönlendirme için URL Rewrite veya HSTS kullanın."),
      rd("Client certificates", "Ignore", [["Ignore", "İstemci sertifikası istenmez (varsayılan)."], ["Accept", "Tarayıcının bir istemci sertifikası göndermesine izin verilir ama zorunlu değildir."], ["Require", "Geçerli bir istemci sertifikası zorunludur (karşılıklı TLS / mTLS). 'Require SSL' de işaretli olmalıdır. Sertifika yoksa 403.7 döner."]], "İstemci (kullanıcı/cihaz) sertifikası davranışı.")] }],
    acts: [A.apply, A.cancel] },

  { id: "rewrite", n: "URL Rewrite", g: "IIS", ic: "✂️", lv: "all",
    d: "Gelişmiş, kural tabanlı URL yeniden yazma ve yönlendirme modülü (ayrıca kurulur). Düzenli ifade (regex) desenleri ve koşullar (HTTPS kapalı mı, host adı nedir vb.) kullanarak istekleri yeniden yazar (Rewrite – sunucu içi, URL değişmez), yönlendirir (Redirect – tarayıcı yeni URL'ye gider), özel yanıt döner veya isteği iptal eder. HTTP→HTTPS, www yönlendirme, SEO dostu URL'ler, ARR ile ters vekil (reverse proxy) için kullanılır.",
    cfg: "system.webServer/rewrite/rules",
    list: { cols: [["Name", "Kural adı."], ["Input", "Desenin karşılaştırıldığı değer (genellikle URL path)."], ["Match", "Matches / Does Not Match."], ["Pattern", "Düzenli ifade deseni."], ["Action Type", "Rewrite, Redirect, Custom Response, Abort Request, None."], ["Action URL", "Hedef URL. {R:1} desen grupları, {HTTP_HOST} gibi sunucu değişkenleri kullanılabilir."], ["Stop Processing", "True ise kural eşleşince sonraki kurallar değerlendirilmez."], ["Entry Type", "Local veya Inherited."]],
      rows: [r("Klasik HTTP→HTTPS yönlendirme kuralı. Koşul: {HTTPS} = off. Eylem: Redirect (301) https://{HTTP_HOST}/{R:1}.", "HTTP to HTTPS", "URL path after '/'", "Matches", "(.*)", "Redirect", "https://{HTTP_HOST}/{R:1}", "True", "Local"),
             r("SPA (Angular/React) uygulamaları için: dosya veya klasör olmayan tüm istekleri index.html'e yeniden yazar.", "SPA fallback", "URL path after '/'", "Matches", ".*", "Rewrite", "/index.html", "True", "Local")] },
    acts: [["Add Rule(s)...", "➕", "Şablonlardan kural ekleme: Blank rule, Rule with rewrite map, Canonical domain name, Enforce lowercase URLs, Append/Remove trailing slash, User-friendly URL, Reverse Proxy (ARR gerekir)."], A.edit(), ["Rename", "✏️", "Kuralı yeniden adlandırır."], A.remove(), ["Move Up", "⬆️", "Kuralı yukarı taşır – kurallar sırayla değerlendirilir."], ["Move Down", "⬇️", "Kuralı aşağı taşır."], ["View Server Variables...", "🔧", "Kuralların değiştirebileceği izinli sunucu değişkenlerini (ör. HTTP_X_FORWARDED_PROTO) yönetir."], ["View Rewrite Maps...", "🗺️", "Eski URL → yeni URL gibi statik eşleme tablolarını yönetir."], ["Add Conditions / Test Pattern", "🧪", "Deseni örnek bir girdiye karşı test edip yakalanan grupları ({R:0}, {R:1}) gösterir."]] },

  { id: "webdav", n: "WebDAV Authoring Rules", g: "IIS", ic: "📝", lv: "all",
    d: "WebDAV, dosyaların HTTP üzerinden (Windows Gezgini'nden ağ sürücüsü gibi) düzenlenmesini sağlar. Kurallar hangi kullanıcıların hangi içeriğe Read/Write/Source erişimi olduğunu belirler. Web API/REST uygulamalarında WebDAV, PUT/DELETE metotlarını engelleyip 405 hatasına neden olabilir.",
    cfg: "system.webServer/webdav/authoringRules",
    list: { cols: [["Path", "Kuralın uygulandığı içerik."], ["Users", "Kullanıcılar."], ["Roles", "Roller."], ["Access", "Read, Write, Source (kaynak kodu okuma)."], ["Entry Type", "Local veya Inherited."]], rows: [] },
    acts: [A.add("Authoring Rule"), A.edit(), A.remove(), ["Enable WebDAV", "✅", "WebDAV yazma özelliğini bu site için etkinleştirir."], ["WebDAV Settings...", "⚙️", "Özellik deposu, kilitler (locks), gizli dosyaların gösterilmesi, istek filtrelemenin WebDAV'a uygulanması ayarları."]] },

  { id: "fastcgi", n: "FastCGI Settings", g: "IIS", ic: "🐘", lv: "server",
    d: "FastCGI uygulamalarını (en yaygın PHP: php-cgi.exe) yönetir. CGI'dan farklı olarak süreçleri havuzda tutup yeniden kullanır, bu yüzden çok daha hızlıdır. Burada süreç sayısı, zaman aşımları ve ortam değişkenleri ayarlanır.",
    cfg: "system.webServer/fastCgi",
    list: { cols: [["Full Path", "FastCGI yürütülebilir dosyasının yolu."], ["Arguments", "Yürütülebilir dosyaya geçilecek argümanlar."], ["Max Instances", "En fazla eşzamanlı süreç sayısı (0 = otomatik, CPU sayısına göre)."], ["Instance MaxRequests", "Bir süreç bu kadar isteği işledikten sonra yeniden başlatılır. PHP için PHP_FCGI_MAX_REQUESTS ile aynı veya daha küçük olmalıdır."]],
      rows: [r("Örnek PHP 8.3 kurulumu.", "C:\\PHP\\8.3\\php-cgi.exe", "", "0", "10000")] },
    acts: [A.add("Application"), A.edit("FastCGI uygulamasının ayrıntıları: Activity Timeout (yanıt vermeyen istek), Request Timeout (uzun süren istek, varsayılan 90 sn), Idle Timeout, Environment Variables (ör. PHP_FCGI_MAX_REQUESTS, PHPRC), Monitor changes to file (php.ini değişince süreçleri yeniden başlatır)."), A.remove()] },

  { id: "isapicgi", n: "ISAPI and CGI Restrictions", g: "IIS", ic: "⛓️", lv: "server",
    d: "Sunucuda hangi ISAPI DLL'lerinin ve CGI programlarının ÇALIŞMASINA İZİN VERİLDİĞİNİ belirleyen güvenlik listesidir. Listede 'Allowed' olmayan bir ISAPI/CGI çalıştırılmaya çalışılırsa 404.2 hatası alınır (ör. ASP.NET v4.0 kısıtlaması 'Not Allowed' ise .aspx sayfaları 404.2 verir).",
    cfg: "system.webServer/security/isapiCgiRestriction",
    list: { cols: [["Description", "Tanımlayıcı ad."], ["Restriction", "Allowed veya Not Allowed."], ["Path", "DLL veya EXE yolu."]],
      rows: [r("ASP.NET 4 (64 bit) – Classic mod uygulamaları için gerekir.", "ASP.NET v4.0.30319", "Allowed", "%windir%\\Microsoft.NET\\Framework64\\v4.0.30319\\aspnet_isapi.dll"),
             r("ASP.NET 4 (32 bit) – 32 bit havuzlar için.", "ASP.NET v4.0.30319", "Allowed", "%windir%\\Microsoft.NET\\Framework\\v4.0.30319\\aspnet_isapi.dll"),
             r("Klasik ASP motoru.", "Active Server Pages", "Allowed", "%windir%\\system32\\inetsrv\\asp.dll"),
             r("PHP CGI/FastCGI yürütülebilir dosyası.", "PHP 8.3", "Allowed", "C:\\PHP\\8.3\\php-cgi.exe")] },
    acts: [A.add(), A.edit(), A.remove(), ["Allow", "✅", "Seçili girdiye izin verir."], ["Deny", "⛔", "Seçili girdiyi engeller."], ["Edit Feature Settings...", "⚙️", "Allow unspecified CGI modules / Allow unspecified ISAPI modules – listede olmayanlara izin verilsin mi (güvenlik için kapalı tutun)."]] },

  { id: "certs", n: "Server Certificates", g: "IIS", ic: "📜", lv: "server",
    d: "Sunucunun yerel bilgisayar sertifika deposundaki (Personal / Web Hosting) SSL/TLS sertifikalarını yönetir. Burada içe aktardığınız sertifika, site bağlamasında (Bindings > https) seçilir. Sertifikaların bitiş tarihlerini takip etmek kritik öneme sahiptir.",
    cfg: "(Sertifika deposu – LocalMachine\\My, WebHosting)",
    list: { cols: [["Name", "Sertifikanın kolay adı (Friendly Name)."], ["Issued To", "Sertifikanın verildiği alan adı (CN / SAN)."], ["Issued By", "Sertifikayı veren otorite (CA)."], ["Expiration Date", "Son geçerlilik tarihi. Süresi dolan sertifika tarayıcıda güvenlik uyarısına neden olur."], ["Certificate Hash", "Sertifikanın parmak izi (thumbprint)."], ["Certificate Store", "Personal (My) veya Web Hosting."]],
      rows: [r("Intranet sitesi için kurum içi CA'dan alınmış sertifika.", "intranet-2026", "intranet.firma.local", "FIRMA-CA", "14.01.2027", "A1B2...9F", "Personal"),
             r("Ticari CA sertifikası (joker karakterli).", "shop-wildcard", "*.shop.com", "DigiCert Global G2 TLS RSA SHA256 2020 CA1", "02.06.2027", "7C3D...11", "Web Hosting"),
             r("IIS Express / geliştirme için kendinden imzalı sertifika – tarayıcılar güvenmez.", "IIS Express Development Certificate", "localhost", "localhost", "05.03.2031", "5E6F...A0", "Personal")] },
    acts: [["Import...", "📥", "Bir .pfx dosyasını (sertifika + özel anahtar) parola ile içe aktarır. 'Allow this certificate to be exported' işareti özel anahtarın dışa aktarılabilmesini sağlar."], ["Create Certificate Request...", "📝", "Bir CSR (sertifika imzalama isteği) oluşturur; ticari bir CA'ya gönderilir. Anahtar uzunluğu en az 2048 bit olmalı."], ["Complete Certificate Request...", "✅", "CA'dan dönen .cer dosyasını, CSR ile oluşturulan özel anahtarla eşleştirerek kurulumu tamamlar."], ["Create Domain Certificate...", "🏢", "Active Directory kurumsal CA'dan doğrudan sertifika ister."], ["Create Self-Signed Certificate...", "🧪", "Test amaçlı kendinden imzalı sertifika oluşturur."], ["Enable Automatic Rebind of Renewed Certificate", "🔄", "Sertifika (ör. otomatik kayıtla) yenilendiğinde bağlamaların yeni sertifikaya otomatik geçmesini sağlar."], ["View...", "👁️", "Sertifika ayrıntılarını gösterir."], ["Export...", "📤", "Sertifikayı özel anahtarla .pfx olarak dışa aktarır."], ["Renew...", "♻️", "Sertifika yenileme isteği oluşturur."], A.remove()] },

  { id: "centralcert", n: "Centralized Certificates", g: "IIS", ic: "🏛️", lv: "server",
    d: "Merkezi Sertifika Deposu (CCS): Sertifikalar her sunucunun deposu yerine bir ağ paylaşımında .pfx dosyaları olarak tutulur. Web çiftliklerinde sertifikayı tek yerde güncellemek için kullanılır. Dosya adı alan adıyla eşleşmelidir (ör. www.shop.com.pfx). Bağlamada 'Use Centralized Certificate Store' seçilir.",
    cfg: "(Kayıt defteri – IIS\\CentralCertProvider)",
    form: [{ sec: "", f: [c("Enable Centralized Certificates", false, "Merkezi sertifika deposunu etkinleştirir."), t("Physical path", "\\\\fs01\\certs", "Sertifikaların bulunduğu UNC paylaşım yolu."), t("User name", "FIRMA\\svc_certs", "Paylaşıma erişecek hesap."), t("Private key password", "", "Tüm .pfx dosyalarının ortak parolası (opsiyonel).")] }],
    acts: [["Edit Feature Settings...", "⚙️", "CCS ayarlarını düzenler."]] },

  { id: "workers", n: "Worker Processes", g: "IIS", ic: "🏃", lv: "server",
    d: "Şu anda çalışan w3wp.exe süreçlerini (her uygulama havuzu için) CPU, bellek ve PID bilgisiyle gösterir. Bir süreci seçip 'View Current Requests' ile o anda işlenmekte olan istekleri (URL, süre, modül, aşama) görebilirsiniz – takılan/yavaş isteği bulmak için çok değerlidir.",
    cfg: "(Çalışma zamanı – RSCA)",
    list: { cols: [["Application Pool Name", "Sürecin ait olduğu havuz."], ["Process ID", "Görev Yöneticisi'ndeki PID. Bellek dökümü almak (procdump -ma <PID>) için kullanılır."], ["State", "Running, Stopping vb."], ["CPU %", "Anlık CPU kullanımı."], ["Private Bytes (KB)", "Sürecin özel bellek kullanımı. Sürekli artıyorsa bellek sızıntısı olabilir."], ["Virtual Bytes (KB)", "Ayrılmış sanal bellek."]],
      rows: [r("", "DefaultAppPool", "4120", "Running", "0", "98 432", "2 214 880"), r("", "IntranetPool", "6684", "Running", "3", "412 776", "2 642 112"), r("", "ShopApiPool", "7012", "Running", "11", "268 104", "2 400 552")] },
    acts: [["View Current Requests", "👁️", "Seçili süreçte şu anda yürütülen istekleri gösterir (URL, istemci IP, geçen süre, mevcut modül ve aşama). appcmd list requests ile de görülebilir."], ["Refresh", "🔄", "Listeyi yeniler."]] },

  /* ===================== Management ===================== */
  { id: "config", n: "Configuration Editor", g: "Management", ic: "🛠️", lv: "all",
    d: "IIS'in tüm yapılandırma bölümlerine (arayüzde simgesi olmayan ayarlar dahil) doğrudan erişim sağlayan gelişmiş düzenleyici. Bölüm seçilir, öznitelikler düzenlenir. 'Generate Script' ile yaptığınız değişikliğin C#, JavaScript, AppCmd ve PowerShell karşılığını üretir – otomasyon öğrenmek için mükemmeldir.",
    cfg: "(Tüm bölümler)",
    grid: [{ cat: "Section: system.webServer/security/requestFiltering   From: ApplicationHost.config", props: [
      ["allowDoubleEscaping", "False", "URL'de çift kodlanmış karakterlere (ör. + işareti, %2520) izin verilsin mi. Kapalıyken 404.11 döner.", "@allowDoubleEscaping"],
      ["allowHighBitCharacters", "True", "ASCII dışı karakterlerin (ğ, ü, ş) URL'de kullanılmasına izin.", "@allowHighBitCharacters"],
      ["removeServerHeader", "False", "True ise yanıtlardaki 'Server: Microsoft-IIS/10.0' başlığı kaldırılır (IIS 10+).", "@removeServerHeader"],
      ["requestLimits/maxAllowedContentLength", "30000000", "İzin verilen en büyük istek gövdesi (bayt).", "requestLimits/@maxAllowedContentLength"],
      ["requestLimits/maxUrl", "4096", "En uzun URL (bayt).", "requestLimits/@maxUrl"],
      ["requestLimits/maxQueryString", "2048", "En uzun sorgu dizesi (bayt).", "requestLimits/@maxQueryString"]] }],
    acts: [A.apply, A.cancel, ["Generate Script", "📜", "Bekleyen değişikliklerin AppCmd, PowerShell, C# ve JavaScript betik karşılığını gösterir."], ["Search Configuration...", "🔎", "Tüm yapılandırma dosyalarında hangi bölümlerin nerede tanımlandığını arar."], ["Section: Lock / Unlock", "🔒", "Bölümü alt düzeylerde geçersiz kılınamaz yapar (overrideMode=Deny) veya serbest bırakır."]] },

  { id: "delegation", n: "Feature Delegation", g: "Management", ic: "🔓", lv: "server",
    d: "Hangi özelliklerin alt düzeylerde (sitelerin web.config dosyalarında veya site yöneticileri tarafından) değiştirilebileceğini belirler. Ör. 'Handler Mappings' Read Only ise bir sitenin web.config dosyasında <handlers> bölümü kullanılırsa 500.19 'This configuration section cannot be used at this path' hatası alınır. Bu hatanın en sık çözüm yeri burasıdır.",
    cfg: "(overrideModeDefault / location overrideMode)",
    list: { cols: [["Name", "Özellik adı."], ["Delegation", "Read/Write: alt düzeylerde değiştirilebilir. Read Only: yalnızca okunabilir, değiştirilemez (kilitli). Not Delegated: site yöneticileri göremez. Configuration Read/Write, Configuration Read Only gibi varyantlar da vardır."]],
      rows: [r("", "Authentication - Anonymous", "Read Only"), r("Windows auth kilitli olduğundan web.config'de etkinleştirmeye çalışmak 500.19 hatasına yol açar.", "Authentication - Windows", "Read Only"), r("", "Default Document", "Read/Write"), r("", "Handler Mappings", "Read Only"), r("", "HTTP Response Headers", "Read/Write"), r("", "Modules", "Read Only"), r("", "URL Rewrite - Inbound Rules", "Read/Write")] },
    acts: [["Read/Write", "✏️", "Seçili özelliği alt düzeylerde düzenlenebilir yapar."], ["Read Only", "🔒", "Seçili özelliği kilitler."], ["Not Delegated", "🚫", "Site yöneticilerinden gizler."], ["Reset to Inherited", "⤴️", "Delegasyonu üst düzeyden miras almaya döndürür."], ["Custom Site Delegation...", "🏷️", "Belirli bir site için farklı delegasyon ayarları yapar."], ["Reset All Delegation", "♻️", "Tüm özellikleri varsayılan delegasyona sıfırlar."]] },

  { id: "sharedcfg", n: "Shared Configuration", g: "Management", ic: "🔁", lv: "server",
    d: "Birden fazla IIS sunucusunun (web çiftliği) aynı applicationHost.config ve administration.config dosyalarını bir ağ paylaşımından kullanmasını sağlar. Böylece tüm sunucular aynı site/havuz yapılandırmasına sahip olur. Şifreleme anahtarları da dışa aktarılıp paylaşılmalıdır.",
    cfg: "(redirection.config)",
    form: [{ sec: "", f: [c("Enable shared configuration", false, "Paylaşılan yapılandırmayı etkinleştirir."), t("Physical path", "\\\\fs01\\iis-shared", "Yapılandırma dosyalarının bulunduğu UNC yolu."), t("User name", "FIRMA\\svc_iisconfig", "Paylaşıma erişecek hesap."), t("Password", "", "Hesabın parolası.")] }],
    acts: [A.apply, A.cancel, ["Export Configuration...", "📤", "Mevcut yapılandırmayı ve şifreleme anahtarlarını (bir parola ile korunan) paylaşım klasörüne dışa aktarır. İlk sunucuda yapılır."]] },

  { id: "mgrperm", n: "IIS Manager Permissions", g: "Management", ic: "🪪", lv: "all",
    d: "Bu siteyi veya uygulamayı uzaktan (Management Service üzerinden) yönetebilecek kullanıcıları belirler. Bu kullanıcılar yalnızca yetkili oldukları site/uygulamayı görebilir ve yalnızca Feature Delegation'da izin verilen özellikleri değiştirebilir. Barındırma (hosting) senaryoları için tasarlanmıştır.",
    cfg: "(administration.config – authorization)",
    list: { cols: [["Name", "Windows kullanıcısı/grubu veya IIS Manager kullanıcısı."], ["Type", "Windows / IIS Manager."]], rows: [r("Örnek: Intranet sitesi için yetkili web geliştirici.", "FIRMA\\webdev", "Windows")] },
    acts: [["Allow User...", "➕", "Bir kullanıcıya bu site/uygulamayı yönetme izni verir."], ["Deny User", "⛔", "Seçili kullanıcının iznini kaldırır."]] },

  { id: "mgrusers", n: "IIS Manager Users", g: "Management", ic: "🧑‍🔧", lv: "server",
    d: "Windows hesabı olmayan, yalnızca IIS Yöneticisi'nde (uzaktan site yönetimi için) geçerli kullanıcılar oluşturur. Management Service'te 'Windows credentials or IIS Manager credentials' seçili olmalıdır.",
    cfg: "(administration.config)",
    list: { cols: [["User Name", "IIS Manager kullanıcı adı."], ["Enabled", "Hesap etkin mi."]], rows: [r("", "musteri-a", "True")] },
    acts: [["Add User...", "➕", "Yeni IIS Manager kullanıcısı ekler."], ["Change Password...", "🔑", "Parolayı değiştirir."], ["Disable", "⛔", "Hesabı devre dışı bırakır."], A.remove()] },

  { id: "mgmtsvc", n: "Management Service", g: "Management", ic: "🛰️", lv: "server",
    d: "Web Management Service (WMSVC) – IIS'in uzaktan yönetimini sağlayan Windows hizmetidir. Başka bir bilgisayardaki IIS Yöneticisi veya Web Deploy (MSDeploy) bu hizmet üzerinden (HTTPS, varsayılan port 8172) bağlanır. Ayarları değiştirmek için hizmetin DURDURULMASI gerekir.",
    cfg: "(Kayıt defteri – WebManagement\\Server)",
    form: [
      { sec: "", f: [c("Enable remote connections", false, "Uzaktan bağlantılara izin verir. Kapalıyken yalnızca yerel yönetim yapılabilir.")] },
      { sec: "Identity Credentials", f: [rd("Credentials", "Windows credentials only", [["Windows credentials only", "Yalnızca Windows hesapları bağlanabilir."], ["Windows credentials or IIS Manager credentials", "IIS Manager Users ile oluşturulan hesaplar da bağlanabilir."]], "Uzak bağlantılarda kabul edilecek kimlik türü.")] },
      { sec: "Connections", f: [t("IP address", "All Unassigned", "Hizmetin dinleyeceği IP."), t("Port", "8172", "Hizmetin portu (güvenlik duvarında açık olmalı)."), s("SSL certificate", "WMSvc-SHA2-WIN-IIS01", ["WMSvc-SHA2-WIN-IIS01", "intranet-2026"], "Bağlantının şifrelenmesi için kullanılacak sertifika.")] },
      { sec: "Logging", f: [c("Log requests to", true, "Yönetim isteklerinin günlüğe yazılması."), t("Log path", "%SystemDrive%\\Inetpub\\logs\\WMSvc", "Günlük klasörü.")] },
      { sec: "IPv4 Address Restrictions", f: [s("Access for unspecified clients", "Allow", ["Allow", "Deny"], "Listede olmayan IP'lerin bağlanıp bağlanamayacağı. Güvenlik için Deny + yalnızca yönetim IP'lerine Allow önerilir.")] }],
    acts: [A.apply, A.cancel, ["Start", "▶️", "Web Management Service'i başlatır."], ["Stop", "⏹️", "Hizmeti durdurur (ayarları değiştirmek için gerekir)."]] }
  ];
})();
