/* IIS Yardım Masası – Server Farms (Application Request Routing 3.0)
   Ağaca "Server Farms" düğümünü, örnek çiftliği ve ARR özelliklerini ekler. */
(function () {
  const r = (h, ...c) => ({ h, c });
  const c = (n, v, h) => ["c", n, v, h];
  const t = (n, v, h) => ["t", n, v, h];
  const s = (n, v, opts, h) => ["s", n, v, h, opts];
  const rd = (n, v, opts, h) => ["r", n, v, h, opts];
  const apply = ["Apply", "✔️", "Sayfadaki değişiklikleri applicationHost.config içindeki <webFarms> bölümüne kaydeder."];
  const cancel = ["Cancel", "↩️", "Kaydedilmemiş değişiklikleri geri alır."];

  /* ---------- Ağaç ---------- */
  const server = IIS.tree.find((n) => n.type === "server");
  server.children.push({
    id: "farms", type: "farms", n: "Server Farms", open: true,
    h: "Sunucu çiftlikleri (Server Farms). Bu düğüm, Application Request Routing (ARR) eklentisi kurulduğunda görünür. Bir sunucu çiftliği, aynı uygulamayı çalıştıran birden fazla arka uç (backend) web sunucusunun bir grup olarak tanımlanmasıdır. Bu IIS sunucusu önde ters vekil (reverse proxy) / yük dengeleyici olarak çalışır: gelen istekleri URL Rewrite kuralıyla yakalar ve çiftlikteki sunuculara dağıtır.\n\nARR, Windows rol hizmeti DEĞİLDİR; Microsoft'un sitesinden ayrı olarak indirilip kurulur (URL Rewrite modülü ön koşuldur).",
    children: [
      { id: "farm1", type: "farm", farmIdx: 0, n: "WebFarm01",
        h: "Örnek sunucu çiftliği: 3 arka uç sunucudan (WEB01, WEB02, WEB03) oluşur. Bu düğüm seçildiğinde çiftliğe özel ARR özellikleri (Caching, Health Test, Load Balance, Monitoring and Management, Proxy, Routing Rules, Server Affinity, Servers) görünür. Ayarlar applicationHost.config içinde <webFarms><webFarm name=\"WebFarm01\"> altına yazılır." }
    ]
  });

  /* ---------- Çiftlik verisi ---------- */
  IIS.farms = [
    { name: "WebFarm01", online: true, algo: "Weighted round robin", affinity: "Disabled", health: "http://shop.local/health",
      servers: [
        { addr: "WEB01", http: 80, https: 443, weight: 100, online: true, status: "Available", health: "Healthy", cur: 12, total: 184220, failed: 31, rt: 42 },
        { addr: "WEB02", http: 80, https: 443, weight: 100, online: true, status: "Available", health: "Healthy", cur: 9, total: 179804, failed: 18, rt: 47 },
        { addr: "10.0.0.23", http: 8080, https: 8443, weight: 50, online: true, status: "Unavailable", health: "Unhealthy", cur: 0, total: 40112, failed: 3120, rt: 0 }
      ] }
  ];

  IIS.farmCols = [
    ["Name", "Sunucu çiftliğinin adı. URL Rewrite kuralları bu adı kullanarak istekleri çiftliğe yönlendirir: Action Type = Route to Server Farm, Server farm = <Ad>. Ad, istekleri yeniden yazarken 'http://WebFarm01/{R:0}' biçiminde de kullanılır."],
    ["Servers", "Çiftlikteki arka uç sunucu sayısı."],
    ["Online", "Çiftliğin etkin olup olmadığı. Çevrimdışı (False) çiftliğe istek yönlendirilmez."],
    ["Load Balance Algorithm", "İsteklerin sunuculara hangi yöntemle dağıtıldığı (Load Balance özelliğinden ayarlanır)."],
    ["Server Affinity", "Aynı istemcinin hep aynı sunucuya gönderilip gönderilmediği (ARRAffinity çerezi)."]
  ];

  /* ---------- Eylemler ---------- */
  IIS.actions.farms = [
    ["Create Server Farm...", "➕", "Yeni bir sunucu çiftliği oluşturma sihirbazını açar: önce çiftlik adı girilir, sonra arka uç sunucular (adres, HTTP/HTTPS portu, ağırlık) eklenir. Bitişte IIS, tüm gelen istekleri bu çiftliğe yönlendirecek bir URL Rewrite kuralı oluşturmayı önerir.", "addFarm"],
    ["Help", "❔", "Sunucu çiftlikleri ve Application Request Routing hakkında yardım."]
  ];
  IIS.actions.farm = [
    { g: "Server Farm Tasks" },
    ["Add Server", "➕", "Çiftliğe yeni bir arka uç sunucu ekler (sunucu adı veya IP, portlar, ağırlık).", "addFarmServer"],
    ["Rename Server Farm", "✏️", "Çiftliğin adını değiştirir. DİKKAT: Bu çiftliği kullanan URL Rewrite kurallarındaki ad da güncellenmelidir; aksi halde istekler yönlendirilemez (502 hatası)."],
    ["Remove Server Farm", "❌", "Çiftliği siler. İlgili URL Rewrite kuralları kaldırılmazsa istekler başarısız olur."],
    { g: "Help" },
    ["Help", "❔", "Sunucu çiftliği özellikleri hakkında yardım."]
  ];

  /* ---------- Simgeler (çiftlik simgeleri ekran görüntülerinde olmadığı için çizildi) ---------- */
  const rack = (badge) => `<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><defs><linearGradient id="rk" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#e9edf2"/><stop offset="1" stop-color="#a9b4c2"/></linearGradient></defs><rect x="2" y="3" width="13" height="5" rx="1" fill="url(#rk)" stroke="#5b6878" stroke-width=".7"/><rect x="2" y="9" width="13" height="5" rx="1" fill="url(#rk)" stroke="#5b6878" stroke-width=".7"/><rect x="2" y="15" width="13" height="5" rx="1" fill="url(#rk)" stroke="#5b6878" stroke-width=".7"/><circle cx="4.5" cy="5.5" r=".9" fill="#2eb82e"/><circle cx="4.5" cy="11.5" r=".9" fill="#2eb82e"/><circle cx="4.5" cy="17.5" r=".9" fill="#2eb82e"/>${badge}</svg>`;
  const B = {
    caching: '<rect x="12" y="11" width="11" height="11" rx="1.5" fill="#f2b632" stroke="#a87511" stroke-width=".7"/><path d="M14.5 14h6M14.5 16.5h6M14.5 19h6" stroke="#7a520a" stroke-width="1"/>',
    health: '<path d="M17.5 22s-5.5-3.3-5.5-7a3 3 0 0 1 5.5-1.6A3 3 0 0 1 23 15c0 3.7-5.5 7-5.5 7z" fill="#e0373f" stroke="#99161c" stroke-width=".6"/><path d="M13.5 16h2l1-2 1.5 4 1-2h2" stroke="#fff" stroke-width=".9" fill="none"/>',
    lb: '<circle cx="17.5" cy="16.5" r="5.5" fill="#2f7fd1" stroke="#164f8c" stroke-width=".6"/><path d="M14 16.5h7M14 16.5l2-2M14 16.5l2 2M21 16.5l-2-2M21 16.5l-2 2" stroke="#fff" stroke-width="1" fill="none"/>',
    monitor: '<rect x="11.5" y="11" width="12" height="9" rx="1" fill="#2b2f36" stroke="#000" stroke-width=".5"/><path d="M13 18l2.5-3 2 2 2.5-4 2 2" stroke="#4cd964" stroke-width="1.1" fill="none"/><rect x="15.5" y="20" width="4" height="2" fill="#5b6878"/>',
    proxy: '<circle cx="17.5" cy="16.5" r="5.5" fill="#33a852" stroke="#1d6b31" stroke-width=".6"/><path d="M14.3 16.5h6.2M18 13.8l2.7 2.7-2.7 2.7" stroke="#fff" stroke-width="1.3" fill="none"/>',
    routing: '<rect x="11.5" y="11" width="12" height="11" rx="1" fill="#fff" stroke="#6b7a8c" stroke-width=".7"/><path d="M13.5 14h3M13.5 17h3M13.5 20h3" stroke="#2f7fd1" stroke-width="1.2"/><path d="M18 14h4M18 17h4M18 20h4" stroke="#999" stroke-width="1"/>',
    affinity: '<circle cx="15.5" cy="16.5" r="3.4" fill="none" stroke="#7a3fc4" stroke-width="1.6"/><circle cx="19.8" cy="16.5" r="3.4" fill="none" stroke="#c43f8e" stroke-width="1.6"/>',
    servers: '<circle cx="18" cy="17" r="5" fill="#fff" stroke="#2f7fd1" stroke-width="1"/><path d="M18 14.2v5.6M15.2 17h5.6" stroke="#2f7fd1" stroke-width="1.4"/>',
    arrcache: '<ellipse cx="17.5" cy="13" rx="5.5" ry="2" fill="#f2b632" stroke="#a87511" stroke-width=".6"/><path d="M12 13v7c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2v-7" fill="#f6c94f" stroke="#a87511" stroke-width=".6"/><path d="M12 16.5c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2" fill="none" stroke="#a87511" stroke-width=".6"/>'
  };
  IIS.svgIcons = Object.assign(IIS.svgIcons || {}, {
    farms: rack(""),
    farm: rack('<circle cx="18.5" cy="16.5" r="5" fill="#2f7fd1"/><path d="M16 16.5h5M18.5 14v5" stroke="#fff" stroke-width="1.2"/>')
  });

  IIS.groups.push(["Server Farm", "Application Request Routing (ARR) ile gelen, seçili sunucu çiftliğine özel ayarlar: istekleri nasıl dağıtacağı, sunucuların sağlığını nasıl test edeceği, önbellekleme, vekil (proxy) davranışı ve oturum bağlılığı. Ayarlar applicationHost.config içinde <webFarms> altına yazılır."]);

  const farmCfg = "webFarms/webFarm[@name='WebFarm01']/applicationRequestRouting";
  const F = [
    { id: "farmcache", n: "Caching", svg: rack(B.caching),
      d: "ARR'nin arka uç sunuculardan gelen yanıtları bu sunucuda (ön uçta) önbelleğe almasını sağlar. Böylece aynı içerik tekrar istendiğinde arka uca gidilmeden doğrudan önbellekten döner; arka uç yükü ve yanıt süresi azalır. Disk önbelleği için sunucu düzeyindeki 'Application Request Routing Cache' özelliğinden önbellek sürücüsü tanımlanmalıdır.",
      cfg: farmCfg + "/protocol/cache",
      form: [
        { sec: "", f: [
          c("Enable disk cache", true, "Yanıtların diske de önbelleklenmesini sağlar. Kapalıysa yalnızca bellek önbelleği kullanılır. Disk konumu sunucu düzeyinde ARR Cache > Add Drive ile belirlenir."),
          t("Memory cache duration (seconds)", "60", "Yanıtların bellekte tutulacağı süre. Arka uç Cache-Control başlığı gönderiyorsa genellikle o başlık önceliklidir."),
          c("Enable request consolidation", false, "Aynı içerik için aynı anda gelen çok sayıda istek arka uca tek istek olarak gönderilir, sonuç hepsine dağıtılır. Canlı yayın / yoğun içerik senaryolarında arka uç yükünü büyük ölçüde azaltır."),
          rd("Query string support", "Include query string", [["Include query string", "?id=1 ve ?id=2 farklı önbellek girdileri olarak tutulur (önerilen)."], ["Ignore query string", "Sorgu dizesi yok sayılır; aynı yolun tüm varyasyonları tek kopya olarak önbelleklenir. Dikkat: dinamik sayfalarda yanlış içerik gösterilebilir."]], "Sorgu dizesinin önbellek anahtarına dahil edilip edilmeyeceği.")] }],
      acts: [apply, cancel] },

    { id: "farmhealth", n: "Health Test", svg: rack(B.health),
      d: "Çiftlikteki sunucuların sağlıklı olup olmadığını denetler. Sağlıksız bulunan sunucuya yeni istek gönderilmez; tekrar sağlıklı olunca otomatik olarak geri alınır. İki yöntem vardır: URL testi (belirli aralıklarla bir test adresi çağrılır) ve canlı trafik testi (gerçek isteklerdeki hatalar sayılır).",
      cfg: farmCfg + "/healthCheck",
      form: [
        { sec: "URL Test", f: [
          t("URL", "http://shop.local/health", "Her sunucuya gönderilecek test adresi. Host adı kısmı yalnızca Host başlığı için kullanılır; istek her bir sunucunun kendi adresine gider. Uygulamanın veritabanı bağlantısı gibi kritik bağımlılıklarını da kontrol eden hafif bir sayfa önerilir."),
          t("Interval (seconds)", "30", "Test isteklerinin gönderilme sıklığı."),
          t("Time-out (seconds)", "30", "Test isteğine yanıt için beklenecek süre; aşılırsa sunucu sağlıksız sayılır."),
          t("Acceptable status codes", "200-399", "Sağlıklı kabul edilecek HTTP durum kodları (aralık veya virgüllü liste)."),
          t("Response match", "OK", "Yanıt gövdesinde bulunması gereken metin. Boş bırakılırsa yalnızca durum kodu kontrol edilir."),
          ["b", "Verify URL Test", "", "Testi hemen tüm sunuculara gönderip sonuçlarını (Pass/Fail, süre, durum kodu) gösterir. Kurulumdan sonra mutlaka deneyin."]] },
        { sec: "Live Traffic Test", f: [
          t("Failure codes", "500-599", "Gerçek isteklerde bu durum kodları dönerse hata sayılır."),
          t("Maximum failures", "0", "Failover period içinde izin verilen en fazla hata. 0 = canlı trafik testi devre dışı."),
          t("Failover period (seconds)", "30", "Hataların sayıldığı süre. Sınır aşılırsa sunucu bu süre boyunca devre dışı bırakılır.")] },
        { sec: "", f: [t("Minimum servers", "0", "Sağlıklı sunucu sayısı bu değerin altına düşerse, ARR sağlıksız sunucuları da kullanmaya devam eder (tamamen hizmet dışı kalmaktansa). 0 = kısıt yok.")] }],
      acts: [apply, cancel] },

    { id: "farmlb", n: "Load Balance", svg: rack(B.lb),
      d: "Gelen isteklerin çiftlikteki sunuculara hangi algoritmayla dağıtılacağını belirler.",
      cfg: farmCfg + "/loadBalancing/@algorithm",
      form: [{ sec: "", f: [
        s("Load balance algorithm", "Weighted round robin", ["Equal distribution", "Least current request", "Least response time", "Weighted round robin", "Weighted total traffic", "Server variable hash", "Query string hash", "Request hash"],
          "Equal distribution: istekler sırayla eşit dağıtılır.\n\nLeast current request: o an en az aktif isteği olan sunucuya gönderilir – istek süreleri farklıysa en dengeli seçenek.\n\nLeast response time: en hızlı yanıt veren sunucuya gönderilir.\n\nWeighted round robin: sunucuların Weight değerine göre oranlı sırayla dağıtılır (ör. 100/100/50).\n\nWeighted total traffic: gönderilen/alınan bayt miktarına göre ağırlıklı dağıtılır.\n\nServer variable hash / Query string hash / Request hash: belirli bir değerin (ör. bir başlık, sorgu parametresi veya URL) özetine göre hep aynı sunucu seçilir – önbellek isabetini artırır."),
        rd("Load distribution", "Even distribution", [["Even distribution", "Weighted algoritmalarda tüm sunucular eşit ağırlıkta sayılır."], ["Custom distribution", "Her sunucunun Servers özelliğindeki Weight değeri kullanılır."]], "Ağırlıklı algoritmalar için dağıtım biçimi."),
        t("Server variable / Query string", "", "Hash tabanlı algoritmalarda özeti alınacak sunucu değişkeni (ör. HTTP_X_TENANT) veya sorgu dizesi anahtarı.")] }],
      acts: [apply, cancel] },

    { id: "farmmon", n: "Monitoring and Management", svg: rack(B.monitor),
      d: "Çiftlikteki her sunucunun canlı durumunu ve istatistiklerini gösterir: kullanılabilirlik, sağlık durumu, anlık ve toplam istek sayısı, hatalı istekler, yanıt süresi. Bakım için bir sunucuyu buradan güvenle devreden çıkarabilirsiniz.",
      cfg: "(Çalışma zamanı istatistikleri)",
      list: { cols: [["Server", "Arka uç sunucunun adresi."], ["Status", "Available: istek alıyor. Unavailable: devre dışı (sağlık testi başarısız veya elle kapatıldı). Unavailable (Graceful): yeni bağlantı almıyor, mevcut oturumlar bitiyor."], ["Health Status", "Healthy / Unhealthy – Health Test sonucuna göre."], ["Current Requests", "Şu an bu sunucuda işlenen istek sayısı."], ["Total Requests", "İstatistiklerin son sıfırlanmasından beri gönderilen toplam istek."], ["Failed Requests", "Hata ile sonuçlanan istek sayısı."], ["Response Time (ms)", "Ortalama yanıt süresi."]],
        rows: [r("Sağlıklı ve istek alan sunucu.", "WEB01", "Available", "Healthy", "12", "184220", "31", "42"), r("", "WEB02", "Available", "Healthy", "9", "179804", "18", "47"), r("Sağlık testinde başarısız olan sunucu: yük dengeleyici bu sunucuya istek göndermiyor. Uygulama havuzunun durmuş olması, health URL'nin 500 dönmesi veya port/güvenlik duvarı sorunu sebep olabilir.", "10.0.0.23", "Unavailable", "Unhealthy", "0", "40112", "3120", "0")] },
      acts: [["Make Server Available", "▶️", "Seçili sunucuyu tekrar istek almaya açar."], ["Make Server Unavailable", "⏹️", "Sunucuyu hemen devreden çıkarır; mevcut istekler kesilebilir."], ["Disallow New Connections", "⏸️", "Yumuşak (graceful) devreden çıkarma: yeni bağlantı/oturum almaz, mevcut oturumlar tamamlanır. Bakım ve güncelleme öncesi ÖNERİLEN yöntemdir."], ["Reset Statistics", "♻️", "Seçili sunucunun sayaçlarını sıfırlar."], ["Refresh", "🔄", "İstatistikleri yeniler."]] },

    { id: "farmproxy", n: "Proxy", svg: rack(B.proxy),
      d: "ARR'nin ters vekil (reverse proxy) olarak istekleri arka uca nasıl ileteceğini belirler: zaman aşımı, HTTP sürümü, istemci IP'sinin aktarılması, yanıt arabelleği ve başlık ayarları.",
      cfg: farmCfg + "/protocol",
      form: [
        { sec: "", f: [
          t("Time-out (seconds)", "120", "Arka uç sunucunun yanıt vermesi için beklenecek süre. Aşılırsa istemciye 502.3 (Bad Gateway – timeout) döner. Uzun süren raporlar/dosya yüklemeleri varsa artırılır."),
          c("Keep alive", true, "ARR ile arka uç arasındaki TCP bağlantıları yeniden kullanılır; performansı artırır."),
          s("HTTP version", "Pass through", ["Pass through", "HTTP/1.0", "HTTP/1.1"], "Arka uca gönderilecek HTTP sürümü. Pass through: istemcinin sürümü korunur."),
          c("Reverse rewrite host in response headers", true, "Arka ucun Location gibi yanıt başlıklarında döndürdüğü iç sunucu adını (ör. WEB01) dışarıdaki host adıyla değiştirir; yönlendirmelerin istemciye iç adres sızdırmasını engeller."),
          c("Preserve client IP in the following header", true, "İstemcinin gerçek IP'si arka uca bir başlıkla aktarılır. Aksi halde arka uç günlüklerinde tüm istekler ARR sunucusunun IP'sinden geliyormuş gibi görünür."),
          t("Header name", "X-Forwarded-For", "İstemci IP'sinin yazılacağı başlık. Arka uç IIS günlüğüne bu başlığı özel alan olarak ekleyerek gerçek IP'yi kaydedebilirsiniz."),
          c("Include TCP port from client IP", false, "Başlığa IP ile birlikte istemci portunu da ekler (ör. 203.0.113.5:51522). Çoğu uygulama bunu beklemediğinden genellikle kapatılır.")] },
        { sec: "Buffer Settings", f: [
          t("Response buffer (KB)", "256", "Arka uç yanıtının istemciye gönderilmeden önce arabelleğe alınan miktarı."),
          t("Response buffer threshold (KB)", "0", "Bu boyuttan sonra yanıt arabelleğe alınmadan akıtılır (streaming)."),
          t("Maximum response header (KB)", "64", "Arka uçtan kabul edilecek en büyük yanıt başlığı boyutu. Büyük çerezlerde 502.4 hatası alınıyorsa artırılır.")] },
        { sec: "Proxy Type", f: [c("Use URL Rewrite to inspect incoming requests", true, "Gelen isteklerin URL Rewrite kurallarıyla incelenip çiftliğe yönlendirilmesi (standart ters vekil kullanımı)."), c("Enable proxy", true, "Sunucu düzeyinde ARR proxy işlevini açar. Kapalıysa 'Route to Server Farm' kuralları çalışmaz.")] }],
      acts: [apply, cancel] },

    { id: "farmrouting", n: "Routing Rules", svg: rack(B.routing),
      d: "Bu çiftliğe istek yönlendiren kuralların genel ayarlarıdır. Asıl kurallar URL Rewrite modülünde tutulur; 'URL Rewrite...' eylemi ile ayrıntılı düzenlenir. Çiftlik oluşturulurken IIS genellikle 'ARR_WebFarm01_loadbalance' adında, tüm istekleri (*) bu çiftliğe yönlendiren bir sunucu düzeyi kural oluşturur.",
      cfg: "system.webServer/rewrite/globalRules",
      form: [{ sec: "", f: [
        c("Use URL Rewrite to inspect incoming requests", true, "İstekler URL Rewrite kurallarına göre bu çiftliğe yönlendirilir."),
        c("Enable SSL offloading", true, "SSL sonlandırma: HTTPS bağlantısı bu (ARR) sunucuda çözülür, arka uca HTTP ile gidilir. Arka uç sunucuların CPU yükünü azaltır ve sertifikayı tek yerde yönetmenizi sağlar. Arka uç ağı güvenli değilse kapatılıp arka uca da HTTPS kullanılmalıdır."),
        ["b", "URL Rewrite...", "", "Sunucu düzeyindeki URL Rewrite sayfasını açar; buradaki 'Route to Server Farm' eylemli kuralları (koşullar, desenler, hariç tutulan yollar) düzenleyebilirsiniz."],
        ["l", "Advanced Routing", "URL Rewrite kuralları", "Sorgu dizesine, host adına veya başlığa göre farklı çiftliklere yönlendirme (ör. /api → ApiFarm, /images → StaticFarm) URL Rewrite kurallarıyla yapılır."]] }],
      acts: [apply, cancel] },

    { id: "farmaffinity", n: "Server Affinity", svg: rack(B.affinity),
      d: "Oturum bağlılığı (sticky session). Etkinleştirilirse aynı istemciden gelen istekler hep aynı arka uç sunucuya gönderilir. InProc oturum durumu (Session) kullanan ve oturumları sunucular arasında paylaşmayan uygulamalar için gereklidir. ARR bunu 'ARRAffinity' adlı bir çerezle yapar.",
      cfg: farmCfg + "/affinity",
      form: [{ sec: "", f: [
        c("Client affinity", false, "Oturum bağlılığını açar. DİKKAT: Yük dengesini bozabilir; mümkünse oturumları SQL/State Server/Redis'te tutup bu ayarı kapalı bırakmak daha iyi ölçeklenir."),
        c("Host name affinity", false, "Aynı host adına gelen istekler aynı sunucuya gönderilir (paylaşımlı barındırma senaryoları)."),
        t("Cookie name", "ARRAffinity", "Bağlılık için kullanılan çerezin adı. Değeri, seçilen sunucunun özetidir."),
        c("Include cookie domain", false, "Çereze Domain özniteliği eklenir; alt alan adları arasında bağlılığın korunmasını sağlar."),
        c("Use secure cookie (SameSite=None; Secure)", false, "Çerezi yalnızca HTTPS üzerinden gönderilecek şekilde işaretler.")] }],
      acts: [apply, cancel] },

    { id: "farmservers", n: "Servers", svg: rack(B.servers),
      d: "Çiftliğe dahil arka uç sunucuların listesi. Her sunucu için adres, HTTP/HTTPS portları, ağırlık (Weight) ve çevrimiçi durumu tanımlanır. Ağırlıklı yük dengelemede daha güçlü sunucuya daha yüksek Weight verilir.",
      cfg: "webFarms/webFarm[@name='WebFarm01']/server",
      list: { cols: [["Server Address", "Arka uç sunucunun adı, FQDN'i veya IP adresi. ARR sunucusunun bu adı DNS'ten çözebilmesi gerekir."], ["HTTP Port", "Arka uca HTTP ile gidilirken kullanılacak port."], ["HTTPS Port", "Arka uca HTTPS ile gidilirken kullanılacak port (SSL offloading kapalıysa)."], ["Weight", "Ağırlıklı algoritmalardaki pay. 100/100/50 → üçüncü sunucu diğerlerinin yarısı kadar istek alır."], ["Online", "False ise sunucu çiftlikte tanımlı kalır ama istek almaz."]],
        rows: [r("", "WEB01", "80", "443", "100", "True"), r("", "WEB02", "80", "443", "100", "True"), r("Farklı portta yayın yapan ve daha düşük ağırlıklı (daha zayıf) örnek sunucu.", "10.0.0.23", "8080", "8443", "50", "True")] },
      acts: [["Add Server...", "➕", "Çiftliğe sunucu ekler.", "addFarmServer"], ["Edit...", "📝", "Seçili sunucunun portlarını, ağırlığını ve durumunu düzenler."], ["Remove", "❌", "Seçili sunucuyu çiftlikten çıkarır."], ["Set Online / Offline", "⏯️", "Sunucunun Online ayarını değiştirir."]] }
  ];
  F.forEach((f) => Object.assign(f, { g: "Server Farm", lv: "farm" }));
  IIS.features.push(...F);

  /* Sunucu düzeyinde ARR Cache özelliği */
  IIS.features.push({
    id: "arrcache", n: "Application Request Routing Cache", g: "IIS", lv: "server", svg: rack(B.arrcache),
    d: "Application Request Routing'in sunucu düzeyi ayarlarıdır. Disk önbelleği için kullanılacak sürücüleri (cache drives) tanımlar, önbellekteki nesneleri görüntülemenizi/silmenizi sağlar ve 'Server Proxy Settings' ile sunucu genelinde ters vekil (proxy) özelliğini açıp kapatırsınız. URL Rewrite kuralında başka bir sunucuya (http://...) yeniden yazma yapabilmek için buradan proxy'nin etkinleştirilmesi gerekir; aksi halde 404 alınır.",
    cfg: "system.webServer/diskCache + proxy",
    list: { cols: [["Drive Location", "Önbellek dosyalarının yazılacağı klasör veya sürücü. Hızlı (SSD) ve sistem diskinden ayrı bir disk önerilir."], ["Max Size (MB)", "Bu sürücüde kullanılacak en fazla alan. Dolunca en az kullanılan içerik silinir."]],
      rows: [r("Örnek önbellek sürücüsü.", "D:\\ARRCache", "20480")] },
    acts: [["Server Proxy Settings...", "⚙️", "Sunucu genelinde proxy'yi etkinleştirir (Enable proxy) ve zaman aşımı, X-Forwarded-For, arabellek gibi varsayılan proxy ayarlarını düzenler."], ["Add Drive...", "➕", "Yeni bir disk önbelleği konumu ekler."], ["Remove Drive", "❌", "Seçili önbellek sürücüsünü kaldırır."], ["Browse Objects", "👁️", "Önbellekteki nesneleri (URL, boyut, son erişim) listeler."], ["Delete All Cached Objects...", "🗑️", "Tüm önbelleği temizler – içerik güncellendiğinde eski sürümün gösterilmesini önlemek için kullanılır."]]
  });

  /* URL Rewrite sayfasına çiftlik kuralını ekle */
  const rw = IIS.features.find((f) => f.id === "rewrite");
  if (rw) rw.list.rows.push(r("ARR ile çiftlik oluşturulurken otomatik eklenen sunucu düzeyi kural: tüm istekleri WebFarm01 sunucu çiftliğine yönlendirir. Statik dosyaları veya bazı yolları ön uçta tutmak için koşul eklenebilir.", "ARR_WebFarm01_loadbalance", "URL path after '/'", "Matches", "*", "Route to Server Farm", "http://WebFarm01/{R:0}", "True", "Inherited"));

  /* Rol hizmetleri penceresi için not */
  IIS.farmNote = "Application Request Routing 3.0 ve URL Rewrite 2.1, Sunucu Yöneticisi rol listesinde yer almaz; Microsoft'un IIS sitesinden ayrı MSI paketleri olarak kurulur. Kurulumdan sonra IIS Yöneticisi'nde 'Server Farms' düğümü ve 'Application Request Routing Cache' simgesi belirir.";
})();
