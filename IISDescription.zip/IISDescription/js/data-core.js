/* IIS Yardım Masası – temel veriler (ağaç, havuzlar, siteler, eylemler) */
window.IIS = window.IIS || {};

IIS.server = { name: "WIN-IIS01", user: "WIN-IIS01\\Administrator", version: "IIS 10.0" };

/* ---------- Ağaç düğümleri ---------- */
IIS.tree = [
  { id: "start", type: "start", n: "Start Page", ic: "🏠",
    h: "IIS Yöneticisi açıldığında görünen başlangıç sayfasıdır. Buradan yerel sunucuya, uzak bir sunucuya, bir siteye veya uygulamaya bağlantı kurabilir, son bağlantılarınızı görebilirsiniz." },
  { id: "server", type: "server", n: "WIN-IIS01 (WIN-IIS01\\Administrator)", short: "WIN-IIS01", ic: "🖥️", open: true,
    h: "Sunucu (makine) düğümüdür. Burada yaptığınız ayarlar sunucu düzeyinde, yani applicationHost.config ve kök web.config dosyalarına yazılır ve aksi belirtilmedikçe bu sunucudaki TÜM sitelere ve uygulamalara miras olarak geçer.",
    children: [
      { id: "pools", type: "pools", n: "Application Pools", ic: "🗂️",
        h: "Uygulama havuzları (Application Pools) listesidir. Her havuz bir veya daha fazla w3wp.exe çalışan süreci (worker process) ile temsil edilir. Havuzlar uygulamaları birbirinden yalıtır: bir havuzdaki çökme veya bellek sızıntısı diğer havuzlardaki uygulamaları etkilemez." },
      { id: "sites", type: "sites", n: "Sites", ic: "🌐", open: true,
        h: "Bu sunucuda tanımlı web sitelerinin listesidir. Her sitenin bir veya daha fazla bağlaması (binding: protokol + IP + port + host adı), bir fiziksel yolu ve bir varsayılan uygulama havuzu vardır.",
        children: [
          { id: "site1", type: "site", siteIdx: 0, n: "Default Web Site", ic: "🌍", open: true,
            h: "IIS kurulduğunda otomatik oluşturulan varsayılan sitedir (ID=1). Varsayılan olarak 80 portunu dinler ve C:\\inetpub\\wwwroot klasörünü sunar.",
            children: [
              { id: "app1", type: "app", n: "api", ic: "📦", h: "Bu bir UYGULAMADIR (Application). Kendi uygulama havuzu, kendi web.config kök ayarları ve kendi AppDomain'i olabilir. Simge olarak dünya/kutu ile gösterilir; normal klasörden farkı budur." },
              { id: "vdir1", type: "vdir", n: "images", ic: "🔗", h: "Bu bir SANAL DİZİNDİR (Virtual Directory). URL'de /images olarak görünür ama fiziksel olarak sitenin klasörü dışındaki başka bir yolu (örn. D:\\Medya\\Resimler veya bir ağ paylaşımı) gösterebilir. Kendi uygulama havuzu yoktur, üst uygulamaya aittir." },
              { id: "fold1", type: "folder", n: "aspnet_client", ic: "📁", h: "Sitenin fiziksel klasörü içindeki sıradan bir KLASÖRDÜR. Klasör düzeyinde de birçok özelliği (kimlik doğrulama, varsayılan belge vb.) ayrıca yapılandırabilirsiniz; ayarlar o klasördeki web.config dosyasına yazılır." }
            ] },
          { id: "site2", type: "site", siteIdx: 1, n: "Intranet", ic: "🌍",
            h: "Örnek ikinci site: Şirket içi (intranet) uygulaması. intranet.firma.local host adıyla HTTPS üzerinden yayın yapar.",
            children: [
              { id: "app2", type: "app", n: "ik", ic: "📦", h: "Intranet sitesi altında 'ik' (İnsan Kaynakları) adında ayrı bir uygulama. Kendi uygulama havuzu (IKAppPool) ile çalışır." }
            ] },
          { id: "site3", type: "site", siteIdx: 2, n: "ShopApi", ic: "🌍",
            h: "Örnek üçüncü site: .NET Core / ASP.NET Core ile yazılmış bir API. ASP.NET Core Module (ANCM) üzerinden çalışır, bu nedenle havuzunun .NET CLR sürümü 'No Managed Code' olarak ayarlanmıştır." }
        ] }
    ] }
];

/* ---------- Uygulama havuzları ---------- */
IIS.pools = [
  { name: "DefaultAppPool", status: "Started", clr: "v4.0", mode: "Integrated", identity: "ApplicationPoolIdentity", apps: 2 },
  { name: ".NET v4.5", status: "Started", clr: "v4.0", mode: "Integrated", identity: "ApplicationPoolIdentity", apps: 0 },
  { name: ".NET v4.5 Classic", status: "Started", clr: "v4.0", mode: "Classic", identity: "ApplicationPoolIdentity", apps: 0 },
  { name: "Classic .NET AppPool", status: "Started", clr: "v2.0", mode: "Classic", identity: "ApplicationPoolIdentity", apps: 0 },
  { name: "IntranetPool", status: "Started", clr: "v4.0", mode: "Integrated", identity: "NetworkService", apps: 1 },
  { name: "IKAppPool", status: "Stopped", clr: "v4.0", mode: "Integrated", identity: "FIRMA\\svc_ik", apps: 1 },
  { name: "ShopApiPool", status: "Started", clr: "No Managed Code", mode: "Integrated", identity: "ApplicationPoolIdentity", apps: 1 }
];

IIS.poolCols = [
  ["Name", "Uygulama havuzunun benzersiz adı. Varsayılan olarak her yeni siteyle aynı adda bir havuz oluşturulur. Havuz kimliği ApplicationPoolIdentity ise Windows'ta 'IIS AppPool\\<HavuzAdı>' adlı sanal bir hesap oluşur; klasör izinleri bu hesaba verilir."],
  ["Status", "Havuzun durumu: Started (çalışıyor, istekleri kabul ediyor) veya Stopped (durduruldu; bu havuzdaki uygulamalara gelen isteklere HTTP 503 Service Unavailable döner)."],
  [".NET CLR Version", "Havuzun yükleyeceği .NET Framework CLR sürümü. v4.0 = .NET Framework 4.x uygulamaları, v2.0 = .NET 2.0/3.0/3.5 uygulamaları. ASP.NET Core, PHP, statik siteler için 'No Managed Code' seçilir; böylece gereksiz CLR yüklenmez."],
  ["Managed Pipeline Mode", "Integrated: IIS ve ASP.NET istek işleme hattı birleşiktir, yönetilen modüller tüm isteklere (statik dosyalar dahil) uygulanabilir – modern varsayılandır. Classic: IIS 6 uyumluluğu için ASP.NET, aspnet_isapi.dll üzerinden ayrı bir ISAPI uzantısı olarak çalışır."],
  ["Identity", "Çalışan sürecin (w3wp.exe) hangi Windows hesabıyla çalışacağı. ApplicationPoolIdentity (önerilen, en az ayrıcalık), NetworkService, LocalService, LocalSystem (tehlikeli – tam yetki) veya özel bir domain/yerel hesap olabilir."],
  ["Applications", "Bu havuzu kullanan uygulama sayısı. Bir havuzu silmeden önce bu sayının 0 olması gerekir; aksi halde bağlı uygulamalar çalışamaz."]
];

/* Gelişmiş Ayarlar – Uygulama Havuzu */
IIS.poolAdvanced = [
  { cat: "(General)", props: [
    [".NET CLR Version", "v4.0", "Havuzun yükleyeceği CLR sürümü (v2.0, v4.0 veya No Managed Code). Yanlış sürüm seçilirse uygulama derleme/yükleme hataları verir.", "managedRuntimeVersion", "b"],
    ["Enable 32-Bit Applications", "False", "True yapılırsa çalışan süreç 64 bit Windows üzerinde WOW64 ile 32 bit olarak çalışır. Yalnızca 32 bit olan eski COM bileşenleri, Jet/Access OLEDB sürücüleri veya 32 bit DLL'ler kullanan uygulamalar için açılır. 32 bit süreç en fazla ~4 GB bellek kullanabilir.", "enable32BitAppOnWin64"],
    ["Managed Pipeline Mode", "Integrated", "Integrated veya Classic. Integrated modda ASP.NET modülleri IIS hattına doğrudan katılır. Classic yalnızca eski (IIS 6 dönemi) uygulamalar için kullanılmalıdır.", "managedPipelineMode"],
    ["Name", "DefaultAppPool", "Havuzun adı. Sadece okunur (gri) gösterilir; değiştirmek için Actions bölmesindeki Rename kullanılır.", "name", "ro"],
    ["Queue Length", "1000", "HTTP.sys'in bu havuz için kuyruğa alabileceği en fazla istek sayısı. Kuyruk dolarsa yeni isteklere HTTP 503 (Service Unavailable – QueueFull) döner. Ani trafik artışlarında yükseltilebilir (ör. 5000), ancak asıl sorun yavaş uygulama ise sadece bekleme süresini uzatır.", "queueLength", "b"],
    ["Start Mode", "OnDemand", "OnDemand: Çalışan süreç ilk istek geldiğinde başlatılır. AlwaysRunning: IIS/WAS başlar başlamaz süreç ayağa kalkar; ilk istekteki 'soğuk başlama' gecikmesini önler. Application Initialization ve Preload Enabled ile birlikte kullanılır.", "startMode"]
  ]},
  { cat: "CPU", props: [
    ["Limit (percent)", "0", "Havuzun bir 'Limit Interval' süresi boyunca kullanabileceği en fazla CPU yüzdesi. 0 = sınır yok. Ör. 50 yazarsanız havuz toplam CPU'nun %50'sinden fazlasını kullandığında 'Limit Action' uygulanır.", "cpu/limit (1/1000 cinsinden saklanır)"],
    ["Limit Action", "NoAction", "CPU sınırı aşıldığında ne yapılacağı: NoAction (yalnızca olay günlüğüne yazar), KillW3wp (süreci sonlandırır, havuz durur), Throttle (CPU kullanımını sınırlar), ThrottleUnderLoad (yalnızca sistemde CPU çekişmesi varken sınırlar).", "cpu/action"],
    ["Limit Interval (minutes)", "5", "CPU kullanımının ölçüldüğü ve sıfırlandığı süre (dakika). Limit bu aralık içinde değerlendirilir.", "cpu/resetInterval"],
    ["Processor Affinity Enabled", "False", "True yapılırsa çalışan süreçler yalnızca 'Processor Affinity Mask' ile belirtilen CPU çekirdeklerinde çalışır. Lisanslama veya kaynak ayırma senaryolarında kullanılır.", "cpu/smpAffinitized"],
    ["Processor Affinity Mask", "4294967295", "Hangi işlemcilerin kullanılacağını belirten bit maskesi (onaltılık 0xFFFFFFFF = tüm çekirdekler). Ör. 3 = sadece CPU0 ve CPU1.", "cpu/smpProcessorAffinityMask"],
    ["Processor Affinity Mask (64-bit option)", "4294967295", "32'den fazla mantıksal işlemcisi olan sistemlerde üst 32 çekirdek için bit maskesi.", "cpu/smpProcessorAffinityMask2"],
    ["Processor Group", "0", "64'ten fazla mantıksal işlemcisi olan sunucularda Windows işlemcileri gruplara ayırır. Bu ayar çalışan sürecin hangi işlemci grubunda çalışacağını belirler (Processor Affinity ile birlikte kullanılır).", "cpu/processorGroup"]
  ]},
  { cat: "Process Model", props: [
    { sub: "Generate Process Model Event Log Entry", collapsed: true, h: "Süreç modeliyle ilgili olaylarda (ör. boşta kalma zaman aşımı nedeniyle kapanma) Windows olay günlüğüne kayıt yazılıp yazılmayacağını belirleyen alt ayarlar.", cfg: "processModel/logEventOnProcessModel", props: [
      ["Idle Time-out Reached", "True", "Çalışan süreç boşta kalma süresi dolduğu için kapatıldığında olay günlüğüne kayıt yazılır (WAS olay kimliği 5186).", "logEventOnProcessModel=IdleTimeout"]] },
    ["Identity", "ApplicationPoolIdentity", "Çalışan sürecin kimliği. ApplicationPoolIdentity: her havuz için otomatik oluşturulan, en az yetkili sanal hesap (önerilen). NetworkService: ağda bilgisayar hesabıyla görünür. LocalService: düşük yetkili yerel hesap. LocalSystem: yönetici üstü yetki – güvenlik riski! Custom account: belirli bir kullanıcı (ör. SQL Server'a Windows kimliğiyle bağlanmak için).", "processModel/identityType", "b"],
    ["Idle Time-out (minutes)", "20", "Hiç istek gelmezse çalışan sürecin kaç dakika sonra kapatılacağı. 0 = asla kapanma. Kapanan süreç sonraki istekte yeniden başlar (ilk istek yavaş olur). Sık kullanılan iç uygulamalarda 0 yapılabilir.", "processModel/idleTimeout"],
    ["Idle Time-out Action", "Terminate", "Boşta kalma süresi dolunca: Terminate (süreci kapat, belleği boşalt) veya Suspend (süreci askıya al; bellekte kalır ama CPU kullanmaz, sonraki istekte çok hızlı devam eder).", "processModel/idleTimeoutAction"],
    ["Load User Profile", "False", "True ise kimlik hesabının kullanıcı profili (HKCU kayıt defteri, %TEMP% klasörü) yüklenir. Bazı kriptografi ve COM işlemleri için gereklidir.", "processModel/loadUserProfile", "b"],
    ["Maximum Worker Processes", "1", "Bu havuz için açılacak en fazla w3wp.exe sayısı. 1'den büyükse 'Web Garden' oluşur. DİKKAT: InProc oturum durumu ve bellek içi önbellek süreçler arasında paylaşılmaz; oturumlar kaybolabilir. 0 yazılırsa NUMA düğüm sayısı kadar süreç açılır.", "processModel/maxProcesses"],
    ["Ping Enabled", "True", "WAS'ın çalışan süreci düzenli olarak 'yaşıyor musun' diye yoklayıp yoklamayacağı. Yanıt vermeyen (kilitlenmiş) süreç sonlandırılıp yenisi başlatılır. Hata ayıklayıcı (debugger) bağlıyken False yapılır.", "processModel/pingingEnabled"],
    ["Ping Maximum Response Time (seconds)", "90", "Ping'e yanıt için beklenecek en fazla süre. Bu sürede yanıt gelmezse süreç sağlıksız sayılır ve sonlandırılır.", "processModel/pingResponseTime"],
    ["Ping Period (seconds)", "30", "İki ping arasındaki süre (saniye).", "processModel/pingInterval"],
    ["Shutdown Time Limit (seconds)", "90", "Süreç kapatılırken (geri dönüşüm, durdurma) devam eden isteklerin tamamlanması için tanınan süre. Süre dolunca süreç zorla sonlandırılır.", "processModel/shutdownTimeLimit"],
    ["Startup Time Limit (seconds)", "90", "Çalışan sürecin başlayıp hazır olması için tanınan süre. Ağır uygulama başlangıçlarında yükseltilebilir.", "processModel/startupTimeLimit"]
  ]},
  { cat: "Process Orphaning", props: [
    ["Enabled", "False", "True ise sağlıksız bulunan süreç sonlandırılmaz, 'yetim' bırakılır ve yerine yenisi başlatılır. Böylece kilitlenmiş süreçten bellek dökümü (dump) alınabilir. Sadece sorun giderme amacıyla açılmalı.", "failure/orphanWorkerProcess"],
    ["Executable", "", "Süreç yetim bırakıldığında çalıştırılacak program (ör. procdump.exe veya bir hata ayıklayıcı).", "failure/orphanActionExe"],
    ["Executable Parameters", "", "Yukarıdaki programa geçilecek parametreler. %1% yetim sürecin PID'si ile değiştirilir. Ör: -ma %1% C:\\dumps", "failure/orphanActionParams"]
  ]},
  { cat: "Rapid-Fail Protection", props: [
    ["\"Service Unavailable\" Response Type", "HttpLevel", "Havuz durdurulduğunda isteklere nasıl yanıt verileceği. HttpLevel: HTTP.sys 503 hata sayfası döner. TcpLevel: bağlantı doğrudan kesilir – yük dengeleyicilerin (load balancer) sunucuyu hızlıca devre dışı sayması için kullanışlıdır.", "failure/loadBalancerCapabilities"],
    ["Enabled", "True", "Hızlı Hata Koruması. Çalışan süreç belirtilen süre içinde belirtilen sayıda çökerse havuz otomatik olarak DURDURULUR ve 503 dönülür. Sürekli çöküp yeniden başlayan bir uygulamanın sunucuyu meşgul etmesini engeller.", "failure/rapidFailProtection"],
    ["Failure Interval (minutes)", "5", "Çökmelerin sayıldığı zaman penceresi (dakika).", "failure/rapidFailProtectionInterval"],
    ["Maximum Failures", "5", "Yukarıdaki süre içinde izin verilen en fazla çökme sayısı. Aşılırsa havuz durur.", "failure/rapidFailProtectionMaxCrashes"],
    ["Shutdown Executable", "", "Hızlı hata koruması havuzu durdurduğunda çalıştırılacak program (ör. uyarı e-postası gönderen bir script).", "failure/autoShutdownExe"],
    ["Shutdown Executable Parameters", "", "Shutdown Executable'a geçilecek parametreler.", "failure/autoShutdownParams"]
  ]},
  { cat: "Recycling", props: [
    ["Disable Overlapped Recycle", "False", "False (varsayılan): Geri dönüşümde önce YENİ süreç başlatılır, eski süreç mevcut istekleri bitirip kapanır – kesinti olmaz. True: önce eski süreç kapanır, sonra yenisi başlar. Aynı anda iki sürecin çalışamayacağı (ör. bir dosyayı kilitleyen) uygulamalarda kullanılır.", "recycling/disallowOverlappingRotation"],
    ["Disable Recycling for Configuration Changes", "False", "False ise havuz ayarları değiştiğinde süreç otomatik geri dönüştürülür. True ise değişiklikler sonraki geri dönüşüme kadar uygulanmaz.", "recycling/disallowRotationOnConfigChange"],
    { sub: "Generate Recycle Event Log Entry", h: "Hangi geri dönüşüm nedenlerinin Windows olay günlüğüne (System, kaynak: WAS) yazılacağını seçen alt ayarlar. Beklenmedik geri dönüşümleri teşhis etmek için hepsini True yapmak faydalıdır.", cfg: "recycling/logEventOnRecycle", props: [
      ["Application Pool Configuration Changed", "True", "Havuzun yapılandırması değiştiği için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=ConfigChange", "b"],
      ["Isapi Reported Unhealthy", "True", "Bir ISAPI uzantısı kendini sağlıksız bildirdiği için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=IsapiUnhealthy", "b"],
      ["Manual Recycle", "True", "Yönetici tarafından elle (Recycle... eylemi, appcmd recycle) yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=OnDemand", "b"],
      ["Private Memory Limit Exceeded", "True", "Özel bellek sınırı aşıldığı için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=PrivateMemory"],
      ["Regular Time Interval", "True", "Düzenli zaman aralığı (varsayılan 1740 dk) dolduğu için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=Time"],
      ["Request Limit Exceeded", "True", "İstek sınırına ulaşıldığı için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=Requests", "b"],
      ["Specific Time", "True", "Belirli bir saatte planlanmış geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=Schedule", "b"],
      ["Virtual Memory Limit Exceeded", "True", "Sanal bellek sınırı aşıldığı için yapılan geri dönüşümler günlüğe yazılır.", "logEventOnRecycle=Memory"]] },
    ["Private Memory Limit (KB)", "0", "Çalışan sürecin özel (private) bellek kullanımı bu değeri aşarsa süreç geri dönüştürülür. 0 = sınır yok. Bellek sızıntısı olan uygulamalarda koruma sağlar (ör. 2097152 = 2 GB).", "recycling/periodicRestart/privateMemory"],
    ["Regular Time Interval (minutes)", "1740", "Süreç bu kadar dakika çalıştıktan sonra düzenli olarak geri dönüştürülür. Varsayılan 1740 dk = 29 saat (her gün farklı saate kayması için). 0 = devre dışı. Birçok yönetici bunu 0 yapıp 'Specific Times' ile gece saatine sabitler.", "recycling/periodicRestart/time"],
    ["Request Limit", "0", "Süreç bu sayıda istek işledikten sonra geri dönüştürülür. 0 = sınır yok.", "recycling/periodicRestart/requests"],
    ["Specific Times", "TimeSpan[] Array", "Günün belirli saatlerinde (ör. 03:00) geri dönüşüm yapılmasını sağlar. Trafiğin en düşük olduğu saat seçilmelidir.", "recycling/periodicRestart/schedule", "b"],
    ["Virtual Memory Limit (KB)", "0", "Sanal bellek kullanımı bu değeri aşarsa geri dönüşüm yapılır. 64 bit süreçlerde sanal bellek çok büyük olabildiğinden genellikle 0 bırakılır; Private Memory Limit tercih edilir.", "recycling/periodicRestart/memory"]
  ]}
];

/* ---------- Siteler ---------- */
IIS.sites = [
  { name: "Default Web Site", id: 1, status: "Started", bindings: "*:80 (http)", path: "%SystemDrive%\\inetpub\\wwwroot", pool: "DefaultAppPool",
    bl: [["http", "", "80", "*"], ["net.tcp", "", "", "808:*"]] },
  { name: "Intranet", id: 2, status: "Started", bindings: "intranet.firma.local on *:443 (https)", path: "D:\\Web\\Intranet", pool: "IntranetPool",
    bl: [["https", "intranet.firma.local", "443", "*"], ["http", "intranet.firma.local", "80", "*"]] },
  { name: "ShopApi", id: 3, status: "Stopped", bindings: "api.shop.com on 10.0.0.15:443 (https)", path: "D:\\Web\\ShopApi\\publish", pool: "ShopApiPool",
    bl: [["https", "api.shop.com", "443", "10.0.0.15"]] }
];

IIS.siteCols = [
  ["Name", "Sitenin IIS içindeki görünen adı. Yalnızca yönetim amaçlıdır, URL'yi etkilemez."],
  ["ID", "Sitenin benzersiz sayısal kimliği. Günlük (log) klasör adlarında kullanılır: ör. W3SVC1 = ID'si 1 olan site."],
  ["Status", "Started: site bağlamalarını dinliyor. Stopped: site istek kabul etmez. 'Unknown' görünüyorsa genellikle aynı IP:Port:Host bağlamasını kullanan başka bir site çalışıyordur."],
  ["Binding", "Sitenin dinlediği protokol, IP adresi, port ve host adı birleşimleri. Aynı sunucudaki iki sitenin bağlaması birebir aynı olamaz."],
  ["Path", "Sitenin kök fiziksel klasörü. Uygulama havuzu kimliğinin bu klasörde en az okuma izni olmalıdır."]
];

IIS.siteAdvanced = [
  { cat: "(General)", props: [
    ["Application Pool", "DefaultAppPool", "Sitenin kök uygulamasının çalışacağı uygulama havuzu. Alt uygulamalar farklı havuz kullanabilir. Değeri seçince sağda çıkan '...' düğmesiyle havuz listesinden seçim yapılır.", "applicationPool", "b"],
    ["Bindings", "http:*:80:", "Sitenin bağlamaları (protokol:IP:port:host). Burada salt okunurdur (gri); düzenlemek için Actions bölmesindeki Bindings... eylemini kullanın.", "bindings", "ro"],
    ["ID", "1", "Sitenin benzersiz kimliği. Log klasörü (W3SVC<ID>) ve FREB klasörü bu numarayı kullanır. Değiştirilebilir ama log klasör adı da değişir.", "id", "b"],
    ["Name", "Default Web Site", "Sitenin adı. Burada salt okunurdur; değiştirmek için ağaçta siteye sağ tıklayıp Rename kullanılır.", "name", "ro"],
    ["Physical Path", "%SystemDrive%\\inetpub\\wwwroot", "Sitenin içeriğinin bulunduğu klasör. UNC yolu (\\\\sunucu\\paylasim) da olabilir. Uygulama havuzu kimliğinin bu klasörde okuma izni olmalıdır.", "physicalPath", "b"],
    ["Physical Path Credentials", "", "Fiziksel yola (özellikle ağ paylaşımına) erişirken kullanılacak özel kullanıcı hesabı. Boş ise 'Pass-through authentication' kullanılır: istek, kimliği doğrulanmış kullanıcı veya anonim kimlik/havuz kimliği ile dosyaya erişir.", "userName"],
    ["Physical Path Credentials Logon Type", "ClearText", "Yukarıdaki özel hesapla oturum açma türü: ClearText (varsayılan), Interactive, Batch, Network.", "logonMethod"],
    ["Preload Enabled", "False", "True ise havuz başlatılınca uygulama, ilk istek beklenmeden 'ısıtılır' (Application Initialization rol hizmeti gerekir). Havuzun Start Mode = AlwaysRunning olmasıyla birlikte kullanılır; ilk istekteki yavaşlığı ortadan kaldırır.", "preloadEnabled"]
  ]},
  { cat: "Behavior", props: [
    ["Enabled Protocols", "http", "Sitede etkin protokoller (virgülle ayrılmış). WCF için net.tcp, net.pipe eklenebilir. https için ayrıca yazmaya gerek yoktur; http yeterlidir.", "enabledProtocols"],
    { sub: "Failed Request Tracing", h: "Bu site için Başarısız İstek İzleme (FREB) günlüğünün ayarları. Kuralların kendisi 'Failed Request Tracing Rules' özelliğinden tanımlanır.", cfg: "traceFailedRequestsLogging", props: [
      ["Directory", "C:\\inetpub\\logs\\FailedReqLogFiles", "FREB XML dosyalarının yazılacağı klasör. Site ID'sine göre W3SVC<ID> alt klasörü oluşturulur. Dosyalar freb.xsl ile tarayıcıda okunabilir.", "directory", "b"],
      ["Enabled", "True", "Bu site için FREB'in etkin olup olmadığı. Kural tanımlamak tek başına yetmez; burası da True olmalıdır.", "enabled", "b"],
      ["Maximum Number of Trace Files", "1", "Klasörde tutulacak en fazla iz dosyası sayısı (varsayılan 50). Dolunca en eski dosyalar silinir.", "maxLogFiles", "b"]] },
    { sub: "HSTS", h: "HTTP Strict Transport Security ayarları (IIS 10.0 1709 / Windows Server 2019 ve sonrası).", cfg: "hsts", props: [
      ["Enabled", "False", "True ise HTTPS yanıtlarına Strict-Transport-Security başlığı eklenir; tarayıcı bundan sonra bu siteye yalnızca HTTPS ile bağlanır.", "enabled"],
      ["IncludeSubDomains", "False", "True ise kural tüm alt alan adlarına da uygulanır.", "includeSubDomains"],
      ["Max-Age", "0", "Tarayıcının HSTS kuralını hatırlayacağı süre (saniye). Ör. 31536000 = 1 yıl.", "max-age"],
      ["Preload", "False", "Tarayıcıların HSTS ön yükleme listesine dahil edilmeye uygunluk işareti (preload) ekler.", "preload"],
      ["Redirect Http to Https", "False", "True ise HTTP istekleri otomatik olarak HTTPS'e (301) yönlendirilir.", "redirectHttpToHttps"]] },
    { sub: "Limits", h: "TCP/IP bağlantılarını ve bant genişliğini denetleyen özellikler.", cfg: "limits", props: [
      ["Connection Time-out (seconds)", "120", "Boşta kalan bir istemci bağlantısının sunucu tarafından kapatılmadan önce bekleneceği süre.", "connectionTimeout"],
      ["Maximum Bandwidth (Bytes/second)", "4294967295", "Siteye ayrılan en fazla bant genişliği. 4294967295 = sınırsız.", "maxBandwidth"],
      ["Maximum Concurrent Connections", "4294967295", "Siteye aynı anda açılabilecek en fazla bağlantı. 4294967295 = sınırsız. Aşılırsa yeni bağlantılar reddedilir (503).", "maxConnections"],
      ["Maximum Url Segments", "32", "URL yolunda izin verilen en fazla segment (/ ile ayrılmış parça) sayısı.", "maxUrlSegments", "b"]] }
  ]}
];

/* ---------- Eylemler (Actions) ---------- */
/* {g: grup başlığı} veya [ad, simge, yardım, diyalogId?] */
IIS.actions = {
  start: [
    { g: "Connection Tasks" },
    ["Connect to localhost", "🖥️", "Bu bilgisayardaki (yerel) IIS sunucusuna bağlanır ve ağaçta sunucu düğümünü açar."],
    ["Connect to a Server...", "🔌", "Uzaktaki bir IIS sunucusuna bağlanır. Uzak sunucuda 'Management Service' (WMSVC, varsayılan port 8172) kurulu ve etkin olmalıdır."],
    ["Connect to a Site...", "🌐", "Uzak sunucudaki yalnızca belirli bir siteye bağlanır. Site yöneticisi yetkisi verilmiş (IIS Manager Permissions) kullanıcılar için kullanılır."],
    ["Connect to an Application...", "📦", "Uzak sunucudaki yalnızca belirli bir uygulamaya bağlanır."],
    ["Help", "❔", "IIS yardım belgelerini açar."]
  ],
  server: [
    { g: "Manage Server" },
    ["Restart", "🔄", "IIS'i (W3SVC ve WAS hizmetlerini) yeniden başlatır. Tüm siteler ve havuzlar kısa süreliğine durur. Komut satırı eşdeğeri: iisreset"],
    ["Start", "▶️", "Durdurulmuş IIS web hizmetini başlatır. (iisreset /start)"],
    ["Stop", "⏹️", "IIS web hizmetini durdurur; sunucudaki TÜM siteler yanıt vermeyi keser. (iisreset /stop)"],
    ["View Application Pools", "🗂️", "Application Pools düğümüne geçer.", "nav:pools"],
    ["View Sites", "🌐", "Sites düğümüne geçer.", "nav:sites"],
    ["Get New Web Platform Components", "⬇️", "Ek IIS bileşenlerini (URL Rewrite, ARR vb.) indirmek için kullanılan eski Web Platform Installer bağlantısıdır."],
    ["Help", "❔", "IIS yardım belgelerini açar."]
  ],
  pools: [
    ["Add Application Pool...", "➕", "Yeni bir uygulama havuzu oluşturur. Ad, .NET CLR sürümü, pipeline modu ve 'hemen başlat' seçenekleri girilir.", "addPool"],
    ["Set Application Pool Defaults...", "⚙️", "Bundan sonra oluşturulacak TÜM havuzların varsayılan ayarlarını belirler (applicationPoolDefaults). Mevcut havuzlardan özel değer atanmamış olanlar da bu varsayılanı miras alır.", "poolAdv"],
    ["Help", "❔", "Uygulama havuzları hakkında yardım."]
  ],
  pool: [
    { g: "Application Pool Tasks" },
    ["Start", "▶️", "Seçili havuzu başlatır. Havuz başladığında hemen w3wp.exe açılmaz; ilk istekte açılır (Start Mode = OnDemand ise).", "poolStart"],
    ["Stop", "⏹️", "Seçili havuzu durdurur. Bu havuzdaki uygulamalara gelen isteklere 503 Service Unavailable döner.", "poolStop"],
    ["Recycle...", "♻️", "Havuzu geri dönüştürür: yeni bir çalışan süreç başlatılır, eskisi elindeki istekleri bitirip kapanır. Uygulama belleği, önbellek ve InProc oturumlar sıfırlanır. Kesintisiz 'yumuşak yeniden başlatma' olarak düşünebilirsiniz.", "poolRecycle"],
    { g: "Edit Application Pool" },
    ["Basic Settings...", "📝", "Havuzun .NET CLR sürümünü ve pipeline modunu düzenler.", "editPool"],
    ["Recycling...", "♻️", "Geri dönüşüm koşullarını (zaman aralığı, belirli saatler, bellek ve istek sınırları) ve hangi olayların günlüğe yazılacağını ayarlar.", "recycling"],
    ["Advanced Settings...", "⚙️", "Havuzun tüm gelişmiş ayarlarını (CPU, Process Model, Rapid-Fail Protection, Recycling...) özellik tablosunda gösterir.", "poolAdv"],
    ["Rename", "✏️", "Havuzun adını değiştirir. DİKKAT: ApplicationPoolIdentity kullanıyorsanız sanal hesap adı da değişir (IIS AppPool\\YeniAd), klasör izinlerini güncellemeniz gerekir."],
    ["Remove", "❌", "Havuzu siler. Havuzu kullanan uygulama varsa önce onlar başka havuza taşınmalıdır."],
    ["View Applications", "📦", "Bu havuzu kullanan uygulamaları listeler."],
    ["Help", "❔", "Uygulama havuzları hakkında yardım."]
  ],
  sites: [
    ["Add Website...", "➕", "Yeni bir web sitesi oluşturur: site adı, uygulama havuzu, fiziksel yol, bağlama (tür, IP, port, host adı) ve SSL sertifikası seçilir.", "addSite"],
    ["Set Website Defaults...", "⚙️", "Yeni sitelerin varsayılan ayarlarını (siteDefaults: log, limitler, FREB vb.) belirler.", "siteAdv"],
    ["Help", "❔", "Siteler hakkında yardım."]
  ],
  site: [
    ["Explore", "📂", "Sitenin fiziksel klasörünü Windows Gezgini'nde açar."],
    ["Edit Permissions...", "🔐", "Fiziksel klasörün NTFS izinlerini düzenleme penceresini açar. Havuz kimliğine (ör. IIS AppPool\\DefaultAppPool) en az Read & Execute izni verilmelidir; dosya yükleme yapılan klasörlere Modify verilir."],
    { g: "Edit Site" },
    ["Bindings...", "🔗", "Sitenin bağlamalarını (http/https, IP adresi, port, host adı, SSL sertifikası) ekler, düzenler veya kaldırır.", "bindings"],
    ["Basic Settings...", "📝", "Site adını, uygulama havuzunu ve fiziksel yolu düzenler.", "siteBasic"],
    ["View Applications", "📦", "Bu site altındaki uygulamaları listeler."],
    ["View Virtual Directories", "🔗", "Bu site altındaki sanal dizinleri listeler."],
    { g: "Manage Website" },
    ["Restart", "🔄", "Siteyi durdurup yeniden başlatır (yalnızca HTTP dinleyicisi; uygulama havuzunu geri dönüştürmez!)."],
    ["Start", "▶️", "Siteyi başlatır. Aynı bağlamayı kullanan başka bir site çalışıyorsa hata verir.", "siteStart"],
    ["Stop", "⏹️", "Siteyi durdurur. Bağlamalara gelen isteklere yanıt verilmez (HTTP.sys 404/503).", "siteStop"],
    { g: "Browse Website" },
    ["Browse *:80 (http)", "🌐", "Siteyi varsayılan tarayıcıda ilgili bağlama adresiyle açar."],
    ["Advanced Settings...", "⚙️", "Sitenin gelişmiş ayarlarını özellik tablosunda gösterir.", "siteAdv"],
    { g: "Configure" },
    ["Failed Request Tracing...", "🧾", "Bu site için Başarısız İstek İzlemeyi (FREB) etkinleştirir, klasör ve dosya sayısını ayarlar. Kurallar ise 'Failed Request Tracing Rules' özelliğinden tanımlanır."],
    ["Limits...", "⏱️", "Bant genişliği, bağlantı zaman aşımı ve eşzamanlı bağlantı sınırlarını ayarlar."],
    ["HSTS...", "🔒", "HTTP Strict Transport Security ayarlarını açar (IIS 10.0 1709+)."],
    ["Add FTP Publishing...", "📤", "Bu web sitesine FTP bağlaması ekler; böylece aynı klasöre FTP ile dosya yüklenebilir. Sihirbazda IP/port (21), SSL, kimlik doğrulama ve yetkilendirme seçilir. FTP Server rol hizmeti kurulu olmalıdır."],
    ["Help", "❔", "Siteler hakkında yardım."]
  ],
  app: [
    ["Explore", "📂", "Uygulamanın fiziksel klasörünü açar."],
    ["Edit Permissions...", "🔐", "Klasörün NTFS izinlerini düzenler."],
    { g: "Manage Application" },
    ["Basic Settings...", "📝", "Uygulamanın takma adını (alias), uygulama havuzunu ve fiziksel yolunu düzenler.", "appBasic"],
    ["View Virtual Directories", "🔗", "Uygulama altındaki sanal dizinleri listeler."],
    ["Browse", "🌐", "Uygulamayı tarayıcıda açar."],
    ["Advanced Settings...", "⚙️", "Uygulamanın gelişmiş ayarlarını (Application Pool, Enabled Protocols, Preload Enabled, Physical Path Credentials) gösterir.", "siteAdv"],
    ["Help", "❔", "Uygulamalar hakkında yardım."]
  ],
  vdir: [
    ["Explore", "📂", "Sanal dizinin gösterdiği fiziksel klasörü açar."],
    ["Edit Permissions...", "🔐", "Klasörün NTFS izinlerini düzenler."],
    ["Convert to Application", "📦", "Sanal dizini bir uygulamaya dönüştürür. Bu sayede kendi uygulama havuzu ve kök web.config'i olabilir. (Ağaçta sağ tık > Convert to Application)"],
    ["Basic Settings...", "📝", "Sanal dizinin takma adını ve fiziksel yolunu düzenler.", "appBasic"],
    ["Advanced Settings...", "⚙️", "Sanal dizinin gelişmiş ayarları.", "siteAdv"],
    ["Help", "❔", "Sanal dizinler hakkında yardım."]
  ],
  folder: [
    ["Explore", "📂", "Klasörü Windows Gezgini'nde açar."],
    ["Edit Permissions...", "🔐", "Klasörün NTFS izinlerini düzenler."],
    ["Convert to Application", "📦", "Klasörü bağımsız bir uygulamaya dönüştürür."],
    ["Help", "❔", "Klasör yapılandırması hakkında yardım."]
  ]
};

/* Menü çubuğu */
IIS.menu = [
  ["File", "Dosya menüsü: sunucuya/siteye/uygulamaya bağlanma, bağlantı listesini kaydetme ve çıkış komutlarını içerir."],
  ["View", "Görünüm menüsü: Features View / Content View arasında geçiş, Group By seçenekleri ve bölmeleri gösterme/gizleme."],
  ["Help", "Yardım menüsü: IIS çevrimiçi yardımı, IIS.net bağlantıları ve sürüm bilgisi (About)."]
];

IIS.connTools = [
  ["💾", "Save Connections", "Connections bölmesindeki bağlantı listesini kaydeder; IIS Yöneticisi tekrar açıldığında aynı bağlantılar görünür."],
  ["🔌", "Create New Connection", "Yeni bir sunucu, site veya uygulama bağlantısı oluşturma sihirbazını başlatır."],
  ["⬆️", "Up", "Ağaçta bir üst düğüme çıkar."],
  ["✖", "Delete Connection", "Seçili bağlantıyı listeden kaldırır (sunucuda hiçbir şeyi silmez)."]
];

IIS.viewTabs = {
  features: "Features View: Seçili düğüm için yapılandırılabilir özellikleri (modülleri, ayarları) simgeler halinde gösterir. Ayarların çoğu buradan yapılır.",
  content: "Content View: Seçili site/uygulama/klasörün fiziksel klasöründeki dosya ve alt klasörleri listeler. Buradan bir dosya seçip yalnızca o dosyaya özel ayar (location etiketi) yapabilirsiniz ('Switch to Features View')."
};
