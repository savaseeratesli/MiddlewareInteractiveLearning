/* IIS Yardım Masası – uygulama mantığı */
(function () {
  "use strict";
  const $ = (s, el) => (el || document).querySelector(s);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));

  /* ---------------- Simgeler (orijinal IIS ekran görüntülerinden) ---------------- */
  const IMG = (n, w, h) => `<img src="img/icons/${n}.png" alt="" width="${w}" height="${h || w}" draggable="false">`;
  const FOLDER = (sz, link) => `<svg width="${sz}" height="${sz}" viewBox="0 0 16 16" aria-hidden="true"><path d="M1 3.5h5l1.4 1.4H15v8.6H1z" fill="#e8b84a"/><path d="M1 6h14v7.5H1z" fill="#f8d775"/><path d="M1 6h14" stroke="#d9a53a" stroke-width=".8"/>${link ? '<rect x="1" y="9" width="6" height="6" fill="#fff" stroke="#555" stroke-width=".7"/><path d="M2.6 13.5c0-2 1-2.8 3-2.8M4.4 9.6l1.3 1.1-1.3 1.1" fill="none" stroke="#1c62b9" stroke-width="1"/>' : ""}</svg>`;
  const SVGI = (svg, sz) => svg.replace('width="24" height="24"', `width="${sz}" height="${sz}"`);
  const TREE_IC = { start: () => IMG("t-start", 14, 13), server: () => IMG("t-server", 14), pools: () => IMG("t-pools", 14), sites: () => IMG("t-sites", 14), site: () => IMG("t-site", 14), app: () => IMG("t-site", 14), vdir: () => FOLDER(15, true), folder: () => FOLDER(15), farms: () => SVGI(IIS.svgIcons.farms, 15), farm: () => SVGI(IIS.svgIcons.farm, 15) };
  const HEAD_IC = { server: () => IMG("h-server", 22), pools: () => IMG("h-pools", 22), sites: () => IMG("h-site", 22), site: () => IMG("h-site", 22), app: () => IMG("h-site", 22), vdir: () => FOLDER(22, true), folder: () => FOLDER(22), farms: () => SVGI(IIS.svgIcons.farms, 24), farm: () => SVGI(IIS.svgIcons.farm, 24) };
  const FIMG = (f, sz) => (f.svg ? SVGI(f.svg, sz || 24) : IMG("f-" + f.id, sz || 24));
  /* IIS gibi: simge etiketi en fazla 2 satır, taşan kısım "..." ile kesilir */
  const measure = (() => { const c = document.createElement("canvas").getContext("2d"); c.font = "11px 'Segoe UI', Tahoma, Arial, sans-serif"; return (s) => c.measureText(s).width; })();
  function tileLabel(name, maxW) {
    maxW = maxW || 47;
    const words = name.split(" "); let l1 = "";
    while (words.length && measure((l1 ? l1 + " " : "") + words[0]) <= maxW) l1 = (l1 ? l1 + " " : "") + words.shift();
    if (!l1) return `<span class="ln1 cut">${esc(name)}</span>`;
    return `<span class="ln1">${esc(l1)}</span>${words.length ? `<span class="ln1 cut">${esc(words.join(" "))}</span>` : ""}`;
  }
  function actIcon(name) {
    if (/^Browse/.test(name)) return IMG("a-browse", 13);
    if (/^Add (Application Pool|Website)/.test(name)) return IMG("a-add", 13);
    const m = { "Restart": "a-restart", "Start": "a-start", "Stop": "a-stop", "Help": "a-help", "Explore": "a-explore", "Basic Settings...": "a-basic", "Get New Web Platform Components": "a-wpi", "Recycle...": "a-restart", "Open Feature": "a-explore" }[name];
    return m ? IMG(m, 13) : "";
  }

  /* ---------------- Yardım kayıt sistemi ---------------- */
  const HELP = {};
  let hid = 0;
  /** ? düğmesi üretir. x: {ctx, cfg, def, tip, links, roles} */
  function q(title, text, x) {
    if (!text) return "";
    const id = "h" + (++hid);
    HELP[id] = Object.assign({ t: title, d: text }, x || {});
    return `<button type="button" class="q" data-h="${id}" title="${esc(title)} – bu ne işe yarar?" aria-label="${esc(title)} hakkında yardım">?</button>`;
  }
  function showHelp(h) {
    $("#helpTitle").textContent = h.t;
    let html = "";
    if (h.ctx) html += `<div class="ctx">${esc(h.ctx)}</div>`;
    html += String(h.d).split(/\n\n/).map((p) => `<p>${esc(p)}</p>`).join("");
    const kv = [];
    if (h.def != null && h.def !== "") kv.push(["Örnek / varsayılan değer", `<code>${esc(h.def)}</code>`]);
    if (h.cfg) kv.push(["Yapılandırma", `<code>${esc(h.cfg)}</code>`]);
    if (h.roles && h.roles.length) kv.push(["Kurulum (rol hizmeti)", h.roles.map((r) => esc(r)).join("<br>")]);
    if (kv.length) html += `<div class="kv">${kv.map(([k, v]) => `<b>${k}</b><span>${v}</span>`).join("")}</div>`;
    if (h.links && h.links.length) html += `<b>IIS Yöneticisi'nde ilgili özellikler:</b><div class="flinks">${h.links.filter((id) => FEAT[id]).map((id) => `<span class="flink" data-gofeat="${id}">${FIMG(FEAT[id], 16)} ${esc(FEAT[id].n)}</span>`).join("")}</div>`;
    if (h.tip) html += `<div class="box tip">💡 ${esc(h.tip)}</div>`;
    if (/DİKKAT|GÜVENSİZ|GÜVENLİK RİSKİ|tehlikeli|ÜRETİMDE/i.test(h.d)) html += `<div class="box warn">⚠️ Bu ayar güvenlik veya kararlılık açısından kritik olabilir. Üretim sunucusunda değiştirmeden önce test ortamında deneyin.</div>`;
    $("#helpBody").innerHTML = html;
    $("#helpPanel").classList.add("open");
    $("#helpPanel").setAttribute("aria-hidden", "false");
  }
  function closeHelp() { $("#helpPanel").classList.remove("open"); $("#helpPanel").setAttribute("aria-hidden", "true"); }

  let toastT;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("on"), 2600); }

  /* ---------------- Ağaç / indeksler ---------------- */
  const NODES = {}, PARENT = {};
  (function index(list, parent) { list.forEach((n) => { NODES[n.id] = n; PARENT[n.id] = parent; if (n.children) index(n.children, n.id); }); })(IIS.tree, null);
  const pathTo = (id) => { const p = []; while (id) { p.unshift(NODES[id]); id = PARENT[id]; } return p; };
  const FEAT = {}; IIS.features.forEach((f) => (FEAT[f.id] = f));
  // özellik -> hangi rol hizmetleriyle kurulur
  const ROLES_OF = {};
  (function walk(n, path) { const p = path.concat(n.n); (n.f || []).forEach((id) => (ROLES_OF[id] = ROLES_OF[id] || []).push(p.join(" › "))); (n.c || []).forEach((c) => walk(c, p)); })(IIS.roleServices, []);
  const featHelp = (f, extra) => Object.assign({ ctx: f.g + " özelliği", cfg: f.cfg, roles: ROLES_OF[f.id] }, extra || {});
  const nodeForFeature = (fid) => ({ site: "site1", farm: "farm1" }[FEAT[fid].lv] || "server");

  /* ---------------- Durum ---------------- */
  const st = { node: "start", feature: null, selFeat: null, selPool: null, selSite: null, selRow: null, view: "features", filter: "", groupBy: "area", collapsed: {}, back: [], fwd: [] };

  function go(node, feature, noHist) {
    if (!noHist) { st.back.push([st.node, st.feature]); st.fwd = []; }
    st.node = node; st.feature = feature || null; st.selRow = null; st.selFeat = feature || null; st.view = "features"; st.filter = "";
    let p = PARENT[node]; while (p) { NODES[p].open = true; p = PARENT[p]; }
    render(); $("#center").scrollTop = 0;
  }

  /* ---------------- Ağaç ---------------- */
  function renderTree() {
    const out = [];
    (function walk(list, depth) {
      list.forEach((n) => {
        const has = n.children && n.children.length;
        out.push(`<div class="tn${st.node === n.id ? " sel" : ""}" data-node="${n.id}" style="padding-left:${depth * 12 + 1}px">
          <span class="tg" data-tg="${n.id}">${has ? (n.open ? "&#9698;" : "&#9655;") : ""}</span><span class="ic">${TREE_IC[n.type]()}</span><span class="lb">${esc(n.n)}</span>${q(n.n, n.h, { ctx: "Connections ağacı" })}</div>`);
        if (has && n.open) walk(n.children, depth + 1);
      });
    })(IIS.tree, 0);
    $("#tree").innerHTML = out.join("");
  }

  /* ---------------- Adres çubuğu ---------------- */
  function renderCrumbs() {
    const parts = pathTo(st.node).filter((n) => n.type !== "start" || st.node === "start");
    const first = parts[0];
    let h = (first ? TREE_IC[first.type]() : "") + '<span class="sep">&#9654;</span>' + parts.map((n) => `<a data-node="${n.id}">${esc(n.short || n.n)}</a>`).join('<span class="sep">&#9654;</span>');
    if (st.feature) h += `<span class="sep">&#9654;</span><a>${esc(FEAT[st.feature].n)}</a>`;
    $("#crumbs").innerHTML = h + '<span class="sep">&#9654;</span>';
    $("#btnBack").disabled = !st.back.length;
    $("#btnFwd").disabled = !st.fwd.length;
  }

  /* ---------------- Orta bölme ---------------- */
  const header = (ic, title, help, ctx) => `<div class="ph"><span class="big">${ic}</span><h1>${esc(title)}</h1>${q(title, help, { ctx })}</div>`;
  const levelOf = (n) => (n.type === "server" ? "server" : n.type === "farm" ? "farm" : "site");
  const featuresFor = (n) => levelOf(n) === "farm" ? IIS.features.filter((f) => f.lv === "farm") : IIS.features.filter((f) => f.lv === "all" || f.lv === levelOf(n));

  function renderCenter() {
    const n = NODES[st.node];
    let h;
    if (n.type === "start") h = startPage();
    else if (n.type === "pools") h = poolsPage();
    else if (n.type === "sites") h = sitesPage();
    else if (n.type === "farms") h = farmsPage();
    else if (st.feature) h = featurePage(FEAT[st.feature], n);
    else if (st.view === "content") h = contentPage(n);
    else h = homePage(n);
    $("#center").innerHTML = h;
  }

  function startPage() {
    const faq = [["HTTP 404.3 – MIME türü yok", "mime"], ["HTTP 500.19 – Yapılandırma kilitli", "delegation"], ["HTTP 403.14 – Dizin listeleme", "dirbrowse"], ["HTTP 405 – PUT/DELETE çalışmıyor", "modules"], ["HTTP 404.13 – Dosya çok büyük", "reqfilt"], ["HTTP→HTTPS yönlendirme", "rewrite"], ["Yavaş istekleri bulmak", "frt"], ["FTP 425 – veri bağlantısı açılamıyor", "ftpfw"], ["Yük dengeleme (Server Farm)", "farmlb"], ["502.3 – arka uç zaman aşımı", "farmproxy"]];
    return `<div class="start">
      <h2>Internet Information Services 10.0 Yardım Masası</h2>
      <p class="lead">Bu sayfa, IIS Yöneticisi'nin (IIS Manager) birebir benzeri bir <b>eğitim simülasyonudur</b>. Tüm rol hizmetleri ve özellikler kurulu görünür. Hiçbir değişiklik gerçek bir sunucuya yazılmaz; istediğiniz her ayarı güvenle kurcalayabilirsiniz.</p>
      <div class="legend-q"><button class="q" tabindex="-1">?</button> Herhangi bir düğmenin, değerin, sütunun veya eylemin yanındaki bu soru işaretine tıklayarak ne işe yaradığını Türkçe olarak okuyabilirsiniz.</div>
      <div class="cards">
        <div class="card"><h3>${IMG("t-server", 14)} Son bağlantılar ${q("Recent connections", "Daha önce bağlandığınız sunucu, site ve uygulamalar burada listelenir. Tıklayarak hızlıca yeniden bağlanabilirsiniz.")}</h3>
          <ul><li><a data-node="server">WIN-IIS01 (localhost)</a></li><li><a data-node="site1">WIN-IIS01/Default Web Site</a></li><li><a data-node="pools">WIN-IIS01/Application Pools</a></li></ul></div>
        <div class="card hl"><h3>${IMG("f-modules", 16)} Rol ve özellik kurulumu ${q("Add Roles and Features", "IIS'in hangi bileşenlerinin kurulu olduğunu Sunucu Yöneticisi'ndeki 'Add Roles and Features Wizard' penceresinde görürsünüz. Bu simülasyonda tüm rol hizmetleri kurulu olarak gösterilir. Her rol hizmetini seçtiğinizde ne işe yaradığını ve IIS Yöneticisi'nde hangi simgeyi eklediğini görebilirsiniz.")}</h3>
          <ul><li><a data-dlgopen="roles">Web Server (IIS) rol hizmetlerini göster</a></li><li>Hangi bileşen hangi simgeyi ekler?</li></ul></div>
        <div class="card"><h3>${IMG("a-help", 13)} Nasıl gezilir? ${q("Arayüz düzeni", "IIS Yöneticisi üç bölmeden oluşur:\n\nSol – Connections: sunucu, uygulama havuzları, siteler, uygulamalar ve klasörlerden oluşan ağaç. Hangi düğümü seçerseniz yaptığınız ayar o düzeye uygulanır.\n\nOrta – Features View: seçili düğümde yapılandırılabilen özellik simgeleri. Bir simgeye çift tıklayarak ayar sayfasını açarsınız. Alttaki sekmeyle Content View'a (dosya listesi) geçilir.\n\nSağ – Actions: seçili öğe veya açık sayfa için yapılabilecek işlemler (Apply, Add, Edit, Start, Stop, Advanced Settings...).")}</h3>
          <ul><li>Soldaki ağaçtan bir düğüm seçin</li><li>Ortadaki bir özelliğe <b>çift tıklayın</b></li><li>Sağdaki eylemlere tıklayın</li><li>Her şeyin yanında <b>?</b> var</li></ul></div>
        <div class="card"><h3>${IMG("f-errpages", 16)} Sık karşılaşılan sorunlar ${q("Sık karşılaşılan sorunlar", "Bu bağlantılar sizi ilgili hata kodunun çözümünün yapıldığı özellik sayfasına götürür. Açılan sayfada ilgili ayarın yanındaki ? işaretine tıklayın.")}</h3>
          <ul>${faq.map(([t, f]) => `<li><a data-gofeat="${f}">${esc(t)}</a></li>`).join("")}</ul></div>
        <div class="card"><h3>${IMG("f-config", 16)} Düzeyler ve miras ${q("Yapılandırma mirası", "IIS ayarları hiyerarşiktir: machine.config → kök web.config → applicationHost.config (sunucu) → sitenin web.config'i → uygulamanın web.config'i → klasörün web.config'i.\n\nÜst düzeyde yapılan ayar alt düzeylere miras geçer. Listelerde 'Entry Type' sütunu Inherited (miras) veya Local (bu düzeyde tanımlı) olarak gösterir. Alt düzeyde değiştirilebilmesi için özelliğin Feature Delegation'da Read/Write olması gerekir.", { cfg: "%windir%\\System32\\inetsrv\\config\\applicationHost.config" })}</h3>
          <ul><li><a data-node="server">Sunucu düzeyi</a></li><li><a data-node="site1">Site düzeyi</a></li><li><a data-node="app1">Uygulama düzeyi</a></li><li><a data-node="fold1">Klasör düzeyi</a></li></ul></div>
      </div></div>`;
  }

  function filterBar(withGroups) {
    return `<div class="filterbar">
      <span class="fb-item">Filter: <input id="flt" type="text" value="${esc(st.filter)}">${q("Filter", "Simgeleri veya liste öğelerini ada (ve açıklamaya) göre süzer. Çok sayıda özellik varken aradığınızı hızlı bulmak için kullanılır.")}</span>
      <span class="sepv"></span><button class="fbtn" id="fltGo">${IMG("b-go", 14, 13)} Go</button>${q("Go", "Filtre kutusundaki metni uygular. Yanındaki açılır ok ile 'Show All' veya filtreleme seçenekleri seçilebilir.")}
      <span class="sepv"></span><button class="fbtn" id="fltAll">${IMG("b-showall", 15, 13)} Show All</button>${q("Show All", "Filtreyi temizler ve tüm öğeleri gösterir.")}
      <span class="sepv"></span><span class="fb-item">Group by: <select id="grp">${(withGroups ? [["area", "Area"], ["category", "Category"], ["none", "No Grouping"]] : [["none", "No Grouping"], ["status", "Status"], ["clr", ".NET CLR Version"]]).map(([v, t]) => `<option value="${v}"${st.groupBy === v ? " selected" : ""}>${t}</option>`).join("")}</select>${q("Group by", withGroups ? "Özellik simgelerinin nasıl gruplanacağı. Area: ASP.NET / FTP / IIS / Management. Category: Security, Performance, Health and Diagnostics gibi işlevsel kategoriler. No Grouping: alfabetik tek liste." : "Listeyi duruma veya .NET CLR sürümüne göre gruplar.")}</span>
      ${withGroups ? `<span class="sepv"></span><button class="fbtn">${IMG("b-view", 22, 13)}</button>${q("Görünüm", "Simgelerin görünümünü değiştirir: Icons (büyük simge – varsayılan), Tiles, Details (ad ve açıklama listesi), List.")}` : ""}
    </div>`;
  }

  function homePage(n) {
    const fs = featuresFor(n).filter((f) => !st.filter || (f.n + " " + f.d).toLowerCase().includes(st.filter.toLowerCase())).sort((a, b) => a.n.localeCompare(b.n, "en", { sensitivity: "base" }));
    let groups;
    if (st.groupBy === "category") {
      const cats = { "Security": ["authc", "authz", "netauthz", "iprestr", "reqfilt", "ssl", "certs", "isapicgi", "machkey", "nettrust", "centralcert", "ftpauth", "ftpauthz", "ftpip", "ftpreq", "ftpssl", "ftplogon"], "Performance": ["compress", "outcache"], "Health and Diagnostics": ["logging", "frt", "workers", "errpages", "neterr", "ftplog"], "Application Development": ["asp", "cgi", "fastcgi", "isapifilt", "netcomp", "netglob", "pages", "session", "appset", "connstr", "providers", "netprof", "netroles", "netusers", "smtp"], "HTTP Features": ["defdoc", "dirbrowse", "redirect", "headers", "mime", "rewrite", "webdav"], "FTP": ["ftpdir", "ftpfw", "ftpmsg", "ftpiso"], "Server Components": ["handlers", "modules"], "Management": ["config", "delegation", "sharedcfg", "mgrperm", "mgrusers", "mgmtsvc"] };
      groups = Object.entries(cats).map(([g, ids]) => [g, g + " kategorisindeki özellikler.", fs.filter((f) => ids.includes(f.id))]);
    } else if (st.groupBy === "none") groups = [["", "", fs]];
    else groups = IIS.groups.map(([g, gh]) => [g, gh, fs.filter((f) => f.g === g)]);
    const tiles = groups.filter((g) => g[2].length).map(([g, gh, list]) => {
      const col = st.collapsed[g];
      return `${g ? `<div class="fgh" data-grp="${esc(g)}"><span>${esc(g)}</span>${q(g + " özellik grubu", gh)}<span class="ln"></span><span class="chev">${col ? "&#9660;" : "&#9650;"}</span></div>` : ""}
      <div class="fgrid${col ? " hid" : ""}">${list.map((f) => `<div class="fi${st.selFeat === f.id ? " sel" : ""}" data-feat="${f.id}" tabindex="0" title="${esc(f.n)}">
        ${FIMG(f)}<span class="fn">${st.selFeat === f.id ? esc(f.n) : tileLabel(f.n)}</span>${q(f.n, f.d, featHelp(f, { tip: "Ayar sayfasını açmak için simgeye çift tıklayın veya sağdaki 'Open Feature' eylemini kullanın." }))}</div>`).join("")}</div>`;
    }).join("");
    return header(HEAD_IC[n.type](), (n.short || n.n) + " Home", n.h, "Features View") + filterBar(true) + `<div class="fgroups">${tiles || '<p style="padding:10px">Filtreye uyan özellik yok.</p>'}</div>`;
  }

  function contentPage(n) {
    const files = [
      ["d", "bin", "Derlenmiş uygulama DLL'lerinin bulunduğu klasör. Request Filtering ile dışarıdan erişime kapalıdır (gizli segment)."],
      ["d", "App_Data", "Uygulama veri dosyaları (ör. .mdf veritabanı, XML). Dışarıdan erişilemez (gizli segment, 404.8). Havuz kimliğine yazma izni gerekebilir."],
      ["d", "Content", "CSS ve resim gibi statik dosyalar."], ["d", "Scripts", "JavaScript dosyaları."],
      ["f", "Default.aspx", "Varsayılan belge listesinde yer aldığı için klasör adresi istendiğinde bu sayfa açılır."],
      ["f", "Global.asax", "ASP.NET uygulama olaylarını (Application_Start, Session_Start, Application_Error) içerir. Dışarıdan indirilemez."],
      ["f", "web.config", "Bu düzeyin yapılandırma dosyası. IIS Yöneticisi'nde bu düzeyde yaptığınız tüm değişiklikler bu dosyaya yazılır. Bozuk XML veya tanınmayan bölüm 500.19 hatasına neden olur."],
      ["f", "favicon.ico", "Tarayıcı sekmesinde görünen site simgesi."]
    ];
    const fileIc = '<svg width="14" height="14" viewBox="0 0 16 16"><path d="M3 1h7l3 3v11H3z" fill="#fff" stroke="#888"/><path d="M10 1v3h3" fill="none" stroke="#888"/></svg>';
    return header(HEAD_IC[n.type](), n.short || n.n, "Content View, seçili düğümün fiziksel klasöründeki dosyaları gösterir. Bir dosyayı seçip 'Switch to Features View' ile yalnızca o dosyaya özel ayar (web.config içinde <location path=\"dosya\">) yapabilirsiniz.", "Content View") + filterBar(false) +
      `<div class="tblwrap"><table class="lv"><thead><tr><th><span class="thc">Name ${q("Name", "Dosya veya klasör adı.")}</span></th><th><span class="thc">Type ${q("Type", "Öğenin türü: klasör, dosya, sanal dizin veya uygulama.")}</span></th></tr></thead><tbody>
      ${files.map(([k, nm, h]) => `<tr class="row"><td>${k === "d" ? FOLDER(14) : fileIc} ${esc(nm)} ${q(nm, h)}</td><td>${k === "d" ? "Folder" : "File"}</td></tr>`).join("")}</tbody></table></div>`;
  }

  function table(cols, rows, selIdx, rowAttr, icon) {
    return `<div class="tblwrap"><table class="lv"><thead><tr>${cols.map(([c, h]) => `<th><span class="thc">${esc(c)} ${q(c, h, { ctx: "Sütun" })}</span></th>`).join("")}</tr></thead><tbody>
      ${rows.map((rw, i) => `<tr class="row${selIdx === i ? " sel" : ""}" ${rowAttr}="${i}">${rw.c.map((v, j) => `<td>${j === 0 && icon ? icon : ""}${esc(v)}${j === 0 && rw.h ? " " + q(String(v), rw.h, { ctx: "Liste öğesi" }) : ""}</td>`).join("")}</tr>`).join("") ||
      `<tr><td colspan="${cols.length}" style="color:#888;padding:8px">Bu düzeyde tanımlı öğe yok.</td></tr>`}</tbody></table></div>`;
  }

  function poolsPage() {
    const n = NODES.pools;
    const rows = IIS.pools.map((p) => ({ c: [p.name, p.status, p.clr, p.mode, p.identity, p.apps] }));
    return header(HEAD_IC.pools(), "Application Pools", n.h) +
      `<div class="pdesc">This page lets you view and manage the list of application pools on the server. Application pools are associated with worker processes, contain one or more applications, and provide isolation among different applications. ${q("Sayfa açıklaması", "Bu sayfada sunucudaki uygulama havuzlarını görüntüler ve yönetirsiniz. Bir havuzu seçtiğinizde sağdaki Actions bölmesinde Start/Stop/Recycle ve Advanced Settings eylemleri belirir. Çift tıklamak Basic Settings penceresini açar.")}</div>` +
      filterBar(false) + table(IIS.poolCols, rows, st.selPool, "data-pool", IMG("t-pool", 13) + " ");
  }
  function sitesPage() {
    const n = NODES.sites;
    const rows = IIS.sites.map((s) => ({ c: [s.name, s.id, s.status, s.bindings, s.path] }));
    return header(HEAD_IC.sites(), "Sites", n.h) + filterBar(false) + table(IIS.siteCols, rows, st.selSite, "data-site", IMG("t-site", 14) + " ");
  }

  function farmsPage() {
    const n = NODES.farms;
    const rows = IIS.farms.map((f) => ({ c: [f.name, f.servers.length, f.online ? "True" : "False", f.algo, f.affinity] }));
    return header(HEAD_IC.farms(), "Server Farms", n.h) +
      `<div class="pdesc">Use this feature to create and manage server farms. A server farm is a group of servers that requests can be routed to for load balancing and failover. ${q("Sayfa açıklaması", "Bu sayfada sunucu çiftliklerini oluşturur ve yönetirsiniz. Bir çiftliği seçip çift tıklayarak (veya ağaçtan seçerek) çiftliğin ARR özelliklerine (yük dengeleme, sağlık testi, önbellek...) ulaşırsınız.\n\nTipik mimari: İnternet → ARR sunucusu (bu IIS, 80/443) → URL Rewrite 'Route to Server Farm' kuralı → WebFarm01 (WEB01, WEB02, WEB03). Kullanıcılar yalnızca ARR sunucusunu görür.")}</div>` +
      filterBar(false) + table(IIS.farmCols, rows, st.selFarm, "data-farm", SVGI(IIS.svgIcons.farm, 14) + " ");
  }

  /* --------- Özellik ızgarası (Advanced Settings biçimi) --------- */
  const PGS = {}; let pgc = 0;
  const attrOf = (cfg) => (cfg ? String(cfg).split("/").pop().replace(/^@/, "").split(" ")[0] : "");
  function propGrid(cats, ctx) {
    const id = "pg" + (++pgc); const G = PGS[id] = { items: [], col: new Set() };
    let html = `<div class="pg" data-pgid="${id}">`;
    function row(p, depth, par, catName) {
      const k = G.items.push(p) - 1;
      const cls = ["r", p.flags && p.flags.includes("ro") ? "ro" : "", p.flags && p.flags.includes("b") ? "b" : ""].join(" ");
      html += `<div class="${cls}" data-pr="${id}:${k}" data-par="${par.join(" ")}"><div class="n"><span class="gut"></span><span style="width:${depth * 12 + 6}px;flex:none"></span><span class="tx">${esc(p.nm)}</span></div><div class="v">${esc(p.val)}</div><div class="h">${q(p.nm, p.h, { ctx: ctx + " › " + catName, cfg: p.cfg, def: p.val })}</div></div>`;
    }
    function walk(list, depth, par, catName) {
      list.forEach((p) => {
        if (Array.isArray(p)) return row({ nm: p[0], val: p[1], h: p[2], cfg: p[3], flags: p[4] || "" }, depth, par, catName);
        const key = id + "s" + (G.items.length); if (p.collapsed) G.col.add(key);
        const k = G.items.push({ nm: p.sub, val: "", h: p.h, cfg: p.cfg }) - 1;
        html += `<div class="r sub" data-pr="${id}:${k}" data-par="${par.join(" ")}"><div class="n"><span class="gut"></span><span style="width:${depth * 12 - 6}px;flex:none"></span><span class="tg" data-pgt="${id}|${key}">${p.collapsed ? "&#9655;" : "&#9698;"}</span><span class="tx">${esc(p.sub)}</span></div><div class="v"></div><div class="h">${q(p.sub, p.h, { ctx: ctx + " › " + catName, cfg: p.cfg })}</div></div>`;
        walk(p.props, depth + 1, par.concat(key), catName);
      });
    }
    cats.forEach((cat, ci) => {
      const key = id + "c" + ci;
      html += `<div class="r cat" data-pgt="${id}|${key}"><div class="n"><span class="gut">&#9660;</span><span class="tx">${esc(cat.cat)}</span></div><div class="v"></div><div class="h"></div></div>`;
      walk(cat.props, 1, [key], cat.cat);
    });
    const f = G.items[0];
    html += `</div><div class="pgdesc" id="${id}-d"><b>${esc(f.nm)}</b>${f.cfg ? "[" + esc(attrOf(f.cfg)) + "] " : ""}${esc(f.h)}</div>`;
    setTimeout(() => applyPg(id), 0);
    return html;
  }
  function applyPg(id) {
    const G = PGS[id]; const root = document.querySelector(`[data-pgid="${id}"]`); if (!root) return;
    root.querySelectorAll("[data-par]").forEach((r) => { r.style.display = r.dataset.par.split(" ").some((k) => G.col.has(k)) ? "none" : ""; });
    root.querySelectorAll("[data-pgt]").forEach((t) => { const k = t.dataset.pgt.split("|")[1]; const g = t.classList.contains("cat") ? t.querySelector(".gut") : t; g.innerHTML = G.col.has(k) ? (t.classList.contains("cat") ? "&#9654;" : "&#9655;") : (t.classList.contains("cat") ? "&#9660;" : "&#9698;"); });
  }
  const findProp = (cats, name) => { let hit = null; (function w(l) { l.forEach((p) => { if (Array.isArray(p)) { if (p[0] === name && !hit) hit = p; } else w(p.props); }); })(cats.flatMap((c) => c.props)); return hit; };
  const cloneCats = (cats) => JSON.parse(JSON.stringify(cats));

  function field(fl, ctx) {
    const [k, n, v, h, opts] = fl;
    const help = q(n, h, { ctx });
    if (k === "c") return `<div class="fr"><label><input type="checkbox"${v ? " checked" : ""}>${esc(n)}</label>${help}</div>`;
    if (k === "t") return `<div class="fr"><label class="l">${esc(n)}:</label><input type="text" value="${esc(v)}">${help}</div>`;
    if (k === "s") return `<div class="fr"><label class="l">${esc(n)}:</label><select>${opts.map((o) => `<option${o === v ? " selected" : ""}>${esc(o)}</option>`).join("")}</select>${help}</div>`;
    if (k === "b") return `<div class="fr"><button class="btn" type="button">${esc(n)}</button>${help}</div>`;
    if (k === "l") return `<div class="fr"><label class="l">${esc(n)}:</label><span class="chip">${esc(v)}</span>${help}</div>`;
    if (k === "r") {
      const name = "r" + (++hid);
      return `<div class="fr col"><div style="display:flex;gap:6px;align-items:center"><span>${esc(n)}</span>${help}</div><div class="opts">${opts.map(([o, oh]) => `<div class="fr" style="margin:0"><label><input type="radio" name="${name}"${o === v ? " checked" : ""}>${esc(o)}</label>${q(o, oh, { ctx: n })}</div>`).join("")}</div></div>`;
    }
    return "";
  }
  const formHtml = (secs, ctx) => `<div class="form">${secs.map((sec) => sec.sec ? `<fieldset class="fs"><legend>${esc(sec.sec)}</legend>${sec.f.map((f) => field(f, ctx)).join("")}</fieldset>` : sec.f.map((f) => field(f, ctx)).join("")).join("")}</div>`;

  function featurePage(f, n) {
    const where = n.short || n.n;
    let body = "";
    if (f.list) body = table(f.list.cols, f.list.rows, st.selRow, "data-frow");
    else if (f.grid) body = `<div class="pane-pg">${propGrid(f.grid, f.n)}</div>`;
    else if (f.form) body = formHtml(f.form, f.n);
    const first = f.d.split(/(?<=\.)\s/)[0];
    return `<div class="ph"><span class="big">${FIMG(f)}</span><h1>${esc(f.n)}</h1>${q(f.n, f.d, featHelp(f, { ctx: f.g + " özelliği · " + where }))}</div>
      <div class="pdesc"><span>${esc(first)}</span></div>
      <div class="filterbar"><span class="fb-item">Düzey: <span class="chip">${esc(where)}</span>${q("Yapılandırma düzeyi", "Bu sayfada yaptığınız ayar şu an seçili olan düzeye yazılır: " + where + ". Sunucu düzeyi applicationHost.config'e, site/uygulama/klasör düzeyi ilgili klasördeki web.config dosyasına yazılır (Feature Delegation izin veriyorsa).")}</span>
      <span class="sepv"></span><span class="fb-item">Bölüm: <code>${esc(f.cfg || "")}</code>${q("Yapılandırma bölümü", "Bu özelliğin yapılandırma dosyasındaki XML bölüm yolu. Configuration Editor'da veya appcmd/PowerShell ile bu ad kullanılarak düzenlenebilir.", { cfg: f.cfg })}</span></div>
      ${body}`;
  }

  /* ---------------- Eylemler ---------------- */
  let ACTS = [];
  function isDisabled(a, ctx) {
    if (ctx === "server") return a[0] === "Start";
    if (ctx === "pool") { const p = curPool(); return (a[0] === "Start" && p.status === "Started") || (a[0] === "Stop" && p.status === "Stopped"); }
    if (ctx === "site") { const s = curSite(); return (a[0] === "Start" && s.status === "Started") || (a[0] === "Stop" && s.status === "Stopped"); }
    return false;
  }
  function actList(list, ctx, kind) {
    return list.map((a, i) => {
      if (a.g) return `<div class="ag${i === 0 ? " top" : ""}">${esc(a.g)}</div>`;
      const k = ACTS.push(a) - 1;
      return `<div class="ai${isDisabled(a, kind) ? " dis" : ""}"><span class="aic">${actIcon(a[0])}</span><a data-act="${k}">${esc(a[0])}</a>${q(a[0], a[2], { ctx: "Actions › " + ctx })}</div>`;
    }).join("");
  }
  function renderActions() {
    ACTS = [];
    const n = NODES[st.node];
    let h = "";
    if (st.feature) {
      const f = FEAT[st.feature];
      h += actList((f.acts || []).concat([["Help", "❔", f.d, "helpFeat"]]), f.n);
    } else if (n.type === "pools") {
      h += actList(IIS.actions.pools, "Application Pools");
      if (st.selPool != null) h += actList(IIS.actions.pool, IIS.pools[st.selPool].name, "pool");
    } else if (n.type === "farms") {
      h += actList(IIS.actions.farms, "Server Farms");
      if (st.selFarm != null) h += actList([{ g: IIS.farms[st.selFarm].name }, ["Open Server Farm", "📂", "Seçili çiftliğin düğümüne geçer ve ARR özelliklerini gösterir.", "openFarm"]].concat(IIS.actions.farm.slice(1)), "Server Farms");
    } else if (n.type === "sites") {
      h += actList(IIS.actions.sites, "Sites");
      if (st.selSite != null) h += actList([{ g: "Manage Website" }, ["Start", "▶️", "Seçili siteyi başlatır.", "siteStart"], ["Stop", "⏹️", "Seçili siteyi durdurur.", "siteStop"], ["Open Site", "🌍", "Seçili sitenin düğümüne geçer.", "openSite"], ["Bindings...", "🔗", "Sitenin bağlamalarını düzenler.", "bindings"], ["Advanced Settings...", "⚙️", "Sitenin gelişmiş ayarları.", "siteAdv"]], "Sites", "site");
    } else {
      if (n.type !== "start" && st.selFeat) h += actList([["Open Feature", "📂", "Seçili özelliğin ayar sayfasını açar (simgeye çift tıklamakla aynıdır).", "openFeat"]], "Features View");
      h += actList(IIS.actions[n.type] || [], n.short || n.n, n.type === "site" ? "site" : n.type === "server" ? "server" : "");
    }
    $("#actions").innerHTML = h;
  }

  function renderTabs() {
    const n = NODES[st.node];
    const vt = $("#viewtabs");
    if (n.type === "start") { vt.style.display = "none"; return; }
    vt.style.display = "";
    const on = st.view === "content" && !st.feature && !["pools", "sites", "farms", "farm"].includes(n.type) ? "content" : "features";
    vt.innerHTML = `<div class="vt${on === "features" ? " on" : ""}" data-view="features">${IMG("v-features", 13)} Features View ${q("Features View", IIS.viewTabs.features)}</div><div class="vt${on === "content" ? " on" : ""}" data-view="content">${IMG("v-content", 13)} Content View ${q("Content View", IIS.viewTabs.content)}</div>`;
  }

  function renderStatic() {
    $("#menubar").innerHTML = IIS.menu.map(([m, h]) => `<span class="mi">${m} ${q(m + " menüsü", h)}</span>`).join("") +
      `<span class="mi link" data-dlgopen="roles" style="margin-left:14px">${IMG("f-modules", 14)} Add Roles and Features</span>${q("Add Roles and Features", "Sunucu Yöneticisi'ndeki (Server Manager) 'Add Roles and Features Wizard' penceresini açar. Web Server (IIS) rolünün tüm rol hizmetleri kurulu olarak gösterilir; her birinin ne işe yaradığını ve IIS Yöneticisi'nde hangi özellik simgesini eklediğini görebilirsiniz.")}` +
      `<span class="mi" style="margin-left:auto;gap:5px">🔎 <input id="gsearch" type="text" placeholder="Yardımda ara (ör. timeout, 503, ssl)">${q("Yardımda ara", "Tüm özelliklerde, rol hizmetlerinde, havuz ve site ayarlarında arama yapar. Sonuca tıkladığınızda ilgili açıklama açılır.")}</span>`;
    $("#connTools").innerHTML = `<span class="toolimg" title="Connections araç çubuğu"></span><span style="margin-left:auto">${q("Connections araç çubuğu", IIS.connTools.map(([ic, t, h]) => t + ": " + h).join("\n\n"))}</span>`;
    $("#connHelp").innerHTML = q("Connections bölmesi", "Bağlı olduğunuz sunucuları ve bunların altındaki uygulama havuzlarını, siteleri, uygulamaları, sanal dizinleri ve klasörleri ağaç olarak gösterir. Bir düğüm seçtiğinizde orta bölme o düğümün özelliklerini gösterir.");
    $("#actHelp").innerHTML = q("Actions bölmesi", "Seçili öğe veya açık özellik sayfası için kullanılabilecek işlemleri listeler. İçerik bağlama duyarlıdır: bir havuz seçince Start/Stop/Recycle, bir ayar sayfasında Apply/Cancel görünür. Gri görünen eylemler o anki durumda kullanılamaz (ör. çalışan bir sunucu için Start).");
    $("#addrHelp").innerHTML = q("Adres çubuğu", "Bulunduğunuz konumu (Sunucu ▸ Sites ▸ Site ▸ Özellik) gösterir. Herhangi bir parçaya tıklayarak o düzeye dönebilirsiniz. Soldaki oklarla geri/ileri gidilir. Sağdaki simgeler: yeniden bağlan, durdur, yenile ve yardım.");
  }

  function render() { renderTree(); renderCrumbs(); renderCenter(); renderActions(); renderTabs(); }

  /* ---------------- Pencereler ---------------- */
  function dlg(title, body, opt) {
    opt = opt || {};
    const root = $("#dlgRoot");
    const foot = opt.footer || `<button class="btn pri" data-dlg="ok">OK</button><button class="btn" data-dlg="close">Cancel</button>`;
    root.innerHTML = `<div class="dlg-back"><div class="dlg ${opt.size || ""}" role="dialog" aria-label="${esc(title)}">
      <div class="dlg-t">${opt.ic || ""}<span class="t">${esc(title)}</span>${opt.help ? q(title, opt.help, { ctx: "Pencere" }) : ""}<button class="x" data-dlg="close" title="Close">&#10005;</button></div>
      <div class="dlg-b">${body}</div><div class="dlg-f">${foot}</div></div></div>`;
    root._ok = opt.onOk;
  }
  const closeDlg = () => { $("#dlgRoot").innerHTML = ""; };

  function curPool() { return IIS.pools[st.selPool != null ? st.selPool : 0]; }
  function curSite() {
    let id = st.node; while (id) { if (NODES[id].type === "site") return IIS.sites[NODES[id].siteIdx]; id = PARENT[id]; }
    return IIS.sites[st.selSite != null ? st.selSite : 0];
  }
  const t = (n, v, h) => ["t", n, v, h], s = (n, v, o, h) => ["s", n, v, h, o], c = (n, v, h) => ["c", n, v, h], l = (n, v, h) => ["l", n, v, h];
  const POOL_FIELDS = (p, isNew) => formHtml([{ sec: "", f: [
    t("Name", isNew ? "" : p.name, "Havuzun adı. ApplicationPoolIdentity kullanılırsa Windows'ta 'IIS AppPool\\<Ad>' sanal hesabı oluşur."),
    s(".NET CLR version", p.clr === "No Managed Code" ? "No Managed Code" : ".NET CLR Version " + p.clr + (p.clr === "v4.0" ? ".30319" : ".50727"), [".NET CLR Version v4.0.30319", ".NET CLR Version v2.0.50727", "No Managed Code"], "v4.0.30319: .NET Framework 4.x uygulamaları. v2.0.50727: .NET 2.0/3.5 uygulamaları. No Managed Code: ASP.NET Core, PHP, Node.js, statik siteler."),
    s("Managed pipeline mode", p.mode, ["Integrated", "Classic"], "Integrated (önerilen): ASP.NET IIS hattına entegre. Classic: IIS 6 uyumluluk modu."),
    c("Start application pool immediately", true, "İşaretliyse havuz oluşturulur oluşturulmaz başlatılır (Started).")] }], "Application Pool");
  const ADV_HELP = "Gelişmiş ayarları kategoriler halinde gösterir (Windows özellik ızgarası). Kalın yazılan değerler varsayılandan farklı (bu düzeyde ayarlanmış) değerlerdir; gri yazılanlar burada değiştirilemez. Bir satıra tıklayınca alttaki açıklama alanında kısa bilgi, satırın sağındaki ? ile ayrıntılı Türkçe açıklama görürsünüz.";

  const DIALOGS = {
    poolAdv() {
      const p = curPool(); const cats = cloneCats(IIS.poolAdvanced);
      [["Name", p.name], [".NET CLR Version", p.clr], ["Managed Pipeline Mode", p.mode], ["Identity", p.identity]].forEach(([k, v]) => { const x = findProp(cats, k); if (x) x[1] = v; });
      dlg("Advanced Settings", `<div class="pane-pg" style="margin:0">${propGrid(cats, "Application Pool")}</div>`, { size: "wide", help: ADV_HELP });
    },
    siteAdv() {
      const so = curSite(); const cats = cloneCats(IIS.siteAdvanced);
      [["Name", so.name], ["ID", so.id], ["Physical Path", so.path], ["Application Pool", so.pool], ["Bindings", so.bl.map((b) => b[0] + ":" + b[3] + ":" + b[2] + ":" + b[1]).join(",")]].forEach(([k, v]) => { const x = findProp(cats, k); if (x) x[1] = String(v); });
      dlg("Advanced Settings", `<div class="pane-pg" style="margin:0">${propGrid(cats, "Site")}</div>`, { size: "wide", help: ADV_HELP });
    },
    addPool() { dlg("Add Application Pool", POOL_FIELDS({ clr: "v4.0", mode: "Integrated" }, true), { help: "Yeni bir uygulama havuzu oluşturur." }); },
    editPool() { dlg("Edit Application Pool", POOL_FIELDS(curPool()), { help: "Havuzun temel ayarlarını düzenler." }); },
    poolRecycle() {
      const p = curPool();
      dlg("Recycle Application Pool", `<p>'${esc(p.name)}' uygulama havuzu geri dönüştürülecek. ${q("Recycle", "Yeni bir w3wp.exe başlatılır ve istekler ona yönlendirilir; eski süreç mevcut isteklerini tamamlayıp kapanır (overlapped recycle). Uygulamanın bellek içi verileri (InProc session, cache, statik değişkenler) sıfırlanır.")}</p>`, { onOk: () => toast("Simülasyon: '" + p.name + "' geri dönüştürüldü.") });
    },
    recycling() {
      dlg("Edit Application Pool Recycling Settings", formHtml([
        { sec: "Fixed Intervals", f: [c("Regular time intervals (in minutes)", true, "Süreç belirtilen dakika çalıştıktan sonra geri dönüştürülür. Varsayılan 1740 dk (29 saat)."), t("Minutes", "1740", "Geri dönüşüm aralığı."), c("Fixed number of requests", false, "Belirli sayıda istek işlendikten sonra geri dönüşüm."), t("Requests", "35000", "İstek sayısı."), c("Specific time(s)", false, "Günün belirli saatlerinde (ör. 03:00) geri dönüşüm – trafik düşükken planlamak için en iyi yöntem."), t("Times", "03:00", "Saat listesi (virgülle ayrılmış).")] },
        { sec: "Memory Based Maximums", f: [c("Virtual memory usage (in KB)", false, "Sanal bellek bu değeri aşınca geri dönüşüm. 64 bit süreçlerde nadiren kullanılır."), c("Private memory usage (in KB)", false, "Özel bellek bu değeri aşınca geri dönüşüm. Bellek sızıntısına karşı koruma."), t("Private memory (KB)", "2097152", "Örnek: 2 GB.")] },
        { sec: "Recycling Events to Log", f: [c("Regular time interval", true, "Zaman aralığı nedeniyle geri dönüşüm olay günlüğüne yazılsın."), c("Specific time", true, "Belirli saat nedeniyle..."), c("Private memory limit", true, "Bellek sınırı nedeniyle..."), c("Configuration changes", false, "Yapılandırma değişikliği nedeniyle."), c("Isapi reported unhealthy", false, "ISAPI uzantısı sağlıksız bildirdiğinde."), c("Manual recycle (On demand)", false, "Elle yapılan geri dönüşümler.")] }], "Recycling"), { help: "Geri dönüşüm koşulları ve günlüğe yazılacak olaylar. Beklenmedik geri dönüşümleri teşhis etmek için olayların günlüğe yazılmasını açın (Windows Olay Görüntüleyicisi > System, kaynak: WAS)." });
    },
    bindings() {
      const so = curSite();
      const cols = [["Type", "Protokol: http, https veya WCF için net.tcp, net.pipe, net.msmq, msmq.formatname."], ["Host Name", "Host başlığı (alan adı). Aynı IP ve portu paylaşan birden fazla siteyi ayırt etmeyi sağlar. Boş = tüm host adları."], ["Port", "Dinlenen port. http için 80, https için 443 standarttır."], ["IP Address", "* = All Unassigned (sunucunun tüm IP'leri). Belirli bir IP seçilebilir."], ["Binding Information", "net.tcp gibi HTTP dışı protokollerin bağlama bilgisi (ör. 808:*)."]];
      const rows = so.bl.map((b) => ({ c: b[0].startsWith("net") ? [b[0], "", "", "", b[3]] : [b[0], b[1], b[2], b[3], ""] }));
      const btns = [["Add...", "Yeni bağlama ekler."], ["Edit...", "Seçili bağlamayı düzenler."], ["Remove", "Seçili bağlamayı kaldırır. Sitenin en az bir bağlaması kalmalıdır."], ["Browse", "Bağlamanın adresini tarayıcıda açar."]];
      dlg("Site Bindings", `<div style="display:flex;gap:8px"><div style="flex:1;border:1px solid #828790;min-height:110px">${table(cols, rows, 0, "data-x")}</div><div style="display:flex;flex-direction:column;gap:4px">${btns.map(([b, h]) => `<div style="display:flex;gap:4px;align-items:center"><button class="btn">${b}</button>${q(b, h)}</div>`).join("")}</div></div>
        <fieldset class="fs" style="margin-top:12px"><legend>Edit Site Binding ${q("Edit Site Binding", "Bağlama düzenleme penceresindeki alanlar. https seçildiğinde SSL sertifikası ve TLS seçenekleri görünür.")}</legend>
        ${formHtml([{ sec: "", f: [
          s("Type", "https", ["http", "https"], "Bağlama protokolü."),
          s("IP address", "All Unassigned", ["All Unassigned", "10.0.0.15", "192.168.10.20"], "All Unassigned: sunucunun başka bir sitenin özel olarak kullanmadığı tüm IP'leri."),
          t("Port", "443", "Port numarası."),
          t("Host name", "intranet.firma.local", "Alan adı. https'te birden fazla site aynı IP:443'ü paylaşacaksa SNI işaretlenmelidir."),
          c("Require Server Name Indication", true, "SNI: İstemci TLS el sıkışmasında hangi host adına bağlandığını bildirir; böylece aynı IP:443 üzerinde farklı sertifikalı birden çok HTTPS sitesi barındırılabilir."),
          c("Disable TLS 1.3 over TCP", false, "Bu bağlama için TLS 1.3'ü kapatır (uyumluluk sorunlarında)."),
          c("Disable Legacy TLS", false, "TLS 1.0 ve 1.1'i bu bağlama için kapatır (önerilir)."),
          c("Disable OCSP Stapling", false, "Sertifika iptal durumunun sunucu tarafından TLS yanıtına eklenmesini kapatır."),
          c("Disable QUIC", false, "HTTP/3 (QUIC) desteğini bu bağlama için kapatır."),
          c("Disable HTTP/2", false, "HTTP/2'yi kapatıp HTTP/1.1'e zorlar."),
          s("SSL certificate", "intranet-2026", ["Not selected", "intranet-2026", "shop-wildcard", "IIS Express Development Certificate"], "Bağlamada kullanılacak sertifika. Server Certificates'ta yüklü sertifikalar listelenir. Sertifikadaki ad (CN/SAN) host adıyla eşleşmelidir.")] }], "Site Binding")}</fieldset>`, { size: "wide", help: "Bir sitenin hangi adres(ler)den yayın yapacağını belirleyen bağlamaları yönetir. Benzersizlik kuralı: Aynı Tür + IP + Port + Host adı birleşimi iki sitede bulunamaz.", footer: `<button class="btn" data-dlg="close">Close</button>` });
    },
    addSite() {
      dlg("Add Website", formHtml([{ sec: "", f: [
        t("Site name", "", "IIS'te görünen site adı."), t("Application pool", "(aynı adla yeni havuz)", "Siteyle aynı adda yeni havuz oluşturulur; 'Select...' ile mevcut havuz seçilebilir."),
        t("Physical path", "D:\\Web\\YeniSite", "İçerik klasörü."), ["b", "Connect as... / Test Settings...", "", "Connect as: fiziksel yola erişim için özel hesap. Test Settings: kimlik doğrulama ve yetkilendirme testini çalıştırır."]] },
        { sec: "Binding", f: [s("Type", "http", ["http", "https"], "Protokol."), s("IP address", "All Unassigned", ["All Unassigned", "10.0.0.15"], "Dinlenecek IP."), t("Port", "80", "Port."), t("Host name", "www.ornek.com", "Alan adı (opsiyonel ama aynı portu paylaşan siteler için gerekli)."), c("Start Website immediately", true, "Site oluşturulunca hemen başlatılsın.")] }], "Add Website"), { help: "Yeni bir web sitesi oluşturur." });
    },
    siteBasic() {
      const so = curSite();
      dlg("Edit Site", formHtml([{ sec: "", f: [t("Site name", so.name, "Site adı."), t("Application pool", so.pool, "Kök uygulamanın havuzu. 'Select...' ile değiştirilir."), t("Physical path", so.path, "İçerik klasörü."), ["b", "Connect as... / Test Settings...", "", "Fiziksel yola erişim kimliği ve test."]] }], "Edit Site"), { help: "Sitenin temel ayarları." });
    },
    appBasic() {
      const n = NODES[st.node];
      dlg("Edit Application", formHtml([{ sec: "", f: [l("Site name", curSite().name, "Uygulamanın bulunduğu site."), l("Path", "/", "Üst yol."), t("Alias", n.n, "URL'de görünecek ad: https://site/<alias>"), t("Application pool", n.id === "app2" ? "IKAppPool" : "DefaultAppPool", "Uygulamanın çalışacağı havuz."), t("Physical path", "D:\\Web\\" + n.n, "Uygulamanın klasörü.")] }], "Edit Application"), { help: "Uygulamanın / sanal dizinin temel ayarları." });
    },
    addFarm() {
      dlg("Create Server Farm", `<div class="wz" style="padding:6px 8px">
        <h2 style="font:300 18px var(--font);margin:4px 0 8px">Specify Server Farm Name ${q("Adım 1 – Çiftlik adı", "Sunucu çiftliğine bir ad verirsiniz. Bu ad URL Rewrite kurallarında 'Route to Server Farm' eylemiyle ve http://<ÇiftlikAdı>/{R:0} biçimindeki yeniden yazma adreslerinde kullanılır; boşluk içermemesi önerilir.")}</h2>
        ${formHtml([{ sec: "", f: [t("Server farm name", "WebFarm02", "Çiftliğin benzersiz adı."), c("Online", true, "İşaretliyse çiftlik oluşturulur oluşturulmaz istek almaya hazırdır.")] }], "Create Server Farm")}
        <h2 style="font:300 18px var(--font);margin:10px 0 8px">Add Server ${q("Adım 2 – Sunucu ekleme", "Çiftliğe arka uç sunucuları eklersiniz. Her sunucu için adres girilip Add'e basılır; eklenen sunucular alttaki listede görünür. Advanced settings ile portlar ve ağırlık değiştirilebilir.")}</h2>
        ${formHtml([{ sec: "", f: [t("Server address", "WEB04", "Arka uç sunucunun adı, FQDN'i veya IP adresi."), c("Online", true, "Sunucu eklenir eklenmez istek alsın."), t("httpPort", "80", "(Advanced settings) Arka uç HTTP portu."), t("httpsPort", "443", "(Advanced settings) Arka uç HTTPS portu."), t("weight", "100", "(Advanced settings) Ağırlıklı yük dengelemedeki payı."), ["b", "Add", "", "Girilen sunucuyu aşağıdaki listeye ekler."]] }], "Add Server")}
        <div style="border:1px solid #828790;min-height:70px">${table([["Server Address", "Eklenmiş sunucunun adresi."], ["Online", "Çevrimiçi durumu."]], [{ c: ["WEB04", "True"] }, { c: ["WEB05", "True"] }], -1, "data-x")}</div>
        <div class="legend-q" style="margin-top:10px">Finish'e bastığınızda IIS şunu sorar: <i>"IIS Manager can create a URL rewrite rule to route all incoming requests to this server farm. Do you want to create this rewrite rule automatically?"</i> ${q("Otomatik URL Rewrite kuralı", "Yes derseniz sunucu düzeyinde 'ARR_<ÇiftlikAdı>_loadbalance' adlı, TÜM istekleri (*) bu çiftliğe yönlendiren bir kural oluşturulur. Bu sunucuda başka siteler de varsa onların istekleri de çiftliğe gider! Sunucu yalnızca yük dengeleyici değilse No deyip kuralı kendiniz, koşullu (ör. Host = shop.com) olarak yazın.")}</div></div>`,
        { size: "wide", help: "Application Request Routing ile yeni bir sunucu çiftliği oluşturma sihirbazı.", footer: `<button class="btn" disabled>&lt; Previous</button><button class="btn" disabled>Next &gt;</button><button class="btn pri" data-dlg="ok">Finish</button><button class="btn" data-dlg="close">Cancel</button>`, onOk: () => toast("Simülasyon: WebFarm02 oluşturuldu ve URL Rewrite kuralı önerildi (gerçek sunucuya yazılmaz).") });
    },
    addFarmServer() {
      dlg("Add Server", formHtml([{ sec: "", f: [t("Server address", "WEB04", "Arka uç sunucunun adı, FQDN'i veya IP adresi. ARR sunucusu bu adı çözebilmeli ve sunucuya ilgili porttan erişebilmelidir."), c("Online", true, "Sunucu eklenir eklenmez istek alsın.")] },
        { sec: "Advanced settings", f: [t("httpPort", "80", "Arka uç HTTP portu."), t("httpsPort", "443", "Arka uç HTTPS portu (SSL offloading kapalıysa kullanılır)."), t("weight", "100", "Ağırlıklı yük dengelemedeki payı. Diğer sunucuların yarısı kadar istek alması için 50 yazın.")] }], "Add Server"), { help: "Seçili sunucu çiftliğine yeni bir arka uç sunucu ekler." });
    },
    roles: () => openWizard()
  };

  /* ---------------- Rol ve Özellik Sihirbazı ---------------- */
  const RS = []; const rsOpen = new Set();
  (function idx(n, depth) { n._i = RS.push(n) - 1; n._d = depth; if (n.c) { rsOpen.add(n._i); n.c.forEach((c) => idx(c, depth + 1)); } })(IIS.roleServices, 0);
  const leaves = (n) => (n.c ? n.c.reduce((a, c) => a + leaves(c), 0) : 1);
  let rsSel = 1;
  function rsTree() {
    const out = [];
    (function walk(n) {
      const label = n.c ? `${n.n} (${leaves(n)} of ${leaves(n)} installed)` : `${n.n} (Installed)`;
      out.push(`<div class="rs${rsSel === n._i ? " sel" : ""}" data-rs="${n._i}" style="padding-left:${n._d * 16 + 2}px"><span class="tg" data-rst="${n._i}">${n.c ? (rsOpen.has(n._i) ? "&#9698;" : "&#9655;") : ""}</span><span class="cb on inst"></span><span class="lb">${esc(label)}</span>${q(n.n, n.d, { ctx: "Role Services", links: n.f, tip: n.c ? "Bu bir gruptur; alt öğelerine tek tek bakabilirsiniz." : "" })}</div>`);
      if (n.c && rsOpen.has(n._i)) n.c.forEach(walk);
    })(IIS.roleServices);
    return out.join("");
  }
  function rsDesc() {
    const n = RS[rsSel];
    const links = (n.f || []).filter((id) => FEAT[id]);
    return `<div class="dtx">${esc(n.d)}${links.length ? `<h4>IIS Yöneticisi'nde eklediği özellikler:</h4><div class="flinks">${links.map((id) => `<span class="flink" data-gofeat="${id}">${FIMG(FEAT[id], 16)} ${esc(FEAT[id].n)}</span>`).join("")}</div>` : ""}</div>`;
  }
  function openWizard() {
    const steps = IIS.wizardSteps.map(([s, h], i) => `<div class="${s === "Role Services" ? "on sub" : ""}">${esc(s)} ${q(s, h, { ctx: "Sihirbaz adımı" })}</div>`).join("");
    dlg("Add Roles and Features Wizard", `<div class="wz">
      <div class="wz-head"><h2>Select role services</h2><div class="wz-dest"><b>DESTINATION SERVER</b>WIN-IIS01.firma.local ${q("Destination server", "Rol hizmetlerinin kurulacağı hedef sunucu. Sunucu Yöneticisi'nin sunucu havuzundaki uzak bir sunucu da seçilebilir.")}</div></div>
      <div class="wz-body"><div class="wz-nav">${steps}</div>
      <div class="wz-main"><p>Select the role services to install for Web Server (IIS) ${q("Role services", "Web Server (IIS) rolü için kurulacak bileşenleri (rol hizmetlerini) seçtiğiniz liste. Bu simülasyonda tüm bileşenler kurulu (Installed) görünür. Bir öğeye tıkladığınızda sağdaki Description alanında ne işe yaradığı ve IIS Yöneticisi'nde hangi özellik simgesini eklediği görünür; simgeye tıklayarak o özelliğin sayfasına gidebilirsiniz.")}</p>
        <div class="wz-cols"><div class="wz-tree"><div class="lbl">Role services</div><div class="wz-list" id="rsList">${rsTree()}</div></div>
        <div class="wz-desc"><div class="lbl">Description</div><div id="rsDesc" style="display:flex;flex-direction:column;flex:1;min-height:0">${rsDesc()}</div></div></div></div></div></div>`,
      { size: "xwide", help: "Sunucu Yöneticisi > Manage > Add Roles and Features ile açılan sihirbazın 'Role Services' adımı. IIS'in hangi bileşenlerinin kurulu olduğunu burada görür, ek bileşen kurar veya (Remove Roles and Features ile) kaldırırsınız. PowerShell eşdeğeri: Install-WindowsFeature Web-Server -IncludeAllSubFeature -IncludeManagementTools",
        footer: `<button class="btn" data-dlg="toast" data-msg="Önceki adım: Web Server Role (IIS)">&lt; Previous</button><button class="btn" data-dlg="toast" data-msg="Sonraki adım: Confirmation – tüm bileşenler zaten kurulu.">Next &gt;</button><button class="btn" disabled>Install</button><button class="btn" data-dlg="close">Cancel</button>` });
  }
  const refreshWizard = () => { const l = $("#rsList"); if (!l) return; const sc = l.scrollTop; l.innerHTML = rsTree(); l.scrollTop = sc; $("#rsDesc").innerHTML = rsDesc(); };

  function doAction(a) {
    const k = a[3];
    if (!k) { showHelp({ t: a[0], d: a[2], ctx: "Actions", tip: "Bu bir simülasyondur; işlem gerçek bir sunucuda çalıştırılmaz." }); return; }
    if (k.startsWith("nav:")) return go(k.slice(4));
    if (k === "helpFeat") { const f = FEAT[st.feature]; return showHelp(featHelp(f, { t: f.n, d: f.d })); }
    if (k === "openFeat") return go(st.node, st.selFeat);
    if (k === "openSite") return go(["site1", "site2", "site3"][st.selSite]);
    if (k === "openFarm") return go("farm" + (st.selFarm + 1));
    if (k === "poolStart" || k === "poolStop") { const p = curPool(); p.status = k === "poolStart" ? "Started" : "Stopped"; toast("Simülasyon: '" + p.name + "' " + (p.status === "Started" ? "başlatıldı." : "durduruldu – uygulamalar 503 döner.")); return render(); }
    if (k === "siteStart" || k === "siteStop") { const so = curSite(); so.status = k === "siteStart" ? "Started" : "Stopped"; toast("Simülasyon: '" + so.name + "' " + (so.status === "Started" ? "başlatıldı." : "durduruldu.")); return render(); }
    if (DIALOGS[k]) return DIALOGS[k]();
    showHelp({ t: a[0], d: a[2] });
  }

  /* ---------------- Arama ---------------- */
  let searchIdx = null;
  function buildIndex() {
    const out = [];
    const walkProps = (list, ctx) => list.forEach((p) => Array.isArray(p) ? out.push({ t: p[0], d: p[2], ctx, cfg: p[3], def: p[1] }) : (out.push({ t: p.sub, d: p.h, ctx, cfg: p.cfg }), walkProps(p.props, ctx + " › " + p.sub)));
    IIS.features.forEach((f) => {
      out.push(featHelp(f, { t: f.n, d: f.d, open: f.id }));
      (f.grid || []).forEach((cat) => walkProps(cat.props, f.n + " › " + cat.cat));
      (f.form || []).forEach((sec) => sec.f.forEach((fl) => out.push({ t: fl[1], d: fl[3], ctx: f.n + (sec.sec ? " › " + sec.sec : "") })));
      (f.list ? f.list.rows : []).forEach((rw) => rw.h && out.push({ t: String(rw.c[0]), d: rw.h, ctx: f.n }));
      (f.acts || []).forEach((a) => out.push({ t: a[0], d: a[2], ctx: f.n + " › Actions" }));
    });
    IIS.poolAdvanced.forEach((cat) => walkProps(cat.props, "Application Pool › " + cat.cat));
    IIS.siteAdvanced.forEach((cat) => walkProps(cat.props, "Site › " + cat.cat));
    RS.forEach((n) => out.push({ t: n.n, d: n.d, ctx: "Rol hizmeti (Add Roles and Features)", links: n.f }));
    return out.filter((x) => x.d);
  }
  function runSearch(qs) {
    searchIdx = searchIdx || buildIndex();
    const words = qs.toLocaleLowerCase("tr").split(/\s+/).filter(Boolean);
    const hits = searchIdx.map((x) => { const tl = x.t.toLocaleLowerCase("tr"), hay = (x.t + " " + x.d + " " + (x.ctx || "")).toLocaleLowerCase("tr"); let sc = 0; for (const w of words) { if (!hay.includes(w)) return null; sc += tl.includes(w) ? 3 : 1; } return [sc, x]; }).filter(Boolean).sort((a, b) => b[0] - a[0]).slice(0, 40);
    $("#helpTitle").textContent = "Arama: " + qs;
    $("#helpBody").innerHTML = hits.length ? `<p>${hits.length} sonuç bulundu.</p>` + hits.map(([, x], i) => `<div class="box" style="cursor:pointer" data-hit="${i}"><b>${esc(x.t)}</b><div class="ctx" style="margin:2px 0 0">${esc(x.ctx || "")}</div><div>${esc(x.d.length > 160 ? x.d.slice(0, 160) + "…" : x.d)}</div></div>`).join("") : "<p>Sonuç bulunamadı.</p>";
    $("#helpBody")._hits = hits.map((h) => h[1]);
    $("#helpPanel").classList.add("open");
  }

  /* ---------------- Olaylar ---------------- */
  document.addEventListener("click", (e) => {
    const qb = e.target.closest(".q");
    if (qb) { e.preventDefault(); e.stopPropagation(); const h = HELP[qb.dataset.h]; if (h) showHelp(h); return; }
    const gf = e.target.closest("[data-gofeat]");
    if (gf) { const id = gf.dataset.gofeat; closeDlg(); go(nodeForFeature(id), id); return; }
    const hit = e.target.closest("[data-hit]");
    if (hit) { const x = $("#helpBody")._hits[+hit.dataset.hit]; if (x.open) go(nodeForFeature(x.open), x.open); showHelp(x); return; }
    if (e.target.closest("#helpClose")) return closeHelp();
    const dop = e.target.closest("[data-dlgopen]");
    if (dop) return DIALOGS[dop.dataset.dlgopen]();
    const dd = e.target.closest("[data-dlg]");
    if (dd) { const kind = dd.dataset.dlg; if (kind === "toast") return toast(dd.dataset.msg); const ok = $("#dlgRoot")._ok; closeDlg(); if (kind === "ok") (ok ? ok() : toast("Simülasyon: değişiklikler kaydedildi (gerçek sunucuya yazılmaz).")); return; }
    if (e.target.classList.contains("dlg-back")) return closeDlg();
    const rst = e.target.closest("[data-rst]");
    if (rst && rst.textContent) { const i = +rst.dataset.rst; rsOpen.has(i) ? rsOpen.delete(i) : rsOpen.add(i); return refreshWizard(); }
    const rs = e.target.closest("[data-rs]");
    if (rs) { rsSel = +rs.dataset.rs; return refreshWizard(); }
    const tg = e.target.closest("[data-tg]");
    if (tg && tg.textContent) { const n = NODES[tg.dataset.tg]; n.open = !n.open; return renderTree(); }
    const nd = e.target.closest("[data-node]");
    if (nd) return go(nd.dataset.node);
    const grp = e.target.closest("[data-grp]");
    if (grp) { const g = grp.dataset.grp; st.collapsed[g] = !st.collapsed[g]; return renderCenter(); }
    const fi = e.target.closest("[data-feat]");
    if (fi) {
      const old = document.querySelector(".fi.sel"); if (old) { old.classList.remove("sel"); old.querySelector(".fn").innerHTML = tileLabel(FEAT[old.dataset.feat].n); }
      st.selFeat = fi.dataset.feat; fi.classList.add("sel"); fi.querySelector(".fn").textContent = FEAT[st.selFeat].n; renderActions(); $("#status").textContent = FEAT[st.selFeat].n + " – çift tıklayarak açın"; return; }
    const pr = e.target.closest("[data-pool]");
    if (pr) { st.selPool = +pr.dataset.pool; renderCenter(); renderActions(); return; }
    const sr = e.target.closest("[data-site]");
    if (sr) { st.selSite = +sr.dataset.site; renderCenter(); renderActions(); return; }
    const fm = e.target.closest("[data-farm]");
    if (fm) { st.selFarm = +fm.dataset.farm; renderCenter(); renderActions(); return; }
    const fr = e.target.closest("[data-frow]");
    if (fr) { st.selRow = +fr.dataset.frow; document.querySelectorAll("tr.row.sel").forEach((x) => x.classList.remove("sel")); fr.classList.add("sel"); return; }
    const pgt = e.target.closest("[data-pgt]");
    if (pgt && (pgt.classList.contains("cat") || pgt.classList.contains("tg"))) { const [id, key] = pgt.dataset.pgt.split("|"); const G = PGS[id]; G.col.has(key) ? G.col.delete(key) : G.col.add(key); applyPg(id); return; }
    const pgr = e.target.closest("[data-pr]");
    if (pgr) {
      const [id, k] = pgr.dataset.pr.split(":"); const p = PGS[id].items[+k];
      pgr.parentNode.querySelectorAll(".r.sel").forEach((x) => x.classList.remove("sel")); pgr.classList.add("sel");
      const d = document.getElementById(id + "-d"); if (d) d.innerHTML = `<b>${esc(p.nm)}</b>${p.cfg ? "[" + esc(attrOf(p.cfg)) + "] " : ""}${esc(p.h)}`; return;
    }
    const ac = e.target.closest("[data-act]");
    if (ac) return doAction(ACTS[+ac.dataset.act]);
    const vt = e.target.closest("[data-view]");
    if (vt) { const n = NODES[st.node]; if (["pools", "sites", "farms"].includes(n.type) || (n.type === "farm" && vt.dataset.view === "content")) return; st.feature = null; st.view = vt.dataset.view; render(); return; }
    if (e.target.closest("#fltGo")) { st.filter = $("#flt").value; renderCenter(); return; }
    if (e.target.closest("#fltAll")) { st.filter = ""; renderCenter(); return; }
  });
  document.addEventListener("dblclick", (e) => {
    if (e.target.closest(".q")) return;
    const fi = e.target.closest("[data-feat]"); if (fi) return go(st.node, fi.dataset.feat);
    const pr = e.target.closest("[data-pool]"); if (pr) { st.selPool = +pr.dataset.pool; return DIALOGS.editPool(); }
    const sr = e.target.closest("[data-site]"); if (sr) return go(["site1", "site2", "site3"][+sr.dataset.site]);
    const fm = e.target.closest("[data-farm]"); if (fm) return go("farm" + (+fm.dataset.farm + 1));
    const rs = e.target.closest("[data-rs]"); if (rs) { const i = +rs.dataset.rs; if (RS[i].c) { rsOpen.has(i) ? rsOpen.delete(i) : rsOpen.add(i); refreshWizard(); } return; }
    const tn = e.target.closest(".tn"); if (tn) { const n = NODES[tn.dataset.node]; if (n.children) { n.open = !n.open; renderTree(); } }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { if ($("#helpPanel").classList.contains("open")) closeHelp(); else closeDlg(); }
    if (e.key === "Enter" && e.target.id === "flt") { st.filter = e.target.value; renderCenter(); const i = $("#flt"); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
    if (e.key === "Enter" && e.target.id === "gsearch" && e.target.value.trim()) runSearch(e.target.value.trim());
    if (e.key === "Enter" && e.target.matches && e.target.matches(".fi")) go(st.node, e.target.dataset.feat);
  });
  document.addEventListener("change", (e) => { if (e.target.id === "grp") { st.groupBy = e.target.value; renderCenter(); } });
  $("#btnBack").onclick = () => { const p = st.back.pop(); if (!p) return; st.fwd.push([st.node, st.feature]); go(p[0], p[1], true); };
  $("#btnFwd").onclick = () => { const p = st.fwd.pop(); if (!p) return; st.back.push([st.node, st.feature]); go(p[0], p[1], true); };

  renderStatic();
  render();
})();
