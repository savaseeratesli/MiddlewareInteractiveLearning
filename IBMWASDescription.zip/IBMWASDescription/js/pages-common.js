/* pages-common.js – Ortak sayfa altyapısı: genel kaynak (resource) tipi,
   custom properties, kaydetme (Save), Welcome ve bağlantı yardımcıları. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act;

  /* ------------------------------------------------------------ bağlantılar */
  W.srvLink = function (name) { var s = W.srv(name); return s ? '<a href="#/servers/appservers/' + W.enc(name) + '">' + esc(name) + '</a>' : esc(name); };
  W.nodeLink = function (n) { return '<a href="#/sys/nodes/' + W.enc(n) + '">' + esc(n) + '</a>'; };
  W.clusterLink = function (c) { return c ? '<a href="#/clusters/' + W.enc(c) + '">' + esc(c) + '</a>' : ''; };
  W.appLink = function (a) { return '<a href="#/apps/' + W.enc(a) + '">' + esc(a) + '</a>'; };
  W.scopeLink = function (s) {
    var p = (s || 'cell').split(':');
    if (p[0] === 'cluster') return W.clusterLink(p[1]);
    if (p[0] === 'server') return W.nodeLink(p[1]) + ' / ' + W.srvLink(p[2]);
    if (p[0] === 'node') return W.nodeLink(p[1]);
    return '<a href="#/sys/cell">' + esc(W.S.cell.name) + '</a>';
  };
  W.scopeCol = { k: 'scope', l: 'Scope', h: 'concept.scope', fmt: function (r) { return '<span class="badge ' + W.scopeShort(r.scope).toLowerCase() + '">' + W.scopeShort(r.scope) + '</span> ' + esc(W.scopeLabel(r.scope)); }, sv: function (r) { return W.scopeLabel(r.scope); } };

  W.prefs = function () {
    return '<div class="prefs" data-act="togglePrefs"><span class="tg plus"></span>Preferences</div><div class="prefs-body" style="display:none">Maximum rows <input type="text" value="20" size="4" class="short"> <label><input type="checkbox"> Retain filter criteria</label> <button class="btn" type="button" data-act="togglePrefs">Apply</button> <span style="color:#666">(Simülasyonda tüm satırlar gösterilir.)</span></div>';
  };
  A.togglePrefs = function (el) {
    var p = el.closest('.pb').querySelector('.prefs'), b = p.nextElementSibling;
    var open = b.style.display === 'none'; b.style.display = open ? '' : 'none'; p.querySelector('.tg').classList.toggle('plus', !open);
  };

  /* ----------------------------------------------------- generic resources */
  W.resTypes = {};
  var uid = 1000;
  W.newId = function (p) { return (p || 'id') + (++uid) + Math.floor(Math.random() * 1000); };
  W.resType = function (d) {
    W.resTypes[d.id] = d;
    d.list = d.list || function () { return W.getPath(W.S, d.coll); };
    d.singular = d.singular || d.title;
    d.file = d.file || 'resources.xml';
    W.route(d.path, function () {
      var rows = d.list().filter(function (r) { return !d.scoped || W.inScope(d.id, r.scope); });
      var cols = d.cols.map(function (c, i) {
        if (i === 0 && !c.fmt) return Object.assign({}, c, { fmt: function (r) { return '<a href="#' + d.path + '/' + W.enc(r.id || r.name) + '">' + esc(r[c.k]) + '</a>'; } });
        return c;
      });
      if (d.scoped) cols.push(W.scopeCol);
      var btns = d.readOnly ? [] : [{ l: 'New...', act: 'nav', href: d.newHref || ('#' + d.path + '/new') }, { l: 'Delete', act: 'resDelete', arg: d.id, need: 1 }];
      if (d.buttons) btns = btns.concat(d.buttons);
      return {
        title: d.title, help: d.help,
        html: (d.crumbless ? '' : '<div class="page-title">' + esc(d.title) + W.hi(d.help) + '</div>') + '<p class="desc">' + d.desc + '</p>' + (d.note ? '<div class="note-tr">' + d.note + '</div>' : '') +
          (d.scoped ? W.scopeBox(d.id) : '') + W.prefs() +
          W.table({ id: 'rt_' + d.id, cols: cols, rows: rows, buttons: btns, key: function (r) { return r.id || r.name; } }) + (d.after ? d.after() : '')
      };
    });
    W.route(d.path + '/:id', function (p) {
      var isNew = p.id === 'new';
      var o = isNew ? d.defaults(W.currentScope(d.id) === 'all' ? 'cell' : W.currentScope(d.id)) : (W.by(d.list(), 'id', p.id) || W.by(d.list(), 'name', p.id));
      if (!o) return { title: d.title, html: '<p>Kaynak bulunamadı: ' + esc(p.id) + '</p>' };
      var general = '';
      if (d.scoped) general += isNew ? F.sel({ l: 'Scope', n: '__scope', v: o.scope, o: W.scopeOptions(false), h: 'concept.scope' }) : F.ro({ l: 'Scope', v: W.scopeFull(o.scope), h: 'concept.scope' });
      general += d.form(o, isNew);
      return {
        title: d.title, help: d.help,
        html: W.crumbs([[d.title, '#' + d.path], isNew ? 'New...' : (o.name || o.id)]) + (d.detailNote ? '<div class="note-tr">' + d.detailNote(o) + '</div>' : '') +
          W.cfgForm({
            ref: d.refBase ? d.refBase + '|' + o.id : (d.coll + '|' + (o.id || o.name)), create: isNew ? d.id : '', back: '#' + d.path, doc: W.scopeDoc(o.scope) + d.file,
            cfgid: (d.scoped ? W.cfgScope(o.scope) : '/Cell:' + W.S.cell.name + '/') + (d.cfgType || 'Resource') + ':' + (o.name || '') + '/', title: d.singular + ' ' + (o.name || ''),
            general: general, ap: !isNew && d.ap ? d.ap(o) : null, tabs: [['Configuration', '#', true]], validate: d.validate || ''
          })
      };
    });
    W.creators[d.id] = function (vals) {
      var o = d.defaults(vals.__scope || 'cell');
      if (d.scoped) o.scope = vals.__scope || 'cell';
      delete vals.__scope;
      Object.keys(vals).forEach(function (k) { W.setPath(o, k, vals[k]); });
      var nm = o.name || o.id;
      if (d.list().some(function (x) { return (x.name || x.id) === nm && (!d.scoped || x.scope === o.scope); })) return { error: 'Bu kapsamda "' + nm + '" adlı bir kaynak zaten var. (The name ' + nm + ' already exists in this scope.)' };
      if (!o.id) o.id = W.newId(d.id);
      if (d.beforeCreate) { var e = d.beforeCreate(o); if (e) return { error: e }; }
      if (d.add) d.add(o); else d.list().push(o);
      W.change(W.scopeDoc(o.scope) + d.file, d.singular + ' oluşturuldu: ' + nm);
      W.cmd(d.singular + ' oluştur: ' + nm, d.createCmd ? d.createCmd(o) : ["AdminConfig.create('" + (d.cfgType || 'Resource') + "', AdminConfig.getid('" + W.cfgScope(o.scope) + "'), [['name', '" + nm + "']])", 'AdminConfig.save()']);
      return { msgs: [esc(d.singular) + ' <b>' + esc(nm) + '</b> oluşturuldu (' + esc(W.scopeFull(o.scope)) + ').'], go: '#' + d.path };
    };
  };
  A.resDelete = function (el) {
    var d = W.resTypes[el.dataset.arg], ids = W.selected(el.dataset.tbl), L = d.list(), msgs = [];
    ids.forEach(function (id) {
      var o = W.by(L, 'id', id) || W.by(L, 'name', id);
      if (!o) return;
      if (o.builtIn) { msgs.push(esc(o.name) + ' yerleşik (built-in) bir kaynaktır, silinemez.'); return; }
      if (d.canDelete) { var e = d.canDelete(o); if (e) { msgs.push(e); return; } }
      var real = W.getPath(W.S, d.coll) || L; real.splice(real.indexOf(o), 1);
      W.change(W.scopeDoc(o.scope) + d.file, d.singular + ' silindi: ' + (o.name || o.id));
      W.cmd(d.singular + ' sil: ' + (o.name || o.id), ["AdminConfig.remove(AdminConfig.getid('" + W.cfgScope(o.scope) + (d.cfgType || 'Resource') + ':' + (o.name || o.id) + "/'))", 'AdminConfig.save()']);
      msgs.push(esc(o.name || o.id) + ' silindi.');
    });
    W.clearSel(el.dataset.tbl);
    W.msg('info', msgs); W.rerender();
  };

  /* -------------------------------------------------- custom properties */
  // #/props/<ref>/<field>?back=..&title=..
  W.propsLink = function (ref, field, title, back) {
    return '#/props/' + W.enc(ref) + '/' + field + '?title=' + W.enc(title) + '&back=' + W.enc(back);
  };
  W.route('/props/:ref/:field', function (p, q) {
    var o = W.resolve(p.ref);
    if (!o) return { title: 'Custom properties', html: 'Nesne bulunamadı.' };
    if (!o[p.field]) o[p.field] = [];
    var arr = o[p.field];
    var title = q.title || 'Custom properties';
    var isSys = p.field === 'systemProperties';
    return {
      title: title, help: isSys ? 'jvm.customProps' : 'concept.customProps',
      html: W.crumbs([[q.back ? 'Geri' : title, q.back || ''], 'Custom properties']) +
        '<p class="desc">' + (isSys ? 'Bu JVM için Java sistem özelliklerini (<code>-Dname=value</code>) tanımlar. Değişiklikler sunucu yeniden başlatıldığında geçerli olur.' : 'Bu bileşen için ek yapılandırma özelliklerini (name/value) tanımlar. Yalnızca IBM dokümantasyonunda veya destek (PMR) yönlendirmesinde belirtilen özellikleri ekleyin.') + '</p>' + W.prefs() +
        W.table({ id: 'props', sig: p.ref + p.field, rows: arr, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'value', l: 'Value' }, { k: 'description', l: 'Description' }],
          buttons: [{ l: 'New...', act: 'propNew', arg: p.ref + '§' + p.field }, { l: 'Delete', act: 'propDel', arg: p.ref + '§' + p.field, need: 1 }] })
    };
  });
  A.propNew = function (el) {
    var a = el.dataset.arg.split('§');
    W.modal({ title: 'New custom property', html: '<form id="propForm" onsubmit="return false">' + F.text({ l: 'Name', n: 'name', req: true, h: 'concept.customProps' }) + F.text({ l: 'Value', n: 'value' }) + F.text({ l: 'Description', n: 'description' }) + '</form>',
      buttons: [{ l: 'OK', fn: function () {
        var r = W.readForm(document.getElementById('propForm'));
        if (r.errs.length || !r.vals.name) { alert('Name zorunludur.'); return false; }
        var o = W.resolve(a[0]); o[a[1]] = o[a[1]] || []; o[a[1]].push({ name: r.vals.name, value: r.vals.value, description: r.vals.description });
        W.change('workspace', 'Custom property eklendi: ' + r.vals.name);
        W.cmd('Custom property ekle', ["AdminConfig.create('" + (a[1] === 'systemProperties' ? 'Property' : 'Property') + "', <parent>, [['name', '" + r.vals.name + "'], ['value', '" + r.vals.value + "']])", 'AdminConfig.save()']);
        W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.propDel = function (el) {
    var a = el.dataset.arg.split('§'), o = W.resolve(a[0]), sel = W.selected(el.dataset.tbl);
    o[a[1]] = o[a[1]].filter(function (x) { return sel.indexOf(x.name) < 0; });
    W.change('workspace', 'Custom property silindi: ' + sel.join(', ')); W.clearSel(el.dataset.tbl); W.rerender();
  };

  /* -------------------------------------------------------------- save */
  W.route('/save', function () {
    var rows = W.pending.map(function (p, i) { return { id: 'c' + i, doc: p.doc, desc: p.desc, time: p.time }; });
    var html = '<div class="page-title">Save changes to master repository' + W.hi('concept.workspace') + '</div>';
    if (!rows.length) {
      html += '<p class="desc">There are no changes to the local configuration. (Yerel çalışma alanında kaydedilecek değişiklik yok.)</p><div class="note-tr">Konsolda yapılan konfigürasyon değişiklikleri önce kullanıcının <b>workspace</b> alanına yazılır (<code>wstemp</code>). <b>Save</b> ile Deployment Manager\'daki <b>master repository</b>\'ye (<code>profiles/Dmgr01/config</code>) aktarılır; ardından node agent\'lar <b>File Synchronization Service</b> ile değişiklikleri kendi node\'larının yerel repository\'sine çeker.</div>';
    } else {
      html += '<p class="desc">Click <b>Save</b> to update the master repository with your changes. Click <b>Discard</b> to discard your changes and begin work again using the master repository configuration. Click <b>Cancel</b> to continue working with your changes.</p>' +
        '<div class="note-tr">Kaydet: değişiklikler master repository\'ye yazılır. Vazgeç (Discard): workspace silinir. İptal (Cancel): değişikliklerle çalışmaya devam edilir.</div>' +
        '<div class="ck-line"><input type="checkbox" id="syncNodes" checked><label for="syncNodes">Synchronize changes with Nodes</label>' + W.hi('sys.syncNodes') + '</div>' +
        '<div class="fld"><b>Total changed documents: ' + rows.length + '</b></div>' +
        W.table({ id: 'saveTbl', select: false, tools: false, adminRow: false, rows: rows, cols: [{ k: 'doc', l: 'Changed items (repository document)' }, { k: 'desc', l: 'Açıklama' }, { k: 'time', l: 'Saat' }] }) +
        '<div class="btnrow"><button class="btn primary" data-act="saveConfirm">Save</button><button class="btn" data-act="saveDiscard">Discard</button><button class="btn" data-act="goBack">Cancel</button></div>';
    }
    return { title: 'Save', help: 'concept.workspace', noPending: true, html: html };
  });
  A.saveConfirm = function () {
    var sync = document.getElementById('syncNodes'); sync = sync ? sync.checked : true;
    var n = W.saveMaster(), msgs = [n + ' değişiklik master repository\'ye kaydedildi.'];
    var cmds = ['AdminConfig.save()'];
    if (sync) {
      W.S.nodeAgents.forEach(function (na) {
        if (W.RT.nodeagents[na.node] === 'started') { W.RT.sync[na.node] = true; msgs.push('ADMS0208I: The configuration synchronization complete for node ' + na.node + '.'); cmds.push("AdminControl.invoke(AdminControl.completeObjectName('type=NodeSync,node=" + na.node + ",*'), 'sync')"); }
        else msgs.push('<span style="color:#c62828">ADMS0005E: Node agent ' + na.node + ' çalışmıyor; node senkronize edilemedi.</span>');
      });
      W.saveRT();
    } else {
      W.S.nodeAgents.forEach(function (na) { W.RT.sync[na.node] = false; }); W.saveRT();
      msgs.push('Node\'lar senkronize edilmedi; node agent\'lar bir sonraki otomatik senkronizasyon döngüsünde (Synchronization interval) değişiklikleri alacak.');
    }
    W.cmd('Kaydet ve senkronize et', cmds);
    W.msg('info', msgs); W.go('#/welcome');
  };
  A.saveDiscard = function () { W.discard(); W.msg('info', 'Workspace değişiklikleri atıldı (discarded). Master repository konfigürasyonu yeniden yüklendi.'); W.go('#/welcome'); };

  /* ------------------------------------------------------------ welcome */
  W.route('/welcome', function () {
    var c = W.S.cell, upS = W.S.servers.filter(function (s) { return W.serverStatus(s) === 'started'; }).length;
    var welcome = W.portlet('Welcome', '<!--MSGS--><p class="desc" style="margin-top:8px">Integrated Solutions Console provides a common administrative console for multiple products. The table lists the product suites that can be administered through this installation. Select a product suite to view more information.</p>' +
      '<div class="tblwrap" style="margin:12px 0"><table class="wt"><thead><tr><th>Suite Name</th><th>Version</th></tr></thead><tbody><tr class="r"><td><a href="#/learn">WebSphere Application Server</a>' + W.hi('concept.was') + '</td><td>' + esc(c.version.replace('ND ', '')) + '.0</td></tr></tbody><tfoot><tr><td colspan="2">&nbsp;</td></tr></tfoot></table></div>' +
      '<div class="note-tr"><b>IBM WAS Eğitim Simülasyonu</b> – Bu arayüz gerçek bir IBM WebSphere Application Server\'a <b>bağlı değildir</b>. Tüm sunucular, uygulamalar ve kaynaklar örnek verilerdir; yaptığınız işlemler yalnızca tarayıcınızda simüle edilir. ' +
      'Her alanın yanındaki <span class="hi" style="cursor:default">?</span> simgesine tıklayarak o özelliğin ne işe yaradığını, hangi seviyede (Cell/Node/Cluster/Server/Application) yapılandırıldığını ve yanlış yapılandırma risklerini öğrenebilirsiniz.</div>' +
      '<div class="kpis">' +
      kpi('Cell', esc(c.name), 'concept.cell', 'Deployment Manager: dmgr') +
      kpi('Nodes', W.S.nodes.length, 'concept.node', '1 DMGR, 3 managed, 2 unmanaged (IHS)') +
      kpi('Application servers', upS + ' / ' + W.S.servers.length, 'concept.appserver', 'çalışan / toplam') +
      kpi('Clusters', W.S.clusters.length, 'concept.cluster', W.S.clusters.map(function (x) { return x.name; }).join(', ')) +
      kpi('Enterprise applications', W.S.apps.length, 'concept.enterpriseApp', 'EAR dosyaları') +
      kpi('Web servers', W.S.webservers.length, 'concept.webserver', 'IBM HTTP Server + Plug-in') +
      '</div>' +
      '<div class="cards">' +
      card('Hızlı başlangıç', 'Önce <a href="#/learn/topology">hücre topolojisini</a> inceleyin, sonra <a href="#/servers/appservers">Application servers</a> sayfasında bir sunucuyu açıp JVM ayarlarına bakın.', 'concept.cell') +
      card('İstek akışını izleyin', '<a href="#/learn/requestflow">F5 → IHS → Plugin → WAS</a> simülatöründe bir URL girin ve isteğin hangi cluster üyesine yönlendirildiğini adım adım görün.', 'concept.plugin') +
      card('Bir uygulama kurun', '<a href="#/apps/new">New Application</a> sihirbazı ile örnek bir EAR kurun; ardından <a href="#/save">Save</a> ile master repository\'ye kaydedin.', 'app.install') +
      card('Simülasyonu sıfırla', 'Tüm örnek verileri ve sunucu durumlarını başlangıç haline döndürür. <br><button class="btn" data-act="resetSim" style="margin-top:6px">Simülasyonu sıfırla</button>', 'concept.simulation') +
      '</div>', { help: 'concept.was' });
    var about = W.portlet('About this Integrated Solutions Console', '<pre class="code light" style="max-height:180px;white-space:pre-wrap">Integrated Solutions Console, 9.0.0.0\nBuild Number: gm1621.04\nBuild Date: 5/26/16\n-----------------------------------------\n' + esc(c.product) + '\nVersion ' + esc(c.version) + '\nJava: ' + esc(c.javaSdk) + '\n\nEĞİTİM SİMÜLASYONU – IBM ürünü değildir.\nIBM, WebSphere ve IBM HTTP Server, IBM Corp.\'un ticari markalarıdır.</pre>', {});
    return { title: 'Welcome', help: 'concept.was', raw: true, html: '<div class="detail" style="gap:14px"><div class="gp" style="flex:1 1 560px">' + welcome + '</div><div class="ap" style="flex:0 1 300px">' + about + '</div></div>' };
    function kpi(l, v, h, s) { return '<div class="kpi"><div class="kl">' + esc(l) + W.hi(h) + '</div><div class="kv">' + v + '</div><div class="ks">' + esc(s) + '</div></div>'; }
    function card(t, b, h) { return '<div class="card"><h4>' + esc(t) + W.hi(h) + '</h4><p>' + b + '</p></div>'; }
  });
  A.resetSim = function () {
    W.modal({ title: 'Simülasyonu sıfırla', html: '<p>Kaydedilmiş tüm konfigürasyon değişiklikleri, oluşturduğunuz kaynaklar ve sunucu durumları başlangıç örnek verilerine döndürülecek. Devam edilsin mi?</p>', buttons: [{ l: 'Sıfırla', fn: function () { W.resetSimulation(); } }, { l: 'İptal' }] });
  };
  A.logout = function () {
    var main = document.getElementById('content');
    if (W.pending.length) {
      W.modal({ title: 'Logout', html: '<p>Kaydedilmemiş ' + W.pending.length + ' değişiklik var. (Your workspace contains unsaved changes.) Çıkış yapılırsa workspace korunur ancak master repository güncellenmez.</p>', buttons: [{ l: 'Save and logout', fn: function () { W.saveMaster(); loggedOut(); } }, { l: 'Discard and logout', fn: function () { W.discard(); loggedOut(); } }, { l: 'Cancel' }] });
      return;
    }
    loggedOut();
    function loggedOut() {
      document.body.innerHTML = '<div class="portlet loggedout"><div class="ph"><span>WebSphere Integrated Solutions Console</span></div><div class="pb"><p><b>Oturum kapatıldı.</b> (You have logged out of the console.)</p><p>Bu bir eğitim simülasyonudur; tekrar giriş için kimlik bilgisi gerekmez.</p><button class="btn primary" onclick="location.hash=\'#/welcome\';location.reload()">Tekrar giriş yap</button></div></div>';
    }
    void main;
  };
})();
