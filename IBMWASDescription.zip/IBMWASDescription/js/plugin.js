/* plugin.js – plugin-cfg.xml ve httpd.conf üreticisi + istek yönlendirme motoru.
   Mevcut simülasyon konfigürasyonundan (cluster, uygulama, virtual host) üretilir. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc;
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  W.cloneId = function (s) { return hash(W.S.cell.name + '/' + s.node + '/' + s.name).slice(0, 8); };
  function clusterNameFor(t) { var p = t.split(':'); return p[0] === 'cluster' ? p[1] : p[2] + '_' + p[1] + '_Cluster'; }
  function membersFor(t) {
    var p = t.split(':');
    if (p[0] === 'cluster') { var c = W.cluster(p[1]); return c ? c.members.map(function (m) { return { s: W.srv(m.name), w: m.weight }; }).filter(function (x) { return x.s; }) : []; }
    var s = W.srv(p[2]); return s ? [{ s: s, w: 2 }] : [];
  }
  /* Bir web server'a eşlenmiş route listesi */
  W.pluginModel = function (ws) {
    var apps = ws ? W.appsOnWebserver(ws) : W.S.apps.filter(function (a) { return a.modules.some(function (m) { return m.type === 'web'; }); });
    var routes = {}, vhosts = {}, clusters = {};
    apps.forEach(function (a) {
      var tgt = a.targets.filter(function (t) { return t.indexOf('webserver:') !== 0; })[0];
      if (!tgt) return;
      var cn = clusterNameFor(tgt);
      clusters[cn] = { name: cn, target: tgt, members: membersFor(tgt) };
      a.modules.filter(function (m) { return m.type === 'web'; }).forEach(function (m) {
        var key = m.vhost + '|' + cn;
        if (!routes[key]) routes[key] = { vhost: m.vhost, cluster: cn, uris: [] };
        var cr = m.contextRoot === '/' ? '' : m.contextRoot;
        routes[key].uris.push({ uri: (cr || '') + '/*', app: a.name, module: m.uri, ctx: m.contextRoot });
        vhosts[m.vhost] = true;
      });
    });
    return { routes: Object.keys(routes).map(function (k) { return routes[k]; }), vhosts: Object.keys(vhosts), clusters: Object.keys(clusters).map(function (k) { return clusters[k]; }) };
  };
  W.pluginCfg = function (ws) {
    var g = ws ? ws.plugin : W.S.webservers[0].plugin, m = W.pluginModel(ws), I = '   ';
    var d = new Date(), dt = d.getFullYear() + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + ('0' + d.getDate()).slice(-2);
    var x = '<?xml version="1.0" encoding="UTF-8"?><!--HTTP server plugin config file for the ' + (ws ? 'webserver ' + W.S.cell.name + '.' + ws.node + '.' + ws.name : 'cell ' + W.S.cell.name) + ' generated on ' + dt + ' at ' + d.toLocaleTimeString('en-US') + ' GMT+03:00-->\n\n';
    x += '<Config ASDisableNagle="false" AcceptAllContent="' + g.AcceptAllContent + '" AppServerPortPreference="' + g.AppServerPortPreference + '" ChunkedResponse="' + g.ChunkedResponse + '" FIPSEnable="' + g.FIPSEnable + '" FailoverToNext="false" HTTPMaxHeaders="300" IISDisableNagle="false" IISPluginPriority="High" IgnoreDNSFailures="' + g.IgnoreDNSFailures + '" KillWebServerStartUpOnParseErr="false" MarkBusyDown="false" OS400ConvertQueryStringToJobCCSID="false" RefreshInterval="' + g.RefreshInterval + '" ResponseChunkSize="' + g.ResponseChunkSize + '" SSLConsolidate="true" StrictSecurity="false" TrustedProxyEnable="' + g.TrustedProxyEnable + '" VHostMatchingCompat="' + g.VHostMatchingCompat + '">\n';
    x += I + '<Log LogLevel="' + g.LogLevel + '" Name="' + esc(g.logFile) + '"/>\n';
    x += I + '<Property Name="ESIEnable" Value="' + g.ESIEnable + '"/>\n' + I + '<Property Name="ESIMaxCacheSize" Value="' + g.ESIMaxCacheSize + '"/>\n' + I + '<Property Name="ESIInvalidationMonitor" Value="' + g.ESIInvalidationMonitor + '"/>\n' + I + '<Property Name="ESIEnableToPassCookies" Value="false"/>\n' + I + '<Property Name="PluginInstallRoot" Value="' + esc(ws ? ws.pluginInstallRoot : '/opt/IBM/WebSphere/Plugins') + '"/>\n';
    m.vhosts.forEach(function (vn) {
      var vh = W.by(W.S.virtualHosts, 'name', vn); if (!vh) return;
      x += I + '<VirtualHostGroup Name="' + vn + '">\n' + vh.aliases.map(function (a) { return I + I + '<VirtualHost Name="' + a[0] + ':' + a[1] + '"/>\n'; }).join('') + I + '</VirtualHostGroup>\n';
    });
    var kdb = ws ? g.remoteKeyring : '/opt/IBM/WebSphere/Plugins/config/webserver1/plugin-key.kdb';
    m.clusters.forEach(function (c) {
      x += I + '<ServerCluster CloneSeparatorChange="' + g.CloneSeparatorChange + '" GetDWLMTable="false" IgnoreAffinityRequests="true" LoadBalance="' + g.LoadBalance + '" Name="' + c.name + '" PostBufferSize="' + g.PostBufferSize + '" PostSizeLimit="' + g.PostSizeLimit + '" RemoveSpecialHeaders="' + g.RemoveSpecialHeaders + '" RetryInterval="' + g.RetryInterval + '" ServerIOTimeoutRetry="' + g.ServerIOTimeoutRetry + '">\n';
      var prim = [], back = [];
      c.members.forEach(function (mm) {
        var s = mm.s, pp = s.pluginProps, host = W.hostOf(s.node), nm = s.node + '_' + s.name;
        (pp.role === 'BACKUP' ? back : prim).push(nm);
        x += I + I + '<Server CloneID="' + W.cloneId(s) + '" ConnectTimeout="' + pp.connectTimeout + '" ExtendedHandshake="' + pp.extendedHandshake + '" LoadBalanceWeight="' + mm.w + '" MaxConnections="' + pp.maxConnections + '" Name="' + nm + '" ServerIOTimeout="' + pp.serverIOTimeout + '" WaitForContinue="' + pp.waitForContinue + '">\n';
        x += I + I + I + '<Transport ConnectionTTL="28" Hostname="' + host + '" Port="' + s.ports.WC_defaulthost + '" Protocol="http"/>\n';
        x += I + I + I + '<Transport ConnectionTTL="28" Hostname="' + host + '" Port="' + s.ports.WC_defaulthost_secure + '" Protocol="https">\n' + I + I + I + I + '<Property Name="keyring" Value="' + esc(kdb) + '"/>\n' + I + I + I + I + '<Property Name="stashfile" Value="' + esc(kdb.replace('.kdb', '.sth')) + '"/>\n' + I + I + I + '</Transport>\n';
        x += I + I + '</Server>\n';
      });
      x += I + I + '<PrimaryServers>\n' + prim.map(function (n) { return I + I + I + '<Server Name="' + n + '"/>\n'; }).join('') + I + I + '</PrimaryServers>\n';
      if (back.length) x += I + I + '<BackupServers>\n' + back.map(function (n) { return I + I + I + '<Server Name="' + n + '"/>\n'; }).join('') + I + I + '</BackupServers>\n';
      x += I + '</ServerCluster>\n';
    });
    m.routes.forEach(function (r) {
      var ug = r.vhost + '_' + r.cluster + '_URIs';
      x += I + '<UriGroup Name="' + ug + '">\n' + r.uris.map(function (u) { return I + I + '<Uri AffinityCookie="JSESSIONID" AffinityURLIdentifier="jsessionid" Name="' + u.uri + '"/>\n'; }).join('') + I + '</UriGroup>\n';
      x += I + '<Route ServerCluster="' + r.cluster + '" UriGroup="' + ug + '" VirtualHostGroup="' + r.vhost + '"/>\n';
    });
    var rm = W.S.requestMetrics;
    x += I + '<RequestMetrics armEnabled="' + rm.arm + '" loggingEnabled="' + rm.standardLogs + '" rmEnabled="' + rm.enable + '" traceLevel="' + rm.traceLevel + '">\n' + I + I + '<filters enable="false" type="URI">\n' + I + I + I + '<filterValues enable="false" value="/snoop"/>\n' + I + I + I + '<filterValues enable="false" value="/hitcount"/>\n' + I + I + '</filters>\n' + I + I + '<filters enable="false" type="SOURCE_IP">\n' + I + I + I + '<filterValues enable="false" value="255.255.255.255"/>\n' + I + I + I + '<filterValues enable="false" value="254.254.254.254"/>\n' + I + I + '</filters>\n' + I + '</RequestMetrics>\n';
    return x + '</Config>\n';
  };
  W.xmlHighlight = function (x) {
    return esc(x)
      .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="xml-com">$1</span>')
      .replace(/(&lt;\/?)([\w:.-]+)/g, '$1<span class="xml-tag">$2</span>')
      .replace(/([\w:.-]+)=(&quot;[^&]*?&quot;)/g, '<span class="xml-attr">$1</span>=<span class="xml-val">$2</span>');
  };
  W.httpdConf = function (w) {
    return '# ============================================================\n# IBM HTTP Server 9.0 – ' + w.installRoot + '/conf/httpd.conf (ilgili bölümler)\n# ============================================================\nServerRoot "' + w.installRoot + '"\nListen 0.0.0.0:' + w.port + '\nServerName ' + w.host + ':' + w.port + '\nUser nobody\nGroup nobody\n\nThreadLimit         25\nServerLimit         64\nStartServers        2\nMaxRequestWorkers   1600\nMinSpareThreads     25\nMaxSpareThreads     75\nThreadsPerChild     25\nMaxConnectionsPerChild 0\nKeepAlive On\nKeepAliveTimeout 5\n\nLoadModule ibm_ssl_module modules/mod_ibm_ssl.so\nListen 0.0.0.0:443\n<VirtualHost *:443>\n    SSLEnable\n    SSLProtocolDisable SSLv3 TLSv10 TLSv11\n    SSLServerCert ihs_' + w.name + '_cert\n</VirtualHost>\nKeyFile ' + w.installRoot + '/conf/key.kdb\nSSLDisable\n\nErrorLog logs/error_log\nCustomLog logs/access_log common\n\n# --- WebSphere Plug-in (Configure Web Server Definition / WCT tarafından eklenir) ---\nLoadModule was_ap24_module ' + w.pluginInstallRoot + '/bin/64bits/mod_was_ap24_http.so\nWebSpherePluginConfig ' + w.plugin.remoteConfigFile + '\n';
  };
  /* İstek yönlendirme simülasyonu */
  W.routeRequest = function (url, ws, opts) {
    opts = opts || {};
    var steps = [], m = /^(https?):\/\/([^/:]+)(?::(\d+))?(\/[^?#]*)?/i.exec(url.trim());
    if (!m) return { ok: false, steps: ['URL çözümlenemedi. Örnek: https://www.ornekbank.com.tr/corebank/login'] };
    var proto = m[1].toLowerCase(), host = m[2].toLowerCase(), port = +(m[3] || (proto === 'https' ? 443 : 80)), path = m[4] || '/';
    var model = W.pluginModel(ws);
    steps.push('Plug-in isteği alır: Host başlığı <code>' + esc(host + ':' + port) + '</code>, URI <code>' + esc(path) + '</code> (AppServerPortPreference=' + ws.plugin.AppServerPortPreference + ').');
    var cand = [];
    model.routes.forEach(function (r) {
      var vh = W.by(W.S.virtualHosts, 'name', r.vhost);
      var vmatch = vh && vh.aliases.some(function (a) { return (a[0] === '*' || a[0].toLowerCase() === host) && +a[1] === port; });
      r.uris.forEach(function (u) {
        var pre = u.uri.replace(/\/\*$/, '');
        if (path === pre || path.indexOf(pre + '/') === 0 || (pre === '' && path)) cand.push({ r: r, u: u, vmatch: vmatch, len: pre.length });
      });
    });
    if (!cand.length) { steps.push('<b>Eşleşen UriGroup yok.</b> Plug-in isteği işlemez; istek IHS\'in kendi DocumentRoot\'undan sunulmaya çalışılır → çoğunlukla <b>HTTP 404</b>. (Uygulama web server\'a eşlenmemiş veya plugin-cfg.xml güncel değil.)'); return { ok: false, steps: steps, code: 404 }; }
    cand.sort(function (a, b) { return (b.vmatch - a.vmatch) || (b.len - a.len); });
    var c = cand[0];
    steps.push('UriGroup eşleşti: <code>' + esc(c.u.uri) + '</code> → uygulama <b>' + esc(c.u.app) + '</b> / modül ' + esc(c.u.module) + '.');
    if (!c.vmatch) { steps.push('<b>VirtualHostGroup eşleşmedi:</b> <code>' + esc(host + ':' + port) + '</code>, <code>' + esc(c.r.vhost) + '</code> alias listesinde yok. Plug-in isteği yönlendirmez → <b>HTTP 404</b>. Çözüm: virtual host alias ekleyin, plug-in\'i yeniden üretip yayın.'); return { ok: false, steps: steps, code: 404 }; }
    steps.push('VirtualHostGroup eşleşti: <code>' + esc(c.r.vhost) + '</code> → Route → ServerCluster <code>' + esc(c.r.cluster) + '</code>.');
    var cl = W.by(model.clusters, 'name', c.r.cluster), members = cl.members;
    var up = members.filter(function (x) { return W.serverStatus(x.s) === 'started' && x.w > 0; });
    var chosen = null;
    if (opts.affinity) {
      var aff = W.by(members.map(function (x) { return { id: W.cloneId(x.s), x: x }; }), 'id', opts.affinity);
      if (aff) {
        steps.push('JSESSIONID içindeki CloneID <code>' + esc(opts.affinity) + '</code> → <b>' + esc(aff.x.s.name) + '</b> (session affinity).');
        if (W.serverStatus(aff.x.s) === 'started') chosen = aff.x;
        else steps.push('<span style="color:#c62828">' + esc(aff.x.s.name) + ' yanıt vermiyor (connect refused). Plug-in sunucuyu <b>RetryInterval=' + ws.plugin.RetryInterval + ' sn</b> boyunca "down" işaretler ve isteği başka bir üyeye gönderir (failover).</span>');
      }
    }
    if (!chosen) {
      if (!up.length) { steps.push('<b>Cluster\'ın çalışan üyesi yok.</b> Tüm üyeler down → plug-in istemciye <b>HTTP 500 / 503</b> döner; http_plugin.log: <i>ERROR: ws_common: websphereFindServer: Failed to find a server</i>.'); return { ok: false, steps: steps, code: 500 }; }
      W._rr = W._rr || {}; var k = c.r.cluster; W._rr[k] = (W._rr[k] || 0) + 1;
      var bag = []; up.forEach(function (x) { for (var i = 0; i < x.w; i++) bag.push(x); });
      chosen = ws.plugin.LoadBalance === 'Random' ? bag[Math.floor(Math.random() * bag.length)] : bag[W._rr[k] % bag.length];
      steps.push((ws.plugin.LoadBalance === 'Random' ? 'Random' : 'Weighted round robin') + ' ile çalışan üyelerden seçildi (' + up.map(function (x) { return esc(x.s.name) + '[w=' + x.w + ']'; }).join(', ') + ').');
    }
    var s = chosen.s, tp = proto === 'https' ? s.ports.WC_defaulthost_secure : s.ports.WC_defaulthost;
    steps.push('Transport: ' + proto + '://' + esc(W.hostOf(s.node)) + ':' + tp + ' → <b>' + esc(s.name) + '</b> (node ' + esc(s.node) + ') web container (WebContainer thread pool).');
    steps.push('Web container, Host/port ile <b>' + esc(c.r.vhost) + '</b> virtual host\'unu ve context root <code>' + esc(c.u.ctx) + '</code> ile web modülünü bulur; servlet çalışır → <b>HTTP 200</b>. Yanıt aynı yoldan istemciye döner; yeni session ise JSESSIONID sonuna <code>:' + W.cloneId(s) + '</code> CloneID eklenir.');
    return { ok: true, steps: steps, code: 200, server: s, cloneId: W.cloneId(s), cluster: c.r.cluster, app: c.u.app };
  };
})();
