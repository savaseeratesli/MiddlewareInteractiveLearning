/* pages-security.js – Global security, user registry (Federated/LDAP), LTPA,
   SSO, CSIv2, SAS, JAAS, SSL/keystore/sertifika, security domains, roller. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };
  var SEC = function () { return W.S.security; };
  var SECDOC = function () { return 'cells/' + CELL() + '/security.xml'; };
  function secPage(title, extra, body, help) { return { title: title, help: help, html: (extra ? W.crumbs(extra) : '') + body }; }
  var GS = ['Global security', '#/sec/global'];

  R('/sec/global', function () {
    var s = SEC();
    var realmName = { federated: 'Federated repositories', localos: 'Local operating system', ldap: 'Standalone LDAP registry', custom: 'Standalone custom registry' };
    var general =
      '<div class="btnrow" style="border:0;margin-top:0;padding-top:0"><button type="button" class="btn" data-act="notInSim" data-arg="Security Configuration Wizard">Security Configuration Wizard</button><button type="button" class="btn" data-act="secReport">Security Configuration Report</button></div>' +
      F.grp('Administrative security', 'sec.adminSecurity', F.ck({ l: 'Enable administrative security', n: 'adminSecurity', v: s.adminSecurity, h: 'sec.adminSecurity' }) +
        '<div class="ap-link"><a href="#/ug/userroles">Administrative user roles</a>' + W.hi('sec.adminRoles') + '</div><div class="ap-link"><a href="#/ug/grouproles">Administrative group roles</a>' + W.hi('sec.adminRoles') + '</div><div class="ap-link"><a href="#/sec/authgroups">Administrative authentication</a></div>') +
      F.grp('Application security', 'sec.appSecurity', F.ck({ l: 'Enable application security', n: 'appSecurity', v: s.appSecurity, h: 'sec.appSecurity' })) +
      F.grp('Java 2 security', 'sec.java2', F.ck({ l: 'Use Java 2 security to restrict application access to local resources', n: 'java2', v: s.java2, h: 'sec.java2' }) + F.ck({ l: 'Warn if applications are granted custom permissions', n: 'java2Warn', v: s.java2Warn, h: 'sec.java2' }) + F.ck({ l: 'Restrict access to resource authentication data', n: 'restrictResourceAuth', v: s.restrictResourceAuth, h: 'sec.java2' })) +
      F.grp('User account repository', 'concept.userRegistry', F.ro({ l: 'Realm name', v: s.realm, h: 'concept.userRegistry' }) + F.ro({ l: 'Current realm definition', v: realmName[s.registry], h: 'concept.userRegistry' }) +
        '<div class="fld"><div class="lbl">Available realm definitions' + W.hi('concept.userRegistry') + '</div><select id="realmSel">' + Object.keys(realmName).map(function (k) { return '<option value="' + k + '"' + (k === s.registry ? ' selected' : '') + '>' + realmName[k] + '</option>'; }).join('') + '</select> <button type="button" class="btn" data-act="realmConfigure">Configure...</button> <button type="button" class="btn" data-act="realmSetCurrent">Set as current</button></div>');
    var ap = [
      { t: 'Authentication', items: [{ l: 'Authentication mechanisms and expiration (LTPA)', href: '#/sec/ltpa', h: 'sec.ltpa' }, { l: 'Authentication cache settings', href: '#/sec/authcache', h: 'sec.authCache' },
        { sub: 'Web and SIP security', h: 'sec.sso', items: [{ l: 'Single sign-on (SSO)', href: '#/sec/sso', h: 'sec.sso' }, { l: 'General settings', act: 'notInSim', arg: 'Web security general settings', h: 'sec.sso' }, { l: 'SPNEGO Web authentication', act: 'notInSim', arg: 'SPNEGO', h: 'sec.spnego' }, { l: 'Trust association', act: 'notInSim', arg: 'Trust association (TAI)', h: 'sec.tai' }] },
        { sub: 'RMI/IIOP security', h: 'sec.csiv2', items: [{ l: 'CSIv2 inbound communications', href: '#/sec/csiv2?dir=in', h: 'sec.csiv2' }, { l: 'CSIv2 outbound communications', href: '#/sec/csiv2?dir=out', h: 'sec.csiv2' }, { l: 'SAS (legacy)', href: '#/sec/sas', h: 'sec.sas' }] },
        { sub: 'Java Authentication and Authorization Service', h: 'concept.jaas', items: [{ l: 'Application logins', href: '#/sec/jaas/app', h: 'concept.jaas' }, { l: 'System logins', href: '#/sec/jaas/sys', h: 'concept.jaas' }, { l: 'J2C authentication data', href: '#/sec/jaas/j2c', h: 'sec.authAlias' }] }] },
      { t: 'Related Items', items: [{ l: 'Use realm-qualified user names: ' + (s.useRealmQualified ? 'Yes' : 'No'), act: 'notInSim', arg: 'Use realm-qualified user names', h: 'concept.userRegistry' }, { l: 'Security domains', href: '#/sec/domains', h: 'sec.domains' }, { l: 'External authorization providers', act: 'notInSim', arg: 'External authorization providers (JACC)', h: 'sec.jacc' }, { l: 'SSL certificate and key management', href: '#/sec/ssl', h: 'concept.ssl' }, { l: 'Custom properties', href: W.propsLink('security', 'customProps', 'Global security', '#/sec/global'), h: 'concept.customProps' }] }
    ];
    return secPage('Global security', null, '<div class="page-title">Global security' + W.hi('concept.security') + '</div><p class="desc">Use this panel to configure administration and the default application security policy. This security configuration applies to the security policy for all administrative functions and is used as a default security policy for user applications. Security domains can be defined to override and customize the security policies for user applications.</p>' +
      W.cfgForm({ ref: 'security', doc: SECDOC(), cfgid: '/Cell:' + CELL() + '/Security:/', back: '#/sec/global', title: 'Global security', general: general, ap: ap, validate: 'globalsec', gpTitle: false }), 'concept.security');
  });
  W.validators.globalsec = function (v) {
    if (!v.adminSecurity && v.appSecurity) return ['Application security, administrative security etkin olmadan kullanılamaz. (Application security requires administrative security to be enabled.)'];
    if (!v.adminSecurity) W.msg('warning', 'UYARI: Administrative security devre dışı bırakıldı. Konsola ve wsadmin\'e kimlik doğrulamasız erişilebilir; üretim ortamında kesinlikle önerilmez.');
    if (v.java2) W.msg('warning', 'Uyarı: Java 2 security etkinleştirildi. Uygulamalar was.policy dosyasında izin verilmeyen işlemlerde java.security.AccessControlException alabilir; performans etkisi vardır. Tüm sunucuların yeniden başlatılması gerekir.');
    W.msg('info', 'Global security değişiklikleri tüm süreçlerin (dmgr, node agent\'lar, sunucular) yeniden başlatılmasını gerektirir.');
  };
  A.secReport = function () {
    var s = SEC();
    W.modal({ title: 'Security Configuration Report', wide: true, html: W.simpleTable(['Console Path', 'Name', 'Value'], [
      ['Global security', 'Administrative security', s.adminSecurity], ['Global security', 'Application security', s.appSecurity], ['Global security', 'Java 2 security', s.java2],
      ['Global security', 'Active user registry', s.registry + ' (' + esc(s.realm) + ')'], ['LTPA', 'LTPA timeout', s.ltpa.timeout + ' minutes'], ['Web security > SSO', 'Requires SSL', s.sso.requiresSSL], ['Web security > SSO', 'Domain name', esc(s.sso.domain)],
      ['CSIv2 inbound', 'Transport', s.csiv2In.transport], ['SSL configurations', 'CellDefaultSSLSettings protocol', 'TLSv1.2'], ['Session management', 'Security integration (BankSrv01)', W.srv('BankSrv01') ? W.srv('BankSrv01').session.enableSecurityIntegration : '-'], ['Session management', 'Cookies HTTPOnly (BankSrv01)', W.srv('BankSrv01') ? W.srv('BankSrv01').session.cookieHttpOnly : '-']
    ].map(function (r) { return r.map(function (c) { return esc(c); }); })) + '<p class="note-tr">Gerçek ortamda bu rapor <code>AdminTask.generateSecConfigReport()</code> ile de alınabilir.</p>' });
  };
  A.realmConfigure = function () { var v = document.getElementById('realmSel').value; location.hash = v === 'federated' ? '#/sec/global/federated' : v === 'ldap' ? '#/sec/global/ldap' : v === 'localos' ? '#/sec/global/localos' : '#/sec/global/custom'; };
  A.realmSetCurrent = function () {
    var v = document.getElementById('realmSel').value, s = SEC();
    if (v === s.registry) { W.msg('info', 'Seçili realm zaten etkin.'); W.rerender(); return; }
    s.registry = v; W.change(SECDOC(), 'Aktif user registry: ' + v);
    W.cmd('Aktif user registry değiştir', ["AdminTask.setGlobalSecurity('[-activeUserRegistry " + ({ federated: 'WIMUserRegistry', ldap: 'LDAPUserRegistry', localos: 'LocalOSUserRegistry', custom: 'CustomUserRegistry' })[v] + "]')", 'AdminConfig.save()']);
    W.msg('warning', 'Aktif user registry değiştirildi. Yeni registry\'de <b>primary administrative user</b> mevcut olmalıdır; aksi halde kaydedip yeniden başlattıktan sonra konsola giriş yapılamaz!'); W.rerender();
  };

  /* Federated repositories */
  R('/sec/global/federated', function () {
    var s = SEC();
    return secPage('Global security', [GS, 'Federated repositories'], '<p class="desc">By federating repositories, identities stored in multiple repositories can be managed in a single, virtual realm. The realm can consist of identities in the file-based repository that is built into the system, in one or more external repositories, or in both.' + W.hi('sec.federated') + '</p>' +
      W.cfgForm({ ref: 'security', doc: 'cells/' + CELL() + '/wim/config/wimconfig.xml', back: '#/sec/global', title: 'Federated repositories', general:
        F.text({ l: 'Realm name', n: 'realm', v: s.realm, req: true, h: 'sec.federated' }) + F.text({ l: 'Primary administrative user name', n: 'primaryAdmin', v: s.primaryAdmin, req: true, h: 'sec.primaryAdmin' }) +
        F.radio({ l: 'Server user identity', n: 'serverId', v: s.serverId, o: [['Automatically generated server identity', 'Automatically generated server identity'], ['Server identity that is stored in the repository', 'Server identity that is stored in the repository']], h: 'sec.serverId' }) +
        F.ck({ l: 'Ignore case for authorization', n: 'ignoreCase', v: s.ignoreCase, h: 'sec.federated' }) + F.ck({ l: 'Allow operations if some of the repositories are down', n: 'allowOpsIfReposDown', v: s.allowOpsIfReposDown, h: 'sec.reposDown' }) +
        '<div class="sect-title" style="margin-top:12px">Repositories in the realm:' + W.hi('sec.federated') + '</div>' +
        W.table({ id: 'repos', select: false, rows: s.repositories, cols: [{ k: 'base', l: 'Base Entry', h: 'sec.baseEntry' }, { k: 'id', l: 'Repository Identifier', fmt: function (r) { return '<a href="#/sec/global/federated/' + W.enc(r.id) + '">' + esc(r.id) + '</a>'; } }, { k: 'type', l: 'Repository Type' }] }) +
        '<div class="btnrow" style="border:0"><button type="button" class="btn" data-act="nav" data-href="#/sec/global/federated/new">Add repositories (LDAP, custom, etc)...</button><button type="button" class="btn" data-act="notInSim" data-arg="Use built-in repository">Use built-in repository</button></div>',
        ap: [{ t: 'Additional Properties', items: [{ l: 'Property extension repository', act: 'notInSim', arg: 'Property extension repository' }, { l: 'Entry mapping repository', act: 'notInSim', arg: 'Entry mapping repository' }, { l: 'Supported entity types', act: 'notInSim', arg: 'Supported entity types', h: 'sec.federated' }] }, { t: 'Related Items', items: [{ l: 'Manage repositories', href: '#/sec/global/federated', h: 'sec.federated' }, { l: 'Trusted authentication realms - inbound', act: 'notInSim', arg: 'Trusted realms' }] }] }), 'sec.federated');
  });
  function ldapForm(r, isNew) {
    return F.text({ l: 'Repository identifier', n: 'id', v: r.id, req: true, ro: !isNew, h: 'sec.ldap' }) +
      F.sel({ l: 'Directory type', n: 'dirType', v: r.dirType, o: ['Microsoft Windows Server Active Directory', 'IBM Security Directory Server', 'IBM Tivoli Directory Server', 'Oracle Directory Server', 'Novell eDirectory', 'Custom'], h: 'sec.ldap' }) +
      F.text({ l: 'Primary host name', n: 'host', v: r.host, req: true, h: 'sec.ldapHost' }) + F.num({ l: 'Port', n: 'port', v: r.port, h: 'sec.ldapHost' }) +
      F.text({ l: 'Failover host (host:port)', n: 'failover', v: r.failover, h: 'sec.ldapHost' }) +
      F.sel({ l: 'Support referrals to other LDAP servers', n: 'supportReferrals', v: r.supportReferrals || 'ignore', o: ['ignore', 'follow'], h: 'sec.ldap' }) +
      F.grp('Security', 'sec.ldapBind', F.text({ l: 'Bind distinguished name', n: 'bindDN', v: r.bindDN, h: 'sec.ldapBind' }) + F.pw({ l: 'Bind password', v: isNew ? '' : '********', h: 'sec.ldapBind' }) +
        F.text({ l: 'Login properties', n: 'loginProperties', v: r.loginProperties, h: 'sec.loginProps' }) + F.sel({ l: 'Certificate mapping', n: 'certMapping', v: r.certMapping || 'EXACT_DN', o: ['EXACT_DN', 'CERTIFICATE_FILTER'], h: 'sec.ldap' }) +
        F.ck({ l: 'Require SSL communications', n: 'ssl', v: r.ssl, h: 'sec.ldapSsl' }) + F.sel({ l: 'Use specific SSL alias', n: 'sslAlias', v: r.sslAlias, o: SEC().sslConfigs.map(function (c) { return c.name; }).filter(function (v, i, a) { return a.indexOf(v) === i; }), h: 'concept.ssl' })) +
      F.grp('Timeouts', 'sec.ldap', F.num({ l: 'Search timeout', n: 'searchTimeout', v: r.searchTimeout || 120, unit: 'seconds' }) + F.num({ l: 'Connection timeout', n: 'connectTimeout', v: r.connectTimeout || 20, unit: 'seconds' })) +
      F.text({ l: 'Unique distinguished name of the base (or parent) entry in federated repositories', n: 'base', v: r.base, req: true, h: 'sec.baseEntry' });
  }
  R('/sec/global/federated/new', function () {
    var r = { id: '', type: 'LDAP:AD', dirType: 'Microsoft Windows Server Active Directory', host: '', port: 636, failover: '', bindDN: '', loginProperties: 'uid', ssl: true, sslAlias: 'CellDefaultSSLSettings', base: '' };
    return secPage('Global security', [GS, ['Federated repositories', '#/sec/global/federated'], 'New repository (LDAP)'], '<p class="desc">LDAP sunucusunu federated realm\'e repository olarak ekler. Bağlantı ve bind bilgileri doğru değilse kaydettikten sonra hiçbir LDAP kullanıcısı giriş yapamaz.' + W.hi('sec.ldap') + '</p>' +
      W.cfgForm({ create: 'ldapRepo', back: '#/sec/global/federated', title: 'LDAP repository', general: ldapForm(r, true), extraButtons: '<button type="button" class="btn" data-act="ldapTest">Test connection</button>' }), 'sec.ldap');
  });
  W.creators.ldapRepo = function (v) {
    var s = SEC();
    if (W.by(s.repositories, 'id', v.id)) return { error: 'Bu repository identifier zaten kullanılıyor.' };
    s.repositories.push(Object.assign({ type: 'LDAP:' + (/Active Directory/.test(v.dirType) ? 'AD' : 'IDS'), description: '' }, v));
    W.change('cells/' + CELL() + '/wim/config/wimconfig.xml', 'LDAP repository eklendi: ' + v.id);
    W.cmd('LDAP repository yapılandır: ' + v.id, ["AdminTask.createIdMgrLDAPRepository('[-default true -id " + v.id + " -adapterClassName com.ibm.ws.wim.adapter.ldap.LdapAdapter -ldapServerType " + (/Active Directory/.test(v.dirType) ? 'AD' : 'IDS') + " -sslConfiguration " + v.sslAlias + " -certificateMapMode " + v.certMapping + " -supportChangeLog none -loginProperties " + v.loginProperties + "]')",
      "AdminTask.addIdMgrLDAPServer('[-id " + v.id + " -host " + v.host + " -port " + v.port + " -bindDN " + v.bindDN + " -bindPassword ******** -sslEnabled " + v.ssl + " -referal " + v.supportReferrals + "]')",
      "AdminTask.addIdMgrRepositoryBaseEntry('[-id " + v.id + " -name " + v.base + " -nameInRepository " + v.base + "]')", "AdminTask.addIdMgrRealmBaseEntry('[-name " + s.realm + " -baseEntry " + v.base + "]')", 'AdminConfig.save()']);
    return { msgs: ['LDAP repository <b>' + esc(v.id) + '</b> (' + esc(v.host) + ':' + v.port + ') federated realm\'e eklendi. Değişiklik için tüm süreçlerin yeniden başlatılması gerekir.'], go: '#/sec/global/federated' };
  };
  A.ldapTest = function (el) {
    var v = W.readForm(el.closest('form')).vals;
    if (!v.host) { W.msg('error', 'Primary host name girin.'); W.rerender(); return; }
    var known = /corp\.local$/.test(v.host);
    var trusted = SEC().certs.signer.some(function (c) { return c.alias === v.host || /Corp Root CA/.test(c.issuedTo); });
    W.modal({ title: 'Test connection', html: known ? (v.ssl && !trusted ? '<div class="msgbox err">CWPKI0022E: SSL HANDSHAKE FAILURE: A signer with SubjectDN CN=' + esc(v.host) + ' was sent from the target host. The signer might need to be added to local trust store CellDefaultTrustStore.</div><p>Çözüm: <a href="#/sec/ssl/keystores/CellDefaultTrustStore/signer">Signer certificates</a> sayfasında <b>Retrieve from port</b> ile LDAP sunucusunun sertifikasını trust store\'a ekleyin.</p>' : '<div class="msgbox info">The test connection operation to the LDAP server ' + esc(v.host) + ':' + v.port + ' was successful. (Bind DN ile kimlik doğrulama başarılı.)</div>') : '<div class="msgbox err">CWWIM4520E The \'javax.naming.CommunicationException: ' + esc(v.host) + ':' + v.port + ' [Root exception is java.net.UnknownHostException: ' + esc(v.host) + ']\' naming exception occurred during processing.</div><p>DNS çözümlemesini, güvenlik duvarını (port ' + v.port + ') ve host adını kontrol edin.</p>' });
  };
  R('/sec/global/federated/:id', function (p) {
    var r = W.by(SEC().repositories, 'id', p.id);
    if (r.type === 'File') {
      return secPage('Global security', [GS, ['Federated repositories', '#/sec/global/federated'], r.id], '<p class="desc">Dahili dosya tabanlı repository (<code>config/cells/' + esc(CELL()) + '/fileRegistry.xml</code>). Genellikle LDAP erişilemediğinde konsola girebilmek için acil durum yönetici hesabını barındırır.' + W.hi('sec.federated') + '</p>' + W.kvTable([['Repository identifier', esc(r.id)], ['Base entry', esc(r.base)], ['Type', 'File'], ['Users', 'wasadmin']]), 'sec.federated');
    }
    return secPage('Global security', [GS, ['Federated repositories', '#/sec/global/federated'], r.id], '<p class="desc">LDAP repository configuration.' + W.hi('sec.ldap') + '</p>' +
      W.cfgForm({ ref: 'security.repositories|' + r.id, doc: 'cells/' + CELL() + '/wim/config/wimconfig.xml', back: '#/sec/global/federated', title: 'LDAP repository ' + r.id, general: ldapForm(r, false), extraButtons: '<button type="button" class="btn" data-act="ldapTest">Test connection</button>',
        ap: [{ t: 'Additional Properties', items: [{ l: 'Performance (cache)', act: 'notInSim', arg: 'LDAP performance', h: 'sec.ldap' }, { l: 'LDAP entity types', act: 'notInSim', arg: 'LDAP entity types', h: 'sec.ldap' }, { l: 'Group attribute definition', act: 'notInSim', arg: 'Group attribute definition', h: 'sec.ldap' }, { l: 'Federated repositories property names to LDAP attributes mapping', act: 'notInSim', arg: 'Attribute mapping', h: 'sec.loginProps' }] }] }), 'sec.ldap');
  });
  R('/sec/global/ldap', function () {
    return secPage('Global security', [GS, 'Standalone LDAP registry'], '<div class="note-tr">Bu hücrede aktif registry <b>Federated repositories</b>\'dir ve LDAP, federated realm içinde bir repository olarak tanımlıdır (önerilen yöntem). Standalone LDAP registry tek bir LDAP sunucusu (ve failover) ile çalışır; birden çok repository birleştirilemez ve dosya tabanlı acil durum hesabı kullanılamaz.' + W.hi('sec.standaloneLdap') + '</div>' +
      W.kvTable([['Primary administrative user name', 'wasadmin'], ['Type of LDAP server', 'Microsoft Windows Active Directory'], ['Host / Port', 'ldap01.corp.local : 636'], ['Base distinguished name (DN)', 'dc=corp,dc=local'], ['Bind distinguished name (DN)', 'CN=svc_was,OU=Service Accounts,DC=corp,DC=local'], ['Search timeout', '120 seconds'], ['SSL enabled', 'true'], ['Durum', 'Tanımlı, ancak aktif (current) değil']]), 'sec.standaloneLdap');
  });
  R('/sec/global/localos', function () {
    return secPage('Global security', [GS, 'Local operating system'], '<div class="note-tr">Local OS registry, kimlik doğrulamayı sunucunun işletim sistemi kullanıcıları ile yapar. Network Deployment ortamında tüm node\'ların aynı kullanıcı veritabanını görmesi gerektiği için (ör. domain controller) dağıtık hücrelerde pek önerilmez. Linux\'ta sunucu sürecinin root ile çalışmasını gerektirebilir.' + W.hi('sec.localos') + '</div>' + W.kvTable([['Primary administrative user name', '(tanımsız)'], ['Durum', 'Aktif değil']]), 'sec.localos');
  });
  R('/sec/global/custom', function () { return secPage('Global security', [GS, 'Standalone custom registry'], '<div class="note-tr">Custom registry, <code>com.ibm.websphere.security.UserRegistry</code> arayüzünü uygulayan özel bir sınıfla kimlik doğrulama sağlar (ör. eski bir veritabanı tablosu). Yeni kurulumlarda bunun yerine federated repositories içinde custom repository adapter tercih edilir.' + W.hi('concept.userRegistry') + '</div>', 'concept.userRegistry'); });

  /* LTPA, SSO, auth cache, CSIv2, SAS */
  R('/sec/ltpa', function () {
    var l = SEC().ltpa;
    return secPage('Global security', [GS, 'LTPA'], '<p class="desc">LTPA (Lightweight Third-Party Authentication), kimliği doğrulanmış kullanıcı için imzalı ve şifreli bir token üretir; tarayıcıda <code>LtpaToken2</code> çerezi olarak taşınır ve aynı anahtarları paylaşan tüm sunucularda tekrar parola sorulmadan kabul edilir.' + W.hi('sec.ltpa') + '</p>' +
      W.cfgForm({ ref: 'security.ltpa', doc: SECDOC(), back: '#/sec/global', title: 'LTPA', general:
        F.grp('Key set groups', 'sec.ltpaKeys', F.ro({ l: 'Key set group', v: l.keyGroup, h: 'sec.ltpaKeys' }) + F.ck({ l: 'Automatically generate keys', n: 'autoGenerate', v: l.autoGenerate, h: 'sec.ltpaKeys' }) + F.ro({ l: 'Key generation schedule', v: l.regenSchedule }) + F.ro({ l: 'Last generated', v: l.lastGenerated }) + '<button type="button" class="btn" data-act="ltpaGen">Generate keys</button>') +
        F.grp('Cross-cell single sign-on', 'sec.ltpaKeys', F.pw({ l: 'Password', v: '********' }) + F.pw({ l: 'Confirm password', v: '********' }) + F.text({ l: 'Fully qualified key file name', n: 'keyFile', v: l.keyFile || '/tmp/ltpa_export.keys', h: 'sec.ltpaKeys' }) + '<button type="button" class="btn" data-act="notInSim" data-arg="Import keys">Import keys</button> <button type="button" class="btn" data-act="notInSim" data-arg="Export keys">Export keys</button>') +
        F.grp('LTPA timeout', 'sec.ltpaTimeout', F.num({ l: 'LTPA timeout value for forwarded credentials between servers', n: 'timeout', v: l.timeout, unit: 'minutes', h: 'sec.ltpaTimeout', min: 5 })) }), 'sec.ltpa');
  });
  A.ltpaGen = function () { var l = SEC().ltpa; l.lastGenerated = new Date().toLocaleString('sv-SE').slice(0, 16); W.change(SECDOC(), 'LTPA anahtarları yeniden üretildi'); W.cmd('LTPA anahtarlarını üret', ["AdminControl.invoke(AdminControl.queryNames('type=SecurityAdmin,process=dmgr,*'), 'generateKeys', '********')", 'AdminConfig.save()']); W.msg('warning', ['LTPA anahtarları yeniden üretildi. Kaydedip senkronize ettiğinizde tüm sunucular yeni anahtarları kullanır; mevcut LtpaToken2 çerezleri geçersiz olur ve kullanıcıların yeniden giriş yapması gerekir.', 'Hücre dışı sistemlerle (ör. başka bir WAS hücresi veya IHS/WebSEAL) SSO varsa anahtarları dışa aktarıp onlara da aktarmanız gerekir.']); W.rerender(); };
  R('/sec/sso', function () {
    var s = SEC().sso;
    return secPage('Global security', [GS, 'Single sign-on (SSO)'], '<p class="desc">Specifies the configuration values for single sign-on.' + W.hi('sec.sso') + '</p>' + W.cfgForm({ ref: 'security.sso', doc: SECDOC(), back: '#/sec/global', title: 'Single sign-on', general:
      F.ck({ l: 'Enabled', n: 'enabled', v: s.enabled, h: 'sec.sso' }) + F.ck({ l: 'Requires SSL', n: 'requiresSSL', v: s.requiresSSL, h: 'sec.sso' }) + F.text({ l: 'Domain name', n: 'domain', v: s.domain, h: 'sec.ssoDomain' }) +
      F.ck({ l: 'Interoperability Mode (LtpaToken + LtpaToken2)', n: 'interop', v: s.interop, h: 'sec.sso' }) + F.ck({ l: 'Web inbound security attribute propagation', n: 'webInbound', v: s.webInbound, h: 'sec.sso' }) }), 'sec.sso');
  });
  R('/sec/authcache', function () {
    var l = SEC().ltpa;
    return secPage('Global security', [GS, 'Authentication cache settings'], W.cfgForm({ ref: 'security.ltpa', doc: SECDOC(), back: '#/sec/global', title: 'Authentication cache', general:
      F.ck({ l: 'Enable the authentication cache', n: 'cacheEnabled', v: l.cacheEnabled !== false, h: 'sec.authCache' }) + F.num({ l: 'Cache timeout', n: 'cacheTimeout', v: l.cacheTimeout, unit: 'minutes', h: 'sec.authCache' }) + F.num({ l: 'Initial cache size', n: 'cacheInitSize', v: l.cacheInitSize, h: 'sec.authCache' }) + F.num({ l: 'Maximum cache size', n: 'cacheMaxSize', v: l.cacheMaxSize, h: 'sec.authCache' }) }), 'sec.authCache');
  });
  R('/sec/csiv2', function (p, q) {
    var dir = q.dir === 'out' ? 'out' : 'in', c = SEC()[dir === 'in' ? 'csiv2In' : 'csiv2Out'], lvl = [['NEVER', 'Never'], ['SUPPORTED', 'Supported'], ['REQUIRED', 'Required']];
    return secPage('Global security', [GS, 'CSIv2 ' + (dir === 'in' ? 'inbound' : 'outbound') + ' communications'], '<p class="desc">CSIv2 (Common Secure Interoperability v2), RMI/IIOP (EJB çağrıları) üzerinde kimlik bilgisi ve taşıma güvenliğini tanımlayan OMG standardıdır. ' + (dir === 'in' ? 'Inbound: bu sunucunun gelen IIOP isteklerinden ne talep ettiği.' : 'Outbound: bu sunucunun başka sunuculara yaptığı IIOP çağrılarında ne gönderdiği.') + W.hi('sec.csiv2') + '</p>' +
      W.cfgForm({ ref: 'security.' + (dir === 'in' ? 'csiv2In' : 'csiv2Out'), doc: SECDOC(), back: '#/sec/global', title: 'CSIv2 ' + dir, general:
        F.grp('CSIv2 Attribute Layer', 'sec.csiv2', F.ck({ l: 'Propagate security attributes / Use identity assertion', n: 'identityAssertion', v: c.identityAssertion, h: 'sec.csiv2' }) + F.text({ l: 'Trusted identities', n: 'trustedIds', v: c.trustedIds || '', h: 'sec.csiv2' })) +
        F.grp('CSIv2 Message Layer', 'sec.csiv2', F.sel({ l: 'Basic authentication', n: 'basicAuth', v: c.basicAuth, o: lvl, h: 'sec.csiv2' }) + F.sel({ l: 'Client certificate authentication', n: 'clientCert', v: c.clientCert, o: lvl, h: 'sec.csiv2' })) +
        F.grp('CSIv2 Transport Layer', 'sec.csiv2', F.radio({ l: 'Transport', n: 'transport', v: c.transport, o: [['TCPIP', 'TCP/IP'], ['SSL-REQUIRED', 'SSL-required'], ['SSL-SUPPORTED', 'SSL-supported']], h: 'sec.csiv2' })) +
        F.ck({ l: 'Stateful sessions', n: 'stateful', v: c.stateful, h: 'sec.csiv2' }) }), 'sec.csiv2');
  });
  R('/sec/sas', function () {
    return secPage('Global security', [GS, 'SAS (legacy)'], '<div class="note-tr"><b>Secure Authentication Service (SAS)</b>, WAS V5.x ve öncesinde RMI/IIOP güvenliği için kullanılan IBM\'e özgü protokoldür. WAS V6.1\'den itibaren kullanımdan kaldırılmıştır (deprecated); yalnızca eski sürümlü süreçlerle birlikte çalışabilirlik için bulunur. WAS 9.0 hücrelerinde tüm IIOP güvenliği <a href="#/sec/csiv2?dir=in">CSIv2</a> ile yapılandırılmalıdır. Bu hücrede SAS kullanılmamaktadır.' + W.hi('sec.sas') + '</div>' +
      W.kvTable([['SAS_SSL_SERVERAUTH_LISTENER_ADDRESS', 'Port tanımı mevcut (ör. 9501) – kullanılmıyor', 'sec.sas'], ['Önerilen eylem', 'Tüm istemcileri CSIv2\'ye taşıyın']]), 'sec.sas');
  });

  /* JAAS */
  R('/sec/jaas/app', function () { return secPage('Global security', [GS, 'JAAS - Application logins'], '<p class="desc">Application login configurations, uygulamaların <code>LoginContext</code> ile kullanabileceği JAAS login modül zincirleridir.' + W.hi('concept.jaas') + '</p>' + W.table({ id: 'jaasA', rows: SEC().jaasApp.map(function (n) { return { name: n }; }), key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Alias' }, { k: 'm', l: 'Module class names', fmt: function (r) { return r.name === 'PaymentCustomLogin' ? 'com.ornekbank.security.OtpLoginModule; com.ibm.ws.security.common.auth.module.WSLoginModuleImpl' : 'com.ibm.ws.security.common.auth.module.WSLoginModuleImpl'; } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New JAAS login' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }] }), 'concept.jaas'); });
  R('/sec/jaas/sys', function () { return secPage('Global security', [GS, 'JAAS - System logins'], '<p class="desc">System login configurations, WAS\'ın kendi bileşenlerinin (web, RMI, LTPA) kimlik doğrulamasında kullandığı login zincirleridir. Örn. <code>WEB_INBOUND</code> zincirine özel modül ekleyerek web girişlerine ek kontrol eklenebilir.' + W.hi('concept.jaas') + '</p>' + W.table({ id: 'jaasS', rows: SEC().jaasSys.map(function (n) { return { name: n }; }), key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Alias' }, { k: 'm', l: 'Module class names', fmt: function (r) { return /INBOUND/.test(r.name) ? 'com.ibm.ws.security.server.lm.ltpaLoginModule; com.ibm.ws.security.server.lm.wsMapDefaultInboundLoginModule' : 'com.ibm.ws.security.server.lm.ltpaLoginModule'; } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New system login' }] }), 'concept.jaas'); });
  W.resType({ id: 'j2cauth', coll: 'authAliases', path: '/sec/jaas/j2c', title: 'J2C authentication data', singular: 'J2C authentication alias', help: 'sec.authAlias', scoped: false, cfgType: 'JAASAuthData', file: 'security.xml',
    desc: 'Specifies a list of user identities and passwords for Java(TM) 2 connector security to use. Data source, JMS ve J2C bağlantıları veritabanı/EIS\'e bu alias\'lardaki kullanıcı ile bağlanır. Parolalar security.xml içinde XOR ile kodlanmış (şifrelenmemiş!) olarak saklanır; dosya erişimi korunmalıdır.',
    cols: [{ k: 'id', l: 'Alias' }, { k: 'user', l: 'User ID' }, { k: 'description', l: 'Description' }],
    defaults: function () { return { id: '', user: '', description: '' }; },
    form: function (o, isNew) { return (isNew ? F.text({ l: 'Alias', n: 'id', v: o.id, req: true, h: 'sec.authAlias', note: 'Konsol, alias adının başına otomatik olarak DMGR node adını ekler (ör. CellManager01/aliasAdı).' }) : F.ro({ l: 'Alias', v: o.id, h: 'sec.authAlias' })) + F.text({ l: 'User ID', n: 'user', v: o.user, req: true, h: 'sec.authAlias' }) + F.pw({ l: 'Password', v: isNew ? '' : '********', h: 'sec.authAlias' }) + F.text({ l: 'Description', n: 'description', v: o.description }); },
    beforeCreate: function (o) { if (o.id.indexOf('/') < 0) { o.id = 'CellManager01/' + o.id; } o.name = o.id; },
    canDelete: function (o) { var u = W.S.dataSources.filter(function (d) { return d.authAlias === o.id; }); if (u.length) return esc(o.id) + ' silinemedi: ' + u.map(function (d) { return esc(d.name); }).join(', ') + ' tarafından kullanılıyor.'; },
    createCmd: function (o) { return ["AdminTask.createAuthDataEntry('[-alias " + o.id.split('/').pop() + " -user " + o.user + " -password ******** -description \"" + o.description + "\"]')", 'AdminConfig.save()']; } });

  /* Security domains & auth groups */
  R('/sec/domains', function () {
    return secPage('Security domains', null, '<div class="page-title">Security domains' + W.hi('sec.domains') + '</div><p class="desc">Use security domains to define different security configurations for applications that run on different servers and clusters. Tanımlanmayan her ayar global security\'den miras alınır.</p>' +
      W.table({ id: 'secdom', rows: SEC().domains, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/sec/domains/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'description', l: 'Description' }, { k: 'scopes', l: 'Assigned scopes', fmt: function (r) { return r.scopes.map(function (s) { return esc(W.scopeLabel(s)); }).join(', '); } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New security domain' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }, { l: 'Copy...', act: 'notInSim', arg: 'Copy' }] }), 'sec.domains');
  });
  R('/sec/domains/:name', function (p) {
    var d = W.by(SEC().domains, 'name', p.name);
    return secPage('Security domains', [['Security domains', '#/sec/domains'], d.name], W.cfgForm({ ref: 'security.domains|' + d.name, doc: 'cells/' + CELL() + '/security-domains/' + d.name + '/security-domain.xml', back: '#/sec/domains', title: 'Security domain ' + d.name, general:
      F.ro({ l: 'Name', v: d.name }) + F.text({ l: 'Description', n: 'description', v: d.description }) + F.ro({ l: 'Assigned scopes', v: d.scopes.map(W.scopeFull).join('; '), h: 'sec.domains' }) +
      F.grp('Security attributes', 'sec.domains', F.ck({ l: 'Application security (customize for this domain)', n: 'appSecurity', v: d.appSecurity, h: 'sec.appSecurity' }) + F.ck({ l: 'Java 2 security', n: 'java2', v: d.java2, h: 'sec.java2' }) + F.ro({ l: 'User realm', v: d.registry, h: 'concept.userRegistry' }) + F.ro({ l: 'JAAS application logins', v: 'PaymentCustomLogin (domain-specific)' }) + F.ro({ l: 'Authentication mechanism attributes', v: 'Use global security settings' })) }), 'sec.domains');
  });
  R('/sec/authgroups', function () {
    return secPage('Administrative Authorization Groups', null, '<div class="page-title">Administrative Authorization Groups' + W.hi('sec.authGroups') + '</div><p class="desc">Use administrative authorization groups to assign administrative roles to users and groups for a subset of resources in the cell (fine-grained administrative security).</p>' +
      W.table({ id: 'aag', rows: [{ name: 'PaymentAdminGroup', res: 'Cluster=BankingCluster; Application=PaymentGatewayApp', roles: 'PaymentOps → Operator, Deployer' }, { name: 'PortalAdminGroup', res: 'Cluster=PortalCluster; Application=CustomerPortalApp', roles: 'WebTeam → Configurator, Operator' }], key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'res', l: 'Resources' }, { k: 'roles', l: 'User/group → roles' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New authorization group' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }] }), 'sec.authGroups');
  });
  R('/sec/audit', function () {
    W.S.audit = W.S.audit || { enabled: false, verbose: false, encryption: false, signing: false };
    return secPage('Security auditing', null, '<div class="page-title">Security auditing' + W.hi('sec.audit') + '</div><p class="desc">Security auditing, yönetsel ve güvenlik olaylarını (giriş, yetki reddi, konfigürasyon değişikliği) değiştirilemez denetim kayıtlarına yazar. Yalnızca <b>Auditor</b> rolüne sahip kullanıcılar yapılandırabilir.</p>' +
      W.cfgForm({ ref: 'audit', doc: 'cells/' + CELL() + '/audit.xml', back: '#/sec/global', title: 'Security auditing', general: F.ck({ l: 'Enable security auditing', n: 'enabled', v: W.S.audit.enabled, h: 'sec.audit' }) + F.ck({ l: 'Enable verbose auditing', n: 'verbose', v: W.S.audit.verbose, h: 'sec.audit' }) + F.ck({ l: 'Enable encryption of audit records', n: 'encryption', v: W.S.audit.encryption }) + F.ck({ l: 'Enable signing of audit records', n: 'signing', v: W.S.audit.signing }) }), 'sec.audit');
  });
  R('/sec/bus', function () {
    return secPage('Bus security', null, '<div class="page-title">Bus security' + W.hi('sib.security') + '</div><p class="desc">Service integration bus güvenliği; bus\'a bağlanan istemcilerin kimlik doğrulamasını, destination erişim yetkilerini (sender/receiver/browser rolleri) ve messaging engine\'ler arası iletişimi korur.</p>' +
      W.table({ id: 'bsec', select: false, rows: W.S.sib.buses, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Bus' }, { k: 'secure', l: 'Security', fmt: function (r) { return r.secure ? 'Enabled' : 'Disabled'; } }, { k: 'interEngineAuthAlias', l: 'Inter-engine authentication alias' }, { k: 'p', l: 'Permitted transports', fmt: function () { return 'Restrict the use of defined transport channel chains to those protected by SSL'; } }] }), 'sib.security');
  });

  /* SSL */
  R('/sec/ssl', function () {
    return secPage('SSL certificate and key management', null, '<div class="page-title">SSL certificate and key management' + W.hi('concept.ssl') + '</div><p class="desc">Use this page to manage SSL configurations, key stores, certificates and certificate expiration. SSL yapılandırmaları Cell → Node → Cluster → Server → Endpoint hiyerarşisinde atanır; en özel olan geçerlidir.</p>' +
      '<div class="detail"><div class="gp"><div class="sect-title">Configuration settings</div><div class="ap-link"><a href="#/sec/ssl/endpoints">Manage endpoint security configurations</a>' + W.hi('ssl.endpoints') + '</div><div class="ap-link"><a href="#/sec/ssl/expiration">Manage certificate expiration</a>' + W.hi('ssl.expiration') + '</div><div class="ap-link"><a data-act="notInSim" data-arg="Manage FIPS">Manage FIPS</a>' + W.hi('ssl.fips') + '</div>' +
      '<div class="ck-line" style="margin-top:8px"><input type="checkbox" checked disabled><label>Dynamically update the run time when SSL configuration changes occur</label>' + W.hi('concept.ssl') + '</div></div>' +
      '<div class="ap">' + W.apGroups([{ t: 'Related Items', items: [{ l: 'SSL configurations', href: '#/sec/ssl/configs', h: 'ssl.config' }, { l: 'Key stores and certificates', href: '#/sec/ssl/keystores', h: 'ssl.keystore' }, { l: 'Key managers', act: 'notInSim', arg: 'Key managers', h: 'ssl.config' }, { l: 'Trust managers', act: 'notInSim', arg: 'Trust managers', h: 'ssl.truststore' }, { l: 'Certificate authority (CA) clients', act: 'notInSim', arg: 'CA clients' }, { l: 'Key sets', act: 'notInSim', arg: 'Key sets', h: 'sec.ltpaKeys' }, { l: 'Key set groups', act: 'notInSim', arg: 'Key set groups', h: 'sec.ltpaKeys' }] }]) + '</div></div>', 'concept.ssl');
  });
  R('/sec/ssl/configs', function () {
    var rows = SEC().sslConfigs.map(function (c, i) { return Object.assign({ id: String(i) }, c); });
    return secPage('SSL configurations', [['SSL certificate and key management', '#/sec/ssl'], 'SSL configurations'], '<p class="desc">Defines a list of Secure Sockets Layer (SSL) configurations.' + W.hi('ssl.config') + '</p>' +
      W.table({ id: 'sslc', rows: rows, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/sec/ssl/configs/' + r.id + '">' + esc(r.name) + '</a>'; } }, { k: 'scope', l: 'Management Scope', fmt: function (r) { return esc(W.scopeFull(r.scope)); } }, { k: 'protocol', l: 'Protocol' }, { k: 'keyStore', l: 'Key store' }, { k: 'trustStore', l: 'Trust store' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New SSL configuration' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }] }), 'ssl.config');
  });
  R('/sec/ssl/configs/:i', function (p) {
    var c = SEC().sslConfigs[+p.i];
    var ks = SEC().keystores.map(function (k) { return k.name; });
    return secPage('SSL configurations', [['SSL certificate and key management', '#/sec/ssl'], ['SSL configurations', '#/sec/ssl/configs'], c.name], '<p class="desc">Management scope: <b>' + esc(W.scopeFull(c.scope)) + '</b></p>' + W.cfgForm({ ref: 'security.sslConfigs|' + p.i, doc: SECDOC(), back: '#/sec/ssl/configs', title: 'SSL configuration ' + c.name, validate: 'ssl', cfgid: '', general:
      F.ro({ l: 'Name', v: c.name, h: 'ssl.config' }) + F.sel({ l: 'Trust store name', n: 'trustStore', v: c.trustStore, o: ks, h: 'ssl.truststore' }) + F.sel({ l: 'Keystore name', n: 'keyStore', v: c.keyStore, o: ks, h: 'ssl.keystore' }) +
      F.text({ l: 'Default server certificate alias', n: 'serverAlias', v: c.serverAlias, h: 'ssl.alias' }) + F.text({ l: 'Default client certificate alias', n: 'clientAlias', v: c.clientAlias, h: 'ssl.alias' }) +
      F.grp('Quality of protection (QoP) settings', 'ssl.qop', F.sel({ l: 'Client authentication', n: 'clientAuth', v: c.clientAuth, o: ['None', 'Supported', 'Required'], h: 'ssl.clientAuth' }) + F.sel({ l: 'Protocol', n: 'protocol', v: c.protocol, o: ['TLSv1.2', 'TLSv1.3', 'TLS', 'SSL_TLSv2', 'TLSv1.1', 'TLSv1'], h: 'ssl.protocol' }) +
        F.sel({ l: 'Provider', n: 'provider', v: c.provider, o: ['IBMJSSE2'], h: 'ssl.qop' }) + F.sel({ l: 'Cipher suite groups', n: 'securityLevel', v: c.securityLevel, o: [['HIGH', 'Strong'], ['MEDIUM', 'Medium'], ['LOW', 'Weak'], ['CUSTOM', 'Custom']], h: 'ssl.ciphers' })),
      ap: [{ t: 'Additional Properties', items: [{ l: 'Trust and key managers', act: 'notInSim', arg: 'Trust and key managers', h: 'ssl.truststore' }, { l: 'Custom properties', href: W.propsLink('security.sslConfigs|' + p.i, 'customProps', 'SSL configuration', '#/sec/ssl/configs/' + p.i), h: 'concept.customProps' }] }] }), 'ssl.config');
  });
  W.validators.ssl = function (v, form) {
    if (/^(TLSv1|TLSv1\.1|SSL_TLSv2|TLS)$/.test(v.protocol)) W.msg('warning', 'Uyarı: ' + v.protocol + ' seçildi. TLS 1.0/1.1 ve SSLv3 güvensiz kabul edilir; yalnızca eski istemcilerle uyumluluk için ve geçici olarak kullanın. Karşı tarafın (IHS plug-in, LDAP, veritabanı) da aynı protokolü desteklediğini doğrulayın, aksi halde CWPKI0022E SSL HANDSHAKE FAILURE oluşur.');
    if (v.securityLevel === 'LOW') W.msg('warning', 'Uyarı: Weak cipher grubu, kırılabilir şifreleme algoritmalarına izin verir.');
    W.cmd('SSL yapılandırması değiştir', ["AdminTask.modifySSLConfig('[-alias " + W.resolve(form.dataset.ref).name + " -scopeName " + W.scopeLabel(W.resolve(form.dataset.ref).scope).replace('Cell=', '(cell):').replace('Node=', '(node):') + " -sslProtocol " + v.protocol + " -securityLevel " + v.securityLevel + " -clientAuthentication " + (v.clientAuth === 'Required') + " -keyStoreName " + v.keyStore + " -trustStoreName " + v.trustStore + "]')", 'AdminConfig.save()']);
  };
  R('/sec/ssl/keystores', function () {
    return secPage('Key stores and certificates', [['SSL certificate and key management', '#/sec/ssl'], 'Key stores and certificates'], '<p class="desc">Defines keystore types, including cryptography, RACF(R), CMS, Java(TM), and all truststore types. Key store = sunucunun kendi özel anahtarı ve kişisel sertifikası; trust store = güvenilen (signer) CA sertifikaları.' + W.hi('ssl.keystore') + '</p>' +
      W.table({ id: 'ks', rows: SEC().keystores, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/sec/ssl/keystores/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'description', l: 'Description' }, { k: 'scope', l: 'Management Scope', fmt: function (r) { return esc(W.scopeFull(r.scope)); } }, { k: 'path', l: 'Path' }, { k: 'type', l: 'Type', h: 'ssl.keystore' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New key store' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }, { l: 'Exchange signers...', act: 'notInSim', arg: 'Exchange signers' }] }), 'ssl.keystore');
  });
  R('/sec/ssl/keystores/:name', function (p) {
    var k = W.by(SEC().keystores, 'name', p.name), b = '#/sec/ssl/keystores/' + W.enc(k.name);
    return secPage('Key stores and certificates', [['SSL certificate and key management', '#/sec/ssl'], ['Key stores and certificates', '#/sec/ssl/keystores'], k.name], W.cfgForm({ ref: 'security.keystores|' + k.name, doc: SECDOC(), back: '#/sec/ssl/keystores', title: 'Key store ' + k.name, general:
      F.ro({ l: 'Name', v: k.name }) + F.text({ l: 'Description', n: 'description', v: k.description }) + F.ro({ l: 'Management scope', v: W.scopeFull(k.scope) }) + F.text({ l: 'Path', n: 'path', v: k.path, h: 'ssl.keystore' }) + F.pw({ l: 'Password', v: '********', h: 'ssl.keystore' }) + F.ro({ l: 'Type', v: k.type, h: 'ssl.keystore' }) + F.ck({ l: 'Read only', n: 'readOnly', v: k.readOnly }) + F.ck({ l: 'Initialize at startup', n: 'initAtStartup', v: !!k.initAtStartup }) + F.ck({ l: 'Enable cryptographic operations on hardware device', n: 'hw', v: false }),
      ap: [{ t: 'Additional Properties', items: [{ l: 'Personal certificates', href: b + '/personal', h: 'ssl.personal' }, { l: 'Signer certificates', href: b + '/signer', h: 'ssl.signer' }, { l: 'Personal certificate requests', act: 'notInSim', arg: 'Personal certificate requests', h: 'ssl.personal' }, { l: 'Custom properties', act: 'notInSim', arg: 'Custom properties' }] }] }), 'ssl.keystore');
  });
  function daysTo(d) { return Math.round((new Date(d) - new Date()) / 86400000); }
  function expFmt(d) { var n = daysTo(d); return esc(d) + (n < 0 ? ' <b style="color:#c62828">(SÜRESİ DOLMUŞ)</b>' : n < 60 ? ' <b style="color:#c62828">(' + n + ' gün kaldı)</b>' : ''); }
  R('/sec/ssl/keystores/:name/personal', function (p) {
    var k = W.by(SEC().keystores, 'name', p.name), rows = SEC().certs.personal.filter(function (c) { return c.keyStore === k.name; });
    return secPage('Key stores and certificates', [['Key stores and certificates', '#/sec/ssl/keystores'], [k.name, '#/sec/ssl/keystores/' + W.enc(k.name)], 'Personal certificates'], '<p class="desc">Manages personal certificates (özel anahtarı bu keystore\'da bulunan sertifikalar).' + W.hi('ssl.personal') + '</p>' +
      W.table({ id: 'pc', sig: k.name, rows: rows, key: function (r) { return r.alias; }, cols: [{ k: 'alias', l: 'Alias' }, { k: 'issuedTo', l: 'Issued to' }, { k: 'issuedBy', l: 'Issued by' }, { k: 'expires', l: 'Expiration', fmt: function (r) { return expFmt(r.expires); }, h: 'ssl.expiration' }], empty: 'Bu keystore\'da kişisel sertifika yok.',
        buttons: [{ l: 'Create', act: 'notInSim', arg: 'Create self-signed / chained certificate' }, { l: 'Delete', act: 'notInSim', arg: 'Delete certificate' }, { l: 'Receive from a certificate authority...', act: 'notInSim', arg: 'Receive from CA' }, { l: 'Replace...', act: 'notInSim', arg: 'Replace' }, { l: 'Extract...', act: 'notInSim', arg: 'Extract' }, { l: 'Import...', act: 'notInSim', arg: 'Import' }, { l: 'Export...', act: 'notInSim', arg: 'Export' }, { l: 'Renew', act: 'certRenew', need: 1 }] }), 'ssl.personal');
  });
  A.certRenew = function (el) {
    W.selected(el.dataset.tbl).forEach(function (a) { var c = W.by(SEC().certs.personal, 'alias', a), d = new Date(); d.setFullYear(d.getFullYear() + 1); c.expires = d.toISOString().slice(0, 10); W.cmd('Sertifika yenile', ["AdminTask.renewCertificate('[-keyStoreName " + c.keyStore + " -certificateAlias " + a + "]')", 'AdminConfig.save()']); });
    W.change(SECDOC(), 'Sertifika yenilendi'); W.clearSel(el.dataset.tbl);
    W.msg('info', ['Sertifika yenilendi (self-signed/chained ise WAS imzalar; CA imzalı sertifikalar için yeni CSR üretilip CA\'dan alınmalıdır).', 'Bu sertifikaya güvenen istemcilerin (ör. IHS plug-in keyring, harici sistemler) trust store\'larını güncellemeyi unutmayın.']); W.rerender();
  };
  R('/sec/ssl/keystores/:name/signer', function (p) {
    var k = W.by(SEC().keystores, 'name', p.name), rows = SEC().certs.signer.filter(function (c) { return c.keyStore === k.name; });
    return secPage('Key stores and certificates', [['Key stores and certificates', '#/sec/ssl/keystores'], [k.name, '#/sec/ssl/keystores/' + W.enc(k.name)], 'Signer certificates'], '<p class="desc">Manages signer certificates in key stores. Bir uç noktaya (LDAP, veritabanı, harici REST servisi) SSL ile bağlanmak için o uç noktanın sertifikasını imzalayan CA burada bulunmalıdır.' + W.hi('ssl.signer') + '</p>' +
      W.table({ id: 'sc', sig: k.name, rows: rows, key: function (r) { return r.alias; }, cols: [{ k: 'alias', l: 'Alias' }, { k: 'issuedTo', l: 'Issued to' }, { k: 'expires', l: 'Expiration', fmt: function (r) { return expFmt(r.expires); } }], empty: 'Signer sertifikası yok.',
        buttons: [{ l: 'Add', act: 'notInSim', arg: 'Add signer' }, { l: 'Delete', act: 'signerDel', need: 1 }, { l: 'Extract', act: 'notInSim', arg: 'Extract' }, { l: 'Retrieve from port', act: 'signerRetrieve', arg: k.name }] }), 'ssl.signer');
  });
  A.signerRetrieve = function (el) {
    W.modal({ title: 'Retrieve signer from port', html: '<form id="srF" onsubmit="return false">' + F.text({ l: 'Host', n: 'host', req: true, v: 'api.partnerbank.com.tr', h: 'ssl.signer' }) + F.num({ l: 'Port', n: 'port', v: 443 }) + F.sel({ l: 'SSL configuration for outbound connection', n: 'cfg', v: 'NodeDefaultSSLSettings', o: ['CellDefaultSSLSettings', 'NodeDefaultSSLSettings'] }) + F.text({ l: 'Alias', n: 'alias', req: true, v: 'partnerbank-ca' }) + '</form>',
      buttons: [{ l: 'Retrieve signer information', fn: function () {
        var v = W.readForm(document.getElementById('srF')).vals;
        SEC().certs.signer.push({ alias: v.alias, issuedTo: 'CN=DigiCert Global G2 TLS RSA SHA256 2020 CA1, O=DigiCert Inc, C=US', expires: '2031-03-29', keyStore: el.dataset.arg });
        W.change(SECDOC(), 'Signer eklendi: ' + v.alias);
        W.cmd('Signer al (retrieve from port)', ["AdminTask.retrieveSignerFromPort('[-keyStoreName " + el.dataset.arg + " -keyStoreScope (cell):" + CELL() + " -host " + v.host + " -port " + v.port + " -certificateAlias " + v.alias + " -sslConfigName " + v.cfg + "]')", 'AdminConfig.save()']);
        W.msg('info', 'Signer sertifikası ' + esc(v.host) + ':' + v.port + ' adresinden alındı ve ' + esc(el.dataset.arg) + ' içine <b>' + esc(v.alias) + '</b> adıyla eklendi. Parmak izini (SHA-256 fingerprint) karşı tarafla doğrulamadan eklemeyin.'); W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.signerDel = function (el) { var sel = W.selected(el.dataset.tbl); SEC().certs.signer = SEC().certs.signer.filter(function (c) { return sel.indexOf(c.alias) < 0; }); W.change(SECDOC(), 'Signer silindi: ' + sel.join(', ')); W.msg('warning', 'Signer silindi. Bu CA tarafından imzalanmış uç noktalara SSL bağlantıları artık CWPKI0022E ile başarısız olacak.'); W.clearSel(el.dataset.tbl); W.rerender(); };
  R('/sec/ssl/endpoints', function () {
    var tree = '<div class="tree"><ul><li><b>' + esc(CELL()) + '</b> (cell) – Inbound/Outbound: CellDefaultSSLSettings<ul>' +
      ['AppNode01', 'AppNode02', 'AppNode03'].map(function (n) { return '<li>' + esc(n) + ' (node) – NodeDefaultSSLSettings<ul>' + W.S.servers.filter(function (s) { return s.node === n; }).map(function (s) { return '<li>' + esc(s.name) + ' (server) – ' + (s.cluster === 'BankingCluster' ? '<b>IBTLSSettings</b> (cluster BankingCluster\'dan)' : 'NodeDefaultSSLSettings (inherited)') + '<ul><li>WC_defaulthost_secure</li><li>ORB_SSL_LISTENER_ADDRESS</li><li>SIB_ENDPOINT_SECURE_ADDRESS</li></ul></li>'; }).join('') + '</ul></li>'; }).join('') +
      '<li>BankingCluster (cluster) – IBTLSSettings</li></ul></li></ul></div>';
    return secPage('Manage endpoint security configurations', [['SSL certificate and key management', '#/sec/ssl'], 'Manage endpoint security configurations'], '<p class="desc">SSL yapılandırmalarının hangi yönetim kapsamına (scope) ve uç noktaya (endpoint) atandığını gösterir. Alt kapsam, üstünden devralır; özel atama yapılmışsa onu kullanır.' + W.hi('ssl.endpoints') + '</p>' + tree, 'ssl.endpoints');
  });
  R('/sec/ssl/expiration', function () {
    var all = SEC().certs.personal.concat(SEC().certs.signer).map(function (c) { return Object.assign({ days: daysTo(c.expires) }, c); }).sort(function (a, b) { return a.days - b.days; });
    return secPage('Manage certificate expiration', [['SSL certificate and key management', '#/sec/ssl'], 'Manage certificate expiration'], '<p class="desc">Certificate expiration monitor, belirlenen eşik içinde süresi dolacak sertifikaları bildirir ve (self-signed ise) otomatik yenileyebilir.' + W.hi('ssl.expiration') + '</p>' +
      F.ck({ l: 'Automatically replace expiring self-signed certificates', v: true, ro: true, h: 'ssl.expiration' }) + F.ck({ l: 'Delete expiring certificates and signers after replacement', v: false, ro: true }) + F.ro({ l: 'Expiration notification threshold', v: '60 days' }) + F.ro({ l: 'Notification', v: 'Message logs (SystemOut.log) + e-mail: middleware@corp.local' }) +
      '<div class="btnrow"><button class="btn" data-act="certCheck">Start now</button></div>' +
      W.table({ id: 'expl', select: false, rows: all, key: function (r) { return r.alias + r.keyStore; }, cols: [{ k: 'alias', l: 'Alias' }, { k: 'keyStore', l: 'Key store' }, { k: 'expires', l: 'Expiration', fmt: function (r) { return expFmt(r.expires); } }, { k: 'days', l: 'Days left' }] }), 'ssl.expiration');
  });
  A.certCheck = function () {
    var soon = SEC().certs.personal.concat(SEC().certs.signer).filter(function (c) { return daysTo(c.expires) < 60; });
    W.msg(soon.length ? 'warning' : 'info', soon.length ? soon.map(function (c) { return 'CWPKI0017W: The certificate with alias ' + esc(c.alias) + ' from keyStore ' + esc(c.keyStore) + ' is expiring in ' + daysTo(c.expires) + ' days. (CA imzalı ise yenileme otomatik yapılamaz; yeni sertifika talep edin.)'; }) : ['Eşik içinde süresi dolan sertifika yok.']);
    W.rerender();
  };

  /* Users and groups */
  R('/ug/userroles', function () {
    return secPage('Administrative user roles', null, '<div class="page-title">Administrative user roles' + W.hi('sec.adminRoles') + '</div><p class="desc">Use this page to give users specific authority to administer application servers through the administrative console or through wsadmin scripting.</p>' +
      W.table({ id: 'ur', rows: SEC().adminUserRoles.map(function (r) { return { name: r[0], roles: r[1] }; }), key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'User' }, { k: 'roles', l: 'Role(s)', h: 'sec.adminRoles' }], buttons: [{ l: 'Add...', act: 'roleAdd', arg: 'user' }, { l: 'Remove', act: 'roleRemove', arg: 'user', need: 1 }] }) + roleLegend(), 'sec.adminRoles');
  });
  R('/ug/grouproles', function () {
    return secPage('Administrative group roles', null, '<div class="page-title">Administrative group roles' + W.hi('sec.adminRoles') + '</div><p class="desc">Use this page to give groups specific authority to administer application servers. Kişisel kullanıcı yerine grup eşlemesi tercih edilmelidir (işe giriş/çıkışlar LDAP\'ta yönetilir).</p>' +
      W.table({ id: 'gr', rows: SEC().adminGroupRoles.map(function (r) { return { name: r[0], roles: r[1] }; }), key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Group' }, { k: 'roles', l: 'Role(s)', h: 'sec.adminRoles' }], buttons: [{ l: 'Add...', act: 'roleAdd', arg: 'group' }, { l: 'Remove', act: 'roleRemove', arg: 'group', need: 1 }] }) + roleLegend(), 'sec.adminRoles');
  });
  function roleLegend() {
    return '<div class="sect-title" style="margin-top:14px">Yönetim rolleri</div>' + W.simpleTable(['Rol', 'Yetki'], [['Monitor', 'Yalnızca görüntüleme (konfigürasyon ve durum).'], ['Configurator', 'Monitor + konfigürasyon değiştirme; sunucu başlatma/durdurma yok.'], ['Operator', 'Monitor + runtime işlemleri (start/stop); konfigürasyon değişikliği yok.'], ['Administrator', 'Operator + Configurator; güvenlik ayarları hariç tam yetki (AdminSecurityManager ile birlikte güvenlik).'], ['Deployer', 'Uygulama kurma/güncelleme/başlatma.'], ['AdminSecurityManager', 'Yönetim rollerini atama ve güvenlik yapılandırması.'], ['Auditor', 'Security auditing yapılandırması ve denetim kayıtları.'], ['iscadmins', 'Konsolda kullanıcı/grup (VMM) yönetimi.']].map(function (r) { return ['<b>' + r[0] + '</b>', esc(r[1])]; }));
  }
  A.roleAdd = function (el) {
    var isU = el.dataset.arg === 'user';
    W.modal({ title: 'Add ' + (isU ? 'user' : 'group') + ' role', html: '<form id="raF" onsubmit="return false">' + F.text({ l: isU ? 'User' : 'Group', n: 'name', req: true }) + '<div class="lbl">Role(s)</div>' + ['Administrator', 'Configurator', 'Operator', 'Monitor', 'Deployer', 'AdminSecurityManager', 'Auditor', 'iscadmins'].map(function (r) { return '<label class="ck-line"><input type="checkbox" name="r_' + r + '">' + r + '</label>'; }).join('') + '</form>',
      buttons: [{ l: 'OK', fn: function () {
        var v = W.readForm(document.getElementById('raF')).vals, roles = Object.keys(v).filter(function (k) { return k.indexOf('r_') === 0 && v[k]; }).map(function (k) { return k.slice(2); });
        if (!v.name || !roles.length) { alert('Kullanıcı/grup ve en az bir rol seçin.'); return false; }
        SEC()[isU ? 'adminUserRoles' : 'adminGroupRoles'].push([v.name, roles.join(', ')]);
        W.change('cells/' + CELL() + '/admin-authz.xml', 'Yönetim rolü: ' + v.name + ' → ' + roles.join(', '));
        W.cmd('Yönetim rolü ata', roles.map(function (r) { return "AdminTask.mapUsersToAdminRole('[-roleName " + r + " -" + (isU ? 'userids' : 'groupids') + " " + v.name + "]')".replace('mapUsersToAdminRole', isU ? 'mapUsersToAdminRole' : 'mapGroupsToAdminRole'); }).concat(['AdminConfig.save()']));
        W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.roleRemove = function (el) { var k = el.dataset.arg === 'user' ? 'adminUserRoles' : 'adminGroupRoles', sel = W.selected(el.dataset.tbl); if (sel.indexOf('wasadmin') >= 0) { W.msg('error', 'Primary administrative user (wasadmin) kaldırılamaz.'); W.rerender(); return; } SEC()[k] = SEC()[k].filter(function (r) { return sel.indexOf(r[0]) < 0; }); W.change('cells/' + CELL() + '/admin-authz.xml', 'Yönetim rolü kaldırıldı'); W.clearSel(el.dataset.tbl); W.rerender(); };
  R('/ug/users', function () {
    return secPage('Manage Users', null, '<div class="page-title">Manage Users' + W.hi('sec.federated') + '</div><p class="desc">Federated realm (' + esc(SEC().realm) + ') içindeki kullanıcılar. LDAP kullanıcıları LDAP tarafında yönetilir; konsoldan yalnızca dosya tabanlı repository kullanıcıları oluşturulabilir.</p>' +
      W.table({ id: 'users', rows: SEC().users, key: function (r) { return r.uid; }, cols: [{ k: 'uid', l: 'User ID' }, { k: 'first', l: 'First name' }, { k: 'last', l: 'Last name' }, { k: 'email', l: 'E-mail' }, { k: 'repo', l: 'Repository' }], buttons: [{ l: 'Create...', act: 'notInSim', arg: 'Create user' }, { l: 'Delete', act: 'notInSim', arg: 'Delete user' }] }), 'sec.federated');
  });
  R('/ug/groups', function () {
    return secPage('Manage Groups', null, '<div class="page-title">Manage Groups</div><p class="desc">Realm içindeki gruplar.</p>' + W.table({ id: 'groups', rows: SEC().groups, key: function (r) { return r.cn; }, cols: [{ k: 'cn', l: 'Group name' }, { k: 'description', l: 'Description' }, { k: 'members', l: 'Members' }, { k: 'repo', l: 'Repository' }], buttons: [{ l: 'Create...', act: 'notInSim', arg: 'Create group' }, { l: 'Delete', act: 'notInSim', arg: 'Delete group' }] }), 'sec.federated');
  });
})();
