/* help-arch.js – WAS mimari yapıları (topolojiler) açıklamaları. */
WAS.help.add({
  'arch.overview': {
    t: 'IBM WAS mimari yapıları (topolojiler)', scope: 'Ürün / Cell',
    what: 'WAS traditional iki temel yapıda kurulur: <b>Standalone</b> (tek, bağımsız application server – Base mimarisi) ve <b>Network Deployment</b> (DMGR tarafından merkezi yönetilen, node agent\'lı, cluster destekli dağıtık hücre). Bunlara ek olarak <b>federasyon</b> (standalone node\'un hücreye katılması), <b>vertical/horizontal cluster</b> ve <b>flexible management</b> (admin agent, job manager) gibi yapı taşları bulunur.',
    role: 'Seçilen yapı; yönetim modelini, yüksek erişilebilirliği, ölçeklemeyi, lisans gereksinimini ve operasyon karmaşıklığını belirler.',
    use: 'Ortamın amacına (geliştirme, test, üretim) ve SLA gereksinimlerine uygun topoloji seçmek.',
    when: 'Kurulum planlamasında ve kapasite/erişilebilirlik gereksinimleri değiştiğinde (ör. standalone bir uygulamanın üretim kritikliği arttığında federasyon ve cluster\'a geçiş).',
    benefit: 'Doğru topoloji gereksiz karmaşıklıktan kaçınırken kesinti ve ölçekleme sorunlarını önler.',
    ex: 'DEV: Standalone server1 (Base)\nTEST: Küçük ND hücresi (1 DMGR + 2 node, 2 üyeli cluster)\nPROD: ND hücresi (1 DMGR + 3 node, horizontal cluster\'lar, 2 IHS, F5)',
    risk: 'Üretim uygulamasını standalone sunucuda çalıştırmak tek nokta hatası yaratır; küçük bir uygulama için ND kurmak ise gereksiz maliyet ve yönetim yükü getirir.',
    see: ['arch.standalone', 'arch.nd', 'arch.federation', 'arch.profiles', 'concept.cluster']
  },
  'arch.standalone': {
    t: 'Standalone (Base) mimari', scope: 'Node / Server',
    what: 'Tek bir application server profilinin (server1) DMGR ve node agent olmadan, kendi başına çalıştığı yapı. Yönetim konsolu ve wsadmin bağlantı noktası sunucunun kendi içindedir; konfigürasyon yalnızca o profilin dizininde tutulur.',
    role: 'WAS Base ve Express sürümlerinin tek seçeneğidir; ND sürümünde ise federasyondan önceki başlangıç durumudur.',
    use: 'Geliştirme, birim/entegrasyon testi, küçük ve kritik olmayan uygulamalar.',
    when: 'Yüksek erişilebilirlik ve yatay ölçekleme gerekmiyorsa.',
    benefit: 'Basitlik, düşük kaynak kullanımı, hızlı kurulum.',
    ex: 'manageprofiles.sh -create -profileName AppSrv01 -templatePath .../profileTemplates/default\nKonsol: https://was-dev01:9043/ibm/console (server1 içinde)',
    risk: 'Sunucu çökerse uygulama ve yönetim konsolu birlikte erişilemez. Çok sayıda standalone sunucu ayrı ayrı yönetildiğinde konfigürasyon farklılıkları (drift) oluşur.',
    see: ['arch.federation', 'arch.nd']
  },
  'arch.nd': {
    t: 'Network Deployment (ND) mimarisi', scope: 'Cell',
    what: 'Bir Deployment Manager, her makinede bir node agent ve application server\'lardan oluşan; tek bir Cell altında merkezi yönetilen dağıtık yapı. Cluster, WLM, session replikasyonu ve HA Manager yalnızca bu mimaride vardır.',
    role: 'DMGR konfigürasyonu yönetir ve dağıtır; node agent\'lar yerel yönetimi ve senkronizasyonu yapar; sunucular uygulamaları çalıştırır; web server plug-in istekleri cluster üyelerine dağıtır.',
    use: 'Üretim ortamları, 7/24 hizmet, yatay ölçekleme ve kesintisiz bakım.',
    when: 'Birden çok sunucu/makine, yük dengeleme veya failover gerektiğinde.',
    benefit: 'Merkezi yönetim, yüksek erişilebilirlik, kapasite artışı, Ripplestart/Rollout Update ile kesintisiz değişiklik.',
    ex: 'WASPRODCell01: CellManager01 (dmgr) + AppNode01/02/03 (nodeagent + sunucular) + ihsnode01/02 (IHS)',
    risk: 'Daha fazla süreç ve bellek; ağ portlarının (SOAP, DCS, BOOTSTRAP) güvenlik duvarında açık olması gerekir; senkronizasyon ve plug-in yayma adımları atlanırsa değişiklikler etkisiz kalır.',
    see: ['concept.dmgr', 'concept.nodeAgent', 'concept.cluster', 'concept.cell']
  },
  'arch.federation': {
    t: 'Federasyon (addNode / removeNode)', scope: 'Node → Cell',
    what: 'Standalone (veya custom) bir profilin <code>addNode.sh</code> ile bir Deployment Manager hücresine katılmasıdır. Node\'un konfigürasyonu DMGR master repository\'sine eklenir, node agent oluşturulup başlatılır ve node "managed" hale gelir.',
    role: '<b>-includeapps</b>: node\'daki mevcut uygulamaları da hücreye taşır (aynı adlı uygulama hücrede varsa atlanır). <b>-includebuses</b>: SIBus tanımlarını taşır. İşlem öncesi orijinal konfigürasyon yedeklenir; <code>removeNode.sh</code> node\'u hücreden çıkarıp bu yedeği geri yükler.',
    use: 'Standalone sunucuları merkezi yönetime almak veya yeni makineleri (custom profil) ND hücresine eklemek.',
    when: 'Yeni uygulama sunucusu makinesi eklendiğinde ya da bir standalone uygulama üretim kritik hale geldiğinde.',
    benefit: 'Node\'un cluster üyesi olabilmesi, hücre kaynaklarına erişim ve tek konsoldan yönetim.',
    ex: 'addNode.sh was-dmgr01.corp.local 8879 -includeapps -username wasadmin -password ****\n→ ADMU0003I: Node AppNode04 has been successfully federated.\nGeri alma: removeNode.sh -username wasadmin -password ****',
    risk: 'Node adı hücrede benzersiz olmalı; DMGR\'nin sürümü node\'un sürümünden eski olamaz; saat farkı ve SSL güven sorunları federasyonu bozar. removeNode sonrası federe dönemdeki değişiklikler kaybolur. Standalone sunucunun kendi admin konsolu federasyon sonrası kaldırılır; yönetim artık DMGR\'den yapılır.',
    see: ['arch.standalone', 'concept.nodeAgent', 'sys.sync']
  },
  'arch.profiles': {
    t: 'WAS profilleri', scope: 'Kurulum / Makine',
    what: 'Profil, WAS ürün ikili dosyalarından ayrı tutulan bir çalışma zamanı ortamıdır (konfigürasyon, loglar, uygulamalar, portlar). Türleri: Application server (standalone), Management (Deployment manager, Administrative agent, Job manager), Custom (boş managed node), Cell (DMGR + node birlikte), Secure proxy.',
    role: 'Aynı ürün kurulumundan birden çok profil oluşturulabilir; fix pack ürün dizinine uygulanır ve tüm profilleri etkiler.',
    use: 'Rolüne göre (DMGR, uygulama node\'u, standalone) WAS ortamı oluşturmak.',
    when: 'Yeni makine/ortam kurulumunda manageprofiles.sh veya Profile Management Tool ile.',
    benefit: 'Tek kurulumla birden çok bağımsız ortam; tutarlı ürün seviyesi.',
    ex: 'manageprofiles.sh -create -profileName Dmgr01 -templatePath .../profileTemplates/management -serverType DEPLOYMENT_MANAGER\nmanageprofiles.sh -create -profileName AppSrv01 -templatePath .../profileTemplates/managed\nmanageprofiles.sh -listProfiles',
    risk: 'Profil silinmeden önce node hücreden çıkarılmazsa (removeNode) DMGR\'de "hayalet" node kalır (cleanupNode gerekir). Aynı makinedeki profillerde port çakışmaları planlanmalıdır.',
    see: ['arch.standalone', 'arch.federation']
  },
  'arch.vertical': {
    t: 'Vertical clustering', scope: 'Cluster',
    what: 'Aynı cluster\'ın birden çok üyesinin aynı makinede (aynı node\'da) çalıştırılması.',
    role: 'Tek JVM\'in tüm CPU\'ları ve belleği verimli kullanamadığı durumlarda kapasiteyi artırır; bir JVM çökmesine karşı (aynı makinede) koruma sağlar.',
    use: 'Güçlü bir makinede daha küçük heap\'li birden çok JVM çalıştırmak (kısa GC duraklamaları).',
    when: 'Makinede boş CPU/bellek kapasitesi varken ve uygulama tek JVM\'de ölçeklenemiyorsa.',
    benefit: 'Donanımın daha iyi kullanımı, JVM seviyesinde dayanıklılık.',
    ex: 'AppNode01: AppSrvA, AppSrvB (aynı cluster, farklı portlar – genUniquePorts)',
    risk: 'Makine veya işletim sistemi arızasında tüm üyeler aynı anda gider; tek başına yüksek erişilebilirlik sağlamaz. Üyelerin toplam heap\'i fiziksel belleği aşmamalıdır.',
    see: ['arch.horizontal', 'concept.cluster']
  },
  'arch.horizontal': {
    t: 'Horizontal clustering', scope: 'Cluster',
    what: 'Cluster üyelerinin farklı makinelere (farklı node\'lara) dağıtılması.',
    role: 'Plug-in ve WLM istekleri makineler arasında dağıtır; bir makine tamamen kaybedilse bile diğer makinelerdeki üyeler hizmet verir.',
    use: 'Üretimde yüksek erişilebilirlik ve yatay ölçekleme.',
    when: 'Donanım/OS arızasına karşı dayanıklılık gerektiğinde (her üretim ortamında önerilir).',
    benefit: 'Gerçek yüksek erişilebilirlik; makine ekleyerek kapasite artışı.',
    ex: 'BankingCluster: BankSrv01 (AppNode01), BankSrv02 (AppNode02), BankSrv03 (AppNode03)',
    risk: 'Session replikasyonu ve transaction log paylaşımı ağ ve depolama altyapısına bağımlılık getirir.',
    see: ['arch.vertical', 'concept.wlm', 'concept.m2m']
  },
  'arch.flexible': {
    t: 'Flexible management (Admin agent + Job manager)', scope: 'Makine / Çoklu hücre',
    what: 'Administrative agent, aynı makinedeki birden çok Base (standalone) profilini tek konsoldan yönetir. Job manager, kayıtlı DMGR hücrelerine ve admin agent\'lara asenkron job\'lar (uygulama kurma, sunucu başlatma, dosya dağıtma, betik çalıştırma) gönderir.',
    role: 'DMGR\'nin senkron, sıkı bağlı yönetimine alternatif/ek olarak çok sayıda ve coğrafi olarak dağınık ortamın gevşek bağlı yönetimini sağlar.',
    use: 'Şube sunucuları, çok sayıda bağımsız Base kurulumu, birden çok ND hücresinin toplu yönetimi.',
    when: 'Yönetilecek ortam sayısı DMGR modelinin pratik sınırlarını aştığında.',
    benefit: 'Ölçeklenebilirlik; hedefler çevrimdışıyken job\'ların kuyrukta beklemesi.',
    ex: 'registerNode.sh (Base profili admin agent\'a kaydeder)\nAdminTask.registerWithJobManager(...) (DMGR\'yi job manager\'a kaydeder)',
    risk: 'Cluster/WLM/HA sağlamaz; yalnızca yönetim katmanıdır. Bir node aynı anda hem DMGR hem admin agent tarafından yönetilemez.',
    see: ['sys.adminAgent', 'sys.jobManager']
  }
});
