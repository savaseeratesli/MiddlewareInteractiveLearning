/* pages-learn.js – WAS Öğrenme Merkezi: topoloji, istek akışı simülatörü,
   cluster/WLM/failover/session replikasyonu, scope, hata senaryoları,
   kavram sözlüğü ve Guided Activities. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };
  var CL_COLORS = ['#2f7ed8', '#8e44ad', '#e67e22', '#16a085', '#c0392b'];
  function clIdx(c) { var i = W.S.clusters.map(function (x) { return x.name; }).indexOf(c); return i < 0 ? 'none' : i % 5; }

  /* ----------------------------------------------------------- ana sayfa */
  R('/learn', function () {
    var cards = [
      ['Mimari yapılar', 'Standalone (Base), Network Deployment, Deployment Manager, Node Agent, vertical/horizontal cluster, federasyon (addNode) simülatörü, profil türleri ve esnek yönetim.', ['arch.overview', 'arch.standalone', 'arch.nd', 'arch.federation', 'arch.profiles'], '#/learn/architecture'],
      ['Yönetim mimarisi', 'Cell, Node, Deployment Manager, Node Agent ve Application Server ilişkisi; merkezi yönetim ve senkronizasyon.', ['concept.cell', 'concept.node', 'concept.dmgr', 'concept.nodeAgent', 'concept.appserver'], '#/learn/topology'],
      ['Cluster ve yüksek erişilebilirlik', 'Server cluster, WLM, weight, failover, session replikasyonu, core group ve HA Manager.', ['concept.cluster', 'concept.wlm', 'concept.m2m', 'concept.coreGroup'], '#/learn/cluster'],
      ['Web katmanı', 'IBM HTTP Server, WebSphere Plug-in, plugin-cfg.xml, virtual host ve istek yönlendirme.', ['concept.ihs', 'concept.plugin', 'concept.pluginCfg', 'concept.vhost'], '#/learn/requestflow'],
      ['JVM ve container\'lar', 'JVM heap/GC, Web container (servlet/JSP), EJB container, thread pool\'lar, class loader.', ['concept.jvm', 'concept.webContainer', 'concept.ejbContainer', 'concept.threadPool', 'concept.classloader'], '#/servers/appservers/BankSrv01'],
      ['Veritabanı erişimi', 'JDBC provider, data source, connection pool, J2C authentication alias, test connection.', ['concept.jdbcProvider', 'concept.datasource', 'concept.connectionPool', 'sec.authAlias'], '#/guided/database'],
      ['Mesajlaşma (JMS)', 'Default messaging (SIBus), messaging engine, queue/topic, activation spec, IBM MQ.', ['concept.sib', 'concept.jmsProvider', 'jms.queue', 'jms.as'], '#/res/jms/queues'],
      ['Güvenlik', 'Administrative/application security, user registry (LDAP), LTPA/SSO, SSL, roller.', ['concept.security', 'concept.userRegistry', 'sec.ltpa', 'concept.ssl'], '#/sec/global'],
      ['Session ve transaction', 'HTTP session yönetimi, kalıcılık seçenekleri; transaction service, timeout\'lar, recovery.', ['concept.session', 'sess.distributed', 'tx.service', 'tx.recovery'], '#/servers/appservers/BankSrv01/session'],
      ['İzleme ve sorun giderme', 'PMI, TPV, request metrics; SystemOut/SystemErr, native loglar, FFDC, trace.', ['concept.pmi', 'concept.logs', 'log.ffdc', 'log.trace'], '#/learn/troubleshooting'],
      ['Yapılandırma seviyeleri', 'Cell/Node/Cluster/Server/Application kapsamları, WebSphere variables ve öncelik kuralları.', ['concept.scope', 'concept.wasVariable', 'concept.workspace'], '#/learn/scope']
    ];
    var html = '<div class="page-title">WAS Öğrenme Merkezi' + W.hi('concept.was') + '</div><p class="desc">Bu bölüm, IBM WebSphere Application Server <b>traditional (ND 9.0.5)</b> mimarisini adım adım öğrenmeniz için hazırlanmıştır. Her kartta ilgili kavramların açıklamalarını açabilir ve konsolun ilgili sayfasına gidebilirsiniz.</p>' +
      '<div class="note-tr"><b>Önemli ayrım:</b> Bu simülasyon <b>WAS traditional</b> (tam profil, ISC yönetim konsolu, DMGR/node agent mimarisi) içindir. <b>WebSphere Liberty</b> farklı bir üründür: server.xml + feature tabanlıdır, DMGR/node agent yerine Collective Controller kullanır ve bu konsola sahip değildir.' + W.hi('concept.libertyVsTraditional') + '</div><div class="cards">' +
      cards.map(function (c) { return '<div class="card"><h4>' + esc(c[0]) + '</h4><p>' + esc(c[1]) + '</p><p>' + c[2].map(function (k) { return '<a class="badge" data-help="' + k + '">' + (W.HELP[k] ? W.HELP[k].t.replace(/<[^>]+>/g, '') : k) + '</a>'; }).join('') + '</p><a href="' + c[3] + '">→ Konsolda incele</a></div>'; }).join('') + '</div>';
    return { title: 'WAS Öğrenme Merkezi', help: 'concept.was', html: html };
  });

  /* ------------------------------------------------------------ topoloji */
  R('/learn/topology', function () {
    var procBox = function (cls, name, st, link, extra, help) { return '<div class="topo-proc ' + cls + '"><span class="inline-flex">' + (link ? '<a href="' + link + '">' + esc(name) + '</a>' : esc(name)) + W.hi(help) + '</span><span>' + (extra || '') + ' ' + W.stIcon(st, '') + '</span></div>'; };
    var nodes = W.S.nodes.map(function (n) {
      var inner = '';
      if (n.type === 'dmgr') inner = procBox('dm', 'dmgr (Deployment Manager)', 'started', '#/sys/dmgr', '', 'concept.dmgr') + '<div style="font-size:10.5px;color:#555;margin-top:4px">Master repository: profiles/Dmgr01/config<br>Konsol: https://' + esc(n.host) + ':9043/ibm/console</div>';
      else if (n.type === 'managed') {
        inner = procBox('na', 'nodeagent', W.RT.nodeagents[n.name], '#/sys/nodeagents/' + W.enc(n.name), W.RT.sync[n.name] ? '<span title="Synchronized">' + W.ICON.sync + '</span>' : '<span title="Not synchronized">' + W.ICON.nosync + '</span>', 'concept.nodeAgent') +
          W.S.servers.filter(function (s) { return s.node === n.name; }).map(function (s) { return procBox('cl-c' + clIdx(s.cluster), s.name, W.serverStatus(s), '#/servers/appservers/' + W.enc(s.name), '<span style="font-size:10px;color:#666">' + (s.cluster || 'standalone') + ' :' + s.ports.WC_defaulthost + '</span>', 'concept.appserver'); }).join('');
      } else inner = W.S.webservers.filter(function (w) { return w.node === n.name; }).map(function (w) { return procBox('', w.name + ' (IHS + Plug-in)', W.wsStatus(w) === 'running' ? 'started' : 'stopped', '#/servers/webservers/' + W.enc(w.name), ':' + w.port + '/:443', 'concept.ihs'); }).join('') + '<div style="font-size:10.5px;color:#555;margin-top:4px">Node agent yok – DMGR, IHS Admin Server (8008) üzerinden yönetir.</div>';
      return '<div class="topo-node"><div class="tn"><span class="inline-flex"><a href="#/sys/nodes/' + W.enc(n.name) + '">' + esc(n.name) + '</a>' + W.hi(n.type === 'unmanaged' ? 'concept.unmanagedNode' : n.type === 'dmgr' ? 'concept.dmgr' : 'concept.node') + '</span><span class="badge ' + (n.type === 'unmanaged' ? 'node' : 'cell') + '">' + (n.type === 'dmgr' ? 'DMGR node' : n.type === 'managed' ? 'managed' : 'unmanaged') + '</span></div><div class="th">' + esc(n.host) + ' · ' + n.cpu + ' vCPU / ' + n.ramGB + ' GB</div>' + inner + '</div>';
    });
    var legend = '<div class="legend">' + W.S.clusters.map(function (c, i) { return '<span style="--c:' + CL_COLORS[i % 5] + '"><a href="#/clusters/' + W.enc(c.name) + '">' + esc(c.name) + '</a> (' + c.members.length + ' üye)</span>'; }).join('') + '<span style="--c:#95a5a6">Standalone</span><span style="--c:#888">Node agent</span><span style="--c:#12366e">DMGR</span></div>';
    var html = '<div class="page-title">Hücre topolojisi' + W.hi('concept.cell') + '</div><p class="desc">Aşağıdaki diyagram bu simülasyondaki <b>' + esc(CELL()) + '</b> hücresinin canlı durumudur. Sunucuları başlatıp durdurdukça, node agent\'ları durdurdukça veya yeni cluster üyesi ekledikçe değişir. Renkli sol kenarlık, sunucunun hangi cluster\'a ait olduğunu gösterir: bir cluster birden çok node\'a yayılabilir.</p>' + legend +
      '<div class="topo"><div class="topo-cell"><div class="tt">Cell: ' + esc(CELL()) + W.hi('concept.cell') + '</div><div class="topo-row">' + nodes.join('') + '</div></div></div>' +
      '<div class="cards" style="margin-top:12px">' +
      '<div class="card"><h4>1. Konfigürasyon akışı' + W.hi('concept.workspace') + '</h4><p>Konsolda değişiklik → workspace → <b>Save</b> → DMGR master repository → node agent\'lar <b>File Synchronization Service</b> ile (varsayılan 1 dk) değişikliği kendi node repository\'lerine çeker → sunucu bir sonraki başlatmada (veya dinamik ise hemen) kullanır.</p></div>' +
      '<div class="card"><h4>2. Yönetim (runtime) akışı' + W.hi('concept.nodeAgent') + '</h4><p>"Start server" isteği: Konsol (DMGR) → JMX/SOAP → ilgili node agent → node agent sunucu JVM\'ini başlatır ve izler (monitoring policy). Node agent kapalıysa DMGR o node\'daki sunucuları yönetemez.</p></div>' +
      '<div class="card"><h4>3. DMGR kapalıysa ne olur?' + W.hi('concept.dmgr') + '</h4><p>Uygulamalar ve sunucular <b>çalışmaya devam eder</b>; node agent\'lar yerel konfigürasyonla sunucuları yönetir. Yalnızca konsol, konfigürasyon değişikliği ve senkronizasyon yapılamaz. DMGR tek nokta hatası (SPOF) değildir.</p></div>' +
      '<div class="card"><h4>4. HA Manager / core group' + W.hi('concept.coreGroup') + '</h4><p>Tüm süreçler DefaultCoreGroup üyesidir. HA Manager; messaging engine ve transaction log recovery gibi "tekil" servislerin bir anda yalnızca bir üyede çalışmasını ve çöken üyenin servisinin başka üyede devralınmasını sağlar.</p></div></div>';
    return { title: 'Hücre topolojisi', help: 'concept.cell', html: html };
  });

  /* ------------------------------------------------------------ istek akışı */
  var PRESETS = ['https://www.ornekbank.com.tr/corebank/accounts/summary', 'https://ib.ornekbank.com.tr/ib/login', 'https://ib.ornekbank.com.tr/ib/api/v1/balance', 'https://www.ornekbank.com.tr/portal/home', 'https://www.ornekbank.com.tr/payment/eft', 'https://www.ornekbank.com.tr/reports/daily', 'https://www.ornekbank.com.tr/notifyadmin/queue', 'https://www.ornekbank.com.tr:8443/corebank/accounts'];
  W._flow = W._flow || { url: PRESETS[0], affinity: '', steps: null, dist: null };
  R('/learn/requestflow', function () {
    var f = W._flow, res = f.steps;
    var act = res ? res.active : {};
    var box = function (k, t, sub, help) { return '<div class="fb' + (act[k] === 'ok' ? ' active' : act[k] === 'down' ? ' down' : '') + '" data-help="' + help + '"><b>' + t + '</b><small>' + sub + '</small></div>'; };
    var arrow = '<div class="fa">➜</div>';
    var html = '<div class="page-title">İstek akışı: Client → F5 → IBM HTTP Server → WebSphere Plug-in → WAS → Application' + W.hi('concept.plugin') + '</div>' +
      '<p class="desc">Bir HTTP isteğinin kurumsal WAS mimarisinde izlediği yol. Kutulara tıklayarak her bileşenin açıklamasını görebilirsiniz. Aşağıdaki simülatör, isteği bu simülasyondaki <b>gerçek konfigürasyona</b> (virtual host\'lar, uygulama context root\'ları, cluster üyeleri ve durumları, plugin-cfg.xml) göre yönlendirir.</p>' +
      '<div class="flow">' + box('client', 'Client', 'Tarayıcı / mobil uygulama', 'arch.client') + arrow + box('f5', 'F5 / Load Balancer', 'VIP: www/ib.ornekbank.com.tr:443', 'arch.f5') + arrow + box('ihs', 'IBM HTTP Server', 'ihs-web01 / ihs-web02', 'concept.ihs') + arrow + box('plugin', 'WebSphere Plug-in', 'mod_was_ap24 + plugin-cfg.xml', 'concept.plugin') + arrow + box('was', 'WAS Application Server', 'Web container (cluster üyesi)', 'concept.appserver') + arrow + box('app', 'Application', 'EAR / WAR modülü', 'concept.enterpriseApp') + '</div>' +
      '<div class="portlet" style="margin-top:12px"><div class="ph"><span>İstek simülatörü</span></div><div class="pb">' +
      '<div class="inline-flex" style="gap:6px;flex-wrap:wrap;width:100%"><input type="text" id="flowUrl" value="' + esc(f.url) + '" style="flex:1;min-width:260px;border:1px solid #8d9dbb;padding:3px 5px" list="flowPresets"><datalist id="flowPresets">' + PRESETS.map(function (u) { return '<option value="' + esc(u) + '">'; }).join('') + '</datalist>' +
      '<button class="btn primary" data-act="flowSend">İsteği gönder</button><button class="btn" data-act="flowSend" data-arg="aff">Aynı session ile tekrar gönder</button><button class="btn" data-act="flowMany">20 istek (yeni session) gönder</button></div>' +
      '<div style="margin-top:6px;color:#555">Hazır örnekler: ' + PRESETS.map(function (u) { return '<a data-act="flowPreset" data-arg="' + esc(u) + '">' + esc(u.replace(/^https:\/\//, '')) + '</a>'; }).join(' · ') + '</div>' +
      (f.affinity ? '<p>Mevcut session çerezi: <code>JSESSIONID=0000' + 'Kq3vXb9TzR7mN2wY1aLp5cE:' + esc(f.affinity) + '</code> (son kısım = CloneID)' + W.hi('plg.affinity') + '</p>' : '') +
      (res ? '<div class="steps-log"><b>Sonuç: HTTP ' + res.code + '</b><ol>' + res.lines.map(function (l) { return '<li>' + l + '</li>'; }).join('') + '</ol></div>' : '') +
      (f.dist ? '<div class="sect-title" style="margin-top:12px">Dağılım (' + f.dist.total + ' istek)</div>' + W.simpleTable(['Hedef', 'İstek sayısı', 'Oran'], Object.keys(f.dist.c).map(function (k) { return [esc(k), f.dist.c[k], '<div class="bar"><i style="width:' + Math.round(f.dist.c[k] / f.dist.total * 100) + '%"></i></div>']; })) : '') +
      '<p class="note-tr">Deneyin: <a href="#/clusters/BankingCluster/members">BankingCluster</a> üyelerinden birini durdurun ve tekrar "Aynı session ile gönder"e basın (failover). <a href="#/apps/CustomerPortalApp/ctxroot">Context root</a> veya <a href="#/env/vhosts/ib_host/aliases">virtual host alias</a> değiştirerek 404 senaryosu oluşturun. :8443 örneği bilerek tanımsız bir port kullanır.</p></div></div>' +
      '<div class="cards">' +
      '<div class="card"><h4>plugin-cfg.xml ne zaman güncellenmeli?' + W.hi('concept.pluginCfg') + '</h4><p>• Yeni uygulama kurulduğunda/kaldırıldığında<br>• Context root veya virtual host eşlemesi değiştiğinde<br>• Cluster\'a üye eklenip çıkarıldığında, weight değiştiğinde<br>• Sunucu portları (WC_defaulthost) değiştiğinde<br>• Virtual host alias eklendiğinde/silindiğinde<br>• Plug-in özellikleri (timeout, LoadBalance, LogLevel) değiştiğinde</p></div>' +
      '<div class="card"><h4>Generate ve Propagate farkı' + W.hi('plg.genprop') + '</h4><p><b>Generate</b>: DMGR, konfigürasyondan plugin-cfg.xml dosyasını <i>kendi repository\'sinde</i> üretir. <b>Propagate</b>: dosyayı IHS makinesindeki plug-in dizinine kopyalar (managed node ise node sync, unmanaged ise IHS Admin Server ile). Plug-in, dosyayı <b>RefreshInterval</b> (60 sn) sonra yeniden okur – IHS restart gerekmez.</p></div>' +
      '<div class="card"><h4>Mevcut plugin-cfg.xml dosyaları</h4><p>' + W.S.webservers.map(function (w) { return '<a href="#/servers/webservers/' + W.enc(w.name) + '/plugin/view">' + esc(w.name) + ' – plugin-cfg.xml</a> (son üretim: ' + esc(w.lastGenerated) + ')'; }).join('<br>') + '</p></div></div>';
    return { title: 'İstek akışı', help: 'concept.plugin', html: html };
  });
  A.flowPreset = function (el) { W._flow.url = el.dataset.arg; W._flow.steps = null; W._flow.affinity = ''; W.rerender(); };
  function sendOnce(url, aff) {
    var lines = [], active = {}, code = 200;
    active.client = 'ok';
    var m = /^https?:\/\/([^/:]+)/i.exec(url) || [];
    lines.push('<b>Client</b>: DNS <code>' + esc(m[1] || '?') + '</code> → F5 VIP 10.10.0.50. TLS bağlantısı F5 üzerinde sonlanır (SSL offload) veya IHS\'e kadar taşınır.');
    var up = W.S.webservers.filter(function (w) { return W.wsStatus(w) === 'running'; });
    if (!up.length) { lines.push('<span style="color:#c62828"><b>F5</b>: Havuzdaki tüm IHS üyeleri health monitor\'e yanıt vermiyor → istemciye bağlantı hatası / 503.</span>'); active.f5 = 'down'; return { lines: lines, active: active, code: 503 }; }
    W._f5 = (W._f5 || 0) + 1; var ws = up[W._f5 % up.length];
    active.f5 = 'ok'; lines.push('<b>F5 / Load Balancer</b>: Havuz <code>pool_ihs_443</code> (' + W.S.webservers.map(function (w) { return esc(w.name) + (W.wsStatus(w) === 'running' ? '' : ' [DOWN]'); }).join(', ') + ') içinden round robin ile <b>' + esc(ws.name) + '</b> (' + esc(ws.host) + ') seçildi. F5, WAS cluster üyelerini bilmez; yalnızca IHS katmanını dengeler.');
    active.ihs = 'ok'; lines.push('<b>IBM HTTP Server</b> (' + esc(ws.name) + '): İstek mod_was_ap24_http plug-in modülüne verilir (statik içerik IHS\'te sunulabilir).');
    var r = W.routeRequest(url, ws, { affinity: aff });
    r.steps.forEach(function (s, i) { lines.push((i === 0 ? '<b>WebSphere Plug-in</b>: ' : '') + s); });
    active.plugin = r.ok || r.code !== 404 ? 'ok' : 'down';
    if (r.ok) { active.was = 'ok'; active.app = 'ok'; } else { if (r.code === 500) active.was = 'down'; }
    return { lines: lines, active: active, code: r.code, r: r };
  }
  A.flowSend = function (el) {
    var f = W._flow; f.url = document.getElementById('flowUrl').value.trim();
    var res = sendOnce(f.url, el.dataset.arg === 'aff' ? f.affinity : '');
    if (res.r && res.r.ok) f.affinity = res.r.cloneId;
    f.steps = res; f.dist = null; W.rerender();
  };
  A.flowMany = function () {
    var f = W._flow; f.url = document.getElementById('flowUrl').value.trim();
    var c = {}, last = null;
    for (var i = 0; i < 20; i++) { var r = sendOnce(f.url, ''); last = r; var k = r.r && r.r.ok ? r.r.server.name + ' (' + r.r.server.node + ')' : 'HTTP ' + r.code; c[k] = (c[k] || 0) + 1; }
    f.steps = last; f.dist = { c: c, total: 20 }; W.rerender();
  };

  /* -------------------------------------------------------------- cluster sim */
  W._cs = W._cs || {};
  R('/learn/cluster', function (p, q) {
    var c = W.cluster(q.cluster || W.UI.lcCluster || 'BankingCluster') || W.S.clusters[0];
    W.UI.lcCluster = c.name;
    var st = W._cs[c.name] = W._cs[c.name] || { sessions: [], log: [], counts: {} };
    var mode = W.srv(c.members[0].name).session.sessionPersistenceMode;
    var modeTxt = { NONE: 'Kalıcılık yok (session yalnızca o üyenin belleğinde)', DATABASE: 'Database persistence (' + esc(W.srv(c.members[0].name).session.datasourceJNDIName) + ')', DATA_REPLICATION: 'Memory-to-memory replication (domain ' + esc(W.srv(c.members[0].name).session.replicationDomain) + ')' }[mode];
    var grid = c.members.map(function (m) {
      var s = W.srv(m.name), up = W.serverStatus(s) === 'started';
      var prim = st.sessions.filter(function (x) { return x.primary === m.name; }), rep = st.sessions.filter(function (x) { return x.replica === m.name; });
      return '<div class="member' + (up ? '' : ' down') + '"><div class="mh"><a href="#/servers/appservers/' + W.enc(m.name) + '">' + esc(m.name) + '</a>' + W.stIcon(W.serverStatus(s), '') + '</div><div style="font-size:10.5px;color:#555">' + esc(m.node) + ' · weight ' + m.weight + ' · CloneID ' + W.cloneId(s) + '</div><div class="reqs">' + (st.counts[m.name] || 0) + ' <span style="font-size:10px;font-weight:normal">istek</span></div>' +
        '<div>' + prim.map(function (x) { return '<span class="sess prim" title="Primary session">' + x.id + '</span>'; }).join('') + rep.map(function (x) { return '<span class="sess rep" title="Replica (yedek kopya)">' + x.id + '′</span>'; }).join('') + '</div>' +
        '<div class="btnrow" style="margin-top:6px;padding-top:4px">' + (up ? '<button class="btn" data-act="lcCrash" data-arg="' + esc(m.name) + '">Çökert (kill)</button><button class="btn" data-act="srv_stop" data-arg="' + esc(m.name) + '">Stop</button>' : '<button class="btn" data-act="srv_start" data-arg="' + esc(m.name) + '">Start</button>') + '</div></div>';
    }).join('');
    var html = '<div class="page-title">Cluster, WLM, failover ve session replikasyonu' + W.hi('concept.cluster') + '</div>' +
      '<div class="scopebox"><span class="inline-flex" style="gap:8px;flex-wrap:wrap">Cluster: <select data-change="lcCluster">' + W.S.clusters.map(function (x) { return '<option' + (x.name === c.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select> Session kalıcılığı: <b>' + modeTxt + '</b>' + W.hi('sess.distributed') + ' <a href="#/servers/appservers/' + W.enc(c.members[0].name) + '/session/dist">değiştir</a></span></div>' +
      '<p class="desc">Plug-in, yeni istekleri çalışan üyeler arasında <b>weight</b> oranında dağıtır (weighted round robin). Session oluşunca istemci <code>JSESSIONID</code> çerezinde üyenin CloneID\'sini taşır ve sonraki istekler aynı üyeye gider (<b>session affinity</b>). Üye çökerse plug-in onu "down" işaretler ve isteği başka üyeye yollar; session\'ın kurtarılıp kurtarılamayacağı kalıcılık ayarına bağlıdır.' + W.hi('concept.wlm') + '</p>' +
      '<div class="btnrow" style="border:0;margin-top:0"><button class="btn primary" data-act="lcNew" data-arg="10">10 yeni kullanıcı (yeni session)</button><button class="btn" data-act="lcAgain">Mevcut kullanıcılar tekrar istek göndersin</button><button class="btn" data-act="lcReset">Sıfırla</button></div>' +
      '<div class="member-grid">' + grid + '</div>' +
      '<div class="legend"><span style="--c:#8fc79a">Primary session (S1)</span><span style="--c:#b9a3e0">Replica kopyası (S1′)</span></div>' +
      (st.log.length ? '<div class="steps-log"><b>Olay günlüğü</b><ol>' + st.log.slice(-14).map(function (l) { return '<li>' + l + '</li>'; }).join('') + '</ol></div>' : '') +
      '<div class="cards" style="margin-top:12px"><div class="card"><h4>Memory-to-memory replication' + W.hi('concept.m2m') + '</h4><p>Session değişiklikleri DRS ile aynı replication domain\'deki başka bir üyeye kopyalanır (Single replica). Üye çökünce yeni üye, session\'ı replikadan alır; kullanıcı fark etmez. Bellek ve ağ maliyeti vardır.</p></div>' +
      '<div class="card"><h4>Database persistence' + W.hi('sess.database') + '</h4><p>Session her servlet çağrısı sonunda (write frequency) veritabanına yazılır. Failover\'da yeni üye session\'ı DB\'den okur. DB yükü ve gecikme ekler.</p></div>' +
      '<div class="card"><h4>Kalıcılık yok' + W.hi('sess.distributed') + '</h4><p>Üye çökerse üzerindeki tüm session\'lar kaybolur; kullanıcılar yeniden giriş yapmak zorunda kalır (sepet/form verisi kaybolur).</p></div>' +
      '<div class="card"><h4>EJB WLM ve diğerleri' + W.hi('concept.wlm') + '</h4><p>IIOP üzerinden EJB çağrıları da WLM ile cluster üyelerine dağıtılır (prefer local açıkken aynı node\'daki üye tercih edilir). Messaging engine ve transaction recovery ise HA Manager ile tek üyede aktif tutulur.</p></div></div>';
    return { title: 'Cluster ve failover', help: 'concept.wlm', html: html };
  });
  W.onChange.lcCluster = function (e) { W.UI.lcCluster = e.value; location.hash = '#/learn/cluster?cluster=' + W.enc(e.value); };
  function lcState() { var c = W.cluster(W.UI.lcCluster); return { c: c, st: W._cs[c.name], mode: W.srv(c.members[0].name).session.sessionPersistenceMode }; }
  function pickMember(c) {
    var up = c.members.filter(function (m) { return W.serverStatus(m.name) === 'started' && m.weight > 0; });
    if (!up.length) return null;
    var bag = []; up.forEach(function (m) { for (var i = 0; i < m.weight; i++) bag.push(m.name); });
    W._lcRR = (W._lcRR || 0) + 1; return bag[W._lcRR % bag.length];
  }
  function pickReplica(c, prim) { var o = c.members.filter(function (m) { return m.name !== prim && W.serverStatus(m.name) === 'started'; }); return o.length ? o[Math.floor(Math.random() * o.length)].name : null; }
  A.lcNew = function (el) {
    var x = lcState(), n = +el.dataset.arg;
    for (var i = 0; i < n; i++) {
      var m = pickMember(x.c);
      if (!m) { x.st.log.push('<span style="color:#c62828">Çalışan üye yok → HTTP 500/503.</span>'); break; }
      var id = 'S' + (x.st.sessions.length + 1);
      x.st.sessions.push({ id: id, primary: m, replica: x.mode === 'DATA_REPLICATION' ? pickReplica(x.c, m) : null });
      x.st.counts[m] = (x.st.counts[m] || 0) + 1;
    }
    x.st.log.push(n + ' yeni kullanıcı weighted round robin ile dağıtıldı.'); W.rerender();
  };
  A.lcAgain = function () {
    var x = lcState(), lost = 0, moved = 0, ok = 0;
    x.st.sessions.forEach(function (s) {
      if (W.serverStatus(s.primary) === 'started') { ok++; x.st.counts[s.primary] = (x.st.counts[s.primary] || 0) + 1; return; }
      var nm = pickMember(x.c);
      if (!nm) { lost++; return; }
      var old = s.primary;
      if (x.mode === 'DATA_REPLICATION') {
        if (s.replica && W.serverStatus(s.replica) === 'started') { nm = s.replica; s.primary = nm; s.replica = pickReplica(x.c, nm); moved++; x.st.log.push(s.id + ': ' + old + ' down → plug-in isteği ' + nm + '\'e yönlendirdi; session <b>replikadan kurtarıldı</b> (kullanıcı oturumda kalır).'); }
        else { s.primary = nm; lost++; x.st.log.push('<span style="color:#c62828">' + s.id + ': hem primary hem replika erişilemez → session kayboldu.</span>'); }
      } else if (x.mode === 'DATABASE') { s.primary = nm; moved++; x.st.log.push(s.id + ': ' + old + ' down → ' + nm + ' session\'ı <b>veritabanından okudu</b> (kullanıcı oturumda kalır).'); }
      else { s.primary = nm; lost++; x.st.log.push('<span style="color:#c62828">' + s.id + ': ' + old + ' down → ' + nm + '\'e yönlendirildi ama session <b>kayboldu</b>; kullanıcı yeniden giriş yapmalı.</span>'); }
      x.st.counts[nm] = (x.st.counts[nm] || 0) + 1;
    });
    x.st.log.push('Özet: ' + ok + ' istek kendi üyesinde (affinity), ' + moved + ' failover ile kurtarıldı, ' + lost + ' session kaybı.'); W.rerender();
  };
  A.lcCrash = function (el) {
    var n = el.dataset.arg; W.RT.servers[n] = 'stopped'; W.saveRT();
    var x = lcState(); x.st.log.push('<b>' + esc(n) + ' çöktü</b> (kill -9 simülasyonu). Node agent monitoring policy\'ye göre yeniden başlatmayı deneyebilir; plug-in ilk başarısız bağlantıda üyeyi RetryInterval süresince down işaretler.');
    W.cmd('Sunucu süreci sonlandırıldı (simülasyon)', ['# kill -9 <pid>  (' + n + ')', "AdminControl.stopServer('" + n + "', '" + W.srv(n).node + "', 'terminate')"]);
    W.rerender();
  };
  A.lcReset = function () { var x = lcState(); W._cs[x.c.name] = { sessions: [], log: [], counts: {} }; W.rerender(); };

  /* ------------------------------------------------------------ scope */
  R('/learn/scope', function () {
    var rows = [
      ['WebSphere variables', '✔', '✔', '✔', '✔', '', 'concept.wasVariable'], ['JDBC provider / Data source', '✔', '✔', '✔', '✔', '', 'concept.datasource'], ['JMS kaynakları (CF, queue, AS)', '✔', '✔', '✔', '✔', '', 'concept.jmsProvider'],
      ['Shared library', '✔', '✔', '✔', '✔', 'referans', 'concept.sharedLib'], ['Virtual host', '✔', '', '', '', 'eşleme', 'concept.vhost'], ['J2C authentication alias', '✔ (global)', '', '', '', '', 'sec.authAlias'],
      ['Global security / user registry', '✔', '', '', '', '', 'concept.security'], ['Security domain', '', '', '✔', '✔', '', 'sec.domains'], ['SSL configuration', '✔', '✔', '✔', '✔', '', 'concept.ssl'],
      ['JVM (heap, argümanlar)', '', '', '', '✔', '', 'concept.jvm'], ['Thread pool', '', '', '', '✔', '', 'concept.threadPool'], ['Ports', '', '', '', '✔', '', 'srv.ports'], ['Transaction service', '', '', '', '✔', '', 'tx.service'],
      ['Session management', '', '', '', '✔', '✔ (override)', 'concept.session'], ['Class loader modu', '', '', '', '✔', '✔', 'concept.classloader'], ['PMI / trace / log', '', '', '', '✔', '', 'concept.pmi'],
      ['Cluster (weight, prefer local)', '', '', '✔', '', '', 'concept.cluster'], ['Node agent / file sync', '', '✔', '', '', '', 'concept.nodeAgent'], ['Request metrics', '✔', '', '', '', '', 'mon.rm']
    ];
    var html = '<div class="page-title">Yapılandırma seviyeleri (scope)' + W.hi('concept.scope') + '</div><p class="desc">IBM WAS\'ta her ayarın tanımlanabildiği belirli seviyeler vardır. Kaynaklar (JDBC, JMS, variables, shared libraries) birden fazla seviyede tanımlanabilir; bir sunucu, kendisini kapsayan tüm seviyelerdeki kaynakları görür ve aynı JNDI adı/değişken adı çakışırsa <b>en özel olan kazanır</b>.</p>' +
      '<div class="flow" style="flex-wrap:wrap"><div class="fb" data-help="concept.cell"><b>Cell</b><small>tüm hücre</small></div><div class="fa">⊃</div><div class="fb" data-help="concept.node"><b>Node</b><small>tek makine/profil</small></div><div class="fa">⊃</div><div class="fb" data-help="concept.appserver"><b>Server</b><small>tek JVM</small></div><div class="fa">·</div><div class="fb" data-help="concept.cluster"><b>Cluster</b><small>node\'ları keser; üyelerini kapsar</small></div><div class="fa">→</div><div class="fb" data-help="concept.enterpriseApp"><b>Application</b><small>uygulamaya özel geçersiz kılma</small></div></div>' +
      '<div class="note-tr">Öncelik (en yüksekten düşüğe): <b>Server → Cluster → Node → Cell</b>. Örnek: <code>jdbc/CoreBankDS</code> hem Cell hem Cluster=BankingCluster seviyesinde tanımlı olsaydı, BankingCluster üyeleri cluster seviyesindekini kullanırdı. <a href="#/env/variables">WebSphere variables</a> sayfasındaki değişken çözümleyiciyi deneyin.</div>' +
      W.simpleTable(['Ayar / kaynak', 'Cell', 'Node', 'Cluster', 'Server', 'Application', ''], rows.map(function (r) { return [esc(r[0]), r[1], r[2], r[3], r[4], esc(r[5]), W.hi(r[6])]; })) +
      '<div class="cards" style="margin-top:12px"><div class="card"><h4>Cluster seviyesinin özelliği' + W.hi('concept.cluster') + '</h4><p>Cluster scope\'ta tanımlanan bir data source, cluster\'ın <b>tüm üyelerinde</b> (farklı node\'larda olsalar da) görünür. Yeni üye eklendiğinde otomatik olarak kullanılabilir. Üye-bağımsız uygulamalar için en doğru seviye genellikle budur.</p></div>' +
      '<div class="card"><h4>Node seviyesi ve sürücü yolları' + W.hi('concept.wasVariable') + '</h4><p><code>ORACLE_JDBC_DRIVER_PATH</code> gibi değişkenler node\'a özgü dosya yollarını tutar. JDBC provider Cell seviyesinde olsa bile sınıf yolu her node\'da o node\'un değişken değeriyle çözülür. Bir node\'da değişken eksikse test connection ClassNotFoundException verir.</p></div>' +
      '<div class="card"><h4>Server seviyesi' + W.hi('concept.appserver') + '</h4><p>JVM, thread pool, port, transaction service ve log ayarları yalnızca sunucu seviyesindedir; cluster üyelerinin her biri ayrı ayrı yapılandırılır (veya şablon/wsadmin ile toplu değiştirilir).</p></div></div>';
    return { title: 'Yapılandırma seviyeleri', help: 'concept.scope', html: html };
  });

  /* ------------------------------------------------- hata senaryoları */
  var SCEN = [
    ['OutOfMemoryError – heap tükendi', 'Uygulama yavaşlar, sonra yanıt vermez; sunucu yeniden başlar.', 'native_stderr.log / SystemErr.log', 'JVMDUMP039I Processing dump event "systhrow", detail "java/lang/OutOfMemoryError" at 2026/11/23 10:42:18 - please wait.\nJVMDUMP032I JVM requested Heap dump using \'/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/heapdump.20261123.104218.41337.0001.phd\' in response to an event\nJVMDUMP010I Java dump written to /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/javacore.20261123.104218.41337.0002.txt\n[11/23/26 10:42:19:004 TRT] 00000123 SystemErr     R java.lang.OutOfMemoryError: Java heap space', 'Bellek sızıntısı (session\'da büyük nesneler, statik cache) veya maximum heap\'in yükte yetersiz kalması.', 'Verbose GC ile heap kullanım eğilimini inceleyin; heapdump (.phd) dosyasını IBM Memory Analyzer (MAT) ile analiz edin. Sızıntı yoksa maximum heap\'i artırın (fiziksel belleği aşmadan). Session nesnelerini küçültün.', '#/servers/appservers/BankSrv01/jvm', 'jvm.maxHeap'],
    ['Hung thread – WSVR0605W', 'Bazı istekler dakikalarca yanıt vermez; WebContainer thread\'leri tükenir.', 'SystemOut.log', 'WSVR0605W: Thread "WebContainer : 37" (00000123) has been active for 612345 milliseconds and may be hung.  There is/are 1 thread(s) in total in the server that may be hung.\n\tat java.net.SocketInputStream.socketRead0(Native Method)\n\tat oracle.jdbc.driver.T4CPreparedStatement.executeForDescribe(...)', 'Thread, yanıt vermeyen bir dış sisteme (DB, web servisi) bağlı bekliyor; kilit (lock) veya sonsuz döngü.', 'Stack trace\'te beklenen kaynağı bulun; birkaç dakika arayla 3 javacore alıp karşılaştırın (<code>kill -3 &lt;pid&gt;</code>). JDBC/HTTP istemcilerine timeout tanımlayın. Hung thread eşiği: com.ibm.websphere.threadmonitor.threshold.', '#/tr/logs/BankSrv02/view?file=SystemOut.log', 'mon.threads'],
    ['Connection pool tükendi – J2CA0045E', '"Connection not available" hataları; yanıt süreleri connection timeout (180 sn) kadar uzar.', 'SystemOut.log, FFDC', 'J2CA0045E: Connection not available while invoking method createOrWaitForConnection for resource jdbc/CoreBankDS.\ncom.ibm.websphere.ce.cm.ConnectionWaitTimeoutException: Connection not available, Timed out waiting for 180003', 'Maximum connections yetersiz, bağlantılar uygulama tarafından kapatılmıyor (leak) veya SQL\'ler çok yavaş.', 'TPV\'de JDBC PoolSize/WaitingThreadCount/UseTime değerlerini izleyin. Kodda finally/try-with-resources ile close() yapıldığını doğrulayın. Gerekirse Maximum connections ve DB oturum limitini birlikte artırın.', '#/res/jdbc/ds/d1/pool', 'concept.connectionPool'],
    ['404 – SRVE0255E (WebGroup/Virtual Host tanımsız)', 'Uygulama çalışıyor görünür ama URL 404 döner.', 'SystemOut.log', 'SRVE0255E: A WebGroup/Virtual Host to handle /portall/home has not been defined.\nSRVE0255E: A WebGroup/Virtual Host to handle ib.ornekbank.com.tr:8443 has not been defined.', 'Yanlış context root, uygulama başlamamış ya da gelen Host:port, web modülünün virtual host alias listesinde yok.', 'Uygulamanın context root ve virtual host eşlemesini kontrol edin; gerekiyorsa virtual host\'a alias ekleyin. Değişiklikten sonra plug-in\'i yeniden üretip yayın.', '#/env/vhosts', 'concept.vhost'],
    ['Plug-in yönlendirmiyor – plugin-cfg.xml güncel değil', 'Yeni kurulan uygulama doğrudan sunucu portundan (9080) açılır, ama web server üzerinden 404 verir; ya da yeni cluster üyesine hiç trafik gelmez.', 'http_plugin.log, IHS access_log', 'STATS: ws_server_group: serverGroupCheckServerStatus: Checking status of AppNode01_BankSrv01, ignoreWeights 0, markedDown 0, retryNow 0\n(Yeni uygulamanın URI\'si için UriGroup eşleşmesi yok → istek IHS DocumentRoot\'a düşer → 404)', 'Uygulama web server\'a eşlenmemiş ya da Generate/Propagate yapılmamış; otomatik üretim/yayma kapalı.', 'Uygulamanın Manage Modules ekranında web server\'ı hedef olarak seçin, ardından Generate Plug-in ve Propagate Plug-in yapın. RefreshInterval sonunda plug-in yeni dosyayı okur.', '#/servers/webservers', 'concept.pluginCfg'],
    ['Tüm cluster üyeleri down – HTTP 500', 'Web server ayakta ama tüm istekler 500 döner.', 'http_plugin.log', 'ERROR: ws_common: websphereGetStream: Failed to connect to app server on host \'was-app01.corp.local\', OS err=111\nERROR: ws_server: serverSetFailoverStatus: Marking AppNode01_BankSrv01 down\nERROR: ws_common: websphereFindServer: Failed to find a server\nERROR: ESI: getResponse: failed to get response: rc = 2', 'Cluster üyeleri durmuş, portlar güvenlik duvarında kapalı veya plugin-cfg.xml\'deki host/port yanlış.', 'Sunucu durumlarını kontrol edin; IHS makinesinden <code>curl http://was-app01.corp.local:9080/</code> ile erişimi test edin. Transport port\'larının sunucu WC_defaulthost portlarıyla eşleştiğini doğrulayın.', '#/clusters/BankingCluster/members', 'concept.plugin'],
    ['SSL handshake hatası – CWPKI0022E', 'LDAP, veritabanı veya dış servise SSL bağlantısı kurulamaz.', 'SystemOut.log', 'CWPKI0022E: SSL HANDSHAKE FAILURE:  A signer with SubjectDN CN=api.partnerbank.com.tr was sent from the target host. The signer might need to be added to local trust store /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/config/cells/WASPRODCell01/trust.p12 ...', 'Karşı tarafın sertifikasını imzalayan CA, WAS trust store\'unda yok ya da protokol/cipher uyumsuzluğu (ör. karşı taraf yalnızca TLS 1.3).', 'Signer certificates → Retrieve from port ile CA sertifikasını ekleyin; SSL configuration\'da protokolü kontrol edin.', '#/sec/ssl/keystores/CellDefaultTrustStore/signer', 'ssl.signer'],
    ['LDAP erişilemiyor – konsola/uygulamaya giriş yapılamıyor', 'Tüm kullanıcı girişleri başarısız; konsola wasadmin dışında giriş yapılamaz.', 'SystemOut.log', 'CWWIM4520E The \'javax.naming.CommunicationException: ldap01.corp.local:636 [Root exception is java.net.ConnectException: Connection timed out]\' naming exception occurred during processing.\nSECJ0369E: Authentication failed when using LTPA. The exception is com.ibm.websphere.wim.exception.WIMSystemException', 'LDAP sunucusu kapalı, ağ erişimi yok veya bind kullanıcısının parolası değişmiş/süresi dolmuş.', 'Failover LDAP host tanımlayın; bind DN parolasını güncelleyin. Acil durum için dosya tabanlı repository\'de admin hesabı bulundurun. "Allow operations if some repositories are down" seçeneğini değerlendirin.', '#/sec/global/federated/CorpAD', 'sec.ldap'],
    ['Sunucu başlamıyor – port çakışması', 'startServer ADMU3011E ile biter; SystemOut\'ta kanal hatası.', 'startServer.log, SystemOut.log', 'ADMU3011E: Server launched but failed initialization. startServer.log, SystemOut.log(or job log in zOS) and other log files under /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/BankSrv04 should contain failure information.\nCHFW0029E: Error starting chain WCInboundDefault because of exception com.ibm.wsspi.channelfw.exception.ChainException: com.ibm.wsspi.channelfw.exception.ChannelException: TCP Channel TCP_2 initialization failed.  The socket bind failed for host * and port 9080.  The port may already be in use.', 'Sunucu "Generate unique ports" seçilmeden oluşturulmuş veya başka bir süreç aynı portu kullanıyor.', 'Server > Ports sayfasında çakışan portu değiştirin; virtual host alias ve plug-in yapılandırmasını güncelleyin. <code>netstat -anp | grep 9080</code> ile portu kullanan süreci bulun.', '#/servers/appservers/BankSrv01/ports', 'srv.ports'],
    ['Node senkronize değil', 'Konsolda yapılan değişiklik o node\'daki sunucularda etkili olmaz.', 'nodeagent SystemOut.log', 'ADMS0005E: The system is unable to generate synchronization request: javax.management.JMRuntimeException: ADMN0022E: Access is denied for the getRepositoryEpoch operation ...\n(veya) ADMS0015E: The synchronization request cannot be completed because the node agent cannot communicate with the deployment manager.', 'Node agent kapalı, DMGR\'ye ağ erişimi yok, ya da güvenlik/SSL uyumsuzluğu.', 'Nodes sayfasında Synchronize / Full Resynchronize deneyin. Node agent kapalıysa host üzerinde startNode.sh çalıştırın. Gerekirse <code>syncNode.sh was-dmgr01.corp.local 8879</code> (node agent durdurulmuşken) kullanın.', '#/sys/nodes', 'sys.sync'],
    ['CPU starvation – HMGR0152W', 'Rastgele duraklamalar, core group üyelikten düşme, failover tetiklenmesi.', 'SystemOut.log', 'HMGR0152W: CPU Starvation detected. Current thread scheduling delay is 34 seconds.\nDCSV1115W: DCS Stack DefaultCoreGroup at Member ...: Member ... suspected of failure.', 'Makinede CPU doygunluğu, uzun GC duraklamaları, sanal makinede CPU steal veya swap.', 'Verbose GC ile uzun duraklamaları kontrol edin; heap ve GC politikasını ayarlayın; aynı makinedeki JVM sayısını azaltın; hipervizör kaynaklarını inceleyin.', '#/mon/tpv?server=BankSrv03', 'mon.cpu'],
    ['ClassNotFoundException / NoSuchMethodError', 'Uygulama başlarken veya belirli bir işlevde sınıf/method bulunamaz.', 'SystemOut.log, SystemErr.log', 'java.lang.NoSuchMethodError: com/fasterxml/jackson/databind/ObjectMapper.readerFor(Ljava/lang/Class;)Lcom/fasterxml/jackson/databind/ObjectReader; (loaded from file:/opt/IBM/WebSphere/AppServer/plugins/com.ibm.ws.jaxrs.jar by org.eclipse.osgi...)', 'Uygulama ile WAS runtime farklı sürümde aynı kütüphaneyi içeriyor; PARENT_FIRST modunda WAS\'ın eski sürümü önce yükleniyor. Ya da shared library hedefin scope\'unda değil.', 'Class loader viewer ile sınıfın nereden yüklendiğini bulun. Uygulamayı PARENT_LAST yapın veya izole (isolated) shared library kullanın.', '#/tr/classloader?server=BankSrv01', 'concept.classloader'],
    ['Failover sonrası kullanıcılar oturumdan düşüyor', 'Bir cluster üyesi yeniden başlatıldığında o üyedeki kullanıcılar login ekranına döner.', 'SystemOut.log', 'SESN0008E: A user authenticated as anonymous has attempted to access a session owned by user:corp.local/zkaya.\n(veya yeni üyede session bulunamadığı için yeni session oluşturulur)', 'Distributed session (database veya memory-to-memory) yapılandırılmamış; ya da security integration ile LTPA token süresi dolmuş.', 'Cluster üyelerinde Distributed environment settings ile replication veya database persistence etkinleştirin; LTPA timeout ve session timeout değerlerini uyumlu hale getirin.', '#/learn/cluster', 'sess.distributed'],
    ['Transaction timeout – WTRN0006W', 'Uzun süren işlemler rollback olur; "transaction has timed out" hataları.', 'SystemOut.log', 'WTRN0006W: Transaction 00000172E6B9A21C0000000100000003... has timed out after 120 seconds.\nWTRN0124I: When the timeout occurred the thread with which the transaction is, or was most recently, associated was Thread[WebContainer : 12,5,main].', 'İşlem Total transaction lifetime timeout (120 sn) değerini aşıyor: yavaş SQL, kilit bekleme veya toplu (batch) işlemin tek transaction\'da yapılması.', 'SQL ve kilitleri inceleyin; batch işlemleri parçalara bölün; gerekiyorsa sadece ilgili sunucuda timeout\'u artırın (BatchSrv01 örneğinde 1800 sn).', '#/servers/appservers/BankSrv01/tx', 'tx.totalLifetime']
  ];
  R('/learn/troubleshooting', function () {
    var files = [['SystemOut.log', 'Sunucunun ana mesaj günlüğü: başlangıç/durma, uygulama başlatma, WAS bileşen mesajları (I/A/W/E), System.out çıktısı. İlk bakılacak yer.', 'log.systemout'], ['SystemErr.log', 'System.err çıktısı ve yakalanmamış exception stack trace\'leri.', 'log.systemerr'], ['native_stdout.log / native_stderr.log', 'JVM native çıktısı: verbose GC (stderr), JVM dump mesajları (JVMDUMP), native kütüphane ve JNI hataları. Sunucu hiç başlamıyorsa veya JVM çöküyorsa bakılır.', 'log.native'], ['FFDC (logs/ffdc)', 'First Failure Data Capture: WAS\'ın beklenmedik exception\'ları ilk oluştuğunda otomatik kaydettiği ayrıntılı dosyalar; IBM Support için değerlidir.', 'log.ffdc'], ['trace.log', 'Diagnostic trace etkinleştirildiğinde bileşen bazında ayrıntılı iz. Yalnızca sorun ararken ve hedefli açılır.', 'log.trace'], ['startServer.log / stopServer.log', 'startServer.sh/stopServer.sh araçlarının çıktısı; sunucu başlatılamadığında (ADMU3011E vb.) ilk bakılacak dosya.', 'log.startstop'], ['javacore / heapdump / core dump', 'Thread dump (javacore.*.txt), heap dump (.phd) ve sistem dump. Hung thread, kilitlenme ve OutOfMemory analizi için.', 'log.dumps'], ['http_plugin.log (IHS makinesi)', 'Plug-in yönlendirme hataları, sunucuların down işaretlenmesi, SSL sorunları.', 'plg.log'], ['IHS access_log / error_log', 'Web server erişim kayıtları (HTTP durum kodları, süre) ve IHS hataları.', 'ws.logs']];
    var html = '<div class="page-title">Log dosyaları ve hata senaryoları' + W.hi('concept.logs') + '</div><p class="desc">Hangi log dosyasına ne zaman bakılmalı? Aşağıda dosya türleri ve gerçek hayatta sık karşılaşılan IBM WAS hata senaryoları, örnek log satırları, kök nedenler ve çözüm adımlarıyla listelenmiştir. Simülasyondaki sunucuların logları için <a href="#/tr/logs">Logs and trace</a> sayfasını kullanın.</p>' +
      W.simpleTable(['Dosya', 'İçerik / ne zaman bakılır', ''], files.map(function (f) { return ['<b>' + esc(f[0]) + '</b>', esc(f[1]), W.hi(f[2])]; })) +
      '<div class="note-tr">Log satırı formatı: <code>[zaman damgası] ThreadID KısaBileşenAdı Seviye MesajID: mesaj</code>. Seviyeler: <b>F</b> fatal, <b>E</b> error, <b>W</b> warning, <b>A</b> audit, <b>I</b> info, <b>C</b> config, <b>D</b> detail, <b>O</b> System.out, <b>R</b> System.err. Mesaj ID sonundaki harf de önem derecesini belirtir (ör. WSVR0605<b>W</b>).' + W.hi('log.format') + '</div>' +
      '<div class="sect-title" style="margin-top:14px">Yaygın hata senaryoları</div>' +
      SCEN.map(function (s, i) { return '<div class="scen' + (i === 0 ? ' open' : '') + '"><div class="sh" data-act="scenToggle"><span>' + (i + 1) + '. ' + esc(s[0]) + '</span><span>▾</span></div><div class="sb"><p><b>Belirti:</b> ' + esc(s[1]) + '</p><p><b>Bakılacak log:</b> ' + esc(s[2]) + '</p><pre class="log">' + W.colorLog(s[3]) + '</pre><p><b>Olası kök neden:</b> ' + esc(s[4]) + '</p><p><b>Çözüm:</b> ' + s[5] + '</p><p><a href="' + s[6] + '">→ İlgili konsol sayfası</a> ' + W.hi(s[7]) + '</p></div></div>'; }).join('');
    return { title: 'Log ve hata senaryoları', help: 'concept.logs', html: html };
  });
  A.scenToggle = function (el) { el.parentNode.classList.toggle('open'); };

  /* ------------------------------------------------------------ glossary */
  R('/learn/glossary', function () {
    var keys = Object.keys(W.HELP).sort(function (a, b) { return W.HELP[a].t.localeCompare(W.HELP[b].t, 'tr'); });
    var rows = keys.map(function (k) { var h = W.HELP[k]; return { id: k, t: h.t.replace(/<[^>]+>/g, ''), scope: (h.scope || '').replace(/<[^>]+>/g, ''), what: (h.what || '').replace(/<[^>]+>/g, '').slice(0, 170) + ((h.what || '').length > 170 ? '…' : '') }; });
    return { title: 'Kavram sözlüğü', help: 'concept.was', html: '<div class="page-title">Kavram sözlüğü (' + rows.length + ' kavram)</div><p class="desc">Konsoldaki tüm açıklamaların listesi. Filtre simgesiyle arama yapabilir, başlığa tıklayarak ayrıntılı açıklamayı açabilirsiniz. Sol üstteki arama kutusu da hem menüde hem bu sözlükte arar.</p>' +
      W.table({ id: 'gloss', select: false, rows: rows, cols: [{ k: 't', l: 'Kavram', fmt: function (r) { return '<a data-help-link="' + esc(r.id) + '">' + esc(r.t) + '</a>'; } }, { k: 'scope', l: 'Seviye' }, { k: 'what', l: 'Kısa açıklama' }] }) };
  });

  /* ------------------------------------------------- guided activities */
  function guide(title, intro, steps, help) {
    return { title: title, help: help, html: '<div class="page-title">' + esc(title) + W.hi(help) + '</div><p class="desc">' + intro + '</p>' + steps.map(function (s, i) {
      return '<div class="portlet"><div class="ph"><span>Step ' + (i + 1) + ': ' + esc(s[0]) + '</span></div><div class="pb"><p>' + s[1] + '</p><div class="inline-flex" style="gap:12px;flex-wrap:wrap"><a href="' + s[2] + '">Click to perform</a><a data-help="' + s[3] + '">Learn more</a></div></div></div>';
    }).join('') };
  }
  R('/guided/database', function () {
    return guide('Connecting to a database', 'Bu rehberli etkinlik, bir uygulamanın veritabanına erişebilmesi için gereken WAS kaynaklarını doğru sırayla oluşturmanızı sağlar.', [
      ['Configure credentials for secure database access', 'Veritabanı kullanıcı adı/parolasını bir <b>J2C authentication alias</b> olarak tanımlayın. Parolayı uygulama koduna veya data source URL\'sine yazmayın.', '#/sec/jaas/j2c', 'sec.authAlias'],
      ['Create a JDBC provider', 'Veritabanı tipine uygun JDBC provider\'ı oluşturun (Oracle, DB2, SQL Server...). Kapsamı (scope) uygulamanın çalışacağı cluster olarak seçmek genellikle en doğrusudur. XA gerekiyorsa XA implementasyonunu seçin.', '#/res/jdbc/providers', 'concept.jdbcProvider'],
      ['Verify the WebSphere variable for the driver path', 'Provider class path\'indeki <code>${..._DRIVER_PATH}</code> değişkeninin, cluster üyelerinin bulunduğu <b>her node</b>\'da doğru dizine işaret ettiğini kontrol edin.', '#/env/variables', 'concept.wasVariable'],
      ['Create a data source', 'Data source\'u JNDI adıyla (ör. jdbc/LoanDS) oluşturun, URL/sunucu bilgilerini ve authentication alias\'ı seçin.', '#/wz/createDS', 'concept.datasource'],
      ['Tune the connection pool', 'Maximum/minimum connections, timeout değerlerini beklenen yüke göre ayarlayın.', '#/res/jdbc/ds', 'concept.connectionPool'],
      ['Save and test the connection', 'Değişiklikleri kaydedip node\'ları senkronize edin, ardından <b>Test connection</b> ile doğrulayın.', '#/save', 'concept.workspace'],
      ['Map the application resource reference', 'Uygulamanın <code>res-ref</code> referansını kurulumda veya sonrasında bu JNDI adına bağlayın.', '#/apps/CoreBankingApp/resrefs', 'app.resrefs']
    ], 'concept.datasource');
  });
  R('/guided/webserver', function () {
    return guide('Routing requests through a Web server to an application server', 'IBM HTTP Server önünde çalışan WAS uygulamalarına istek yönlendirmek için gerekli adımlar.', [
      ['Install IBM HTTP Server and the Web Server Plug-in', 'IHS ve WebSphere Plug-in, IBM Installation Manager ile kurulur. Ardından <b>WebSphere Customization Toolbox (WCT)</b> ile plug-in yapılandırılır: httpd.conf\'a <code>LoadModule was_ap24_module</code> ve <code>WebSpherePluginConfig</code> satırları eklenir ve DMGR\'de web server tanımını oluşturan <code>configurewebserver1.sh</code> betiği üretilir.', '#/servers/webservers/webserver1/conf', 'concept.ihs'],
      ['Create the Web server definition', 'configurewebserver betiği çalıştırılarak veya konsoldan web server tanımı (unmanaged node üzerinde) oluşturulur.', '#/wz/createWebServer', 'concept.webserver'],
      ['Map the applications to the Web server', 'Uygulamanın web modüllerini hem cluster\'a hem web server\'a eşleyin.', '#/apps/CoreBankingApp/modules', 'ws.appMapping'],
      ['Check virtual host aliases', 'Kullanıcıların kullanacağı host adı ve portun (ör. *:443) web modülünün virtual host\'unda tanımlı olduğunu kontrol edin.', '#/env/vhosts', 'concept.vhost'],
      ['Generate the plug-in configuration', 'DMGR plugin-cfg.xml dosyasını üretir.', '#/servers/webservers', 'plg.genprop'],
      ['Propagate the plug-in configuration', 'Üretilen dosyayı IHS makinesine kopyalayın; plug-in RefreshInterval sonrası yeni dosyayı okur.', '#/servers/webservers', 'plg.genprop'],
      ['Test the request flow', 'URL\'yi web server üzerinden çağırın ve isteğin doğru cluster üyesine gittiğini doğrulayın.', '#/learn/requestflow', 'concept.plugin']
    ], 'concept.plugin');
  });
})();
