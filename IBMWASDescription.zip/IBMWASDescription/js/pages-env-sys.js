/* pages-env-sys.js – Environment (virtual hosts, variables, shared libraries,
   replication domains, naming, global plug-in) ve System administration
   (cell, DMGR, nodes, node agents, node groups, job manager, console). */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };

  /* ---------------------------------------------------------- virtual hosts */
  W.resType({ id: 'vhost', coll: 'virtualHosts', path: '/env/vhosts', title: 'Virtual Hosts', singular: 'Virtual host', help: 'concept.vhost', scoped: false, cfgType: 'VirtualHost', file: 'virtualhosts.xml',
    desc: 'Use this page to create a virtual host with a logical name and to configure the virtual host. A virtual host has a logical name and a list of one or more DNS aliases by which it is known.',
    note: 'Virtual host, hücre (Cell) seviyesinde tanımlanır. Web modülleri kurulum sırasında bir virtual host\'a eşlenir; gelen isteğin <b>Host:port</b> değeri bu virtual host\'un alias listesinde yoksa web container isteği reddeder (<i>SRVE0255E: A WebGroup/Virtual Host to handle /x has not been defined</i>) ve plug-in isteği yönlendirmez.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'a', l: 'Host aliases', fmt: function (r) { return esc(r.aliases.map(function (a) { return a[0] + ':' + a[1]; }).join(', ')); } }],
    defaults: function () { return { name: '', aliases: [], mimeCount: 116 }; },
    form: function (o, isNew) { return isNew ? F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'concept.vhost' }) : F.ro({ l: 'Name', v: o.name, h: 'concept.vhost' }) + F.ro({ l: 'Used by', v: W.S.apps.filter(function (a) { return a.modules.some(function (m) { return m.vhost === o.name; }); }).map(function (a) { return W.appLink(a.name); }).join(', ') || '(no web modules)', raw: true }); },
    ap: function (o) { return [{ t: 'Additional Properties', items: [{ l: 'Host Aliases', href: '#/env/vhosts/' + W.enc(o.name) + '/aliases', h: 'vh.alias' }, { l: 'MIME Types (' + o.mimeCount + ')', act: 'notInSim', arg: 'MIME Types', h: 'vh.mime' }] }]; },
    canDelete: function (o) { if (/^(default_host|admin_host)$/.test(o.name)) return o.name + ' sistem tarafından kullanılır; silinmemelidir.'; var u = W.S.apps.filter(function (a) { return a.modules.some(function (m) { return m.vhost === o.name; }); }); if (u.length) return esc(o.name) + ' silinemedi: ' + u.map(function (a) { return esc(a.name); }).join(', ') + ' tarafından kullanılıyor.'; },
    createCmd: function (o) { return ["AdminConfig.create('VirtualHost', AdminConfig.getid('/Cell:" + CELL() + "/'), [['name', '" + o.name + "']])", 'AdminConfig.save()']; } });
  R('/env/vhosts/:name/aliases', function (p) {
    var v = W.by(W.S.virtualHosts, 'name', p.name);
    return { title: 'Virtual Hosts', help: 'vh.alias', html: W.crumbs([['Virtual Hosts', '#/env/vhosts'], [v.name, '#/env/vhosts/' + W.enc(v.name)], 'Host Aliases']) + '<p class="desc">Use this page to edit the host aliases for this virtual host. "*" tüm host adlarıyla eşleşir. Alias değişikliğinden sonra uygulama sunucusunun yeni alias\'ı görmesi için kaydedin; web server için plug-in yapılandırmasını yeniden üretip yayın.' + W.hi('vh.alias') + '</p>' +
      W.table({ id: 'alias', sig: v.name, rows: v.aliases.map(function (a, i) { return { id: String(i), host: a[0], port: a[1] }; }), cols: [{ k: 'host', l: 'Host Name' }, { k: 'port', l: 'Port' }], buttons: [{ l: 'New...', act: 'aliasNew', arg: v.name }, { l: 'Delete', act: 'aliasDel', arg: v.name, need: 1 }] }) };
  });
  A.aliasNew = function (el) {
    W.modal({ title: 'New host alias – ' + el.dataset.arg, html: '<form id="alF" onsubmit="return false">' + F.text({ l: 'Host Name', n: 'host', v: '*', req: true, h: 'vh.alias' }) + F.num({ l: 'Port', n: 'port', v: 80, h: 'vh.alias' }) + '</form>', buttons: [{ l: 'OK', fn: function () {
      var r = W.readForm(document.getElementById('alF')).vals, v = W.by(W.S.virtualHosts, 'name', el.dataset.arg);
      if (v.aliases.some(function (a) { return a[0] === r.host && +a[1] === +r.port; })) { alert('Bu alias zaten var.'); return false; }
      v.aliases.push([r.host, +r.port]); W.change('cells/' + CELL() + '/virtualhosts.xml', 'Host alias eklendi: ' + v.name + ' ' + r.host + ':' + r.port);
      W.cmd('Host alias ekle', ["AdminConfig.create('HostAlias', AdminConfig.getid('/Cell:" + CELL() + "/VirtualHost:" + v.name + "/'), [['hostname', '" + r.host + "'], ['port', '" + r.port + "']])", 'AdminConfig.save()']);
      W.msg('info', 'Alias ' + esc(r.host + ':' + r.port) + ' eklendi. Plug-in yapılandırmasını yeniden üretip yaymayı unutmayın.'); W.rerender();
    } }, { l: 'Cancel' }] });
  };
  A.aliasDel = function (el) { var v = W.by(W.S.virtualHosts, 'name', el.dataset.arg), sel = W.selected(el.dataset.tbl).map(Number); v.aliases = v.aliases.filter(function (a, i) { return sel.indexOf(i) < 0; }); W.change('cells/' + CELL() + '/virtualhosts.xml', 'Host alias silindi: ' + v.name); W.clearSel(el.dataset.tbl); W.msg('warning', 'Alias silindi. Bu host:port ile gelen istekler artık bu virtual host\'a eşlenmeyecek (HTTP 404).'); W.rerender(); };

  R('/env/globalplugin', function () {
    return { title: 'Update global Web server plug-in configuration', help: 'concept.pluginCfg', html: '<div class="page-title">Update global Web server plug-in configuration' + W.hi('concept.pluginCfg') + '</div><p class="desc">Use this page to update the global Web server plug-in configuration file (plugin-cfg.xml). The global plug-in configuration file contains routing information for <b>all</b> the applications in the cell.</p>' +
      '<div class="note-tr">Global plug-in dosyası (<code>profiles/Dmgr01/config/cells/plugin-cfg.xml</code>) tüm uygulamaları içerir ve web server eşlemelerini dikkate almaz. Modern kurulumlarda her web server tanımı için ayrı plugin-cfg.xml üretmek (Servers &gt; Web servers &gt; Generate Plug-in) tercih edilir; global dosya genellikle elle kopyalanarak kullanılan eski yöntemdir.</div>' +
      '<div class="btnrow"><button class="btn primary" data-act="globalPluginGen">OK</button><a href="#/env/globalplugin/view" style="align-self:center">View or download the current Web server plug-in configuration file</a></div>' };
  });
  A.globalPluginGen = function () { W.cmd('Global plug-in üret', ["gen = AdminControl.completeObjectName('type=PluginCfgGenerator,*')", "AdminControl.invoke(gen, 'generate', '/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config " + CELL() + " null null plugin-cfg.xml')"]); W.msg('info', 'PLGC0005I: Plug-in configuration file = /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config/cells/plugin-cfg.xml'); W.rerender(); };
  R('/env/globalplugin/view', function () { return { title: 'Global plugin-cfg.xml', help: 'concept.pluginCfg', html: W.crumbs([['Update global Web server plug-in configuration', '#/env/globalplugin'], 'plugin-cfg.xml']) + '<pre class="code">' + W.xmlHighlight(W.pluginCfg(null)) + '</pre>' }; });

  /* ------------------------------------------------------------ variables */
  W.resType({ id: 'vars', coll: 'variables', path: '/env/variables', title: 'WebSphere Variables', singular: 'WebSphere variable', help: 'concept.wasVariable', scoped: true, cfgType: 'VariableSubstitutionEntry', file: 'variables.xml',
    desc: 'Use this page to define substitution variables. Variables specify a level of indirection for some system-defined values, such as file system root directories. Variables have a scope level, which is either server, cluster, node, or cell.',
    note: 'Öncelik sırası: <b>Server &gt; Cluster &gt; Node &gt; Cell</b>. Aynı ada sahip değişken birden çok seviyede tanımlıysa, kullanan sürece en yakın (en özel) olan uygulanır. Aşağıdaki <b>değişken çözümleyici</b> ile bir sunucu için değerin nasıl çözümlendiğini görebilirsiniz.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'value', l: 'Value' }, { k: 'description', l: 'Description' }],
    defaults: function (s) { return { name: '', value: '', scope: s, description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'concept.wasVariable' }) + F.text({ l: 'Value', n: 'value', v: o.value, h: 'concept.wasVariable' }) + F.text({ l: 'Description', n: 'description', v: o.description }); },
    canDelete: function (o) { if (/^(WAS_INSTALL_ROOT|USER_INSTALL_ROOT|LOG_ROOT|SERVER_LOG_ROOT|WAS_CELL_NAME|WAS_NODE_NAME|WAS_SERVER_NAME|JAVA_HOME|APP_INSTALL_ROOT)$/.test(o.name)) return esc(o.name) + ' sistem değişkenidir; silinirse sunucular başlatılamayabilir. (Silme engellendi)'; },
    createCmd: function (o) { return ["AdminTask.setVariable('[-variableName " + o.name + " -variableValue " + o.value + " -scope " + W.scopeLabel(o.scope) + "]')", 'AdminConfig.save()']; },
    after: function () {
      var sv = W.UI.varSrv || 'BankSrv01', vn = W.UI.varName || 'BANK_CONFIG_DIR', s = W.srv(sv) || W.S.servers[0];
      var scopes = W.visibleScopes(s), chain = scopes.map(function (sc) { var v = W.S.variables.filter(function (x) { return x.name === vn && x.scope === sc; })[0]; return [esc(W.scopeLabel(sc)), v ? '<code>' + esc(v.value) + '</code>' : '<span style="color:#999">(tanımsız)</span>']; });
      var hit = W.resolveVar(vn, scopes);
      var names = W.S.variables.map(function (v) { return v.name; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort();
      return '<div class="portlet" style="margin-top:14px"><div class="ph"><span>Değişken çözümleyici (eğitim aracı)</span></div><div class="pb"><div class="inline-flex" style="gap:8px;flex-wrap:wrap">Sunucu: <select data-change="varSrv">' + W.S.servers.map(function (x) { return '<option' + (x.name === s.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select> Değişken: <select data-change="varName">' + names.map(function (n) { return '<option' + (n === vn ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('') + '</select>' + W.hi('concept.wasVariable') + '</div>' +
        W.simpleTable(['Arama sırası (scope)', 'Değer'], chain) + '<p>Sonuç: <b>${' + esc(vn) + '}</b> = ' + (hit ? '<code>' + esc(W.expandVars(hit.value, scopes)) + '</code> (' + esc(W.scopeShort(hit.scope)) + ' seviyesinden)' : '<span style="color:#c62828">tanımsız – kullanan konfigürasyon hata verir</span>') + '</p></div></div>';
    } });
  W.onChange.varSrv = function (e) { W.UI.varSrv = e.value; W.rerender(); };
  W.onChange.varName = function (e) { W.UI.varName = e.value; W.rerender(); };

  W.resType({ id: 'slib', coll: 'sharedLibs', path: '/env/sharedlibs', title: 'Shared Libraries', singular: 'Shared library', help: 'concept.sharedLib', scoped: true, cfgType: 'Library', file: 'libraries.xml',
    desc: 'Use this page to define a list of shared library files that deployed applications can use. Shared library, birden çok uygulamanın ortak kullandığı JAR dosyalarını tek yerde tanımlar; uygulama veya server class loader\'ına referans verilerek kullanılır.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description' }, { k: 'isolated', l: 'Isolated', fmt: function (r) { return r.isolated ? 'Yes' : 'No'; }, h: 'slib.isolated' }],
    defaults: function (s) { return { name: '', scope: s, classPath: '', nativePath: '', isolated: false, description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'concept.sharedLib' }) + F.text({ l: 'Description', n: 'description', v: o.description }) + F.ta({ l: 'Classpath', n: 'classPath', v: o.classPath, h: 'slib.classpath' }) + F.ta({ l: 'Native Library Path', n: 'nativePath', v: o.nativePath, style: 'height:40px', h: 'jdbc.nativePath' }) + F.grp('Class Loading', 'slib.isolated', F.ck({ l: 'Use an isolated class loader for this shared library', n: 'isolated', v: o.isolated, h: 'slib.isolated' })) + F.ro({ l: 'Referenced by', v: W.S.apps.filter(function (a) { return a.sharedLibs.indexOf(o.name) >= 0; }).map(function (a) { return W.appLink(a.name); }).join(', ') || '(none)', raw: true }); },
    canDelete: function (o) { var u = W.S.apps.filter(function (a) { return a.sharedLibs.indexOf(o.name) >= 0; }); if (u.length) return esc(o.name) + ' silinemedi: ' + u.map(function (a) { return esc(a.name); }).join(', ') + ' tarafından referans ediliyor.'; },
    createCmd: function (o) { return ["AdminConfig.create('Library', AdminConfig.getid('" + W.cfgScope(o.scope) + "'), [['name', '" + o.name + "'], ['classPath', '" + o.classPath.replace(/\n/g, ';') + "'], ['isolatedClassLoader', '" + o.isolated + "']])", 'AdminConfig.save()']; } });

  W.resType({ id: 'repl', coll: 'replicationDomains', path: '/env/replication', title: 'Data replication domains', singular: 'Replication domain', help: 'concept.replicationDomain', scoped: false, cfgType: 'DataReplicationDomain', file: 'multibroker.xml',
    desc: 'Use this page to configure data replication domains. A replication domain is a collection of application servers that share data (HTTP session, dynamic cache, stateful session bean failover) through memory-to-memory replication using the Data Replication Service (DRS).',
    cols: [{ k: 'name', l: 'Name' }, { k: 'numberOfReplicas', l: 'Number of replicas', fmt: function (r) { return +r.numberOfReplicas === -1 ? 'Entire domain' : r.numberOfReplicas; }, h: 'repl.replicas' }, { k: 'description', l: 'Description' }],
    defaults: function () { return { name: '', requestTimeout: 5, encryptionType: 'NONE', numberOfReplicas: 1, description: '' }; },
    form: function (o, isNew) { return (isNew ? F.text({ l: 'Name', n: 'name', v: o.name, req: true }) : F.ro({ l: 'Name', v: o.name })) + F.num({ l: 'Request timeout', n: 'requestTimeout', v: o.requestTimeout, unit: 'seconds', h: 'concept.replicationDomain' }) + F.sel({ l: 'Encryption type', n: 'encryptionType', v: o.encryptionType, o: ['NONE', 'DES', 'TRIPLE_DES'], h: 'concept.replicationDomain' }) + F.radio({ l: 'Number of replicas', n: 'numberOfReplicas', v: String(o.numberOfReplicas), o: [['1', 'Single replica'], ['-1', 'Entire domain'], ['2', 'Specify: 2']], h: 'repl.replicas' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
      F.ro({ l: 'Servers using this domain', v: W.S.servers.filter(function (s) { return s.session.replicationDomain === o.name && s.session.sessionPersistenceMode === 'DATA_REPLICATION'; }).map(function (s) { return W.srvLink(s.name); }).join(', ') || '(none)', raw: true }); } });

  W.resType({ id: 'nsb', coll: 'nameBindings', path: '/env/namebindings', title: 'Name space bindings', singular: 'Name space binding', help: 'concept.naming', scoped: true, cfgType: 'StringNameSpaceBinding', file: 'namebindings.xml',
    desc: 'Use this page to configure name bindings in the name space. Name space binding, JNDI ağacına sabit bir değer (String), EJB referansı, CORBA nesnesi veya başka bir isim alanına dolaylı (indirect) bağlantı ekler.',
    cols: [{ k: 'name', l: 'Binding identifier' }, { k: 'nameInNamespace', l: 'Name in name space' }, { k: 'type', l: 'Binding type' }, { k: 'value', l: 'Value' }],
    defaults: function (s) { return { name: '', type: 'String', nameInNamespace: '', value: '', scope: s }; },
    form: function (o) { return F.sel({ l: 'Binding type', n: 'type', v: o.type, o: ['String', 'EJB', 'CORBA', 'Indirect'], h: 'concept.naming' }) + F.text({ l: 'Binding identifier', n: 'name', v: o.name, req: true }) + F.text({ l: 'Name in name space relative to lookup name prefix "cell/persistent/"', n: 'nameInNamespace', v: o.nameInNamespace, req: true, h: 'concept.naming' }) + F.text({ l: 'String value / target', n: 'value', v: o.value }); } });

  /* ------------------------------------------------------------- cell */
  R('/sys/cell', function () {
    var c = W.S.cell;
    return { title: 'Cell', help: 'concept.cell', html: '<div class="page-title">Cell' + W.hi('concept.cell') + '</div><p class="desc">Use this page to set the discovery protocol for a cell. A cell is a configuration concept that groups nodes into a single administrative domain.</p>' +
      W.cfgForm({ ref: 'cell', doc: 'cells/' + c.name + '/cell.xml', cfgid: '/Cell:' + c.name + '/', back: '#/sys/cell', title: 'Cell', tabs: [['Configuration', '#/sys/cell', true]], general:
        F.ro({ l: 'Name', v: c.name, h: 'concept.cell' }) + F.ro({ l: 'Cell type', v: c.cellType }) + F.ro({ l: 'Product', v: c.product + ' ' + c.version }) + F.text({ l: 'Description', n: 'description', v: c.description }) +
        F.sel({ l: 'Cell discovery protocol', n: 'cellDiscoveryProtocol', v: c.cellDiscoveryProtocol, o: ['TCP', 'UDP'], h: 'sys.discovery' }) +
        F.ro({ l: 'Master repository', v: '/opt/IBM/WebSphere/AppServer/profiles/' + c.dmgrProfile + '/config/cells/' + c.name, h: 'concept.workspace' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Custom properties', href: W.propsLink('cell', 'customProps', 'Cell', '#/sys/cell'), h: 'concept.customProps' }, { l: 'Nodes', href: '#/sys/nodes', h: 'concept.node' }, { l: 'Node groups', href: '#/sys/nodegroups', h: 'sys.nodeGroups' }, { l: 'Core groups', href: '#/coregroups', h: 'concept.coreGroup' }, { l: 'Hücre topolojisi', href: '#/learn/topology', h: 'concept.cell' }] }] }) };
  });

  /* ------------------------------------------------------------- DMGR */
  R('/sys/dmgr', function (p, q) {
    var d = W.S.dmgr, tabs = [['Runtime', '#/sys/dmgr?tab=runtime', q.tab === 'runtime'], ['Configuration', '#/sys/dmgr', q.tab !== 'runtime']];
    if (q.tab === 'runtime') return { title: 'Deployment manager', help: 'concept.dmgr', html: '<div class="tabs">' + tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + t[0] + '</a>'; }).join('') + '</div>' +
      W.kvTable([['Process ID', '30211'], ['Cell name', esc(CELL())], ['Node name', 'CellManager01'], ['Host', 'was-dmgr01.corp.local'], ['State', W.stIcon('started')]]) + '<div class="btnrow"><button class="btn" data-act="dmgrStop">Stop</button></div>' };
    var portRows = Object.keys(d.ports).map(function (k) { return [esc(k), '*', d.ports[k]]; });
    return { title: 'Deployment manager', help: 'concept.dmgr', html: '<div class="page-title">Deployment manager' + W.hi('concept.dmgr') + '</div>' +
      W.cfgForm({ ref: 'dmgr', doc: 'cells/' + CELL() + '/nodes/CellManager01/servers/dmgr/server.xml', back: '#/sys/dmgr', title: 'Deployment manager', tabs: tabs, general:
        F.ro({ l: 'Name', v: 'dmgr' }) + F.ro({ l: 'Node', v: 'CellManager01 (was-dmgr01.corp.local)' }) + F.num({ l: 'Initial heap size', n: 'jvm.initialHeapSize', v: d.jvm.initialHeapSize, unit: 'MB', h: 'jvm.initialHeap' }) + F.num({ l: 'Maximum heap size', n: 'jvm.maximumHeapSize', v: d.jvm.maximumHeapSize, unit: 'MB', h: 'jvm.maxHeap' }) + F.ta({ l: 'Generic JVM arguments', n: 'jvm.genericJvmArguments', v: d.jvm.genericJvmArguments, h: 'jvm.genericArgs' }) +
          '<div class="sect-title" style="margin-top:10px">Ports' + W.hi('srv.ports') + '</div>' + W.simpleTable(['Port Name', 'Host', 'Port'], portRows),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Administration services', act: 'notInSim', arg: 'Administration services', h: 'concept.dmgr' }, { l: 'Logging and tracing', href: '#/tr/logs/dmgr', h: 'concept.logs' }, { l: 'Custom properties', href: W.propsLink('dmgr', 'customProps', 'Deployment manager', '#/sys/dmgr'), h: 'concept.customProps' }] }] }) };
  });
  A.dmgrStop = function () {
    W.modal({ title: 'Deployment manager – Stop', html: '<p>Gerçek ortamda DMGR durdurulduğunda bu konsol oturumu kapanır (konsol DMGR üzerinde çalışır).</p><div class="note-tr"><b>Önemli:</b> DMGR kapalıyken <b>uygulamalar ve application server\'lar çalışmaya devam eder</b>; yalnızca merkezi yönetim (konfigürasyon değişikliği, senkronizasyon, konsol, uygulama kurulumu) yapılamaz. Node agent\'lar, yerel repository kopyalarıyla sunucularını yönetmeye devam eder. DMGR tekrar başlatmak için: <code>/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/bin/startManager.sh</code></div><p>Simülasyonda DMGR durdurulmaz.</p>' });
    W.cmd('DMGR durdur', ["AdminControl.stopServer('dmgr', 'CellManager01')", '# veya: profiles/Dmgr01/bin/stopManager.sh -username wasadmin -password ****']);
  };

  /* ------------------------------------------------------------- nodes */
  function nodeSyncStatus(n) { if (n.type === 'dmgr') return '<span class="st">' + W.ICON.sync + ' Deployment manager</span>'; if (n.type === 'unmanaged') return '<span class="st" style="color:#555">Not applicable (unmanaged)</span>'; if (W.RT.nodeagents[n.name] !== 'started') return W.stIcon('unknown', 'Unknown (node agent stopped)'); return W.RT.sync[n.name] ? W.stIcon('sync') : W.stIcon('nosync'); }
  R('/sys/nodes', function () {
    return { title: 'Nodes', help: 'concept.node', html: '<div class="page-title">Nodes' + W.hi('concept.node') + '</div><p class="desc">Use this page to manage nodes in the application server environment. A node corresponds to a physical computer system with a distinct IP host address.</p>' +
      '<div class="note-tr">Status sütunu, node\'un yerel konfigürasyon kopyasının DMGR master repository ile <b>senkronize</b> olup olmadığını gösterir. AppNode03 başlangıçta senkronize değil: <b>Synchronize</b> ile düzeltin.' + W.hi('sys.sync') + '</div>' + W.prefs() +
      W.table({ id: 'nodes', rows: W.S.nodes, key: function (r) { return r.name; },
        cols: [{ k: 'name', l: 'Name', fmt: function (r) { return W.nodeLink(r.name); } }, { k: 'host', l: 'Host Name' }, { k: 'version', l: 'Version', fmt: function (r) { return esc(r.version || 'Not applicable'); } }, { k: 'discoveryProtocol', l: 'Discovery Protocol', h: 'sys.discovery' }, { k: 'st', l: 'Status', fmt: nodeSyncStatus, sv: function (r) { return W.RT.sync[r.name] ? 1 : 0; }, h: 'sys.sync' }],
        buttons: [{ l: 'Add Node', act: 'nodeAdd' }, { l: 'Remove Node', act: 'nodeRemove', need: 1 }, { l: 'Force Delete', act: 'nodeRemove', need: 1 }, { l: 'Synchronize', act: 'nodeSync', need: 1 }, { l: 'Full Resynchronize', act: 'nodeSync', arg: 'full', need: 1 }, { l: 'Stop', act: 'naStop', need: 1 }], btnHelp: 'sys.sync' }) };
  });
  function syncNodes(names, full) {
    var m = [];
    names.forEach(function (n) {
      var nd = W.node(n);
      if (nd.type !== 'managed') { m.push(esc(n) + ': senkronizasyon yalnızca managed node\'lar için geçerlidir.'); return; }
      if (W.RT.nodeagents[n] !== 'started') { m.push('<span style="color:#c62828">' + esc(n) + ': node agent çalışmıyor; senkronizasyon yapılamadı. Önce host üzerinde <code>startNode.sh</code> çalıştırın.</span>'); return; }
      W.RT.sync[n] = true;
      m.push(full ? 'Full resynchronize: ' + esc(n) + ' üzerindeki tüm konfigürasyon (epoch ayrımı yapılmadan) master repository\'den yeniden alındı.' : 'The node synchronization was successful for node ' + esc(n) + '. (ADMS0003I: The configuration synchronization completed successfully.)');
      W.cmd((full ? 'Full resync: ' : 'Node sync: ') + n, ["AdminControl.invoke(AdminControl.completeObjectName('type=NodeSync,node=" + n + ",*'), '" + (full ? 'sync' : 'sync') + "')"]);
    });
    W.saveRT(); return m;
  }
  A.nodeSync = function (el) { W.msg('info', syncNodes(el.dataset.tbl ? W.selected(el.dataset.tbl) : [el.dataset.node], el.dataset.arg === 'full')); if (el.dataset.tbl) W.clearSel(el.dataset.tbl); W.rerender(); };
  A.nodeAdd = function () {
    W.modal({ title: 'Add Node', html: '<form id="naF" onsubmit="return false">' + F.radio({ l: 'Select node type', n: 'type', v: 'unmanaged', h: 'concept.unmanagedNode', o: [['managed', 'Managed node (node agent ile, WAS kurulu sunucu)'], ['unmanaged', 'Unmanaged node (ör. yalnızca IHS kurulu sunucu)']] }) + F.text({ l: 'Name', n: 'name', v: 'ihsnode03', req: true }) + F.text({ l: 'Host name', n: 'host', v: 'ihs-web03.corp.local', req: true }) + F.sel({ l: 'Platform type', n: 'os', v: 'linux', o: ['linux', 'windows', 'aix', 'os400'] }) + '</form><p class="note-tr">Managed node genellikle hedef sunucuda <code>addNode.sh was-dmgr01.corp.local 8879 -username wasadmin -password ****</code> komutuyla federe edilir. Bu işlem node\'un yerel konfigürasyonunu DMGR\'ye yükler, node agent oluşturur ve başlatır.</p>',
      buttons: [{ l: 'OK', fn: function () {
        var v = W.readForm(document.getElementById('naF')).vals;
        if (W.node(v.name)) { alert('Bu adda bir node var.'); return false; }
        if (v.type === 'managed') { W.msg('info', 'Managed node eklemek için hedef sunucuda: <code>/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/addNode.sh was-dmgr01.corp.local 8879 -username wasadmin -password ****</code> (Simülasyonda yalnızca unmanaged node eklenebilir.)'); W.rerender(); return; }
        W.S.nodes.push({ name: v.name, host: v.host, type: 'unmanaged', os: v.os, osName: v.os, version: '', profile: '', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 4, ramGB: 8 });
        W.change('cells/' + CELL() + '/nodes/' + v.name + '/node.xml', 'Unmanaged node eklendi: ' + v.name);
        W.cmd('Unmanaged node oluştur', ["AdminTask.createUnmanagedNode('[-nodeName " + v.name + " -hostName " + v.host + " -nodeOperatingSystem " + v.os + "]')", 'AdminConfig.save()']);
        W.msg('info', 'Unmanaged node ' + esc(v.name) + ' oluşturuldu. Artık bu node üzerinde bir web server tanımlayabilirsiniz.'); W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.nodeRemove = function (el) {
    var m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      var nd = W.node(n);
      if (nd.type === 'dmgr') { m.push('DMGR node\'u kaldırılamaz.'); return; }
      if (nd.type === 'managed') { m.push(esc(n) + ' managed node\'dur. Kaldırmak için node üzerinde <code>removeNode.sh</code> çalıştırın (node standalone base profile\'a döner; cluster üyeleri ve uygulama hedefleri etkilenir).'); return; }
      if (W.S.webservers.some(function (w) { return w.node === n; })) { m.push(esc(n) + ' üzerinde web server tanımı var; önce web server\'ı silin.'); return; }
      W.S.nodes.splice(W.S.nodes.indexOf(nd), 1); W.change('cells/' + CELL() + '/nodes/' + n, 'Node kaldırıldı: ' + n); m.push(esc(n) + ' kaldırıldı.');
    });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  R('/sys/nodes/:name', function (p) {
    var n = W.node(p.name);
    if (!n) return { title: 'Nodes', html: 'Node bulunamadı' };
    var srvs = W.S.servers.filter(function (s) { return s.node === n.name; }), ws = W.S.webservers.filter(function (w) { return w.node === n.name; });
    var heap = srvs.reduce(function (a, s) { return a + (+s.jvm.maximumHeapSize || 0); }, 0) + (n.type === 'managed' ? 512 : 0);
    return { title: 'Nodes', help: 'concept.node', html: W.crumbs([['Nodes', '#/sys/nodes'], n.name]) + W.cfgForm({ ref: 'nodes|' + n.name, doc: 'cells/' + CELL() + '/nodes/' + n.name + '/node.xml', back: '#/sys/nodes', title: 'Node ' + n.name, general:
      F.ro({ l: 'Name', v: n.name, h: 'concept.node' }) + F.ro({ l: 'Node type', v: n.type === 'dmgr' ? 'Deployment manager node' : n.type === 'managed' ? 'Managed node (WebSphere Application Server)' : 'Unmanaged node', h: n.type === 'unmanaged' ? 'concept.unmanagedNode' : 'concept.node' }) +
        F.text({ l: 'Host name', n: 'host', v: n.host, h: 'concept.node' }) + F.ro({ l: 'Platform', v: n.osName }) + F.ro({ l: 'Version', v: n.version || 'Not applicable' }) + F.ro({ l: 'Profile', v: n.profile || '-' }) + F.sel({ l: 'Discovery protocol', n: 'discoveryProtocol', v: n.discoveryProtocol, o: ['TCP', 'UDP'], h: 'sys.discovery' }) +
        F.ro({ l: 'Hardware (simülasyon)', v: n.cpu + ' vCPU, ' + n.ramGB + ' GB RAM' }) + (n.type === 'managed' ? F.ro({ l: 'JVM max heap toplamı', v: heap + ' MB / ' + n.ramGB * 1024 + ' MB fiziksel bellek', h: 'concept.jvm' }) + F.ro({ l: 'Synchronization status', v: nodeSyncStatus(n), raw: true, h: 'sys.sync' }) : '') +
        F.ro({ l: 'Servers on this node', v: srvs.map(function (s) { return W.srvLink(s.name) + ' ' + W.stIcon(W.serverStatus(s), ''); }).concat(ws.map(function (w) { return '<a href="#/servers/webservers/' + W.enc(w.name) + '">' + esc(w.name) + '</a> (web server)'; })).join('<br>') || '(none)', raw: true }),
      extraButtons: n.type === 'managed' ? '<button type="button" class="btn" data-act="nodeSync" data-node="' + esc(n.name) + '">Synchronize</button><button type="button" class="btn" data-act="nav" data-href="#/wz/createServer?node=' + W.enc(n.name) + '">New server on this node...</button>' : '',
      ap: [{ t: 'Additional Properties', items: [{ l: 'Node agent', href: n.type === 'managed' ? '#/sys/nodeagents/' + W.enc(n.name) : '#/sys/nodeagents', h: 'concept.nodeAgent' }, { l: 'Custom properties', href: W.propsLink('nodes|' + n.name, 'customProps', 'Node ' + n.name, '#/sys/nodes/' + W.enc(n.name)), h: 'concept.customProps' }, { l: 'WebSphere variables (node scope)', href: '#/env/variables', h: 'concept.wasVariable' }] }] }) };
  });

  /* ------------------------------------------------------------ node agents */
  R('/sys/nodeagents', function () {
    return { title: 'Node agents', help: 'concept.nodeAgent', html: '<div class="page-title">Node agents' + W.hi('concept.nodeAgent') + '</div><p class="desc">Use this page to view information about node agents. Node agents are administrative agents that route administrative requests to servers.</p>' + W.prefs() +
      W.table({ id: 'na', rows: W.S.nodeAgents.map(function (n) { return { id: n.node, name: 'nodeagent', node: n.node }; }),
        cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/sys/nodeagents/' + W.enc(r.node) + '">nodeagent</a>'; } }, { k: 'node', l: 'Node', fmt: function (r) { return W.nodeLink(r.node); } }, { k: 'host', l: 'Host Name', fmt: function (r) { return esc(W.hostOf(r.node)); } }, { k: 'v', l: 'Version', fmt: function () { return esc(W.S.cell.version); } }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(W.RT.nodeagents[r.node], ''); } }],
        buttons: [{ l: 'Synchronize', act: 'naSync', need: 1 }, { l: 'Full Resynchronize', act: 'naSync', arg: 'full', need: 1 }, { l: 'Restart', act: 'naRestart', need: 1 }, { l: 'Restart all Servers on Node', act: 'naRestartAll', need: 1 }, { l: 'Stop', act: 'naStop', need: 1 }, { l: 'Start (startNode.sh)', act: 'naStart', need: 1 }], btnHelp: 'concept.nodeAgent' }) +
      '<div class="note-tr"><b>Not:</b> Durdurulmuş bir node agent konsoldan başlatılamaz; DMGR ile iletişim node agent üzerinden kurulduğu için ilgili sunucuda <code>profiles/AppSrv01/bin/startNode.sh</code> çalıştırılmalıdır. Simülasyonda bunu "Start (startNode.sh)" düğmesi temsil eder. Node agent durdurulduğunda o node\'daki sunucuların durumu <i>Unknown</i> görünür, ancak sunucular <b>çalışmaya devam eder</b>.</div>' };
  });
  A.naSync = function (el) { W.msg('info', syncNodes(W.selected(el.dataset.tbl), el.dataset.arg === 'full')); W.clearSel(el.dataset.tbl); W.rerender(); };
  A.naStop = function (el) {
    var m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      if (!W.RT.nodeagents[n]) { m.push(esc(n) + ': bu node\'da node agent yok.'); return; }
      W.RT.nodeagents[n] = 'stopped'; m.push('Node agent ' + esc(n) + ' durduruldu. Bu node\'daki sunucular çalışmaya devam ediyor; ancak DMGR artık onları yönetemez, durumları Unknown görünür ve konfigürasyon senkronizasyonu yapılamaz.');
      W.cmd('Node agent durdur: ' + n, ["AdminControl.invoke(AdminControl.queryNames('WebSphere:*,type=NodeAgent,node=" + n + "'), 'stop')"]);
    });
    W.saveRT(); W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  A.naStart = function (el) { W.selected(el.dataset.tbl).forEach(function (n) { W.RT.nodeagents[n] = 'started'; }); W.saveRT(); W.cmd('Node agent başlat (host üzerinde)', ['# ssh wasadm@' + W.hostOf(W.selected(el.dataset.tbl)[0]), '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/startNode.sh']); W.clearSel(el.dataset.tbl); W.msg('info', 'ADMU3000I: Server nodeagent open for e-business; process id is 21877. (startNode.sh simüle edildi)'); W.rerender(); };
  A.naRestart = function (el) { var m = W.selected(el.dataset.tbl).map(function (n) { return W.RT.nodeagents[n] === 'started' ? 'Node agent ' + esc(n) + ' yeniden başlatıldı.' : '<span style="color:#c62828">' + esc(n) + ' çalışmıyor; Restart yalnızca çalışan node agent\'a uygulanır.</span>'; }); W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender(); };
  A.naRestartAll = function (el) { var m = []; W.selected(el.dataset.tbl).forEach(function (n) { m = m.concat(W.serverOp(W.S.servers.filter(function (s) { return s.node === n && W.RT.servers[s.name] === 'started'; }).map(function (s) { return s.name; }), 'restart')); }); W.clearSel(el.dataset.tbl); W.msg('info', m.length ? m : ['Bu node\'da çalışan sunucu yok.']); W.rerender(); };
  R('/sys/nodeagents/:node', function (p, q) {
    var na = W.by(W.S.nodeAgents, 'node', p.node), b = '#/sys/nodeagents/' + W.enc(na.node);
    var tabs = [['Runtime', b + '?tab=runtime', q.tab === 'runtime'], ['Configuration', b, q.tab !== 'runtime']];
    var cr = W.crumbs([['Node agents', '#/sys/nodeagents'], 'nodeagent (' + na.node + ')']);
    if (q.tab === 'runtime') return { title: 'Node agents', help: 'concept.nodeAgent', html: cr + '<div class="tabs">' + tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + t[0] + '</a>'; }).join('') + '</div>' + W.kvTable([['State', W.stIcon(W.RT.nodeagents[na.node])], ['Node', esc(na.node)], ['Host', esc(W.hostOf(na.node))], ['Last synchronization', W.RT.sync[na.node] ? 'Başarılı' : 'Senkronize değil'], ['Managed servers', W.S.servers.filter(function (s) { return s.node === na.node; }).map(function (s) { return W.srvLink(s.name); }).join(', ')]]) };
    return { title: 'Node agents', help: 'concept.nodeAgent', html: cr + W.cfgForm({ ref: 'nodeAgents|' + na.node, doc: 'cells/' + CELL() + '/nodes/' + na.node + '/servers/nodeagent/server.xml', back: '#/sys/nodeagents', title: 'Node agent ' + na.node, tabs: tabs, general:
      F.ro({ l: 'Name', v: 'nodeagent' }) + F.ro({ l: 'Node', v: na.node }) + F.num({ l: 'Maximum heap size', n: 'jvm.maximumHeapSize', v: na.jvm.maximumHeapSize, unit: 'MB', h: 'jvm.maxHeap' }) + '<div class="sect-title" style="margin-top:10px">Ports' + W.hi('srv.ports') + '</div>' + W.simpleTable(['Port Name', 'Port'], Object.keys(na.ports).map(function (k) { return [esc(k), na.ports[k]]; })),
      ap: [{ t: 'Additional Properties', items: [{ l: 'File synchronization service', href: b + '/sync', h: 'sys.syncService' }, { l: 'Logging and tracing', href: '#/tr/logs', h: 'concept.logs' }, { l: 'Custom properties', href: W.propsLink('nodeAgents|' + na.node, 'customProps', 'Node agent', b), h: 'concept.customProps' }] }] }) };
  });
  R('/sys/nodeagents/:node/sync', function (p) {
    var na = W.by(W.S.nodeAgents, 'node', p.node), y = na.sync, b = '#/sys/nodeagents/' + W.enc(na.node);
    return { title: 'Node agents', help: 'sys.syncService', html: W.crumbs([['Node agents', '#/sys/nodeagents'], ['nodeagent (' + na.node + ')', b], 'File synchronization service']) + '<p class="desc">Use this page to configure the file synchronization service. The file synchronization service runs in the deployment manager and node agents, and ensures that configuration changes made to the cell repository are propagated to the appropriate node repositories.' + W.hi('sys.syncService') + '</p>' +
      W.cfgForm({ ref: 'nodeAgents|' + na.node + '|sync', doc: 'cells/' + CELL() + '/nodes/' + na.node + '/servers/nodeagent/server.xml', back: b, title: 'File synchronization service', general:
        F.ck({ l: 'Enable service at server startup', v: true, ro: true, h: 'sys.syncService' }) + F.num({ l: 'Synchronization interval', n: 'synchInterval', v: y.synchInterval, unit: 'minutes', h: 'sys.syncService', min: 1 }) +
        F.ck({ l: 'Automatic synchronization', n: 'autoSynchEnabled', v: y.autoSynchEnabled, h: 'sys.syncService' }) + F.ck({ l: 'Startup synchronization', n: 'synchOnServerStartup', v: y.synchOnServerStartup, h: 'sys.syncService' }) + F.ta({ l: 'Exclusions', n: 'exclusions', v: y.exclusions, h: 'sys.syncService' }) }) };
  });
  R('/sys/nodegroups', function () {
    return { title: 'Node groups', help: 'sys.nodeGroups', html: '<div class="page-title">Node groups' + W.hi('sys.nodeGroups') + '</div><p class="desc">Use this page to manage node groups. A node group is a collection of managed nodes with similar capabilities; a cluster must be bounded by a single node group.</p>' +
      W.table({ id: 'ng', rows: W.S.nodeGroups, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description' }, { k: 'm', l: 'Members', fmt: function () { return esc(W.S.nodes.map(function (n) { return n.name; }).join(', ')); } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New node group' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }] }) };
  });
  R('/sys/middleware', function () {
    var rows = [{ id: 'dmgr', name: 'dmgr', node: 'CellManager01', type: 'Deployment manager', st: 'started' }]
      .concat(W.S.nodeAgents.map(function (n) { return { id: 'na' + n.node, name: 'nodeagent', node: n.node, type: 'Node agent', st: W.RT.nodeagents[n.node] }; }))
      .concat(W.S.servers.map(function (s) { return { id: s.name, name: s.name, node: s.node, type: 'WebSphere application server', st: W.serverStatus(s), link: '#/servers/appservers/' + W.enc(s.name) }; }))
      .concat(W.S.webservers.map(function (w) { return { id: w.name, name: w.name, node: w.node, type: 'Web server (IBM HTTP Server)', st: W.wsStatus(w) === 'running' ? 'started' : 'stopped', link: '#/servers/webservers/' + W.enc(w.name) }; }))
      .concat(W.S.genericServers.map(function (g) { return { id: g.name, name: g.name, node: g.node, type: 'Generic server', st: W.RT.generic[g.name] || 'stopped' }; }));
    return { title: 'Middleware servers', help: 'sys.middleware', html: '<div class="page-title">Middleware servers' + W.hi('sys.middleware') + '</div><p class="desc">Hücredeki tüm yönetilen süreçlerin (middleware server) türüne bakılmaksızın birleşik görünümü.</p>' +
      W.table({ id: 'mw', select: false, rows: rows, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return r.link ? '<a href="' + r.link + '">' + esc(r.name) + '</a>' : esc(r.name); } }, { k: 'node', l: 'Node' }, { k: 'type', l: 'Server type' }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(r.st, ''); } }] }) };
  });
  R('/sys/adminagent', function () {
    return { title: 'Administrative agents', help: 'sys.adminAgent', html: '<div class="page-title">Administrative agents' + W.hi('sys.adminAgent') + '</div><p class="desc">Administrative agent, <b>Base (standalone)</b> sürümündeki birden çok application server profilini tek bir yönetim noktasından yönetmek için kullanılan ayrı bir profil türüdür.</p>' +
      '<div class="note-tr">Bu hücre bir <b>Network Deployment</b> hücresidir ve merkezi yönetimi Deployment Manager yapar; dolayısıyla administrative agent kullanılmaz. Admin agent ile DMGR aynı node\'u aynı anda yönetemez. Admin agent, <code>manageprofiles.sh -create -templatePath .../management -serverType ADMIN_AGENT</code> ile oluşturulur ve base profiller <code>registerNode</code> komutuyla kaydedilir.</div>' +
      W.table({ id: 'aa', select: false, rows: [], cols: [{ k: 'name', l: 'Administrative agent' }, { k: 'host', l: 'Host' }, { k: 'nodes', l: 'Registered nodes' }], empty: 'Bu ND hücresinde administrative agent yok (beklenen durum).' }) };
  });
  R('/sys/jobmanager', function () {
    var j = W.S.jobManager;
    return { title: 'Job manager', help: 'sys.jobManager', html: '<div class="page-title">Job manager' + W.hi('sys.jobManager') + '</div><p class="desc">Job manager; birden çok DMGR hücresini ve admin agent\'ı, asenkron "job"lar (dosya dağıtma, uygulama kurma, sunucu başlatma vb.) ile büyük ölçekte yönetmek için kullanılan ayrı bir profildir.</p>' +
      W.kvTable([['Registered with job manager', j.registered ? 'Yes' : 'No', 'sys.jobManager'], ['Job manager', esc(j.name) + ' (' + esc(j.host) + ':' + j.port + ')'], ['Managed node name', esc(j.managedNodeName)], ['Job manager UUID', esc(j.uuid)]]) +
      '<div class="sect-title" style="margin-top:12px">Son job\'lar (job manager konsolundan)</div>' +
      W.simpleTable(['Job ID', 'Job type', 'Target', 'Status', 'Submitted'], [['1288345201', 'Install application', W.S.cell.name, '<span style="color:#1f8a2e">Succeeded</span>', '2026-11-14 23:40'], ['1288345377', 'Distribute file', W.S.cell.name, '<span style="color:#1f8a2e">Succeeded</span>', '2026-11-18 21:02'], ['1288345410', 'Start server', 'AppNode03/BatchSrv01', '<span style="color:#c62828">Failed</span>', '2026-11-20 06:00']]) };
  });
  R('/sys/prefs', function () {
    W.S.consolePrefs = W.S.consolePrefs || { autoRefresh: true, noConfirmDiscard: false, useDefaultScope: false, showHelp: true, cmdNotify: true, logCmds: false, syncNodes: true };
    var p = W.S.consolePrefs;
    return { title: 'Console Preferences', help: 'sys.prefs', html: '<div class="page-title">Console Preferences' + W.hi('sys.prefs') + '</div><p class="desc">Use this page to modify the console preferences.</p>' +
      W.cfgForm({ ref: 'consolePrefs', back: '#/sys/prefs', title: 'Console preferences', doc: 'workspace/preferences', gpTitle: false, general:
        F.ck({ l: 'Turn on workspace automatic refresh', n: 'autoRefresh', v: p.autoRefresh }) + F.ck({ l: 'No confirmation on workspace discard', n: 'noConfirmDiscard', v: p.noConfirmDiscard }) + F.ck({ l: 'Use default scope (administration node)', n: 'useDefaultScope', v: p.useDefaultScope, h: 'concept.scope' }) +
        F.ck({ l: 'Show the help portlet', n: 'showHelp', v: p.showHelp, h: 'sys.prefs' }) + F.ck({ l: 'Enable command assistance notifications', n: 'cmdNotify', v: p.cmdNotify, h: 'concept.wsadmin' }) + F.ck({ l: 'Log command assistance commands', n: 'logCmds', v: p.logCmds, h: 'concept.wsadmin' }) + F.ck({ l: 'Synchronize changes with Nodes', n: 'syncNodes', v: p.syncNodes, h: 'sys.syncNodes' }) }) +
      '<div class="portlet" style="margin-top:12px"><div class="ph"><span>Simülasyon</span></div><div class="pb"><p>Tarayıcınızda saklanan simülasyon verilerini (kaydedilmiş konfigürasyon, sunucu durumları, panel tercihleri) başlangıç durumuna döndürür.</p><button class="btn" data-act="resetSim">Simülasyonu sıfırla</button></div></div>',
      onMount: function () { W.applyPrefs(); } };
  });
  W.applyPrefs = function () { var p = W.S.consolePrefs; var hp = document.getElementById('helpPortlet'); if (hp) hp.classList.toggle('collapsed', p && p.showHelp === false); };
  R('/sys/identity', function () {
    W.S.consoleIdentity = W.S.consoleIdentity || { type: 'string', text: 'PROD – ' + CELL() };
    return { title: 'Console Identity', help: 'sys.identity', html: '<div class="page-title">Console Identity' + W.hi('sys.identity') + '</div><p class="desc">Console identity, banner\'da ve tarayıcı başlığında hangi ortamda (PROD/TEST) çalıştığınızı gösteren bir metindir. Birden çok konsol açıkken yanlış ortamda işlem yapma riskini azaltır.</p>' +
      W.cfgForm({ ref: 'consoleIdentity', back: '#/sys/identity', title: 'Console identity', doc: 'cells/' + CELL() + '/cell.xml', general: F.radio({ l: 'Console identity', n: 'type', v: W.S.consoleIdentity.type, o: [['none', 'None'], ['machine', 'Machine name'], ['string', 'Custom string']], h: 'sys.identity' }) + F.text({ l: 'Custom string', n: 'text', v: W.S.consoleIdentity.text }) }), onMount: function () { W.updateIdentity(); } };
  });
  W.updateIdentity = function () { var i = W.S.consoleIdentity, el = document.getElementById('consoleId'); if (!el) return; el.textContent = !i || i.type === 'none' ? '' : i.type === 'machine' ? 'was-dmgr01.corp.local' : i.text; el.style.display = el.textContent ? '' : 'none'; };
  R('/sys/ers', function () {
    W.S.ers = W.S.ers || { enabled: false, maxVersions: 5, dir: '${USER_INSTALL_ROOT}/config/temp/extendedRepository' };
    return { title: 'Extended Repository Service', help: 'sys.ers', html: '<div class="page-title">Extended Repository Service' + W.hi('sys.ers') + '</div><p class="desc">Extended Repository Service, konfigürasyon değişikliklerinde değişen belgelerin önceki sürümlerini saklayarak konfigürasyon geçmişi ve geri alma (rollback) için kaynak sağlar.</p>' +
      W.cfgForm({ ref: 'ers', back: '#/sys/ers', doc: 'cells/' + CELL() + '/cell.xml', title: 'Extended Repository Service', general: F.ck({ l: 'Enable extended repository service', n: 'enabled', v: W.S.ers.enabled, h: 'sys.ers' }) + F.num({ l: 'Maximum number of versions retained', n: 'maxVersions', v: W.S.ers.maxVersions }) + F.text({ l: 'Repository directory', n: 'dir', v: W.S.ers.dir }) }) };
  });
})();
