/* pages-arch.js – WAS mimari yapıları: Standalone (Base), Network Deployment,
   Deployment Manager, Node Agent, Cluster (vertical/horizontal), federe yapı
   (addNode), profil türleri ve esnek yönetim (admin agent / job manager). */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, A = W.act, R = W.route;

  /* ---------------------------------------------------- diyagram yardımcıları */
  function proc(cls, name, sub, help, extra) {
    return '<div class="topo-proc ' + (cls || '') + '"><span class="inline-flex">' + esc(name) + (help ? W.hi(help) : '') + '</span><span style="font-size:10px;color:#555">' + (sub || '') + '</span>' + (extra || '') + '</div>';
  }
  function node(title, sub, inner, help, badge) {
    return '<div class="topo-node"><div class="tn"><span class="inline-flex">' + esc(title) + (help ? W.hi(help) : '') + '</span>' + (badge ? '<span class="badge ' + (badge[1] || 'cell') + '">' + esc(badge[0]) + '</span>' : '') + '</div><div class="th">' + sub + '</div>' + inner + '</div>';
  }
  function cell(title, inner, help, color) {
    return '<div class="topo-cell"' + (color ? ' style="border-color:' + color + '"' : '') + '><div class="tt">' + title + (help ? W.hi(help) : '') + '</div><div class="topo-row">' + inner + '</div></div>';
  }
  function repo(txt) { return '<div style="font-size:10.5px;color:#555;margin-top:5px;border-top:1px dashed #c3cde0;padding-top:4px">📁 ' + txt + '</div>'; }
  function cmp(rows) { return W.simpleTable(['Özellik', 'Değer'], rows.map(function (r) { return ['<b>' + esc(r[0]) + '</b>', r[1]]; })); }
  function proscons(p, c) { return '<div class="cards" style="margin-top:10px"><div class="card"><h4>✔ Avantajlar</h4><p>' + p.map(esc).join('<br>') + '</p></div><div class="card"><h4>✘ Sınırlamalar / riskler</h4><p>' + c.map(esc).join('<br>') + '</p></div></div>'; }
  function cmdBox(title, lines) { return '<div class="sect-title" style="margin-top:12px">' + esc(title) + '</div><pre class="code light">' + esc(lines.join('\n')) + '</pre>'; }

  /* -------------------------------------------------------- mimari tanımları */
  var ARCH = {
    standalone: {
      t: 'Standalone (Base / tek sunucu)', h: 'arch.standalone',
      intro: 'Tek bir <b>Application server profili</b> (varsayılan sunucu adı <code>server1</code>) kendi başına çalışır. Yönetim konsolu (adminconsole uygulaması) bu sunucunun <b>içinde</b> çalışır; DMGR ve node agent yoktur. Bu yapı <b>WAS Base</b> sürümünde zorunlu, ND sürümünde ise henüz federe edilmemiş bir profil için geçerlidir.',
      diagram: function () {
        return cell('Cell: was-dev01Node01Cell <span class="badge">standalone hücre</span>',
          node('was-dev01Node01', 'was-dev01.corp.local · profil AppSrv01', proc('cl-c0', 'server1', 'Application server', 'concept.appserver') +
            '<div style="margin-left:14px">' + proc('dm', 'adminconsole + wsadmin (SOAP 8880)', 'yönetim sunucunun içinde', 'concept.wsadmin') + proc('', 'Uygulamalar (EAR/WAR)', ':9080 / :9443', 'concept.enterpriseApp') + '</div>' +
            repo('profiles/AppSrv01/config/cells/... – yerel ve tek konfigürasyon deposu'), 'concept.node', ['Base', 'node']), 'concept.cell');
      },
      table: [['Ürün sürümü', 'WAS Base, WAS Express veya ND (federe edilmemiş profil)'], ['Profil türü', 'Application server profile (manageprofiles -templatePath .../default)'], ['Yönetim', 'Sunucunun kendi konsolu: https://host:9043/ibm/console'], ['Konfigürasyon deposu', 'Profilin kendi config dizini (tek kopya, senkronizasyon yok)'], ['Cluster / WLM', 'Yok'], ['Session failover', 'Yok (tek JVM)'], ['Süreçler', 'server1 (tek JVM)'], ['Başlatma', 'profiles/AppSrv01/bin/startServer.sh server1']],
      pros: ['Kurulum ve yönetimi çok basit', 'Düşük kaynak kullanımı (tek JVM)', 'Geliştirme, test ve küçük uygulamalar için ideal', 'DMGR/node agent bakımı yok'],
      cons: ['Yüksek erişilebilirlik yok: sunucu çökerse uygulama erişilemez', 'Yatay ölçekleme (cluster) yok', 'Her sunucu ayrı ayrı yönetilir; çok sayıda sunucuda tutarsızlık riski', 'Yönetim konsolu da aynı JVM\'de: sunucu kapalıysa konsol da kapalı'],
      cmds: ['# Profil oluşturma', '/opt/IBM/WebSphere/AppServer/bin/manageprofiles.sh -create -profileName AppSrv01 \\', '   -templatePath /opt/IBM/WebSphere/AppServer/profileTemplates/default \\', '   -nodeName was-dev01Node01 -serverName server1 -enableAdminSecurity true -adminUserName wasadmin -adminPassword ****', '', '# Başlatma / durdurma', '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/startServer.sh server1', '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/stopServer.sh server1 -username wasadmin -password ****']
    },
    nd: {
      t: 'Network Deployment (ND) – dağıtık hücre', h: 'arch.nd',
      intro: 'Network Deployment, birden çok makinedeki WAS süreçlerini tek bir <b>Cell</b> altında merkezi yöneten mimaridir. Bir <b>Deployment Manager</b> (yönetim), her managed node\'da bir <b>Node Agent</b> (yerel aracı) ve uygulamaları çalıştıran <b>application server</b>\'lar bulunur. Sunucular <b>cluster</b>\'larda gruplanarak yük dağıtımı ve failover sağlanır. Bu simülasyondaki WASPRODCell01 bir ND hücresidir.',
      diagram: function () {
        return cell('Cell: WASPRODCell01 <span class="badge">ND</span>',
          node('CellManager01', 'was-dmgr01 · Dmgr01 profili', proc('dm', 'dmgr', 'konsol 9043, SOAP 8879', 'concept.dmgr') + repo('<b>Master repository</b>'), 'concept.dmgr', ['DMGR node', 'cell']) +
          node('AppNode01', 'was-app01 · AppSrv01 (federe)', proc('na', 'nodeagent', 'SOAP 8878, sync', 'concept.nodeAgent') + proc('cl-c0', 'BankSrv01', 'BankingCluster') + proc('cl-c1', 'PortalSrv01', 'PortalCluster') + repo('yerel repository kopyası'), 'concept.node', ['managed', 'node']) +
          node('AppNode02', 'was-app02 · AppSrv01 (federe)', proc('na', 'nodeagent', '') + proc('cl-c0', 'BankSrv02', 'BankingCluster') + proc('cl-c1', 'PortalSrv02', 'PortalCluster') + repo('yerel repository kopyası'), 'concept.node', ['managed', 'node']) +
          node('ihsnode01', 'ihs-web01 · WAS yok', proc('', 'webserver1 (IHS + Plug-in)', ':80/:443', 'concept.ihs'), 'concept.unmanagedNode', ['unmanaged', 'node']), 'concept.cell');
      },
      table: [['Ürün sürümü', 'WAS Network Deployment'], ['Profiller', 'Management (Deployment manager) + her makinede Custom/Application server profili (federe)'], ['Yönetim', 'Tek konsol (DMGR) ve tek wsadmin bağlantı noktası'], ['Konfigürasyon deposu', 'DMGR\'de master repository + her node\'da senkronize kopya'], ['Cluster / WLM', 'Var (HTTP: plug-in, EJB: ORB WLM)'], ['Session failover', 'Database veya memory-to-memory replication ile'], ['Yüksek erişilebilirlik', 'HA Manager / core group (ME, transaction recovery failover)'], ['Süreçler', 'dmgr + her node\'da nodeagent + N application server']],
      pros: ['Merkezi yönetim, tutarlı konfigürasyon', 'Cluster ile yatay ölçekleme ve failover', 'Kesintisiz bakım (Ripplestart, Rollout Update)', 'Hücre genelinde kaynak, güvenlik ve uygulama dağıtımı'],
      cons: ['Daha fazla süreç ve bellek (dmgr, node agent\'lar)', 'Daha karmaşık kurulum, ağ/güvenlik duvarı kuralları', 'Senkronizasyon ve plug-in güncellemesi gibi ek operasyon adımları', 'Lisans maliyeti Base\'e göre yüksek'],
      cmds: ['# 1) DMGR profili (management)', 'manageprofiles.sh -create -profileName Dmgr01 -templatePath .../profileTemplates/management \\', '   -serverType DEPLOYMENT_MANAGER -cellName WASPRODCell01 -nodeName CellManager01 -enableAdminSecurity true -adminUserName wasadmin -adminPassword ****', 'profiles/Dmgr01/bin/startManager.sh', '', '# 2) Her uygulama makinesinde custom profil ve federasyon', 'manageprofiles.sh -create -profileName AppSrv01 -templatePath .../profileTemplates/managed -nodeName AppNode01', 'profiles/AppSrv01/bin/addNode.sh was-dmgr01.corp.local 8879 -username wasadmin -password ****', '', '# 3) Cluster ve üyeler (wsadmin)', "AdminTask.createCluster('[-clusterConfig [-clusterName BankingCluster]]')", "AdminTask.createClusterMember('[-clusterName BankingCluster -memberConfig [-memberNode AppNode01 -memberName BankSrv01]]')"]
    },
    dmgr: {
      t: 'Deployment Manager (DMGR) rolü', h: 'concept.dmgr',
      intro: 'DMGR, ND hücresinin <b>yönetim beynidir</b>; kullanıcı uygulaması çalıştırmaz. Konsol ve wsadmin isteklerini kabul eder, değişiklikleri master repository\'ye yazar, node agent\'lara dağıtır ve runtime komutlarını (start/stop) node agent\'lar aracılığıyla iletir.',
      diagram: function () {
        return '<div class="flow">' + fb('Yönetici', 'Konsol (9043) / wsadmin (SOAP 8879)', 'concept.wsadmin') + fa() + fb('Deployment Manager', 'workspace → Save → master repository', 'concept.dmgr') + fa() + fb('Node agent\'lar', 'File sync (1 dk) + JMX komutları', 'concept.nodeAgent') + fa() + fb('Application server\'lar', 'yerel konfigürasyonu okur', 'concept.appserver') + '</div>' +
          '<div class="cards"><div class="card"><h4>DMGR kapalıyken çalışmaya devam edenler</h4><p>✔ Application server\'lar ve uygulamalar<br>✔ Web server + plug-in yönlendirmesi<br>✔ Node agent\'ların sunucuları izlemesi/yeniden başlatması<br>✔ HA Manager failover\'ı</p></div><div class="card"><h4>DMGR kapalıyken yapılamayanlar</h4><p>✘ Konsol ve wsadmin (DMGR\'ye bağlı)<br>✘ Konfigürasyon değişikliği ve Save<br>✘ Node senkronizasyonu<br>✘ Uygulama kurulumu / plug-in üretimi</p></div></div>';
      },
      table: [['Profil türü', 'Management profile (serverType DEPLOYMENT_MANAGER)'], ['Süreç adı', 'dmgr'], ['Önemli portlar', 'WC_adminhost_secure 9043 (konsol), SOAP 8879, BOOTSTRAP 9809, CELL_DISCOVERY 7277'], ['Sayısı', 'Hücre başına tam olarak 1'], ['Tek nokta hatası mı?', 'Runtime için hayır; yönetim için evet (yedek: profil/config yedeği, backupConfig)'], ['Yedekleme', 'profiles/Dmgr01/bin/backupConfig.sh (restoreConfig.sh ile geri yükleme)']],
      pros: ['Tek noktadan tüm hücrenin yönetimi', 'Rol tabanlı yönetim güvenliği', 'Workspace ile değişiklikleri gözden geçirip toplu kaydetme'],
      cons: ['DMGR makinesinin kaybı konfigürasyon kaybı riski (düzenli backupConfig şart)', 'Büyük hücrelerde DMGR heap\'i yetersiz kalırsa konsol yavaşlar'],
      cmds: ['profiles/Dmgr01/bin/startManager.sh', 'profiles/Dmgr01/bin/stopManager.sh -username wasadmin -password ****', 'profiles/Dmgr01/bin/backupConfig.sh /backup/WASPRODCell01_$(date +%F).zip -nostop']
    },
    nodeagent: {
      t: 'Node Agent rolü', h: 'concept.nodeAgent',
      intro: 'Node agent, federe edilmiş her (managed) node\'da çalışan yönetim sürecidir. DMGR doğrudan uygulama sunucularıyla değil, <b>node agent ile</b> konuşur.',
      diagram: function () {
        return cell('Managed node: AppNode02 (was-app02.corp.local)',
          node('nodeagent', 'AppSrv01 profili', '<div style="font-size:11px;line-height:1.6">① <b>File Synchronization Service</b>: master repository değişikliklerini çeker' + W.hi('sys.syncService') + '<br>② <b>Süreç yönetimi</b>: sunucuları başlatır/durdurur, monitoring policy ile izler' + W.hi('srv.monitor') + '<br>③ <b>Location Service Daemon</b> (2809): EJB istemcilerini doğru sunucuya yönlendirir' + W.hi('concept.naming') + '<br>④ <b>Yönetim aracı</b>: DMGR\'nin JMX isteklerini sunuculara iletir</div>', 'concept.nodeAgent', ['node agent', 'node']) +
          node('Yönettiği sunucular', 'aynı node üzerinde', proc('cl-c0', 'BankSrv02', 'BankingCluster') + proc('cl-c1', 'PortalSrv02', 'PortalCluster') + proc('cl-c2', 'MsgSrv01', 'MessagingCluster'), 'concept.appserver'), 'concept.node');
      },
      table: [['Sayısı', 'Her managed node\'da 1 (unmanaged node\'da yok)'], ['Oluşturulma', 'addNode.sh ile federasyon sırasında otomatik'], ['Başlatma', 'Konsoldan başlatılamaz: profiles/AppSrv01/bin/startNode.sh (veya OS servisi)'], ['Önemli portlar', 'SOAP 8878, BOOTSTRAP 2809, NODE_DISCOVERY 7272'], ['Kapalıysa', 'Sunucular çalışır ama durumları Unknown, senkronizasyon ve uzaktan start/stop yok']],
      pros: ['Uzak makinelerin merkezi yönetimi', 'Çöken sunucuların otomatik yeniden başlatılması', 'DMGR kapalıyken bile yerel yönetimin sürmesi'],
      cons: ['Ek bir JVM (bellek)', 'Makine açılışında başlatılmazsa yönetim kopar (systemd servisi önerilir)'],
      cmds: ['profiles/AppSrv01/bin/startNode.sh', 'profiles/AppSrv01/bin/stopNode.sh -stopservers -username wasadmin -password ****', '# Node agent kapalıyken elle senkronizasyon:', 'profiles/AppSrv01/bin/syncNode.sh was-dmgr01.corp.local 8879 -username wasadmin -password ****', '# OS servisi olarak tanımlama:', 'bin/wasservice.sh -add AppNode01_nodeagent -serverName nodeagent -profilePath /opt/IBM/WebSphere/AppServer/profiles/AppSrv01']
    },
    cluster: {
      t: 'Cluster – vertical ve horizontal', h: 'concept.cluster',
      intro: 'Cluster, aynı uygulamaları çalıştıran sunucu grubudur. Üyelerin yerleşimine göre iki tür vardır: <b>Vertical clustering</b> (aynı makinede birden çok üye) ve <b>Horizontal clustering</b> (farklı makinelerde üyeler). Üretimde genellikle ikisi birlikte (her makinede 1–2 üye, birden çok makine) kullanılır.',
      diagram: function () {
        return '<div class="cards"><div class="card"><h4>Vertical clustering' + W.hi('arch.vertical') + '</h4>' +
          node('AppNode01', 'tek makine (8 vCPU / 32 GB)', proc('cl-c0', 'AppSrvA', 'üye 1') + proc('cl-c0', 'AppSrvB', 'üye 2') + proc('cl-c0', 'AppSrvC', 'üye 3'), 'concept.node') +
          '<p style="margin-top:6px">✔ CPU\'ları daha iyi kullanır, JVM başına daha küçük heap (kısa GC)<br>✔ Bir JVM çökerse diğerleri hizmet verir<br>✘ Makine/OS arızasında <b>tüm üyeler</b> gider</p></div>' +
          '<div class="card"><h4>Horizontal clustering' + W.hi('arch.horizontal') + '</h4><div class="topo-row">' +
          node('AppNode01', 'was-app01', proc('cl-c0', 'BankSrv01', 'üye'), 'concept.node') + node('AppNode02', 'was-app02', proc('cl-c0', 'BankSrv02', 'üye'), 'concept.node') + node('AppNode03', 'was-app03', proc('cl-c0', 'BankSrv03', 'üye'), 'concept.node') +
          '</div><p style="margin-top:6px">✔ Donanım/OS arızasına karşı dayanıklı<br>✔ Kapasite makine ekleyerek artar<br>✘ Daha fazla makine ve ağ trafiği (session replikasyonu)</p></div></div>' +
          '<div class="note-tr">Bu simülasyondaki <a href="#/clusters/BankingCluster">BankingCluster</a> horizontal bir cluster\'dır (3 node). <a href="#/learn/cluster">Cluster, WLM ve failover</a> sayfasında üyeleri çökertip davranışı deneyebilirsiniz.</div>';
      },
      table: [['Gereken sürüm', 'Network Deployment (Base\'de cluster yoktur)'], ['Üyelerin konfigürasyonu', 'Her üyenin kendi server.xml\'i; uygulamalar ortak (cluster hedefi)'], ['Yük dağıtımı', 'HTTP: web server plug-in (weight); EJB: WLM (prefer local)'], ['Kaynak tanımı', 'Cluster scope\'ta tanımlanan kaynaklar tüm üyelerde görünür'], ['Dinamik cluster', 'Yalnızca Intelligent Management ile (bu simülasyonda statik cluster)']],
      pros: ['Yüksek erişilebilirlik', 'Kapasite artışı', 'Kesintisiz bakım (Ripplestart / Rollout Update)'],
      cons: ['Session replikasyonu yoksa failover\'da oturum kaybı', 'Üyeler arası konfigürasyon farkı (drift) riski', 'Plug-in yeniden üretimi gibi ek operasyon adımları'],
      cmds: ["AdminTask.createCluster('[-clusterConfig [-clusterName BankingCluster -preferLocal true] -replicationDomain [-createDomain true]]')", "AdminTask.createClusterMember('[-clusterName BankingCluster -memberConfig [-memberNode AppNode01 -memberName BankSrv01 -memberWeight 2 -genUniquePorts true] -firstMember [-templateName default]]')", "AdminTask.createClusterMember('[-clusterName BankingCluster -memberConfig [-memberNode AppNode02 -memberName BankSrv02 -memberWeight 2]]')", 'AdminConfig.save()']
    },
    federation: {
      t: 'Federe yapı (federation / addNode)', h: 'arch.federation',
      intro: '<b>Federasyon</b>, standalone bir profilin (veya boş bir custom profilin) <code>addNode.sh</code> ile bir DMGR hücresine katılmasıdır. Federasyondan sonra node artık <b>managed node</b>\'dur: konfigürasyonu DMGR\'nin master repository\'sinde tutulur, bir node agent oluşturulur ve sunucular DMGR\'den yönetilir. Tersi işlem <code>removeNode.sh</code>\'dur. Aşağıdaki simülatörle süreci adım adım izleyebilirsiniz.',
      diagram: function () { return fedSim(); },
      table: [['Komut', 'addNode.sh <dmgr_host> <dmgr_SOAP_port> [-includeapps] [-includebuses] [-username -password]'], ['Kaynak profil', 'Application server profili (server1 ile) veya Custom profil (boş node)'], ['Hücre adı', 'Node\'un eski standalone hücresi bırakılır; node DMGR\'nin hücresine (WASPRODCell01) katılır'], ['Uygulamalar', 'Varsayılan olarak taşınmaz; -includeapps ile mevcut uygulamalar da DMGR\'ye aktarılır'], ['Yedek', 'Orijinal standalone konfigürasyon yedeklenir; removeNode.sh bu yedeği geri yükler'], ['Önkoşullar', 'DMGR çalışıyor olmalı, SOAP portu (8879) erişilebilir, node adı hücrede benzersiz, saatler senkron (±5 dk), sürüm DMGR ≥ node']],
      pros: ['Mevcut standalone sunucuları merkezi yönetime alma', 'Custom profil + addNode ile yeni makineleri hızla hücreye ekleme', 'Federasyon sonrası cluster üyeliği ve hücre kaynaklarına erişim'],
      cons: ['removeNode ile ayrılınca federe süre boyunca yapılan konfigürasyon node\'a geri gelmez (eski yedek geri yüklenir)', 'Saat farkı, güvenlik/SSL uyumsuzluğu veya port erişimi federasyonu başarısız kılar', 'Standalone sunucunun kendi admin konsolu federasyondan sonra kaldırılır'],
      cmds: ['# Uygulama makinesinde (node tarafında) çalıştırılır:', '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/addNode.sh was-dmgr01.corp.local 8879 \\', '     -includeapps -username wasadmin -password ****', '', '# Beklenen çıktı (özet):', 'ADMU0001I: Begin federation of node AppNode04 with Deployment Manager at was-dmgr01.corp.local:8879.', 'ADMU0009I: Successfully connected to Deployment Manager Server: was-dmgr01.corp.local:8879', 'ADMU0505I: Servers found in configuration:', 'ADMU0506I: Server name: server1', 'ADMU2010I: Stopping all server processes for node AppNode04', 'ADMU0024I: Deleting the old backup directory.', 'ADMU0015I: Backing up the original cell repository.', 'ADMU0012I: Creating Node Agent configuration for node: AppNode04', 'ADMU0014I: Adding node AppNode04 configuration to cell: WASPRODCell01', 'ADMU0016I: Synchronizing configuration between node and cell.', 'ADMU0018I: Launching Node Agent process for node: AppNode04', 'ADMU0003I: Node AppNode04 has been successfully federated.', '', '# Node\'u hücreden ayırma:', 'profiles/AppSrv01/bin/removeNode.sh -username wasadmin -password ****']
    },
    profiles: {
      t: 'Profil türleri', h: 'arch.profiles',
      intro: 'WAS traditional\'da ürün ikili dosyaları (<code>/opt/IBM/WebSphere/AppServer</code>) bir kez kurulur; çalışma zamanı ortamları ise <b>profil</b> olarak oluşturulur (<code>manageprofiles.sh</code> veya Profile Management Tool). Her profilin kendi konfigürasyonu, logları ve portları vardır; aynı kurulumda birden çok profil olabilir.',
      diagram: function () {
        var rows = [['Application server', 'default', 'Standalone server1 (Base mimarisi); sonradan federe edilebilir', 'arch.standalone'], ['Management – Deployment manager', 'management (-serverType DEPLOYMENT_MANAGER)', 'ND hücresinin DMGR\'si', 'concept.dmgr'], ['Custom (managed node)', 'managed', 'Boş node; addNode ile federe edilip sunucular DMGR\'den oluşturulur', 'arch.federation'], ['Cell (DMGR + node)', 'cell (dmgr + managed çifti)', 'Tek makinede DMGR ve federe bir node\'u birlikte oluşturur (test/POC)', 'arch.nd'], ['Management – Administrative agent', 'management (-serverType ADMIN_AGENT)', 'Base profillerini tek noktadan yönetir', 'sys.adminAgent'], ['Management – Job manager', 'management (-serverType JOB_MANAGER)', 'Birden çok DMGR/admin agent için asenkron iş yönetimi', 'sys.jobManager'], ['Secure proxy', 'secureproxy', 'DMZ için güvenli proxy sunucusu (ND)', 'srv.proxy']];
        return W.simpleTable(['Profil türü', 'Şablon (template)', 'Kullanım', ''], rows.map(function (r) { return ['<b>' + esc(r[0]) + '</b>', '<code>' + esc(r[1]) + '</code>', esc(r[2]), W.hi(r[3])]; })) +
          '<div class="note-tr">Bu simülasyonda: was-dmgr01 üzerinde <b>Dmgr01</b> (management), was-app01/02/03 üzerinde <b>AppSrv01</b> (custom, federe). IHS makinelerinde WAS profili yoktur (unmanaged node).</div>';
      },
      table: [['Profil listesi', 'bin/manageprofiles.sh -listProfiles'], ['Profil kayıt dosyası', '${WAS_INSTALL_ROOT}/properties/profileRegistry.xml'], ['Profil silme', 'manageprofiles.sh -delete -profileName AppSrv01 (önce removeNode)']],
      pros: ['Tek kurulumdan birden çok bağımsız ortam', 'Fix pack bir kez kurulur, tüm profilleri etkiler'],
      cons: ['Fix pack tüm profilleri aynı anda etkiler (ayrı sürüm için ayrı kurulum gerekir)', 'Aynı makinedeki profillerin port çakışmaları planlanmalıdır'],
      cmds: ['bin/manageprofiles.sh -create -profileName AppSrv02 -templatePath .../profileTemplates/managed -nodeName AppNode04 -hostName was-app04.corp.local', 'bin/manageprofiles.sh -listProfiles']
    },
    flexible: {
      t: 'Esnek yönetim: Administrative agent ve Job manager', h: 'arch.flexible',
      intro: '<b>Flexible management</b>, DMGR\'nin sağladığı sıkı (senkron) yönetim yerine gevşek bağlı, ölçeklenebilir bir yönetim modelidir. <b>Administrative agent</b>, aynı makinedeki birden çok Base profilini tek konsoldan yönetir. <b>Job manager</b>, birden çok DMGR hücresine ve admin agent\'a "job" (iş) göndererek uzak/çok sayıda ortamı asenkron yönetir.',
      diagram: function () {
        return cell('Job manager: jobmgr01 (was-jm01)',
          node('DMGR hücresi', 'WASPRODCell01', proc('dm', 'dmgr', 'registerWithJobManager', 'concept.dmgr'), 'concept.cell', ['ND', 'cell']) +
          node('Admin agent', 'şube sunucusu', proc('', 'adminagent', 'registerNode ile kayıtlı', 'sys.adminAgent') + proc('cl-none', 'Base profil 1 – server1', '') + proc('cl-none', 'Base profil 2 – server1', ''), 'sys.adminAgent', ['flexible', 'node']), 'sys.jobManager', '#16a085') +
          '<div class="note-tr">Job örnekleri: Install application, Start server, Distribute file, Run wsadmin script. Job\'lar hedefler çevrimdışıysa sıraya alınır ve tekrar bağlandıklarında çalıştırılır. Bu hücre jobmgr01\'e kayıtlıdır: <a href="#/sys/jobmanager">Job manager</a>.</div>';
      },
      table: [['Admin agent kaydı', 'profiles/<base>/bin/registerNode.sh -profilePath <agent profil> ...'], ['DMGR\'yi job manager\'a kaydetme', "AdminTask.registerWithJobManager('[-host was-jm01.corp.local -port 9943 -managedNodeName WASPRODCell01]')"], ['Uygun senaryo', 'Çok sayıda şube/uzak lokasyon, yüzlerce Base sunucu, birden çok hücre'], ['Not', 'Admin agent ve DMGR aynı node\'u aynı anda yönetemez']],
      pros: ['Yüzlerce sunucu/hücreye ölçeklenir', 'Ağ kesintilerine dayanıklı (asenkron job kuyruğu)'],
      cons: ['Cluster/WLM sağlamaz (yalnızca yönetim)', 'Ek profil ve operasyon karmaşıklığı'],
      cmds: ['profiles/AdminAgent01/bin/startServer.sh adminagent', 'profiles/AppSrv01/bin/registerNode.sh -profilePath /opt/IBM/WebSphere/AppServer/profiles/AdminAgent01 -username wasadmin -password ****']
    }
  };
  var ORDER = ['standalone', 'nd', 'dmgr', 'nodeagent', 'cluster', 'federation', 'profiles', 'flexible'];
  function fb(t, s, h) { return '<div class="fb" data-help="' + h + '"><b>' + esc(t) + '</b><small>' + esc(s) + '</small></div>'; }
  function fa() { return '<div class="fa">➜</div>'; }

  /* ------------------------------------------------- federasyon simülatörü */
  W._fed = W._fed || { step: 0, includeApps: true };
  var FED = [
    ['Başlangıç: standalone profil', 'was-app04 üzerinde AppSrv04 profili, kendi standalone hücresi (was-app04Node01Cell) ile çalışıyor. server1\'in kendi admin konsolu var; DMGR\'den habersiz.', 'ADMU0116I: Tool information is being logged in file .../logs/addNode.log'],
    ['addNode.sh çalıştırılır', 'Node tarafında: <code>addNode.sh was-dmgr01.corp.local 8879' + ' -includeapps</code>. Araç DMGR\'nin SOAP portuna bağlanır, kimlik doğrular, sürüm ve node adı benzersizliğini kontrol eder.', 'ADMU0001I: Begin federation of node AppNode04 with Deployment Manager at was-dmgr01.corp.local:8879.\nADMU0009I: Successfully connected to Deployment Manager Server: was-dmgr01.corp.local:8879'],
    ['Sunucular durdurulur ve yerel konfigürasyon yedeklenir', 'Çalışan server1 durdurulur; orijinal standalone konfigürasyon yedeklenir (removeNode bu yedeğe döner).', 'ADMU2010I: Stopping all server processes for node AppNode04\nADMU0015I: Backing up the original cell repository.\nADMU0510I: Server server1 is now STOPPED'],
    ['Node konfigürasyonu hücreye eklenir', 'Node\'un konfigürasyonu DMGR master repository\'sine (cells/WASPRODCell01/nodes/AppNode04) yüklenir. -includeapps seçildiyse uygulamalar da hücreye aktarılır. server1\'in standalone admin konsolu kaldırılır.', 'ADMU0014I: Adding node AppNode04 configuration to cell: WASPRODCell01\nADMU0510I: Server server1 is now STOPPED'],
    ['Node agent oluşturulur ve senkronizasyon yapılır', 'Node için nodeagent konfigürasyonu oluşturulur; master repository ile ilk tam senkronizasyon yapılır.', 'ADMU0012I: Creating Node Agent configuration for node: AppNode04\nADMU0016I: Synchronizing configuration between node and cell.'],
    ['Node agent başlatılır – federasyon tamam', 'Node agent başlar ve DMGR\'ye kaydolur. Node artık managed: konsolda Nodes listesinde görünür, sunucular DMGR\'den başlatılır, cluster üyesi yapılabilir.', 'ADMU0018I: Launching Node Agent process for node: AppNode04\nADMU0020I: Reading configuration for Node Agent process: nodeagent\nADMU0003I: Node AppNode04 has been successfully federated.']
  ];
  function fedSim() {
    var st = W._fed.step, done = function (i) { return st >= i; };
    var left = node('AppNode04 (was-app04)', done(3) ? 'AppSrv04 profili – <b>managed</b>' : 'AppSrv04 profili – standalone',
      (done(5) ? proc('na', 'nodeagent', 'çalışıyor', 'concept.nodeAgent') : done(4) ? proc('na', 'nodeagent', 'oluşturuldu (kapalı)', 'concept.nodeAgent') : '') +
      proc('cl-none', 'server1', done(2) ? (done(5) ? 'Stopped – DMGR\'den başlatılabilir' : 'Stopped') : 'Started', 'concept.appserver') +
      (done(3) ? '' : proc('dm', 'adminconsole (server1 içinde)', 'yerel konsol', 'concept.wsadmin')) +
      repo(done(3) ? 'Yerel kopya ← master repository (sync)' : 'Kendi hücresi: was-app04Node01Cell') + (done(2) ? repo('Yedek: orijinal standalone konfigürasyon') : ''), 'concept.node', [done(3) ? 'managed' : 'standalone', 'node']);
    var right = node('CellManager01 (was-dmgr01)', 'Dmgr01 – WASPRODCell01', proc('dm', 'dmgr', 'SOAP 8879', 'concept.dmgr') + repo('Master repository: ' + (done(3) ? 'nodes/AppNode04 <b>eklendi</b>' + (W._fed.includeApps ? ' + uygulamalar' : '') : 'AppNode01–03')), 'concept.dmgr', ['DMGR', 'cell']);
    var arrow = '<div class="fa" style="width:60px;font-size:20px">' + (st >= 1 && st < 5 ? '⇄' : st >= 5 ? '⇆' : '·') + '</div>';
    var steps = '<div class="steps-log"><ol>' + FED.map(function (f, i) { return '<li style="' + (i === st ? 'font-weight:bold;color:#12366e' : i < st ? 'color:#1f8a2e' : 'color:#777') + '">' + (i < st ? '✓ ' : i === st ? '▶ ' : '') + esc(f[0]) + '</li>'; }).join('') + '</ol></div>';
    var cur = FED[st];
    return '<div class="portlet"><div class="ph"><span>Federasyon simülatörü – addNode adım adım' + '</span></div><div class="pb">' +
      '<div class="topo-row" style="align-items:stretch">' + left + arrow + right + '</div>' +
      '<div class="detail" style="margin-top:10px"><div class="gp"><b>Adım ' + (st + 1) + '/' + FED.length + ': ' + esc(cur[0]) + '</b><p>' + cur[1] + '</p><pre class="log">' + W.colorLog(cur[2].split('\n').map(function (l) { return '[addNode] ' + l.replace(/^(ADMU\d+)([IWE]):/, '$1$2:'); }).join('\n')) + '</pre>' +
      '<div class="btnrow">' + (st > 0 ? '<button class="btn" data-act="fedStep" data-arg="-1">◀ Önceki</button>' : '') + (st < FED.length - 1 ? '<button class="btn primary" data-act="fedStep" data-arg="1">Sonraki adım ▶</button>' : '<button class="btn primary" data-act="fedStep" data-arg="reset">Baştan başla</button>') +
      '<label class="ck-line" style="margin:0 0 0 10px"><input type="checkbox" data-change="fedApps"' + (W._fed.includeApps ? ' checked' : '') + '> -includeapps' + W.hi('arch.federation') + '</label></div></div><div class="ap">' + steps + '</div></div></div></div>' +
      '<div class="cards"><div class="card"><h4>removeNode ne yapar?' + W.hi('arch.federation') + '</h4><p>Node agent\'ı durdurur, node\'u hücreden çıkarır ve addNode sırasında alınan <b>orijinal standalone yedeğini geri yükler</b>. Federe süre boyunca o node için yapılan değişiklikler (yeni sunucular, kaynaklar) geri gelmez. DMGR erişilemezse son çare: <code>cleanupNode.sh</code> (DMGR tarafı) + <code>removeNode.sh -force</code>.</p></div>' +
      '<div class="card"><h4>Sık federasyon hataları</h4><p>• ADMU0006E: DMGR\'ye bağlanılamadı (host/port/güvenlik duvarı)<br>• Node adı hücrede zaten var (federasyon geri alınır)<br>• Saat farkı > 5 dk: güvenlik/LTPA hataları<br>• SSL signer güvenilmiyor: soap.client.props / trust store<br>• Node sürümü DMGR\'den yeni olamaz</p></div></div>';
  }
  A.fedStep = function (el) { var a = el.dataset.arg; W._fed.step = a === 'reset' ? 0 : Math.max(0, Math.min(FED.length - 1, W._fed.step + (+a))); W.rerender(); };
  W.onChange.fedApps = function (e) { W._fed.includeApps = e.checked; W.rerender(); };

  /* -------------------------------------------------------------- sayfa */
  R('/learn/architecture', function (p, q) {
    var k = ARCH[q.type] ? q.type : (W.UI.archType && ARCH[W.UI.archType] ? W.UI.archType : 'standalone');
    W.UI.archType = k;
    var a = ARCH[k];
    var tabs = '<div class="tabs">' + ORDER.map(function (x) { return '<a href="#/learn/architecture?type=' + x + '"' + (x === k ? ' class="on"' : '') + '>' + esc(ARCH[x].t.replace(/ \(.*\)| –.*/, '')) + '</a>'; }).join('') + '</div>';
    var comp = W.simpleTable(['', 'Standalone (Base)', 'Network Deployment'], [
      ['Merkezi yönetim (DMGR)', '✘ (her sunucu kendi konsolu)', '✔ tek konsol'], ['Node agent', '✘', '✔ her managed node\'da'], ['Cluster / WLM', '✘', '✔'], ['Session failover', '✘', '✔ (DB / memory-to-memory)'], ['HA Manager (ME, tranlog failover)', '✘', '✔'], ['Konfigürasyon deposu', 'Profilde tek kopya', 'Master repository + node kopyaları'], ['Süreç sayısı', '1 JVM', 'dmgr + node agent\'lar + sunucular'], ['Tipik kullanım', 'Geliştirme, test, küçük uygulama', 'Üretim, yüksek erişilebilirlik'], ['Büyüme yolu', 'addNode ile ND hücresine federe edilebilir (ND lisansı ile)', 'Node/cluster üyesi ekleyerek yatay ölçekleme']
    ].map(function (r) { return ['<b>' + esc(r[0]) + '</b>', esc(r[1]), esc(r[2])]; }));
    var html = '<div class="page-title">IBM WAS mimari yapıları' + W.hi('arch.overview') + '</div>' +
      '<p class="desc">IBM WebSphere Application Server traditional farklı ölçek ve erişilebilirlik ihtiyaçları için farklı topolojilerle kurulabilir. Sekmelerden bir yapı seçin; her birinde diyagram, temel özellikler, avantaj/sınırlamalar ve gerçek komut örnekleri yer alır. Diyagramdaki <span class="hi" style="cursor:default">?</span> simgeleri ilgili kavramın ayrıntılı açıklamasını açar.</p>' +
      tabs + '<h3 style="font-size:13px;margin:6px 0 4px" class="inline-flex">' + esc(a.t) + W.hi(a.h) + '</h3><p class="desc">' + a.intro + '</p>' +
      a.diagram() +
      '<div class="sect-title" style="margin-top:12px">Temel özellikler</div>' + cmp(a.table.map(function (r) { return [r[0], esc(r[1])]; })) +
      proscons(a.pros, a.cons) + cmdBox('Komut / betik örnekleri', a.cmds) +
      '<div class="sect-title" style="margin-top:16px">Karşılaştırma: Standalone ve Network Deployment' + W.hi('arch.nd') + '</div>' + comp +
      '<div class="cards" style="margin-top:12px"><div class="card"><h4>Hangi yapıyı seçmeliyim?</h4><p>• Geliştirici makinesi / tek uygulama / kesinti tolere edilebilir → <b>Standalone</b><br>• Üretim, 7/24 erişim, yük artışı → <b>ND + horizontal cluster</b><br>• Mevcut standalone sunucuları merkezileştirme → <b>addNode ile federasyon</b><br>• Çok sayıda şube/uzak Base sunucusu → <b>Admin agent + Job manager</b></p></div>' +
      '<div class="card"><h4>Tipik kurumsal üretim yapısı</h4><p>F5 → 2+ IHS (unmanaged node) → ND hücresi: 1 DMGR + 3 managed node, her uygulama için horizontal cluster (node başına 1–2 üye), memory-to-memory session replikasyonu, paylaşımlı tranlog. Bu simülasyonun yapısı budur: <a href="#/learn/topology">Hücre topolojisi</a>.</p></div></div>';
    return { title: 'WAS mimari yapıları', help: 'arch.overview', html: html };
  });
})();
