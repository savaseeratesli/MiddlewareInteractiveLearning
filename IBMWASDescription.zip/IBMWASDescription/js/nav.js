/* nav.js – Sol navigasyon ağacı (WAS 9.0 ISC "All tasks" görünümüne göre) */
(function () {
  var W = window.WAS;
  W.NAV = [
    { g: 'WAS Öğrenme Merkezi', learning: true, open: true, view: 'learn', items: [
      { t: 'Öğrenme merkezi ana sayfası', h: '#/learn' },
      { t: 'Mimari yapılar (Standalone, ND, federasyon...)', h: '#/learn/architecture' },
      { t: 'Hücre topolojisi (Cell / Node / Server)', h: '#/learn/topology' },
      { t: 'İstek akışı: F5 → IHS → Plugin → WAS', h: '#/learn/requestflow' },
      { t: 'Cluster, WLM, failover ve session replikasyonu', h: '#/learn/cluster' },
      { t: 'Yapılandırma seviyeleri (scope) ve değişkenler', h: '#/learn/scope' },
      { t: 'Log dosyaları ve hata senaryoları', h: '#/learn/troubleshooting' },
      { t: 'Kavram sözlüğü', h: '#/learn/glossary' }
    ] },
    { g: 'Guided Activities', view: 'learn', items: [
      { t: 'Connecting to a database', h: '#/guided/database' },
      { t: 'Routing requests through a Web server to an application server', h: '#/guided/webserver' }
    ] },
    { g: 'Servers', view: 'servers', open: true, items: [
      { g: 'Server Types', open: true, items: [
        { t: 'WebSphere application servers', h: '#/servers/appservers' },
        { t: 'WebSphere proxy servers', h: '#/servers/proxy' },
        { t: 'Generic servers', h: '#/servers/generic' },
        { t: 'WebSphere MQ servers', h: '#/servers/mq' },
        { t: 'Web servers', h: '#/servers/webservers' }
      ] },
      { g: 'Clusters', items: [
        { t: 'WebSphere application server clusters', h: '#/clusters' },
        { t: 'Cluster topology', h: '#/clusters/topology' }
      ] },
      { g: 'Core Groups', items: [
        { t: 'Core group settings', h: '#/coregroups' },
        { t: 'Core group bridge settings', h: '#/coregroupbridge' }
      ] }
    ] },
    { g: 'Applications', view: 'apps', open: true, items: [
      { t: 'New Application', h: '#/apps/new' },
      { g: 'Application Types', open: true, items: [
        { t: 'WebSphere enterprise applications', h: '#/apps' },
        { t: 'Business-level applications', h: '#/apps/bla' },
        { t: 'Assets', h: '#/apps/assets' }
      ] },
      { t: 'Global deployment settings', h: '#/apps/global' }
    ] },
    { g: 'Services', view: 'apps', items: [
      { t: 'Service providers', h: '#/services/providers' },
      { t: 'Service clients', h: '#/services/clients' },
      { g: 'Policy sets', items: [{ t: 'Application policy sets', h: '#/services/policysets' }] }
    ] },
    { g: 'Resources', view: 'res', items: [
      { t: 'Schedulers', h: '#/res/schedulers' },
      { g: 'JMS', items: [
        { t: 'JMS providers', h: '#/res/jms/providers' },
        { t: 'Connection factories', h: '#/res/jms/cf' },
        { t: 'Queue connection factories', h: '#/res/jms/qcf' },
        { t: 'Topic connection factories', h: '#/res/jms/tcf' },
        { t: 'Queues', h: '#/res/jms/queues' },
        { t: 'Topics', h: '#/res/jms/topics' },
        { t: 'Activation specifications', h: '#/res/jms/as' }
      ] },
      { g: 'JDBC', items: [
        { t: 'JDBC providers', h: '#/res/jdbc/providers' },
        { t: 'Data sources', h: '#/res/jdbc/ds' }
      ] },
      { g: 'Resource Adapters', items: [
        { t: 'Resource adapters', h: '#/res/ra' },
        { t: 'J2C connection factories', h: '#/res/j2ccf' }
      ] },
      { g: 'Asynchronous beans', items: [
        { t: 'Work managers', h: '#/res/wm' },
        { t: 'Timer managers', h: '#/res/tm' }
      ] },
      { g: 'Mail', items: [
        { t: 'Mail providers', h: '#/res/mailproviders' },
        { t: 'Mail sessions', h: '#/res/mail' }
      ] },
      { g: 'URL', items: [
        { t: 'URL providers', h: '#/res/urlproviders' },
        { t: 'URLs', h: '#/res/urls' }
      ] },
      { g: 'Resource Environment', items: [
        { t: 'Resource environment providers', h: '#/res/reprov' },
        { t: 'Resource environment entries', h: '#/res/reentries' }
      ] }
    ] },
    { g: 'Security', view: 'sec', items: [
      { t: 'Global security', h: '#/sec/global' },
      { t: 'Security domains', h: '#/sec/domains' },
      { t: 'Administrative Authorization Groups', h: '#/sec/authgroups' },
      { t: 'SSL certificate and key management', h: '#/sec/ssl' },
      { t: 'Security auditing', h: '#/sec/audit' },
      { t: 'Bus security', h: '#/sec/bus' }
    ] },
    { g: 'Environment', view: 'env', items: [
      { t: 'Virtual hosts', h: '#/env/vhosts' },
      { t: 'Update global Web server plug-in configuration', h: '#/env/globalplugin' },
      { t: 'WebSphere variables', h: '#/env/variables' },
      { t: 'Shared libraries', h: '#/env/sharedlibs' },
      { t: 'Replication domains', h: '#/env/replication' },
      { g: 'Naming', items: [
        { t: 'Name space bindings', h: '#/env/namebindings' }
      ] }
    ] },
    { g: 'System administration', view: 'sys', items: [
      { t: 'Cell', h: '#/sys/cell' },
      { t: 'Save changes to master repository', h: '#/save' },
      { t: 'Deployment manager', h: '#/sys/dmgr' },
      { t: 'Nodes', h: '#/sys/nodes' },
      { t: 'Node agents', h: '#/sys/nodeagents' },
      { t: 'Node groups', h: '#/sys/nodegroups' },
      { t: 'Middleware servers', h: '#/sys/middleware' },
      { t: 'Administrative agents', h: '#/sys/adminagent' },
      { t: 'Job manager', h: '#/sys/jobmanager' },
      { t: 'Console Preferences', h: '#/sys/prefs' },
      { t: 'Console Identity', h: '#/sys/identity' },
      { t: 'Extended Repository Service', h: '#/sys/ers' }
    ] },
    { g: 'Users and Groups', view: 'sec', items: [
      { t: 'Administrative user roles', h: '#/ug/userroles' },
      { t: 'Administrative group roles', h: '#/ug/grouproles' },
      { t: 'Manage Users', h: '#/ug/users' },
      { t: 'Manage Groups', h: '#/ug/groups' }
    ] },
    { g: 'Monitoring and Tuning', view: 'mon', items: [
      { g: 'Performance Viewer', open: true, items: [{ t: 'Current activity', h: '#/mon/tpv' }] },
      { t: 'Performance Monitoring Infrastructure (PMI)', h: '#/mon/pmi' },
      { t: 'Request metrics', h: '#/mon/rm' },
      { t: 'Performance and Diagnostic Advisor Configuration', h: '#/mon/advisors' }
    ] },
    { g: 'Troubleshooting', view: 'mon', items: [
      { t: 'Logs and trace', h: '#/tr/logs' },
      { t: 'Configuration problems', h: '#/tr/config' },
      { t: 'Class loader viewer', h: '#/tr/classloader' }
    ] },
    { g: 'Service integration', view: 'res', items: [
      { t: 'Buses', h: '#/sib/buses' }
    ] },
    { g: 'UDDI', view: 'apps', items: [
      { t: 'UDDI Nodes', h: '#/uddi' }
    ] }
  ];
})();
