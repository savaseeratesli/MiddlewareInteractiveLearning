/* pages-apps.js – Applications: enterprise applications, kurulum (install)
   sihirbazı, güncelleme, kaldırma, modül/hedef eşlemeleri, class loading,
   güvenlik rol eşlemesi, BLA, assets, services. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };

  /* ---------------------------------------------------------- list */
  R('/apps', function () {
    return {
      title: 'Enterprise Applications', help: 'concept.enterpriseApp',
      html: '<div class="page-title">Enterprise Applications' + W.hi('concept.enterpriseApp') + '</div><p class="desc">Use this page to manage installed applications. A single application can be deployed onto multiple servers.</p>' + W.prefs() +
        W.table({ id: 'apps', rows: W.S.apps, key: function (r) { return r.name; },
          cols: [{ k: 'name', l: 'Name', fmt: function (r) { return W.appLink(r.name); } }, { k: 'st', l: 'Application Status', sv: function (r) { return W.appStatus(r); }, fmt: function (r) { return W.stIcon(W.appStatus(r), ''); }, h: 'app.status' }],
          buttons: [{ l: 'Start', act: 'appStart', need: 1 }, { l: 'Stop', act: 'appStop', need: 1 }, { l: 'Install', href: '#/wz/installApp' }, { l: 'Uninstall', act: 'appUninstall', need: 1 }, { l: 'Update', act: 'appUpdate', need: 1 }, { l: 'Rollout Update', act: 'appRollout', need: 1 }, { l: 'Remove File', act: 'notInSim', arg: 'Remove File' }, { l: 'Export', act: 'appExport', need: 1 }, { l: 'Export DDL', act: 'notInSim', arg: 'Export DDL' }, { l: 'Export File', act: 'notInSim', arg: 'Export File' }], btnHelp: 'app.ops' }) +
        '<div class="note-tr">Durum simgeleri: ' + W.stIcon('started') + ' tüm hedef sunucularda çalışıyor · ' + W.stIcon('partial') + ' hedeflerin bir kısmında çalışıyor (ör. bir cluster üyesi kapalı) · ' + W.stIcon('stopped') + ' hiçbir hedefte çalışmıyor · ' + W.stIcon('unknown') + ' node agent erişilemediği için durum bilinmiyor.</div>'
    };
  });
  function appMsgs(a, start) {
    var out = [];
    W.targetServers(a).forEach(function (s) {
      if (W.serverStatus(s) === 'started') out.push('The application ' + esc(a.name) + ' on server ' + esc(s.name) + ' and node ' + esc(s.node) + ' has ' + (start ? 'started' : 'stopped') + ' successfully.');
      else out.push('<span style="color:#b26a00">' + esc(s.name) + ' (' + esc(s.node) + ') çalışmadığı için uygulama bu hedefte ' + (start ? 'başlatılamadı' : 'zaten durmuş durumda') + '.</span>');
    });
    return out;
  }
  A.appStart = function (el) {
    var m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      var a = W.app(n); a.state = 'started'; m = m.concat(appMsgs(a, true));
      W.cmd('Uygulama başlat: ' + n, W.targetServers(a).map(function (s) { return "AdminControl.invoke(AdminControl.queryNames('type=ApplicationManager,node=" + s.node + ",process=" + s.name + ",*'), 'startApplication', '" + n + "')"; }));
    });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  A.appStop = function (el) {
    var m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      var a = W.app(n); a.state = 'stopped'; m = m.concat(appMsgs(a, false));
      W.cmd('Uygulama durdur: ' + n, W.targetServers(a).map(function (s) { return "AdminControl.invoke(AdminControl.queryNames('type=ApplicationManager,node=" + s.node + ",process=" + s.name + ",*'), 'stopApplication', '" + n + "')"; }));
    });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  A.appUninstall = function (el) {
    var sel = W.selected(el.dataset.tbl);
    W.modal({ title: 'Uninstall Application', html: '<p>Uninstall the following applications?</p><ul>' + sel.map(function (s) { return '<li><b>' + esc(s) + '</b></li>'; }).join('') + '</ul><p class="note-tr">Uygulama tüm hedeflerden (cluster/server) ve web server eşlemelerinden kaldırılır. Kaydettikten sonra node senkronizasyonunda <code>installedApps</code> altındaki dosyalar silinir.' + W.hi('app.uninstall') + '</p>',
      buttons: [{ l: 'OK', fn: function () {
        var m = [];
        sel.forEach(function (n) {
          var a = W.app(n); W.S.apps.splice(W.S.apps.indexOf(a), 1);
          m.push('ADMA5017I: Uninstallation of ' + esc(n) + ' started.', 'ADMA5104I: The server index entry for ' + esc(W.targetLabel(a.targets[0])) + ' is updated successfully.', 'ADMA5106I: Application ' + esc(n) + ' uninstalled successfully.');
          W.change('cells/' + CELL() + '/applications/' + n + '.ear/', 'Uygulama kaldırıldı: ' + n);
          W.cmd('Uygulama kaldır: ' + n, ["AdminApp.uninstall('" + n + "')", 'AdminConfig.save()']);
        });
        m.push('Application uninstalled successfully. Değişiklikleri kaydedin ve plug-in yapılandırmasını yeniden üretip yayın.');
        W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.appUpdate = function (el) {
    var n = W.selected(el.dataset.tbl)[0], a = W.app(n);
    W.modal({ title: 'Preparing for the application update – ' + n, html: '<p class="desc">Specify the EAR, WAR, JAR, or SAR module to upload and install.</p><form id="updF" onsubmit="return false">' +
      F.radio({ l: 'Application update options', n: 'op', v: 'full', h: 'app.update', o: [['full', 'Replace the entire application'], ['module', 'Replace or add a single module'], ['partial', 'Replace, add, or delete multiple files'], ['file', 'Replace or add a single file']] }) +
      F.text({ l: 'Path to the new application (simüle edilmiş dosya)', n: 'path', v: '/tmp/deploy/' + a.ear.replace('.ear', '-' + bump(a.version) + '.ear'), h: 'app.update' }) + '</form>',
      buttons: [{ l: 'Next → Update', fn: function () {
        var v = W.readForm(document.getElementById('updF')).vals, old = a.version;
        a.version = bump(a.version); a.installed = new Date().toLocaleString('sv-SE').slice(0, 16);
        W.change('cells/' + CELL() + '/applications/' + n + '.ear/', 'Uygulama güncellendi: ' + n + ' ' + old + ' → ' + a.version);
        W.cmd('Uygulama güncelle: ' + n, ["AdminApp.update('" + n + "', 'app', '[-operation update -contents " + v.path + " -usedefaultbindings -nodeployejb]')", 'AdminConfig.save()']);
        W.msg('info', ['ADMA5009I: An application archive is extracted at /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/wstemp/app_' + Date.now().toString(16) + '/ext', 'ADMA5005I: The application ' + esc(n) + ' is configured in the WebSphere Application Server repository.', 'Application ' + esc(n) + ' updated successfully (' + old + ' → ' + a.version + '). Güncelleme, kaydedip senkronize ettiğinizde hedef sunuculara dağıtılır; uygulama varsayılan olarak yeniden başlatılır. Kesintisiz güncelleme için <b>Rollout Update</b> kullanın.']);
        W.clearSel(el.dataset.tbl); W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.appRollout = function (el) {
    var n = W.selected(el.dataset.tbl)[0], a = W.app(n), ss = W.targetServers(a);
    a.version = bump(a.version);
    W.saveMaster();
    var t = 0;
    ss.forEach(function (s) { if (W.serverStatus(s) !== 'started') return; setTimeout(function () { W.serverOp([s.name], 'restart', true); W.liveRefresh(); }, t); t += 4800; });
    setTimeout(function () { W.msg('info', 'Rollout Update tamamlandı: ' + esc(n) + ' ' + a.version + ' tüm üyelerde çalışıyor.'); W.liveRefresh(); }, t + 600);
    W.cmd('Rollout update: ' + n, ["AdminApp.update('" + n + "', 'app', '[-operation update -contents /tmp/deploy/" + a.ear + "]')", 'AdminConfig.save()', "AdminTask.updateAppOnCluster('[-ApplicationNames " + n + " -timeout 600]')"]);
    W.clearSel(el.dataset.tbl);
    W.msg('info', ['Rollout Update başlatıldı: değişiklikler kaydedildi, node\'lar senkronize ediliyor ve ' + ss.map(function (s) { return esc(s.name); }).join(' → ') + ' sırayla güncellenip yeniden başlatılıyor. Bu sırada diğer üyeler trafiğe hizmet vermeye devam eder.' + W.hi('app.rollout')]);
    W.rerender();
  };
  A.appExport = function (el) {
    var n = W.selected(el.dataset.tbl)[0];
    W.cmd('Uygulama dışa aktar', ["AdminApp.export('" + n + "', '/tmp/export/" + n + ".ear')"]);
    W.modal({ title: 'Export Application', html: '<p><b>' + esc(n) + '.ear</b> dışa aktarma bağlantısı oluşturuldu.</p><p class="note-tr">Bu eğitim simülasyonunda gerçek bir EAR dosyası indirilmez. Gerçek ortamda dışa aktarılan EAR, kurulum sırasında yapılan bağlama (binding) bilgilerini de içerir.</p>' });
  };
  function bump(v) { var p = String(v).split('.'); p[p.length - 1] = (+p[p.length - 1] || 0) + 1; return p.join('.'); }

  /* ---------------------------------------------------------- new / install */
  R('/apps/new', function () {
    return { title: 'New Application', help: 'app.install', html: '<div class="page-title">New Application</div><p class="desc">Select the type of application that you want to create or install.</p>' +
      '<div class="ap-link"><a href="#/wz/installApp">New Enterprise Application</a>' + W.hi('concept.enterpriseApp') + '</div><div class="ap-link"><a href="#/apps/bla">New Business Level Application</a>' + W.hi('app.bla') + '</div><div class="ap-link"><a href="#/apps/assets">New Asset</a>' + W.hi('app.assets') + '</div>' };
  });
  var SAMPLES = {
    'AccountServiceApp.ear': { name: 'AccountServiceApp', version: '1.0.0', modules: [{ name: 'Account Service Web', uri: 'AccountServiceWeb.war', type: 'web', contextRoot: '/accounts', vhost: 'default_host' }, { name: 'Account Service EJB', uri: 'AccountServiceEJB.jar', type: 'ejb' }], refs: [{ module: 'AccountServiceEJB.jar', ref: 'jdbc/AccountDS', type: 'javax.sql.DataSource' }] },
    'LoanCalculator.war': { name: 'LoanCalculator_war', version: '2.1.0', modules: [{ name: 'LoanCalculator', uri: 'LoanCalculator.war', type: 'web', contextRoot: '/loan', vhost: 'default_host' }], refs: [] },
    'HRPortal.ear': { name: 'HRPortalApp', version: '4.0.2', modules: [{ name: 'HR Portal Web', uri: 'HRPortalWeb.war', type: 'web', contextRoot: '/hr', vhost: 'default_host' }], refs: [{ module: 'HRPortalWeb.war', ref: 'jdbc/HRDS', type: 'javax.sql.DataSource' }] },
    'CampaignApi.war': { name: 'CampaignApi_war', version: '0.9.5', modules: [{ name: 'Campaign API', uri: 'CampaignApi.war', type: 'web', contextRoot: '/campaign/api', vhost: 'default_host' }], refs: [] },
    'ConflictDemo.war (context root /corebank)': { name: 'ConflictDemo_war', version: '1.0.0', modules: [{ name: 'ConflictDemo', uri: 'ConflictDemo.war', type: 'web', contextRoot: '/corebank', vhost: 'default_host' }], refs: [] }
  };
  function targetOptions() {
    var o = [];
    W.S.clusters.forEach(function (c) { o.push(['cluster:' + c.name, W.targetLabel('cluster:' + c.name)]); });
    W.S.servers.filter(function (s) { return !s.cluster; }).forEach(function (s) { o.push(['server:' + s.node + ':' + s.name, W.targetLabel('server:' + s.node + ':' + s.name)]); });
    W.S.webservers.forEach(function (w) { o.push(['webserver:' + w.node + ':' + w.name, W.targetLabel('webserver:' + w.node + ':' + w.name)]); });
    return o;
  }
  W.targetOptions = targetOptions;
  W.wizard('installApp', {
    title: 'Enterprise Applications', help: 'app.install', back: '#/apps', crumbs: [['Enterprise Applications', '#/apps'], 'Install New Application'],
    intro: 'Kurulum sihirbazı EAR/WAR dosyasını DMGR\'ye yükler, deployment descriptor\'ları okur ve hedef eşlemelerini (modül → cluster/server, web modülü → virtual host, kaynak referansı → JNDI) sorar.',
    init: function () { return { file: 'AccountServiceApp.ear', where: 'local', path: 'Fast', name: '', precompile: false, distribute: true, useBinaryConfig: false, deployEjb: false, createMBeans: true, target: 'cluster:BankingCluster', ws1: true, ws2: true, vhost: 'default_host', ctx: '', refmap: 'jdbc/CoreBankDS' }; },
    steps: function (v) {
      var smp = SAMPLES[v.file] || SAMPLES['AccountServiceApp.ear'];
      var st = [
        { t: 'Path to the new application', h: 'app.install', desc: 'Specify the EAR, WAR, JAR, or SAR module to upload and install. (Simülasyon: gerçek dosya yüklenmez; örnek bir arşiv seçin.)', html: function (v2) {
          return F.radio({ l: '', n: 'where', v: v2.where, o: [['local', 'Local file system'], ['remote', 'Remote file system']] }) + F.sel({ l: 'Full path', n: 'file', v: v2.file, o: Object.keys(SAMPLES).map(function (k) { return [k, 'C:\\deploy\\' + k]; }), h: 'app.install' }) +
            F.radio({ l: 'How do you want to install the application?', n: 'path', v: v2.path, h: 'app.fastDetailed', o: [['Fast', 'Fast Path - Prompt only when additional information is required.'], ['Detailed', 'Detailed - Show all installation options and parameters.']] });
        } },
        { t: 'Select installation options', h: 'app.installOptions', html: function (v2) {
          var s2 = SAMPLES[v2.file] || smp;
          return F.ck({ l: 'Precompile JavaServer Pages files', n: 'precompile', v: v2.precompile, h: 'app.precompile' }) + F.text({ l: 'Directory to install application', n: 'dir', v: '${APP_INSTALL_ROOT}/' + CELL(), h: 'app.binaries' }) +
            F.ck({ l: 'Distribute application', n: 'distribute', v: v2.distribute, h: 'app.binaries' }) + F.ck({ l: 'Use Binary Configuration', n: 'useBinaryConfig', v: v2.useBinaryConfig, h: 'app.binaries' }) +
            F.ck({ l: 'Deploy enterprise beans', n: 'deployEjb', v: v2.deployEjb, h: 'concept.ejbContainer' }) + F.text({ l: 'Application name', n: 'name', v: v2.name || s2.name, req: true, h: 'app.name' }) +
            F.ck({ l: 'Create MBeans for resources', n: 'createMBeans', v: v2.createMBeans, h: 'app.startup' }) + F.sel({ l: 'Validate Input off/warn/fail', n: 'validate', v: 'warn', o: ['off', 'warn', 'fail'], h: 'app.validate' });
        }, validate: function (v2) { if (W.app(v2.name)) return ['ADMA0084E: "' + v2.name + '" adlı bir uygulama zaten kurulu. Farklı bir ad verin veya Update kullanın.']; } },
        { t: 'Map modules to servers', h: 'app.mapModules', desc: 'Specify targets such as application servers or clusters of application servers where you want to install the modules that are contained in your application. Web modülleri, web server üzerinden erişilecekse web server\'a da eşlenmelidir.', html: function (v2) {
          var s2 = SAMPLES[v2.file] || smp;
          return F.sel({ l: 'Clusters and servers', n: 'target', v: v2.target, o: targetOptions().filter(function (o) { return o[0].indexOf('webserver') !== 0; }), h: 'app.mapModules' }) +
            W.S.webservers.map(function (w, i) { return F.ck({ l: 'Also map web modules to ' + W.targetLabel('webserver:' + w.node + ':' + w.name), n: 'ws' + (i + 1), v: v2['ws' + (i + 1)] !== false, h: 'ws.appMapping' }); }).join('') +
            W.simpleTable(['Module', 'URI', 'Module type'], s2.modules.map(function (m) { return [esc(m.name), esc(m.uri) + ',WEB-INF/' + (m.type === 'web' ? 'web.xml' : 'ejb-jar.xml'), m.type === 'web' ? 'Web Module' : 'EJB Module']; }));
        } },
        { t: 'Map virtual hosts for Web modules', h: 'concept.vhost', html: function (v2) {
          var s2 = SAMPLES[v2.file] || smp;
          return F.sel({ l: 'Virtual host (all web modules)', n: 'vhost', v: v2.vhost, o: W.S.virtualHosts.map(function (x) { return x.name; }), h: 'concept.vhost' }) + W.simpleTable(['Web module', 'URI'], s2.modules.filter(function (m) { return m.type === 'web'; }).map(function (m) { return [esc(m.name), esc(m.uri)]; }));
        } }
      ];
      if (v.path === 'Detailed') {
        st.push({ t: 'Context root for Web modules', h: 'app.contextRoot', html: function (v2) { var s2 = SAMPLES[v2.file] || smp; var w = s2.modules.filter(function (m) { return m.type === 'web'; })[0]; return F.text({ l: 'Context root (' + w.uri + ')', n: 'ctx', v: v2.ctx || w.contextRoot, h: 'app.contextRoot' }); } });
        if (smp.refs.length) st.push({ t: 'Map resource references to resources', h: 'app.resrefs', html: function (v2) { var s2 = SAMPLES[v2.file] || smp; return W.simpleTable(['Module', 'Resource Reference', 'Resource type'], s2.refs.map(function (r) { return [esc(r.module), esc(r.ref), esc(r.type)]; })) + F.sel({ l: 'Target Resource JNDI Name', n: 'refmap', v: v2.refmap, o: W.S.dataSources.map(function (d) { return d.jndi; }), h: 'app.resrefs' }); } });
      }
      st.push({ t: 'Summary', html: function (v2) {
        var s2 = SAMPLES[v2.file] || smp;
        return '<p>Summary of installation options</p>' + W.kvTable([['Application name', esc(v2.name || s2.name)], ['Archive', esc(v2.file)], ['Precompile JSPs', v2.precompile], ['Distribute application', v2.distribute], ['Target', esc(W.targetLabel(v2.target))], ['Web servers', W.S.webservers.filter(function (w, i) { return v2['ws' + (i + 1)] !== false; }).map(function (w) { return w.name; }).join(', ') || '(none)'], ['Virtual host', esc(v2.vhost)], ['Context root', esc(v2.ctx || s2.modules.filter(function (m) { return m.type === 'web'; })[0].contextRoot)], ['Cell/Node/Server', 'Click here']]);
      } });
      return st;
    },
    finish: function (v) {
      var smp = SAMPLES[v.file] || SAMPLES['AccountServiceApp.ear'];
      var name = v.name || smp.name, mods = W.clone(smp.modules);
      mods.forEach(function (m) { if (m.type === 'web') { m.vhost = v.vhost; if (v.ctx) m.contextRoot = v.ctx; } });
      var targets = [v.target];
      W.S.webservers.forEach(function (w, i) { if (v['ws' + (i + 1)] !== false) targets.push('webserver:' + w.node + ':' + w.name); });
      // Context root çakışması
      var warn = [];
      mods.filter(function (m) { return m.type === 'web'; }).forEach(function (m) {
        W.S.apps.forEach(function (a) { a.modules.forEach(function (x) { if (x.type === 'web' && x.contextRoot === m.contextRoot && x.vhost === m.vhost && a.targets.some(function (t) { return targets.indexOf(t) >= 0; })) warn.push('<span style="color:#b26a00">Uyarı: Context root <b>' + esc(m.contextRoot) + '</b>, ' + esc(a.name) + ' uygulaması tarafından aynı virtual host (' + esc(m.vhost) + ') ve hedefte zaten kullanılıyor. İkinci uygulama başlatılırken <i>SRVE0164E: Web Application ' + esc(m.name) + ' uses the context root ' + esc(m.contextRoot) + ', which is already in use by Web Application ...</i> hatası alınır.</span>'); }); });
      });
      W.S.apps.push({ name: name, version: smp.version, ear: v.file.split(' ')[0], state: 'started', installed: new Date().toLocaleString('sv-SE').slice(0, 16), targets: targets, modules: mods, classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 1, autoStart: true, backgroundApplication: false, sharedLibs: [], reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL(), distribute: v.distribute, useMetadataFromBinaries: v.useBinaryConfig, createMBeansForResources: v.createMBeans, validate: 'warn', roles: [], envEntries: [], resourceRefs: smp.refs.map(function (r) { return Object.assign({ target: v.refmap || 'jdbc/CoreBankDS', auth: 'Container', alias: '' }, r); }) });
      W.change('cells/' + CELL() + '/applications/' + name + '.ear/deployments/' + name + '/deployment.xml', 'Uygulama kuruldu: ' + name);
      var mm = mods.map(function (m) { return "['" + m.name + "' " + m.uri + ',WEB-INF/' + (m.type === 'web' ? 'web.xml' : 'ejb-jar.xml') + ' ' + targets.map(W.targetLabel).join('+') + ']'; }).join(' ');
      W.cmd('Uygulama kur: ' + name, ["AdminApp.install('/tmp/deploy/" + v.file.split(' ')[0] + "', '[-appname " + name + (v.distribute ? ' -distributeApp' : ' -nodistributeApp') + (v.precompile ? ' -preCompileJSPs' : ' -nopreCompileJSPs') + " -MapModulesToServers [" + mm + "] -MapWebModToVH [" + mods.filter(function (m) { return m.type === 'web'; }).map(function (m) { return "['" + m.name + "' " + m.uri + ',WEB-INF/web.xml ' + m.vhost + ']'; }).join(' ') + "]]')", 'AdminConfig.save()']);
      return { msgs: ['ADMA5016I: Installation of ' + esc(name) + ' started.', 'ADMA5058I: Application and module versions are validated with versions of deployment targets.', 'ADMA5005I: The application ' + esc(name) + ' is configured in the WebSphere Application Server repository.', 'ADMA5081I: The bootstrap address for client module is configured in the WebSphere Application Server repository.', 'ADMA5053I: The library references for the installed optional package are created.', 'ADMA5001I: The application binaries are saved in /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/wstemp/' + name + '.ear', 'ADMA5011I: The cleanup of the temp directory for application ' + esc(name) + ' is complete.', 'ADMA5013I: Application ' + esc(name) + ' installed successfully.', '<b>Application ' + esc(name) + ' installed successfully.</b> To start the application, first save changes to the master configuration. (Kaydet → node senkronizasyonu → uygulama hedef sunucularda başlatılır.)'].concat(warn), go: '#/apps' };
    }
  });

  /* ---------------------------------------------------------- detail */
  function appBase(n) { return '#/apps/' + W.enc(n); }
  function appDoc(a) { return 'cells/' + CELL() + '/applications/' + a.name + '.ear/deployments/' + a.name + '/deployment.xml'; }
  function appPage(a, extra, body, help) { return { title: 'Enterprise Applications', help: help || 'concept.enterpriseApp', html: W.crumbs([['Enterprise Applications', '#/apps'], [a.name, appBase(a.name)]].concat(extra || [])) + body }; }
  R('/apps/bla', function () {
    return { title: 'Business-level applications', help: 'app.bla', html: '<div class="page-title">Business-level applications' + W.hi('app.bla') + '</div><p class="desc">Use this page to manage business-level applications. A business-level application is an administrative model that captures the entire semantics of a business application. WAS, her enterprise application kurulumunda aynı adla bir BLA otomatik oluşturur.</p>' +
      W.table({ id: 'bla', rows: W.S.apps, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'd', l: 'Description', fmt: function (r) { return 'Composition unit: WebSphere:cuname=' + esc(r.name); } }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(W.appStatus(r), ''); } }], buttons: [{ l: 'Start', act: 'notInSim', arg: 'BLA start' }, { l: 'Stop', act: 'notInSim', arg: 'BLA stop' }, { l: 'New...', act: 'notInSim', arg: 'New BLA' }, { l: 'Delete', act: 'notInSim', arg: 'Delete BLA' }] }) };
  });
  R('/apps/assets', function () {
    return { title: 'Assets', help: 'app.assets', html: '<div class="page-title">Assets' + W.hi('app.assets') + '</div><p class="desc">Use this page to manage assets. An asset represents at least one binary file that implements business logic (ör. paylaşılan JAR dosyaları, OSGi bundle\'ları).</p>' +
      W.table({ id: 'assets', rows: [{ name: 'ornekbank-commons-2.1.4.jar', type: 'jar', status: 'Installed' }, { name: 'fx-rates-client-1.2.jar', type: 'jar', status: 'Installed' }], key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'type', l: 'Type' }, { k: 'status', l: 'Status' }], buttons: [{ l: 'Import...', act: 'notInSim', arg: 'Import asset' }, { l: 'Delete', act: 'notInSim', arg: 'Delete asset' }, { l: 'Export...', act: 'notInSim', arg: 'Export asset' }] }) };
  });
  W.S_global = { monitorDir: false, dir: '${USER_INSTALL_ROOT}/monitoredDeployableApps', poll: 5 };
  R('/apps/global', function () {
    W.S.globalDeploy = W.S.globalDeploy || { monitorDir: false, monitoredDirectory: '${USER_INSTALL_ROOT}/monitoredDeployableApps', pollingInterval: 5 };
    var g = W.S.globalDeploy;
    return { title: 'Global deployment settings', help: 'app.monitoredDir', html: '<div class="page-title">Global deployment settings</div>' + W.cfgForm({ ref: 'globalDeploy', doc: 'cells/' + CELL() + '/cell.xml', back: '#/apps', title: 'Global deployment settings', general:
      F.ck({ l: 'Monitor directory to automatically deploy applications', n: 'monitorDir', v: g.monitorDir, h: 'app.monitoredDir' }) + F.text({ l: 'Monitored directory', n: 'monitoredDirectory', v: g.monitoredDirectory, h: 'app.monitoredDir' }) + F.num({ l: 'Polling interval', n: 'pollingInterval', v: g.pollingInterval, unit: 'seconds', h: 'app.monitoredDir' }) }) };
  });
  R('/apps/:name', function (p, q) {
    var a = W.app(p.name);
    if (!a) return { title: 'Enterprise Applications', html: 'Uygulama bulunamadı.' };
    var b = appBase(a.name), hasWeb = a.modules.some(function (m) { return m.type === 'web'; });
    var general = F.ro({ l: 'Name', v: a.name, h: 'app.name' }) + F.ro({ l: 'Application Status', v: W.stIcon(W.appStatus(a)), raw: true, h: 'app.status' }) + F.ro({ l: 'Application version (EAR manifest)', v: a.version, h: 'app.version' }) +
      F.ro({ l: 'Deployment targets', v: a.targets.map(function (t) { return esc(W.targetShort(t)); }).join('<br>'), raw: true, h: 'app.mapModules' }) +
      F.ro({ l: 'Context roots', v: a.modules.filter(function (m) { return m.type === 'web'; }).map(function (m) { return '<code>' + esc(m.contextRoot) + '</code> (' + esc(m.uri) + ', ' + esc(m.vhost) + ')'; }).join('<br>') || '(web modülü yok)', raw: true, h: 'app.contextRoot' }) +
      F.ro({ l: 'Classloader mode / WAR policy', v: (a.classloaderMode === 'PARENT_LAST' ? 'Parent last' : 'Parent first') + ' / ' + (a.warPolicy === 'SINGLE' ? 'Single class loader for application' : 'Class loader for each WAR file'), h: 'concept.classloader' }) +
      F.ro({ l: 'Shared libraries', v: a.sharedLibs.join(', ') || '(none)', h: 'concept.sharedLib' }) + F.ro({ l: 'Installed', v: a.installed }) +
      F.sel({ l: 'Application reference validation', n: 'validate', v: a.validate, o: [['warn', 'Issue warnings'], ['fail', 'Stop installation'], ['off', 'Do not validate']], h: 'app.validate' });
    var ap = [
      { t: 'Detail Properties', items: [{ l: 'Target specific application status', href: b + '/status', h: 'app.targetStatus' }, { l: 'Startup behavior', href: b + '/startup', h: 'app.startup' }, { l: 'Application binaries', href: b + '/binaries', h: 'app.binaries' }, { l: 'Class loading and update detection', href: b + '/classloading', h: 'concept.classloader' }, { l: 'Remote request dispatcher properties', act: 'notInSim', arg: 'Remote request dispatcher properties', h: 'app.rrd' }, { l: 'View Deployment Descriptor', href: b + '/dd', h: 'app.dd' }, { l: 'Last participant support extension', act: 'notInSim', arg: 'Last participant support extension', h: 'tx.lps' }] },
      { t: 'Modules', items: [{ l: 'Manage Modules', href: b + '/modules', h: 'app.mapModules' }] }
    ];
    if (hasWeb) ap.push({ t: 'Web Module Properties', items: [{ l: 'Session management', href: b + '/session', h: 'concept.session' }, { l: 'Context Root For Web Modules', href: b + '/ctxroot', h: 'app.contextRoot' }, { l: 'JSP and JSF options', act: 'notInSim', arg: 'JSP and JSF options', h: 'app.precompile' }, { l: 'Virtual hosts', href: b + '/vhosts', h: 'concept.vhost' }] });
    ap.push({ t: 'References', items: [{ l: 'Shared library references', href: b + '/libs', h: 'concept.sharedLib' }, { l: 'Resource references', href: b + '/resrefs', h: 'app.resrefs' }] });
    ap.push({ t: 'Detail Properties – Security', items: [{ l: 'Security role to user/group mapping', href: b + '/roles', h: 'app.roles' }, { l: 'User RunAs roles', act: 'notInSim', arg: 'User RunAs roles', h: 'app.roles' }] });
    ap.push({ t: 'Environment', items: [{ l: 'Environment entries for Web/EJB modules', href: b + '/env', h: 'app.envEntries' }] });
    return appPage(a, [], '<p class="desc">Use this page to configure an enterprise application. Click the links to access pages for further configuring of the application or its modules.</p>' + W.cfgForm({ ref: 'apps|' + a.name, doc: appDoc(a), cfgid: '/Deployment:' + a.name + '/', back: '#/apps', title: 'Application ' + a.name, tabs: [['Configuration', b, true]], general: general, ap: ap }));
  });
  R('/apps/:name/status', function (p) {
    var a = W.app(p.name), rows = W.targetServers(a).map(function (s) { return { id: s.name, server: s.name, node: s.node, cluster: s.cluster }; });
    return appPage(a, ['Target specific application status'], '<p class="desc">Uygulamanın her hedef sunucudaki durumu ve sunucu açılışında otomatik başlayıp başlamayacağı.' + W.hi('app.targetStatus') + '</p>' +
      W.table({ id: 'appst', sig: a.name, rows: rows, cols: [{ k: 'server', l: 'Target', fmt: function (r) { return W.srvLink(r.server); } }, { k: 'node', l: 'Node' }, { k: 'cluster', l: 'Cluster' }, { k: 'auto', l: 'Auto Start', fmt: function () { return a.autoStart ? 'Yes' : 'No'; } }, { k: 'st', l: 'Application Status', fmt: function (r) { return W.stIcon(a.state === 'stopped' ? 'stopped' : W.serverStatus(r.server) === 'started' ? 'started' : 'stopped', ''); } }],
        buttons: [{ l: 'Enable Auto Start', act: 'appAuto', arg: a.name + '§1', need: 1 }, { l: 'Disable Auto Start', act: 'appAuto', arg: a.name + '§0', need: 1 }] }), 'app.targetStatus');
  });
  A.appAuto = function (el) { var x = el.dataset.arg.split('§'), a = W.app(x[0]); a.autoStart = x[1] === '1'; W.change(appDoc(a), 'Auto start: ' + a.autoStart); W.clearSel(el.dataset.tbl); W.rerender(); };
  R('/apps/:name/startup', function (p) {
    var a = W.app(p.name), b = appBase(a.name);
    return appPage(a, ['Startup behavior'], W.cfgForm({ ref: 'apps|' + a.name, doc: appDoc(a), back: b, title: 'Startup behavior', cfgid: '/Deployment:' + a.name + '/ApplicationDeployment:/', general:
      F.num({ l: 'Startup order', n: 'startingWeight', v: a.startingWeight, h: 'app.startup', min: 0 }) + F.ck({ l: 'Launch application before server completes startup', n: 'backgroundApplication', v: a.backgroundApplication, h: 'app.startup' }) +
      F.ck({ l: 'Create MBeans for resources', n: 'createMBeansForResources', v: a.createMBeansForResources, h: 'app.startup' }) }), 'app.startup');
  });
  R('/apps/:name/binaries', function (p) {
    var a = W.app(p.name), b = appBase(a.name);
    return appPage(a, ['Application binaries'], W.cfgForm({ ref: 'apps|' + a.name, doc: appDoc(a), back: b, title: 'Application binaries', general:
      F.text({ l: 'Location (full path)', n: 'binariesDir', v: a.binariesDir, h: 'app.binaries' }) + F.ck({ l: 'Use configuration information in binary', n: 'useMetadataFromBinaries', v: a.useMetadataFromBinaries, h: 'app.binaries' }) +
      F.ck({ l: 'Enable binary distribution, expansion and cleanup post uninstallation', n: 'distribute', v: a.distribute, h: 'app.binaries' }) + F.text({ l: 'File permissions', n: 'filePermission', v: a.filePermission || '.*\\.dll=755#.*\\.so=755#.*\\.a=755#.*\\.sl=755', h: 'app.binaries' }) +
      F.ro({ l: 'Application build level', v: a.version }) }), 'app.binaries');
  });
  R('/apps/:name/classloading', function (p) {
    var a = W.app(p.name), b = appBase(a.name);
    return appPage(a, ['Class loader'], '<p class="desc">Specify class loader order and WAR class loader policy for the application.' + W.hi('concept.classloader') + '</p>' + W.cfgForm({ ref: 'apps|' + a.name, doc: appDoc(a), back: b, title: 'Class loading and update detection', cfgid: '/Deployment:' + a.name + '/ApplicationDeployment:/Classloader:/', general:
      F.grp('Class reloading options', 'app.reload', F.ck({ l: 'Override class reloading settings for Web and EJB modules', n: 'reloadEnabled', v: a.reloadEnabled, h: 'app.reload' }) + F.num({ l: 'Polling interval for updated files', n: 'reloadInterval', v: a.reloadInterval, unit: 'seconds', h: 'app.reload' })) +
      F.radio({ l: 'Class loader order', n: 'classloaderMode', v: a.classloaderMode, h: 'concept.classloader', o: [['PARENT_FIRST', 'Classes loaded with parent class loader first'], ['PARENT_LAST', 'Classes loaded with local class loader first (parent last)']] }) +
      F.radio({ l: 'WAR class loader policy', n: 'warPolicy', v: a.warPolicy, h: 'app.warPolicy', o: [['MULTIPLE', 'Class loader for each WAR file in application'], ['SINGLE', 'Single class loader for application']] }) }), 'concept.classloader');
  });
  R('/apps/:name/modules', function (p) {
    var a = W.app(p.name);
    var opts = targetOptions().map(function (o) { return '<label class="ck-line"><input type="checkbox" name="t" value="' + esc(o[0]) + '"' + (a.targets.indexOf(o[0]) >= 0 ? ' checked' : '') + '>' + esc(o[1]) + '</label>'; }).join('');
    return appPage(a, ['Manage Modules'], '<p class="desc">Specify targets such as application servers or clusters of application servers where you want to install the modules that are contained in your application. Modules can be installed on the same application server or dispersed among several application servers. Also, specify the Web servers as targets that serve as routers for requests to this application.' + W.hi('app.mapModules') + '</p>' +
      '<fieldset class="grp"><legend>Clusters and servers</legend><form id="modT" onsubmit="return false">' + opts + '</form><button class="btn" data-act="appMap" data-arg="' + esc(a.name) + '">Apply</button></fieldset>' +
      W.table({ id: 'mods', sig: a.name, rows: a.modules, key: function (r) { return r.uri; }, cols: [{ k: 'name', l: 'Module' }, { k: 'uri', l: 'URI' }, { k: 'type', l: 'Module Type', fmt: function (r) { return r.type === 'web' ? 'Web Module' : 'EJB Module'; } }, { k: 'srv', l: 'Server', fmt: function () { return a.targets.map(function (t) { return esc(W.targetLabel(t)); }).join('<br>'); } }] }), 'app.mapModules');
  });
  A.appMap = function (el) {
    var a = W.app(el.dataset.arg), ts = [].slice.call(document.querySelectorAll('#modT input[name=t]:checked')).map(function (i) { return i.value; });
    if (!ts.some(function (t) { return t.indexOf('webserver') !== 0; })) { W.msg('error', 'En az bir application server veya cluster hedefi seçilmelidir.'); W.rerender(); return; }
    a.targets = ts; W.change(appDoc(a), 'Modül hedefleri değişti: ' + a.name);
    W.cmd('Modül hedeflerini değiştir', ["AdminApp.edit('" + a.name + "', '[-MapModulesToServers [" + a.modules.map(function (m) { return "['" + m.name + "' " + m.uri + ',WEB-INF/web.xml ' + ts.map(W.targetLabel).join('+') + ']'; }).join(' ') + "]]')", 'AdminConfig.save()']);
    W.msg('info', 'Hedefler güncellendi. Kaydettikten sonra plug-in yapılandırmasını yeniden üretip yaymayı unutmayın.'); W.rerender();
  };
  R('/apps/:name/ctxroot', function (p) {
    var a = W.app(p.name);
    return appPage(a, ['Context root for Web modules'], '<p class="desc">Configure the context root for Web modules.' + W.hi('app.contextRoot') + '</p>' +
      W.table({ id: 'ctx', sig: a.name, select: false, rows: a.modules.filter(function (m) { return m.type === 'web'; }), key: function (r) { return r.uri; }, cols: [{ k: 'name', l: 'Web module' }, { k: 'uri', l: 'URI' }, { k: 'contextRoot', l: 'Context Root', fmt: function (r) { return '<input type="text" data-ctx="' + esc(r.uri) + '" value="' + esc(r.contextRoot) + '">'; } }] }) +
      '<div class="btnrow"><button class="btn primary" data-act="appCtx" data-arg="' + esc(a.name) + '">OK</button><button class="btn" data-act="goBack" data-href="' + appBase(a.name) + '">Cancel</button></div>', 'app.contextRoot');
  });
  A.appCtx = function (el) {
    var a = W.app(el.dataset.arg), ch = [];
    document.querySelectorAll('[data-ctx]').forEach(function (i) { var m = W.by(a.modules, 'uri', i.dataset.ctx), v = i.value.trim(); if (!/^\//.test(v)) v = '/' + v; if (m.contextRoot !== v) { ch.push(m.uri + ': ' + m.contextRoot + ' → ' + v); m.contextRoot = v; } });
    if (ch.length) { W.change(appDoc(a), 'Context root: ' + ch.join(', ')); W.cmd('Context root değiştir', ["AdminApp.edit('" + a.name + "', '[-CtxRootForWebMod [" + a.modules.filter(function (m) { return m.type === 'web'; }).map(function (m) { return "['" + m.name + "' " + m.uri + ',WEB-INF/web.xml ' + m.contextRoot + ']'; }).join(' ') + "]]')", 'AdminConfig.save()']); W.msg('info', ['Context root güncellendi: ' + ch.join('; '), 'Uygulamanın yeniden başlatılması ve plug-in yapılandırmasının yeniden üretilip yayılması gerekir; aksi halde web server eski URI ile istek yönlendirmeye devam eder.']); }
    W.go(appBase(a.name));
  };
  R('/apps/:name/vhosts', function (p) {
    var a = W.app(p.name);
    return appPage(a, ['Virtual hosts'], '<p class="desc">Specify the virtual host for the Web modules that are contained in your application.' + W.hi('concept.vhost') + '</p>' +
      W.table({ id: 'avh', sig: a.name, select: false, rows: a.modules.filter(function (m) { return m.type === 'web'; }), key: function (r) { return r.uri; }, cols: [{ k: 'name', l: 'Web module' }, { k: 'uri', l: 'URI' }, { k: 'vhost', l: 'Virtual host', fmt: function (r) { return '<select data-vh="' + esc(r.uri) + '">' + W.S.virtualHosts.map(function (v) { return '<option' + (v.name === r.vhost ? ' selected' : '') + '>' + esc(v.name) + '</option>'; }).join('') + '</select>'; } }] }) +
      '<div class="btnrow"><button class="btn primary" data-act="appVh" data-arg="' + esc(a.name) + '">OK</button><button class="btn" data-act="goBack" data-href="' + appBase(a.name) + '">Cancel</button></div>', 'concept.vhost');
  });
  A.appVh = function (el) {
    var a = W.app(el.dataset.arg);
    document.querySelectorAll('[data-vh]').forEach(function (s) { W.by(a.modules, 'uri', s.dataset.vh).vhost = s.value; });
    W.change(appDoc(a), 'Virtual host eşlemesi: ' + a.name);
    W.cmd('Web modülü virtual host eşle', ["AdminApp.edit('" + a.name + "', '[-MapWebModToVH [" + a.modules.filter(function (m) { return m.type === 'web'; }).map(function (m) { return "['" + m.name + "' " + m.uri + ',WEB-INF/web.xml ' + m.vhost + ']'; }).join(' ') + "]]')", 'AdminConfig.save()']);
    W.msg('info', 'Virtual host eşlemesi güncellendi. Plug-in yapılandırmasını yeniden üretip yayın.'); W.go(appBase(a.name));
  };
  R('/apps/:name/libs', function (p) {
    var a = W.app(p.name);
    var opts = W.S.sharedLibs.map(function (l) { return '<label class="ck-line"><input type="checkbox" name="lib" value="' + esc(l.name) + '"' + (a.sharedLibs.indexOf(l.name) >= 0 ? ' checked' : '') + '>' + esc(l.name) + ' <span style="color:#666">(' + esc(W.scopeLabel(l.scope)) + ')</span></label>'; }).join('');
    return appPage(a, ['Shared library references'], '<p class="desc">Uygulamanın kullanacağı shared library\'leri seçin. Shared library, kapsamı (scope) uygulamanın hedeflerini içermelidir; aksi halde çalışma zamanında ClassNotFoundException alınır.' + W.hi('concept.sharedLib') + '</p>' +
      '<form id="libF" onsubmit="return false">' + opts + '</form><div class="btnrow"><button class="btn primary" data-act="appLibs" data-arg="' + esc(a.name) + '">OK</button><button class="btn" data-act="goBack" data-href="' + appBase(a.name) + '">Cancel</button></div>', 'concept.sharedLib');
  });
  A.appLibs = function (el) {
    var a = W.app(el.dataset.arg), sel = [].slice.call(document.querySelectorAll('#libF input:checked')).map(function (i) { return i.value; }), warn = [];
    sel.forEach(function (ln) {
      var l = W.by(W.S.sharedLibs, 'name', ln), ok = l.scope === 'cell' || a.targets.some(function (t) { var p = t.split(':'); return (p[0] === 'cluster' && l.scope === 'cluster:' + p[1]) || (p[0] === 'server' && (l.scope === 'node:' + p[1] || l.scope === 'server:' + p[1] + ':' + p[2])); });
      if (!ok) warn.push('<span style="color:#b26a00">Uyarı: ' + esc(ln) + ' (' + esc(W.scopeLabel(l.scope)) + ') uygulamanın hedeflerinden görünmüyor; çalışma zamanında bulunamaz.</span>');
    });
    a.sharedLibs = sel; W.change(appDoc(a), 'Shared library referansları: ' + a.name);
    W.cmd('Shared library referansı', ["AdminApp.edit('" + a.name + "', '[-MapSharedLibForMod [[" + a.name + " META-INF/application.xml " + sel.join('+') + "]]]')", 'AdminConfig.save()']);
    W.msg('info', ['Shared library referansları güncellendi: ' + (sel.join(', ') || '(none)')].concat(warn)); W.go(appBase(a.name));
  };
  R('/apps/:name/resrefs', function (p) {
    var a = W.app(p.name);
    return appPage(a, ['Resource references'], '<p class="desc">Uygulama kodundaki mantıksal referansların (<code>java:comp/env/jdbc/...</code>) sunucudaki gerçek JNDI kaynaklarına bağlanması.' + W.hi('app.resrefs') + '</p>' +
      W.table({ id: 'rr', sig: a.name, select: false, rows: a.resourceRefs.map(function (r, i) { return Object.assign({ id: 'r' + i }, r); }), cols: [{ k: 'module', l: 'Module' }, { k: 'ref', l: 'Resource Reference' }, { k: 'type', l: 'Resource type' }, { k: 'target', l: 'Target Resource JNDI Name' }, { k: 'auth', l: 'Authentication', fmt: function (r) { return esc(r.auth) + (r.alias ? ' (alias: ' + esc(r.alias) + ')' : ''); } }], empty: 'Bu uygulamada resource reference yok.' }), 'app.resrefs');
  });
  R('/apps/:name/roles', function (p) {
    var a = W.app(p.name);
    return appPage(a, ['Security role to user/group mapping'], '<p class="desc">Each role that is defined in the application or module must map to a user or group from the domain user registry. Bu eşleme yalnızca <b>application security</b> etkin olduğunda uygulanır.' + W.hi('app.roles') + '</p>' +
      W.table({ id: 'roles', sig: a.name, rows: a.roles, key: function (r) { return r.role; }, cols: [{ k: 'role', l: 'Role' }, { k: 'sp', l: 'Special subjects', fmt: function (r) { return r.everyone ? 'Everyone' : r.allAuth ? 'All authenticated in application\'s realm' : ''; } }, { k: 'users', l: 'Mapped users' }, { k: 'groups', l: 'Mapped groups' }], empty: 'Uygulamada güvenlik rolü tanımlı değil.',
        buttons: [{ l: 'Map Users...', act: 'roleMap', arg: a.name + '§users', need: 1 }, { l: 'Map Groups...', act: 'roleMap', arg: a.name + '§groups', need: 1 }, { l: 'Map Special Subjects: All authenticated', act: 'roleSpecial', arg: a.name + '§auth', need: 1 }, { l: 'Map Special Subjects: Everyone', act: 'roleSpecial', arg: a.name + '§everyone', need: 1 }, { l: 'Map Special Subjects: None', act: 'roleSpecial', arg: a.name + '§none', need: 1 }] }), 'app.roles');
  });
  A.roleMap = function (el) {
    var x = el.dataset.arg.split('§'), a = W.app(x[0]), sel = W.selected(el.dataset.tbl), isU = x[1] === 'users';
    var list = isU ? W.S.security.users.map(function (u) { return u.uid; }) : W.S.security.groups.map(function (g) { return g.cn; });
    W.modal({ title: 'Map ' + (isU ? 'users' : 'groups') + ' – ' + sel.join(', '), html: '<p class="desc">Search and Select (registry: ' + esc(W.S.security.realm) + ')</p><form id="rmF">' + list.map(function (n) { return '<label class="ck-line"><input type="checkbox" value="' + esc(n) + '">' + esc(n) + '</label>'; }).join('') + '</form>',
      buttons: [{ l: 'OK', fn: function () {
        var ch = [].slice.call(document.querySelectorAll('#rmF input:checked')).map(function (i) { return i.value; }).join('|');
        sel.forEach(function (r) { W.by(a.roles, 'role', r)[x[1]] = ch; });
        W.change(appDoc(a), 'Rol eşlemesi: ' + sel.join(', '));
        W.cmd('Rol eşle', ["AdminApp.edit('" + a.name + "', '[-MapRolesToUsers [" + sel.map(function (r) { return "['" + r + "' AppDeploymentOption.No AppDeploymentOption.No '" + (isU ? ch : '') + "' '" + (isU ? '' : ch) + "']"; }).join(' ') + "]]')", 'AdminConfig.save()']);
        W.clearSel(el.dataset.tbl); W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.roleSpecial = function (el) {
    var x = el.dataset.arg.split('§'), a = W.app(x[0]);
    W.selected(el.dataset.tbl).forEach(function (r) { var o = W.by(a.roles, 'role', r); o.everyone = x[1] === 'everyone'; o.allAuth = x[1] === 'auth'; });
    W.change(appDoc(a), 'Special subject eşlemesi');
    if (x[1] === 'everyone') W.msg('warning', 'Uyarı: "Everyone" eşlemesi rolü kimlik doğrulaması YAPILMAMIŞ kullanıcılara da açar. Korunan kaynaklar için kullanmayın.');
    W.clearSel(el.dataset.tbl); W.rerender();
  };
  R('/apps/:name/env', function (p) {
    var a = W.app(p.name);
    return appPage(a, ['Environment entries'], '<p class="desc">Configure values for environment entries in Web and EJB modules (deployment descriptor\'daki <code>&lt;env-entry&gt;</code> öğeleri). Uygulama bunları <code>java:comp/env</code> altından okur.' + W.hi('app.envEntries') + '</p>' +
      W.table({ id: 'env', sig: a.name, select: false, rows: a.envEntries.map(function (e, i) { return Object.assign({ id: 'e' + i, i: i }, e); }), cols: [{ k: 'module', l: 'Module' }, { k: 'name', l: 'Name' }, { k: 'type', l: 'Type' }, { k: 'description', l: 'Description' }, { k: 'value', l: 'Value', fmt: function (r) { return '<input type="text" data-env="' + r.i + '" value="' + esc(r.value) + '">'; } }], empty: 'Bu uygulamada environment entry yok.' }) +
      (a.envEntries.length ? '<div class="btnrow"><button class="btn primary" data-act="appEnv" data-arg="' + esc(a.name) + '">OK</button></div>' : ''), 'app.envEntries');
  });
  A.appEnv = function (el) { var a = W.app(el.dataset.arg); document.querySelectorAll('[data-env]').forEach(function (i) { a.envEntries[+i.dataset.env].value = i.value; }); W.change(appDoc(a), 'Environment entries: ' + a.name); W.cmd('Env entry değiştir', ["AdminApp.edit('" + a.name + "', '[-MapEnvEntryForWebMod [...]]')", 'AdminConfig.save()']); W.msg('info', 'Environment entry değerleri güncellendi; uygulamanın yeniden başlatılması gerekir.'); W.go(appBase(a.name)); };
  R('/apps/:name/session', function (p) {
    var a = W.app(p.name), b = appBase(a.name);
    a.session = a.session || { override: false, invalidationTimeout: 30, enableCookies: true, enableUrlRewriting: false, maxInMemorySessionCount: 1000, allowOverflow: true };
    var s = a.session;
    return appPage(a, ['Session management'], '<p class="desc">Uygulama seviyesinde session ayarları. <b>Override session management</b> seçilirse sunucu seviyesindeki ayarlar bu uygulama için geçersiz kılınır (Application &gt; Server önceliği).' + W.hi('concept.session') + '</p>' + W.cfgForm({ ref: 'apps|' + a.name + '|session', doc: appDoc(a), back: b, title: 'Application session management', general:
      F.ck({ l: 'Override session management', n: 'override', v: s.override, h: 'sess.override' }) + F.ck({ l: 'Enable cookies', n: 'enableCookies', v: s.enableCookies, h: 'sess.cookies' }) + F.ck({ l: 'Enable URL rewriting', n: 'enableUrlRewriting', v: s.enableUrlRewriting, h: 'sess.urlRewrite' }) +
      F.num({ l: 'Maximum in-memory session count', n: 'maxInMemorySessionCount', v: s.maxInMemorySessionCount, h: 'sess.maxInMemory' }) + F.ck({ l: 'Allow overflow', n: 'allowOverflow', v: s.allowOverflow, h: 'sess.overflow' }) + F.num({ l: 'Session timeout', n: 'invalidationTimeout', v: s.invalidationTimeout, unit: 'minutes', h: 'sess.timeout' }) }), 'concept.session');
  });
  R('/apps/:name/dd', function (p) {
    var a = W.app(p.name), w = a.modules.filter(function (m) { return m.type === 'web'; })[0];
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<application xmlns="http://xmlns.jcp.org/xml/ns/javaee" version="7">\n  <display-name>' + a.name + '</display-name>\n' + a.modules.map(function (m) { return m.type === 'web' ? '  <module>\n    <web>\n      <web-uri>' + m.uri + '</web-uri>\n      <context-root>' + m.contextRoot + '</context-root>\n    </web>\n  </module>\n' : '  <module>\n    <ejb>' + m.uri + '</ejb>\n  </module>\n'; }).join('') + a.roles.map(function (r) { return '  <security-role>\n    <role-name>' + r.role + '</role-name>\n  </security-role>\n'; }).join('') + '</application>\n';
    return appPage(a, ['View Deployment Descriptor'], '<p class="desc">META-INF/application.xml (salt okunur). Bağlamalar (bindings) ayrıca <code>ibm-application-bnd.xml</code> ve WAS repository\'sindeki <code>deployment.xml</code> dosyasında tutulur.' + W.hi('app.dd') + '</p><pre class="code">' + W.xmlHighlight(xml) + '</pre>' + (w ? '<p>Web modülü: ' + esc(w.uri) + ' → <code>WEB-INF/web.xml</code>, <code>WEB-INF/ibm-web-bnd.xml</code>, <code>WEB-INF/ibm-web-ext.xml</code></p>' : ''), 'app.dd');
  });

  /* ---------------------------------------------------------- services */
  R('/services/providers', function () {
    return { title: 'Service providers', help: 'svc.providers', html: '<div class="page-title">Service providers' + W.hi('svc.providers') + '</div><p class="desc">Use this page to view the service providers (JAX-WS web services) that are deployed in the cell.</p>' +
      W.table({ id: 'svcp', rows: [{ name: 'PaymentService', app: 'PaymentGatewayApp', type: 'JAX-WS', ps: 'Username WSSecurity default' }, { name: 'AccountInquiryService', app: 'CoreBankingApp', type: 'JAX-WS', ps: 'WSHTTPS default' }, { name: 'FxRateService', app: 'InternetBankingApp', type: 'JAX-WS', ps: '(none)' }], key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Service' }, { k: 'app', l: 'Application', fmt: function (r) { return W.appLink(r.app); } }, { k: 'type', l: 'Type' }, { k: 'ps', l: 'Attached policy set', h: 'svc.policySets' }] }) };
  });
  R('/services/clients', function () {
    return { title: 'Service clients', help: 'svc.providers', html: '<div class="page-title">Service clients</div><p class="desc">Use this page to view service clients (web service references) in the cell.</p>' +
      W.table({ id: 'svcc', rows: [{ name: 'CreditBureauService', app: 'CoreBankingApp', ps: 'WSHTTPS default', ep: 'https://kkb-gw.corp.local/ws/v3' }, { name: 'SmsGatewayService', app: 'NotificationApp', ps: '(none)', ep: 'https://sms-gw.corp.local/ws' }], key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Service' }, { k: 'app', l: 'Application' }, { k: 'ep', l: 'Endpoint' }, { k: 'ps', l: 'Attached policy set' }] }) };
  });
  R('/services/policysets', function () {
    return { title: 'Application policy sets', help: 'svc.policySets', html: '<div class="page-title">Application policy sets' + W.hi('svc.policySets') + '</div><p class="desc">Policy sets are assertions about how Web services are defined (WS-Security, WS-Addressing, WS-ReliableMessaging, HTTP transport).</p>' +
      W.table({ id: 'ps', rows: ['LTPA WSSecurity default', 'Username WSSecurity default', 'WSHTTPS default', 'WSAddressing default', 'WSReliableMessaging 1_1', 'WSReliableMessaging persistent'].map(function (n) { return { name: n, d: 'Default policy set (system)', a: n.indexOf('Username') === 0 || n === 'WSHTTPS default' ? 'Yes' : 'No' }; }), key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'd', l: 'Description' }, { k: 'a', l: 'Attached' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New policy set' }, { l: 'Copy...', act: 'notInSim', arg: 'Copy policy set' }, { l: 'Import', act: 'notInSim', arg: 'Import' }, { l: 'Export...', act: 'notInSim', arg: 'Export' }] }) };
  });
  R('/uddi', function () {
    return { title: 'UDDI Nodes', help: 'svc.uddi', html: '<div class="page-title">UDDI Nodes' + W.hi('svc.uddi') + '</div><p class="desc">Use this page to manage UDDI nodes. Bu hücrede UDDI registry uygulaması kurulu değildir.</p>' + W.table({ id: 'uddi', rows: [], cols: [{ k: 'name', l: 'UDDI Node ID' }, { k: 'd', l: 'Description' }, { k: 's', l: 'Status' }], empty: 'None – UDDI registry (uddiregistry.ear) kurulu değil.' }) };
  });
})();
