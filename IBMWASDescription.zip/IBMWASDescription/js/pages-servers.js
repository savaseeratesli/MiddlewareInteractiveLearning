/* pages-servers.js – Servers: application servers, web servers, generic/proxy/MQ,
   templates, clusters, core groups ve sunucu runtime işlemleri. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };

  /* ----------------------------------------------------- runtime işlemleri */
  W.liveRefresh = function () {
    if (document.getElementById('modal').classList.contains('open')) return;
    var ae = document.activeElement;
    if (ae && ae.closest && ae.closest('form.cfg, form.wz') && /INPUT|TEXTAREA|SELECT/.test(ae.tagName)) return;
    W.rerender();
  };
  var OPNAME = { start: 'Start', stop: 'Stop', restart: 'Restart', immediateStop: 'ImmediateStop', terminate: 'Terminate' };
  W.serverOp = function (names, op, quiet) {
    var msgs = [], cmds = [];
    names.forEach(function (n, idx) {
      var s = W.srv(n); if (!s) return;
      var na = W.RT.nodeagents[s.node];
      if (na !== 'started') { msgs.push('<span style="color:#c62828">ADMU0509I/ADMC0016E: ' + esc(s.name) + ' için işlem yapılamadı – ' + esc(s.node) + ' node agent\'ı çalışmıyor. DMGR, sunucuları node agent üzerinden yönetir; önce node agent\'ı <code>startNode.sh</code> ile başlatın.</span>'); return; }
      var st = W.RT.servers[n];
      if ((op === 'start') && st === 'started') { msgs.push(esc(n) + ' zaten çalışıyor (already started).'); return; }
      if ((op === 'stop' || op === 'immediateStop' || op === 'terminate') && st === 'stopped') { msgs.push(esc(n) + ' zaten durdurulmuş (already stopped).'); return; }
      if (op === 'restart' && st === 'stopped') op = 'start';
      var delay = 1800 + idx * 700 + Math.random() * 900;
      if (op === 'start') {
        W.RT.servers[n] = 'starting';
        cmds.push("AdminControl.startServer('" + n + "', '" + s.node + "')");
        setTimeout(function () { W.RT.servers[n] = 'started'; W.RT.pids[n] = 40000 + Math.floor(Math.random() * 20000); W.RT.startTimes[n] = new Date().toLocaleString('tr-TR'); W.saveRT(); if (!quiet) W.msg('info', 'Sunucu <b>' + esc(n) + '</b> (node ' + esc(s.node) + ') başarıyla başlatıldı. WSVR0001I: Server ' + esc(n) + ' open for e-business'); W.liveRefresh(); }, delay + 1500);
      } else if (op === 'restart') {
        W.RT.servers[n] = 'stopping';
        cmds.push("AdminControl.invoke(AdminControl.queryNames('WebSphere:*,type=Server,node=" + s.node + ",process=" + n + "'), 'restart')");
        setTimeout(function () { W.RT.servers[n] = 'starting'; W.liveRefresh(); setTimeout(function () { W.RT.servers[n] = 'started'; W.RT.startTimes[n] = new Date().toLocaleString('tr-TR'); W.saveRT(); W.msg('info', 'Sunucu <b>' + esc(n) + '</b> yeniden başlatıldı.'); W.liveRefresh(); }, 2200); }, delay);
      } else {
        W.RT.servers[n] = 'stopping';
        var fast = op !== 'stop';
        cmds.push(op === 'stop' ? "AdminControl.stopServer('" + n + "', '" + s.node + "')" : op === 'immediateStop' ? "AdminControl.stopServer('" + n + "', '" + s.node + "', 'immediate')" : "AdminControl.stopServer('" + n + "', '" + s.node + "', 'terminate')");
        setTimeout(function () { W.RT.servers[n] = 'stopped'; W.saveRT(); if (!quiet) W.msg('info', 'Sunucu <b>' + esc(n) + '</b> durduruldu (' + OPNAME[op] + '). ' + (s.cluster ? 'Plug-in, bu üyeye gelen yeni istekleri ' + esc(s.cluster) + ' cluster\'ının diğer üyelerine yönlendirecek.' : '')); W.liveRefresh(); }, fast ? 900 : delay);
      }
      msgs.push(esc(OPNAME[op]) + ' isteği <b>' + esc(n) + '</b> için gönderildi. Durum otomatik olarak güncellenecek.');
    });
    if (cmds.length) W.cmd('Server ' + OPNAME[op] + ': ' + names.join(', '), cmds);
    W.saveRT();
    return msgs;
  };
  ['start', 'stop', 'restart', 'immediateStop', 'terminate'].forEach(function (op) {
    A['srv_' + op] = function (el) {
      var names = el.dataset.tbl ? W.selected(el.dataset.tbl) : [el.dataset.arg];
      if (el.dataset.tbl) W.clearSel(el.dataset.tbl);
      W.msg('info', W.serverOp(names, op)); W.rerender();
    };
  });

  /* --------------------------------------------- Application servers list */
  R('/servers/appservers', function () {
    var rows = W.S.servers;
    return {
      title: 'Application servers', help: 'page.appservers',
      html: '<div class="page-title">Application servers' + W.hi('concept.appserver') + '</div><p class="desc">Use this page to view a list of the application servers in your environment and the status of each of these servers. You can also use this page to change the status of a specific application server.</p>' +
        '<div class="note-tr">Application server, Java EE uygulamalarının çalıştığı JVM sürecidir. Durum sütunu node agent üzerinden alınan anlık (runtime) bilgidir; node agent durdurulmuşsa durum <i>Unknown</i> görünür.</div>' + W.prefs() +
        W.table({
          id: 'appsrv', rows: rows,
          cols: [
            { k: 'name', l: 'Name', fmt: function (r) { return W.srvLink(r.name); } },
            { k: 'node', l: 'Node', fmt: function (r) { return W.nodeLink(r.node); }, h: 'concept.node' },
            { k: 'host', l: 'Host Name', sv: function (r) { return W.hostOf(r.node); }, fmt: function (r) { return esc(W.hostOf(r.node)); } },
            { k: 'ver', l: 'Version', sv: function () { return W.S.cell.version; }, fmt: function () { return esc(W.S.cell.version); } },
            { k: 'cluster', l: 'Cluster Name', fmt: function (r) { return W.clusterLink(r.cluster); }, h: 'concept.cluster' },
            { k: 'status', l: 'Status', sv: function (r) { return W.serverStatus(r); }, fmt: function (r) { return W.stIcon(W.serverStatus(r), ''); }, h: 'srv.status' }
          ],
          buttons: [{ l: 'New...', href: '#/wz/createServer' }, { l: 'Delete', act: 'srvDelete', need: 1 }, { l: 'Templates...', href: '#/servers/templates' },
            { l: 'Start', act: 'srv_start', need: 1 }, { l: 'Stop', act: 'srv_stop', need: 1 }, { l: 'Restart', act: 'srv_restart', need: 1 }, { l: 'ImmediateStop', act: 'srv_immediateStop', need: 1 }, { l: 'Terminate', act: 'srv_terminate', need: 1 }],
          btnHelp: 'srv.ops'
        })
    };
  });
  A.srvDelete = function (el) {
    var names = W.selected(el.dataset.tbl), msgs = [];
    names.forEach(function (n) {
      var s = W.srv(n);
      if (s.cluster) { msgs.push(esc(n) + ', ' + esc(s.cluster) + ' cluster üyesidir. Cluster üyelerini <a href="#/clusters/' + W.enc(s.cluster) + '/members">Cluster members</a> sayfasından silin.'); return; }
      if (W.RT.servers[n] !== 'stopped') { msgs.push(esc(n) + ' çalışıyor. Silmeden önce sunucuyu durdurun.'); return; }
      var apps = W.S.apps.filter(function (a) { return a.targets.indexOf('server:' + s.node + ':' + s.name) >= 0; });
      if (apps.length) { msgs.push(esc(n) + ' üzerinde kurulu uygulamalar var (' + apps.map(function (a) { return esc(a.name); }).join(', ') + '). Önce uygulamaları kaldırın veya başka bir hedefe eşleyin.'); return; }
      W.S.servers.splice(W.S.servers.indexOf(s), 1);
      W.change('cells/' + CELL() + '/nodes/' + s.node + '/servers/' + n + '/', 'Application server silindi: ' + n);
      W.cmd('Application server sil', ["AdminTask.deleteServer('[-serverName " + n + " -nodeName " + s.node + "]')", 'AdminConfig.save()']);
      msgs.push('Sunucu ' + esc(n) + ' silindi.');
    });
    W.clearSel(el.dataset.tbl); W.msg('info', msgs); W.rerender();
  };

  /* Create application server wizard */
  W.wizard('createServer', {
    title: 'Application servers', help: 'srv.create', back: '#/servers/appservers', crumbs: [['Application servers', '#/servers/appservers'], 'Create a new application server'],
    intro: 'Yeni bir application server oluşturur. Sunucu, seçilen node üzerindeki node agent tarafından yönetilecek ve konfigürasyonu <code>cells/' + 'WASPRODCell01' + '/nodes/&lt;node&gt;/servers/&lt;ad&gt;/server.xml</code> altında tutulacaktır.',
    init: function (q) { return { node: q.node || 'AppNode03', name: '', template: 'default', genUniquePorts: true }; },
    steps: function () {
      return [
        { t: 'Select a node', h: 'concept.node', html: function (v) {
          return F.sel({ l: 'Select node', n: 'node', v: v.node, h: 'srv.selectNode', o: W.S.nodes.filter(function (n) { return n.type === 'managed'; }).map(function (n) { return [n.name, n.name + ' (' + W.S.cell.version + ')']; }) }) +
            F.text({ l: 'Server name', n: 'name', v: v.name, req: true, h: 'srv.name', ph: 'ör. BankSrv04' }) + F.ro({ l: 'Core group', v: 'DefaultCoreGroup', h: 'concept.coreGroup' });
        }, validate: function (v) {
          if (!/^[A-Za-z][\w.-]*$/.test(v.name || '')) return ['Sunucu adı harf ile başlamalı ve yalnızca harf, rakam, "_", "-", "." içermelidir.'];
          if (W.srv(v.name)) return ['"' + v.name + '" adlı bir sunucu zaten var.'];
        } },
        { t: 'Select a server template', h: 'srv.template', html: function (v) {
          return F.radio({ l: 'Select a template', n: 'template', v: v.template, h: 'srv.template', o: W.S.templates.filter(function (t) { return t.type === 'APPLICATION_SERVER' && t.name !== 'defaultZOS'; }).map(function (t) { return [t.name, t.name + ' – ' + t.description]; }) });
        } },
        { t: 'Specify server specific properties', h: 'srv.genPorts', html: function (v) {
          return F.ck({ l: 'Generate unique ports', n: 'genUniquePorts', v: v.genUniquePorts, h: 'srv.genPorts' }) + '<p class="desc">Benzersiz port üretimi seçilmezse sunucu şablondaki portları (ör. 9080) kullanır ve aynı node üzerindeki başka bir sunucuyla çakışarak <b>başlatılamayabilir</b> (CHFW0029E: Error starting chain ... address already in use).</p>';
        } },
        { t: 'Confirm new server', html: function (v) {
          var slot = W.S.servers.filter(function (s) { return s.node === v.node; }).length, p = W.Data.ports(v.genUniquePorts ? slot : 0);
          return '<p>Summary of actions:</p>' + W.kvTable([['Cell', esc(CELL())], ['Node', esc(v.node)], ['Server name', esc(v.name)], ['Template name', esc(v.template)], ['Generate unique ports', v.genUniquePorts ? 'true' : 'false'], ['WC_defaulthost', p.WC_defaulthost], ['WC_defaulthost_secure', p.WC_defaulthost_secure], ['BOOTSTRAP_ADDRESS', p.BOOTSTRAP_ADDRESS]]);
        } }
      ];
    },
    finish: function (v) {
      var slot = W.S.servers.filter(function (s) { return s.node === v.node; }).length;
      var kind = v.template === 'BankingTemplate' ? 'bank' : 'std';
      var heap = kind === 'bank' ? [1024, 2048] : [50, 256];
      var s = W.Data.newServer(v.name, v.node, v.genUniquePorts ? slot : 0, '', kind, heap);
      s.template = v.template; s.developmentMode = v.template === 'DeveloperServer';
      if (kind === 'std') { s.jvm.genericJvmArguments = ''; s.jvm.verboseModeGarbageCollection = false; s.session.sessionPersistenceMode = 'NONE'; s.session.replicationDomain = ''; s.session.enableSecurityIntegration = false; s.customProps = []; s.jvm.systemProperties = []; }
      s.created = new Date().toISOString().slice(0, 10);
      W.S.servers.push(s);
      W.RT.servers[s.name] = 'stopped'; W.saveRT();
      var added = W.ensureVhostPorts(s);
      W.S.variables.push({ id: W.newId('v'), name: 'SERVER_LOG_ROOT', value: '${LOG_ROOT}/' + s.name, scope: W.serverScope(s), description: '' });
      W.change('cells/' + CELL() + '/nodes/' + v.node + '/servers/' + v.name + '/server.xml', 'Application server oluşturuldu: ' + v.name);
      W.cmd('Application server oluştur', ["AdminTask.createApplicationServer('" + v.node + "', '[-name " + v.name + " -templateName " + v.template + " -genUniquePorts " + v.genUniquePorts + "]')", 'AdminConfig.save()']);
      return { msgs: ['Sunucu <b>' + esc(v.name) + '</b> ' + esc(v.node) + ' üzerinde oluşturuldu (durum: Stopped).' + (added.length ? ' default_host virtual host\'a yeni alias eklendi: ' + added.join(', ') + '.' : ''), 'Değişiklikleri kaydedip node\'ları senkronize ettikten sonra sunucuyu başlatabilirsiniz.'], go: '#/servers/appservers' };
    }
  });
  W.ensureVhostPorts = function (s) {
    var vh = W.by(W.S.virtualHosts, 'name', 'default_host'), added = [];
    [s.ports.WC_defaulthost, s.ports.WC_defaulthost_secure].forEach(function (p) {
      if (!vh.aliases.some(function (a) { return a[0] === '*' && +a[1] === p; })) { vh.aliases.push(['*', p]); added.push('*:' + p); }
    });
    return added;
  };

  /* ------------------------------------------------ server detail & tabs */
  function srvBase(n) { return '#/servers/appservers/' + W.enc(n); }
  function srvCfgId(s) { return '/Cell:' + CELL() + '/Node:' + s.node + '/Server:' + s.name + '/'; }
  function srvDoc(s) { return 'cells/' + CELL() + '/nodes/' + s.node + '/servers/' + s.name + '/server.xml'; }
  function srvCrumbs(s, extra) { return W.crumbs([['Application servers', '#/servers/appservers'], [s.name, srvBase(s.name)]].concat(extra || [])); }
  function srvPage(s, extra, body) { return { title: 'Application servers', help: 'page.appserverDetail', html: srvCrumbs(s, extra) + body }; }
  W.srvBase = srvBase;

  R('/servers/appservers/:name', function (p, q) {
    var s = W.srv(p.name);
    if (!s) return { title: 'Application servers', html: 'Sunucu bulunamadı.' };
    var b = srvBase(s.name), st = W.serverStatus(s);
    var tabs = [['Runtime', b + '?tab=runtime', q.tab === 'runtime'], ['Configuration', b, q.tab !== 'runtime']];
    if (q.tab === 'runtime') {
      var ns = W.node(s.node);
      var rt = '<div class="tabs">' + tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + t[0] + '</a>'; }).join('') + '</div>' +
        '<div class="detail"><div class="gp"><div class="sect-title">General Properties</div>' +
        F.ro({ l: 'Process ID', v: st === 'started' ? W.RT.pids[s.name] : '', h: 'srv.pid' }) + F.ro({ l: 'Cell name', v: CELL(), h: 'concept.cell' }) + F.ro({ l: 'Node name', v: s.node, h: 'concept.node' }) +
        F.ro({ l: 'State', v: W.stIcon(st), raw: true, h: 'srv.status' }) + F.ro({ l: 'Started at', v: st === 'started' ? W.RT.startTimes[s.name] : '-', h: 'srv.status' }) + F.ro({ l: 'Host / OS', v: ns.host + ' – ' + ns.osName }) + F.ro({ l: 'Java SDK', v: W.S.cell.javaSdk, h: 'srv.sdk' }) +
        '<div class="btnrow"><button class="btn" data-act="srv_start" data-arg="' + esc(s.name) + '">Start</button><button class="btn" data-act="srv_stop" data-arg="' + esc(s.name) + '">Stop</button><button class="btn" data-act="srv_restart" data-arg="' + esc(s.name) + '">Restart</button><button class="btn" data-act="srv_immediateStop" data-arg="' + esc(s.name) + '">ImmediateStop</button></div></div>' +
        '<div class="ap">' + W.apGroups([{ t: 'Additional Properties', items: [
          { l: 'Product Information', act: 'productInfo', arg: s.name, h: 'srv.productInfo' },
          { l: 'Transaction Service', href: b + '/tx?tab=runtime', h: 'tx.service' },
          { l: 'Performance (Tivoli Performance Viewer)', href: '#/mon/tpv?server=' + W.enc(s.name), h: 'mon.tpv' },
          { l: 'Logs (SystemOut.log)', href: '#/tr/logs/' + W.enc(s.name) + '/view?file=SystemOut.log', h: 'log.systemout' }] }]) + '</div></div>';
      return srvPage(s, [], rt);
    }
    var tmode = s.cluster ? 'Cluster üyesi: <a href="#/clusters/' + W.enc(s.cluster) + '">' + esc(s.cluster) + '</a>. Cluster üyelerinin konfigürasyonu ayrı ayrı tutulur; ortak ayar değişikliklerini tüm üyelere uygulamayı unutmayın.' : 'Bu sunucu bir cluster üyesi değildir (standalone, managed server).';
    var general = F.ro({ l: 'Name', v: s.name, h: 'srv.name' }) + F.ro({ l: 'Node name', v: s.node, h: 'concept.node' }) +
      F.ck({ l: 'Run in development mode', n: 'developmentMode', v: s.developmentMode, h: 'srv.devMode' }) +
      F.ck({ l: 'Parallel start', n: 'parallelStartEnabled', v: s.parallelStartEnabled, h: 'srv.parallelStart' }) +
      F.ck({ l: 'Start components as needed', n: 'provisionComponents', v: s.provisionComponents, h: 'srv.provision' }) +
      F.sel({ l: 'Access to internal server classes', n: 'accessInternalClasses', v: s.accessInternalClasses, o: [['ALLOW', 'Allow'], ['RESTRICT', 'Restrict']], h: 'srv.internalClasses' }) +
      F.grp('Server-specific Application Settings', 'srv.appSettings',
        F.sel({ l: 'Classloader policy', n: 'classloaderPolicy', v: s.classloaderPolicy, o: [['MULTIPLE', 'Multiple'], ['SINGLE', 'Single']], h: 'srv.classloaderPolicy' }) +
        F.sel({ l: 'Class loading mode', n: 'applicationClassLoaderPolicy', v: s.applicationClassLoaderPolicy, o: [['PARENT_FIRST', 'Classes loaded with parent class loader first'], ['PARENT_LAST', 'Classes loaded with local class loader first (parent last)']], h: 'concept.classloader' }));
    var ap = [
      { t: 'Container Settings', items: [
        { sub: 'Web Container Settings', h: 'concept.webContainer', items: [{ l: 'Web container', href: b + '/webcontainer', h: 'concept.webContainer' }, { l: 'Web container transport chains', href: b + '/chains', h: 'wc.chains' }] },
        { l: 'Session management', href: b + '/session', h: 'concept.session' },
        { sub: 'EJB Container Settings', h: 'concept.ejbContainer', items: [{ l: 'EJB container', href: b + '/ejb', h: 'concept.ejbContainer' }] },
        { sub: 'Container Services', items: [{ l: 'Transaction service', href: b + '/tx', h: 'tx.service' }, { l: 'Dynamic cache service', act: 'notInSim', arg: 'Dynamic cache service', h: 'srv.dynacache' }] }
      ] },
      { t: 'Applications', items: [{ l: 'Installed applications', href: b + '/apps', h: 'concept.enterpriseApp' }] },
      { t: 'Server Infrastructure', items: [
        { sub: 'Java and Process Management', h: 'concept.jvm', items: [{ l: 'Class loader', href: b + '/classloader', h: 'concept.classloader' }, { l: 'Process definition', href: b + '/procdef', h: 'srv.procdef' }, { l: 'Process execution', href: b + '/procexec', h: 'srv.procexec' }, { l: 'Monitoring policy', href: b + '/monitor', h: 'srv.monitor' }] },
        { sub: 'Administration', items: [{ l: 'Custom properties', href: W.propsLink('servers|' + s.name, 'customProps', 'Application servers > ' + s.name, b), h: 'concept.customProps' }] }
      ] },
      { t: 'Additional Properties', items: [
        { l: 'Thread pools', href: b + '/threadpools', h: 'concept.threadPool' },
        { l: 'Ports', href: b + '/ports', h: 'srv.ports' },
        { l: 'Java SDKs', href: b + '/sdk', h: 'srv.sdk' },
        { l: 'Web server plug-in properties', href: b + '/plugin', h: 'srv.pluginProps' }
      ] },
      { t: 'Troubleshooting', items: [{ l: 'Logging and tracing', href: '#/tr/logs/' + W.enc(s.name), h: 'concept.logs' }, { l: 'Performance Monitoring Infrastructure (PMI)', href: '#/mon/pmi/' + W.enc(s.name), h: 'concept.pmi' }] },
      { t: 'Communications', items: [{ l: 'Ports', href: b + '/ports', h: 'srv.ports' }].concat(s.cluster === 'MessagingCluster' ? [{ l: 'Messaging engines', href: '#/sib/buses/BankingBus', h: 'sib.me' }] : []) },
      { t: 'Security', items: [{ l: 'Security domain: ' + (s.cluster === 'BankingCluster' ? 'PaymentSecurityDomain' : 'Global security'), href: s.cluster === 'BankingCluster' ? '#/sec/domains' : '#/sec/global', h: 'sec.domains' }] }
    ];
    return srvPage(s, [], '<div class="note-tr">' + tmode + '</div>' + W.cfgForm({ ref: 'servers|' + s.name, doc: srvDoc(s), cfgid: srvCfgId(s), back: '#/servers/appservers', title: 'Application server ' + s.name, tabs: tabs, general: general, ap: ap }));
  });
  A.notInSim = function (el) { W.modal({ title: el.dataset.arg, html: '<p><b>' + esc(el.dataset.arg) + '</b> sayfası bu simülasyonda ayrıntılı olarak modellenmemiştir.</p><p>Gerçek konsolda bu bölüm mevcuttur; ilgili açıklama için yanındaki ? simgesine tıklayın.</p>' }); };
  A.productInfo = function (el) {
    W.modal({ title: 'Product Information – ' + el.dataset.arg, html: '<pre class="code light">Installed Product\n  Name            IBM WebSphere Application Server Network Deployment\n  Version         ' + W.S.cell.version.replace('ND ', '') + '\n  ID              ND\n  Build Level     ' + W.S.cell.build + '\n  Build Date      ' + W.S.cell.buildDate + '\n  Package         com.ibm.websphere.ND.v90_9.0.5014.20230602_1218\n  Architecture    x86-64 (64 bit)\n  Installed Features  WebSphere Application Server Full Profile\n                      EJBDeploy tool for pre-EJB 3.0 modules\n                      Embeddable EJB container\n                      Stand-alone thin clients and resource adapters\n  Java SDK        ' + W.S.cell.javaSdk + '</pre><p class="note-tr">Bu bilgi gerçek ortamda <code>versionInfo.sh</code> komutu ile de alınabilir.</p>' });
  };

  /* Installed applications on server */
  R('/servers/appservers/:name/apps', function (p) {
    var s = W.srv(p.name), apps = W.appsOnServer(s);
    return srvPage(s, ['Installed applications'], '<p class="desc">Bu sunucuya (doğrudan veya cluster üzerinden) eşlenmiş uygulamalar.</p>' +
      W.table({ id: 'srvapps', sig: s.name, select: false, rows: apps, cols: [{ k: 'name', l: 'Application', fmt: function (r) { return W.appLink(r.name); } }, { k: 'version', l: 'Version' }, { k: 't', l: 'Target', sv: function (r) { return r.targets[0]; }, fmt: function (r) { return esc(W.targetShort(r.targets[0])); } }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(W.appStatus(r)); } }] }));
  });

  /* Process definition / JVM / exec / monitor */
  R('/servers/appservers/:name/procdef', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), d = s.processDef;
    return srvPage(s, ['Process definition'], '<p class="desc">Use this page to configure a process definition. A process definition defines the command line information necessary to start or initialize a process.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|processDef', doc: srvDoc(s), cfgid: srvCfgId(s) + 'JavaProcessDef:/', back: b, title: 'Process definition', general:
        F.text({ l: 'Executable name', n: 'executableName', v: d.executableName, h: 'srv.procdef' }) + F.text({ l: 'Executable arguments', n: 'executableArguments', v: d.executableArguments, h: 'srv.procdef' }) +
        F.text({ l: 'Working directory', n: 'workingDirectory', v: d.workingDirectory, h: 'srv.workingDir' }) + F.sel({ l: 'Executable target type', n: 'executableTargetKind', v: d.executableTargetKind, o: ['JAVA_CLASS', 'EXECUTABLE_JAR'], h: 'srv.procdef' }) + F.text({ l: 'Executable target', n: 'executableTarget', v: d.executableTarget, h: 'srv.procdef' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Java Virtual Machine', href: b + '/jvm', h: 'concept.jvm' }, { l: 'Process execution', href: b + '/procexec', h: 'srv.procexec' }, { l: 'Process logs', href: '#/tr/logs/' + W.enc(s.name), h: 'log.native' }, { l: 'Monitoring policy', href: b + '/monitor', h: 'srv.monitor' }, { l: 'Environment entries', href: W.propsLink('servers|' + s.name + '|processDef', 'environment', 'Process definition', b + '/procdef'), h: 'srv.envEntries' }] }] }));
  });
  R('/servers/appservers/:name/jvm', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), j = s.jvm;
    var general =
      F.ta({ l: 'Classpath', n: 'classpath', v: j.classpath, h: 'jvm.classpath', style: 'height:44px' }) +
      F.ta({ l: 'Boot Classpath', n: 'bootClasspath', v: j.bootClasspath, h: 'jvm.bootClasspath', style: 'height:44px' }) +
      F.ck({ l: 'Verbose class loading', n: 'verboseModeClass', v: j.verboseModeClass, h: 'jvm.verboseClass' }) +
      F.ck({ l: 'Verbose garbage collection', n: 'verboseModeGarbageCollection', v: j.verboseModeGarbageCollection, h: 'jvm.verboseGC' }) +
      F.ck({ l: 'Verbose JNI', n: 'verboseModeJNI', v: j.verboseModeJNI, h: 'jvm.verboseJNI' }) +
      F.num({ l: 'Initial heap size', n: 'initialHeapSize', v: j.initialHeapSize, unit: 'MB', h: 'jvm.initialHeap', min: 0 }) +
      F.num({ l: 'Maximum heap size', n: 'maximumHeapSize', v: j.maximumHeapSize, unit: 'MB', h: 'jvm.maxHeap', min: 0 }) +
      F.ck({ l: 'Run HProf', n: 'runHProf', v: j.runHProf, h: 'jvm.hprof' }) + F.text({ l: 'HProf Arguments', n: 'hprofArguments', v: j.hprofArguments, h: 'jvm.hprof' }) +
      F.ck({ l: 'Debug Mode', n: 'debugMode', v: j.debugMode, h: 'jvm.debug' }) + F.text({ l: 'Debug arguments', n: 'debugArgs', v: j.debugArgs, h: 'jvm.debug' }) +
      F.ta({ l: 'Generic JVM arguments', n: 'genericJvmArguments', v: j.genericJvmArguments, h: 'jvm.genericArgs' }) +
      F.text({ l: 'Executable JAR file name', n: 'executableJarFileName', v: j.executableJarFileName, h: 'jvm.execJar' }) +
      F.ck({ l: 'Disable JIT', n: 'disableJIT', v: j.disableJIT, h: 'jvm.disableJit' }) + F.ro({ l: 'Operating system name', v: j.osName, h: 'jvm.osName' });
    return srvPage(s, [['Process definition', b + '/procdef'], 'Java Virtual Machine'], '<p class="desc">Use this page to configure advanced Java(TM) virtual machine settings.</p>' +
      '<div class="note-tr">Node <b>' + esc(s.node) + '</b> fiziksel belleği: ' + W.node(s.node).ramGB + ' GB. Bu node üzerindeki tüm JVM\'lerin (sunucular + node agent) maksimum heap toplamı + native bellek, fiziksel belleği aşmamalıdır.' + W.hi('concept.jvm') + '</div>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|jvm', doc: srvDoc(s), cfgid: srvCfgId(s) + 'JavaProcessDef:/JavaVirtualMachine:/', back: b + '/procdef', title: 'Java Virtual Machine (' + s.name + ')', validate: 'jvm', general: general,
        ap: [{ t: 'Additional Properties', items: [{ l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|jvm', 'systemProperties', 'Java Virtual Machine', b + '/jvm'), h: 'jvm.customProps' }] }] }));
  });
  W.validators.jvm = function (v, form) {
    var e = [];
    if (v.initialHeapSize && v.maximumHeapSize && v.initialHeapSize > v.maximumHeapSize) e.push('Initial heap size (' + v.initialHeapSize + ' MB) maximum heap size (' + v.maximumHeapSize + ' MB) değerinden büyük olamaz. JVM bu ayarla başlatılamaz (JVMJ9VM... Initial heap size must be less than or equal to maximum heap size).');
    var s = W.resolve(form.dataset.ref.split('|').slice(0, 2).join('|'));
    if (s && s.node && v.maximumHeapSize) {
      var ram = W.node(s.node).ramGB * 1024;
      var total = W.S.servers.filter(function (x) { return x.node === s.node && x.name !== s.name; }).reduce(function (a, x) { return a + (+x.jvm.maximumHeapSize || 0); }, 0) + v.maximumHeapSize + 512;
      if (total > ram * 0.85) W.msg('warning', 'Uyarı: ' + s.node + ' üzerindeki JVM maksimum heap toplamı (' + total + ' MB) fiziksel belleğin (' + ram + ' MB) %85\'ini aşıyor. İşletim sistemi swap\'a düşebilir; GC duraklamaları ve OutOfMemory riski artar.');
    }
    if (/-Xmx|-Xms/.test(v.genericJvmArguments || '')) W.msg('warning', 'Uyarı: Generic JVM arguments içinde -Xms/-Xmx kullanılmış. Heap boyutlarını Initial/Maximum heap size alanlarından yönetin; aksi halde iki ayar birbiriyle çelişir ve hangisinin geçerli olduğu belirsizleşir.');
    return e;
  };
  R('/servers/appservers/:name/procexec', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), x = s.procExec;
    return srvPage(s, [['Process definition', b + '/procdef'], 'Process execution'], '<p class="desc">Use this page to configure how the process runs on the operating system.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|procExec', doc: srvDoc(s), cfgid: srvCfgId(s) + 'JavaProcessDef:/ProcessExecution:/', back: b + '/procdef', title: 'Process execution', general:
        F.num({ l: 'Process priority', n: 'processPriority', v: x.processPriority, h: 'srv.procexec' }) + F.text({ l: 'UMASK', n: 'umask', v: x.umask, cls: 'short', h: 'srv.umask' }) +
        F.text({ l: 'Run as user', n: 'runAsUser', v: x.runAsUser, h: 'srv.runAs' }) + F.text({ l: 'Run as group', n: 'runAsGroup', v: x.runAsGroup, h: 'srv.runAs' }) + F.num({ l: 'Run in process group', n: 'runInProcessGroup', v: x.runInProcessGroup, h: 'srv.procexec' }) }));
  });
  R('/servers/appservers/:name/monitor', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), m = s.monitor;
    return srvPage(s, [['Process definition', b + '/procdef'], 'Monitoring policy'], '<p class="desc">Use this page to configure the process monitoring policy. Node agent, yönettiği sunucuları bu politikaya göre izler ve gerekirse yeniden başlatır.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|monitor', doc: srvDoc(s), cfgid: srvCfgId(s) + 'JavaProcessDef:/MonitoringPolicy:/', back: b + '/procdef', title: 'Monitoring policy', general:
        F.num({ l: 'Maximum startup attempts', n: 'maximumStartupAttempts', v: m.maximumStartupAttempts, h: 'srv.monitor.attempts', min: 0 }) + F.num({ l: 'Ping interval', n: 'pingInterval', v: m.pingInterval, unit: 'seconds', h: 'srv.monitor.ping', min: 1 }) +
        F.num({ l: 'Ping timeout', n: 'pingTimeout', v: m.pingTimeout, unit: 'seconds', h: 'srv.monitor.ping', min: 1 }) + F.ck({ l: 'Automatic restart', n: 'autoRestart', v: m.autoRestart, h: 'srv.monitor.restart' }) +
        F.sel({ l: 'Node restart state', n: 'nodeRestartState', v: m.nodeRestartState, o: ['STOPPED', 'RUNNING', 'PREVIOUS'], h: 'srv.monitor.nodeRestart' }) }));
  });

  /* Thread pools */
  R('/servers/appservers/:name/threadpools', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name);
    return srvPage(s, ['Thread pools'], '<p class="desc">Use this page to select a thread pool to configure. Thread pools enable components of the server to reuse threads, which eliminates the need to create new threads at run time.</p>' + W.prefs() +
      W.table({ id: 'tp', sig: s.name, rows: s.threadPools, key: function (r) { return r.name; }, select: false,
        cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="' + b + '/threadpools/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'description', l: 'Description' }, { k: 'minimumSize', l: 'Minimum Size', h: 'tp.min' }, { k: 'maximumSize', l: 'Maximum Size', h: 'tp.max' }, { k: 'inactivityTimeout', l: 'Thread inactivity timeout', h: 'tp.timeout' }] }));
  });
  R('/servers/appservers/:name/threadpools/:pool', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), t = W.by(s.threadPools, 'name', p.pool);
    return srvPage(s, [['Thread pools', b + '/threadpools'], t.name], '<p class="desc">Use this page to change the configuration settings for a thread pool.</p>' + (t.name === 'WebContainer' ? '<div class="note-tr">WebContainer havuzu, HTTP isteklerini (servlet/JSP/REST) işleyen thread\'leri sağlar. Eşzamanlı istek kapasitesi = maksimum thread sayısı. Ayrıca bu havuzun boyutu ile Data source <i>Maximum connections</i> değeri birlikte düşünülmelidir.</div>' : '') +
      W.cfgForm({ ref: 'servers|' + s.name + '|threadPools|' + t.name, doc: srvDoc(s), cfgid: srvCfgId(s) + 'ThreadPoolManager:/ThreadPool:' + t.name + '/', back: b + '/threadpools', title: 'Thread pool ' + t.name, validate: 'tp', general:
        F.ro({ l: 'Name', v: t.name, h: 'concept.threadPool' }) + F.text({ l: 'Description', n: 'description', v: t.description }) +
        F.num({ l: 'Minimum Size', n: 'minimumSize', v: t.minimumSize, unit: 'threads', h: 'tp.min', min: 0 }) + F.num({ l: 'Maximum Size', n: 'maximumSize', v: t.maximumSize, unit: 'threads', h: 'tp.max', min: 1 }) +
        F.num({ l: 'Thread inactivity timeout', n: 'inactivityTimeout', v: t.inactivityTimeout, unit: 'milliseconds', h: 'tp.timeout', min: 0 }) +
        F.ck({ l: 'Allow thread allocation beyond maximum thread size', n: 'isGrowable', v: t.isGrowable, h: 'tp.growable' }) }));
  });
  W.validators.tp = function (v) {
    var e = [];
    if (v.minimumSize > v.maximumSize) e.push('Minimum Size, Maximum Size değerinden büyük olamaz.');
    if (v.isGrowable) W.msg('warning', 'Uyarı: "Allow thread allocation beyond maximum" etkinleştirildi. Yük altında thread sayısı sınırsız artabilir; bellek tükenmesi (native OOM) ve CPU doygunluğu riski doğar.');
    return e;
  };

  /* Transaction service */
  R('/servers/appservers/:name/tx', function (p, q) {
    var s = W.srv(p.name), b = srvBase(s.name), t = s.tx;
    var tabs = [['Runtime', b + '/tx?tab=runtime', q.tab === 'runtime'], ['Configuration', b + '/tx', q.tab !== 'runtime']];
    if (q.tab === 'runtime') {
      var up = W.serverStatus(s) === 'started';
      return srvPage(s, ['Transaction service'], '<div class="tabs">' + tabs.map(function (x) { return '<a href="' + x[1] + '"' + (x[2] ? ' class="on"' : '') + '>' + x[0] + '</a>'; }).join('') + '</div>' +
        (up ? '' : '<div class="msgbox err">Sunucu çalışmadığı için runtime bilgisi alınamıyor.</div>') +
        W.kvTable([['Transaction log directory', esc(t.transactionLogDirectory), 'tx.logDir'], ['Total transaction lifetime timeout', t.totalTranLifetimeTimeout + ' s', 'tx.totalLifetime'], ['Client inactivity timeout', t.clientInactivityTimeout + ' s', 'tx.clientInactivity'],
          ['Imported prepared transactions', up ? '0' : '-', 'tx.recovery'], ['Transactions to retry', up ? '0' : '-', 'tx.recovery'], ['Transactions with heuristic outcome', up ? (s.name === 'BankSrv02' ? '1 (Review)' : '0') : '-', 'tx.heuristic'], ['Transactions requiring manual completion', up ? '0' : '-', 'tx.heuristic']]) +
        (up && s.name === 'BankSrv02' ? '<div class="note-tr">BankSrv02 üzerinde 1 adet heuristic sonuçlu işlem var (örnek senaryo: veritabanı XA rollback yaparken MQ commit etmiş). Bu durum veri tutarsızlığı riskidir ve uygulama ekibiyle incelenmelidir.' + W.hi('tx.heuristic') + '</div>' : ''));
    }
    return srvPage(s, ['Transaction service'], '<p class="desc">Use this page to specify settings for the transaction service, as well as manage active transaction locks. The transaction service is a server runtime component that coordinates updates to multiple resource managers to ensure atomic updates of data.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|tx', doc: srvDoc(s), cfgid: srvCfgId(s) + 'TransactionService:/', back: b, title: 'Transaction service', tabs: tabs, general:
        F.text({ l: 'Transaction log directory', n: 'transactionLogDirectory', v: t.transactionLogDirectory, h: 'tx.logDir' }) +
        F.num({ l: 'Total transaction lifetime timeout', n: 'totalTranLifetimeTimeout', v: t.totalTranLifetimeTimeout, unit: 'seconds', h: 'tx.totalLifetime', min: 0 }) +
        F.num({ l: 'Asynchronous response timeout', n: 'asyncResponseTimeout', v: t.asyncResponseTimeout, unit: 'seconds', h: 'tx.async', min: 0 }) +
        F.num({ l: 'Client inactivity timeout', n: 'clientInactivityTimeout', v: t.clientInactivityTimeout, unit: 'seconds', h: 'tx.clientInactivity', min: 0 }) +
        F.num({ l: 'Maximum transaction timeout', n: 'propogatedOrBMTTranLifetimeTimeout', v: t.propogatedOrBMTTranLifetimeTimeout, unit: 'seconds', h: 'tx.maxTimeout', min: 0 }) +
        F.num({ l: 'Heuristic retry limit', n: 'heuristicRetryLimit', v: t.heuristicRetryLimit, unit: 'retries', h: 'tx.heuristicRetry', min: 0 }) +
        F.num({ l: 'Heuristic retry wait', n: 'heuristicRetryWait', v: t.heuristicRetryWait, unit: 'seconds', h: 'tx.heuristicRetry', min: 0 }) +
        F.sel({ l: 'Heuristic completion direction', n: 'LPSHeuristicCompletion', v: t.LPSHeuristicCompletion, o: ['ROLLBACK', 'COMMIT', 'MANUAL'], h: 'tx.heuristic' }) +
        F.ck({ l: 'Enable file locking', n: 'enableFileLocking', v: t.enableFileLocking, h: 'tx.fileLocking' }) +
        F.ck({ l: 'Enable protocol security', n: 'enableProtocolSecurity', v: t.enableProtocolSecurity, h: 'tx.protocolSecurity' }) +
        F.ck({ l: 'Accept heuristic hazard', n: 'acceptHeuristicHazard', v: t.acceptHeuristicHazard, h: 'tx.lps' }) +
        F.ck({ l: 'Enable logging for heuristic reporting', n: 'enableLoggingForHeuristicReporting', v: t.enableLoggingForHeuristicReporting, h: 'tx.heuristic' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|tx', 'customProps', 'Transaction service', b + '/tx'), h: 'concept.customProps' }, { l: 'Transaction recovery (Cluster HA)', href: '#/clusters/' + W.enc(s.cluster || ''), h: 'tx.recovery' }] }] }));
  });

  /* Web container, chains, session, EJB */
  R('/servers/appservers/:name/webcontainer', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), w = s.webContainer;
    return srvPage(s, ['Web container'], '<p class="desc">Configure the Web container. The Web container processes servlets, JavaServer Pages (JSP) files and other types of server-side includes.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|webContainer', doc: srvDoc(s), cfgid: srvCfgId(s) + 'ApplicationServer:/WebContainer:/', back: b, title: 'Web container', general:
        F.sel({ l: 'Default virtual host', n: 'defaultVirtualHost', v: w.defaultVirtualHost, o: W.S.virtualHosts.map(function (v) { return v.name; }), h: 'concept.vhost' }) +
        F.ck({ l: 'Enable servlet caching', n: 'enableServletCaching', v: w.enableServletCaching, h: 'wc.servletCaching' }) +
        F.ck({ l: 'Disable servlet request and response pooling', n: 'disablePooling', v: w.disablePooling, h: 'wc.pooling' }) +
        F.ck({ l: 'Enable port based virtual host matching', n: 'enablePortBasedVirtualHostMatching', v: w.enablePortBasedVirtualHostMatching, h: 'concept.vhost' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Session management', href: b + '/session', h: 'concept.session' }, { l: 'Web container transport chains', href: b + '/chains', h: 'wc.chains' }, { l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|webContainer', 'customProps', 'Web container', b + '/webcontainer'), h: 'concept.customProps' }] }] }));
  });
  R('/servers/appservers/:name/chains', function (p) {
    var s = W.srv(p.name), P = s.ports;
    var rows = [['WCInboundAdmin', 'admin_host', P.WC_adminhost, false], ['WCInboundAdminSecure', 'admin_host', P.WC_adminhost_secure, true], ['WCInboundDefault', 'default_host', P.WC_defaulthost, false], ['WCInboundDefaultSecure', 'default_host', P.WC_defaulthost_secure, true]]
      .map(function (r) { return { name: r[0], vh: r[1], port: r[2], ssl: r[3] }; });
    return srvPage(s, [['Web container', srvBase(s.name) + '/webcontainer'], 'Web container transport chains'], '<p class="desc">Transport chains represent network protocol stacks that operate within a client or server. Plug-in, istekleri bu zincirlerin portlarına (Transport öğeleri) gönderir.</p>' +
      W.table({ id: 'chains', sig: s.name, rows: rows, select: false, cols: [{ k: 'name', l: 'Name', h: 'wc.chains' }, { k: 'en', l: 'Enabled', fmt: function () { return 'Enabled'; } }, { k: 'host', l: 'Host', fmt: function () { return '*'; } }, { k: 'port', l: 'Port' }, { k: 'ssl', l: 'SSL Enabled', fmt: function (r) { return r.ssl ? 'Enabled' : 'Disabled'; } }, { k: 'vh', l: 'Virtual host (WC_*)', h: 'concept.vhost' }] }));
  });
  R('/servers/appservers/:name/session', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), m = s.session;
    return srvPage(s, ['Session management'], '<p class="desc">Session management settings. Bu ayarlar sunucu seviyesindedir; uygulama (Application) veya web modülü seviyesinde <i>Override session management</i> ile geçersiz kılınabilir.' + W.hi('concept.session') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|session', doc: srvDoc(s), cfgid: srvCfgId(s) + 'ApplicationServer:/WebContainer:/SessionManager:/', back: b, title: 'Session management', validate: 'session', general:
        F.grp('Session tracking mechanism', 'sess.tracking',
          F.ck({ l: 'Enable SSL ID tracking (deprecated)', n: 'enableSSLTracking', v: m.enableSSLTracking, h: 'sess.ssl' }) +
          F.ck({ l: 'Enable cookies', n: 'enableCookies', v: m.enableCookies, h: 'sess.cookies' }) + '<div style="margin:-4px 0 6px 24px"><a href="' + b + '/session/cookies">Cookie ayarları (Cookies)</a></div>' +
          F.ck({ l: 'Enable URL rewriting', n: 'enableUrlRewriting', v: m.enableUrlRewriting, h: 'sess.urlRewrite' }) +
          F.ck({ l: 'Enable protocol switch rewriting', n: 'enableProtocolSwitchRewriting', v: m.enableProtocolSwitchRewriting, h: 'sess.urlRewrite' })) +
        F.num({ l: 'Maximum in-memory session count', n: 'maxInMemorySessionCount', v: m.maxInMemorySessionCount, unit: 'sessions', h: 'sess.maxInMemory', min: 1 }) +
        F.ck({ l: 'Allow overflow', n: 'allowOverflow', v: m.allowOverflow, h: 'sess.overflow' }) +
        F.num({ l: 'Session timeout (Set timeout)', n: 'invalidationTimeout', v: m.invalidationTimeout, unit: 'minutes', h: 'sess.timeout' }) +
        F.ck({ l: 'Security integration', n: 'enableSecurityIntegration', v: m.enableSecurityIntegration, h: 'sess.security' }) +
        F.ck({ l: 'Serialize session access', n: 'allowSerializedSessionAccess', v: m.allowSerializedSessionAccess, h: 'sess.serialize' }) +
        F.num({ l: 'Maximum wait time', n: 'maxWaitTime', v: m.maxWaitTime, unit: 'seconds', h: 'sess.serialize' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Distributed environment settings', href: b + '/session/dist', h: 'sess.distributed' }, { l: 'Cookies', href: b + '/session/cookies', h: 'sess.cookies' }, { l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|session', 'customProps', 'Session management', b + '/session'), h: 'concept.customProps' }] }] }));
  });
  W.validators.session = function (v) {
    if (!v.enableCookies && !v.enableUrlRewriting && !v.enableSSLTracking) return ['En az bir session tracking mekanizması seçilmelidir.'];
    if (+v.invalidationTimeout > 240) W.msg('warning', 'Uyarı: Session timeout ' + v.invalidationTimeout + ' dakika. Uzun süreler bellekte çok sayıda session birikmesine ve güvenlik riskine (oturum ele geçirme penceresi) yol açar.');
  };
  R('/servers/appservers/:name/session/cookies', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), m = s.session;
    return srvPage(s, [['Session management', b + '/session'], 'Cookies'], '<p class="desc">Session tracking cookie ayarları.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|session', doc: srvDoc(s), cfgid: srvCfgId(s) + 'ApplicationServer:/WebContainer:/SessionManager:/Cookie:/', back: b + '/session', title: 'Session cookies', general:
        F.text({ l: 'Cookie name', n: 'cookieName', v: m.cookieName, h: 'sess.cookieName' }) + F.ck({ l: 'Restrict cookies to HTTPS sessions', n: 'cookieSecure', v: m.cookieSecure, h: 'sess.cookieSecure' }) +
        F.ck({ l: 'Set session cookies to HTTPOnly to help prevent cross-site scripting attacks', n: 'cookieHttpOnly', v: m.cookieHttpOnly, h: 'sess.cookieSecure' }) + F.text({ l: 'Cookie domain', n: 'cookieDomain', v: m.cookieDomain, h: 'sess.cookieName' }) +
        F.text({ l: 'Cookie path', n: 'cookiePath', v: m.cookiePath, h: 'sess.cookieName' }) + F.num({ l: 'Cookie maximum age (-1 = current browser session)', n: 'cookieMaxAge', v: m.cookieMaxAge, unit: 'seconds', h: 'sess.cookieName' }) }));
  });
  R('/servers/appservers/:name/session/dist', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), m = s.session;
    var doms = [['', '(none)']].concat(W.S.replicationDomains.map(function (d) { return [d.name, d.name]; }));
    return srvPage(s, [['Session management', b + '/session'], 'Distributed environment settings'], '<p class="desc">Specifies whether to use a database or memory-to-memory replication for session distribution. Cluster ortamında bir üye çöktüğünde kullanıcının oturumunun kaybolmaması için gereklidir.' + W.hi('sess.distributed') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|session', doc: srvDoc(s), cfgid: srvCfgId(s) + 'ApplicationServer:/WebContainer:/SessionManager:/', back: b + '/session', title: 'Distributed environment settings', validate: 'sessdist', general:
        F.radio({ l: 'Distributed sessions', n: 'sessionPersistenceMode', v: m.sessionPersistenceMode, h: 'sess.distributed', o: [['NONE', 'None'], ['DATABASE', 'Database', 'sess.database'], ['DATA_REPLICATION', 'Memory-to-memory replication', 'concept.m2m']] }) +
        F.grp('Database settings', 'sess.database', F.text({ l: 'Datasource JNDI name', n: 'datasourceJNDIName', v: m.datasourceJNDIName, h: 'sess.database' }) + F.text({ l: 'Table name', n: 'tableName', v: m.tableName, h: 'sess.database' }) +
          F.sel({ l: 'Write frequency', n: 'writeFrequency', v: m.writeFrequency, o: ['END_OF_SERVLET_SERVICE', 'MANUAL_UPDATE', 'TIME_BASED_WRITE'], h: 'sess.writeFreq' }) + F.sel({ l: 'Write contents', n: 'writeContents', v: m.writeContents, o: ['ONLY_UPDATED_ATTRIBUTES', 'ALL_SESSION_ATTRIBUTES'], h: 'sess.writeFreq' })) +
        F.grp('Memory-to-memory replication', 'concept.m2m', F.sel({ l: 'Replication domain', n: 'replicationDomain', v: m.replicationDomain, o: doms, h: 'concept.replicationDomain' }) +
          F.sel({ l: 'Replication mode', n: 'replicationMode', v: m.replicationMode, o: [['BOTH', 'Both client and server'], ['CLIENT', 'Client only'], ['SERVER', 'Server only']], h: 'sess.replicationMode' })) }));
  });
  W.validators.sessdist = function (v) {
    if (v.sessionPersistenceMode === 'DATABASE' && !v.datasourceJNDIName) return ['Database modu için Datasource JNDI name zorunludur.'];
    if (v.sessionPersistenceMode === 'DATA_REPLICATION' && !v.replicationDomain) return ['Memory-to-memory replication için bir replication domain seçilmelidir.'];
  };
  R('/servers/appservers/:name/ejb', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), e = s.ejb;
    return srvPage(s, ['EJB container'], '<p class="desc">Configures the EJB container. The EJB container provides a runtime environment for enterprise beans within the application server.</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|ejb', doc: srvDoc(s), cfgid: srvCfgId(s) + 'ApplicationServer:/EJBContainer:/', back: b, title: 'EJB container', general:
        F.text({ l: 'Passivation directory', n: 'passivationDirectory', v: e.passivationDirectory, h: 'ejb.passivation' }) + F.num({ l: 'Inactive pool cleanup interval', n: 'inactivePoolCleanupInterval', v: e.inactivePoolCleanupInterval, unit: 'milliseconds', h: 'ejb.pool' }) +
        F.text({ l: 'Default data source JNDI name', n: 'defaultDatasourceJNDIName', v: e.defaultDatasourceJNDIName, h: 'ejb.defaultDs' }) +
        F.grp('EJB cache settings', 'ejb.cache', F.num({ l: 'Cleanup interval', n: 'cleanupInterval', v: e.cleanupInterval, unit: 'milliseconds', h: 'ejb.cache' }) + F.num({ l: 'Cache size', n: 'cacheSize', v: e.cacheSize, unit: 'buckets', h: 'ejb.cache' })),
        ap: [{ t: 'Additional Properties', items: [{ l: 'EJB timer service settings', act: 'notInSim', arg: 'EJB timer service', h: 'ejb.timer' }, { l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|ejb', 'customProps', 'EJB container', b + '/ejb'), h: 'concept.customProps' }] }] }));
  });

  /* Ports, class loader, SDK, plug-in props */
  R('/servers/appservers/:name/ports', function (p) {
    var s = W.srv(p.name), host = W.hostOf(s.node);
    var rows = Object.keys(s.ports).map(function (k) { return { name: k, host: k.indexOf('WC_') === 0 || k.indexOf('SIP') === 0 || k.indexOf('SIB') === 0 ? '*' : host, port: s.ports[k] }; });
    return srvPage(s, ['Ports'], '<p class="desc">Use this page to view and manage the ports used by this server. Port değişikliğinden sonra ilgili virtual host alias\'larını güncellemeyi ve plug-in yapılandırmasını yeniden üretmeyi unutmayın.' + W.hi('srv.ports') + '</p>' +
      W.table({ id: 'ports', sig: s.name, rows: rows, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Port Name', fmt: function (r) { return esc(r.name) + W.hi(W.HELP['port.' + r.name] ? 'port.' + r.name : 'srv.ports'); } }, { k: 'host', l: 'Host' }, { k: 'port', l: 'Port' }], buttons: [{ l: 'Details...', act: 'notInSim', arg: 'Port details' }] }));
  });
  R('/servers/appservers/:name/classloader', function (p) {
    var s = W.srv(p.name);
    var modeTxt = s.applicationClassLoaderPolicy === 'PARENT_LAST' ? 'Classes loaded with local class loader first (parent last)' : 'Classes loaded with parent class loader first';
    return srvPage(s, ['Class loader'], '<p class="desc">Server seviyesindeki class loader\'lar, sunucu genelinde paylaşılan kütüphaneleri (shared library) ilişkilendirmek için kullanılır. Uygulama seviyesindeki class loader ayarı ayrıca uygulama sayfasından yapılır.' + W.hi('concept.classloader') + '</p>' +
      W.table({ id: 'srvcl', sig: s.name, rows: [{ id: 'Classloader_1', mode: modeTxt, libs: s.name === 'BatchSrv01' ? 'CommonUtilsLib' : '(none)' }], cols: [{ k: 'id', l: 'Class loader ID' }, { k: 'mode', l: 'Class loader order', h: 'concept.classloader' }, { k: 'libs', l: 'Shared library references', h: 'concept.sharedLib' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New class loader' }, { l: 'Delete', act: 'notInSim', arg: 'Delete class loader' }] }) +
      '<div class="note-tr">Class loader hiyerarşisi: <b>Bootstrap (JVM)</b> → <b>Extensions</b> → <b>WebSphere runtime (ws.ext.dirs)</b> → <b>Server class loader (bu sayfa)</b> → <b>Application (EAR) class loader</b> → <b>WAR class loader</b>. Policy = ' + esc(s.classloaderPolicy) + '. <a href="#/tr/classloader?server=' + W.enc(s.name) + '">Class loader viewer</a> ile çalışma zamanında inceleyin.</div>');
  });
  R('/servers/appservers/:name/sdk', function (p) {
    var s = W.srv(p.name);
    return srvPage(s, ['Java SDKs'], '<p class="desc">Use this page to view the Java SDKs that are installed and available to this server and to change the default SDK. WAS 9.0 traditional, IBM SDK Java Technology Edition 8 ile gelir.' + W.hi('srv.sdk') + '</p>' +
      W.table({ id: 'sdk', sig: s.name, rows: [{ name: '1.8_64', loc: '${WAS_INSTALL_ROOT}/java/8.0', def: true, bits: '64' }], cols: [{ k: 'name', l: 'Name' }, { k: 'loc', l: 'Location' }, { k: 'bits', l: 'Bits' }, { k: 'def', l: 'Default', fmt: function (r) { return r.def ? W.ICON.sync + ' true' : ''; } }], buttons: [{ l: 'Make Default', act: 'notInSim', arg: 'Make Default' }] }));
  });
  R('/servers/appservers/:name/plugin', function (p) {
    var s = W.srv(p.name), b = srvBase(s.name), pp = s.pluginProps;
    return srvPage(s, ['Web server plug-in properties'], '<p class="desc">Bu sunucuya ait <code>&lt;Server&gt;</code> öğesinin plugin-cfg.xml içindeki özellikleri. Değişiklik sonrası plug-in yapılandırmasını yeniden üretip yaymanız gerekir.' + W.hi('srv.pluginProps') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|pluginProps', doc: srvDoc(s), cfgid: srvCfgId(s) + 'WebserverPluginSettings:/', back: b, title: 'Web server plug-in properties', general:
        F.sel({ l: 'Server role', n: 'role', v: pp.role, o: [['PRIMARY', 'Primary'], ['BACKUP', 'Backup']], h: 'plg.role' }) +
        F.num({ l: 'Connect timeout', n: 'connectTimeout', v: pp.connectTimeout, unit: 'seconds', h: 'plg.connectTimeout' }) +
        F.num({ l: 'Read/write timeout (ServerIOTimeout)', n: 'serverIOTimeout', v: pp.serverIOTimeout, unit: 'seconds', h: 'plg.ioTimeout' }) +
        F.ck({ l: 'Use extended handshake to check whether application server is running', n: 'extendedHandshake', v: pp.extendedHandshake, h: 'plg.extHandshake' }) +
        F.ck({ l: 'Send the header "100 Continue" before sending the request content', n: 'waitForContinue', v: pp.waitForContinue, h: 'plg.extHandshake' }) +
        F.num({ l: 'Maximum number of connections that can be handled by the Application server (-1 = unlimited)', n: 'maxConnections', v: pp.maxConnections, h: 'plg.maxConn' }) }));
  });

  /* ------------------------------------------------------------ templates */
  R('/servers/templates', function () {
    return {
      title: 'Application server templates', help: 'srv.template',
      html: W.crumbs([['Application servers', '#/servers/appservers'], 'Server Templates']) + '<p class="desc">Use this page to view a list of server templates. Şablonlar yeni sunucu ve cluster üyesi oluştururken temel alınan hazır konfigürasyonlardır.' + W.hi('srv.template') + '</p>' + W.prefs() +
        W.table({ id: 'tpl', rows: W.S.templates, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'type', l: 'Server type' }, { k: 'description', l: 'Description' }, { k: 'builtIn', l: 'Built-in', fmt: function (r) { return r.builtIn ? 'Yes' : 'No'; } }],
          buttons: [{ l: 'New...', act: 'tplNew' }, { l: 'Delete', act: 'tplDel', need: 1 }] })
    };
  });
  A.tplNew = function () {
    W.modal({ title: 'New template', html: '<form id="tplF" onsubmit="return false">' + F.sel({ l: 'Select an existing server to use as a template', n: 'srv', o: W.S.servers.map(function (s) { return [s.name, s.node + '/' + s.name]; }), h: 'srv.template' }) + F.text({ l: 'Name', n: 'name', req: true }) + F.text({ l: 'Description', n: 'description' }) + '</form>',
      buttons: [{ l: 'OK', fn: function () {
        var v = W.readForm(document.getElementById('tplF')).vals;
        if (!v.name) { alert('Name zorunludur'); return false; }
        W.S.templates.push({ name: v.name, type: 'APPLICATION_SERVER', builtIn: false, description: v.description || ('Based on ' + v.srv) });
        W.change('cells/' + CELL() + '/templates/servertypes/APPLICATION_SERVER/servers/' + v.name, 'Template oluşturuldu: ' + v.name);
        W.cmd('Server template oluştur', ["AdminTask.createApplicationServerTemplate('[-templateName " + v.name + " -serverName " + v.srv + " -nodeName " + W.srv(v.srv).node + " -description \"" + (v.description || '') + "\"]')", 'AdminConfig.save()']);
        W.rerender();
      } }, { l: 'Cancel' }] });
  };
  A.tplDel = function (el) {
    var sel = W.selected(el.dataset.tbl), m = [];
    sel.forEach(function (n) { var t = W.by(W.S.templates, 'name', n); if (t.builtIn) m.push(n + ' yerleşik şablondur, silinemez.'); else { W.S.templates.splice(W.S.templates.indexOf(t), 1); W.change('templates', 'Template silindi: ' + n); m.push(n + ' silindi.'); } });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };

  /* ---------------------------------------------------------- web servers */
  W.wsStatus = function (w) { return W.RT.webservers[w.name] || 'stopped'; };
  R('/servers/webservers', function () {
    return {
      title: 'Web servers', help: 'concept.webserver',
      html: '<div class="page-title">Web servers' + W.hi('concept.webserver') + '</div><p class="desc">Use this page to view a list of the installed Web servers.</p>' +
        '<div class="note-tr">Web server tanımı; IBM HTTP Server\'ın WAS konsolunda temsil edilmesidir. Bu tanım sayesinde DMGR, web server için <b>plugin-cfg.xml</b> üretebilir, yayabilir (propagate) ve IHS Administration Server (port 8008) üzerinden web server\'ı başlatıp durdurabilir. Bu ortamdaki IHS\'ler <b>unmanaged node</b> üzerindedir.' + W.hi('concept.unmanagedNode') + '</div>' + W.prefs() +
        W.table({ id: 'ws', rows: W.S.webservers, key: function (r) { return r.name; },
          cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/servers/webservers/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'type', l: 'Web server Type', fmt: function () { return 'IBM HTTP Server'; } }, { k: 'node', l: 'Node', fmt: function (r) { return W.nodeLink(r.node); } }, { k: 'host', l: 'Host Name' }, { k: 'version', l: 'Version' }, { k: 'st', l: 'Status', sv: function (r) { return W.wsStatus(r); }, fmt: function (r) { return W.stIcon(W.wsStatus(r) === 'running' ? 'started' : W.wsStatus(r), ''); } }],
          buttons: [{ l: 'New...', href: '#/wz/createWebServer' }, { l: 'Delete', act: 'wsDelete', need: 1 }, { l: 'Templates...', href: '#/servers/templates' }, { l: 'Start', act: 'wsStart', need: 1 }, { l: 'Stop', act: 'wsStop', need: 1 }, { l: 'Terminate', act: 'wsStop', need: 1 }, { l: 'Generate Plug-in', act: 'wsGen', need: 1 }, { l: 'Propagate Plug-in', act: 'wsProp', need: 1 }], btnHelp: 'plg.genprop' })
    };
  });
  A.wsStart = function (el) { wsOp(W.selected(el.dataset.tbl), 'start', el.dataset.tbl); };
  A.wsStop = function (el) { wsOp(W.selected(el.dataset.tbl), 'stop', el.dataset.tbl); };
  function wsOp(names, op, tbl) {
    var m = [];
    names.forEach(function (n) {
      var w = W.by(W.S.webservers, 'name', n);
      W.RT.webservers[n] = op === 'start' ? 'starting' : 'stopping';
      setTimeout(function () { W.RT.webservers[n] = op === 'start' ? 'running' : 'stopped'; W.saveRT(); W.liveRefresh(); }, 1500);
      m.push('Web server ' + esc(n) + ' ' + (op === 'start' ? 'başlatma' : 'durdurma') + ' isteği IHS Administration Server\'a (' + esc(w.host) + ':' + w.adminPort + ') gönderildi.');
      W.cmd('Web server ' + op, ["AdminControl.invoke(AdminControl.completeObjectName('WebSphere:type=WebServer,*'), '" + op + "', '[" + CELL() + " " + w.node + " " + n + "]')"]);
    });
    if (tbl) W.clearSel(tbl);
    W.msg('info', m); W.rerender();
  }
  W.genPlugin = function (w) {
    w.lastGenerated = new Date().toLocaleString('sv-SE').replace('T', ' ');
    W.cmd('Generate Plug-in: ' + w.name, ["gen = AdminControl.completeObjectName('type=PluginCfgGenerator,*')", "AdminControl.invoke(gen, 'generate', '/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config " + CELL() + " " + w.node + " " + w.name + " false')"]);
    return 'PLGC0005I: Plug-in configuration file = /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config/cells/' + CELL() + '/nodes/' + w.node + '/servers/' + w.name + '/plugin-cfg.xml';
  };
  W.propPlugin = function (w) {
    if (W.wsStatus(w) !== 'running') return '<span style="color:#c62828">PLGC0049E: The propagation of the plug-in configuration file failed for the Web server ' + CELL() + '.' + w.node + '.' + w.name + '. IHS Administration Server\'a (' + w.host + ':' + w.adminPort + ') ulaşılamıyor.</span>';
    w.lastPropagated = new Date().toLocaleString('sv-SE').replace('T', ' ');
    W.cmd('Propagate Plug-in: ' + w.name, ["gen = AdminControl.completeObjectName('type=PluginCfgGenerator,*')", "AdminControl.invoke(gen, 'propagate', '/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config " + CELL() + " " + w.node + " " + w.name + "')"]);
    return 'PLGC0062I: The plug-in configuration file is propagated from /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config/cells/' + CELL() + '/nodes/' + w.node + '/servers/' + w.name + '/plugin-cfg.xml to ' + w.plugin.remoteConfigFile + ' on the Web server computer.<br>PLGC0048I: The propagation of the plug-in configuration file is complete for the Web server. ' + CELL() + '.' + w.node + '.' + w.name + '.';
  };
  A.wsGen = function (el) { var m = W.selected(el.dataset.tbl).map(function (n) { return W.genPlugin(W.by(W.S.webservers, 'name', n)); }); W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender(); };
  A.wsProp = function (el) { var m = W.selected(el.dataset.tbl).map(function (n) { return W.propPlugin(W.by(W.S.webservers, 'name', n)); }); W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender(); };
  A.wsGenOne = function (el) { W.msg('info', W.genPlugin(W.by(W.S.webservers, 'name', el.dataset.arg))); W.rerender(); };
  A.wsPropOne = function (el) { W.msg('info', W.propPlugin(W.by(W.S.webservers, 'name', el.dataset.arg))); W.rerender(); };
  A.wsDelete = function (el) {
    W.selected(el.dataset.tbl).forEach(function (n) {
      var w = W.by(W.S.webservers, 'name', n); W.S.webservers.splice(W.S.webservers.indexOf(w), 1);
      W.S.apps.forEach(function (a) { a.targets = a.targets.filter(function (t) { return t !== 'webserver:' + w.node + ':' + n; }); });
      W.change('cells/' + CELL() + '/nodes/' + w.node + '/servers/' + n, 'Web server silindi: ' + n);
      W.cmd('Web server sil', ["AdminTask.deleteServer('[-serverName " + n + " -nodeName " + w.node + "]')", 'AdminConfig.save()']);
    });
    W.clearSel(el.dataset.tbl); W.msg('info', 'Seçili web server tanımları silindi; uygulama eşlemeleri kaldırıldı.'); W.rerender();
  };
  function wsBase(n) { return '#/servers/webservers/' + W.enc(n); }
  function wsDoc(w) { return 'cells/' + CELL() + '/nodes/' + w.node + '/servers/' + w.name + '/server.xml'; }
  function wsPage(w, extra, body, help) { return { title: 'Web servers', help: help || 'concept.webserver', html: W.crumbs([['Web servers', '#/servers/webservers'], [w.name, wsBase(w.name)]].concat(extra || [])) + body }; }
  R('/servers/webservers/:name', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name);
    if (!w) return { title: 'Web servers', html: 'Bulunamadı' };
    var apps = W.appsOnWebserver(w);
    var general = F.ro({ l: 'Web server name', v: w.name, h: 'concept.webserver' }) + F.ro({ l: 'Type', v: 'IBM HTTP Server', h: 'concept.ihs' }) + F.ro({ l: 'Host name', v: w.host }) +
      F.num({ l: 'Port', n: 'port', v: w.port, h: 'ws.port' }) + F.text({ l: 'Web server installation location', n: 'installRoot', v: w.installRoot, h: 'ws.installRoot' }) +
      F.text({ l: 'Configuration file name', n: 'configFile', v: w.configFile, h: 'ws.httpdconf' }) + F.text({ l: 'Service name', n: 'serviceName', v: w.serviceName, h: 'ws.serviceName' }) +
      F.text({ l: 'Plug-in installation location', n: 'pluginInstallRoot', v: w.pluginInstallRoot, h: 'concept.plugin' }) +
      F.radio({ l: 'Application mapping to the Web server', n: 'mapAll', v: w.mapAll ? 'true' : 'false', o: [['true', 'All'], ['false', 'None']], h: 'ws.appMapping' }) +
      F.ro({ l: 'Status', v: W.stIcon(W.wsStatus(w) === 'running' ? 'started' : W.wsStatus(w), W.wsStatus(w) === 'running' ? 'Running' : 'Stopped'), raw: true }) +
      F.ro({ l: 'Mapped applications', v: apps.map(function (a) { return W.appLink(a.name); }).join(', ') || '(none)', raw: true, h: 'ws.appMapping' });
    return wsPage(w, [], '<p class="desc">Use this page to configure a Web server.</p>' + W.cfgForm({ ref: 'webservers|' + w.name, doc: wsDoc(w), cfgid: '/Cell:' + CELL() + '/Node:' + w.node + '/Server:' + w.name + '/WebServer:/', back: '#/servers/webservers', title: 'Web server ' + w.name, general: general,
      extraButtons: '<button type="button" class="btn" data-act="wsGenOne" data-arg="' + esc(w.name) + '">Generate Plug-in</button><button type="button" class="btn" data-act="wsPropOne" data-arg="' + esc(w.name) + '">Propagate Plug-in</button>',
      ap: [{ t: 'Additional Properties', items: [{ l: 'Plug-in properties', href: b + '/plugin', h: 'concept.plugin' }, { l: 'Configuration File (httpd.conf)', href: b + '/conf', h: 'ws.httpdconf' }, { l: 'Remote Web server management', href: b + '/remote', h: 'ws.remote' }, { l: 'Log file', href: b + '/log', h: 'ws.logs' }, { l: 'Custom properties', href: W.propsLink('webservers|' + w.name, 'customProps', 'Web server', b), h: 'concept.customProps' }] },
        { t: 'Related Items', items: [{ l: 'View plugin-cfg.xml', href: b + '/plugin/view', h: 'concept.pluginCfg' }, { l: 'İstek akışı simülatörü', href: '#/learn/requestflow', h: 'concept.plugin' }] }] }));
  });
  W.validators.ws = null;
  R('/servers/webservers/:name/plugin', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name), g = w.plugin;
    return wsPage(w, ['Plug-in properties'], '<p class="desc">Use this page to view or change the configuration settings for a Web server plug-in.</p>' +
      '<div class="note-tr">Son üretim (generate): <b>' + esc(w.lastGenerated) + '</b> · Son yayım (propagate): <b>' + esc(w.lastPropagated) + '</b></div>' +
      W.cfgForm({ ref: 'webservers|' + w.name + '|plugin', doc: wsDoc(w), cfgid: '/Cell:' + CELL() + '/Node:' + w.node + '/Server:' + w.name + '/PluginProperties:/', back: b, title: 'Plug-in properties', general:
        F.ck({ l: 'Ignore DNS failures during Web server startup', n: 'IgnoreDNSFailures', v: g.IgnoreDNSFailures, h: 'plg.ignoreDns' }) +
        F.num({ l: 'Refresh configuration interval', n: 'RefreshInterval', v: g.RefreshInterval, unit: 'seconds', h: 'plg.refresh' }) +
        F.grp('Repository copy of Web server plug-in files', 'concept.pluginCfg',
          F.text({ l: 'Plug-in configuration file name', n: 'configFileName', v: g.configFileName, h: 'concept.pluginCfg' }) +
          F.ck({ l: 'Automatically generate the plug-in configuration file', n: 'autoGenerate', v: g.autoGenerate, h: 'plg.autoGen' }) +
          F.ck({ l: 'Automatically propagate plug-in configuration file', n: 'autoPropagate', v: g.autoPropagate, h: 'plg.autoProp' }) +
          F.text({ l: 'Plug-in key store file name', n: 'keyring', v: g.keyring, h: 'plg.keyring' })) +
        F.grp('Web server copy of Web server plug-in files', 'concept.pluginCfg',
          F.text({ l: 'Plug-in configuration directory and file name', n: 'remoteConfigFile', v: g.remoteConfigFile, h: 'concept.pluginCfg' }) +
          F.text({ l: 'Plug-in key store directory and file name', n: 'remoteKeyring', v: g.remoteKeyring, h: 'plg.keyring' })) +
        F.grp('Plug-in logging', 'plg.log', F.text({ l: 'Log file name', n: 'logFile', v: g.logFile, h: 'plg.log' }) + F.sel({ l: 'Log level', n: 'LogLevel', v: g.LogLevel, o: ['Error', 'Warn', 'Stats', 'Detail', 'Debug', 'Trace'], h: 'plg.log' })),
        extraButtons: '<button type="button" class="btn" data-act="nav" data-href="' + b + '/plugin/view">View</button>',
        ap: [{ t: 'Additional Properties', items: [{ l: 'Request routing', href: b + '/plugin/routing', h: 'plg.routing' }, { l: 'Request and response', href: b + '/plugin/reqresp', h: 'plg.reqresp' }, { l: 'Caching', href: b + '/plugin/caching', h: 'plg.esi' }, { l: 'Custom properties', href: W.propsLink('webservers|' + w.name + '|plugin', 'customProps', 'Plug-in properties', b + '/plugin'), h: 'concept.customProps' }] },
          { t: 'Related Items', items: [{ l: 'Manage keys and certificates', href: '#/sec/ssl/keystores', h: 'plg.keyring' }, { l: 'Copy to Web server key store directory', act: 'wsPropOne', arg: w.name, h: 'plg.keyring' }] }] }), 'concept.plugin');
  });
  R('/servers/webservers/:name/plugin/routing', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name), g = w.plugin;
    return wsPage(w, [['Plug-in properties', b + '/plugin'], 'Request routing'], '<p class="desc">Plug-in\'in istekleri cluster üyeleri arasında nasıl dağıtacağını belirler.</p>' +
      W.cfgForm({ ref: 'webservers|' + w.name + '|plugin', doc: wsDoc(w), back: b + '/plugin', title: 'Request routing', cfgid: '/Cell:' + CELL() + '/Node:' + w.node + '/Server:' + w.name + '/PluginProperties:/PluginServerClusterProperties:/', general:
        F.radio({ l: 'Load balancing option', n: 'LoadBalance', v: g.LoadBalance, o: [['Round Robin', 'Round robin'], ['Random', 'Random']], h: 'plg.loadBalance' }) +
        F.ck({ l: 'Clone separator change', n: 'CloneSeparatorChange', v: g.CloneSeparatorChange, h: 'plg.affinity' }) +
        F.num({ l: 'Retry interval', n: 'RetryInterval', v: g.RetryInterval, unit: 'seconds', h: 'plg.retry' }) +
        F.num({ l: 'Maximum size of request content (-1 = no limit)', n: 'PostSizeLimit', v: g.PostSizeLimit, unit: 'kilobytes', h: 'plg.postSize' }) +
        F.num({ l: 'Size of the buffer that is used to cache POST requests', n: 'PostBufferSize', v: g.PostBufferSize, unit: 'kilobytes', h: 'plg.postSize' }) +
        F.ck({ l: 'Remove special headers', n: 'RemoveSpecialHeaders', v: g.RemoveSpecialHeaders, h: 'plg.specialHeaders' }) +
        F.num({ l: 'Number of retries after ServerIOTimeout (ServerIOTimeoutRetry)', n: 'ServerIOTimeoutRetry', v: g.ServerIOTimeoutRetry, h: 'plg.ioTimeout' }) }), 'plg.routing');
  });
  R('/servers/webservers/:name/plugin/reqresp', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name), g = w.plugin;
    return wsPage(w, [['Plug-in properties', b + '/plugin'], 'Request and response'], '' +
      W.cfgForm({ ref: 'webservers|' + w.name + '|plugin', doc: wsDoc(w), back: b + '/plugin', title: 'Request and response', general:
        F.num({ l: 'Maximum chunk size used when reading the response body', n: 'ResponseChunkSize', v: g.ResponseChunkSize, unit: 'kilobytes', h: 'plg.reqresp' }) +
        F.ck({ l: 'Accept content for all requests', n: 'AcceptAllContent', v: g.AcceptAllContent, h: 'plg.reqresp' }) +
        F.ck({ l: 'Enable chunked encoding (ChunkedResponse)', n: 'ChunkedResponse', v: g.ChunkedResponse, h: 'plg.reqresp' }) +
        F.sel({ l: 'Application server port preference', n: 'AppServerPortPreference', v: g.AppServerPortPreference, o: [['HostHeader', 'Host header'], ['WebserverPort', 'Web server port']], h: 'plg.portPref' }) +
        F.ck({ l: 'Virtual host matching (VHostMatchingCompat)', n: 'VHostMatchingCompat', v: g.VHostMatchingCompat, h: 'plg.portPref' }) +
        F.ck({ l: 'Enable trusted proxy (TrustedProxyEnable)', n: 'TrustedProxyEnable', v: g.TrustedProxyEnable, h: 'plg.trustedProxy' }) }), 'plg.reqresp');
  });
  R('/servers/webservers/:name/plugin/caching', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name), g = w.plugin;
    return wsPage(w, [['Plug-in properties', b + '/plugin'], 'Caching'], W.cfgForm({ ref: 'webservers|' + w.name + '|plugin', doc: wsDoc(w), back: b + '/plugin', title: 'Caching', general:
      F.ck({ l: 'Enable Edge Side Include (ESI) processing to cache the responses', n: 'ESIEnable', v: g.ESIEnable, h: 'plg.esi' }) +
      F.ck({ l: 'Enable invalidation monitor to receive notifications', n: 'ESIInvalidationMonitor', v: g.ESIInvalidationMonitor, h: 'plg.esi' }) +
      F.num({ l: 'Maximum cache size', n: 'ESIMaxCacheSize', v: g.ESIMaxCacheSize, unit: 'kilobytes', h: 'plg.esi' }) }), 'plg.esi');
  });
  R('/servers/webservers/:name/plugin/view', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name);
    return wsPage(w, [['Plug-in properties', wsBase(w.name) + '/plugin'], 'plugin-cfg.xml'], '<p class="desc">DMGR tarafındaki repository kopyası: <code>config/cells/' + esc(CELL()) + '/nodes/' + esc(w.node) + '/servers/' + esc(w.name) + '/plugin-cfg.xml</code>. Bu dosya mevcut konfigürasyondan <b>dinamik olarak</b> üretilmiştir: yeni bir uygulama kurar ya da bir cluster üyesi eklerseniz burada görürsünüz.' + W.hi('concept.pluginCfg') + '</p>' +
      '<div class="btnrow" style="border:0;margin-top:0"><button class="btn" data-act="wsGenOne" data-arg="' + esc(w.name) + '">Generate Plug-in</button><button class="btn" data-act="wsPropOne" data-arg="' + esc(w.name) + '">Propagate Plug-in</button><a href="#/learn/requestflow" style="align-self:center">→ İstek akışı simülatöründe dene</a></div>' +
      '<pre class="code">' + W.xmlHighlight(W.pluginCfg(w)) + '</pre>', 'concept.pluginCfg');
  });
  R('/servers/webservers/:name/conf', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name);
    return wsPage(w, ['Configuration File'], '<p class="desc">IBM HTTP Server yapılandırma dosyası (httpd.conf) – ilgili kısımlar. Plug-in modülünün yüklenmesi ve plugin-cfg.xml konumunun bildirilmesi bu dosyada yapılır.' + W.hi('ws.httpdconf') + '</p><pre class="code">' + esc(W.httpdConf(w)) + '</pre>', 'ws.httpdconf');
  });
  R('/servers/webservers/:name/remote', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name), b = wsBase(w.name);
    return wsPage(w, ['Remote Web server management'], '<p class="desc">DMGR\'nin, unmanaged node üzerindeki IHS\'i yönetebilmesi için IHS Administration Server bağlantı bilgileri.</p>' + W.cfgForm({ ref: 'webservers|' + w.name, doc: wsDoc(w), back: b, title: 'Remote Web server management', general:
      F.num({ l: 'Port', n: 'adminPort', v: w.adminPort, h: 'ws.remote' }) + F.ck({ l: 'Use SSL', n: 'adminSSL', v: w.adminSSL, h: 'ws.remote' }) + F.text({ l: 'User ID', n: 'adminUser', v: w.adminUser, h: 'ws.remote' }) + F.pw({ l: 'Password', v: '********', h: 'ws.remote' }) + F.pw({ l: 'Confirm password', v: '********' }) }), 'ws.remote');
  });
  R('/servers/webservers/:name/log', function (p) {
    var w = W.by(W.S.webservers, 'name', p.name);
    return wsPage(w, ['Log file'], '<div class="tabs"><a class="on">http_plugin.log</a></div><p class="desc">' + esc(w.plugin.logFile) + ' (LogLevel=' + esc(w.plugin.LogLevel) + ')' + W.hi('plg.log') + '</p><pre class="log">' + W.colorLog(W.logs.plugin(w)) + '</pre>' +
      '<div class="tabs" style="margin-top:14px"><a class="on">error_log</a></div><pre class="log">' + W.colorLog(W.logs.ihsError(w)) + '</pre>', 'ws.logs');
  });

  W.wizard('createWebServer', {
    title: 'Web servers', help: 'concept.webserver', back: '#/servers/webservers', crumbs: [['Web servers', '#/servers/webservers'], 'Create new Web server definition'],
    init: function () { return { node: 'ihsnode01', name: 'webserver3', type: 'IHS', port: 80, installRoot: '/opt/IBM/HTTPServer', pluginRoot: '/opt/IBM/WebSphere/Plugins', mapAll: true, adminPort: 8008, adminUser: 'ihsadmin' }; },
    steps: function () {
      return [
        { t: 'Select a node for the Web server and select the Web server type', h: 'concept.unmanagedNode', html: function (v) {
          return F.sel({ l: 'Select node', n: 'node', v: v.node, o: W.S.nodes.filter(function (n) { return n.type !== 'dmgr'; }).map(function (n) { return [n.name, n.name + (n.type === 'unmanaged' ? ' (unmanaged)' : ' (managed)')]; }), h: 'concept.unmanagedNode' }) +
            F.text({ l: 'Server name', n: 'name', v: v.name, req: true, h: 'concept.webserver' }) + F.sel({ l: 'Type', n: 'type', v: v.type, o: [['IHS', 'IBM HTTP Server'], ['APACHE', 'Apache'], ['IIS', 'Internet Information Services'], ['SUNJAVASYSTEM', 'Sun Java System'], ['DOMINO', 'Lotus Domino']], h: 'concept.ihs' });
        }, validate: function (v) { if (W.by(W.S.webservers, 'name', v.name)) return ['Bu adda bir web server zaten var.']; } },
        { t: 'Select a Web server template', h: 'srv.template', html: function () { return F.radio({ l: 'Select a template', n: 'tpl', v: 'IHS', o: [['IHS', 'IHS – IBM HTTP Server Template (system)']] }); } },
        { t: 'Enter the properties for the new Web server', h: 'concept.webserver', html: function (v) {
          return F.num({ l: 'Port', n: 'port', v: v.port, h: 'ws.port' }) + F.text({ l: 'Web server installation location', n: 'installRoot', v: v.installRoot, h: 'ws.installRoot' }) + F.text({ l: 'Plug-in installation location', n: 'pluginRoot', v: v.pluginRoot, h: 'concept.plugin' }) +
            F.radio({ l: 'Application mapping to the Web server', n: 'mapAll', v: v.mapAll ? 'true' : 'false', o: [['true', 'All'], ['false', 'None']], h: 'ws.appMapping' }) +
            F.grp('IBM HTTP Server Administration Server properties', 'ws.remote', F.num({ l: 'Administration Server Port', n: 'adminPort', v: v.adminPort }) + F.text({ l: 'Username', n: 'adminUser', v: v.adminUser }) + F.pw({ l: 'Password', v: '' }) + F.ck({ l: 'Use SSL', n: 'adminSSL', v: false }));
        } },
        { t: 'Confirm new Web server', html: function (v) { return W.kvTable([['Node', esc(v.node)], ['Server name', esc(v.name)], ['Type', esc(v.type)], ['Port', v.port], ['Application mapping', v.mapAll ? 'All' : 'None']]); } }
      ];
    },
    finish: function (v) {
      var n = W.node(v.node);
      var base = W.clone(W.S.webservers[0] || {});
      var w = Object.assign(base, { name: v.name, node: v.node, host: n.host, port: v.port, type: v.type, installRoot: v.installRoot, pluginInstallRoot: v.pluginRoot, mapAll: !!v.mapAll, adminPort: v.adminPort, adminUser: v.adminUser, lastGenerated: '-', lastPropagated: '-', customProps: [] });
      w.plugin = Object.assign({}, base.plugin, { remoteConfigFile: v.pluginRoot + '/config/' + v.name + '/plugin-cfg.xml', remoteKeyring: v.pluginRoot + '/config/' + v.name + '/plugin-key.kdb', logFile: v.pluginRoot + '/logs/' + v.name + '/http_plugin.log' });
      W.S.webservers.push(w); W.RT.webservers[w.name] = 'running'; W.saveRT();
      if (w.mapAll) W.S.apps.forEach(function (a) { if (a.modules.some(function (m) { return m.type === 'web' && m.vhost !== 'admin_host'; }) && a.targets.some(function (t) { return t.indexOf('cluster:') === 0; })) a.targets.push('webserver:' + w.node + ':' + w.name); });
      W.change('cells/' + CELL() + '/nodes/' + v.node + '/servers/' + v.name + '/server.xml', 'Web server oluşturuldu: ' + v.name);
      W.cmd('Web server oluştur', ["AdminTask.createWebServer('" + v.node + "', '[-name " + v.name + " -templateName IHS -serverConfig [-webPort " + v.port + " -webInstallRoot " + v.installRoot + " -pluginInstallRoot " + v.pluginRoot + " -webAppMapping " + (v.mapAll ? 'ALL' : 'NONE') + "] -remoteServerConfig [-adminPort " + v.adminPort + " -adminUserID " + v.adminUser + " -adminPasswd ******** -adminProtocol HTTP]]')", 'AdminConfig.save()']);
      return { msgs: ['Web server <b>' + esc(v.name) + '</b> tanımlandı. Kaydettikten sonra <b>Generate Plug-in</b> ve <b>Propagate Plug-in</b> işlemlerini yapın.'], go: '#/servers/webservers' };
    }
  });

  /* ---------------------------------------------------- generic/proxy/MQ */
  R('/servers/generic', function () {
    return { title: 'Generic servers', help: 'srv.generic', html: '<div class="page-title">Generic servers' + W.hi('srv.generic') + '</div><p class="desc">Use this page to view a list of generic servers. A generic server is a server that is managed in the WebSphere Application Server administrative domain, although the server is not supplied by WebSphere Application Server.</p>' + W.prefs() +
      W.table({ id: 'gen', rows: W.S.genericServers, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'node', l: 'Node' }, { k: 'executable', l: 'Executable name' }, { k: 'description', l: 'Description' }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(W.RT.generic[r.name] || 'stopped', ''); } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New generic server' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }, { l: 'Start', act: 'genOp', arg: 'started', need: 1 }, { l: 'Stop', act: 'genOp', arg: 'stopped', need: 1 }] }) };
  });
  A.genOp = function (el) { W.selected(el.dataset.tbl).forEach(function (n) { W.RT.generic[n] = el.dataset.arg; }); W.saveRT(); W.clearSel(el.dataset.tbl); W.msg('info', 'Generic server durumu güncellendi (node agent harici süreci başlatır/durdurur).'); W.rerender(); };
  R('/servers/proxy', function () {
    return { title: 'WebSphere proxy servers', help: 'srv.proxy', html: '<div class="page-title">WebSphere proxy servers' + W.hi('srv.proxy') + '</div><p class="desc">Use this page to view a list of proxy servers. A proxy server is a specific type of application server that routes HTTP requests to content servers that perform the work.</p>' + W.prefs() +
      W.table({ id: 'proxy', rows: W.S.proxyServers, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'node', l: 'Node' }, { k: 'protocols', l: 'Protocols' }, { k: 'description', l: 'Description' }, { k: 'st', l: 'Status', fmt: function () { return W.stIcon(W.RT.proxy || 'stopped', ''); } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New proxy server' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }, { l: 'Start', act: 'notInSim', arg: 'Proxy server start' }, { l: 'Stop', act: 'notInSim', arg: 'Proxy server stop' }] }) };
  });
  R('/servers/mq', function () {
    return { title: 'WebSphere MQ servers', help: 'srv.mq', html: '<div class="page-title">WebSphere MQ servers' + W.hi('srv.mq') + '</div><p class="desc">Use this page to view a list of WebSphere MQ servers. Bir MQ server tanımı, bir IBM MQ kuyruk yöneticisini (queue manager) temsil eder ve SIBus\'a MQ link/bus member olarak eklenebilir.</p>' + W.prefs() +
      W.table({ id: 'mqs', rows: W.S.mqServers, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'qmgr', l: 'Queue manager' }, { k: 'host', l: 'Host' }, { k: 'port', l: 'Port' }, { k: 'channel', l: 'Channel' }, { k: 'description', l: 'Description' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New MQ server' }, { l: 'Delete', act: 'notInSim', arg: 'Delete' }] }) };
  });

  /* ------------------------------------------------------------ clusters */
  R('/clusters', function () {
    return {
      title: 'WebSphere application server clusters', help: 'concept.cluster',
      html: '<div class="page-title">WebSphere application server clusters' + W.hi('concept.cluster') + '</div><p class="desc">Use this page to change the configuration settings for a cluster. A server cluster consists of a group of application servers. If one of the member servers fails, requests will be routed to other members of the cluster.</p>' + W.prefs() +
        W.table({ id: 'cl', rows: W.S.clusters, key: function (r) { return r.name; },
          cols: [{ k: 'name', l: 'Name', fmt: function (r) { return W.clusterLink(r.name); } }, { k: 'n', l: 'Members', sv: function (r) { return r.members.length; }, fmt: function (r) { return r.members.length; } }, { k: 'description', l: 'Description' }, { k: 'st', l: 'Status', sv: function (r) { return W.clusterStatus(r); }, fmt: function (r) { return W.stIcon(W.clusterStatus(r), ''); }, h: 'cl.status' }],
          buttons: [{ l: 'New...', href: '#/wz/createCluster' }, { l: 'Delete', act: 'clDelete', need: 1 }, { l: 'Start', act: 'clOp', arg: 'start', need: 1 }, { l: 'Stop', act: 'clOp', arg: 'stop', need: 1 }, { l: 'Ripplestart', act: 'clOp', arg: 'ripple', need: 1 }, { l: 'ImmediateStop', act: 'clOp', arg: 'immediateStop', need: 1 }], btnHelp: 'cl.ops' })
    };
  });
  W.clusterOp = function (c, op) {
    var names = c.members.map(function (m) { return m.name; });
    if (op === 'ripple') {
      var t = 0;
      names.forEach(function (n) {
        setTimeout(function () { W.serverOp([n], 'restart', true); W.liveRefresh(); }, t); t += 5200;
      });
      setTimeout(function () { W.msg('info', 'Ripplestart tamamlandı: ' + esc(c.name) + ' üyeleri sırayla yeniden başlatıldı; cluster hiçbir anda tamamen kapanmadı.'); W.liveRefresh(); }, t + 500);
      W.cmd('Cluster Ripplestart: ' + c.name, ["cl = AdminControl.completeObjectName('cell=" + CELL() + ",type=Cluster,name=" + c.name + ",*')", "AdminControl.invoke(cl, 'rippleStart')"]);
      return ['Ripplestart başlatıldı: ' + esc(c.name) + ' üyeleri teker teker durdurulup başlatılacak (' + names.join(' → ') + ').'];
    }
    var m = W.serverOp(names, op, true);
    W.cmd('Cluster ' + op + ': ' + c.name, ["cl = AdminControl.completeObjectName('cell=" + CELL() + ",type=Cluster,name=" + c.name + ",*')", "AdminControl.invoke(cl, '" + (op === 'start' ? 'start' : op === 'stop' ? 'stop' : 'stopImmediate') + "')"]);
    return m;
  };
  A.clOp = function (el) {
    var m = [];
    var names = el.dataset.tbl ? W.selected(el.dataset.tbl) : [el.dataset.name];
    names.forEach(function (n) { m = m.concat(W.clusterOp(W.cluster(n), el.dataset.arg)); });
    if (el.dataset.tbl) W.clearSel(el.dataset.tbl);
    W.msg('info', m); W.rerender();
  };
  A.clDelete = function (el) {
    var m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      var c = W.cluster(n);
      var apps = W.S.apps.filter(function (a) { return a.targets.indexOf('cluster:' + n) >= 0; });
      if (apps.length) { m.push(esc(n) + ' cluster\'ına kurulu uygulamalar var: ' + apps.map(function (a) { return esc(a.name); }).join(', ') + '. Önce bunları kaldırın.'); return; }
      if (W.clusterStatus(c) !== 'stopped') { m.push(esc(n) + ' çalışıyor; önce durdurun.'); return; }
      c.members.forEach(function (mb) { var s = W.srv(mb.name); if (s) W.S.servers.splice(W.S.servers.indexOf(s), 1); });
      W.S.clusters.splice(W.S.clusters.indexOf(c), 1);
      W.change('cells/' + CELL() + '/clusters/' + n + '/cluster.xml', 'Cluster silindi: ' + n);
      W.cmd('Cluster sil', ["AdminTask.deleteCluster('[-clusterName " + n + "]')", 'AdminConfig.save()']);
      m.push(esc(n) + ' ve üyeleri silindi.');
    });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  function clBase(n) { return '#/clusters/' + W.enc(n); }
  R('/clusters/topology', function () {
    var html = '<p class="desc">Cluster topology görünümü, hücredeki cluster\'ları, üyelerini ve üyelerin bulunduğu node\'ları ağaç yapısında gösterir.' + W.hi('concept.cluster') + '</p><div class="tree"><ul><li><b>' + esc(CELL()) + '</b> (Cell)<ul>' +
      W.S.clusters.map(function (c) {
        return '<li><span class="n"></span>' + W.clusterLink(c.name) + ' ' + W.stIcon(W.clusterStatus(c), '') + '<ul>' + c.members.map(function (m) { return '<li>' + W.srvLink(m.name) + ' — node ' + W.nodeLink(m.node) + ' (' + esc(W.hostOf(m.node)) + '), weight ' + m.weight + ' ' + W.stIcon(W.serverStatus(m.name), '') + '</li>'; }).join('') + '</ul></li>';
      }).join('') + '</ul></li></ul></div>';
    return { title: 'Cluster topology', help: 'concept.cluster', html: html };
  });
  R('/clusters/:name', function (p, q) {
    var c = W.cluster(p.name);
    if (!c) return { title: 'Clusters', html: 'Cluster bulunamadı' };
    var b = clBase(c.name), tabs = [['Runtime', b + '?tab=runtime', q.tab === 'runtime'], ['Configuration', b, q.tab !== 'runtime']];
    var cr = W.crumbs([['WebSphere application server clusters', '#/clusters'], c.name]);
    if (q.tab === 'runtime') {
      return { title: 'WebSphere application server clusters', help: 'concept.cluster', html: cr + '<div class="tabs">' + tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + t[0] + '</a>'; }).join('') + '</div>' +
        W.kvTable([['Cluster name', esc(c.name)], ['State', W.stIcon(W.clusterStatus(c)), 'cl.status'], ['Members running', c.members.filter(function (m) { return W.serverStatus(m.name) === 'started'; }).length + ' / ' + c.members.length]]) +
        '<div class="btnrow"><button class="btn" data-act="clOp" data-arg="start" data-name="' + esc(c.name) + '">Start</button><button class="btn" data-act="clOp" data-arg="stop" data-name="' + esc(c.name) + '">Stop</button><button class="btn" data-act="clOp" data-arg="ripple" data-name="' + esc(c.name) + '">Ripplestart</button></div>' };
    }
    var apps = W.S.apps.filter(function (a) { return a.targets.indexOf('cluster:' + c.name) >= 0; });
    var general = F.ro({ l: 'Cluster name', v: c.name, h: 'concept.cluster' }) + F.ro({ l: 'Bounding node group', v: 'DefaultNodeGroup', h: 'sys.nodeGroups' }) +
      F.ck({ l: 'Prefer local', n: 'preferLocal', v: c.preferLocal, h: 'cl.preferLocal' }) +
      F.ck({ l: 'Enable failover of transaction log recovery', n: 'enableHA', v: c.enableHA, h: 'tx.recovery' }) +
      F.ro({ l: 'Internal replication domain', v: c.replicationDomain ? '<a href="#/env/replication">' + esc(c.replicationDomain) + '</a> (memory-to-memory)' : '(none)', raw: true, h: 'concept.replicationDomain' }) +
      F.text({ l: 'Description', n: 'description', v: c.description }) +
      F.ro({ l: 'Deployed applications', v: apps.map(function (a) { return W.appLink(a.name); }).join(', ') || '(none)', raw: true, h: 'concept.enterpriseApp' });
    return { title: 'WebSphere application server clusters', help: 'concept.cluster', html: cr + W.cfgForm({ ref: 'clusters|' + c.name, doc: 'cells/' + CELL() + '/clusters/' + c.name + '/cluster.xml', cfgid: '/ServerCluster:' + c.name + '/', back: '#/clusters', title: 'Cluster ' + c.name, tabs: tabs, general: general,
      ap: [{ t: 'Additional Properties', items: [{ l: 'Cluster members', href: b + '/members', h: 'cl.members' }, { l: 'Backup cluster', act: 'notInSim', arg: 'Backup cluster', h: 'cl.backup' }, { l: 'Custom properties', href: W.propsLink('clusters|' + c.name, 'customProps', 'Cluster', b), h: 'concept.customProps' }] },
        { t: 'Related Items', items: [{ l: 'Cluster, WLM ve failover simülasyonu', href: '#/learn/cluster?cluster=' + W.enc(c.name), h: 'concept.wlm' }, { l: 'Session replication (Replication domains)', href: '#/env/replication', h: 'concept.m2m' }] }] }) };
  });
  R('/clusters/:name/members', function (p) {
    var c = W.cluster(p.name);
    return {
      title: 'WebSphere application server clusters', help: 'cl.members',
      html: W.crumbs([['WebSphere application server clusters', '#/clusters'], [c.name, clBase(c.name)], 'Cluster members']) + '<p class="desc">Use this page to view the list of cluster members. Weight değerleri plug-in\'in ve EJB WLM\'in istekleri dağıtma oranını belirler.' + W.hi('cl.weight') + '</p>' + W.prefs() +
        W.table({ id: 'clm', sig: c.name, rows: c.members, key: function (r) { return r.name; },
          cols: [{ k: 'name', l: 'Member name', fmt: function (r) { return W.srvLink(r.name); } }, { k: 'node', l: 'Node', fmt: function (r) { return W.nodeLink(r.node); } }, { k: 'host', l: 'Host Name', fmt: function (r) { return esc(W.hostOf(r.node)); } }, { k: 'v', l: 'Version', fmt: function () { return esc(W.S.cell.version); } },
            { k: 'weight', l: 'Configured weight', h: 'cl.weight', fmt: function (r) { return '<input type="text" class="short" style="width:50px" data-weight="' + esc(r.name) + '" value="' + r.weight + '">'; } }, { k: 'rw', l: 'Runtime weight', fmt: function (r) { return W.serverStatus(r.name) === 'started' ? r.weight : '-'; } }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(W.serverStatus(r.name), ''); } }],
          buttons: [{ l: 'New...', href: '#/wz/addMember?cluster=' + W.enc(c.name) }, { l: 'Delete', act: 'clmDelete', arg: c.name, need: 1 }, { l: 'Start', act: 'srv_start', need: 1 }, { l: 'Stop', act: 'srv_stop', need: 1 }, { l: 'ImmediateStop', act: 'srv_immediateStop', need: 1 }, { l: 'Terminate', act: 'srv_terminate', need: 1 }, { l: 'Update weights', act: 'clmWeights', arg: c.name }] })
    };
  });
  A.clmWeights = function (el) {
    var c = W.cluster(el.dataset.arg), ch = [];
    document.querySelectorAll('[data-weight]').forEach(function (i) {
      var m = W.by(c.members, 'name', i.dataset.weight), v = parseInt(i.value, 10);
      if (isNaN(v) || v < 0 || v > 20) { W.msg('error', 'Weight 0 ile 20 arasında olmalıdır (' + m.name + ').'); return; }
      if (v !== m.weight) { m.weight = v; ch.push(m.name + '=' + v); }
    });
    if (ch.length) { W.change('cells/' + CELL() + '/clusters/' + c.name + '/cluster.xml', 'Cluster member weight: ' + ch.join(', ')); W.cmd('Cluster member weight güncelle', ch.map(function (x) { var k = x.split('='); return "AdminConfig.modify(AdminConfig.getid('/ServerCluster:" + c.name + "/ClusterMember:" + k[0] + "/'), [['weight', '" + k[1] + "']])"; }).concat(['AdminConfig.save()'])); W.msg('info', 'Weight değerleri güncellendi: ' + ch.join(', ') + '. Plug-in yapılandırmasını yeniden üretip yaymayı unutmayın (LoadBalanceWeight).'); }
    W.rerender();
  };
  A.clmDelete = function (el) {
    var c = W.cluster(el.dataset.arg), m = [];
    W.selected(el.dataset.tbl).forEach(function (n) {
      if (W.RT.servers[n] !== 'stopped') { m.push(esc(n) + ' çalışıyor; önce durdurun.'); return; }
      if (c.members.length === 1) { m.push('Cluster\'ın son üyesi silinemez; uygulamalar hedefsiz kalır. Cluster\'ı silin.'); return; }
      c.members = c.members.filter(function (x) { return x.name !== n; });
      var s = W.srv(n); W.S.servers.splice(W.S.servers.indexOf(s), 1);
      W.change('cells/' + CELL() + '/clusters/' + c.name + '/cluster.xml', 'Cluster member silindi: ' + n);
      W.cmd('Cluster member sil', ["AdminTask.deleteClusterMember('[-clusterName " + c.name + " -memberNode " + s.node + " -memberName " + n + "]')", 'AdminConfig.save()']);
      m.push(esc(n) + ' cluster\'dan ve hücreden silindi.');
    });
    W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender();
  };
  function addMemberServer(cl, name, node, weight, gen, basis) {
    var slot = W.S.servers.filter(function (s) { return s.node === node; }).length;
    var ref = W.srv(basis);
    var s;
    if (ref) { s = W.clone(ref); s.id = s.name = name; s.node = node; s.slot = slot; s.ports = W.Data.ports(gen ? slot : 0); s.tx.transactionLogDirectory = '/shared/tranlog/' + CELL() + '/' + node + '/' + name + '/transaction'; }
    else { s = W.Data.newServer(name, node, gen ? slot : 0, cl, basis === 'BankingTemplate' ? 'bank' : 'std', basis === 'BankingTemplate' ? [1024, 2048] : [50, 256]); }
    s.cluster = cl; s.created = new Date().toISOString().slice(0, 10);
    W.S.servers.push(s); W.RT.servers[name] = 'stopped';
    W.ensureVhostPorts(s);
    return { name: name, node: node, weight: +weight || 2 };
  }
  W.wizard('createCluster', {
    title: 'WebSphere application server clusters', help: 'concept.cluster', back: '#/clusters', crumbs: [['WebSphere application server clusters', '#/clusters'], 'Create a new cluster'],
    init: function () { return { name: '', preferLocal: true, m2m: false, m1name: '', m1node: 'AppNode01', m1weight: 2, m1gen: true, m1basis: 'default', extra: [] }; },
    steps: function () {
      return [
        { t: 'Enter basic cluster information', h: 'concept.cluster', html: function (v) {
          return F.text({ l: 'Cluster name', n: 'name', v: v.name, req: true, h: 'concept.cluster', ph: 'ör. ApiCluster' }) + F.ck({ l: 'Prefer local', n: 'preferLocal', v: v.preferLocal, h: 'cl.preferLocal' }) +
            F.ck({ l: 'Configure HTTP session memory-to-memory replication', n: 'm2m', v: v.m2m, h: 'concept.m2m' });
        }, validate: function (v) { if (W.cluster(v.name)) return ['Bu adda bir cluster zaten var.']; if (!/^[A-Za-z][\w.-]*$/.test(v.name)) return ['Geçersiz cluster adı.']; } },
        { t: 'Create first cluster member', h: 'cl.members', html: function (v) {
          return F.text({ l: 'Member name', n: 'm1name', v: v.m1name, req: true, h: 'cl.members' }) + F.sel({ l: 'Select node', n: 'm1node', v: v.m1node, o: W.S.nodes.filter(function (n) { return n.type === 'managed'; }).map(function (n) { return n.name; }), h: 'concept.node' }) +
            F.num({ l: 'Weight', n: 'm1weight', v: v.m1weight, h: 'cl.weight', min: 0, max: 20 }) + F.ck({ l: 'Generate unique HTTP ports', n: 'm1gen', v: v.m1gen, h: 'srv.genPorts' }) +
            F.sel({ l: 'Select basis for first cluster member', n: 'm1basis', v: v.m1basis, h: 'srv.template', o: [['default', 'Create the member using an application server template: default'], ['BankingTemplate', 'Create the member using an application server template: BankingTemplate']].concat(W.S.servers.map(function (s) { return [s.name, 'Create the member using an existing application server as a template: ' + s.node + '/' + s.name]; })) });
        }, validate: function (v) { if (!v.m1name) return ['Member name zorunludur.']; if (W.srv(v.m1name)) return ['"' + v.m1name + '" adlı sunucu zaten var.']; } },
        { t: 'Create additional cluster members', h: 'cl.members', desc: 'Ek üyeler farklı node\'lara yerleştirilirse donanım/OS arızasında yüksek erişilebilirlik (vertical yerine horizontal clustering) sağlanır.', html: function (v) {
          return F.text({ l: 'Member name', n: 'mxname', v: '', h: 'cl.members' }) + F.sel({ l: 'Select node', n: 'mxnode', v: 'AppNode02', o: W.S.nodes.filter(function (n) { return n.type === 'managed'; }).map(function (n) { return n.name; }) }) + F.num({ l: 'Weight', n: 'mxweight', v: 2, h: 'cl.weight' }) +
            '<button type="button" class="btn" data-act="wzAddMember">Add Member</button>' +
            W.simpleTable(['Member name', 'Node', 'Weight'], [[esc(v.m1name), esc(v.m1node), v.m1weight]].concat(v.extra.map(function (m) { return [esc(m.name), esc(m.node), m.weight]; })));
        } },
        { t: 'Summary', html: function (v) {
          return '<p>Summary of actions:</p>' + W.kvTable([['Cluster name', esc(v.name)], ['Prefer local', v.preferLocal], ['Memory-to-memory replication', v.m2m ? 'Yes (replication domain ' + esc(v.name) + ')' : 'No'], ['Members', [v.m1name + ' (' + v.m1node + ')'].concat(v.extra.map(function (m) { return m.name + ' (' + m.node + ')'; })).map(esc).join('<br>')], ['Basis', esc(v.m1basis)]]);
        } }
      ];
    },
    finish: function (v) {
      var c = { name: v.name, preferLocal: v.preferLocal, enableHA: false, replicationDomain: v.m2m ? v.name : '', description: '', members: [], customProps: [] };
      c.members.push(addMemberServer(v.name, v.m1name, v.m1node, v.m1weight, v.m1gen, v.m1basis));
      v.extra.forEach(function (m) { c.members.push(addMemberServer(v.name, m.name, m.node, m.weight, true, v.m1name)); });
      if (v.m2m) { W.S.replicationDomains.push({ name: v.name, requestTimeout: 5, encryptionType: 'NONE', numberOfReplicas: 1, description: 'Created with cluster ' + v.name }); c.members.forEach(function (m) { var s = W.srv(m.name); s.session.sessionPersistenceMode = 'DATA_REPLICATION'; s.session.replicationDomain = v.name; }); }
      W.S.clusters.push(c); W.saveRT();
      W.change('cells/' + CELL() + '/clusters/' + v.name + '/cluster.xml', 'Cluster oluşturuldu: ' + v.name + ' (' + c.members.length + ' üye)');
      W.cmd('Cluster oluştur', ["AdminTask.createCluster('[-clusterConfig [-clusterName " + v.name + " -preferLocal " + v.preferLocal + "]" + (v.m2m ? " -replicationDomain [-createDomain true]" : '') + "]')"].concat(c.members.map(function (m, i) { return "AdminTask.createClusterMember('[-clusterName " + v.name + " -memberConfig [-memberNode " + m.node + " -memberName " + m.name + " -memberWeight " + m.weight + " -genUniquePorts true -replicatorEntry " + (v.m2m ? 'true' : 'false') + "]" + (i === 0 ? " -firstMember [-templateName " + (W.srv(v.m1basis) ? '' : v.m1basis) + "]" : '') + "]')"; })).concat(['AdminConfig.save()']));
      return { msgs: ['Cluster <b>' + esc(v.name) + '</b> ve ' + c.members.length + ' üyesi oluşturuldu. Kaydedin, node\'ları senkronize edin, ardından cluster\'ı başlatın. Web server\'lar için plug-in yapılandırmasını yeniden üretmeyi unutmayın.'], go: '#/clusters' };
    }
  });
  A.wzAddMember = function () {
    var f = document.querySelector('form.wz'), r = W.readForm(f).vals, st = W._wz.createCluster;
    if (!r.mxname) { W.msg('error', 'Member name girin.'); W.rerender(); return; }
    if (W.srv(r.mxname) || r.mxname === st.v.m1name || st.v.extra.some(function (m) { return m.name === r.mxname; })) { W.msg('error', 'Bu adda bir üye/sunucu zaten var.'); W.rerender(); return; }
    st.v.extra.push({ name: r.mxname, node: r.mxnode, weight: r.mxweight || 2 }); W.rerender();
  };
  W.wizard('addMember', {
    title: 'WebSphere application server clusters', help: 'cl.members', back: '#/clusters',
    init: function (q) { return { cluster: q.cluster || 'BankingCluster', name: '', node: 'AppNode01', weight: 2, gen: true }; },
    steps: function (v) {
      return [
        { t: 'Create additional cluster member', h: 'cl.members', desc: 'Yeni üye, cluster\'ın mevcut ilk üyesinin konfigürasyonu (cluster member template) temel alınarak oluşturulur: JVM, thread pool, session ayarları kopyalanır.', html: function (v2) {
          return F.ro({ l: 'Cluster', v: v2.cluster }) + F.text({ l: 'Member name', n: 'name', v: v2.name, req: true, h: 'cl.members' }) + F.sel({ l: 'Select node', n: 'node', v: v2.node, o: W.S.nodes.filter(function (n) { return n.type === 'managed'; }).map(function (n) { return n.name; }), h: 'concept.node' }) +
            F.num({ l: 'Weight', n: 'weight', v: v2.weight, h: 'cl.weight', min: 0, max: 20 }) + F.ck({ l: 'Generate unique HTTP ports', n: 'gen', v: v2.gen, h: 'srv.genPorts' });
        }, validate: function (v2) { if (W.srv(v2.name)) return ['Bu adda bir sunucu zaten var.']; } },
        { t: 'Summary', html: function (v2) { return W.kvTable([['Cluster', esc(v2.cluster)], ['Member', esc(v2.name)], ['Node', esc(v2.node)], ['Weight', v2.weight]]); } }
      ];
    },
    finish: function (v) {
      var c = W.cluster(v.cluster);
      c.members.push(addMemberServer(v.cluster, v.name, v.node, v.weight, v.gen, c.members[0] && c.members[0].name));
      W.saveRT();
      W.change('cells/' + CELL() + '/clusters/' + c.name + '/cluster.xml', 'Cluster member eklendi: ' + v.name);
      W.cmd('Cluster member ekle', ["AdminTask.createClusterMember('[-clusterName " + v.cluster + " -memberConfig [-memberNode " + v.node + " -memberName " + v.name + " -memberWeight " + v.weight + " -genUniquePorts " + v.gen + " -replicatorEntry false]]')", 'AdminConfig.save()']);
      return { msgs: ['<b>' + esc(v.name) + '</b>, ' + esc(v.cluster) + ' cluster\'ına eklendi. Cluster\'a kurulu uygulamalar otomatik olarak bu üyeye de dağıtılır (node senkronizasyonundan sonra). Plug-in yapılandırması yeniden üretilip yayılmazsa web server bu üyeye istek göndermez!'], go: '#/clusters/' + W.enc(v.cluster) + '/members' };
    }
  });

  /* ---------------------------------------------------------- core groups */
  R('/coregroups', function () {
    return { title: 'Core groups', help: 'concept.coreGroup', html: '<div class="page-title">Core groups' + W.hi('concept.coreGroup') + '</div><p class="desc">Use this page to manage core groups. A core group is a component of the high availability manager function. It can contain stand-alone servers, cluster members, node agents and the deployment manager.</p>' + W.prefs() +
      W.table({ id: 'cg', rows: W.S.coreGroups, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/coregroups/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'description', l: 'Description' }, { k: 'm', l: 'Members', fmt: function () { return W.allProcesses().length; } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New core group' }, { l: 'Delete', act: 'notInSim', arg: 'Delete core group' }] }) };
  });
  R('/coregroups/:name', function (p, q) {
    var g = W.by(W.S.coreGroups, 'name', p.name), b = '#/coregroups/' + W.enc(g.name);
    var cr = W.crumbs([['Core groups', '#/coregroups'], g.name]);
    var sub = q.view;
    if (sub === 'servers') {
      return { title: 'Core groups', help: 'concept.coreGroup', html: W.crumbs([['Core groups', '#/coregroups'], [g.name, b], 'Core group servers']) + W.table({ id: 'cgs', select: false, rows: W.allProcesses().map(function (x) { return { id: x.node + '/' + x.name, name: x.name, node: x.node, type: x.type }; }), cols: [{ k: 'name', l: 'Server name' }, { k: 'node', l: 'Node' }, { k: 'type', l: 'Type' }, { k: 'st', l: 'Status', fmt: function (r) { return W.stIcon(r.type === 'Application server' ? W.serverStatus(r.name) : r.type === 'Node agent' ? W.RT.nodeagents[r.node] : 'started', ''); } }] }) };
    }
    if (sub === 'policies') {
      return { title: 'Core groups', help: 'cg.policy', html: W.crumbs([['Core groups', '#/coregroups'], [g.name, b], 'Policies']) + '<p class="desc">High availability policies define how the high availability manager manages singleton services (ör. transaction log recovery, messaging engine) within the core group.' + W.hi('cg.policy') + '</p>' +
        W.table({ id: 'cgp', select: false, rows: g.policies, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Policy name' }, { k: 'type', l: 'Policy type', h: 'cg.policy' }, { k: 'match', l: 'Match criteria' }, { k: 'failback', l: 'Fail back', fmt: function (r) { return r.failback ? 'true' : 'false'; } }, { k: 'preferred', l: 'Preferred servers', fmt: function (r) { return esc(r.preferred || '-'); } }] }) +
        '<div class="sect-title" style="margin-top:14px">High availability groups (runtime)' + W.hi('cg.haGroup') + '</div>' +
        W.simpleTable(['HA group', 'Policy', 'Active member', 'Members'], [
          ['WSAF_SIB_BUS=BankingBus, WSAF_SIB_MESSAGING_ENGINE=MessagingCluster.000-BankingBus, type=WSAF_SIB', 'BankingBus ME Policy', W.serverStatus('MsgSrv01') === 'started' ? 'MsgSrv01' : (W.serverStatus('MsgSrv02') === 'started' ? 'MsgSrv02 (failover)' : '-'), 'MsgSrv01, MsgSrv02']
        ].concat(W.S.servers.filter(function (s) { return s.cluster; }).slice(0, 4).map(function (s) { return ['GN_PS=' + CELL() + '\\' + s.node + '\\' + s.name + ', IBM_hc=' + s.cluster + ', type=WAS_TRANSACTIONS', 'Clustered TM Policy', W.serverStatus(s) === 'started' ? s.name : '-', s.name]; }))) };
    }
    return { title: 'Core groups', help: 'concept.coreGroup', html: cr + W.cfgForm({ ref: 'coreGroups|' + g.name, doc: 'cells/' + CELL() + '/coregroups/' + g.name + '/coregroup.xml', back: '#/coregroups', title: 'Core group ' + g.name, general:
      F.ro({ l: 'Name', v: g.name }) + F.text({ l: 'Description', n: 'description', v: g.description }) + F.num({ l: 'Number of coordinators', n: 'numCoordinators', v: g.numCoordinators, h: 'cg.coordinator' }) +
      F.sel({ l: 'Transport type', n: 'transport', v: g.transport, o: ['CHANNEL_FRAMEWORK', 'UNICAST', 'MULTICAST'], h: 'cg.transport' }) + F.ro({ l: 'Preferred coordinator servers', v: g.preferredCoordinators, h: 'cg.coordinator' }),
      ap: [{ t: 'Additional Properties', items: [{ l: 'Core group servers', href: b + '?view=servers', h: 'concept.coreGroup' }, { l: 'Policies', href: b + '?view=policies', h: 'cg.policy' }, { l: 'Preferred coordinator servers', act: 'notInSim', arg: 'Preferred coordinator servers', h: 'cg.coordinator' }, { l: 'Discovery and failure detection', act: 'notInSim', arg: 'Discovery and failure detection', h: 'cg.coordinator' }, { l: 'Custom properties', href: W.propsLink('coreGroups|' + g.name, 'customProps', 'Core group', b), h: 'concept.customProps' }] }] }) };
  });
  R('/coregroupbridge', function () {
    var a = W.S.coreGroupBridges.accessPointGroups;
    return { title: 'Core group bridge settings', help: 'concept.coreGroupBridge', html: '<div class="page-title">Core group bridge settings' + W.hi('concept.coreGroupBridge') + '</div><p class="desc">Use this page to configure the core group bridge service. The core group bridge service connects core groups together so that they can share information about the availability of resources.</p>' +
      '<div class="note-tr">Bu hücrede tek core group (DefaultCoreGroup) olduğu için bridge gerekmez. Bridge; büyük hücrelerde (yaklaşık 50+ süreç önerilen sınır) core group\'ları bölmek veya <b>farklı hücreler arasında</b> WLM bilgisi paylaşmak (ör. hücreler arası EJB yönlendirme, ODR) için yapılandırılır.</div>' +
      W.table({ id: 'apg', select: false, rows: a, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Access point group', h: 'concept.coreGroupBridge' }, { k: 'cg', l: 'Core group access points', fmt: function (r) { return esc(r.coreGroups.join(', ')); } }, { k: 'peers', l: 'Peer access points' }] }) };
  });
})();
