/* =====================================================================
   core.js – Simülasyon çekirdeği: durum (workspace / master repository),
   yönlendirme (hash router), UI bileşenleri, yardım paneli, modal, tablo,
   form ve sihirbaz (wizard) altyapısı.
   Hiçbir gerçek IBM WAS sunucusuna bağlanmaz; tüm veriler tarayıcıdadır.
   ===================================================================== */
(function () {
  'use strict';
  var W = window.WAS = window.WAS || {};
  var LS_MASTER = 'wasSim.master.v3', LS_RT = 'wasSim.runtime.v3', LS_UI = 'wasSim.ui.v3';

  /* ------------------------------------------------------------------ util */
  var esc = W.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  W.enc = encodeURIComponent;
  W.clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  W.by = function (arr, k, v) { for (var i = 0; i < (arr || []).length; i++) if (arr[i][k] === v) return arr[i]; return null; };
  W.fmtNum = function (n, d) { return Number(n).toLocaleString('tr-TR', { maximumFractionDigits: d == null ? 0 : d, minimumFractionDigits: d == null ? 0 : d }); };
  W.now = function () { return new Date(); };
  function lsGet(k) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* özel pencere vb. */ } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { } }

  /* --------------------------------------------------------------- state */
  W.init = function () {
    var m = lsGet(LS_MASTER);
    W.S = (m && m.__v === W.Data.VERSION) ? m : W.Data.create();
    W.masterJson = JSON.stringify(W.S);
    var rt = lsGet(LS_RT);
    W.RT = (rt && rt.__v === W.Data.VERSION) ? rt : W.Data.runtime(W.S);
    W.UI = lsGet(LS_UI) || { open: {}, navW: 330, help: true };
    W.pending = [];
    W.cmdLog = [];
    W.flash = [];
  };
  W.saveUI = function () { lsSet(LS_UI, W.UI); };
  W.saveRT = function () { W.RT.__v = W.Data.VERSION; lsSet(LS_RT, W.RT); };
  W.change = function (doc, desc) {
    W.pending.push({ doc: doc, desc: desc, time: new Date().toLocaleTimeString('tr-TR') });
  };
  W.saveMaster = function () {
    W.S.__v = W.Data.VERSION;
    W.masterJson = JSON.stringify(W.S);
    lsSet(LS_MASTER, W.S);
    var n = W.pending.length; W.pending = [];
    return n;
  };
  W.discard = function () { W.S = JSON.parse(W.masterJson); W.pending = []; };
  W.resetSimulation = function () {
    lsDel(LS_MASTER); lsDel(LS_RT); lsDel(LS_UI);
    W.init(); W.renderNav(); location.hash = '#/welcome'; W.render();
  };

  /* ------------------------------------------------- wsadmin komut kaydı */
  W.cmd = function (title, lines) {
    W.cmdLog.unshift({ title: title, lines: [].concat(lines), time: new Date().toLocaleTimeString('tr-TR') });
    if (W.cmdLog.length > 30) W.cmdLog.pop();
  };

  /* -------------------------------------------------------------- scope */
  W.scopeLabel = function (s) {
    var c = W.S.cell.name;
    if (!s || s === 'cell') return 'Cell=' + c;
    var p = s.split(':');
    if (p[0] === 'node') return 'Node=' + p[1];
    if (p[0] === 'cluster') return 'Cluster=' + p[1];
    if (p[0] === 'server') return 'Node=' + p[1] + ',Server=' + p[2];
    return s;
  };
  W.scopeShort = function (s) {
    if (!s || s === 'cell') return 'Cell';
    var p = s.split(':');
    return { node: 'Node', cluster: 'Cluster', server: 'Server' }[p[0]] || s;
  };
  W.scopeFull = function (s) {
    var c = 'Cell=' + W.S.cell.name;
    if (!s || s === 'cell') return c;
    return c + ', ' + W.scopeLabel(s);
  };
  W.scopeOptions = function (withAll) {
    var o = [];
    if (withAll) o.push(['all', 'All scopes']);
    o.push(['cell', W.scopeFull('cell')]);
    W.S.nodes.filter(function (n) { return n.type !== 'unmanaged'; }).forEach(function (n) { o.push(['node:' + n.name, W.scopeFull('node:' + n.name)]); });
    W.S.clusters.forEach(function (c) { o.push(['cluster:' + c.name, W.scopeFull('cluster:' + c.name)]); });
    W.S.servers.forEach(function (s) { o.push(['server:' + s.node + ':' + s.name, W.scopeFull('server:' + s.node + ':' + s.name)]); });
    return o;
  };
  W.cfgScope = function (s) {
    var c = '/Cell:' + W.S.cell.name + '/';
    if (!s || s === 'cell') return c;
    var p = s.split(':');
    if (p[0] === 'node') return c + 'Node:' + p[1] + '/';
    if (p[0] === 'cluster') return c + 'ServerCluster:' + p[1] + '/';
    return c + 'Node:' + p[1] + '/Server:' + p[2] + '/';
  };
  W.scopeDoc = function (s) {
    var c = 'cells/' + W.S.cell.name + '/';
    if (!s || s === 'cell') return c;
    var p = s.split(':');
    if (p[0] === 'node') return c + 'nodes/' + p[1] + '/';
    if (p[0] === 'cluster') return c + 'clusters/' + p[1] + '/';
    return c + 'nodes/' + p[1] + '/servers/' + p[2] + '/';
  };
  /* Scope seçimi kutusu */
  W.scopeBox = function (pageKey, helpKey) {
    var cur = (W.UI.scope && W.UI.scope[pageKey]) || 'all';
    var opts = W.scopeOptions(true).map(function (o) { return '<option value="' + esc(o[0]) + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('');
    return '<div class="scopebox"><div class="inline-flex"><b>Scope:</b>&nbsp;' + esc(cur === 'all' ? 'All scopes' : W.scopeFull(cur)) + W.hi(helpKey || 'concept.scope') + '</div>' +
      '<div class="sv">Kaynağın görünür olacağı ve tanımlanacağı yapılandırma seviyesini seçin. Daha dar kapsam (Server) daha geniş kapsamdaki (Cell) aynı JNDI adlı tanımı geçersiz kılar.</div>' +
      '<select data-change="scope" data-page="' + esc(pageKey) + '">' + opts + '</select></div>';
  };
  W.currentScope = function (pageKey) { return (W.UI.scope && W.UI.scope[pageKey]) || 'all'; };
  W.inScope = function (pageKey, s) { var c = W.currentScope(pageKey); return c === 'all' || c === s; };

  /* -------------------------------------------------------- icons / status */
  var ICON = {
    started: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#2e9d3a" stroke="#1d6b26"/><path d="M5 3.8 L10 7 L5 10.2Z" fill="#fff"/></svg>',
    stopped: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#d23a2e" stroke="#922017"/><path d="M4.5 4.5 L9.5 9.5 M9.5 4.5 L4.5 9.5" stroke="#fff" stroke-width="1.8"/></svg>',
    partial: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#f0b400" stroke="#a37a00"/><path d="M7 3.5v4.5" stroke="#fff" stroke-width="1.8"/><circle cx="7" cy="10.3" r="1" fill="#fff"/></svg>',
    unknown: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#9aa3b2" stroke="#6b7484"/><text x="7" y="10.5" font-size="9" font-family="Arial" font-weight="bold" text-anchor="middle" fill="#fff">?</text></svg>',
    sync: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#2e9d3a" stroke="#1d6b26"/><path d="M3.8 7.2 L6 9.4 L10.3 4.8" stroke="#fff" stroke-width="1.8" fill="none"/></svg>',
    nosync: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#d23a2e" stroke="#922017"/><path d="M4 7h6" stroke="#fff" stroke-width="2"/></svg>',
    info: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#2d61b3"/><rect x="6.2" y="6" width="1.6" height="4.6" fill="#fff"/><circle cx="7" cy="4" r="1" fill="#fff"/></svg>',
    warn: '<svg class="ico" viewBox="0 0 14 14"><path d="M7 1 L13.4 12.6 H0.6Z" fill="#f0b400" stroke="#a37a00"/><rect x="6.3" y="4.6" width="1.4" height="4.4" fill="#fff"/><circle cx="7" cy="10.6" r=".9" fill="#fff"/></svg>',
    err: '<svg class="ico" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.3" fill="#d23a2e"/><path d="M4.5 4.5 L9.5 9.5 M9.5 4.5 L4.5 9.5" stroke="#fff" stroke-width="1.8"/></svg>',
    selAll: '<svg width="14" height="12" viewBox="0 0 14 12"><rect x=".5" y=".5" width="5" height="5" fill="#fff" stroke="#345"/><path d="M1.5 3 L2.8 4.3 L4.8 1.6" stroke="#1a6" fill="none"/><rect x=".5" y="6.5" width="5" height="5" fill="#fff" stroke="#345"/><path d="M1.5 9 L2.8 10.3 L4.8 7.6" stroke="#1a6" fill="none"/><path d="M7 3h7M7 9h7" stroke="#345"/></svg>',
    selNone: '<svg width="14" height="12" viewBox="0 0 14 12"><rect x=".5" y=".5" width="5" height="5" fill="#fff" stroke="#345"/><rect x=".5" y="6.5" width="5" height="5" fill="#fff" stroke="#345"/><path d="M7 3h7M7 9h7" stroke="#345"/></svg>',
    filter: '<svg width="14" height="13" viewBox="0 0 14 13"><path d="M.5 .5h13L8.5 6.5v5l-3-1.5V6.5Z" fill="#dbe6f7" stroke="#345"/></svg>',
    clearFilter: '<svg width="14" height="13" viewBox="0 0 14 13"><path d="M.5 .5h10L6.5 5.5v4l-2-1V5.5Z" fill="#fff" stroke="#345"/><path d="M9 8l4 4M13 8l-4 4" stroke="#c22" stroke-width="1.5"/></svg>'
  };
  W.ICON = ICON;
  var ST_LABEL = { started: 'Started', stopped: 'Stopped', partial: 'Partial Start', unknown: 'Unknown', starting: 'Starting', stopping: 'Stopping', sync: 'Synchronized', nosync: 'Not synchronized', running: 'Running' };
  W.stIcon = function (st, label) {
    if (st === 'starting' || st === 'stopping') return '<span class="st"><span class="spin"></span>' + esc(label || ST_LABEL[st]) + '</span>';
    var key = st === 'running' ? 'started' : st;
    return '<span class="st" title="' + esc(label || ST_LABEL[st] || st) + '">' + (ICON[key] || ICON.unknown) + (label === '' ? '' : esc(label || ST_LABEL[st] || st)) + '</span>';
  };

  /* --------------------------------------------------------------- help */
  W.HELP = W.HELP || {};
  W.help = {
    add: function (o) { for (var k in o) W.HELP[k] = o[k]; }
  };
  W.hi = function (key) { return key ? '<a class="hi" data-help="' + esc(key) + '" tabindex="0" role="button" aria-label="Açıklama" title="Açıklama">?</a>' : ''; };
  var SEC = [['what', 'Ne işe yarar?'], ['role', 'IBM WAS içindeki görevi'], ['use', 'Hangi amaçla kullanılır?'], ['when', 'Ne zaman kullanılmalı / yapılandırılmalı?'], ['benefit', 'Sağladığı fayda'], ['ex', 'Teknik örnek'], ['risk', 'Yanlış yapılandırmada olası sorunlar']];
  W.helpHtml = function (key, inModal) {
    var h = W.HELP[key];
    if (!h) return '<div class="help-entry"><h3>' + esc(key) + '</h3><p>Bu öğe için açıklama bulunamadı.</p></div>';
    var s = '<div class="help-entry"><h3>' + h.t + '</h3>';
    if (h.scope) s += '<div class="scope" title="Yapılandırma seviyesi">Seviye: ' + h.scope + '</div>';
    if (!inModal) s += '<div class="tools"><a data-act="helpModal" data-key="' + esc(key) + '">Geniş görünümde aç ⤢</a></div>';
    SEC.forEach(function (p) {
      var v = h[p[0]]; if (!v) return;
      if (p[0] === 'ex') s += '<h5>' + p[1] + '</h5><pre>' + esc(v) + '</pre>';
      else if (p[0] === 'risk') s += '<h5>' + p[1] + '</h5><div class="risk">' + v + '</div>';
      else s += '<h5>' + p[1] + '</h5><p>' + v + '</p>';
    });
    if (h.more) s += h.more;
    if (h.see && h.see.length) {
      s += '<h5>İlgili konular</h5><p>' + h.see.filter(function (k) { return W.HELP[k]; }).map(function (k) { return '<a data-help-link="' + esc(k) + '">' + W.HELP[k].t + '</a>'; }).join(' · ') + '</p>';
    }
    return s + '</div>';
  };
  W.showHelp = function (key) {
    W.UI.lastHelp = key;
    var hp = document.getElementById('helpPortlet');
    var visible = hp && getComputedStyle(hp).display !== 'none' && !hp.classList.contains('collapsed');
    if (!visible) { W.helpModal(key); return; }
    document.getElementById('fieldHelp').innerHTML = W.helpHtml(key);
    var pb = hp.querySelector('.pb'); if (pb) pb.scrollTop = 0;
    document.querySelectorAll('.hi.active').forEach(function (e) { e.classList.remove('active'); });
    document.querySelectorAll('.hi[data-help="' + key + '"]').forEach(function (e) { e.classList.add('active'); });
  };
  W.helpModal = function (key) {
    var h = W.HELP[key];
    W.modal({ title: 'Yardım – ' + (h ? h.t.replace(/<[^>]+>/g, '') : key), html: W.helpHtml(key, true) });
  };

  /* -------------------------------------------------------------- modal */
  W.modal = function (o) {
    var m = document.getElementById('modal');
    var btns = (o.buttons || [{ l: 'Kapat', close: true }]).map(function (b, i) {
      return '<button class="btn' + (i === 0 ? ' primary' : '') + '" data-mbtn="' + i + '">' + esc(b.l) + '</button>';
    }).join('');
    m.innerHTML = '<div class="mdl' + (o.wide ? ' wide' : '') + '" role="dialog" aria-modal="true"><div class="ph"><span>' + esc(o.title) + '</span><button data-mclose title="Kapat">×</button></div><div class="mb">' + o.html + '</div><div class="mf">' + btns + '</div></div>';
    m.classList.add('open');
    m._btns = o.buttons || [{ close: true }];
    var f = m.querySelector('[data-mbtn="0"]'); if (f) f.focus();
  };
  W.closeModal = function () { var m = document.getElementById('modal'); m.classList.remove('open'); m.innerHTML = ''; };

  W.toast = function (t) {
    var el = document.getElementById('toast');
    el.textContent = t; el.classList.add('on');
    clearTimeout(W._tt); W._tt = setTimeout(function () { el.classList.remove('on'); }, 2600);
  };

  /* ------------------------------------------------------------ messages */
  W.msg = function (type, items) { W.flash.push({ type: type, items: [].concat(items) }); };
  function msgsHtml(skipPending) {
    var s = '';
    W.flash.forEach(function (m) {
      var cls = m.type === 'error' ? 'err' : (m.type === 'info' ? 'info' : '');
      var ic = m.type === 'error' ? ICON.err : (m.type === 'info' ? ICON.info : ICON.warn);
      s += '<div class="msgbox ' + cls + '"><div class="mh">Messages</div><ul style="list-style:none;margin-left:0">' + m.items.map(function (i) { return '<li class="inline-flex" style="align-items:flex-start;gap:6px">' + ic + '<span>' + i + '</span></li>'; }).join('') + '</ul></div>';
    });
    W.flash = [];
    if (W.pending.length && !skipPending) {
      s += '<div class="msgbox"><div class="mh">' + ICON.warn + ' Messages</div><ul style="list-style:none;margin-left:0"><li>' +
        'Changes have been made to your local configuration. You can:<ul>' +
        '<li><a data-act="saveDirect">Save</a> directly to the master configuration.</li>' +
        '<li><a href="#/save">Review</a> changes before saving or discarding.</li></ul></li>' +
        '<li style="margin-top:4px">' + ICON.warn + ' The server may need to be restarted for these changes to take effect.</li>' +
        '<li style="margin-top:4px;color:#3b4b66">Yerel çalışma alanında (workspace) <b>' + W.pending.length + '</b> kaydedilmemiş değişiklik var. Kaydetmeden master repository ve node\'lar güncellenmez.' + W.hi('concept.workspace') + '</li></ul></div>';
    }
    return s;
  }
  W.msgsHtml = msgsHtml;

  /* -------------------------------------------------------------- portlet */
  W.portlet = function (title, body, opts) {
    opts = opts || {};
    return '<div class="portlet"' + (opts.id ? ' id="' + opts.id + '"' : '') + '><div class="ph"><span class="pt">' + esc(title) + '</span><span class="ph-icons">' +
      (opts.help ? '<a data-help="' + esc(opts.help) + '" title="Sayfa yardımı">?</a>' : '') + '<span data-act="minPortlet" title="Simge durumuna küçült">–</span></span></div><div class="pb">' + body + '</div></div>';
  };
  W.crumbs = function (arr) {
    return '<div class="crumbs">' + arr.map(function (c, i) {
      var last = i === arr.length - 1;
      var t = Array.isArray(c) ? c : [c];
      return (last || !t[1] ? '<span>' + esc(t[0]) + '</span>' : '<a href="' + t[1] + '">' + esc(t[0]) + '</a>') + (last ? '' : '<span class="gt">&gt;</span>');
    }).join('') + '</div>';
  };

  /* --------------------------------------------------------------- fields */
  function lbl(o, forId) {
    return '<label' + (forId ? ' for="' + forId + '"' : '') + '>' + (o.req ? '<span class="req">*</span>' : '') + esc(o.l) + W.hi(o.h) + '</label>';
  }
  var fid = 0;
  var F = W.F = {
    text: function (o) {
      var id = 'f' + (++fid);
      return '<div class="fld">' + lbl(o, id) + '<div class="inline-flex"><input type="' + (o.pw ? 'password' : 'text') + '" id="' + id + '" name="' + esc(o.n || '') + '" value="' + esc(o.v) + '"' +
        (o.cls ? ' class="' + o.cls + '"' : '') + (o.ro ? ' readonly' : '') + (o.num ? ' data-num="1" inputmode="numeric"' : '') + (o.req ? ' data-req="1"' : '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.min != null ? ' data-min="' + o.min + '"' : '') + (o.max != null ? ' data-max="' + o.max + '"' : '') + ' data-label="' + esc(o.l) + '">' +
        (o.unit ? '<span class="unit">' + esc(o.unit) + '</span>' : '') + '</div>' + (o.note ? '<div style="color:#555;margin-top:2px">' + o.note + '</div>' : '') + '</div>';
    },
    num: function (o) { o.num = true; o.cls = o.cls || 'short'; return F.text(o); },
    pw: function (o) { o.pw = true; return F.text(o); },
    ta: function (o) {
      var id = 'f' + (++fid);
      return '<div class="fld">' + lbl(o, id) + '<textarea id="' + id + '" name="' + esc(o.n || '') + '"' + (o.ro ? ' readonly' : '') + ' data-label="' + esc(o.l) + '"' + (o.style ? ' style="' + o.style + '"' : '') + '>' + esc(o.v) + '</textarea></div>';
    },
    sel: function (o) {
      var id = 'f' + (++fid);
      var opts = (o.o || []).map(function (x) { var v = Array.isArray(x) ? x[0] : x, t = Array.isArray(x) ? x[1] : x; return '<option value="' + esc(v) + '"' + (String(v) === String(o.v) ? ' selected' : '') + '>' + esc(t) + '</option>'; }).join('');
      return '<div class="fld">' + lbl(o, id) + '<select id="' + id + '" name="' + esc(o.n || '') + '"' + (o.ro ? ' disabled' : '') + (o.change ? ' data-change="' + o.change + '"' : '') + '>' + opts + '</select>' + (o.note ? '<div style="color:#555;margin-top:2px">' + o.note + '</div>' : '') + '</div>';
    },
    ck: function (o) {
      var id = 'f' + (++fid);
      return '<div class="ck-line"><input type="checkbox" id="' + id + '" name="' + esc(o.n || '') + '"' + (o.v ? ' checked' : '') + (o.ro ? ' disabled' : '') + '><label for="' + id + '">' + esc(o.l) + '</label>' + W.hi(o.h) + '</div>';
    },
    radio: function (o) {
      var nm = o.n || ('r' + (++fid));
      return '<div class="fld"><div class="lbl">' + esc(o.l || '') + W.hi(o.h) + '</div>' + o.o.map(function (x) {
        var id = 'f' + (++fid);
        return '<div class="radio-line"><input type="radio" id="' + id + '" name="' + esc(nm) + '" value="' + esc(x[0]) + '"' + (String(x[0]) === String(o.v) ? ' checked' : '') + (o.ro ? ' disabled' : '') + '><label for="' + id + '">' + esc(x[1]) + '</label>' + (x[2] ? W.hi(x[2]) : '') + '</div>';
      }).join('') + '</div>';
    },
    ro: function (o) {
      return '<div class="fld"><div class="lbl">' + esc(o.l) + W.hi(o.h) + '</div><div class="ro">' + (o.raw ? o.v : esc(o.v)) + '</div></div>';
    },
    grp: function (legend, help, inner) {
      return '<fieldset class="grp"><legend>' + esc(legend) + W.hi(help) + '</legend>' + inner + '</fieldset>';
    }
  };

  /* Ek özellik bağlantı grupları (sağ sütun) */
  W.apGroups = function (groups) {
    return groups.map(function (g) {
      return '<div class="ap-group"><div class="apt">' + esc(g.t) + '</div>' + g.items.map(function (it) {
        if (it.sub) return '<div class="apsub">' + esc(it.sub) + W.hi(it.h) + '</div><div class="ap-sub">' + it.items.map(apLink).join('') + '</div>';
        return apLink(it);
      }).join('') + '</div>';
    }).join('');
    function apLink(it) {
      var href = it.href || '#';
      return '<div class="ap-link"><a ' + (it.act ? 'data-act="' + it.act + '"' + (it.arg ? ' data-arg="' + esc(it.arg) + '"' : '') : 'href="' + href + '"') + '>' + esc(it.l) + '</a>' + W.hi(it.h) + '</div>';
    }
  };

  /* Konfigürasyon formu (General Properties + Additional Properties) */
  W.cfgForm = function (o) {
    // o: {ref, doc, cfgid, back, validate, general(html), ap(groups), tabs, extraButtons, noButtons}
    var tabs = '';
    if (o.tabs) tabs = '<div class="tabs">' + o.tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + esc(t[0]) + '</a>'; }).join('') + '</div>';
    var btn = o.noButtons ? '' : '<div class="btnrow">' + (o.readOnly ? '<button type="button" class="btn" data-act="goBack" data-href="' + esc(o.back || '') + '">Back</button>' :
      '<button type="button" class="btn primary" data-act="cfgApply">Apply</button><button type="button" class="btn" data-act="cfgOk">OK</button><button type="button" class="btn" data-act="cfgReset">Reset</button><button type="button" class="btn" data-act="cfgCancel">Cancel</button>') + (o.extraButtons || '') + '</div>';
    return tabs + '<form class="cfg" onsubmit="return false"' + (o.create ? ' data-create="' + esc(o.create) + '"' : '') + ' data-ref="' + esc(o.ref || '') + '" data-doc="' + esc(o.doc || '') + '" data-cfgid="' + esc(o.cfgid || '') + '" data-back="' + esc(o.back || '') + '" data-validate="' + esc(o.validate || '') + '" data-title="' + esc(o.title || '') + '">' +
      '<div class="detail"><div class="gp">' + (o.gpTitle === false ? '' : '<div class="sect-title">' + esc(o.gpTitle || 'General Properties') + '</div>') + o.general + btn + '</div>' +
      (o.ap ? '<div class="ap">' + W.apGroups(o.ap) + '</div>' : '') + '</div></form>';
  };

  /* Referans yolu: "servers|BankSrv01|jvm" -> nesne */
  W.resolve = function (ref) {
    if (!ref) return null;
    var p = ref.split('|');
    var obj = getPath(W.S, p[0]);
    if (p.length > 1 && Array.isArray(obj)) obj = W.by(obj, 'id', p[1]) || W.by(obj, 'name', p[1]) || (/^\d+$/.test(p[1]) ? obj[+p[1]] : null);
    for (var i = 2; i < p.length && obj; i++) {
      if (Array.isArray(obj)) obj = W.by(obj, 'name', p[i]) || W.by(obj, 'id', p[i]);
      else obj = obj[p[i]];
    }
    return obj;
  };
  function setPath(obj, path, v) {
    var ks = path.split('.');
    for (var i = 0; i < ks.length - 1; i++) { if (obj[ks[i]] == null) obj[ks[i]] = {}; obj = obj[ks[i]]; }
    var old = obj[ks[ks.length - 1]];
    obj[ks[ks.length - 1]] = v;
    return old;
  }
  function getPath(obj, path) { var ks = path.split('.'); for (var i = 0; i < ks.length && obj != null; i++) obj = obj[ks[i]]; return obj; }
  W.getPath = getPath; W.setPath = setPath;

  W.readForm = function (form) {
    var vals = {}, errs = [];
    form.querySelectorAll('input[name],select[name],textarea[name]').forEach(function (el) {
      if (!el.name || el.disabled) return;
      if (el.type === 'radio') { if (el.checked) vals[el.name] = el.value === 'true' ? true : el.value === 'false' ? false : el.value; return; }
      if (el.type === 'checkbox') { vals[el.name] = el.checked; return; }
      var v = el.value;
      if (el.dataset.req && !String(v).trim()) errs.push('"' + el.dataset.label + '" alanı zorunludur. (A value is required for ' + el.dataset.label + '.)');
      if (el.dataset.num && String(v).trim() !== '') {
        if (!/^-?\d+$/.test(String(v).trim())) errs.push('"' + el.dataset.label + '" alanı bir tam sayı olmalıdır.');
        else {
          v = parseInt(v, 10);
          if (el.dataset.min != null && v < +el.dataset.min) errs.push('"' + el.dataset.label + '" en az ' + el.dataset.min + ' olmalıdır.');
          if (el.dataset.max != null && v > +el.dataset.max) errs.push('"' + el.dataset.label + '" en fazla ' + el.dataset.max + ' olabilir.');
        }
      }
      vals[el.name] = v;
    });
    return { vals: vals, errs: errs };
  };
  W.validators = {};

  /* Konfigürasyon formunu uygula */
  function cfgApply(form, goBack) {
    var r = W.readForm(form);
    var vName = form.dataset.validate;
    if (vName && W.validators[vName]) { var e = W.validators[vName](r.vals, form); if (e) r.errs = r.errs.concat(e); }
    if (r.errs.length) { W.msg('error', r.errs); W.rerender(); return; }
    if (form.dataset.create) {
      var res = W.creators[form.dataset.create](r.vals, form) || {};
      if (res.error) { W.msg('error', res.error); W.rerender(); return; }
      if (res.msgs) W.msg('info', res.msgs);
      W.go((goBack ? form.dataset.back : res.go) || form.dataset.back);
      return;
    }
    var obj = W.resolve(form.dataset.ref);
    if (!obj) { W.msg('error', 'Nesne bulunamadı.'); W.render(); return; }
    var changed = [];
    Object.keys(r.vals).forEach(function (k) {
      var nv = r.vals[k], ov = getPath(obj, k);
      if (String(ov == null ? '' : ov) !== String(nv)) { setPath(obj, k, nv); changed.push([k, nv]); }
    });
    if (changed.length) {
      W.change(form.dataset.doc || 'workspace', (form.dataset.title || 'Konfigürasyon') + ': ' + changed.map(function (c) { return c[0]; }).join(', '));
      var id = form.dataset.cfgid;
      W.cmd((form.dataset.title || 'Konfigürasyon') + ' güncellendi', [
        id ? "obj = AdminConfig.getid('" + id + "')" : "obj = <yapılandırma nesnesi>",
        "AdminConfig.modify(obj, [" + changed.map(function (c) { return "['" + c[0].split('.').pop() + "', '" + String(c[1]).replace(/'/g, "\\'") + "']"; }).join(', ') + "])",
        'AdminConfig.save()'
      ]);
    } else {
      W.msg('info', 'Değişiklik yapılmadı. (No changes were made.)');
    }
    if (goBack && form.dataset.back && ('#' + W.parseHash().path) !== form.dataset.back) { location.hash = form.dataset.back; } else W.rerender();
  }
  W.creators = {};

  /* ---------------------------------------------------------------- tables */
  W._tbl = {};
  W.table = function (cfg) {
    var t = W._tbl[cfg.id];
    if (!t || t.sig !== (cfg.sig || '')) { t = W._tbl[cfg.id] = { sel: {}, sortK: null, dir: 1, filter: null, showFilter: false, sig: cfg.sig || '' }; }
    t.cfg = cfg;
    return '<div class="coll" data-tbl="' + esc(cfg.id) + '">' + tableInner(cfg.id) + '</div>';
  };
  function tableInner(id) {
    var t = W._tbl[id], cfg = t.cfg, rows = cfg.rows.slice();
    var key = cfg.key || function (r) { return r.id || r.name; };
    if (t.filter && t.filter.text) {
      var col = W.by(cfg.cols, 'k', t.filter.col) || cfg.cols[0];
      var re = new RegExp(t.filter.text.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.'), 'i');
      rows = rows.filter(function (r) { return re.test(String(col.sv ? col.sv(r) : (r[col.k] != null ? r[col.k] : ''))); });
    }
    if (t.sortK) {
      var sc = W.by(cfg.cols, 'k', t.sortK);
      rows.sort(function (a, b) {
        var x = sc.sv ? sc.sv(a) : a[sc.k], y = sc.sv ? sc.sv(b) : b[sc.k];
        if (typeof x === 'number' && typeof y === 'number') return (x - y) * t.dir;
        return String(x).localeCompare(String(y), 'tr', { numeric: true }) * t.dir;
      });
    }
    var sel = cfg.select !== false;
    var tb = '';
    if (cfg.buttons && cfg.buttons.length || cfg.tools !== false) {
      tb = '<div class="toolbar">' + (cfg.buttons || []).map(function (b) {
        return '<button type="button" class="btn" data-act="' + (b.act || 'nav') + '" data-tbl="' + esc(id) + '"' + (b.href ? ' data-href="' + esc(b.href) + '"' : '') + (b.arg ? ' data-arg="' + esc(b.arg) + '"' : '') + (b.need ? ' data-need="' + b.need + '"' : '') + '>' + esc(b.l) + '</button>';
      }).join('') + (cfg.btnHelp ? W.hi(cfg.btnHelp) : '') + '</div>' +
        (cfg.tools !== false ? '<div class="toolbar">' + (sel ? '<button type="button" class="toolicon" title="Select all" data-act="tblAll" data-tbl="' + esc(id) + '">' + ICON.selAll + '</button><button type="button" class="toolicon" title="Deselect all" data-act="tblNone" data-tbl="' + esc(id) + '">' + ICON.selNone + '</button>' : '') +
          '<button type="button" class="toolicon" title="Show the filter function" data-act="tblFilter" data-tbl="' + esc(id) + '">' + ICON.filter + '</button><button type="button" class="toolicon" title="Clear filter" data-act="tblClear" data-tbl="' + esc(id) + '">' + ICON.clearFilter + '</button></div>' : '');
    }
    var fb = '';
    if (t.showFilter) {
      fb = '<div class="filterbar"><b>Filter</b><select data-fcol>' + cfg.cols.map(function (c) { return '<option value="' + c.k + '"' + (t.filter && t.filter.col === c.k ? ' selected' : '') + '>' + esc(c.l) + '</option>'; }).join('') + '</select>' +
        '<span>Search terms:</span><input type="text" data-ftext value="' + esc(t.filter ? t.filter.text : '') + '" placeholder="ör. Bank*"><button type="button" class="btn" data-act="tblGo" data-tbl="' + esc(id) + '">Go</button>' + W.hi('ui.filter') + '</div>';
    }
    var head = '<tr>' + (sel ? '<th class="ck">Select</th>' : '') + cfg.cols.map(function (c) {
      var arrow = t.sortK === c.k ? (t.dir > 0 ? '▲' : '▼') : '⇕';
      return '<th class="' + (c.nosort ? '' : 'sortable') + '" data-sort="' + c.k + '" data-tbl="' + esc(id) + '"' + (c.w ? ' style="width:' + c.w + '"' : '') + '><span class="inline-flex">' + esc(c.l) + (c.nosort ? '' : '<span class="sa">' + arrow + '</span>') + (c.h ? W.hi(c.h) : '') + '</span></th>';
    }).join('') + '</tr>';
    var ncol = cfg.cols.length + (sel ? 1 : 0);
    var body = '';
    if (cfg.adminRow !== false) body += '<tr class="admin"><td colspan="' + ncol + '">You can administer the following resources:</td></tr>';
    if (!rows.length) body += '<tr><td colspan="' + ncol + '" class="empty">' + esc(cfg.empty || 'None') + '</td></tr>';
    rows.forEach(function (r) {
      var k = key(r);
      body += '<tr class="r' + (t.sel[k] ? ' sel' : '') + (cfg.rowClass ? ' ' + cfg.rowClass(r) : '') + '">' + (sel ? '<td class="ck"><input type="checkbox" data-rowsel="' + esc(k) + '" data-tbl="' + esc(id) + '"' + (t.sel[k] ? ' checked' : '') + ' aria-label="Select ' + esc(k) + '"></td>' : '') +
        cfg.cols.map(function (c) { return '<td>' + (c.fmt ? c.fmt(r) : esc(r[c.k])) + '</td>'; }).join('') + '</tr>';
    });
    var foot = '<tfoot><tr><td colspan="' + ncol + '">Total ' + rows.length + (rows.length !== cfg.rows.length ? ' (filtered from ' + cfg.rows.length + ')' : '') + '</td></tr></tfoot>';
    return tb + fb + '<div class="tblwrap"><table class="wt"><thead>' + head + '</thead><tbody>' + body + '</tbody>' + foot + '</table></div>';
  }
  W.redrawTable = function (id) {
    var el = document.querySelector('.coll[data-tbl="' + id + '"]');
    if (el) el.innerHTML = tableInner(id);
  };
  W.selected = function (id) {
    var t = W._tbl[id]; if (!t) return [];
    return Object.keys(t.sel).filter(function (k) { return t.sel[k]; });
  };
  W.clearSel = function (id) { if (W._tbl[id]) W._tbl[id].sel = {}; };
  W.kvTable = function (rows, cls) {
    return '<div class="tblwrap"><table class="wt kv ' + (cls || '') + '">' + rows.map(function (r) { return '<tr><td><span class="inline-flex">' + esc(r[0]) + (r[2] ? W.hi(r[2]) : '') + '</span></td><td>' + r[1] + '</td></tr>'; }).join('') + '</table></div>';
  };
  W.simpleTable = function (cols, rows) {
    return '<div class="tblwrap"><table class="wt"><thead><tr>' + cols.map(function (c) { return '<th>' + (Array.isArray(c) ? '<span class="inline-flex">' + esc(c[0]) + W.hi(c[1]) + '</span>' : esc(c)) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      rows.map(function (r) { return '<tr class="r">' + r.map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>';
  };

  /* --------------------------------------------------------------- wizard */
  W.wizards = {};
  W._wz = {};
  W.wizard = function (id, def) { W.wizards[id] = def; };
  function wizardPage(id, query) {
    var def = W.wizards[id];
    if (!def) return null;
    var st = W._wz[id];
    if (!st || st.fresh) { st = W._wz[id] = { i: 0, v: def.init ? def.init(query || {}) : {}, q: query || {} }; }
    var steps = def.steps(st.v);
    if (st.i >= steps.length) st.i = steps.length - 1;
    var cur = steps[st.i];
    var stepsHtml = '<div class="wz-steps">' + steps.map(function (s, i) {
      return '<div class="' + (i === st.i ? 'on' : (i < st.i ? 'done' : '')) + '"><span>' + (i < st.i ? '✓' : '→') + '</span><span>Step ' + (i + 1) + ': ' + esc(s.t) + '</span></div>';
    }).join('') + '</div>';
    var last = st.i === steps.length - 1;
    var body = '<div class="wz-body"><h3>' + esc(cur.t) + (cur.h ? W.hi(cur.h) : '') + '</h3>' + (cur.desc ? '<p class="desc">' + cur.desc + '</p>' : '') +
      '<form class="wz" onsubmit="return false" data-wz="' + esc(id) + '">' + cur.html(st.v) + '</form>' +
      '<div class="btnrow">' + (st.i > 0 ? '<button type="button" class="btn" data-act="wzPrev" data-wz="' + esc(id) + '">Previous</button>' : '') +
      (last ? '<button type="button" class="btn primary" data-act="wzFinish" data-wz="' + esc(id) + '">Finish</button>' : '<button type="button" class="btn primary" data-act="wzNext" data-wz="' + esc(id) + '">Next</button>') +
      '<button type="button" class="btn" data-act="wzCancel" data-wz="' + esc(id) + '">Cancel</button></div></div>';
    return {
      title: def.title, help: def.help,
      html: W.crumbs(def.crumbs || [def.title]) + (def.intro ? '<p class="desc">' + def.intro + '</p>' : '') + '<div class="wizard">' + stepsHtml + body + '</div>'
    };
  }
  function wzCollect(id) {
    var form = document.querySelector('form.wz[data-wz="' + id + '"]');
    var st = W._wz[id];
    var r = form ? W.readForm(form) : { vals: {}, errs: [] };
    Object.keys(r.vals).forEach(function (k) { st.v[k] = r.vals[k]; });
    var def = W.wizards[id], steps = def.steps(st.v), cur = steps[st.i];
    if (cur.validate) { var e = cur.validate(st.v); if (e) r.errs = r.errs.concat(e); }
    return r.errs;
  }

  /* ---------------------------------------------------------------- router */
  W.routes = [];
  W.route = function (pattern, fn) {
    var keys = [];
    var re = new RegExp('^' + pattern.replace(/:(\w+)/g, function (m, k) { keys.push(k); return '([^/]+)'; }) + '$');
    W.routes.push({ re: re, keys: keys, fn: fn, pattern: pattern });
  };
  W.parseHash = function () {
    var h = location.hash.replace(/^#/, '') || '/welcome';
    var qi = h.indexOf('?'), q = {};
    if (qi >= 0) { h.slice(qi + 1).split('&').forEach(function (p) { var kv = p.split('='); if (kv[0]) q[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || ''); }); h = h.slice(0, qi); }
    return { path: h, q: q };
  };
  W.onLeave = [];
  W.render = function () {
    W.onLeave.forEach(function (f) { try { f(); } catch (e) { } }); W.onLeave = [];
    var ph = W.parseHash(), page = null;
    var content = document.getElementById('content');
    if (W._lastPath !== ph.path) {
      // yeni sayfaya geçiş: sihirbaz durumu sıfırlansın
      var m = ph.path.match(/^\/wz\/([^/]+)/);
      if (m && W._wz[m[1]]) W._wz[m[1]].fresh = true;
    }
    W._lastPath = ph.path;
    var wm = ph.path.match(/^\/wz\/([^/]+)$/);
    if (wm) page = wizardPage(decodeURIComponent(wm[1]), ph.q);
    if (W._wz[wm && wm[1]]) W._wz[wm[1]].fresh = false;
    if (!page) {
      for (var i = 0; i < W.routes.length; i++) {
        var r = W.routes[i], mm = ph.path.match(r.re);
        if (mm) {
          var params = {}; r.keys.forEach(function (k, j) { params[k] = decodeURIComponent(mm[j + 1]); });
          try { page = r.fn(params, ph.q); } catch (e) { console.error(e); page = { title: 'Hata', html: '<div class="msgbox err">Sayfa oluşturulurken hata: ' + esc(e.message) + '</div>' }; }
          break;
        }
      }
    }
    if (!page) page = { title: 'Sayfa bulunamadı', html: '<p>İstenen sayfa (<code>' + esc(ph.path) + '</code>) bulunamadı.</p><p><a href="#/welcome">Welcome sayfasına dön</a></p>' };
    W.page = page;
    var html = page.raw ? page.html.replace('<!--MSGS-->', msgsHtml(page.noPending)) : W.portlet(page.title, (page.crumbsHtml || '') + msgsHtml(page.noPending) + page.html, { help: page.help });
    content.innerHTML = html;
    if (page.onMount) { try { page.onMount(content); } catch (e) { console.error(e); } }
    document.getElementById('pageHelpLink').style.display = page.help ? '' : 'none';
    W.highlightNav(ph.path);
    if (W.UI.lastHelp && !W._helpInit) { W._helpInit = true; }
    document.title = (page.title ? page.title + ' – ' : '') + 'WebSphere Integrated Solutions Console';
    if (!W._noScroll) document.getElementById('main').scrollTop = 0;
    W._noScroll = false;
    document.body.classList.remove('nav-open');
  };
  W.rerender = function () { W._noScroll = true; W.render(); };

  /* ------------------------------------------------------------------ nav */
  W.renderNav = function () {
    var nav = document.getElementById('navTree');
    var view = W.UI.view || 'all';
    var html = '<div class="nav-leaf"><a href="#/welcome">Welcome</a></div>';
    W.NAV.forEach(function (g, gi) {
      if (view !== 'all' && g.view !== view && !(view === 'learn' && g.learning)) return;
      html += navGroup(g, 'g' + gi, true);
    });
    nav.innerHTML = html;
    W.highlightNav((W.parseHash()).path);
  };
  function navGroup(g, path, top) {
    var open = W.UI.open[path] != null ? W.UI.open[path] : !!g.open;
    var kids = g.items.map(function (it, i) {
      if (it.items) return navGroup(it, path + '.' + i, false);
      return '<div class="nav-leaf" data-href="' + esc(it.h) + '"><a href="' + esc(it.h) + '">' + esc(it.t) + '</a></div>';
    }).join('');
    return '<div class="' + (top ? 'nav-top' : 'nav-sub') + (g.learning ? ' learning' : '') + '" data-np="' + path + '"><div class="nav-head" data-act="navToggle" data-np="' + path + '"><span class="tg' + (open ? '' : ' plus') + '"></span><span>' + esc(g.g) + '</span></div><div class="nav-body' + (open ? '' : ' nav-hidden') + '">' + kids + '</div></div>';
  }
  W.highlightNav = function (path) {
    document.querySelectorAll('.nav-leaf.current').forEach(function (e) { e.classList.remove('current'); });
    var best = null, bestLen = 0;
    document.querySelectorAll('#navTree .nav-leaf[data-href]').forEach(function (e) {
      var h = e.getAttribute('data-href').replace(/^#/, '');
      if ((path === h || path.indexOf(h + '/') === 0) && h.length > bestLen) { best = e; bestLen = h.length; }
    });
    if (best) best.classList.add('current');
  };
  function navSearch(q) {
    var box = document.getElementById('navResults'), tree = document.getElementById('navTree');
    q = q.trim().toLowerCase();
    if (!q) { box.innerHTML = ''; box.style.display = 'none'; tree.style.display = ''; return; }
    var hits = [];
    (function walk(items, trail) {
      items.forEach(function (it) {
        if (it.items) walk(it.items, trail.concat(it.g));
        else if (it.t.toLowerCase().indexOf(q) >= 0 || trail.join(' ').toLowerCase().indexOf(q) >= 0) hits.push('<div class="nav-leaf"><a href="' + esc(it.h) + '">' + esc(it.t) + '</a><span class="nr-path">' + esc(trail.join(' › ')) + '</span></div>');
      });
    })(W.NAV, []);
    var hh = [];
    Object.keys(W.HELP).forEach(function (k) {
      var h = W.HELP[k], txt = (h.t + ' ' + (h.what || '')).replace(/<[^>]+>/g, '').toLowerCase();
      if (txt.indexOf(q) >= 0) hh.push([h.t.replace(/<[^>]+>/g, '').toLowerCase().indexOf(q) >= 0 ? 0 : 1, '<div class="nav-leaf"><a data-help-link="' + esc(k) + '">' + h.t + '</a></div>']);
    });
    hh.sort(function (a, b) { return a[0] - b[0]; });
    box.innerHTML = '<div class="nav-results"><div class="nr-title">Menü sonuçları (' + hits.length + ')</div>' + (hits.join('') || '<div class="empty">Eşleşme yok</div>') +
      '<div class="nr-title">Açıklama / kavram sonuçları (' + hh.length + ')</div>' + (hh.slice(0, 40).map(function (x) { return x[1]; }).join('') || '<div class="empty">Eşleşme yok</div>') + '</div>';
    box.style.display = ''; tree.style.display = 'none';
  }

  /* -------------------------------------------------------------- actions */
  W.act = W.act || {};
  var A = W.act;
  A.nav = function (el) { if (el.dataset.href) location.hash = el.dataset.href; };
  A.goBack = function (el) { if (el.dataset.href) location.hash = el.dataset.href; else history.back(); };
  A.navToggle = function (el) {
    var p = el.dataset.np, box = el.parentNode, body = box.querySelector(':scope > .nav-body'), tg = el.querySelector('.tg');
    var open = body.classList.contains('nav-hidden');
    body.classList.toggle('nav-hidden', !open); tg.classList.toggle('plus', !open);
    W.UI.open[p] = open; W.saveUI();
  };
  A.minPortlet = function (el) { var pb = el.closest('.portlet').querySelector('.pb'); pb.style.display = pb.style.display === 'none' ? '' : 'none'; };
  A.helpModal = function (el) { W.helpModal(el.dataset.key); };
  A.tblAll = function (el) { var t = W._tbl[el.dataset.tbl]; var cfg = t.cfg, key = cfg.key || function (r) { return r.id || r.name; }; cfg.rows.forEach(function (r) { t.sel[key(r)] = true; }); W.redrawTable(el.dataset.tbl); };
  A.tblNone = function (el) { W._tbl[el.dataset.tbl].sel = {}; W.redrawTable(el.dataset.tbl); };
  A.tblFilter = function (el) { var t = W._tbl[el.dataset.tbl]; t.showFilter = !t.showFilter; W.redrawTable(el.dataset.tbl); var i = document.querySelector('.coll[data-tbl="' + el.dataset.tbl + '"] [data-ftext]'); if (i) i.focus(); };
  A.tblClear = function (el) { var t = W._tbl[el.dataset.tbl]; t.filter = null; t.showFilter = false; W.redrawTable(el.dataset.tbl); };
  A.tblGo = function (el) {
    var c = el.closest('.coll'), t = W._tbl[el.dataset.tbl];
    t.filter = { col: c.querySelector('[data-fcol]').value, text: c.querySelector('[data-ftext]').value };
    W.redrawTable(el.dataset.tbl);
  };
  A.cfgApply = function (el) { cfgApply(el.closest('form'), false); };
  A.cfgOk = function (el) { cfgApply(el.closest('form'), true); };
  A.cfgReset = function () { W.rerender(); };
  A.cfgCancel = function (el) { var f = el.closest('form'); if (f.dataset.back) location.hash = f.dataset.back; else history.back(); };
  A.saveDirect = function () {
    var n = W.saveMaster();
    W.msg('info', ['Master repository güncellendi: ' + n + ' değişiklik kaydedildi.', 'ADMS0208I: The configuration synchronization complete for cell. (Node\'lar File Synchronization Service ile güncellendi.)']);
    W.cmd('Değişiklikleri master repository\'ye kaydet', ['AdminConfig.save()', "AdminControl.invoke(AdminControl.completeObjectName('type=NodeSync,node=AppNode01,*'), 'sync')"]);
    W.rerender();
  };
  A.wzNext = function (el) {
    var id = el.dataset.wz, errs = wzCollect(id);
    if (errs.length) { W.msg('error', errs); W.rerender(); return; }
    W._wz[id].i++; W.rerender();
  };
  A.wzPrev = function (el) { var id = el.dataset.wz; wzCollect(id); W._wz[id].i--; W.flash = []; W.rerender(); };
  A.wzCancel = function (el) { var def = W.wizards[el.dataset.wz]; delete W._wz[el.dataset.wz]; location.hash = def.back || '#/welcome'; };
  A.wzFinish = function (el) {
    var id = el.dataset.wz, errs = wzCollect(id);
    if (errs.length) { W.msg('error', errs); W.rerender(); return; }
    var def = W.wizards[id], res = def.finish(W._wz[id].v) || {};
    if (res.error) { W.msg('error', res.error); W.rerender(); return; }
    delete W._wz[id];
    if (res.msgs) W.msg(res.type || 'info', res.msgs);
    W.go(res.go || def.back || '#/welcome');
  };
  W.go = function (h) {
    if (!h) { W.rerender(); return; }
    if (location.hash === h || ('#' + W.parseHash().path) === h && location.hash.indexOf('?') < 0) W.render();
    else location.hash = h;
  };
  A.cmdAssist = function () {
    var html = W.cmdLog.length ? W.cmdLog.map(function (c) {
      return '<div style="margin-bottom:12px"><div><b>' + esc(c.title) + '</b> <span style="color:#777">(' + c.time + ')</span></div><pre class="code light">' + esc(c.lines.join('\n')) + '</pre></div>';
    }).join('') : '<p>Henüz bir yönetim işlemi yapılmadı. Bir sunucuyu başlatın, bir ayarı değiştirin veya bir kaynak oluşturun; eşdeğer <b>wsadmin (Jython)</b> komutu burada gösterilir.</p>';
    W.modal({ title: 'Command Assistance – Administrative scripting commands', wide: true, html: '<p class="note-tr">Konsolda yaptığınız her işlemin <code>wsadmin -lang jython</code> ile otomatikleştirilebilir karşılığı aşağıdadır. Gerçek ortamda bu komutlar <code>wsadmin.sh -lang jython -conntype SOAP -host was-dmgr01.corp.local -port 8879</code> ile Deployment Manager\'a bağlanarak çalıştırılır. Bu simülasyon hiçbir komutu çalıştırmaz.' + W.hi('concept.wsadmin') + '</p>' + html });
  };

  /* --------------------------------------------------------------- events */
  function bind() {
    document.addEventListener('click', function (ev) {
      var h = ev.target.closest('[data-help]');
      if (h) { ev.preventDefault(); W.showHelp(h.dataset.help); return; }
      var hl = ev.target.closest('[data-help-link]');
      if (hl) { ev.preventDefault(); var mo = document.getElementById('modal').classList.contains('open'); if (mo) document.querySelector('#modal .mb').innerHTML = W.helpHtml(hl.dataset.helpLink, true); else W.showHelp(hl.dataset.helpLink); return; }
      var mb = ev.target.closest('[data-mbtn]');
      if (mb) { var m = document.getElementById('modal'), b = m._btns[+mb.dataset.mbtn]; if (b && b.fn) { if (b.fn() === false) return; } W.closeModal(); return; }
      if (ev.target.closest('[data-mclose]') || ev.target.id === 'modal') { W.closeModal(); return; }
      var th = ev.target.closest('th[data-sort]');
      if (th && th.classList.contains('sortable')) {
        var t = W._tbl[th.dataset.tbl]; if (t.sortK === th.dataset.sort) t.dir = -t.dir; else { t.sortK = th.dataset.sort; t.dir = 1; }
        W.redrawTable(th.dataset.tbl); return;
      }
      var a = ev.target.closest('[data-act]');
      if (a) {
        var fn = A[a.dataset.act];
        if (fn) {
          ev.preventDefault();
          if (a.dataset.need && a.dataset.tbl && W.selected(a.dataset.tbl).length < +a.dataset.need) {
            W.msg('error', 'Bu işlem için tablodan en az bir öğe seçmelisiniz. (You must select at least one item.)'); W.rerender(); return;
          }
          fn(a, ev);
        } else console.warn('Tanımsız işlem: ' + a.dataset.act);
      }
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') W.closeModal();
      if ((ev.key === 'Enter' || ev.key === ' ') && ev.target.classList && ev.target.classList.contains('hi')) { ev.preventDefault(); W.showHelp(ev.target.dataset.help); }
      if (ev.key === 'Enter' && ev.target.matches && ev.target.matches('[data-ftext]')) { ev.preventDefault(); var c = ev.target.closest('.coll'); A.tblGo(c.querySelector('[data-act="tblGo"]')); }
    });
    document.addEventListener('change', function (ev) {
      var e = ev.target;
      if (e.dataset.rowsel) {
        W._tbl[e.dataset.tbl].sel[e.dataset.rowsel] = e.checked;
        e.closest('tr').classList.toggle('sel', e.checked); return;
      }
      if (e.dataset.change && W.onChange[e.dataset.change]) W.onChange[e.dataset.change](e, ev);
    });
    window.addEventListener('hashchange', W.render);
    document.getElementById('navSearch').addEventListener('input', function (e) { navSearch(e.target.value); });
    document.getElementById('navSearchClear').addEventListener('click', function () { var i = document.getElementById('navSearch'); i.value = ''; navSearch(''); });
    document.getElementById('viewSel').value = W.UI.view || 'all';
    document.getElementById('viewSel').addEventListener('change', function (e) { W.UI.view = e.target.value; W.saveUI(); W.renderNav(); });
    document.getElementById('navToggle').addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
    // splitter
    var sp = document.getElementById('splitter'), nav = document.getElementById('nav');
    if (W.UI.navW) nav.style.width = W.UI.navW + 'px';
    sp.addEventListener('mousedown', function (e) {
      e.preventDefault();
      function mv(ev) { var w = Math.max(230, Math.min(470, ev.clientX)); nav.style.width = w + 'px'; W.UI.navW = w; }
      function up() { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); W.saveUI(); }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  W.onChange = {
    scope: function (e) { W.UI.scope = W.UI.scope || {}; W.UI.scope[e.dataset.page] = e.value; W.saveUI(); W.rerender(); }
  };

  W.start = function () {
    W.init();
    document.getElementById('cellCtx').textContent = 'Cell=' + W.S.cell.name + ', Profile=' + W.S.cell.dmgrProfile;
    W.renderNav();
    bind();
    if (W.updateIdentity) W.updateIdentity();
    if (W.applyPrefs && W.S.consolePrefs) W.applyPrefs();
    W.render();
  };
})();
