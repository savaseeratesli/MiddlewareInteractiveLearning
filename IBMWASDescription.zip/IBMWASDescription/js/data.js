/* =====================================================================
   data.js – Örnek (simülasyon) IBM WAS ND 9.0.5 hücresi.
   Tüm veriler birbiriyle tutarlıdır: sunucu-cluster üyelikleri, uygulama
   hedefleri, port numaraları, virtual host alias'ları ve plugin-cfg.xml
   aynı kaynaktan üretilir. Gerçek bir sisteme ait DEĞİLDİR.
   ===================================================================== */
(function () {
  'use strict';
  var W = window.WAS = window.WAS || {};
  var CELL = 'WASPRODCell01';

  function ports(slot, nodeIdx) {
    var s = slot;
    return {
      BOOTSTRAP_ADDRESS: 9810 + s, SOAP_CONNECTOR_ADDRESS: 8880 + s, ORB_LISTENER_ADDRESS: 9101 + s,
      SAS_SSL_SERVERAUTH_LISTENER_ADDRESS: 9501 + s, CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS: 9521 + s, CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS: 9541 + s,
      WC_adminhost: 9061 + s, WC_defaulthost: 9080 + s, DCS_UNICAST_ADDRESS: 9353 + s, WC_adminhost_secure: 9044 + s, WC_defaulthost_secure: 9443 + s,
      SIP_DEFAULTHOST: 5060 + 2 * s, SIP_DEFAULTHOST_SECURE: 5061 + 2 * s, SIB_ENDPOINT_ADDRESS: 7276 + s, SIB_ENDPOINT_SECURE_ADDRESS: 7286 + s,
      SIB_MQ_ENDPOINT_ADDRESS: 5558 + s, SIB_MQ_ENDPOINT_SECURE_ADDRESS: 5578 + s, IPC_CONNECTOR_ADDRESS: 9633 + s, OVERLAY_UDP_LISTENER_ADDRESS: 11003 + 2 * s, OVERLAY_TCP_LISTENER_ADDRESS: 11004 + 2 * s
    };
  }
  function threadPools(kind) {
    var wc = kind === 'bank' ? [50, 150] : kind === 'portal' ? [40, 100] : [20, 50];
    return [
      { name: 'Default', minimumSize: 20, maximumSize: 20, inactivityTimeout: 5000, isGrowable: false, description: '' },
      { name: 'WebContainer', minimumSize: wc[0], maximumSize: wc[1], inactivityTimeout: 60000, isGrowable: false, description: '' },
      { name: 'ORB.thread.pool', minimumSize: 10, maximumSize: 50, inactivityTimeout: 3500, isGrowable: false, description: '' },
      { name: 'SIBFAPInboundThreadPool', minimumSize: 4, maximumSize: 50, inactivityTimeout: 5000, isGrowable: false, description: 'Service integration bus FAP inbound channel thread pool' },
      { name: 'SIBFAPThreadPool', minimumSize: 4, maximumSize: 50, inactivityTimeout: 5000, isGrowable: true, description: 'Service integration bus FAP outbound channel thread pool' },
      { name: 'TCPChannel.DCS', minimumSize: 5, maximumSize: 20, inactivityTimeout: 5000, isGrowable: false, description: '' },
      { name: 'HAManager.thread.pool', minimumSize: 2, maximumSize: 2, inactivityTimeout: 5000, isGrowable: true, description: '' },
      { name: 'WMQJCAResourceAdapter', minimumSize: 10, maximumSize: 50, inactivityTimeout: 3500, isGrowable: true, description: '' },
      { name: 'ProcessDiscovery', minimumSize: 1, maximumSize: 2, inactivityTimeout: 5000, isGrowable: false, description: '' }
    ];
  }
  function server(name, node, slot, cluster, kind, heap, opts) {
    opts = opts || {};
    var persist = kind === 'bank' ? 'DATA_REPLICATION' : kind === 'portal' ? 'DATABASE' : 'NONE';
    return {
      id: name, name: name, node: node, cluster: cluster || '', type: 'APPLICATION_SERVER', slot: slot, template: 'default', kind: kind,
      developmentMode: false, parallelStartEnabled: true, provisionComponents: false, accessInternalClasses: 'ALLOW',
      classloaderPolicy: 'MULTIPLE', applicationClassLoaderPolicy: 'PARENT_FIRST', shortName: '', uniqueId: '',
      jvm: {
        initialHeapSize: heap[0], maximumHeapSize: heap[1],
        genericJvmArguments: kind === 'bank' ? '-Xgcpolicy:gencon -Xmn768m -Dfile.encoding=UTF-8 -Duser.timezone=Europe/Istanbul -Xverbosegclog:${SERVER_LOG_ROOT}/verbosegc.%seq.log,5,20000' :
          kind === 'portal' ? '-Xgcpolicy:gencon -Dfile.encoding=UTF-8 -Duser.timezone=Europe/Istanbul' :
            kind === 'batch' ? '-Xgcpolicy:balanced -Dfile.encoding=UTF-8 -Dbatch.work.dir=${BATCH_WORK_DIR}' : '-Xgcpolicy:gencon -Dfile.encoding=UTF-8',
        verboseModeGarbageCollection: kind === 'bank' || kind === 'batch', verboseModeClass: false, verboseModeJNI: false,
        classpath: '', bootClasspath: '', debugMode: false, debugArgs: '-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=7777',
        runHProf: false, hprofArguments: '', disableJIT: false, executableJarFileName: '', osName: 'linux',
        systemProperties: kind === 'bank' ? [
          { name: 'com.ibm.websphere.threadmonitor.threshold', value: '300', description: 'Hung thread algılama eşiği (saniye)' },
          { name: 'com.ibm.websphere.threadmonitor.interval', value: '120', description: 'Thread monitor kontrol aralığı (saniye)' },
          { name: 'com.ibm.ws.webcontainer.extractHostHeaderPort', value: 'true', description: '' }
        ] : []
      },
      processDef: { executableName: '', executableArguments: '', workingDirectory: '${USER_INSTALL_ROOT}', executableTargetKind: 'JAVA_CLASS', executableTarget: 'com.ibm.wsspi.bootstrap.WSPreLauncher' },
      procExec: { processPriority: 20, umask: '022', runAsUser: 'wasadm', runAsGroup: 'wasgrp', runInProcessGroup: 0 },
      monitor: { maximumStartupAttempts: 3, pingInterval: 60, pingTimeout: 300, autoRestart: true, nodeRestartState: kind === 'batch' ? 'STOPPED' : 'PREVIOUS' },
      threadPools: threadPools(kind),
      tx: {
        transactionLogDirectory: '/shared/tranlog/' + CELL + '/' + node + '/' + name + '/transaction', totalTranLifetimeTimeout: kind === 'batch' ? 1800 : 120, asyncResponseTimeout: 30,
        clientInactivityTimeout: 60, propogatedOrBMTTranLifetimeTimeout: kind === 'batch' ? 3600 : 300, heuristicRetryLimit: 0, heuristicRetryWait: 0,
        LPSHeuristicCompletion: 'ROLLBACK', enableFileLocking: true, enableProtocolSecurity: true, acceptHeuristicHazard: false, enableLoggingForHeuristicReporting: false
      },
      session: {
        enableCookies: true, enableUrlRewriting: false, enableSSLTracking: false, enableProtocolSwitchRewriting: false,
        maxInMemorySessionCount: kind === 'bank' ? 3000 : 1000, allowOverflow: true, invalidationTimeout: kind === 'portal' ? 60 : 30,
        enableSecurityIntegration: kind === 'bank', allowSerializedSessionAccess: false, maxWaitTime: 5,
        sessionPersistenceMode: persist, replicationDomain: kind === 'bank' ? 'BankingCluster' : '', replicationMode: 'BOTH',
        datasourceJNDIName: kind === 'portal' ? 'jdbc/SessionDS' : '', tableName: 'SESSIONS', writeFrequency: 'END_OF_SERVLET_SERVICE', writeContents: 'ONLY_UPDATED_ATTRIBUTES',
        cookieName: 'JSESSIONID', cookieDomain: '', cookiePath: '/', cookieSecure: true, cookieHttpOnly: true, cookieMaxAge: -1
      },
      webContainer: { defaultVirtualHost: 'default_host', enableServletCaching: kind === 'portal', disablePooling: false, sessionAffinityTimeout: 0, enablePortBasedVirtualHostMatching: false },
      ejb: { passivationDirectory: '${USER_INSTALL_ROOT}/temp', inactivePoolCleanupInterval: 30000, cacheSize: 2053, cleanupInterval: 3000, defaultDatasourceJNDIName: '' },
      pluginProps: { role: 'PRIMARY', connectTimeout: 5, serverIOTimeout: 900, extendedHandshake: false, waitForContinue: false, maxConnections: -1 },
      ports: ports(slot),
      pmi: { enable: true, synchronizedUpdate: false, statisticSet: opts.pmi || 'basic' },
      logs: { systemOutFile: '${SERVER_LOG_ROOT}/SystemOut.log', systemErrFile: '${SERVER_LOG_ROOT}/SystemErr.log', rolloverType: 'BOTH', rolloverSize: 20, baseHour: 24, rolloverPeriod: 24, maxNumberOfBackupFiles: 10, showAppPrints: true, formatType: 'BASIC', logFormat: 'BASIC' },
      trace: { startupTraceSpecification: opts.trace || '*=info', traceOutputType: 'SPECIFIED_FILE', traceFileName: '${SERVER_LOG_ROOT}/trace.log', rolloverSize: 20, maxNumberOfBackupFiles: 5, traceFormat: 'BASIC', memoryBufferSize: 8 },
      customProps: kind === 'bank' ? [{ name: 'com.ibm.ws.webcontainer.invokeFlushAfterService', value: 'false', description: '' }] : [],
      created: '2025-03-12'
    };
  }

  W.Data = {
    newServer: server, ports: ports,
    VERSION: 7,
    create: function () {
      var S = {};
      S.cell = {
        name: CELL, dmgrProfile: 'Dmgr01', version: 'ND 9.0.5.14', product: 'IBM WebSphere Application Server Network Deployment', build: 'cf142224.02', buildDate: '2023-06-02',
        cellDiscoveryProtocol: 'TCP', installRoot: '/opt/IBM/WebSphere/AppServer', javaSdk: '1.8_64 (IBM SDK, Java Technology Edition, 8.0.8.10)',
        cellType: 'DISTRIBUTED', description: 'Ornek Bank üretim hücresi (EĞİTİM SİMÜLASYONU)',
        customProps: [
          { name: 'com.ibm.websphere.management.registerServerIORWithLSD', value: 'true', description: '' },
          { name: 'IBM_CLUSTER_ENABLE_ACK_ON_SEND', value: 'true', description: '' }
        ]
      };
      S.nodes = [
        { name: 'CellManager01', host: 'was-dmgr01.corp.local', type: 'dmgr', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: 'ND 9.0.5.14', profile: 'Dmgr01', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 4, ramGB: 16 },
        { name: 'AppNode01', host: 'was-app01.corp.local', type: 'managed', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: 'ND 9.0.5.14', profile: 'AppSrv01', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 8, ramGB: 32 },
        { name: 'AppNode02', host: 'was-app02.corp.local', type: 'managed', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: 'ND 9.0.5.14', profile: 'AppSrv01', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 8, ramGB: 32 },
        { name: 'AppNode03', host: 'was-app03.corp.local', type: 'managed', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: 'ND 9.0.5.14', profile: 'AppSrv01', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 8, ramGB: 32 },
        { name: 'ihsnode01', host: 'ihs-web01.corp.local', type: 'unmanaged', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: '', profile: '', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 4, ramGB: 8 },
        { name: 'ihsnode02', host: 'ihs-web02.corp.local', type: 'unmanaged', os: 'linux', osName: 'Red Hat Enterprise Linux 8.8', version: '', profile: '', nodeGroup: 'DefaultNodeGroup', discoveryProtocol: 'TCP', cpu: 4, ramGB: 8 }
      ];
      S.dmgr = {
        name: 'dmgr', node: 'CellManager01', jvm: { initialHeapSize: 512, maximumHeapSize: 2048, genericJvmArguments: '-Xgcpolicy:gencon -Dfile.encoding=UTF-8' },
        ports: { BOOTSTRAP_ADDRESS: 9809, SOAP_CONNECTOR_ADDRESS: 8879, ORB_LISTENER_ADDRESS: 9100, CELL_DISCOVERY_ADDRESS: 7277, DCS_UNICAST_ADDRESS: 9352, WC_adminhost: 9060, WC_adminhost_secure: 9043, DataPowerMgr_inbound_secure: 5555, IPC_CONNECTOR_ADDRESS: 9632, CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS: 9403, CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS: 9402, SAS_SSL_SERVERAUTH_LISTENER_ADDRESS: 9401 }
      };
      S.nodeAgents = ['AppNode01', 'AppNode02', 'AppNode03'].map(function (n, i) {
        return {
          node: n, name: 'nodeagent', sync: { synchInterval: 1, autoSynchEnabled: true, synchOnServerStartup: false, exclusions: '' },
          ports: { BOOTSTRAP_ADDRESS: 2809, SOAP_CONNECTOR_ADDRESS: 8878, ORB_LISTENER_ADDRESS: 9900, NODE_DISCOVERY_ADDRESS: 7272, NODE_IPV6_MULTICAST_DISCOVERY_ADDRESS: 5001, NODE_MULTICAST_DISCOVERY_ADDRESS: 5000, DCS_UNICAST_ADDRESS: 9354, IPC_CONNECTOR_ADDRESS: 9626 },
          jvm: { initialHeapSize: 256, maximumHeapSize: 512, genericJvmArguments: '' }
        };
      });
      S.servers = [
        server('BankSrv01', 'AppNode01', 0, 'BankingCluster', 'bank', [1024, 2048], { pmi: 'extended' }),
        server('PortalSrv01', 'AppNode01', 1, 'PortalCluster', 'portal', [512, 1536], { pmi: 'custom' }),
        server('BankSrv02', 'AppNode02', 0, 'BankingCluster', 'bank', [1024, 2048], { pmi: 'extended' }),
        server('PortalSrv02', 'AppNode02', 1, 'PortalCluster', 'portal', [512, 1536]),
        server('MsgSrv01', 'AppNode02', 2, 'MessagingCluster', 'msg', [512, 1024]),
        server('BankSrv03', 'AppNode03', 0, 'BankingCluster', 'bank', [1024, 2048], { pmi: 'extended' }),
        server('MsgSrv02', 'AppNode03', 1, 'MessagingCluster', 'msg', [512, 1024]),
        server('BatchSrv01', 'AppNode03', 2, '', 'batch', [1024, 4096], { trace: '*=info:com.ornekbank.batch.*=fine' })
      ];
      S.clusters = [
        { name: 'BankingCluster', preferLocal: true, enableHA: false, replicationDomain: 'BankingCluster', description: 'Core banking ve internet bankacılığı uygulamaları', members: [{ name: 'BankSrv01', node: 'AppNode01', weight: 2 }, { name: 'BankSrv02', node: 'AppNode02', weight: 2 }, { name: 'BankSrv03', node: 'AppNode03', weight: 2 }] },
        { name: 'PortalCluster', preferLocal: true, enableHA: false, replicationDomain: '', description: 'Müşteri portalı (session kalıcılığı: veritabanı)', members: [{ name: 'PortalSrv01', node: 'AppNode01', weight: 2 }, { name: 'PortalSrv02', node: 'AppNode02', weight: 2 }] },
        { name: 'MessagingCluster', preferLocal: true, enableHA: true, replicationDomain: '', description: 'BankingBus messaging engine ve MDB uygulamaları', members: [{ name: 'MsgSrv01', node: 'AppNode02', weight: 2 }, { name: 'MsgSrv02', node: 'AppNode03', weight: 2 }] }
      ];
      S.replicationDomains = [
        { name: 'BankingCluster', requestTimeout: 5, encryptionType: 'NONE', numberOfReplicas: 1, description: 'BankingCluster için memory-to-memory HTTP session replikasyonu' }
      ];
      S.webservers = ['1', '2'].map(function (n) {
        return {
          name: 'webserver' + n, node: 'ihsnode0' + n, host: 'ihs-web0' + n + '.corp.local', port: 80, sslPort: 443, type: 'IHS', version: 'IBM HTTP Server 9.0.5.14',
          installRoot: '/opt/IBM/HTTPServer', configFile: '${WEB_INSTALL_ROOT}/conf/httpd.conf', serviceName: '', pluginInstallRoot: '/opt/IBM/WebSphere/Plugins',
          adminPort: 8008, adminUser: 'ihsadmin', adminSSL: false, mapAll: true, accessLog: '${WEB_INSTALL_ROOT}/logs/access_log', errorLog: '${WEB_INSTALL_ROOT}/logs/error_log',
          plugin: {
            RefreshInterval: 60, configFileName: 'plugin-cfg.xml', autoGenerate: true, autoPropagate: true, keyring: 'plugin-key.kdb', stashfile: 'plugin-key.sth',
            remoteConfigFile: '/opt/IBM/WebSphere/Plugins/config/webserver' + n + '/plugin-cfg.xml', remoteKeyring: '/opt/IBM/WebSphere/Plugins/config/webserver' + n + '/plugin-key.kdb',
            logFile: '/opt/IBM/WebSphere/Plugins/logs/webserver' + n + '/http_plugin.log', LogLevel: 'Error', IgnoreDNSFailures: false,
            LoadBalance: 'Round Robin', RetryInterval: 60, PostSizeLimit: -1, PostBufferSize: 0, RemoveSpecialHeaders: true, CloneSeparatorChange: false,
            ESIEnable: true, ESIMaxCacheSize: 1024, ESIInvalidationMonitor: false, AcceptAllContent: true, ChunkedResponse: false, ResponseChunkSize: 64,
            AppServerPortPreference: 'HostHeader', VHostMatchingCompat: false, TrustedProxyEnable: false, FIPSEnable: false, ServerIOTimeoutRetry: -1
          },
          lastGenerated: '2026-11-20 14:32:10', lastPropagated: '2026-11-20 14:32:14'
        };
      });
      S.virtualHosts = [
        { name: 'default_host', aliases: [['*', 80], ['*', 443], ['*', 9080], ['*', 9081], ['*', 9082], ['*', 9083], ['*', 9443], ['*', 9444], ['*', 9445], ['*', 9446], ['*', 5060], ['*', 5061]], mimeCount: 116 },
        { name: 'admin_host', aliases: [['*', 9060], ['*', 9043], ['*', 9061], ['*', 9062], ['*', 9063], ['*', 9044], ['*', 9045], ['*', 9046]], mimeCount: 116 },
        { name: 'ib_host', aliases: [['ib.ornekbank.com.tr', 443], ['ib.ornekbank.com.tr', 80], ['*', 9080], ['*', 9443]], mimeCount: 116 },
        { name: 'proxy_host', aliases: [['*', 80], ['*', 443]], mimeCount: 116 }
      ];
      S.apps = [
        {
          name: 'CoreBankingApp', version: '3.4.1', ear: 'CoreBankingApp.ear', state: 'started', installed: '2026-10-02 22:14',
          targets: ['cluster:BankingCluster', 'webserver:ihsnode01:webserver1', 'webserver:ihsnode02:webserver2'],
          modules: [{ name: 'CoreBanking Web', uri: 'CoreBankingWeb.war', type: 'web', contextRoot: '/corebank', vhost: 'default_host' }, { name: 'CoreBanking EJB', uri: 'CoreBankingEJB.jar', type: 'ejb' }],
          classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 10, autoStart: true, backgroundApplication: false, sharedLibs: ['CommonUtilsLib'],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [{ role: 'BankAdmin', everyone: false, allAuth: false, users: '', groups: 'WASAdmins' }, { role: 'Teller', everyone: false, allAuth: false, users: '', groups: 'BankTellers' }, { role: 'AuthenticatedUser', everyone: false, allAuth: true, users: '', groups: '' }],
          envEntries: [{ module: 'CoreBankingWeb.war', name: 'config/maxTransferAmount', type: 'java.lang.Integer', value: '250000', description: 'Tek seferde izin verilen EFT limiti (TRY)' }, { module: 'CoreBankingWeb.war', name: 'config/eodCutoff', type: 'java.lang.String', value: '17:30', description: 'Gün sonu kesim saati' }],
          resourceRefs: [{ module: 'CoreBankingEJB.jar', ref: 'jdbc/CoreBankDS', type: 'javax.sql.DataSource', target: 'jdbc/CoreBankDS', auth: 'Container', alias: 'CellManager01/corebank_app' }, { module: 'CoreBankingEJB.jar', ref: 'jms/PaymentQCF', type: 'javax.jms.QueueConnectionFactory', target: 'jms/PaymentQCF', auth: 'Container', alias: '' }, { module: 'CoreBankingWeb.war', ref: 'jdbc/AuditDS', type: 'javax.sql.DataSource', target: 'jdbc/AuditDS', auth: 'Container', alias: 'CellManager01/audit_app' }]
        },
        {
          name: 'InternetBankingApp', version: '5.2.0', ear: 'InternetBankingApp.ear', state: 'started', installed: '2026-11-14 23:40',
          targets: ['cluster:BankingCluster', 'webserver:ihsnode01:webserver1', 'webserver:ihsnode02:webserver2'],
          modules: [{ name: 'Internet Banking Web', uri: 'InternetBankingWeb.war', type: 'web', contextRoot: '/ib', vhost: 'ib_host' }, { name: 'IB REST API', uri: 'IBRestApi.war', type: 'web', contextRoot: '/ib/api', vhost: 'ib_host' }],
          classloaderMode: 'PARENT_LAST', warPolicy: 'SINGLE', startingWeight: 20, autoStart: true, backgroundApplication: false, sharedLibs: ['JacksonLib', 'CommonUtilsLib'],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [{ role: 'Customer', everyone: false, allAuth: true, users: '', groups: '' }],
          envEntries: [{ module: 'IBRestApi.war', name: 'api/rateLimitPerMinute', type: 'java.lang.Integer', value: '120', description: 'Müşteri başına dakikalık API limiti' }],
          resourceRefs: [{ module: 'InternetBankingWeb.war', ref: 'jdbc/CoreBankDS', type: 'javax.sql.DataSource', target: 'jdbc/CoreBankDS', auth: 'Container', alias: 'CellManager01/corebank_app' }]
        },
        {
          name: 'PaymentGatewayApp', version: '1.9.0', ear: 'PaymentGatewayApp.ear', state: 'started', installed: '2026-09-18 21:05',
          targets: ['cluster:BankingCluster', 'webserver:ihsnode01:webserver1', 'webserver:ihsnode02:webserver2'],
          modules: [{ name: 'Payment Web', uri: 'PaymentWeb.war', type: 'web', contextRoot: '/payment', vhost: 'default_host' }, { name: 'Payment EJB', uri: 'PaymentEJB.jar', type: 'ejb' }],
          classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 15, autoStart: true, backgroundApplication: false, sharedLibs: ['CommonUtilsLib'],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [{ role: 'PaymentOperator', everyone: false, allAuth: false, users: '', groups: 'PaymentOps' }],
          envEntries: [], resourceRefs: [{ module: 'PaymentEJB.jar', ref: 'jdbc/PaymentDS', type: 'javax.sql.DataSource', target: 'jdbc/PaymentDS', auth: 'Container', alias: 'CellManager01/payment_app' }, { module: 'PaymentEJB.jar', ref: 'jms/PaymentQueue', type: 'javax.jms.Queue', target: 'jms/PaymentQueue', auth: 'Container', alias: '' }]
        },
        {
          name: 'CustomerPortalApp', version: '2.8.3', ear: 'CustomerPortalApp.ear', state: 'started', installed: '2026-11-02 23:55',
          targets: ['cluster:PortalCluster', 'webserver:ihsnode01:webserver1', 'webserver:ihsnode02:webserver2'],
          modules: [{ name: 'Customer Portal', uri: 'CustomerPortal.war', type: 'web', contextRoot: '/portal', vhost: 'default_host' }],
          classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 1, autoStart: true, backgroundApplication: false, sharedLibs: ['PortalThemeLib'],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [{ role: 'PortalUser', everyone: false, allAuth: true, users: '', groups: '' }],
          envEntries: [], resourceRefs: [{ module: 'CustomerPortal.war', ref: 'jdbc/PortalDS', type: 'javax.sql.DataSource', target: 'jdbc/PortalDS', auth: 'Container', alias: 'CellManager01/portal_db2' }]
        },
        {
          name: 'NotificationApp', version: '1.3.2', ear: 'NotificationApp.ear', state: 'started', installed: '2026-07-21 20:30',
          targets: ['cluster:MessagingCluster'],
          modules: [{ name: 'Notification MDB', uri: 'NotificationMDB.jar', type: 'ejb' }, { name: 'Notification Admin', uri: 'NotificationAdmin.war', type: 'web', contextRoot: '/notifyadmin', vhost: 'admin_host' }],
          classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 30, autoStart: true, backgroundApplication: false, sharedLibs: [],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [], envEntries: [{ module: 'NotificationMDB.jar', name: 'smsProviderUrl', type: 'java.lang.String', value: 'https://sms-gw.corp.local/api/v2', description: '' }],
          resourceRefs: [{ module: 'NotificationMDB.jar', ref: 'mail/BankMailSession', type: 'javax.mail.Session', target: 'mail/BankMailSession', auth: 'Container', alias: '' }]
        },
        {
          name: 'ReportBatchApp', version: '1.0.7', ear: 'ReportBatchApp.ear', state: 'started', installed: '2026-05-06 19:10',
          targets: ['server:AppNode03:BatchSrv01'],
          modules: [{ name: 'Report Batch Web', uri: 'ReportBatch.war', type: 'web', contextRoot: '/reports', vhost: 'default_host' }],
          classloaderMode: 'PARENT_FIRST', warPolicy: 'MULTIPLE', startingWeight: 1, autoStart: true, backgroundApplication: false, sharedLibs: ['CommonUtilsLib'],
          reloadEnabled: false, reloadInterval: 3, binariesDir: '${APP_INSTALL_ROOT}/' + CELL, distribute: true, useMetadataFromBinaries: false, createMBeansForResources: true, validate: 'warn',
          roles: [], envEntries: [], resourceRefs: [{ module: 'ReportBatch.war', ref: 'jdbc/ReportDS', type: 'javax.sql.DataSource', target: 'jdbc/ReportDS', auth: 'Container', alias: 'CellManager01/report_ro' }]
        }
      ];
      S.sharedLibs = [
        { id: 'CommonUtilsLib', name: 'CommonUtilsLib', scope: 'cell', classPath: '/opt/ornekbank/lib/common/commons-lang3-3.12.0.jar\n/opt/ornekbank/lib/common/ornekbank-utils-2.1.4.jar', nativePath: '', isolated: false, description: 'Tüm uygulamaların ortak yardımcı sınıfları' },
        { id: 'JacksonLib', name: 'JacksonLib', scope: 'cluster:BankingCluster', classPath: '/opt/ornekbank/lib/jackson/jackson-core-2.15.3.jar\n/opt/ornekbank/lib/jackson/jackson-databind-2.15.3.jar\n/opt/ornekbank/lib/jackson/jackson-annotations-2.15.3.jar', nativePath: '', isolated: true, description: 'REST API için Jackson JSON kütüphanesi (izole class loader)' },
        { id: 'PortalThemeLib', name: 'PortalThemeLib', scope: 'cluster:PortalCluster', classPath: '${PORTAL_LIB_DIR}/portal-theme-4.0.jar', nativePath: '', isolated: false, description: 'Portal tema bileşenleri' }
      ];
      S.variables = [
        { id: 'v1', name: 'WAS_CELL_NAME', value: CELL, scope: 'cell', description: 'Hücre adı' },
        { id: 'v2', name: 'APP_ENV', value: 'PROD', scope: 'cell', description: 'Uygulamaların okuduğu ortam bilgisi' },
        { id: 'v3', name: 'ORNEKBANK_CONFIG_ROOT', value: '/opt/ornekbank/config', scope: 'cell', description: '' },
        { id: 'v4', name: 'BANK_CONFIG_DIR', value: '${ORNEKBANK_CONFIG_ROOT}/banking', scope: 'cluster:BankingCluster', description: 'BankingCluster üyelerine özgü yapılandırma dizini' },
        { id: 'v5', name: 'PORTAL_LIB_DIR', value: '/opt/ornekbank/lib/portal', scope: 'cluster:PortalCluster', description: '' },
        { id: 'v6', name: 'BATCH_WORK_DIR', value: '/data/batch/work', scope: 'server:AppNode03:BatchSrv01', description: 'Batch sunucusu çalışma dizini' }
      ];
      var vid = 7;
      ['CellManager01', 'AppNode01', 'AppNode02', 'AppNode03'].forEach(function (n) {
        var prof = n === 'CellManager01' ? 'Dmgr01' : 'AppSrv01';
        [['WAS_INSTALL_ROOT', '/opt/IBM/WebSphere/AppServer'], ['USER_INSTALL_ROOT', '/opt/IBM/WebSphere/AppServer/profiles/' + prof], ['LOG_ROOT', '${USER_INSTALL_ROOT}/logs'],
         ['APP_INSTALL_ROOT', '${USER_INSTALL_ROOT}/installedApps'], ['JAVA_HOME', '${WAS_INSTALL_ROOT}/java/8.0'], ['WAS_NODE_NAME', n], ['DERBY_JDBC_DRIVER_PATH', '${WAS_INSTALL_ROOT}/derby/lib'], ['CONNECTOR_INSTALL_ROOT', '${USER_INSTALL_ROOT}/installedConnectors']].forEach(function (v) {
          S.variables.push({ id: 'v' + (vid++), name: v[0], value: v[1], scope: 'node:' + n, description: '' });
        });
        if (n !== 'CellManager01') {
          S.variables.push({ id: 'v' + (vid++), name: 'ORACLE_JDBC_DRIVER_PATH', value: '/opt/IBM/drivers/oracle', scope: 'node:' + n, description: 'ojdbc8.jar konumu' });
          S.variables.push({ id: 'v' + (vid++), name: 'DB2_JCC_DRIVER_PATH', value: '/opt/IBM/drivers/db2', scope: 'node:' + n, description: 'db2jcc4.jar konumu' });
        }
      });
      S.variables.push({ id: 'v' + (vid++), name: 'MICROSOFT_JDBC_DRIVER_PATH', value: '/opt/IBM/drivers/mssql', scope: 'node:AppNode03', description: '' });
      S.servers.forEach(function (s) {
        S.variables.push({ id: 'v' + (vid++), name: 'SERVER_LOG_ROOT', value: '${LOG_ROOT}/' + s.name, scope: 'server:' + s.node + ':' + s.name, description: '' });
        S.variables.push({ id: 'v' + (vid++), name: 'WAS_SERVER_NAME', value: s.name, scope: 'server:' + s.node + ':' + s.name, description: '' });
      });
      S.authAliases = [
        { id: 'CellManager01/corebank_app', user: 'COREBANK_APP', description: 'CoreBank Oracle şeması uygulama kullanıcısı' },
        { id: 'CellManager01/payment_app', user: 'PAYMENT_APP', description: 'Ödeme şeması' },
        { id: 'CellManager01/audit_app', user: 'AUDIT_WRITER', description: 'Denetim kayıtları' },
        { id: 'CellManager01/portal_db2', user: 'db2portal', description: 'Portal DB2 kullanıcısı' },
        { id: 'CellManager01/report_ro', user: 'rpt_readonly', description: 'Rapor (salt okunur)' },
        { id: 'CellManager01/sib_auth', user: 'sibadmin', description: 'SIBus inter-engine ve veri deposu' },
        { id: 'CellManager01/mq_auth', user: 'mqwas', description: 'IBM MQ kuyruk yöneticisi bağlantısı' }
      ];
      S.jdbcProviders = [
        { id: 'p1', name: 'Oracle JDBC Driver', scope: 'cell', dbType: 'Oracle', providerType: 'Oracle JDBC Driver', impl: 'Connection pool data source', implClass: 'oracle.jdbc.pool.OracleConnectionPoolDataSource', classpath: '${ORACLE_JDBC_DRIVER_PATH}/ojdbc8.jar', nativePath: '', description: 'Oracle JDBC Driver' },
        { id: 'p2', name: 'Oracle JDBC Driver (XA)', scope: 'cell', dbType: 'Oracle', providerType: 'Oracle JDBC Driver', impl: 'XA data source', implClass: 'oracle.jdbc.xa.client.OracleXADataSource', classpath: '${ORACLE_JDBC_DRIVER_PATH}/ojdbc8.jar', nativePath: '', description: 'Oracle JDBC Driver (XA) – 2PC işlemleri için' },
        { id: 'p3', name: 'DB2 Using IBM JCC Driver', scope: 'cluster:PortalCluster', dbType: 'DB2', providerType: 'DB2 Using IBM JCC Driver', impl: 'Connection pool data source', implClass: 'com.ibm.db2.jcc.DB2ConnectionPoolDataSource', classpath: '${DB2_JCC_DRIVER_PATH}/db2jcc4.jar\n${DB2_JCC_DRIVER_PATH}/db2jcc_license_cu.jar', nativePath: '', description: 'DB2 JCC provider' },
        { id: 'p4', name: 'Microsoft SQL Server JDBC Driver', scope: 'server:AppNode03:BatchSrv01', dbType: 'SQL Server', providerType: 'Microsoft SQL Server JDBC Driver', impl: 'Connection pool data source', implClass: 'com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource', classpath: '${MICROSOFT_JDBC_DRIVER_PATH}/mssql-jdbc-8.4.1.jre8.jar', nativePath: '', description: '' },
        { id: 'p5', name: 'Derby JDBC Provider', scope: 'server:AppNode01:BankSrv01', dbType: 'Derby', providerType: 'Derby JDBC Provider', impl: 'Connection pool data source', implClass: 'org.apache.derby.jdbc.EmbeddedConnectionPoolDataSource', classpath: '${DERBY_JDBC_DRIVER_PATH}/derby.jar', nativePath: '', description: 'Varsayılan EJB Timer için gömülü Derby' },
        { id: 'p6', name: 'Oracle JDBC Driver', scope: 'cluster:MessagingCluster', dbType: 'Oracle', providerType: 'Oracle JDBC Driver', impl: 'Connection pool data source', implClass: 'oracle.jdbc.pool.OracleConnectionPoolDataSource', classpath: '${ORACLE_JDBC_DRIVER_PATH}/ojdbc8.jar', nativePath: '', description: 'SIBus mesaj deposu için' }
      ];
      function ds(id, name, jndi, scope, prov, helper, props, alias, pool, extra) {
        var o = {
          id: id, name: name, jndi: jndi, scope: scope, provider: prov, helper: helper, props: props, authAlias: alias, mappingAlias: 'DefaultPrincipalMapping', xaRecoveryAlias: '',
          cmp: false, description: '', statementCacheSize: 10, nonTransactional: false, validateNewConnection: false, validationQuery: '',
          pool: Object.assign({ connectionTimeout: 180, maxConnections: 10, minConnections: 1, reapTime: 180, unusedTimeout: 1800, agedTimeout: 0, purgePolicy: 'EntirePool', surgeThreshold: -1, stuckTimerTime: 0 }, pool || {})
        };
        return Object.assign(o, extra || {});
      }
      var ORA = 'com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper';
      S.dataSources = [
        ds('d1', 'CoreBankDS', 'jdbc/CoreBankDS', 'cell', 'p2', ORA, { URL: 'jdbc:oracle:thin:@//orabank-scan.corp.local:1521/COREBANK' }, 'CellManager01/corebank_app', { maxConnections: 60, minConnections: 10, agedTimeout: 7200 }, { statementCacheSize: 60, description: 'Ana bankacılık veritabanı (XA)' }),
        ds('d2', 'PaymentDS', 'jdbc/PaymentDS', 'cell', 'p2', ORA, { URL: 'jdbc:oracle:thin:@//orapay-scan.corp.local:1521/PAYMENT' }, 'CellManager01/payment_app', { maxConnections: 30, minConnections: 5 }, { statementCacheSize: 40 }),
        ds('d3', 'AuditDS', 'jdbc/AuditDS', 'cell', 'p1', ORA, { URL: 'jdbc:oracle:thin:@//oraaudit.corp.local:1521/AUDIT' }, 'CellManager01/audit_app', { maxConnections: 20, purgePolicy: 'FailingConnectionOnly' }, { statementCacheSize: 20 }),
        ds('d4', 'PortalDS', 'jdbc/PortalDS', 'cluster:PortalCluster', 'p3', 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper', { databaseName: 'PORTALDB', driverType: 4, serverName: 'db2-portal.corp.local', portNumber: 50000 }, 'CellManager01/portal_db2', { maxConnections: 40, minConnections: 5 }, { statementCacheSize: 30 }),
        ds('d5', 'SessionDS', 'jdbc/SessionDS', 'cluster:PortalCluster', 'p3', 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper', { databaseName: 'SESSDB', driverType: 4, serverName: 'db2-portal.corp.local', portNumber: 50000 }, 'CellManager01/portal_db2', { maxConnections: 30, minConnections: 2 }, { nonTransactional: true, description: 'HTTP session kalıcılığı (non-transactional olmalı)' }),
        ds('d6', 'ReportDS', 'jdbc/ReportDS', 'server:AppNode03:BatchSrv01', 'p4', 'com.ibm.websphere.rsadapter.MicrosoftSQLServerDataStoreHelper', { databaseName: 'REPORTING', serverName: 'sqlrpt01.corp.local', portNumber: 1433 }, 'CellManager01/report_ro', { maxConnections: 15 }, { testFail: true }),
        ds('d7', 'DefaultEJBTimerDataSource', 'jdbc/DefaultEJBTimerDataSource', 'server:AppNode01:BankSrv01', 'p5', 'com.ibm.websphere.rsadapter.DerbyDataStoreHelper', { databaseName: '${USER_INSTALL_ROOT}/databases/EJBTimers/${SERVER}/EJBTimerDB' }, '', { maxConnections: 10 }, { description: 'Default data source for WebSphere EJB Timer Service' }),
        ds('d8', 'SIBDS', 'jdbc/SIBDS', 'cluster:MessagingCluster', 'p6', ORA, { URL: 'jdbc:oracle:thin:@//oramsg.corp.local:1521/SIBSTORE' }, 'CellManager01/sib_auth', { maxConnections: 20, minConnections: 2 }, {})
      ];
      S.sib = {
        buses: [{
          name: 'BankingBus', uuid: '6F1A0C9B4E7D2A31', secure: true, interEngineAuthAlias: 'CellManager01/sib_auth', mediationsAuthAlias: '', protocol: 'InboundBasicMessaging', highMessageThreshold: 50000, discardMsgsAfterQueueDeletion: false,
          members: ['cluster:MessagingCluster'],
          engines: [{ name: 'MessagingCluster.000-BankingBus', member: 'cluster:MessagingCluster', store: 'Data store', ds: 'jdbc/SIBDS', schema: 'IBMWSSIB', alias: 'CellManager01/sib_auth', activeOn: 'MsgSrv01', highMessageThreshold: 50000 }],
          destinations: [
            { name: 'PaymentQueue', type: 'Queue', member: 'MessagingCluster', reliability: 'ASSURED_PERSISTENT', maxFailedDeliveries: 5, exception: '_SYSTEM.Exception.Destination.MessagingCluster.000-BankingBus', depth: 12 },
            { name: 'NotificationQueue', type: 'Queue', member: 'MessagingCluster', reliability: 'RELIABLE_PERSISTENT', maxFailedDeliveries: 5, exception: '_SYSTEM.Exception.Destination.MessagingCluster.000-BankingBus', depth: 248 },
            { name: 'AuditQueue', type: 'Queue', member: 'MessagingCluster', reliability: 'ASSURED_PERSISTENT', maxFailedDeliveries: 3, exception: '_SYSTEM.Exception.Destination.MessagingCluster.000-BankingBus', depth: 0 },
            { name: 'Default.Topic.Space', type: 'TopicSpace', member: '', reliability: 'RELIABLE_NONPERSISTENT', maxFailedDeliveries: 5, exception: '', depth: 0 },
            { name: '_SYSTEM.Exception.Destination.MessagingCluster.000-BankingBus', type: 'Queue', member: 'MessagingCluster', reliability: 'ASSURED_PERSISTENT', maxFailedDeliveries: 5, exception: '', depth: 3 }
          ]
        }]
      };
      S.jms = {
        cfs: [
          { id: 'c1', name: 'BankingCF', jndi: 'jms/BankingCF', scope: 'cell', provider: 'default', kind: 'CF', bus: 'BankingBus', targetType: 'BusMember', target: '', connectionProximity: 'Bus', maxConnections: 20, description: 'Birleşik (unified) JMS 1.1 connection factory' },
          { id: 'c2', name: 'PaymentQCF', jndi: 'jms/PaymentQCF', scope: 'cell', provider: 'default', kind: 'QCF', bus: 'BankingBus', targetType: 'BusMember', target: '', connectionProximity: 'Bus', maxConnections: 30, description: '' },
          { id: 'c3', name: 'RateTCF', jndi: 'jms/RateTCF', scope: 'cell', provider: 'default', kind: 'TCF', bus: 'BankingBus', targetType: 'BusMember', target: '', connectionProximity: 'Bus', maxConnections: 10, description: 'Döviz kuru yayınları' },
          { id: 'c4', name: 'LegacyMQQCF', jndi: 'jms/LegacyMQQCF', scope: 'cell', provider: 'mq', kind: 'QCF', qmgr: 'QM_BANK01', host: 'mq01.corp.local', port: 1414, channel: 'WAS.SVRCONN', transport: 'CLIENT', alias: 'CellManager01/mq_auth', maxConnections: 20, description: 'Ana sistem (mainframe) entegrasyonu için IBM MQ' }
        ],
        queues: [
          { id: 'q1', name: 'PaymentQueue', jndi: 'jms/PaymentQueue', scope: 'cell', provider: 'default', bus: 'BankingBus', queueName: 'PaymentQueue', deliveryMode: 'Persistent', description: '' },
          { id: 'q2', name: 'NotificationQueue', jndi: 'jms/NotificationQueue', scope: 'cell', provider: 'default', bus: 'BankingBus', queueName: 'NotificationQueue', deliveryMode: 'Application', description: '' },
          { id: 'q3', name: 'AuditQueue', jndi: 'jms/AuditQueue', scope: 'cell', provider: 'default', bus: 'BankingBus', queueName: 'AuditQueue', deliveryMode: 'Persistent', description: '' },
          { id: 'q4', name: 'LegacyCoreRequest', jndi: 'jms/LegacyCoreRequest', scope: 'cell', provider: 'mq', qmgr: 'QM_BANK01', queueName: 'BANK.CORE.REQUEST', deliveryMode: 'Persistent', description: 'MQ kuyruğu' }
        ],
        topics: [
          { id: 't1', name: 'RateUpdateTopic', jndi: 'jms/RateUpdateTopic', scope: 'cell', provider: 'default', bus: 'BankingBus', topicSpace: 'Default.Topic.Space', topicName: 'rates/fx', deliveryMode: 'NonPersistent', description: '' }
        ],
        aspecs: [
          { id: 'a1', name: 'NotificationAS', jndi: 'jms/NotificationAS', scope: 'cluster:MessagingCluster', provider: 'default', destJndi: 'jms/NotificationQueue', destType: 'Queue', bus: 'BankingBus', maxConcurrency: 10, maxBatchSize: 1, ackMode: 'Auto-acknowledge', description: 'NotificationMDB için' },
          { id: 'a2', name: 'PaymentAS', jndi: 'jms/PaymentAS', scope: 'cluster:BankingCluster', provider: 'default', destJndi: 'jms/PaymentQueue', destType: 'Queue', bus: 'BankingBus', maxConcurrency: 20, maxBatchSize: 5, ackMode: 'Auto-acknowledge', description: '' }
        ]
      };
      S.resourceAdapters = [
        { id: 'ra1', name: 'WebSphere Relational Resource Adapter', scope: 'cell', archive: '${WAS_INSTALL_ROOT}/lib/rsadapter.rar', builtIn: true, description: 'Built-in Relational Resource Adapter for WebSphere Persistence' },
        { id: 'ra2', name: 'SIB JMS Resource Adapter', scope: 'cell', archive: '${WAS_INSTALL_ROOT}/lib/sib.ra.rar', builtIn: true, description: 'Default messaging provider' },
        { id: 'ra3', name: 'WebSphere MQ Resource Adapter', scope: 'cell', archive: '${WAS_INSTALL_ROOT}/installedConnectors/wmq.jmsra.rar', builtIn: true, description: 'WebSphere MQ Resource Adapter' },
        { id: 'ra4', name: 'CICS ECI Resource Adapter', scope: 'cluster:BankingCluster', archive: '${CONNECTOR_INSTALL_ROOT}/cicseci.rar', builtIn: false, description: 'CICS Transaction Gateway ile ana sistem çağrıları' }
      ];
      S.j2cCFs = [{ id: 'j1', name: 'CICSBankCF', jndi: 'eis/CICSBank', scope: 'cluster:BankingCluster', ra: 'ra4', alias: 'CellManager01/mq_auth', props: { ConnectionURL: 'tcp://ctg01.corp.local', PortNumber: '2006', ServerName: 'CICSPROD' }, pool: { maxConnections: 20, minConnections: 2, connectionTimeout: 180 } }];
      S.mailProviders = [{ id: 'mp1', name: 'Built-in Mail Provider', scope: 'cell', builtIn: true, description: 'The built-in mail provider' }];
      S.mailSessions = [{ id: 'm1', name: 'BankMailSession', jndi: 'mail/BankMailSession', scope: 'cell', provider: 'mp1', mailTransportHost: 'smtp.corp.local', mailTransportPort: 25, mailTransportProtocol: 'smtp', mailFrom: 'noreply@ornekbank.com.tr', mailStoreHost: '', mailStoreProtocol: 'imap', debug: false }];
      S.urlProviders = [{ id: 'up1', name: 'Default URL Provider', scope: 'cell', streamHandler: 'unused', protocol: 'unused', builtIn: true }];
      S.urls = [{ id: 'u1', name: 'ConfigServiceURL', jndi: 'url/ConfigService', scope: 'cell', provider: 'up1', spec: 'https://config.corp.local/api/v1/bank', description: 'Merkezi yapılandırma servisi' }];
      S.workManagers = [
        { id: 'w1', name: 'DefaultWorkManager', jndi: 'wm/default', scope: 'cell', description: 'WebSphere Default Work Manager', category: '', numAlarmThreads: 5, minThreads: 0, maxThreads: 10, threadPriority: 5, isGrowable: true, workTimeout: 0, workReqQSize: 0, workReqQFullAction: 0, serviceNames: '' },
        { id: 'w2', name: 'BatchWorkManager', jndi: 'wm/batch', scope: 'server:AppNode03:BatchSrv01', description: 'Paralel rapor üretimi', category: 'batch', numAlarmThreads: 2, minThreads: 2, maxThreads: 16, threadPriority: 5, isGrowable: false, workTimeout: 600000, workReqQSize: 200, workReqQFullAction: 0, serviceNames: 'security;UserWorkArea' }
      ];
      S.timerManagers = [{ id: 'tm1', name: 'DefaultTimerManager', jndi: 'tm/default', scope: 'cell', numAlarmThreads: 2 }];
      S.schedulers = [{ id: 's1', name: 'BankingScheduler', jndi: 'sched/BankingScheduler', scope: 'cluster:BankingCluster', datasourceJNDIName: 'jdbc/CoreBankDS', datasourceAlias: 'CellManager01/corebank_app', tablePrefix: 'SCHED_', pollInterval: 30, workManagerInfoJNDIName: 'wm/default', useAdminRoles: false, description: 'Gün sonu ve faiz tahakkuku görevleri' }];
      S.resEnv = { providers: [{ id: 'rep1', name: 'BankConfigProvider', scope: 'cell', description: 'Özel yapılandırma nesneleri' }], entries: [{ id: 're1', name: 'FeatureFlags', jndi: 'resenv/FeatureFlags', scope: 'cell', provider: 'rep1', referenceable: 'com.ornekbank.config.FeatureFlagsFactory', description: '' }] };
      S.nameBindings = [
        { id: 'nb1', name: 'BankEnvironment', type: 'String', nameInNamespace: 'config/bankEnvironment', value: 'PROD', scope: 'cell' },
        { id: 'nb2', name: 'PaymentServiceEJB', type: 'EJB', nameInNamespace: 'ejb/remote/PaymentService', value: 'ejb/com/ornekbank/payment/PaymentServiceHome (BankingCluster)', scope: 'cell' },
        { id: 'nb3', name: 'LegacyCoreRef', type: 'Indirect', nameInNamespace: 'legacy/coreService', value: 'corbaname::legacy-was.corp.local:2809#cell/clusters/CoreCluster/ejb/CoreService', scope: 'cell' }
      ];
      S.templates = [
        { name: 'default', type: 'APPLICATION_SERVER', builtIn: true, description: 'The WebSphere Default Server Template' },
        { name: 'DeveloperServer', type: 'APPLICATION_SERVER', builtIn: true, description: 'The WebSphere Developer Server Template (geliştirme için optimize, üretimde kullanılmaz)' },
        { name: 'defaultZOS', type: 'APPLICATION_SERVER', builtIn: true, description: 'The WebSphere Default Server Template for z/OS' },
        { name: 'BankingTemplate', type: 'APPLICATION_SERVER', builtIn: false, description: 'BankSrv01 üzerinden oluşturuldu: heap 1024/2048, gencon, thread pool ayarlı' },
        { name: 'IHS', type: 'WEB_SERVER', builtIn: true, description: 'IBM HTTP Server Template' },
        { name: 'proxy_server', type: 'PROXY_SERVER', builtIn: true, description: 'The WebSphere Default Proxy Server Template' }
      ];
      S.genericServers = [{ name: 'FileTransferAgent', node: 'AppNode03', executable: '/opt/ornekbank/fta/bin/fta.sh', args: 'start', workDir: '/opt/ornekbank/fta', description: 'Harici dosya transfer ajanı (WAS tarafından başlatılır/izlenir)' }];
      S.proxyServers = [{ name: 'odrProxy01', node: 'AppNode03', protocols: 'HTTP, SIP', httpPort: 80, httpsPort: 443, description: 'WebSphere proxy server (kullanılmıyor – IHS tercih edildi)' }];
      S.mqServers = [{ name: 'QM_BANK01', qmgr: 'QM_BANK01', host: 'mq01.corp.local', port: 1414, channel: 'WAS.SVRCONN', description: 'IBM MQ kuyruk yöneticisi tanımı' }];
      S.nodeGroups = [{ name: 'DefaultNodeGroup', description: 'Default node group' }];
      S.coreGroups = [{ name: 'DefaultCoreGroup', numCoordinators: 1, preferredCoordinators: 'dmgr', protocol: 'Unicast', transport: 'CHANNEL_FRAMEWORK', description: 'Hücredeki tüm süreçleri içeren varsayılan core group',
        policies: [
          { name: 'Clustered TM Policy', type: 'One of N policy', failback: true, preferredOnly: false, match: 'type=WAS_TRANSACTIONS', quorum: false },
          { name: 'Default SIBus Policy', type: 'One of N policy', failback: false, preferredOnly: false, match: 'type=WSAF_SIB', quorum: false },
          { name: 'BankingBus ME Policy', type: 'One of N policy', failback: true, preferredOnly: false, match: 'type=WSAF_SIB, WSAF_SIB_MESSAGING_ENGINE=MessagingCluster.000-BankingBus', quorum: false, preferred: 'MsgSrv01' }
        ] }];
      S.coreGroupBridges = { accessPointGroups: [{ name: 'DefaultAccessPointGroup', coreGroups: ['DefaultCoreGroup'], peers: 'Yok (tek core group)' }] };
      S.security = {
        adminSecurity: true, appSecurity: true, java2: false, java2Warn: true, restrictResourceAuth: false,
        realm: 'corp.local', registry: 'federated', primaryAdmin: 'wasadmin', useRealmQualified: false, ignoreCase: true, allowOpsIfReposDown: false,
        serverId: 'Automatically generated server identity',
        repositories: [
          { id: 'InternalFileRepository', type: 'File', base: 'o=defaultWIMFileBasedRealm', host: '', port: '', description: 'Dahili dosya tabanlı depo (fileRegistry.xml) – acil durum admin hesabı' },
          { id: 'CorpAD', type: 'LDAP:AD', base: 'dc=corp,dc=local', host: 'ldap01.corp.local', port: 636, failover: 'ldap02.corp.local:636', bindDN: 'CN=svc_was,OU=Service Accounts,DC=corp,DC=local', loginProperties: 'sAMAccountName', ssl: true, sslAlias: 'CellDefaultSSLSettings', dirType: 'Microsoft Windows Server Active Directory', supportReferrals: 'ignore', certMapping: 'EXACT_DN', searchTimeout: 120, connectTimeout: 20, description: 'Kurumsal Active Directory' }
        ],
        ltpa: { timeout: 120, cacheTimeout: 10, cacheInitSize: 200, cacheMaxSize: 25000, keyGroup: 'CellLTPAKeySetGroup', autoGenerate: true, regenSchedule: 'Her 12 haftada bir, Pazar 03:00', lastGenerated: '2026-09-06 03:00' },
        sso: { enabled: true, requiresSSL: true, domain: '.corp.local', interop: false, webInbound: true },
        csiv2In: { basicAuth: 'SUPPORTED', clientCert: 'SUPPORTED', identityAssertion: false, transport: 'SSL-SUPPORTED', stateful: true, trustedIds: '' },
        csiv2Out: { basicAuth: 'SUPPORTED', clientCert: 'SUPPORTED', identityAssertion: false, transport: 'SSL-SUPPORTED', stateful: true },
        sslConfigs: [
          { name: 'CellDefaultSSLSettings', scope: 'cell', keyStore: 'CellDefaultKeyStore', trustStore: 'CellDefaultTrustStore', protocol: 'TLSv1.2', securityLevel: 'HIGH', clientAuth: 'None', serverAlias: '', clientAlias: '', provider: 'IBMJSSE2' },
          { name: 'NodeDefaultSSLSettings', scope: 'node:AppNode01', keyStore: 'NodeDefaultKeyStore', trustStore: 'NodeDefaultTrustStore', protocol: 'TLSv1.2', securityLevel: 'HIGH', clientAuth: 'None', serverAlias: '', clientAlias: '', provider: 'IBMJSSE2' },
          { name: 'NodeDefaultSSLSettings', scope: 'node:AppNode02', keyStore: 'NodeDefaultKeyStore', trustStore: 'NodeDefaultTrustStore', protocol: 'TLSv1.2', securityLevel: 'HIGH', clientAuth: 'None', serverAlias: '', clientAlias: '', provider: 'IBMJSSE2' },
          { name: 'NodeDefaultSSLSettings', scope: 'node:AppNode03', keyStore: 'NodeDefaultKeyStore', trustStore: 'NodeDefaultTrustStore', protocol: 'TLSv1.2', securityLevel: 'HIGH', clientAuth: 'None', serverAlias: '', clientAlias: '', provider: 'IBMJSSE2' },
          { name: 'IBTLSSettings', scope: 'cluster:BankingCluster', keyStore: 'IBPublicKeyStore', trustStore: 'CellDefaultTrustStore', protocol: 'TLSv1.2', securityLevel: 'CUSTOM', clientAuth: 'None', serverAlias: 'ib.ornekbank.com.tr', clientAlias: '', provider: 'IBMJSSE2' }
        ],
        keystores: [
          { name: 'CellDefaultKeyStore', scope: 'cell', path: '${CONFIG_ROOT}/cells/' + CELL + '/key.p12', type: 'PKCS12', readOnly: false, description: 'Default key store for ' + CELL },
          { name: 'CellDefaultTrustStore', scope: 'cell', path: '${CONFIG_ROOT}/cells/' + CELL + '/trust.p12', type: 'PKCS12', readOnly: false, description: 'Default trust store for ' + CELL },
          { name: 'CellLTPAKeys', scope: 'cell', path: '${CONFIG_ROOT}/cells/' + CELL + '/ltpa.jceks', type: 'JCEKS', readOnly: false, description: 'LTPA keys' },
          { name: 'NodeDefaultKeyStore', scope: 'node:AppNode01', path: '${CONFIG_ROOT}/cells/' + CELL + '/nodes/AppNode01/key.p12', type: 'PKCS12', readOnly: false, description: 'Default key store for AppNode01' },
          { name: 'NodeDefaultTrustStore', scope: 'node:AppNode01', path: '${CONFIG_ROOT}/cells/' + CELL + '/nodes/AppNode01/trust.p12', type: 'PKCS12', readOnly: false, description: 'Default trust store for AppNode01' },
          { name: 'IBPublicKeyStore', scope: 'cluster:BankingCluster', path: '/opt/ornekbank/ssl/ib-public.p12', type: 'PKCS12', readOnly: true, description: 'İnternet bankacılığı genel (public) sertifikası' },
          { name: 'CMSKeyStore', scope: 'cell', path: '${CONFIG_ROOT}/cells/' + CELL + '/nodes/ihsnode01/servers/webserver1/plugin-key.kdb', type: 'CMSKS', readOnly: false, description: 'Web server plug-in key ring (webserver1)' }
        ],
        certs: {
          personal: [
            { alias: 'default', issuedTo: 'CN=was-dmgr01.corp.local, OU=' + CELL + ', OU=CellManager01, O=IBM, C=US', issuedBy: 'CN=was-dmgr01.corp.local, OU=Root Certificate, OU=' + CELL + ', O=IBM, C=US', serial: '4A1F8C2E77D3', expires: '2027-03-11', keyStore: 'CellDefaultKeyStore' },
            { alias: 'ib.ornekbank.com.tr', issuedTo: 'CN=ib.ornekbank.com.tr, O=Ornek Bank A.S., C=TR', issuedBy: 'CN=Ornek Corp Issuing CA 02, DC=corp, DC=local', serial: '1F00000A8B9C2D', expires: '2026-12-19', keyStore: 'IBPublicKeyStore' }
          ],
          signer: [
            { alias: 'root', issuedTo: 'CN=was-dmgr01.corp.local, OU=Root Certificate, OU=' + CELL + ', O=IBM, C=US', expires: '2040-03-08', keyStore: 'CellDefaultTrustStore' },
            { alias: 'corp-root-ca', issuedTo: 'CN=Ornek Corp Root CA, DC=corp, DC=local', expires: '2034-01-01', keyStore: 'CellDefaultTrustStore' },
            { alias: 'corp-issuing-ca-02', issuedTo: 'CN=Ornek Corp Issuing CA 02, DC=corp, DC=local', expires: '2030-06-30', keyStore: 'CellDefaultTrustStore' },
            { alias: 'ldap01.corp.local', issuedTo: 'CN=ldap01.corp.local', expires: '2027-05-14', keyStore: 'CellDefaultTrustStore' }
          ]
        },
        domains: [{ name: 'PaymentSecurityDomain', scopes: ['cluster:BankingCluster'], description: 'Ödeme uygulamaları için ayrı JAAS login ve auth cache ayarları', appSecurity: true, java2: false, registry: 'Global (inherit)' }],
        adminUserRoles: [['wasadmin', 'Administrator, AdminSecurityManager'], ['svc_deploy', 'Deployer'], ['audit_user', 'Auditor']],
        adminGroupRoles: [['WASAdmins', 'Administrator'], ['WASOperators', 'Operator'], ['WASDeployers', 'Configurator, Deployer'], ['WASMonitors', 'Monitor']],
        users: [
          { uid: 'wasadmin', first: 'WAS', last: 'Admin', email: 'wasadmin@corp.local', repo: 'InternalFileRepository' },
          { uid: 'svc_deploy', first: 'Deploy', last: 'Service', email: '', repo: 'CorpAD' },
          { uid: 'audit_user', first: 'Denetim', last: 'Kullanıcısı', email: '', repo: 'CorpAD' },
          { uid: 'ayilmaz', first: 'Ahmet', last: 'Yılmaz', email: 'ayilmaz@corp.local', repo: 'CorpAD' },
          { uid: 'zkaya', first: 'Zeynep', last: 'Kaya', email: 'zkaya@corp.local', repo: 'CorpAD' },
          { uid: 'mdemir', first: 'Mehmet', last: 'Demir', email: 'mdemir@corp.local', repo: 'CorpAD' }
        ],
        groups: [
          { cn: 'WASAdmins', members: 'ayilmaz, zkaya', repo: 'CorpAD', description: 'Middleware yöneticileri' },
          { cn: 'WASOperators', members: 'mdemir', repo: 'CorpAD', description: '7/24 operasyon' },
          { cn: 'WASDeployers', members: 'svc_deploy', repo: 'CorpAD', description: 'CI/CD dağıtım hesabı' },
          { cn: 'WASMonitors', members: 'audit_user', repo: 'CorpAD', description: 'İzleme' },
          { cn: 'BankTellers', members: '(1.240 üye)', repo: 'CorpAD', description: 'Şube personeli' },
          { cn: 'PaymentOps', members: '(18 üye)', repo: 'CorpAD', description: 'Ödeme operasyonları' }
        ],
        jaasApp: ['ClientContainer', 'DefaultPrincipalMapping', 'JAASClient', 'WSLogin', 'PaymentCustomLogin'],
        jaasSys: ['DEFAULT', 'LTPA', 'LTPA_WEB', 'RMI_INBOUND', 'WEB_INBOUND', 'SWAM', 'wssecurity.signature', 'wssecurity.IDAssertion', 'ICSF', 'KRB5']
      };
      S.requestMetrics = { enable: false, components: 'ALL', traceLevel: 'PERF_DEBUG', standardLogs: true, arm: false, armType: 'ARM40', filtersSourceIP: '10.20.0.0/16', filtersURI: '/corebank/*' };
      S.jobManager = { registered: true, name: 'jobmgr01', host: 'was-jm01.corp.local', port: 9943, managedNodeName: CELL, uuid: 'JM-9C21-77AE' };
      S.adminAgents = [];
      return S;
    },
    runtime: function (S) {
      var RT = { __v: W.Data.VERSION, servers: {}, nodeagents: {}, dmgr: 'started', webservers: {}, sync: {}, generic: {}, pids: {}, startTimes: {} };
      var pid = 41200;
      S.servers.forEach(function (s) { RT.servers[s.name] = s.name === 'BatchSrv01' ? 'stopped' : 'started'; RT.pids[s.name] = (pid += 137); RT.startTimes[s.name] = '2026-11-21 02:1' + (s.slot + 1) + ':0' + s.slot; });
      S.nodeAgents.forEach(function (n) { RT.nodeagents[n.node] = 'started'; RT.sync[n.node] = n.node !== 'AppNode03'; });
      S.webservers.forEach(function (w) { RT.webservers[w.name] = 'running'; });
      (S.genericServers || []).forEach(function (g) { RT.generic[g.name] = 'started'; });
      RT.proxy = 'stopped';
      return RT;
    }
  };

  /* ---------------------------------------------------- yardımcı sorgular */
  W.srv = function (name) { return W.by(W.S.servers, 'name', name); };
  W.cluster = function (name) { return W.by(W.S.clusters, 'name', name); };
  W.app = function (name) { return W.by(W.S.apps, 'name', name); };
  W.node = function (name) { return W.by(W.S.nodes, 'name', name); };
  W.hostOf = function (node) { var n = W.node(node); return n ? n.host : ''; };
  W.serverStatus = function (s) {
    if (typeof s === 'string') s = W.srv(s);
    if (!s) return 'unknown';
    if (W.RT.nodeagents[s.node] && W.RT.nodeagents[s.node] !== 'started') return 'unknown';
    return W.RT.servers[s.name] || 'stopped';
  };
  W.clusterStatus = function (c) {
    var st = c.members.map(function (m) { return W.serverStatus(m.name); });
    if (!st.length) return 'stopped';
    if (st.every(function (x) { return x === 'started'; })) return 'started';
    if (st.some(function (x) { return x === 'starting'; })) return 'starting';
    if (st.some(function (x) { return x === 'stopping'; })) return 'stopping';
    if (st.some(function (x) { return x === 'started'; })) return 'partial';
    if (st.every(function (x) { return x === 'unknown'; })) return 'unknown';
    return 'stopped';
  };
  W.targetServers = function (a) {
    var out = [];
    a.targets.forEach(function (t) {
      var p = t.split(':');
      if (p[0] === 'cluster') { var c = W.cluster(p[1]); if (c) c.members.forEach(function (m) { var s = W.srv(m.name); if (s) out.push(s); }); }
      if (p[0] === 'server') { var s = W.srv(p[2]); if (s) out.push(s); }
    });
    return out;
  };
  W.appStatus = function (a) {
    if (typeof a === 'string') a = W.app(a);
    if (!a) return 'unknown';
    var ss = W.targetServers(a);
    if (a.state === 'stopped') return 'stopped';
    var up = ss.filter(function (s) { return W.serverStatus(s) === 'started'; }).length;
    if (!ss.length) return 'unknown';
    if (up === ss.length) return 'started';
    if (up === 0) return ss.some(function (s) { return W.serverStatus(s) === 'unknown'; }) ? 'unknown' : 'stopped';
    return 'partial';
  };
  W.targetLabel = function (t) {
    var p = t.split(':');
    if (p[0] === 'cluster') return 'WebSphere:cell=' + W.S.cell.name + ',cluster=' + p[1];
    if (p[0] === 'server') return 'WebSphere:cell=' + W.S.cell.name + ',node=' + p[1] + ',server=' + p[2];
    if (p[0] === 'webserver') return 'WebSphere:cell=' + W.S.cell.name + ',node=' + p[1] + ',server=' + p[2];
    return t;
  };
  W.targetShort = function (t) { var p = t.split(':'); return p[0] === 'cluster' ? 'Cluster: ' + p[1] : (p[0] === 'webserver' ? 'Web server: ' + p[2] : 'Server: ' + p[2] + ' (' + p[1] + ')'); };
  W.appsOnServer = function (s) {
    return W.S.apps.filter(function (a) { return W.targetServers(a).some(function (x) { return x.name === s.name; }); });
  };
  W.appsOnWebserver = function (ws) {
    return W.S.apps.filter(function (a) { return a.targets.indexOf('webserver:' + ws.node + ':' + ws.name) >= 0; });
  };
  W.resourcesInScope = function (coll, scope) { return (W.S[coll] || []).filter(function (r) { return r.scope === scope; }); };
  W.serverScope = function (s) { return 'server:' + s.node + ':' + s.name; };
  /* Sunucuya görünen kaynaklar (Server > Cluster > Node > Cell öncelik) */
  W.visibleScopes = function (s) {
    var a = [W.serverScope(s)];
    if (s.cluster) a.push('cluster:' + s.cluster);
    a.push('node:' + s.node, 'cell');
    return a;
  };
  W.allProcesses = function () {
    var L = [{ name: 'dmgr', node: 'CellManager01', type: 'Deployment manager' }];
    W.S.nodeAgents.forEach(function (n) { L.push({ name: 'nodeagent', node: n.node, type: 'Node agent' }); });
    W.S.servers.forEach(function (s) { L.push({ name: s.name, node: s.node, type: 'Application server', cluster: s.cluster }); });
    return L;
  };
})();
