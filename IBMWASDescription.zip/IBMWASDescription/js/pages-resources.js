/* pages-resources.js – Resources: JDBC (provider, data source, connection pool,
   test connection), JMS, Service Integration Bus ve diğer kaynaklar. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };

  /* -------------------------------------------- WebSphere variable çözümleme */
  // scopes: en özelden en genele (Server > Cluster > Node > Cell)
  W.resolveVar = function (name, scopes) {
    for (var i = 0; i < scopes.length; i++) {
      var v = W.S.variables.filter(function (x) { return x.name === name && x.scope === scopes[i]; })[0];
      if (v) return v;
    }
    return null;
  };
  W.expandVars = function (str, scopes, depth) {
    depth = depth || 0;
    return String(str).replace(/\$\{([A-Za-z0-9_.]+)\}/g, function (m, n) {
      var v = W.resolveVar(n, scopes);
      if (!v) return '⟨' + n + ' TANIMSIZ⟩';
      return depth > 5 ? v.value : W.expandVars(v.value, scopes, depth + 1);
    });
  };
  function nodesForScope(scope) {
    var p = (scope || 'cell').split(':');
    if (p[0] === 'cell') return W.S.nodeAgents.map(function (n) { return { node: n.node, scopes: ['node:' + n.node, 'cell'] }; });
    if (p[0] === 'node') return [{ node: p[1], scopes: ['node:' + p[1], 'cell'] }];
    if (p[0] === 'cluster') { var c = W.cluster(p[1]), seen = {}; return c.members.filter(function (m) { if (seen[m.node]) return false; seen[m.node] = 1; return true; }).map(function (m) { return { node: m.node, scopes: ['cluster:' + p[1], 'node:' + m.node, 'cell'] }; }); }
    var s = W.srv(p[2]); return [{ node: p[1], server: p[2], scopes: W.visibleScopes(s) }];
  }

  /* --------------------------------------------------------- JDBC providers */
  var DBT = {
    Oracle: { types: ['Oracle JDBC Driver'], impl: { 'Connection pool data source': 'oracle.jdbc.pool.OracleConnectionPoolDataSource', 'XA data source': 'oracle.jdbc.xa.client.OracleXADataSource' }, cp: '${ORACLE_JDBC_DRIVER_PATH}/ojdbc8.jar', helper: 'com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper' },
    DB2: { types: ['DB2 Using IBM JCC Driver', 'DB2 Universal JDBC Driver Provider'], impl: { 'Connection pool data source': 'com.ibm.db2.jcc.DB2ConnectionPoolDataSource', 'XA data source': 'com.ibm.db2.jcc.DB2XADataSource' }, cp: '${DB2_JCC_DRIVER_PATH}/db2jcc4.jar\n${DB2_JCC_DRIVER_PATH}/db2jcc_license_cu.jar', helper: 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper' },
    'SQL Server': { types: ['Microsoft SQL Server JDBC Driver'], impl: { 'Connection pool data source': 'com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource', 'XA data source': 'com.microsoft.sqlserver.jdbc.SQLServerXADataSource' }, cp: '${MICROSOFT_JDBC_DRIVER_PATH}/mssql-jdbc-8.4.1.jre8.jar', helper: 'com.ibm.websphere.rsadapter.MicrosoftSQLServerDataStoreHelper' },
    Derby: { types: ['Derby JDBC Provider'], impl: { 'Connection pool data source': 'org.apache.derby.jdbc.EmbeddedConnectionPoolDataSource', 'XA data source': 'org.apache.derby.jdbc.EmbeddedXADataSource' }, cp: '${DERBY_JDBC_DRIVER_PATH}/derby.jar', helper: 'com.ibm.websphere.rsadapter.DerbyDataStoreHelper' },
    'User-defined': { types: ['User-defined JDBC Provider'], impl: { 'Connection pool data source': '', 'XA data source': '' }, cp: '', helper: 'com.ibm.websphere.rsadapter.GenericDataStoreHelper' }
  };
  W.DBT = DBT;
  W.resType({
    id: 'jdbcprov', coll: 'jdbcProviders', path: '/res/jdbc/providers', title: 'JDBC providers', singular: 'JDBC provider', help: 'concept.jdbcProvider', scoped: true, cfgType: 'JDBCProvider',
    desc: 'Use this page to edit properties of a JDBC provider. The JDBC provider object encapsulates the specific JDBC driver implementation class for access to the specific vendor database of your environment.',
    note: 'JDBC provider, veritabanı sürücüsünün (JAR) nerede olduğunu ve hangi implementasyon sınıfının kullanılacağını tanımlar. Class path\'te <code>${ORACLE_JDBC_DRIVER_PATH}</code> gibi <a href="#/env/variables">WebSphere variable</a>\'lar kullanılır; bu değişken, provider\'ın kullanılacağı her node\'da tanımlı olmalıdır.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description' }, { k: 'impl', l: 'Implementation type', h: 'jdbc.implType' }],
    defaults: function (scope) { return { name: '', scope: scope, dbType: 'Oracle', providerType: 'Oracle JDBC Driver', impl: 'Connection pool data source', implClass: DBT.Oracle.impl['Connection pool data source'], classpath: DBT.Oracle.cp, nativePath: '', description: '' }; },
    form: function (o, isNew) {
      return F.sel({ l: 'Database type', n: 'dbType', v: o.dbType, o: Object.keys(DBT), h: 'jdbc.dbType', ro: !isNew }) + F.sel({ l: 'Provider type', n: 'providerType', v: o.providerType, o: [].concat.apply([], Object.keys(DBT).map(function (k) { return DBT[k].types; })), h: 'jdbc.dbType', ro: !isNew }) +
        F.sel({ l: 'Implementation type', n: 'impl', v: o.impl, o: ['Connection pool data source', 'XA data source'], h: 'jdbc.implType', ro: !isNew }) + F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'concept.jdbcProvider' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
        F.ta({ l: 'Class path', n: 'classpath', v: o.classpath, h: 'jdbc.classpath' }) + F.text({ l: 'Native library path', n: 'nativePath', v: o.nativePath, h: 'jdbc.nativePath' }) + F.text({ l: 'Implementation class name', n: 'implClass', v: o.implClass, h: 'jdbc.implClass', req: true });
    },
    beforeCreate: function (o) { var d = DBT[o.dbType]; if (d && !o.implClass) o.implClass = d.impl[o.impl]; },
    ap: function (o) { return [{ t: 'Additional Properties', items: [{ l: 'Data sources', href: '#/res/jdbc/ds', h: 'concept.datasource' }] }]; },
    canDelete: function (o) { var ds = W.S.dataSources.filter(function (d) { return d.provider === o.id; }); if (ds.length) return esc(o.name) + ' silinemez: ' + ds.map(function (d) { return esc(d.name); }).join(', ') + ' data source(lar)ı bu provider\'ı kullanıyor.'; },
    createCmd: function (o) { return ["AdminTask.createJDBCProvider('[-scope " + W.scopeLabel(o.scope) + " -databaseType " + o.dbType + " -providerType \"" + o.providerType + "\" -implementationType \"" + o.impl + "\" -name \"" + o.name + "\" -classpath [" + o.classpath.replace(/\n/g, ' ') + "] -nativePath \"\"]')", 'AdminConfig.save()']; }
  });

  /* ----------------------------------------------------------- data sources */
  W.resType({
    id: 'ds', coll: 'dataSources', path: '/res/jdbc/ds', title: 'Data sources', singular: 'Data source', help: 'concept.datasource', scoped: true, cfgType: 'DataSource', newHref: '#/wz/createDS',
    desc: 'Use this page to edit the settings of a datasource that is associated with your selected JDBC provider. The datasource object supplies your application with connections for accessing the database.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name', h: 'ds.jndi' }, { k: 'prov', l: 'Provider', sv: function (r) { var p = W.by(W.S.jdbcProviders, 'id', r.provider); return p ? p.name : ''; }, fmt: function (r) { var p = W.by(W.S.jdbcProviders, 'id', r.provider); return p ? '<a href="#/res/jdbc/providers/' + p.id + '">' + esc(p.name) + '</a>' : ''; } }, { k: 'description', l: 'Description' }],
    buttons: [{ l: 'Test connection', act: 'dsTest', need: 1 }, { l: 'Manage state...', act: 'notInSim', arg: 'Manage state' }],
    defaults: function (scope) { return { name: '', jndi: 'jdbc/', scope: scope, provider: 'p1', helper: DBT.Oracle.helper, props: { URL: 'jdbc:oracle:thin:@//dbhost:1521/SERVICE' }, authAlias: '', mappingAlias: 'DefaultPrincipalMapping', cmp: false, description: '', statementCacheSize: 10, nonTransactional: false, validateNewConnection: false, validationQuery: '', pool: { connectionTimeout: 180, maxConnections: 10, minConnections: 1, reapTime: 180, unusedTimeout: 1800, agedTimeout: 0, purgePolicy: 'EntirePool', surgeThreshold: -1, stuckTimerTime: 0 } }; },
    form: function (o) {
      var p = W.by(W.S.jdbcProviders, 'id', o.provider) || {};
      var aliases = [['', '(none)']].concat(W.S.authAliases.map(function (a) { return [a.id, a.id]; }));
      var dbprops = o.props.URL != null ? F.text({ l: 'URL', n: 'props.URL', v: o.props.URL, req: true, h: 'ds.url' }) :
        F.text({ l: 'Database name', n: 'props.databaseName', v: o.props.databaseName, h: 'ds.url' }) + (o.props.driverType != null ? F.sel({ l: 'Driver type', n: 'props.driverType', v: o.props.driverType, o: ['4', '2'], h: 'ds.url' }) : '') + (o.props.serverName != null ? F.text({ l: 'Server name', n: 'props.serverName', v: o.props.serverName, h: 'ds.url' }) + F.num({ l: 'Port number', n: 'props.portNumber', v: o.props.portNumber, h: 'ds.url' }) : '');
      return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'concept.datasource' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) +
        F.ro({ l: 'JDBC provider', v: '<a href="#/res/jdbc/providers/' + esc(p.id || '') + '">' + esc(p.name || '') + '</a> (' + esc(p.impl || '') + ')', raw: true, h: 'concept.jdbcProvider' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
        F.grp('Common and required data source properties', 'ds.url', dbprops) +
        F.grp('Data store helper class name', 'ds.helper', F.text({ l: 'Data store helper class name', n: 'helper', v: o.helper, h: 'ds.helper' })) +
        F.grp('Security settings', 'ds.alias',
          F.sel({ l: 'Component-managed authentication alias', n: 'authAlias', v: o.authAlias, o: aliases, h: 'ds.alias' }) +
          F.sel({ l: 'Mapping-configuration alias', n: 'mappingAlias', v: o.mappingAlias, o: ['DefaultPrincipalMapping', '(none)'], h: 'ds.alias' }) +
          F.sel({ l: 'Container-managed authentication alias', n: 'containerAlias', v: o.containerAlias || o.authAlias, o: aliases, h: 'ds.alias' })) +
        F.ck({ l: 'Use this data source in container managed persistence (CMP)', n: 'cmp', v: o.cmp, h: 'ds.cmp' });
    },
    ap: function (o) {
      var b = '#/res/jdbc/ds/' + o.id;
      return [{ t: 'Additional Properties', items: [{ l: 'Connection pool properties', href: b + '/pool', h: 'concept.connectionPool' }, { l: 'WebSphere Application Server data source properties', href: b + '/wasprops', h: 'ds.wasprops' }, { l: 'Custom properties', href: W.propsLink('dataSources|' + o.id, 'customProps', 'Data source ' + o.name, b), h: 'concept.customProps' }] },
        { t: 'Related Items', items: [{ l: 'JAAS - J2C authentication data', href: '#/sec/jaas/j2c', h: 'sec.authAlias' }, { l: 'JDBC providers', href: '#/res/jdbc/providers', h: 'concept.jdbcProvider' }] }];
    },
    detailNote: function (o) {
      var users = W.S.apps.filter(function (a) { return a.resourceRefs.some(function (r) { return r.target === o.jndi; }); });
      return 'Kapsam: <b>' + esc(W.scopeFull(o.scope)) + '</b>. Bu data source\'u kullanan uygulamalar: ' + (users.map(function (a) { return W.appLink(a.name); }).join(', ') || '(yok)') + '. <button class="btn" data-act="dsTestOne" data-arg="' + esc(o.id) + '">Test connection</button>';
    },
    canDelete: function (o) { var u = W.S.apps.filter(function (a) { return a.resourceRefs.some(function (r) { return r.target === o.jndi; }); }); if (u.length) return '<span style="color:#b26a00">' + esc(o.name) + ' silinemedi: ' + u.map(function (a) { return esc(a.name); }).join(', ') + ' uygulaması ' + esc(o.jndi) + ' referansını kullanıyor (silinirse NameNotFoundException alınır).</span>'; }
  });
  function dsTest(o) {
    var prov = W.by(W.S.jdbcProviders, 'id', o.provider), out = [];
    var hostPart = (o.props.URL || o.props.serverName || '').replace(/^.*@\/\//, '').replace(/[:/].*$/, '');
    nodesForScope(o.scope).forEach(function (n) {
      var where = n.server && W.serverStatus(n.server) === 'started' ? 'server ' + n.server : 'server nodeagent';
      if (W.RT.nodeagents[n.node] !== 'started') { out.push('<span style="color:#c62828">The test connection operation failed for data source ' + esc(o.name) + ' on server nodeagent at node ' + esc(n.node) + ': ADMC0016E node agent erişilemiyor.</span>'); return; }
      var missing = (prov ? prov.classpath : '').match(/\$\{([A-Za-z0-9_]+)\}/g) || [];
      missing = missing.map(function (m) { return m.slice(2, -1); }).filter(function (v) { return !W.resolveVar(v, n.scopes); });
      if (missing.length) { out.push('<span style="color:#c62828">The test connection operation failed for data source ' + esc(o.name) + ' on ' + where + ' at node ' + esc(n.node) + ' with the following exception: java.lang.ClassNotFoundException: ' + esc(prov.implClass) + '. DSRA8040I: Failed to connect to the DataSource. WebSphere variable <b>' + missing.map(esc).join(', ') + '</b> node ' + esc(n.node) + ' için tanımlı değil (<a href="#/env/variables">WebSphere variables</a>).</span>'); return; }
      if (o.testFail) { out.push('<span style="color:#c62828">The test connection operation failed for data source ' + esc(o.name) + ' on ' + where + ' at node ' + esc(n.node) + ' with the following exception: com.microsoft.sqlserver.jdbc.SQLServerException: The TCP/IP connection to the host ' + esc(hostPart) + ', port ' + esc(o.props.portNumber || '') + ' has failed. Error: "Connection refused." DSRA0010E: SQL State = 08S01, Error Code = 0. View JVM logs for further details.</span>'); return; }
      if (!o.authAlias && prov && prov.dbType !== 'Derby') { out.push('<span style="color:#c62828">The test connection operation failed for data source ' + esc(o.name) + ' on ' + where + ' at node ' + esc(n.node) + ' with the following exception: java.sql.SQLException: ORA-01017: invalid username/password; logon denied DSRA0010E: SQL State = 72000, Error Code = 1,017. (Component-managed authentication alias tanımlı değil.)</span>'); return; }
      out.push('The test connection operation for data source ' + esc(o.name) + ' on ' + where + ' at node ' + esc(n.node) + ' was successful.');
    });
    W.cmd('Test connection: ' + o.name, ["ds = AdminConfig.getid('" + W.cfgScope(o.scope) + "JDBCProvider:" + (prov ? prov.name : '') + "/DataSource:" + o.name + "/')", 'print AdminControl.testConnection(ds)']);
    return out;
  }
  A.dsTest = function (el) { var m = []; W.selected(el.dataset.tbl).forEach(function (id) { m = m.concat(dsTest(W.by(W.S.dataSources, 'id', id))); }); W.clearSel(el.dataset.tbl); W.msg('info', m); W.rerender(); };
  A.dsTestOne = function (el) { W.msg('info', dsTest(W.by(W.S.dataSources, 'id', el.dataset.arg))); W.rerender(); };

  R('/res/jdbc/ds/:id/pool', function (p) {
    var o = W.by(W.S.dataSources, 'id', p.id), q = o.pool, b = '#/res/jdbc/ds/' + o.id;
    var users = W.S.servers.filter(function (s) { return W.visibleScopes(s).indexOf(o.scope) >= 0; });
    var wcMax = users.length ? Math.max.apply(null, users.map(function (s) { return W.by(s.threadPools, 'name', 'WebContainer').maximumSize; })) : 0;
    return { title: 'Data sources', help: 'concept.connectionPool', html: W.crumbs([['Data sources', '#/res/jdbc/ds'], [o.name, b], 'Connection pools']) +
      '<p class="desc">Use this page to edit the connection pool settings for a data source. Havuz <b>her JVM (sunucu) için ayrı</b> oluşturulur: Cell scope\'taki bu data source\'u kullanan ' + users.length + ' sunucunun her biri en fazla <b>Maximum connections</b> kadar bağlantı açabilir.' + W.hi('concept.connectionPool') + '</p>' +
      '<div class="note-tr">Veritabanına açılabilecek toplam bağlantı ≈ ' + users.length + ' sunucu × ' + q.maxConnections + ' = <b>' + users.length * q.maxConnections + '</b>. DBA ile veritabanı tarafındaki oturum (sessions/processes) limitini doğrulayın. Bu sunuculardaki en büyük WebContainer thread pool: <b>' + wcMax + '</b>.</div>' +
      W.cfgForm({ ref: 'dataSources|' + o.id + '|pool', doc: W.scopeDoc(o.scope) + 'resources.xml', cfgid: W.cfgScope(o.scope) + 'DataSource:' + o.name + '/ConnectionPool:/', back: b, title: 'Connection pool ' + o.name, validate: 'pool', general:
        F.num({ l: 'Connection timeout', n: 'connectionTimeout', v: q.connectionTimeout, unit: 'seconds', h: 'pool.connTimeout', min: 0 }) +
        F.num({ l: 'Maximum connections', n: 'maxConnections', v: q.maxConnections, unit: 'connections', h: 'pool.max', min: 0 }) +
        F.num({ l: 'Minimum connections', n: 'minConnections', v: q.minConnections, unit: 'connections', h: 'pool.min', min: 0 }) +
        F.num({ l: 'Reap time', n: 'reapTime', v: q.reapTime, unit: 'seconds', h: 'pool.reap', min: 0 }) +
        F.num({ l: 'Unused timeout', n: 'unusedTimeout', v: q.unusedTimeout, unit: 'seconds', h: 'pool.unused', min: 0 }) +
        F.num({ l: 'Aged timeout', n: 'agedTimeout', v: q.agedTimeout, unit: 'seconds', h: 'pool.aged', min: 0 }) +
        F.sel({ l: 'Purge policy', n: 'purgePolicy', v: q.purgePolicy, o: ['EntirePool', 'FailingConnectionOnly'], h: 'pool.purge' }),
        ap: [{ t: 'Additional Properties', items: [{ l: 'Advanced connection pool properties', act: 'notInSim', arg: 'Advanced connection pool properties', h: 'concept.connectionPool' }, { l: 'Connection pool custom properties', href: W.propsLink('dataSources|' + o.id + '|pool', 'customProps', 'Connection pool', b + '/pool'), h: 'concept.customProps' }] }] }) };
  });
  W.validators.pool = function (v, form) {
    var e = [];
    if (v.minConnections > v.maxConnections && v.maxConnections > 0) e.push('Minimum connections, Maximum connections değerinden büyük olamaz.');
    if (v.reapTime === 0 && (v.unusedTimeout > 0 || v.agedTimeout > 0)) W.msg('warning', 'Uyarı: Reap time = 0 olduğunda pool maintenance thread çalışmaz; Unused timeout ve Aged timeout etkisiz kalır.');
    if (v.reapTime > 0 && v.unusedTimeout > 0 && v.reapTime >= v.unusedTimeout) W.msg('warning', 'Uyarı: Reap time, Unused timeout değerinden küçük olmalıdır (IBM önerisi). Aksi halde kullanılmayan bağlantılar beklenenden geç kapatılır.');
    var o = W.resolve(form.dataset.ref.split('|').slice(0, 2).join('|'));
    var wc = W.S.servers.filter(function (s) { return W.visibleScopes(s).indexOf(o.scope) >= 0; }).map(function (s) { return W.by(s.threadPools, 'name', 'WebContainer').maximumSize; });
    if (wc.length && v.maxConnections < Math.max.apply(null, wc) / 3) W.msg('warning', 'Uyarı: Maximum connections (' + v.maxConnections + ') WebContainer thread pool boyutuna (' + Math.max.apply(null, wc) + ') göre düşük. Yük altında istek thread\'leri bağlantı bekler; Connection timeout (' + v.connectionTimeout + ' sn) aşılırsa <b>J2CA0045E / ConnectionWaitTimeoutException</b> alınır.');
    return e;
  };
  R('/res/jdbc/ds/:id/wasprops', function (p) {
    var o = W.by(W.S.dataSources, 'id', p.id), b = '#/res/jdbc/ds/' + o.id;
    return { title: 'Data sources', help: 'ds.wasprops', html: W.crumbs([['Data sources', '#/res/jdbc/ds'], [o.name, b], 'WebSphere Application Server data source properties']) +
      W.cfgForm({ ref: 'dataSources|' + o.id, doc: W.scopeDoc(o.scope) + 'resources.xml', back: b, title: 'WAS data source properties', general:
        F.num({ l: 'Statement cache size', n: 'statementCacheSize', v: o.statementCacheSize, unit: 'statements', h: 'ds.stmtCache', min: 0 }) +
        F.ck({ l: 'Enable multithreaded access detection', n: 'mtDetect', v: !!o.mtDetect, h: 'ds.wasprops' }) +
        F.ck({ l: 'Enable database reauthentication', n: 'reauth', v: !!o.reauth, h: 'ds.wasprops' }) +
        F.ck({ l: 'Enable JMS one phase optimization support', n: 'jms1pc', v: !!o.jms1pc, h: 'ds.wasprops' }) +
        F.ck({ l: 'Log missing transaction context', n: 'logMissingTx', v: o.logMissingTx !== false, h: 'ds.wasprops' }) +
        F.ck({ l: 'Non-transactional data source', n: 'nonTransactional', v: o.nonTransactional, h: 'ds.nonTx' }) +
        F.grp('Connection validation properties', 'ds.validate', F.ck({ l: 'Validate new connections', n: 'validateNewConnection', v: o.validateNewConnection, h: 'ds.validate' }) + F.text({ l: 'Validation by SQL query', n: 'validationQuery', v: o.validationQuery, ph: 'ör. SELECT 1 FROM DUAL', h: 'ds.validate' })) }) };
  });

  /* Create data source wizard */
  W.wizard('createDS', {
    title: 'Data sources', help: 'concept.datasource', back: '#/res/jdbc/ds', crumbs: [['Data sources', '#/res/jdbc/ds'], 'Create a data source'],
    init: function () { var sc = W.currentScope('ds'); return { scope: sc === 'all' ? 'cell' : sc, name: '', jndi: 'jdbc/', provMode: 'existing', provider: 'p1', newDb: 'Oracle', newImpl: 'Connection pool data source', url: 'jdbc:oracle:thin:@//dbhost.corp.local:1521/SERVICE', dbName: '', server: '', port: 50000, alias: '', cmp: false }; },
    steps: function (v) {
      return [
        { t: 'Enter basic data source information', h: 'concept.datasource', html: function (v2) {
          return F.sel({ l: 'Scope', n: 'scope', v: v2.scope, o: W.scopeOptions(false), h: 'concept.scope' }) + F.text({ l: 'Data source name', n: 'name', v: v2.name, req: true, h: 'concept.datasource', ph: 'ör. LoanDS' }) + F.text({ l: 'JNDI name', n: 'jndi', v: v2.jndi, req: true, h: 'ds.jndi' });
        }, validate: function (v2) {
          if (!/^jdbc\//.test(v2.jndi)) W.msg('warning', 'Uyarı: JNDI adı için "jdbc/" öneki standart uygulamadır.');
          if (W.S.dataSources.some(function (d) { return d.jndi === v2.jndi && d.scope === v2.scope; })) return ['Bu scope\'ta aynı JNDI adlı bir data source zaten var.'];
        } },
        { t: 'Select JDBC provider', h: 'concept.jdbcProvider', html: function (v2) {
          var vis = W.S.jdbcProviders.filter(function (p) { return p.scope === v2.scope || p.scope === 'cell' || (v2.scope.indexOf('server:') === 0 && W.visibleScopes(W.srv(v2.scope.split(':')[2])).indexOf(p.scope) >= 0); });
          return F.radio({ l: '', n: 'provMode', v: v2.provMode, o: [['existing', 'Select an existing JDBC provider'], ['new', 'Create new JDBC provider']] }) +
            F.sel({ l: 'Existing JDBC provider', n: 'provider', v: v2.provider, o: vis.map(function (p) { return [p.id, p.name + ' (' + W.scopeLabel(p.scope) + ')']; }), h: 'concept.jdbcProvider' }) +
            F.grp('Create new JDBC provider', 'concept.jdbcProvider', F.sel({ l: 'Database type', n: 'newDb', v: v2.newDb, o: Object.keys(DBT), h: 'jdbc.dbType' }) + F.sel({ l: 'Implementation type', n: 'newImpl', v: v2.newImpl, o: ['Connection pool data source', 'XA data source'], h: 'jdbc.implType' }));
        } },
        { t: 'Enter database specific properties for the data source', h: 'ds.url', html: function (v2) {
          var db = v2.provMode === 'new' ? v2.newDb : (W.by(W.S.jdbcProviders, 'id', v2.provider) || {}).dbType;
          var h = db === 'Oracle' ? F.text({ l: 'Value for URL', n: 'url', v: v2.url, req: true, h: 'ds.url' }) : F.text({ l: 'Database name', n: 'dbName', v: v2.dbName, req: true, h: 'ds.url' }) + F.text({ l: 'Server name', n: 'server', v: v2.server, h: 'ds.url' }) + F.num({ l: 'Port number', n: 'port', v: v2.port, h: 'ds.url' });
          return h + F.ro({ l: 'Data store helper class name', v: (DBT[db] || DBT.Oracle).helper, h: 'ds.helper' }) + F.ck({ l: 'Use this data source in container managed persistence (CMP)', n: 'cmp', v: v2.cmp, h: 'ds.cmp' });
        } },
        { t: 'Setup security aliases', h: 'ds.alias', html: function (v2) {
          var al = [['', '(none)']].concat(W.S.authAliases.map(function (a) { return [a.id, a.id + ' (' + a.user + ')']; }));
          return F.sel({ l: 'Component-managed authentication alias', n: 'alias', v: v2.alias, o: al, h: 'ds.alias' }) + F.sel({ l: 'Mapping-configuration alias', n: 'map', v: 'DefaultPrincipalMapping', o: ['DefaultPrincipalMapping', '(none)'], h: 'ds.alias' }) + F.sel({ l: 'Container-managed authentication alias', n: 'calias', v: v2.alias, o: al, h: 'ds.alias' }) +
            '<p><a href="#/sec/jaas/j2c">Global J2C authentication alias</a> sayfasından yeni alias oluşturabilirsiniz.</p>';
        } },
        { t: 'Summary', html: function (v2) {
          var p = v2.provMode === 'new' ? v2.newDb + ' (yeni provider)' : (W.by(W.S.jdbcProviders, 'id', v2.provider) || {}).name;
          return W.kvTable([['Scope', esc(W.scopeFull(v2.scope))], ['Data source name', esc(v2.name)], ['JNDI name', esc(v2.jndi)], ['JDBC provider', esc(p)], ['URL / DB', esc(v2.url || v2.dbName)], ['Component-managed authentication alias', esc(v2.alias || '(none)')]]);
        } }
      ];
    },
    finish: function (v) {
      var prov = v.provider;
      if (v.provMode === 'new') {
        var d = DBT[v.newDb]; prov = W.newId('p');
        W.S.jdbcProviders.push({ id: prov, name: d.types[0] + (v.newImpl === 'XA data source' ? ' (XA)' : ''), scope: v.scope, dbType: v.newDb, providerType: d.types[0], impl: v.newImpl, implClass: d.impl[v.newImpl], classpath: d.cp, nativePath: '', description: '' });
      }
      var P = W.by(W.S.jdbcProviders, 'id', prov), db = P.dbType;
      var o = W.resTypes.ds.defaults(v.scope);
      Object.assign(o, { id: W.newId('d'), name: v.name, jndi: v.jndi, provider: prov, helper: (DBT[db] || DBT.Oracle).helper, authAlias: v.alias, containerAlias: v.calias, cmp: v.cmp, props: db === 'Oracle' ? { URL: v.url } : { databaseName: v.dbName, driverType: 4, serverName: v.server, portNumber: v.port } });
      W.S.dataSources.push(o);
      W.change(W.scopeDoc(v.scope) + 'resources.xml', 'Data source oluşturuldu: ' + v.name);
      W.cmd('Data source oluştur: ' + v.name, ["provider = AdminConfig.getid('" + W.cfgScope(v.scope) + "JDBCProvider:" + P.name + "/')", "AdminTask.createDatasource(provider, '[-name " + v.name + " -jndiName " + v.jndi + " -dataStoreHelperClassName " + o.helper + " -containerManagedPersistence " + v.cmp + (v.alias ? " -componentManagedAuthenticationAlias " + v.alias : '') + " -configureResourceProperties [" + (db === 'Oracle' ? "[URL java.lang.String " + v.url + "]" : "[databaseName java.lang.String " + v.dbName + "] [serverName java.lang.String " + v.server + "] [portNumber java.lang.Integer " + v.port + "]") + "]]')", 'AdminConfig.save()']);
      return { msgs: ['Data source <b>' + esc(v.name) + '</b> (' + esc(v.jndi) + ') ' + esc(W.scopeFull(v.scope)) + ' kapsamında oluşturuldu.', 'Kaydettikten sonra <b>Test connection</b> ile bağlantıyı doğrulayın. Uygulamaların kullanabilmesi için resource reference\'larının bu JNDI adına bağlanması gerekir.'], go: '#/res/jdbc/ds' };
    }
  });

  /* ------------------------------------------------------------------- JMS */
  R('/res/jms/providers', function () {
    var rows = [{ name: 'Default messaging provider', d: 'Service Integration Bus (SIBus) tabanlı, WAS ile gelen yerleşik JMS sağlayıcısı', scope: 'cell' }, { name: 'WebSphere MQ messaging provider', d: 'Harici IBM MQ kuyruk yöneticilerine bağlanan sağlayıcı (wmq.jmsra.rar)', scope: 'cell' }, { name: 'V5 default messaging provider', d: 'Kullanımdan kaldırılmış (deprecated) – WAS V5 uyumluluğu', scope: 'cell' }];
    return { title: 'JMS providers', help: 'concept.jmsProvider', html: '<div class="page-title">JMS providers' + W.hi('concept.jmsProvider') + '</div><p class="desc">Use this page to select a messaging provider for which you want to administer JMS resources. JMS provider\'lar her scope\'ta (Cell, Node, Cluster, Server) örtük olarak bulunur.</p>' + W.scopeBox('jmsprov') +
      W.table({ id: 'jmsprov', select: false, rows: rows, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Provider' }, { k: 'd', l: 'Description' }, W.scopeCol] }) +
      '<div class="note-tr"><b>Default messaging provider</b> mesajları WAS içindeki SIBus messaging engine\'lerinde saklar (<a href="#/sib/buses">Buses</a>). <b>WebSphere MQ messaging provider</b> ise mesajları ayrı bir IBM MQ sunucusunda tutar ve kurumsal entegrasyonlar (mainframe, diğer platformlar) için tercih edilir.' + W.hi('concept.sib') + '</div>' };
  });
  function cfForm(o, isNew) {
    var buses = W.S.sib.buses.map(function (b) { return b.name; });
    return F.sel({ l: 'Messaging provider', n: 'provider', v: o.provider, o: [['default', 'Default messaging provider'], ['mq', 'WebSphere MQ messaging provider']], h: 'concept.jmsProvider', ro: !isNew }) +
      F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'jms.cf' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
      (o.provider === 'mq' && !isNew ? '' : F.grp('Connection (Default messaging provider)', 'concept.sib', F.sel({ l: 'Bus name', n: 'bus', v: o.bus, o: buses, h: 'concept.sib' }) + F.sel({ l: 'Target type', n: 'targetType', v: o.targetType || 'BusMember', o: ['BusMember', 'Custom', 'ME'], h: 'jms.target' }) + F.text({ l: 'Target', n: 'target', v: o.target, h: 'jms.target' }) + F.sel({ l: 'Connection proximity', n: 'connectionProximity', v: o.connectionProximity || 'Bus', o: ['Bus', 'Cluster', 'Host', 'Server'], h: 'jms.target' }))) +
      (o.provider === 'default' && !isNew ? '' : F.grp('Connection (WebSphere MQ messaging provider)', 'jms.mq', F.text({ l: 'Queue manager', n: 'qmgr', v: o.qmgr, h: 'jms.mq' }) + F.text({ l: 'Host', n: 'host', v: o.host, h: 'jms.mq' }) + F.num({ l: 'Port', n: 'port', v: o.port, h: 'jms.mq' }) + F.text({ l: 'Server connection channel', n: 'channel', v: o.channel, h: 'jms.mq' }) + F.sel({ l: 'Transport', n: 'transport', v: o.transport || 'CLIENT', o: ['CLIENT', 'BINDINGS', 'BINDINGS_THEN_CLIENT'], h: 'jms.mq' }) + F.sel({ l: 'Authentication alias', n: 'alias', v: o.alias, o: [['', '(none)']].concat(W.S.authAliases.map(function (a) { return [a.id, a.id]; })), h: 'sec.authAlias' }))) +
      F.num({ l: 'Connection pool – Maximum connections', n: 'maxConnections', v: o.maxConnections, h: 'jms.cfPool' });
  }
  [['cf', 'CF', 'Connection factories', 'Connection factory', 'jms.cf', 'createSIBJMSConnectionFactory', 'J2CConnectionFactory'], ['qcf', 'QCF', 'Queue connection factories', 'Queue connection factory', 'jms.qcf', 'createSIBJMSConnectionFactory', 'J2CConnectionFactory'], ['tcf', 'TCF', 'Topic connection factories', 'Topic connection factory', 'jms.qcf', 'createSIBJMSConnectionFactory', 'J2CConnectionFactory']].forEach(function (d) {
    W.resType({
      id: 'jms' + d[0], coll: 'jms.cfs', list: function () { return W.S.jms.cfs.filter(function (c) { return c.kind === d[1]; }); }, add: function (o) { o.kind = d[1]; W.S.jms.cfs.push(o); }, refBase: 'jms.cfs',
      path: '/res/jms/' + d[0], title: d[2], singular: d[3], help: d[4], scoped: true, cfgType: 'J2CConnectionFactory',
      desc: d[0] === 'cf' ? 'A JMS connection factory is used to create connections to the associated JMS provider of JMS destinations, for both point-to-point and publish/subscribe messaging. (JMS 1.1 birleşik/unified connection factory.)' : d[0] === 'qcf' ? 'A JMS queue connection factory is used to create connections to the associated JMS provider of JMS queues, for point-to-point messaging.' : 'A JMS topic connection factory is used to create connections to the associated JMS provider of JMS topics, for publish/subscribe messaging.',
      cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'provider', l: 'Provider', fmt: function (r) { return r.provider === 'mq' ? 'WebSphere MQ messaging provider' : 'Default messaging provider'; } }, { k: 'description', l: 'Description' }],
      defaults: function (scope) { return { name: '', jndi: 'jms/', scope: scope, provider: 'default', kind: d[1], bus: 'BankingBus', targetType: 'BusMember', target: '', connectionProximity: 'Bus', maxConnections: 10, qmgr: '', host: '', port: 1414, channel: 'SYSTEM.DEF.SVRCONN', transport: 'CLIENT', alias: '', description: '' }; },
      form: cfForm,
      createCmd: function (o) { return o.provider === 'mq' ? ["AdminTask.createWMQConnectionFactory('" + W.cfgScope(o.scope) + "', '[-type " + (d[1] === 'CF' ? 'CF' : d[1]) + " -name " + o.name + " -jndiName " + o.jndi + " -qmgrName " + o.qmgr + " -wmqTransportType " + o.transport + " -qmgrHostname " + o.host + " -qmgrPortNumber " + o.port + " -qmgrSvrconnChannel " + o.channel + "]')", 'AdminConfig.save()'] : ["AdminTask." + d[5] + "(AdminConfig.getid('" + W.cfgScope(o.scope) + "'), '[-name " + o.name + " -jndiName " + o.jndi + " -busName " + o.bus + (d[1] === 'CF' ? '' : ' -type ' + (d[1] === 'QCF' ? 'queue' : 'topic')) + "]')", 'AdminConfig.save()']; }
    });
  });
  W.resType({
    id: 'jmsq', coll: 'jms.queues', path: '/res/jms/queues', title: 'Queues', singular: 'JMS queue', help: 'jms.queue', scoped: true, cfgType: 'J2CAdminObject',
    desc: 'A JMS queue is used as a destination for point-to-point messaging. Default messaging provider\'da JMS queue, bir SIBus <b>queue destination</b>\'ına işaret eden yönetilen nesnedir (administered object).',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'provider', l: 'Provider', fmt: function (r) { return r.provider === 'mq' ? 'WebSphere MQ messaging provider' : 'Default messaging provider'; } }, { k: 'queueName', l: 'Queue name' }, { k: 'description', l: 'Description' }],
    defaults: function (scope) { return { name: '', jndi: 'jms/', scope: scope, provider: 'default', bus: 'BankingBus', queueName: '', deliveryMode: 'Application', qmgr: '', description: '' }; },
    form: function (o, isNew) {
      return F.sel({ l: 'Messaging provider', n: 'provider', v: o.provider, o: [['default', 'Default messaging provider'], ['mq', 'WebSphere MQ messaging provider']], ro: !isNew, h: 'concept.jmsProvider' }) + F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'jms.queue' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
        F.grp('Connection', 'jms.queue', F.sel({ l: 'Bus name', n: 'bus', v: o.bus, o: W.S.sib.buses.map(function (b) { return b.name; }), h: 'concept.sib' }) + F.text({ l: 'Queue name (bus destination / MQ queue)', n: 'queueName', v: o.queueName, req: true, h: 'jms.queue' }) + F.text({ l: 'Queue manager (MQ)', n: 'qmgr', v: o.qmgr, h: 'jms.mq' })) +
        F.sel({ l: 'Delivery mode', n: 'deliveryMode', v: o.deliveryMode, o: ['Application', 'Persistent', 'NonPersistent'], h: 'jms.delivery' });
    },
    beforeCreate: function (o) {
      if (o.provider === 'default') {
        var bus = W.by(W.S.sib.buses, 'name', o.bus);
        if (bus && !W.by(bus.destinations, 'name', o.queueName)) { bus.destinations.push({ name: o.queueName, type: 'Queue', member: 'MessagingCluster', reliability: 'ASSURED_PERSISTENT', maxFailedDeliveries: 5, exception: '_SYSTEM.Exception.Destination.MessagingCluster.000-BankingBus', depth: 0 }); W.msg('info', 'Bus destination <b>' + esc(o.queueName) + '</b> (' + esc(o.bus) + ') otomatik olarak oluşturuldu ve MessagingCluster üzerine yerleştirildi.'); }
      }
    },
    canDelete: function (o) { var u = W.S.apps.filter(function (a) { return a.resourceRefs.some(function (r) { return r.target === o.jndi; }); }); if (u.length) return esc(o.name) + ' silinemedi: ' + u.map(function (a) { return esc(a.name); }).join(', ') + ' tarafından kullanılıyor.'; },
    createCmd: function (o) { return o.provider === 'mq' ? ["AdminTask.createWMQQueue('" + W.cfgScope(o.scope) + "', '[-name " + o.name + " -jndiName " + o.jndi + " -queueName " + o.queueName + " -qmgr " + o.qmgr + "]')", 'AdminConfig.save()'] : ["AdminTask.createSIBDestination('[-bus " + o.bus + " -name " + o.queueName + " -type Queue -cluster MessagingCluster]')", "AdminTask.createSIBJMSQueue(AdminConfig.getid('" + W.cfgScope(o.scope) + "'), '[-name " + o.name + " -jndiName " + o.jndi + " -queueName " + o.queueName + " -busName " + o.bus + " -deliveryMode " + o.deliveryMode + "]')", 'AdminConfig.save()']; }
  });
  W.resType({
    id: 'jmst', coll: 'jms.topics', path: '/res/jms/topics', title: 'Topics', singular: 'JMS topic', help: 'jms.topic', scoped: true, cfgType: 'J2CAdminObject',
    desc: 'A JMS topic is used as a destination for publish/subscribe messaging.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'topicSpace', l: 'Topic space' }, { k: 'topicName', l: 'Topic name' }],
    defaults: function (scope) { return { name: '', jndi: 'jms/', scope: scope, provider: 'default', bus: 'BankingBus', topicSpace: 'Default.Topic.Space', topicName: '', deliveryMode: 'Application', description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'jms.topic' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Topic name', n: 'topicName', v: o.topicName, req: true, h: 'jms.topic' }) + F.sel({ l: 'Bus name', n: 'bus', v: o.bus, o: W.S.sib.buses.map(function (b) { return b.name; }) }) + F.text({ l: 'Topic space', n: 'topicSpace', v: o.topicSpace, h: 'jms.topic' }) + F.sel({ l: 'Delivery mode', n: 'deliveryMode', v: o.deliveryMode, o: ['Application', 'Persistent', 'NonPersistent'], h: 'jms.delivery' }); },
    createCmd: function (o) { return ["AdminTask.createSIBJMSTopic(AdminConfig.getid('" + W.cfgScope(o.scope) + "'), '[-name " + o.name + " -jndiName " + o.jndi + " -topicName " + o.topicName + " -topicSpace " + o.topicSpace + " -busName " + o.bus + "]')", 'AdminConfig.save()']; }
  });
  W.resType({
    id: 'jmsas', coll: 'jms.aspecs', path: '/res/jms/as', title: 'Activation specifications', singular: 'Activation specification', help: 'jms.as', scoped: true, cfgType: 'J2CActivationSpec',
    desc: 'A JMS activation specification is associated with one or more message-driven beans (MDB) and provides the configuration necessary for them to receive messages.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'destJndi', l: 'Destination JNDI name' }, { k: 'maxConcurrency', l: 'Maximum concurrent MDB invocations per endpoint', h: 'jms.asConcurrency' }],
    defaults: function (scope) { return { name: '', jndi: 'jms/', scope: scope, provider: 'default', destJndi: 'jms/', destType: 'Queue', bus: 'BankingBus', maxConcurrency: 10, maxBatchSize: 1, ackMode: 'Auto-acknowledge', description: '' }; },
    form: function (o) {
      return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'jms.as' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Description', n: 'description', v: o.description }) +
        F.grp('Destination', 'jms.as', F.sel({ l: 'Destination type', n: 'destType', v: o.destType, o: ['Queue', 'Topic'] }) + F.text({ l: 'Destination JNDI name', n: 'destJndi', v: o.destJndi, req: true, h: 'jms.as' }) + F.sel({ l: 'Bus name', n: 'bus', v: o.bus, o: W.S.sib.buses.map(function (b) { return b.name; }) })) +
        F.grp('Additional', 'jms.asConcurrency', F.sel({ l: 'Acknowledge mode', n: 'ackMode', v: o.ackMode, o: ['Auto-acknowledge', 'Duplicates-ok auto-acknowledge'], h: 'jms.asConcurrency' }) + F.num({ l: 'Maximum batch size', n: 'maxBatchSize', v: o.maxBatchSize, h: 'jms.asConcurrency' }) + F.num({ l: 'Maximum concurrent MDB invocations per endpoint', n: 'maxConcurrency', v: o.maxConcurrency, h: 'jms.asConcurrency' }));
    },
    createCmd: function (o) { return ["AdminTask.createSIBJMSActivationSpec(AdminConfig.getid('" + W.cfgScope(o.scope) + "'), '[-name " + o.name + " -jndiName " + o.jndi + " -destinationJndiName " + o.destJndi + " -destinationType javax.jms." + o.destType + " -busName " + o.bus + " -maxConcurrency " + o.maxConcurrency + "]')", 'AdminConfig.save()']; }
  });

  /* ------------------------------------------------------- SIB buses */
  W.meActive = function () { return W.serverStatus('MsgSrv01') === 'started' ? 'MsgSrv01' : W.serverStatus('MsgSrv02') === 'started' ? 'MsgSrv02' : ''; };
  R('/sib/buses', function () {
    return { title: 'Buses', help: 'concept.sib', html: '<div class="page-title">Buses' + W.hi('concept.sib') + '</div><p class="desc">A service integration bus supports applications using message-based and service-oriented architectures. A bus is a group of interconnected servers and clusters that have been added as members of the bus.</p>' +
      W.table({ id: 'buses', rows: W.S.sib.buses, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/sib/buses/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'd', l: 'Description', fmt: function () { return 'Bankacılık JMS altyapısı'; } }, { k: 's', l: 'Security', fmt: function (r) { return r.secure ? 'Enabled' : 'Disabled'; }, h: 'sib.security' }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New bus' }, { l: 'Delete', act: 'notInSim', arg: 'Delete bus' }] }) };
  });
  R('/sib/buses/:name', function (p, q) {
    var b = W.by(W.S.sib.buses, 'name', p.name), base = '#/sib/buses/' + W.enc(b.name), act = W.meActive();
    var cr = function (x) { return W.crumbs([['Buses', '#/sib/buses'], [b.name, base]].concat(x)); };
    if (q.view === 'members') return { title: 'Buses', help: 'sib.member', html: cr(['Bus members']) + '<p class="desc">Bus member = mesajlaşma motoru barındıran server veya cluster.' + W.hi('sib.member') + '</p>' + W.table({ id: 'bm', select: false, rows: b.members.map(function (m) { return { id: m, m: m }; }), cols: [{ k: 'm', l: 'Name', fmt: function (r) { return 'Cluster=' + esc(r.m.split(':')[1]); } }, { k: 'me', l: 'Messaging engines', fmt: function () { return '1'; } }, { k: 'store', l: 'Message store type', fmt: function () { return 'Data store'; } }] }) };
    if (q.view === 'engines') return { title: 'Buses', help: 'sib.me', html: cr(['Messaging engines']) + '<p class="desc">Messaging engine (ME), bus üzerindeki mesajları saklayan ve iletilen bileşendir. Cluster bus member\'da varsayılan olarak tek ME bulunur ve HA Manager tarafından <b>bir anda yalnızca bir üyede</b> (One of N policy) aktif tutulur.' + W.hi('sib.me') + '</p>' +
      W.table({ id: 'me', select: false, rows: b.engines, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Name' }, { k: 'd', l: 'Description', fmt: function () { return ''; } }, { k: 'st', l: 'Status', fmt: function () { return act ? W.stIcon('started', 'Started on ' + act) : W.stIcon('stopped'); } }, { k: 'store', l: 'Message store', fmt: function (r) { return esc(r.store + ' – ' + r.ds + ' (schema ' + r.schema + ')'); }, h: 'sib.store' }] }) +
      '<div class="note-tr">MsgSrv01 durdurulursa ME, HA Manager tarafından birkaç saniye içinde MsgSrv02 üzerinde başlatılır (failover). Bunu <a href="#/clusters/MessagingCluster/members">MessagingCluster members</a> sayfasında MsgSrv01\'i durdurarak deneyebilirsiniz.</div>' };
    if (q.view === 'dest') return { title: 'Buses', help: 'sib.destination', html: cr(['Destinations']) + '<p class="desc">Bus destination\'ları; queue, topic space, alias, foreign ve exception destination türlerindedir. JMS queue/topic nesneleri bu destination\'lara işaret eder.' + W.hi('sib.destination') + '</p>' +
      W.table({ id: 'dst', rows: b.destinations, key: function (r) { return r.name; }, cols: [{ k: 'name', l: 'Identifier' }, { k: 'type', l: 'Type' }, { k: 'member', l: 'Bus member / queue point' }, { k: 'reliability', l: 'Default reliability', h: 'sib.reliability' }, { k: 'maxFailedDeliveries', l: 'Maximum failed deliveries', h: 'sib.exception' }, { k: 'depth', l: 'Current message depth', fmt: function (r) { return act ? r.depth : '-'; } }], buttons: [{ l: 'New...', act: 'notInSim', arg: 'New destination' }, { l: 'Delete', act: 'notInSim', arg: 'Delete destination' }] }) };
    return { title: 'Buses', help: 'concept.sib', html: cr([]) + W.cfgForm({ ref: 'sib.buses|' + b.name, doc: 'cells/' + CELL() + '/buses/' + b.name + '/sib-bus.xml', back: '#/sib/buses', title: 'Bus ' + b.name, general:
      F.ro({ l: 'Name', v: b.name }) + F.ro({ l: 'UUID', v: b.uuid }) + F.sel({ l: 'Inter-engine authentication alias', n: 'interEngineAuthAlias', v: b.interEngineAuthAlias, o: W.S.authAliases.map(function (a) { return a.id; }), h: 'sib.security' }) +
      F.num({ l: 'Default messaging engine high message threshold', n: 'highMessageThreshold', v: b.highMessageThreshold, h: 'sib.threshold' }) + F.ck({ l: 'Bus security', n: 'secure', v: b.secure, h: 'sib.security' }) + F.ck({ l: 'Discard messages after queue deletion', n: 'discardMsgsAfterQueueDeletion', v: b.discardMsgsAfterQueueDeletion }),
      ap: [{ t: 'Topology', items: [{ l: 'Bus members', href: base + '?view=members', h: 'sib.member' }, { l: 'Messaging engines', href: base + '?view=engines', h: 'sib.me' }] }, { t: 'Destination resources', items: [{ l: 'Destinations', href: base + '?view=dest', h: 'sib.destination' }] }, { t: 'Security', items: [{ l: 'Bus security', href: '#/sec/bus', h: 'sib.security' }] }] }) };
  });

  /* -------------------------------------------------- diğer kaynak tipleri */
  function aliasOpts() { return [['', '(none)']].concat(W.S.authAliases.map(function (a) { return [a.id, a.id]; })); }
  W.resType({ id: 'sched', coll: 'schedulers', path: '/res/schedulers', title: 'Schedulers', singular: 'Scheduler', help: 'res.scheduler', scoped: true, cfgType: 'SchedulerConfiguration',
    desc: 'Schedulers, kalıcı (persistent) ve cluster genelinde güvenilir zamanlanmış görevler (Task) çalıştırır. Görevler bir veritabanı tablosunda tutulur; böylece cluster\'daki bir üye çökse bile görev başka bir üyede çalışır.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'datasourceJNDIName', l: 'Data source JNDI name' }, { k: 'description', l: 'Description' }],
    defaults: function (s) { return { name: '', jndi: 'sched/', scope: s, datasourceJNDIName: 'jdbc/', datasourceAlias: '', tablePrefix: 'SCHED_', pollInterval: 30, workManagerInfoJNDIName: 'wm/default', useAdminRoles: false, description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.scheduler' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Description', n: 'description', v: o.description }) + F.text({ l: 'Data source JNDI name', n: 'datasourceJNDIName', v: o.datasourceJNDIName, h: 'res.scheduler' }) + F.sel({ l: 'Data source alias', n: 'datasourceAlias', v: o.datasourceAlias, o: aliasOpts(), h: 'sec.authAlias' }) + F.text({ l: 'Table prefix', n: 'tablePrefix', v: o.tablePrefix, h: 'res.scheduler' }) + F.num({ l: 'Poll interval', n: 'pollInterval', v: o.pollInterval, unit: 'seconds', h: 'res.scheduler' }) + F.text({ l: 'Work managers', n: 'workManagerInfoJNDIName', v: o.workManagerInfoJNDIName, h: 'res.workManager' }) + F.ck({ l: 'Use administration roles', n: 'useAdminRoles', v: o.useAdminRoles }); },
    createCmd: function (o) { return ["AdminTask.createSchedulerResource('[-name " + o.name + " -jndiName " + o.jndi + " -datasourceJNDIName " + o.datasourceJNDIName + " -tablePrefix " + o.tablePrefix + " -pollInterval " + o.pollInterval + " -workManagerInfoJNDIName " + o.workManagerInfoJNDIName + " -scope " + W.scopeLabel(o.scope) + "]')", 'AdminConfig.save()']; } });
  W.resType({ id: 'wm', coll: 'workManagers', path: '/res/wm', title: 'Work managers', singular: 'Work manager', help: 'res.workManager', scoped: true, cfgType: 'WorkManagerInfo',
    desc: 'Work manager, uygulamaların Java EE uyumlu şekilde paralel (asenkron) iş çalıştırması için yönetilen bir thread havuzu sağlar (asynchronous beans / CommonJ). WAS traditional\'da ayrı bir "work manager provider" nesnesi yoktur; work manager\'lar yerleşik sağlayıcı altında doğrudan bu sayfadan tanımlanır.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'maxThreads', l: 'Maximum number of threads' }, { k: 'description', l: 'Description' }],
    defaults: function (s) { return { name: '', jndi: 'wm/', scope: s, description: '', category: '', numAlarmThreads: 2, minThreads: 0, maxThreads: 2, threadPriority: 5, isGrowable: true, workTimeout: 0, workReqQSize: 0, workReqQFullAction: 0, serviceNames: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.workManager' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Description', n: 'description', v: o.description }) + F.text({ l: 'Category', n: 'category', v: o.category }) + F.text({ l: 'Service names (work context)', n: 'serviceNames', v: o.serviceNames, h: 'res.workManager' }) +
      F.grp('Thread pool properties', 'concept.threadPool', F.num({ l: 'Number of alarm threads', n: 'numAlarmThreads', v: o.numAlarmThreads }) + F.num({ l: 'Minimum number of threads', n: 'minThreads', v: o.minThreads }) + F.num({ l: 'Maximum number of threads', n: 'maxThreads', v: o.maxThreads, h: 'res.workManager' }) + F.num({ l: 'Thread priority', n: 'threadPriority', v: o.threadPriority }) + F.ck({ l: 'Growable', n: 'isGrowable', v: o.isGrowable, h: 'tp.growable' })) +
      F.grp('Work timeout and queue', 'res.workManager', F.num({ l: 'Work timeout', n: 'workTimeout', v: o.workTimeout, unit: 'milliseconds' }) + F.num({ l: 'Work request queue size', n: 'workReqQSize', v: o.workReqQSize }) + F.sel({ l: 'Work request queue full action', n: 'workReqQFullAction', v: o.workReqQFullAction, o: [[0, 'Block'], [1, 'Fail']] })); } });
  W.resType({ id: 'tm', coll: 'timerManagers', path: '/res/tm', title: 'Timer managers', singular: 'Timer manager', help: 'res.workManager', scoped: true, cfgType: 'TimerManagerInfo', desc: 'Timer manager, uygulamaların yönetilen ortamda zamanlayıcı (CommonJ Timer) kullanmasını sağlar.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'numAlarmThreads', l: 'Number of timer threads' }],
    defaults: function (s) { return { name: '', jndi: 'tm/', scope: s, numAlarmThreads: 2 }; }, form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.num({ l: 'Number of timer threads', n: 'numAlarmThreads', v: o.numAlarmThreads }); } });
  W.resType({ id: 'mailprov', coll: 'mailProviders', path: '/res/mailproviders', title: 'Mail providers', singular: 'Mail provider', help: 'res.mail', scoped: true, cfgType: 'MailProvider', desc: 'Mail provider, JavaMail protokol sağlayıcılarını (smtp, imap, pop3) gruplar. Built-in Mail Provider çoğu durumda yeterlidir.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description' }], defaults: function (s) { return { name: '', scope: s, description: '' }; }, form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.mail' }) + F.text({ l: 'Description', n: 'description', v: o.description }); } });
  W.resType({ id: 'mail', coll: 'mailSessions', path: '/res/mail', title: 'Mail sessions', singular: 'Mail session', help: 'res.mail', scoped: true, cfgType: 'MailSession',
    desc: 'A mail session is a resource collection of protocol providers that authenticate users and control user access to messaging systems.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'mailTransportHost', l: 'Mail transport host' }],
    defaults: function (s) { return { name: '', jndi: 'mail/', scope: s, provider: 'mp1', mailTransportHost: '', mailTransportPort: 25, mailTransportProtocol: 'smtp', mailFrom: '', mailStoreHost: '', mailStoreProtocol: 'imap', debug: false }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.mail' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.grp('Outgoing Mail Properties', 'res.mail', F.text({ l: 'Server', n: 'mailTransportHost', v: o.mailTransportHost }) + F.num({ l: 'Port', n: 'mailTransportPort', v: o.mailTransportPort }) + F.sel({ l: 'Protocol', n: 'mailTransportProtocol', v: o.mailTransportProtocol, o: ['smtp', 'smtps'] }) + F.text({ l: 'Return e-mail address', n: 'mailFrom', v: o.mailFrom })) + F.grp('Incoming Mail Properties', 'res.mail', F.text({ l: 'Server', n: 'mailStoreHost', v: o.mailStoreHost }) + F.sel({ l: 'Protocol', n: 'mailStoreProtocol', v: o.mailStoreProtocol, o: ['imap', 'imaps', 'pop3', 'pop3s'] })) + F.ck({ l: 'Enable debug mode', n: 'debug', v: o.debug }); } });
  W.resType({ id: 'urlprov', coll: 'urlProviders', path: '/res/urlproviders', title: 'URL providers', singular: 'URL provider', help: 'res.url', scoped: true, cfgType: 'URLProvider', desc: 'URL provider, belirli URL protokollerini (ör. özel bir protokol) destekleyen stream handler sınıflarını tanımlar. Default URL Provider http, https, ftp, file protokollerini JDK ile destekler.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'protocol', l: 'Protocol' }], defaults: function (s) { return { name: '', scope: s, streamHandler: '', protocol: '' }; }, form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.url' }) + F.text({ l: 'Stream handler class name', n: 'streamHandler', v: o.streamHandler }) + F.text({ l: 'Protocol', n: 'protocol', v: o.protocol }); } });
  W.resType({ id: 'url', coll: 'urls', path: '/res/urls', title: 'URLs', singular: 'URL', help: 'res.url', scoped: true, cfgType: 'URL', desc: 'URL kaynakları, uygulamaların harici adresleri kodda sabitlemeden JNDI üzerinden (<code>java.net.URL</code>) almasını sağlar. Ortamdan ortama değişen adresler için idealdir.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'spec', l: 'Specification' }], defaults: function (s) { return { name: '', jndi: 'url/', scope: s, provider: 'up1', spec: 'https://', description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.url' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.text({ l: 'Specification', n: 'spec', v: o.spec, req: true, h: 'res.url' }) + F.text({ l: 'Description', n: 'description', v: o.description }); } });
  W.resType({ id: 'ra', coll: 'resourceAdapters', path: '/res/ra', title: 'Resource adapters', singular: 'Resource adapter', help: 'res.ra', scoped: true, cfgType: 'J2CResourceAdapter',
    desc: 'A resource adapter is a system-level software driver that a Java application uses to connect to an enterprise information system (EIS). Resource adapter\'lar Java EE Connector Architecture (JCA) ile tanımlanır ve RAR dosyası olarak kurulur.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'archive', l: 'Archive path' }, { k: 'description', l: 'Description' }], buttons: [{ l: 'Install RAR', act: 'notInSim', arg: 'Install RAR' }],
    defaults: function (s) { return { name: '', scope: s, archive: '${CONNECTOR_INSTALL_ROOT}/', builtIn: false, description: '' }; }, form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.ra' }) + F.text({ l: 'Archive path', n: 'archive', v: o.archive, h: 'res.ra' }) + F.text({ l: 'Description', n: 'description', v: o.description }); } });
  W.resType({ id: 'j2ccf', coll: 'j2cCFs', path: '/res/j2ccf', title: 'J2C connection factories', singular: 'J2C connection factory', help: 'res.j2ccf', scoped: true, cfgType: 'J2CConnectionFactory',
    desc: 'J2C connection factory, bir resource adapter üzerinden EIS\'e (ör. CICS, SAP, IMS) bağlantı havuzu sağlar; JDBC data source\'un JCA karşılığıdır.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'ra', l: 'Resource adapter', fmt: function (r) { var x = W.by(W.S.resourceAdapters, 'id', r.ra); return x ? esc(x.name) : ''; } }],
    defaults: function (s) { return { name: '', jndi: 'eis/', scope: s, ra: 'ra4', alias: '', props: {}, pool: { maxConnections: 10, minConnections: 1, connectionTimeout: 180 } }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.j2ccf' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.sel({ l: 'Resource adapter', n: 'ra', v: o.ra, o: W.S.resourceAdapters.map(function (r) { return [r.id, r.name]; }), h: 'res.ra' }) + F.sel({ l: 'Component-managed authentication alias', n: 'alias', v: o.alias, o: aliasOpts(), h: 'sec.authAlias' }) + F.grp('Connection pool', 'concept.connectionPool', F.num({ l: 'Maximum connections', n: 'pool.maxConnections', v: o.pool.maxConnections, h: 'pool.max' }) + F.num({ l: 'Minimum connections', n: 'pool.minConnections', v: o.pool.minConnections, h: 'pool.min' }) + F.num({ l: 'Connection timeout', n: 'pool.connectionTimeout', v: o.pool.connectionTimeout, unit: 'seconds', h: 'pool.connTimeout' })); } });
  W.resType({ id: 'reprov', coll: 'resEnv.providers', path: '/res/reprov', title: 'Resource environment providers', singular: 'Resource environment provider', help: 'res.resenv', scoped: true, cfgType: 'ResourceEnvironmentProvider', desc: 'Resource environment provider, JNDI\'ye bağlanacak özel nesneler için factory/referenceable tanımlarını içerir.',
    cols: [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description' }], defaults: function (s) { return { name: '', scope: s, description: '' }; }, form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.resenv' }) + F.text({ l: 'Description', n: 'description', v: o.description }); } });
  W.resType({ id: 'reentries', coll: 'resEnv.entries', path: '/res/reentries', title: 'Resource environment entries', singular: 'Resource environment entry', help: 'res.resenv', scoped: true, cfgType: 'ResourceEnvEntry', desc: 'Resource environment entry, uygulamanın <code>&lt;resource-env-ref&gt;</code> ile aradığı nesneyi JNDI adına bağlar (ör. özellik bayrakları, yapılandırma nesneleri).',
    cols: [{ k: 'name', l: 'Name' }, { k: 'jndi', l: 'JNDI name' }, { k: 'referenceable', l: 'Referenceable' }], defaults: function (s) { return { name: '', jndi: 'resenv/', scope: s, provider: 'rep1', referenceable: '', description: '' }; },
    form: function (o) { return F.text({ l: 'Name', n: 'name', v: o.name, req: true, h: 'res.resenv' }) + F.text({ l: 'JNDI name', n: 'jndi', v: o.jndi, req: true, h: 'ds.jndi' }) + F.sel({ l: 'Provider', n: 'provider', v: o.provider, o: W.S.resEnv.providers.map(function (p) { return [p.id, p.name]; }) }) + F.text({ l: 'Referenceable', n: 'referenceable', v: o.referenceable, h: 'res.resenv' }) + F.text({ l: 'Description', n: 'description', v: o.description }); } });
})();
