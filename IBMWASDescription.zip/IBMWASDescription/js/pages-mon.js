/* pages-mon.js – Monitoring and Tuning (PMI, Tivoli Performance Viewer,
   request metrics, advisors) ve Troubleshooting (logs, trace, FFDC,
   configuration problems, class loader viewer). Grafikler saf SVG'dir. */
(function () {
  'use strict';
  var W = window.WAS, esc = W.esc, F = W.F, A = W.act, R = W.route;
  var CELL = function () { return W.S.cell.name; };

  /* ------------------------------------------------------------ metrics */
  W.metrics = {};
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function seedMetrics(s) {
    var m = { t: [], heap: [], cpu: [], wcActive: [], jdbcUse: [], jdbcWait: [], sess: [], rt: [], rps: [], gcPause: [], txCommit: [], txRollback: [], mem: [], hung: 0 };
    var heapMax = +s.jvm.maximumHeapSize || 256, base = heapMax * (s.kind === 'bank' ? 0.38 : 0.3), h = base;
    for (var i = 0; i < 40; i++) pushPoint(s, m, i === 0 ? null : m);
    W.metrics[s.name] = m;
    return m;
    function pushPoint() { stepMetrics(s, m, h); h = m.heap[m.heap.length - 1]; }
  }
  function cap(a) { while (a.length > 40) a.shift(); }
  function stepMetrics(s, m, lastHeap) {
    var up = W.serverStatus(s) === 'started', heapMax = +s.jvm.maximumHeapSize || 256;
    var wc = W.by(s.threadPools, 'name', 'WebContainer'), kindLoad = { bank: 1, portal: 0.7, msg: 0.35, batch: 0.5, std: 0.2 }[s.kind] || 0.3;
    var hour = new Date().getHours(), dayLoad = 0.55 + 0.45 * Math.sin((hour - 6) / 24 * Math.PI * 2 - 0.4) * 0.5 + 0.25;
    var load = up ? Math.max(0.05, kindLoad * dayLoad * rnd(0.8, 1.2)) : 0;
    var prev = m.heap.length ? m.heap[m.heap.length - 1] : (lastHeap || heapMax * 0.35);
    var nh = prev + heapMax * rnd(0.01, 0.05) * (0.4 + load), gc = 0;
    if (nh > heapMax * rnd(0.72, 0.86)) { nh = heapMax * rnd(0.28, 0.4); gc = Math.round(rnd(25, 90) * (heapMax / 1024)); }
    var ds = (W.S.dataSources.filter(function (d) { return W.visibleScopes(s).indexOf(d.scope) >= 0 && d.provider !== 'p5'; })[0]);
    var maxC = ds ? ds.pool.maxConnections : 10;
    var jdbc = Math.round(Math.min(maxC, maxC * load * rnd(0.35, 0.8)));
    var wait = jdbc >= maxC * 0.95 ? Math.round(rnd(1, 6)) : 0;
    var act = Math.round(Math.min(wc.maximumSize, wc.maximumSize * load * rnd(0.2, 0.55)));
    m.t.push(new Date().toLocaleTimeString('tr-TR'));
    m.heap.push(up ? Math.round(nh) : 0); m.gcPause.push(up ? gc : 0);
    m.cpu.push(up ? Math.round(Math.min(98, 6 + 55 * load * rnd(0.7, 1.3))) : 0);
    m.wcActive.push(up ? act : 0); m.jdbcUse.push(up ? jdbc : 0); m.jdbcWait.push(up ? wait : 0);
    var ls = m.sess.length ? m.sess[m.sess.length - 1] : Math.round(800 * kindLoad);
    m.sess.push(up && s.kind !== 'msg' ? Math.max(0, Math.round(ls + rnd(-40, 46) * kindLoad)) : 0);
    m.rt.push(up ? Math.round(rnd(60, 140) * (1 + (wait ? 2.5 : 0) + load * 0.6)) : 0);
    m.rps.push(up ? Math.round(rnd(30, 60) * load * 4) : 0);
    m.txCommit.push(up ? Math.round(rnd(20, 50) * load * 3) : 0); m.txRollback.push(up ? Math.round(rnd(0, 3) * load) : 0);
    m.mem.push(up ? Math.round(heapMax * 1.35 + rnd(-30, 30)) : 0);
    ['t', 'heap', 'gcPause', 'cpu', 'wcActive', 'jdbcUse', 'jdbcWait', 'sess', 'rt', 'rps', 'txCommit', 'txRollback', 'mem'].forEach(function (k) { cap(m[k]); });
  }
  W.getMetrics = function (s) { return W.metrics[s.name] || seedMetrics(s); };

  /* SVG line chart */
  W.lineChart = function (title, series, opts) {
    opts = opts || {};
    var w = 360, h = 150, pl = 40, pr = 8, pt = 10, pb = 20, n = series[0].data.length;
    var max = opts.max || Math.max.apply(null, [1].concat(series.map(function (s) { return Math.max.apply(null, s.data); }))) * 1.15;
    var x = function (i) { return pl + (w - pl - pr) * i / Math.max(1, n - 1); }, y = function (v) { return pt + (h - pt - pb) * (1 - v / max); };
    var g = '';
    for (var k = 0; k <= 4; k++) { var vv = max * k / 4; g += '<line x1="' + pl + '" x2="' + (w - pr) + '" y1="' + y(vv) + '" y2="' + y(vv) + '" stroke="#e3e8f1"/><text x="' + (pl - 4) + '" y="' + (y(vv) + 3) + '" font-size="9" text-anchor="end" fill="#667">' + fmtAxis(vv) + '</text>'; }
    if (opts.limit) g += '<line x1="' + pl + '" x2="' + (w - pr) + '" y1="' + y(opts.limit) + '" y2="' + y(opts.limit) + '" stroke="#d84a3a" stroke-dasharray="4 3"/><text x="' + (w - pr) + '" y="' + (y(opts.limit) - 3) + '" font-size="9" text-anchor="end" fill="#d84a3a">' + esc(opts.limitLabel || 'max') + '</text>';
    var paths = series.map(function (s) {
      var d = s.data.map(function (v, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1); }).join(' ');
      var area = s.fill ? '<path d="' + d + ' L' + x(n - 1) + ' ' + y(0) + ' L' + x(0) + ' ' + y(0) + 'Z" fill="' + s.color + '" opacity=".12"/>' : '';
      return area + '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="1.8" stroke-linejoin="round"/>';
    }).join('');
    var last = series.map(function (s) { return s.data[n - 1]; });
    return '<div class="chart"><div class="ct"><span class="inline-flex">' + esc(title) + (opts.h ? W.hi(opts.h) : '') + '</span><span class="cv">' + series.map(function (s, i) { return esc(String(last[i])) + (opts.unit ? ' ' + opts.unit : ''); }).join(' / ') + '</span></div>' +
      '<svg viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(title) + '">' + g + paths + '<text x="' + pl + '" y="' + (h - 5) + '" font-size="9" fill="#667">-' + Math.round(n * 3) + ' sn</text><text x="' + (w - pr) + '" y="' + (h - 5) + '" font-size="9" fill="#667" text-anchor="end">şimdi</text></svg>' +
      '<div class="lg">' + series.map(function (s) { return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>'; }).join('') + '</div></div>';
  };
  function fmtAxis(v) { return v >= 1000 ? (v / 1000).toFixed(1) + 'k' : v >= 10 ? Math.round(v) : v.toFixed(1); }

  /* ------------------------------------------------------- TPV / current activity */
  R('/mon/tpv', function (p, q) {
    var s = W.srv(q.server || W.UI.tpvSrv || 'BankSrv01') || W.S.servers[0];
    W.UI.tpvSrv = s.name;
    var m = W.getMetrics(s), up = W.serverStatus(s) === 'started';
    var html = '<div class="page-title">Tivoli Performance Viewer – Current activity' + W.hi('mon.tpv') + '</div><p class="desc">Tivoli Performance Viewer (TPV), PMI tarafından toplanan performans sayaçlarını gerçek zamanlı gösterir. Aşağıdaki değerler simülasyondur ve her 3 saniyede güncellenir.</p>' +
      '<div class="scopebox"><span class="inline-flex" style="gap:8px;flex-wrap:wrap">Sunucu: <select data-change="tpvSrv">' + W.S.servers.map(function (x) { return '<option' + (x.name === s.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select> ' + W.stIcon(W.serverStatus(s)) + ' &nbsp; PMI statistic set: <b>' + esc(s.pmi.statisticSet) + '</b>' + W.hi('mon.statset') + ' &nbsp; <a href="#/mon/pmi/' + W.enc(s.name) + '">PMI ayarları</a> · <a href="#/mon/advisors">Advisor önerileri</a></span></div>' +
      (up ? '' : '<div class="msgbox err">Sunucu çalışmıyor; PMI verisi alınamıyor.</div>') + '<div id="tpvBody">' + tpvBody(s, m) + '</div>';
    return { title: 'Current activity', help: 'mon.tpv', html: html, onMount: function () {
      var iv = setInterval(function () {
        W.S.servers.forEach(function (x) { if (W.metrics[x.name]) stepMetrics(x, W.metrics[x.name]); });
        var b = document.getElementById('tpvBody'); if (b) b.innerHTML = tpvBody(s, W.getMetrics(s));
      }, 3000);
      W.onLeave.push(function () { clearInterval(iv); });
    } };
  });
  W.onChange.tpvSrv = function (e) { location.hash = '#/mon/tpv?server=' + W.enc(e.value); };
  function last(a) { return a[a.length - 1]; }
  function avg(a) { return Math.round(a.reduce(function (x, y) { return x + y; }, 0) / a.length); }
  function tpvBody(s, m) {
    var heapMax = +s.jvm.maximumHeapSize, wc = W.by(s.threadPools, 'name', 'WebContainer');
    var ds = W.S.dataSources.filter(function (d) { return W.visibleScopes(s).indexOf(d.scope) >= 0 && d.provider !== 'p5'; })[0];
    var maxC = ds ? ds.pool.maxConnections : 10;
    var kpis = '<div class="kpis">' +
      kpi('JVM heap kullanımı', last(m.heap) + ' / ' + heapMax + ' MB', Math.round(last(m.heap) / heapMax * 100) + '% kullanımda', 'mon.heap') +
      kpi('Process CPU', last(m.cpu) + ' %', 'ort. ' + avg(m.cpu) + ' %', 'mon.cpu') +
      kpi('WebContainer aktif thread', last(m.wcActive) + ' / ' + wc.maximumSize, 'Hung thread: ' + (s.kind === 'bank' && s.name === 'BankSrv02' ? 1 : 0), 'mon.threads') +
      kpi('JDBC pool (' + (ds ? ds.name : '-') + ')', last(m.jdbcUse) + ' / ' + maxC, 'Bekleyen thread: ' + last(m.jdbcWait), 'mon.jdbc') +
      kpi('HTTP session (LiveCount)', last(m.sess), 'Timeout ' + s.session.invalidationTimeout + ' dk', 'mon.sessions') +
      kpi('Ortalama yanıt süresi', last(m.rt) + ' ms', last(m.rps) + ' istek/sn', 'mon.responseTime') + '</div>';
    var charts = '<div class="charts">' +
      W.lineChart('JVM Heap Usage (MB)', [{ name: 'UsedMemory', data: m.heap, color: '#2f63b5', fill: true }], { max: heapMax * 1.05, limit: heapMax, limitLabel: 'Max heap ' + heapMax, h: 'mon.heap' }) +
      W.lineChart('Garbage Collection pause (ms)', [{ name: 'GC duraklama süresi', data: m.gcPause, color: '#8e44ad' }], { h: 'mon.gc', unit: 'ms' }) +
      W.lineChart('Thread Pool Usage – WebContainer', [{ name: 'ActiveCount', data: m.wcActive, color: '#16a085', fill: true }], { max: wc.maximumSize * 1.1, limit: wc.maximumSize, limitLabel: 'MaximumSize ' + wc.maximumSize, h: 'mon.threads' }) +
      W.lineChart('JDBC Connection Pool', [{ name: 'Kullanımdaki bağlantılar', data: m.jdbcUse, color: '#e67e22', fill: true }, { name: 'WaitingThreadCount', data: m.jdbcWait, color: '#c0392b' }], { max: maxC * 1.1, limit: maxC, limitLabel: 'MaxConnections ' + maxC, h: 'mon.jdbc' }) +
      W.lineChart('HTTP Session Statistics (LiveCount)', [{ name: 'Canlı session', data: m.sess, color: '#2980b9', fill: true }], { h: 'mon.sessions' }) +
      W.lineChart('Request Metrics – Response time (ms)', [{ name: 'ServiceTime', data: m.rt, color: '#d35400' }], { h: 'mon.responseTime', unit: 'ms' }) +
      W.lineChart('Transaction Statistics (/interval)', [{ name: 'Committed', data: m.txCommit, color: '#27ae60' }, { name: 'Rolled back', data: m.txRollback, color: '#c0392b' }], { h: 'mon.tx' }) +
      W.lineChart('CPU Usage (%)', [{ name: 'ProcessCpuUsage', data: m.cpu, color: '#7f8c8d', fill: true }], { max: 100, h: 'mon.cpu', unit: '%' }) +
      W.lineChart('Process Memory (MB, heap + native)', [{ name: 'Resident memory', data: m.mem, color: '#34495e' }], { h: 'mon.memory' }) + '</div>';
    var counters = W.simpleTable([['Module / Counter', 'mon.counters'], 'Value', 'Unit', 'Statistic set'], [
      ['JVM Runtime › HeapSize', heapMax * 1024, 'KILOBYTE', 'basic'], ['JVM Runtime › UsedMemory', last(m.heap) * 1024, 'KILOBYTE', 'basic'], ['JVM Runtime › ProcessCpuUsage', last(m.cpu), 'PERCENT', 'basic'], ['JVM Runtime › GCCount', 1840 + m.gcPause.filter(Boolean).length, 'N/A', 'extended'], ['JVM Runtime › GCTime', avg(m.gcPause.filter(Boolean).concat([0])), 'MILLISECOND', 'extended'],
      ['Thread Pools › WebContainer › ActiveCount', last(m.wcActive), 'N/A', 'basic'], ['Thread Pools › WebContainer › PoolSize', wc.maximumSize, 'N/A', 'basic'], ['Thread Pools › WebContainer › ConcurrentHungThreadCount', s.name === 'BankSrv02' ? 1 : 0, 'N/A', 'extended'],
      ['JDBC Connection Pools › ' + (ds ? ds.jndi : '-') + ' › PoolSize', maxC, 'N/A', 'basic'], ['JDBC › FreePoolSize', maxC - last(m.jdbcUse), 'N/A', 'basic'], ['JDBC › PercentUsed', Math.round(last(m.jdbcUse) / maxC * 100), 'PERCENT', 'basic'], ['JDBC › WaitingThreadCount', last(m.jdbcWait), 'N/A', 'basic'], ['JDBC › WaitTime', last(m.jdbcWait) ? Math.round(rnd(200, 1800)) : 0, 'MILLISECOND', 'basic'], ['JDBC › UseTime', Math.round(rnd(8, 60)), 'MILLISECOND', 'basic'],
      ['Servlet Session Manager › LiveCount', last(m.sess), 'N/A', 'basic'], ['Servlet Session Manager › ActiveCount', Math.round(last(m.sess) * 0.08), 'N/A', 'basic'], ['Servlet Session Manager › SessionObjectSize', s.pmi.statisticSet === 'all' ? Math.round(rnd(3000, 9000)) : 'Statistic set "all" gerektirir', 'BYTE', 'all'],
      ['Web Applications › RequestCount', 152340 + last(m.rps) * 3, 'N/A', 'basic'], ['Web Applications › ServiceTime', last(m.rt), 'MILLISECOND', 'basic'], ['Web Applications › ErrorCount', 37, 'N/A', 'basic'],
      ['Transaction Manager › CommittedCount', 88210 + last(m.txCommit), 'N/A', 'basic'], ['Transaction Manager › RolledbackCount', 142, 'N/A', 'basic'], ['Transaction Manager › GlobalTranTime', Math.round(rnd(20, 120)), 'MILLISECOND', 'basic']
    ].map(function (r) { return [esc(r[0]), esc(String(r[1])), esc(r[2]), esc(r[3])]; }));
    return kpis + charts + '<div class="sect-title" style="margin-top:14px">Performance counters (PMI)' + W.hi('mon.counters') + '</div>' + counters;
    function kpi(l, v, s2, h) { return '<div class="kpi"><div class="kl">' + esc(l) + W.hi(h) + '</div><div class="kv">' + esc(v) + '</div><div class="ks">' + esc(s2) + '</div></div>'; }
  }

  /* --------------------------------------------------------------- PMI */
  R('/mon/pmi', function () {
    return { title: 'Performance Monitoring Infrastructure (PMI)', help: 'concept.pmi', html: '<div class="page-title">Performance Monitoring Infrastructure (PMI)' + W.hi('concept.pmi') + '</div><p class="desc">Use this page to configure Performance Monitoring Infrastructure (PMI) for each server.</p>' +
      W.table({ id: 'pmi', rows: W.S.servers, key: function (r) { return r.name; }, select: false, cols: [{ k: 'name', l: 'Name', fmt: function (r) { return '<a href="#/mon/pmi/' + W.enc(r.name) + '">' + esc(r.name) + '</a>'; } }, { k: 'node', l: 'Node' }, { k: 'pmi', l: 'Statistic set', sv: function (r) { return r.pmi.statisticSet; }, fmt: function (r) { return esc(r.pmi.enable ? r.pmi.statisticSet : 'disabled'); }, h: 'mon.statset' }, { k: 'v', l: 'Version', fmt: function () { return esc(W.S.cell.version); } }] }) };
  });
  R('/mon/pmi/:name', function (p, q) {
    var s = W.srv(p.name), b = '#/mon/pmi/' + W.enc(s.name), tabs = [['Runtime', b + '?tab=runtime', q.tab === 'runtime'], ['Configuration', b, q.tab !== 'runtime']];
    var mods = ['Dynamic Caching', 'Enterprise Beans', 'JDBC Connection Pools', 'J2C Connection Pools', 'JVM Runtime', 'ORB', 'Servlet Session Manager', 'SIB Service', 'System Data', 'Thread Pools', 'Transaction Manager', 'Web Applications', 'Workload Management'];
    var custom = s.pmi.statisticSet === 'custom' ? '<fieldset class="grp"><legend>Custom statistic set – modules' + W.hi('mon.statset') + '</legend><div class="tree"><ul>' + mods.map(function (m) { return '<li><label><input type="checkbox"' + (/JDBC|JVM|Thread|Servlet|Web App|Transaction/.test(m) ? ' checked' : '') + '> ' + esc(m) + '</label></li>'; }).join('') + '</ul></div></fieldset>' : '';
    return { title: 'Performance Monitoring Infrastructure (PMI)', help: 'concept.pmi', html: W.crumbs([['Performance Monitoring Infrastructure (PMI)', '#/mon/pmi'], s.name]) + '<p class="desc">' + (q.tab === 'runtime' ? 'Runtime sekmesindeki değişiklik <b>hemen</b> etkili olur ancak sunucu yeniden başlatıldığında kaybolur.' : 'Configuration sekmesindeki değişiklik kaydedilip sunucu yeniden başlatıldığında etkili olur.') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|pmi', doc: 'cells/' + CELL() + '/nodes/' + s.node + '/servers/' + s.name + '/server.xml', back: '#/mon/pmi', title: 'PMI ' + s.name, tabs: tabs, general:
        F.ck({ l: 'Enable Performance Monitoring Infrastructure (PMI)', n: 'enable', v: s.pmi.enable, h: 'concept.pmi' }) + F.ck({ l: 'Use sequential counter updates', n: 'synchronizedUpdate', v: s.pmi.synchronizedUpdate, h: 'mon.sequential' }) +
        F.radio({ l: 'Currently monitored statistic set', n: 'statisticSet', v: s.pmi.statisticSet, h: 'mon.statset', o: [['none', 'None – No statistics are enabled'], ['basic', 'Basic – Java EE components, CPU usage, HTTP session information'], ['extended', 'Extended – Basic + WLM, Dynamic cache'], ['all', 'All – All statistics are enabled'], ['custom', 'Custom – Enable or disable statistics selectively']] }) + custom,
        ap: [{ t: 'Related Items', items: [{ l: 'Current activity (TPV)', href: '#/mon/tpv?server=' + W.enc(s.name), h: 'mon.tpv' }, { l: 'Custom properties', href: W.propsLink('servers|' + s.name + '|pmi', 'customProps', 'PMI', b), h: 'concept.customProps' }] }] }) };
  });
  R('/mon/rm', function () {
    var r = W.S.requestMetrics;
    return { title: 'Request metrics', help: 'mon.rm', html: '<div class="page-title">Request metrics' + W.hi('mon.rm') + '</div><p class="desc">Request metrics, tek bir isteğin web server plug-in → web container → EJB → JDBC boyunca harcadığı süreyi (hop bazında) izler. Ayarlar <b>hücre seviyesindedir</b>; değişiklikten sonra plug-in yapılandırması da yeniden üretilmelidir (plugin-cfg.xml içindeki &lt;RequestMetrics&gt; öğesi).</p>' +
      W.cfgForm({ ref: 'requestMetrics', doc: 'cells/' + CELL() + '/pmirm.xml', back: '#/mon/rm', title: 'Request metrics', general:
        F.ck({ l: 'Prepare Servers for Request metrics collection', n: 'enable', v: r.enable, h: 'mon.rm' }) +
        F.radio({ l: 'Components to be instrumented', n: 'components', v: r.components, o: [['ALL', 'All'], ['NONE', 'None'], ['CUSTOM', 'Custom (Servlet, EJB, JDBC, JMS, Web services...)']], h: 'mon.rm' }) +
        F.sel({ l: 'Trace level', n: 'traceLevel', v: r.traceLevel, o: [['NONE', 'None'], ['HOPS', 'Hops'], ['PERF_DEBUG', 'Performance_debug'], ['DEBUG', 'Debug']], h: 'mon.rmTrace' }) +
        F.grp('Request metrics destination', 'mon.rm', F.ck({ l: 'Standard logs', n: 'standardLogs', v: r.standardLogs, h: 'mon.rm' }) + F.ck({ l: 'Application Response Measurement (ARM) agent', n: 'arm', v: r.arm, h: 'mon.rm' }) + F.sel({ l: 'Specify ARM agent type', n: 'armType', v: r.armType, o: ['ARM40', 'TIVOLI_ARM'] })) +
        F.grp('Filters', 'mon.rm', F.text({ l: 'Source IP filter', n: 'filtersSourceIP', v: r.filtersSourceIP }) + F.text({ l: 'URI filter', n: 'filtersURI', v: r.filtersURI })) }) +
      '<div class="sect-title" style="margin-top:12px">Örnek SystemOut.log çıktısı (trace level = Hops)</div><pre class="log">' + W.colorLog('[11/23/26 10:21:44:512 TRT] 00000083 PmiRmArmWrapp I   PMRM0003I:  parent:ver=1,ip=10.20.1.21,time=1763881304120,pid=3412,reqid=6881,event=1 - current:ver=1,ip=10.20.1.11,time=1763881304201,pid=41337,reqid=6881,event=1 type=URI detail=/corebank/accounts/summary elapsed=243\n[11/23/26 10:21:44:509 TRT] 00000083 PmiRmArmWrapp I   PMRM0003I:  parent:ver=1,ip=10.20.1.11,time=1763881304201,pid=41337,reqid=6881,event=1 - current:ver=1,ip=10.20.1.11,time=1763881304201,pid=41337,reqid=6882,event=1 type=JDBC detail=java.sql.PreparedStatement.executeQuery() elapsed=188') + '</pre><p class="note-tr">Yorum: Toplam 243 ms\'nin 188 ms\'si JDBC sorgusunda geçmiş → darboğaz veritabanı tarafında.</p>' };
  });
  R('/mon/advisors', function () {
    W.S.pda = W.S.pda || { enable: true, interval: 4, maxSeq: 1, cpus: 8 };
    var tips = [];
    W.S.servers.forEach(function (s) {
      if (W.serverStatus(s) !== 'started') return;
      var m = W.getMetrics(s), wc = W.by(s.threadPools, 'name', 'WebContainer');
      if (Math.max.apply(null, m.jdbcWait) > 0) tips.push([s.name, 'JDBC connection pool doygun: bağlantı bekleyen thread\'ler görüldü. Maximum connections değerini artırmayı veya SQL sürelerini incelemeyi değerlendirin.', 'concept.connectionPool']);
      if (Math.max.apply(null, m.wcActive) >= wc.maximumSize * 0.9) tips.push([s.name, 'WebContainer thread pool %90 üzerinde kullanılıyor.', 'concept.threadPool']);
      if (s.jvm.verboseModeGarbageCollection === false && s.kind === 'bank') tips.push([s.name, 'Verbose GC kapalı; bellek sorunlarının analizi için açılması önerilir.', 'jvm.verboseGC']);
      if (+s.jvm.initialHeapSize < +s.jvm.maximumHeapSize / 4) tips.push([s.name, 'Initial heap, maximum heap\'e göre çok küçük; başlangıçta sık heap genişlemesi ve GC olabilir.', 'jvm.initialHeap']);
    });
    if (!tips.length) tips.push(['-', 'Şu anda öneri yok.', 'mon.advisor']);
    return { title: 'Performance and Diagnostic Advisor Configuration', help: 'mon.advisor', html: '<div class="page-title">Performance and Diagnostic Advisor Configuration' + W.hi('mon.advisor') + '</div><p class="desc">Performance and Diagnostic Advisor (PDA), PMI verilerini periyodik olarak analiz eder ve SystemOut.log\'a ayarlama önerileri yazar.</p>' +
      W.cfgForm({ ref: 'pda', back: '#/mon/advisors', title: 'PDA', doc: 'cells/' + CELL() + '/pmi', general: F.ck({ l: 'Enable Performance and Diagnostic Advisor Framework', n: 'enable', v: W.S.pda.enable, h: 'mon.advisor' }) + F.num({ l: 'Calculation interval', n: 'interval', v: W.S.pda.interval, unit: 'minutes' }) + F.num({ l: 'Maximum warning sequence', n: 'maxSeq', v: W.S.pda.maxSeq }) + F.num({ l: 'Number of processors', n: 'cpus', v: W.S.pda.cpus }) }) +
      '<div class="sect-title" style="margin-top:12px">Güncel öneriler (simülasyon PMI verisinden)</div>' + W.simpleTable(['Server', 'Öneri', ''], tips.map(function (t) { return [esc(t[0]), esc(t[1]), W.hi(t[2])]; })) };
  });

  /* -------------------------------------------------------------- logs */
  function ts(d) { d = d || new Date(); var p = function (n, l) { return ('000' + n).slice(-(l || 2)); }; return '[' + (d.getMonth() + 1) + '/' + d.getDate() + '/' + String(d.getFullYear()).slice(2) + ' ' + d.getHours() + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + ':' + p(d.getMilliseconds(), 3) + ' TRT]'; }
  function at(min) { var d = new Date(); d.setMinutes(d.getMinutes() - min); d.setMilliseconds(Math.floor(Math.random() * 999)); return ts(d); }
  W.logs = {
    env: function (s) {
      var n = W.node(s.node), pid = W.RT.pids[s.name] || 41337;
      return '************ Start Display Current Environment ************\nWebSphere Platform ' + W.S.cell.version.replace('ND ', '') + ' [ND ' + W.S.cell.version.replace('ND ', '') + ' ' + W.S.cell.build + ']  running with process name ' + CELL() + '\\' + s.node + '\\' + s.name + ' and process id ' + pid + '\nFull host name: ' + n.host + '(10.20.1.' + (10 + W.S.nodes.indexOf(n)) + ')\nDetailed IFix information: ID: 9.0.5-WS-WASProd-IFPH55123  BuildVrsn: null  Desc: Security fix\nHost Operating System is Linux, version 4.18.0-477.27.1.el8_8.x86_64\nJava version = 1.8.0_381, Java Runtime Version = 8.0.8.10 - pxa6480sr8fp10-20230707_01(SR8 FP10), Java Compiler = j9jit29, Java VM name = IBM J9 VM\nwas.install.root = /opt/IBM/WebSphere/AppServer\nuser.install.root = /opt/IBM/WebSphere/AppServer/profiles/AppSrv01\nJava Home = /opt/IBM/WebSphere/AppServer/java/8.0/jre\nws.ext.dirs = /opt/IBM/WebSphere/AppServer/java/8.0/lib:/opt/IBM/WebSphere/AppServer/classes:/opt/IBM/WebSphere/AppServer/lib:/opt/IBM/WebSphere/AppServer/installedChannels:/opt/IBM/WebSphere/AppServer/lib/ext\nClasspath = /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/properties:/opt/IBM/WebSphere/AppServer/properties:/opt/IBM/WebSphere/AppServer/lib/startup.jar:/opt/IBM/WebSphere/AppServer/lib/bootstrap.jar:/opt/IBM/WebSphere/AppServer/lib/jsf-nls.jar:/opt/IBM/WebSphere/AppServer/lib/lmproxy.jar:/opt/IBM/WebSphere/AppServer/lib/urlprotocols.jar:/opt/IBM/WebSphere/AppServer/deploytool/itp/batchboot.jar:/opt/IBM/WebSphere/AppServer/deploytool/itp/batch2.jar:/opt/IBM/WebSphere/AppServer/java/8.0/lib/tools.jar\nJava Library path = /opt/IBM/WebSphere/AppServer/lib/native/linux/x86_64/:/opt/IBM/WebSphere/AppServer/java/8.0/jre/lib/amd64/compressedrefs\nOrb Version = IBM Java ORB build orb80-20230615.00\nCurrent trace specification = ' + s.trace.startupTraceSpecification + '\n************* End Display Current Environment *************\n';
    },
    systemOut: function (s) {
      var L = [], st = W.serverStatus(s), apps = W.appsOnServer(s);
      var add = function (min, thr, comp, lvl, msg) { L.push(at(min) + ' ' + thr + ' ' + (comp + '             ').slice(0, 13) + ' ' + lvl + '   ' + msg); };
      var T0 = 180;
      add(T0, '00000001', 'ManagerAdmin', 'I', 'TRAS0017I: The startup trace state is ' + s.trace.startupTraceSpecification + '.');
      add(T0, '00000001', 'ManagerAdmin', 'I', 'TRAS0111I: The message IDs that are in use are deprecated');
      add(T0, '00000001', 'ModelMgr', 'I', 'WSVR0800I: Initializing core configuration models');
      add(T0, '00000001', 'ComponentMeta', 'I', 'WSVR0179I: The runtime provisioning feature is ' + (s.provisionComponents ? 'enabled' : 'disabled. All components will be started') + '.');
      add(T0, '00000001', 'AdminInitiali', 'A', 'ADMN0015I: The administration service is initialized.');
      add(T0, '00000001', 'SystemOut', 'O', 'PLGC0057I: Plug-in configuration file generation is not supported on managed server process; DMGR generates plugin-cfg.xml.');
      add(T0, '00000001', 'PMIImpl', 'A', 'PMON1001I: PMI is enabled');
      add(T0, '00000001', 'SibMessage', 'I', '[:] CWSIU0000I: Release: WAS90.SIB Level: ' + W.S.cell.build);
      add(T0, '00000001', 'SecurityDM', 'I', 'SECJ0231I: The Security component\'s FFDC Diagnostic Module com.ibm.ws.security.core.SecurityDM registered successfully: true.');
      add(T0, '00000001', 'AuditService', 'I', 'SECJ6004I: Security Auditing is disabled.');
      add(T0, '00000001', 'distSecurity', 'I', 'SECJ0309I: Java 2 Security is disabled.');
      add(T0, '00000001', 'Configuratio', 'A', 'SECJ0215I: Successfully set JAAS login provider configuration class to com.ibm.ws.security.auth.login.Configuration.');
      add(T0, '00000001', 'SecurityCompo', 'I', 'SECJ0242I: Security service is starting');
      add(T0, '00000001', 'distContextMa', 'I', 'SECJ0240I: Security service initialization completed successfully');
      add(T0, '00000001', 'DCSPluginSing', 'I', 'HMGR0005I: The Single Server DCS Core Stack transport has been started for core group DefaultCoreGroup.');
      add(T0, '00000001', 'NameServerImp', 'A', 'NMSV0018I: Name server available on bootstrap port ' + s.ports.BOOTSTRAP_ADDRESS + '.');
      add(T0, '00000001', 'JMXSoapAdapte', 'A', 'ADMC0013I: The SOAP connector is available at port ' + s.ports.SOAP_CONNECTOR_ADDRESS);
      add(T0, '00000001', 'JMXConnectors', 'I', 'ADMC0026I: The RMI Connector is available at port ' + s.ports.BOOTSTRAP_ADDRESS);
      if (s.cluster === 'MessagingCluster') add(T0, '00000047', 'SibMessage', 'I', '[BankingBus:MessagingCluster.000-BankingBus] CWSID0016I: Messaging engine MessagingCluster.000-BankingBus is in state ' + (W.meActive() === s.name ? 'Started' : 'Joined') + '.');
      if (s.session.sessionPersistenceMode === 'DATA_REPLICATION') add(T0, '00000052', 'DRSCacheApp', 'I', 'DRSW0001I: DRS: Data Replication Service is starting for replication domain ' + s.session.replicationDomain + ' (mode=' + s.session.replicationMode + ').');
      apps.forEach(function (a) {
        add(T0 - 1, '0000004f', 'ApplicationMg', 'A', 'WSVR0200I: Starting application: ' + a.name);
        add(T0 - 1, '0000004f', 'ApplicationMg', 'A', 'WSVR0204I: Application: ' + a.name + '  Application build level: ' + a.version);
        a.modules.forEach(function (m) {
          if (m.type === 'web') {
            add(T0 - 1, '0000004f', 'webapp', 'I', 'com.ibm.ws.webcontainer.webapp.WebGroupImpl WebGroup SRVE0169I: Loading Web Module: ' + m.name + '.');
            add(T0 - 1, '0000004f', 'WASSessionCor', 'I', 'SessionContextRegistry getSessionContext SESN0176I: Will create a new session context for application key ' + m.vhost + m.contextRoot);
            var vh = W.by(W.S.virtualHosts, 'name', m.vhost);
            add(T0 - 1, '0000004f', 'webcontainer', 'I', 'com.ibm.ws.webcontainer.VirtualHostImpl addWebApplication SRVE0250I: Web Module ' + m.name + ' has been bound to ' + m.vhost + '[' + (vh ? vh.aliases.slice(0, 6).map(function (x) { return x[0] + ':' + x[1]; }).join(',') : '') + '].');
          } else add(T0 - 1, '0000004f', 'EJBContainerI', 'I', 'CNTR0167I: The server is binding the ' + m.uri.replace('.jar', '') + ' interface of the ' + m.name.replace(/ /g, '') + 'Bean enterprise bean in the ' + m.uri + ' module of the ' + a.name + ' application.  The binding location is: ejblocal:' + a.name + '/' + m.uri);
        });
        add(T0 - 1, '0000004f', 'ApplicationMg', 'A', 'WSVR0221I: Application started: ' + a.name);
      });
      add(T0 - 1, '00000001', 'TCPChannel', 'I', 'TCPC0001I: TCP Channel TCP_2 is listening on host *  (IPv6) port ' + s.ports.WC_defaulthost + '.');
      add(T0 - 1, '00000001', 'WSChannelFram', 'A', 'CHFW0019I: The Transport Channel Service has started chain WCInboundDefault.');
      add(T0 - 1, '00000001', 'TCPChannel', 'I', 'TCPC0001I: TCP Channel TCP_4 is listening on host *  (IPv6) port ' + s.ports.WC_defaulthost_secure + '.');
      add(T0 - 1, '00000001', 'WSChannelFram', 'A', 'CHFW0019I: The Transport Channel Service has started chain WCInboundDefaultSecure.');
      add(T0 - 1, '00000001', 'WsServerImpl', 'A', 'WSVR0001I: Server ' + s.name + ' open for e-business');
      if (s.kind === 'bank') {
        add(95, '00000123', 'SystemOut', 'O', '2026-11-23 08:45:10 INFO  [AccountServlet] EOD batch trigger received');
        if (s.name === 'BankSrv02') {
          add(62, '0000009a', 'ThreadMonitor', 'W', 'WSVR0605W: Thread "WebContainer : 37" (00000123) has been active for 612345 milliseconds and may be hung.  There is/are 1 thread(s) in total in the server that may be hung.\n\tat java.net.SocketInputStream.socketRead0(Native Method)\n\tat oracle.net.ns.Packet.receive(Packet.java:311)\n\tat oracle.jdbc.driver.T4CPreparedStatement.executeForDescribe(T4CPreparedStatement.java:885)\n\tat com.ornekbank.corebank.dao.TransferDao.lockAccount(TransferDao.java:214)');
          add(40, '00000077', 'FreePool', 'E', 'J2CA0045E: Connection not available while invoking method createOrWaitForConnection for resource jdbc/CoreBankDS.');
          add(40, '00000077', 'J2CUtilityCla', 'E', 'J2CA0056I: The Connection Manager received a fatal connection error from the Resource Adapter for resource jdbc/CoreBankDS. The exception is: com.ibm.websphere.ce.cm.ConnectionWaitTimeoutException: Connection not available, Timed out waiting for 180003');
          add(31, '0000009a', 'ThreadMonitor', 'W', 'WSVR0606W: Thread "WebContainer : 37" (00000123) was previously reported to be hung but has completed.  It was active for approximately 1840231 milliseconds.  There is/are 0 thread(s) in total in the server that still may be hung.');
        }
        if (s.name === 'BankSrv03') add(25, '00000041', 'CoordinatorCo', 'W', 'HMGR0152W: CPU Starvation detected. Current thread scheduling delay is 34 seconds.');
        add(12, '00000088', 'LTPAServerObj', 'W', 'SECJ0371W: Validation of the LTPA token failed because the token expired with the following info: Token expiration Date: Sun Nov 23 08:12:44 TRT 2026, current Date: Sun Nov 23 10:13:01 TRT 2026.');
      }
      if (s.kind === 'portal') {
        add(70, '000000b3', 'srt', 'E', 'com.ibm.ws.webcontainer.srt.SRTServletResponse setStatus SRVE0255E: A WebGroup/Virtual Host to handle /portall/home has not been defined.');
        add(48, '000000c1', 'SessionContex', 'E', 'SESN0008E: A user authenticated as anonymous has attempted to access a session owned by user:corp.local/zkaya.');
        add(22, '0000005e', 'MCWrapper', 'W', 'J2CA0075W: An active transaction should be present while processing method allocateMCWrapper.');
      }
      if (s.kind === 'msg') add(33, '00000063', 'SibMessage', 'W', '[BankingBus:MessagingCluster.000-BankingBus] CWSIP0251W: The destination NotificationQueue on messaging engine MessagingCluster.000-BankingBus has reached its high limit for messages.');
      if (s.kind === 'batch') {
        add(30, '00000033', 'DSRA', 'E', 'DSRA0010E: SQL State = 08S01, Error Code = 0');
        add(30, '00000033', 'J2CUtilityCla', 'E', 'J2CA0056I: The Connection Manager received a fatal connection error from the Resource Adapter for resource jdbc/ReportDS. The exception is: com.microsoft.sqlserver.jdbc.SQLServerException: The TCP/IP connection to the host sqlrpt01.corp.local, port 1433 has failed.');
      }
      if (st === 'stopped') { add(5, '00000088', 'ServerCollabo', 'A', 'WSVR0024I: Server ' + s.name + ' stopped'); }
      return this.env(s) + L.join('\n') + '\n';
    },
    systemErr: function (s) {
      var L = [this.env(s)];
      if (s.kind === 'bank') L.push(at(40) + ' 00000123 SystemErr     R java.lang.NullPointerException\n' + at(40) + ' 00000123 SystemErr     R \tat com.ornekbank.corebank.web.AccountServlet.doGet(AccountServlet.java:118)\n' + at(40) + ' 00000123 SystemErr     R \tat javax.servlet.http.HttpServlet.service(HttpServlet.java:687)\n' + at(40) + ' 00000123 SystemErr     R \tat javax.servlet.http.HttpServlet.service(HttpServlet.java:790)\n' + at(40) + ' 00000123 SystemErr     R \tat com.ibm.ws.webcontainer.servlet.ServletWrapper.service(ServletWrapper.java:1230)\n' + at(40) + ' 00000123 SystemErr     R \tat com.ibm.ws.webcontainer.servlet.ServletWrapper.handleRequest(ServletWrapper.java:729)\n' + at(40) + ' 00000123 SystemErr     R \tat com.ibm.ws.webcontainer.webapp.WebApp.handleRequest(WebApp.java:5167)\n' + at(40) + ' 00000123 SystemErr     R \tat com.ibm.ws.webcontainer.channel.WCChannelLink.ready(WCChannelLink.java:96)');
      if (s.kind === 'batch') L.push(at(30) + ' 00000033 SystemErr     R com.microsoft.sqlserver.jdbc.SQLServerException: The TCP/IP connection to the host sqlrpt01.corp.local, port 1433 has failed. Error: "Connection refused. Verify the connection properties."\n' + at(30) + ' 00000033 SystemErr     R \tat com.microsoft.sqlserver.jdbc.SQLServerException.makeFromDriverError(SQLServerException.java:234)\n' + at(30) + ' 00000033 SystemErr     R \tat com.ornekbank.report.job.DailyReportJob.run(DailyReportJob.java:57)');
      if (s.kind === 'portal') L.push(at(50) + ' 000000a2 SystemErr     R log4j:WARN No appenders could be found for logger (com.ornekbank.portal.theme.ThemeLoader).');
      if (L.length === 1) L.push('(Bu sunucunun SystemErr.log dosyasında yalnızca ortam bilgisi var – hata kaydı yok.)');
      return L.join('\n') + '\n';
    },
    nativeErr: function (s) {
      if (!s.jvm.verboseModeGarbageCollection) return 'JVMJ9VM082E Unable to switch to IFA processor - issue "extattr +a libj9ifa29.so"\n(Verbose garbage collection kapalı: GC kayıtları bu dosyaya yazılmıyor. JVM ayarlarından "Verbose garbage collection" seçeneğini açabilirsiniz.)\n';
      var hm = +s.jvm.maximumHeapSize * 1048576, out = '<?xml version="1.0" ?>\n<verbosegc xmlns="http://www.ibm.com/j9/verbosegc" version="R29_Java8_SR8_20230707_1216_B12345_CMPRSS">\n<initialized id="1" timestamp="2026-11-21T02:11:02.110">\n  <attribute name="gcPolicy" value="-Xgcpolicy:' + (/balanced/.test(s.jvm.genericJvmArguments) ? 'balanced' : 'gencon') + '" />\n  <attribute name="maxHeapSize" value="0x' + hm.toString(16) + '" />\n  <attribute name="initialHeapSize" value="0x' + (+s.jvm.initialHeapSize * 1048576).toString(16) + '" />\n  <attribute name="compressedRefs" value="true" />\n</initialized>\n';
      for (var i = 0; i < 4; i++) {
        var id = 4120 + i * 7, free = Math.round(hm * (0.15 + Math.random() * 0.1)), after = Math.round(hm * (0.6 + Math.random() * 0.1)), dur = (20 + Math.random() * 60).toFixed(3);
        out += '\n<cycle-start id="' + id + '" type="scavenge" contextid="0" timestamp="2026-11-23T10:1' + i + ':32.118" intervalms="' + (4000 + Math.random() * 3000).toFixed(3) + '" />\n<gc-start id="' + (id + 1) + '" type="scavenge" contextid="' + id + '" timestamp="2026-11-23T10:1' + i + ':32.118">\n  <mem-info id="' + (id + 2) + '" free="' + free + '" total="' + hm + '" percent="' + Math.round(free / hm * 100) + '">\n    <mem type="nursery" free="0" total="' + Math.round(hm / 4) + '" percent="0" />\n    <mem type="tenure" free="' + free + '" total="' + Math.round(hm * 0.75) + '" percent="' + Math.round(free / hm * 133) + '" />\n  </mem-info>\n</gc-start>\n<gc-end id="' + (id + 5) + '" type="scavenge" contextid="' + id + '" durationms="' + dur + '" usertimems="' + (dur * 3.8).toFixed(3) + '" systemtimems="2.000" timestamp="2026-11-23T10:1' + i + ':32.' + Math.round(118 + +dur) + '" activeThreads="8">\n  <mem-info id="' + (id + 6) + '" free="' + after + '" total="' + hm + '" percent="' + Math.round(after / hm * 100) + '" />\n</gc-end>\n<cycle-end id="' + (id + 6) + '" type="scavenge" contextid="' + id + '" />\n';
      }
      return out;
    },
    nativeOut: function (s) { return 'WebSphere Application Server ' + W.S.cell.version + ' – ' + s.name + '\nJVMDUMP034I User requested Java dump using \'/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/javacore.20261120.031512.' + (W.RT.pids[s.name] || 41337) + '.0001.txt\' through com.ibm.jvm.Dump.JavaDump\nJVMDUMP010I Java dump written to /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/javacore.20261120.031512.' + (W.RT.pids[s.name] || 41337) + '.0001.txt\nJVMDUMP013I Processed dump event "user", detail "".\n'; },
    startServer: function (s) { return this.env(s).split('\n').slice(0, 3).join('\n') + '\n' + at(181) + ' 00000001 ManagerAdmin  I   TRAS0017I: The startup trace state is *=info.\n' + at(181) + ' 00000001 AdminTool     A   ADMU0116I: Tool information is being logged in file /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/' + s.name + '/startServer.log\n' + at(181) + ' 00000001 AdminTool     A   ADMU0128I: Starting tool with the AppSrv01 profile\n' + at(181) + ' 00000001 AdminTool     A   ADMU3100I: Reading configuration for server: ' + s.name + '\n' + at(181) + ' 00000001 AdminTool     A   ADMU3200I: Server launched. Waiting for initialization status.\n' + at(179) + ' 00000001 AdminTool     A   ADMU3000I: Server ' + s.name + ' open for e-business; process id is ' + (W.RT.pids[s.name] || 41337) + '\n'; },
    stopServer: function (s) { return at(1440) + ' 00000001 AdminTool     A   ADMU0116I: Tool information is being logged in file /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/' + s.name + '/stopServer.log\n' + at(1440) + ' 00000001 AdminTool     A   ADMU0128I: Starting tool with the AppSrv01 profile\n' + at(1440) + ' 00000001 AdminTool     A   ADMU3100I: Reading configuration for server: ' + s.name + '\n' + at(1440) + ' 00000001 AdminTool     A   ADMU3201I: Server stop request issued. Waiting for stop status.\n' + at(1439) + ' 00000001 AdminTool     A   ADMU4000I: Server ' + s.name + ' stop completed.\n'; },
    trace: function (s) {
      if (s.trace.startupTraceSpecification === '*=info') return '(Trace spesifikasyonu *=info – ek trace kaydı yazılmıyor. "Change log detail levels" ile bileşen bazında (ör. com.ibm.ws.webcontainer.*=all) trace açabilirsiniz.)\n';
      return at(15) + ' 00000071 id=00000000 com.ornekbank.batch.ReportRunner                               >  run Entry \n                                                                                                                  jobId=DAILY_GL\n' + at(15) + ' 00000071 id=00000000 com.ornekbank.batch.ReportRunner                               3   fetching rows from jdbc/ReportDS\n' + at(15) + ' 00000071 id=00000000 com.ornekbank.batch.ReportRunner                               <  run Exit \n';
    },
    ffdc: function (s) {
      var bad = s.kind === 'bank' || s.kind === 'batch' || s.kind === 'portal';
      if (!bad) return 'Index  Count  Time of first Occurrence    Time of last Occurrence     Exception SourceId ProbeId\n------+------+---------------------------+---------------------------+---------------------------\n(no incidents)\n';
      var ex = s.kind === 'batch' ? 'com.microsoft.sqlserver.jdbc.SQLServerException com.ibm.ws.rsadapter.spi.WSManagedConnectionFactoryImpl.createManagedConnection 1386' : s.kind === 'portal' ? 'java.lang.IllegalStateException com.ibm.ws.session.SessionContext 1053' : 'com.ibm.websphere.ce.cm.ConnectionWaitTimeoutException com.ibm.ejs.j2c.FreePool.createOrWaitForConnection 1172';
      return 'Index  Count  Time of first Occurrence    Time of last Occurrence     Exception SourceId ProbeId\n------+------+---------------------------+---------------------------+---------------------------\n     1      3 ' + at(40).slice(1, 26) + '   ' + at(30).slice(1, 26) + '   ' + ex + '\n     2      1 ' + at(170).slice(1, 26) + '   ' + at(170).slice(1, 26) + '   java.io.IOException com.ibm.ws.management.discovery.DiscoveryService.sendQuery 1124\n------+------+---------------------------+---------------------------+---------------------------\n\n=== ' + s.name + '_7f3a2b1c_26.11.23_09.40.11.4410234.txt ===\n------Start of DE processing------ = ' + at(40) + ' \nException = ' + ex.split(' ')[0] + '\nSource = ' + ex.split(' ')[1] + '\nprobeid = ' + ex.split(' ')[2] + '\nStack Dump = ' + ex.split(' ')[0] + ': ' + (s.kind === 'bank' ? 'Connection not available, Timed out waiting for 180003' : 'see SystemOut.log') + '\n\tat com.ibm.ejs.j2c.FreePool.createOrWaitForConnection(FreePool.java:1797)\n\tat com.ibm.ejs.j2c.PoolManager.reserve(PoolManager.java:3911)\n\tat com.ibm.ws.rsadapter.jdbc.WSJdbcDataSource.getConnection(WSJdbcDataSource.java:660)\n';
    },
    plugin: function (w) {
      var t = function (m) { var d = new Date(); d.setMinutes(d.getMinutes() - m); return '[' + d.toUTCString().replace(/,/, '').replace(' GMT', '') + ' 2026] 00003a1f 7f8b2c3d4700 - '; };
      var downs = W.S.servers.filter(function (s) { return W.serverStatus(s) !== 'started' && s.cluster; });
      var out = t(600) + 'PLUGIN: Plugins loaded.\n' + t(600) + 'PLUGIN: --------------------System Information-----------------------\n' + t(600) + 'PLUGIN: Bld version: 9.0.5\n' + t(600) + 'PLUGIN: Bld date: Jun  2 2023, 10:41:22\n' + t(600) + 'PLUGIN: Web Server: IBM_HTTP_Server/9.0.5.14 (Unix)\n' + t(600) + 'PLUGIN: Hostname = ' + w.host + '\n' + t(600) + 'PLUGIN: OS version 4.18.0, x86_64\n' + t(600) + 'PLUGIN: --------------------------------------------------------------\n';
      out += t(65) + 'ERROR: ws_common: websphereGetStream: Failed to connect to app server on host \'was-app03.corp.local\', OS err=111\n' + t(65) + 'ERROR: ws_common: websphereExecute: Failed to create the stream\n' + t(65) + 'ERROR: ws_server: serverSetFailoverStatus: Marking AppNode03_BankSrv03 down\n' + t(65) + 'ERROR: ws_common: websphereWriteRequestReadResponse: Failed to execute the transaction to \'AppNode03_BankSrv03\'on host \'was-app03.corp.local\'; will try another one\n';
      out += t(9) + 'ERROR: ws_common: websphereFindTransport: Nosecure transports available\n';
      downs.forEach(function (s) { out += t(2) + 'ERROR: ws_server: serverSetFailoverStatus: Marking ' + s.node + '_' + s.name + ' down\n'; });
      return out;
    },
    ihsError: function (w) { return '[Sun Nov 23 02:00:01.123456 2026] [mpm_event:notice] [pid 1234:tid 140221837330240] AH00489: IBM_HTTP_Server/9.0.5.14 (Unix) configured -- resuming normal operations\n[Sun Nov 23 02:00:01.123590 2026] [core:notice] [pid 1234:tid 140221837330240] AH00094: Command line: \'/opt/IBM/HTTPServer/bin/httpd -d /opt/IBM/HTTPServer -f /opt/IBM/HTTPServer/conf/httpd.conf\'\n[Sun Nov 23 02:00:01.130002 2026] [was_ap24:notice] [pid 1235:tid 140221837330240] WebSphere Plugins loaded. (' + w.plugin.remoteConfigFile + ')\n[Sun Nov 23 09:12:44.880001 2026] [ssl:warn] [pid 1240:tid 140221700112128] SSL0208E: SSL Handshake Failed, Certificate validation error. [10.30.4.18:51122 -> 10.20.2.11:443] [00:00:02.181020]\n'; }
  };
  W.colorLog = function (txt, q) {
    var e = esc(txt);
    e = e.replace(/^(\[[^\]]+\])/gm, '<span class="ts">$1</span>');
    e = e.split('\n').map(function (l) {
      var m = / ([EWIAOR]) {2,}/.exec(l);
      var cls = /ERROR|Exception|SEVERE/.test(l) && !m ? 'lE' : m ? ({ E: 'lE', W: 'lW', I: 'lI', A: 'lA', O: 'lO', R: 'lE' })[m[1]] : '';
      return cls ? '<span class="' + cls + '">' + l + '</span>' : l;
    }).join('\n');
    if (q) { var re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'); e = e.replace(/>([^<]+)</g, function (m0, t) { return '>' + t.replace(re, '<mark>$1</mark>') + '<'; }); }
    return e;
  };

  /* -------------------------------------------------- troubleshooting pages */
  function procList() { return [{ id: 'dmgr', name: 'dmgr', node: 'CellManager01', type: 'Deployment manager' }].concat(W.S.nodeAgents.map(function (n) { return { id: 'nodeagent@' + n.node, name: 'nodeagent', node: n.node, type: 'Node agent' }; })).concat(W.S.servers.map(function (s) { return { id: s.name, name: s.name, node: s.node, type: 'Application server', cluster: s.cluster }; })); }
  R('/tr/logs', function () {
    return { title: 'Logging and tracing', help: 'concept.logs', html: '<div class="page-title">Logging and tracing' + W.hi('concept.logs') + '</div><p class="desc">Use this page to select a server and to configure logging and tracing for the server.</p>' +
      '<div class="note-tr">Log dosyaları her sunucunun <code>${SERVER_LOG_ROOT}</code> dizinindedir (ör. <code>/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/BankSrv01/</code>). FFDC kayıtları <code>profiles/AppSrv01/logs/ffdc/</code> altındadır. Yaygın hata senaryoları için <a href="#/learn/troubleshooting">Log ve hata senaryoları</a> sayfasına bakın.</div>' +
      W.table({ id: 'logsrv', select: false, rows: procList(), cols: [{ k: 'name', l: 'Server', fmt: function (r) { return r.type === 'Application server' ? '<a href="#/tr/logs/' + W.enc(r.name) + '">' + esc(r.name) + '</a>' : esc(r.name); } }, { k: 'node', l: 'Node' }, { k: 'type', l: 'Type' }, { k: 'q', l: 'Hızlı erişim', fmt: function (r) { return r.type === 'Application server' ? ['SystemOut.log', 'SystemErr.log', 'native_stderr.log', 'FFDC'].map(function (f) { return '<a href="#/tr/logs/' + W.enc(r.name) + '/view?file=' + W.enc(f) + '">' + f + '</a>'; }).join(' · ') : '<span style="color:#888">(simülasyonda yalnızca application server logları)</span>'; } }] }) };
  });
  function logBase(n) { return '#/tr/logs/' + W.enc(n); }
  R('/tr/logs/:name', function (p) {
    var s = W.srv(p.name);
    if (!s) return { title: 'Logging and tracing', html: '<p>Bu süreç için log görünümü simülasyonda yok.</p><p><a href="#/tr/logs">Geri</a></p>' };
    var b = logBase(s.name);
    return { title: 'Logging and tracing', help: 'concept.logs', html: W.crumbs([['Logging and tracing', '#/tr/logs'], s.name]) + '<p class="desc">Use this page to view and configure logging and trace settings for the server.</p>' +
      '<div class="detail"><div class="gp"><div class="sect-title">General Properties</div>' + W.apGroups([{ t: '', items: [
        { l: 'Diagnostic Trace', href: b + '/trace', h: 'log.trace' }, { l: 'Change log detail levels', href: b + '/levels', h: 'log.levels' }, { l: 'JVM Logs', href: b + '/jvm', h: 'log.jvm' }, { l: 'Process Logs', href: b + '/process', h: 'log.native' }, { l: 'IBM Service Logs', href: b + '/service', h: 'log.service' }, { l: 'NCSA access and HTTP error logging', act: 'notInSim', arg: 'NCSA access logging', h: 'log.ncsa' }] }]) + '</div>' +
      '<div class="ap">' + W.apGroups([{ t: 'Log dosyalarını görüntüle', items: ['SystemOut.log', 'SystemErr.log', 'native_stdout.log', 'native_stderr.log', 'trace.log', 'startServer.log', 'stopServer.log', 'FFDC'].map(function (f) { return { l: f, href: b + '/view?file=' + W.enc(f), h: ({ 'SystemOut.log': 'log.systemout', 'SystemErr.log': 'log.systemerr', 'native_stdout.log': 'log.native', 'native_stderr.log': 'log.native', 'trace.log': 'log.trace', 'startServer.log': 'log.startstop', 'stopServer.log': 'log.startstop', FFDC: 'log.ffdc' })[f] }; }) }]) + '</div></div>' };
  });
  R('/tr/logs/:name/view', function (p, q) {
    var s = W.srv(p.name), f = q.file || 'SystemOut.log', b = logBase(s.name);
    var fn = { 'SystemOut.log': 'systemOut', 'SystemErr.log': 'systemErr', 'native_stdout.log': 'nativeOut', 'native_stderr.log': 'nativeErr', 'trace.log': 'trace', 'startServer.log': 'startServer', 'stopServer.log': 'stopServer', FFDC: 'ffdc' }[f] || 'systemOut';
    var txt = W.logs[fn](s), qq = W.UI.logQ || '', lv = W.UI.logLv || 'all';
    if (lv !== 'all' && /SystemOut|SystemErr/.test(f)) txt = txt.split('\n').filter(function (l) { return !/^\[/.test(l) || new RegExp(' [' + lv + '] {2,}').test(l); }).join('\n');
    var path = f === 'FFDC' ? '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/ffdc/' + s.name + '_exception.log' : '/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/' + s.name + '/' + f;
    return { title: 'Logging and tracing', help: ({ 'SystemOut.log': 'log.systemout', 'SystemErr.log': 'log.systemerr', FFDC: 'log.ffdc', 'trace.log': 'log.trace', 'startServer.log': 'log.startstop', 'stopServer.log': 'log.startstop' })[f] || 'log.native',
      html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], f]) + '<div class="tabs">' + ['SystemOut.log', 'SystemErr.log', 'native_stdout.log', 'native_stderr.log', 'trace.log', 'startServer.log', 'stopServer.log', 'FFDC'].map(function (x) { return '<a href="' + b + '/view?file=' + W.enc(x) + '"' + (x === f ? ' class="on"' : '') + '>' + x + '</a>'; }).join('') + '</div>' +
        '<div class="scopebox"><span class="inline-flex" style="gap:8px;flex-wrap:wrap"><b>' + esc(path) + '</b>' + W.hi(({ 'SystemOut.log': 'log.systemout', 'SystemErr.log': 'log.systemerr', FFDC: 'log.ffdc', 'trace.log': 'log.trace' })[f] || 'log.native') + '</span><div class="inline-flex" style="gap:8px;margin-top:6px;flex-wrap:wrap">Ara/vurgula: <input type="text" id="logQ" value="' + esc(qq) + '" placeholder="ör. J2CA0045E" style="border:1px solid #98a7c4;padding:2px 4px"><button class="btn" data-act="logSearch">Ara</button> Seviye: <select data-change="logLv"><option value="all">Tümü</option><option value="E"' + (lv === 'E' ? ' selected' : '') + '>E – Error</option><option value="W"' + (lv === 'W' ? ' selected' : '') + '>W – Warning</option><option value="A"' + (lv === 'A' ? ' selected' : '') + '>A – Audit</option><option value="I"' + (lv === 'I' ? ' selected' : '') + '>I – Info</option></select>' + W.hi('log.format') + '</div></div>' +
        '<pre class="log">' + W.colorLog(txt, qq) + '</pre>' };
  });
  A.logSearch = function () { W.UI.logQ = document.getElementById('logQ').value; W.rerender(); };
  W.onChange.logLv = function (e) { W.UI.logLv = e.value; W.rerender(); };
  R('/tr/logs/:name/jvm', function (p, q) {
    var s = W.srv(p.name), b = logBase(s.name), l = s.logs, tabs = [['Runtime', b + '/jvm?tab=runtime', q.tab === 'runtime'], ['Configuration', b + '/jvm', q.tab !== 'runtime']];
    if (q.tab === 'runtime') return { title: 'Logging and tracing', help: 'log.jvm', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'JVM Logs']) + '<div class="tabs">' + tabs.map(function (t) { return '<a href="' + t[1] + '"' + (t[2] ? ' class="on"' : '') + '>' + t[0] + '</a>'; }).join('') + '</div>' +
      W.simpleTable(['Log', 'File name', ''], [['System.out', esc(l.systemOutFile), '<button class="btn" data-act="nav" data-href="' + b + '/view?file=SystemOut.log">View</button>'], ['System.err', esc(l.systemErrFile), '<button class="btn" data-act="nav" data-href="' + b + '/view?file=SystemErr.log">View</button>']]) };
    return { title: 'Logging and tracing', help: 'log.jvm', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'JVM Logs']) + '<p class="desc">The JVM logs are created by redirecting the System.out and System.err streams of the JVM to independent log files.' + W.hi('log.jvm') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|logs', doc: 'cells/' + CELL() + '/nodes/' + s.node + '/servers/' + s.name + '/server.xml', back: b, title: 'JVM Logs', tabs: tabs, general:
        F.grp('System.out', 'log.systemout', F.text({ l: 'File Name', n: 'systemOutFile', v: l.systemOutFile, h: 'log.systemout' }) + F.sel({ l: 'Log File Format', n: 'formatType', v: l.formatType, o: ['BASIC', 'ADVANCED'], h: 'log.format' })) +
        F.grp('Log File Rotation', 'log.rotation', F.sel({ l: 'Rollover type', n: 'rolloverType', v: l.rolloverType, o: [['SIZE', 'File Size'], ['TIME', 'Time'], ['BOTH', 'File Size and Time'], ['NONE', 'None']], h: 'log.rotation' }) + F.num({ l: 'Maximum Size', n: 'rolloverSize', v: l.rolloverSize, unit: 'MB', h: 'log.rotation' }) + F.num({ l: 'Start Time (base hour)', n: 'baseHour', v: l.baseHour }) + F.num({ l: 'Repeat Time', n: 'rolloverPeriod', v: l.rolloverPeriod, unit: 'hours' })) +
        F.num({ l: 'Maximum Number of Historical Log Files', n: 'maxNumberOfBackupFiles', v: l.maxNumberOfBackupFiles, h: 'log.rotation', min: 1, max: 999 }) +
        F.grp('Installed Application Output', 'log.appPrints', F.ck({ l: 'Show application print statements', n: 'showAppPrints', v: l.showAppPrints, h: 'log.appPrints' })) +
        F.grp('System.err', 'log.systemerr', F.text({ l: 'File Name', n: 'systemErrFile', v: l.systemErrFile, h: 'log.systemerr' })) }) };
  });
  R('/tr/logs/:name/process', function (p) {
    var s = W.srv(p.name), b = logBase(s.name);
    return { title: 'Logging and tracing', help: 'log.native', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'Process Logs']) + '<p class="desc">Process logs, JVM\'in native (işletim sistemi) stdout/stderr çıktılarıdır: verbose GC, JVM dump mesajları, native kütüphane hataları.' + W.hi('log.native') + '</p>' +
      W.kvTable([['Stdout File Name', '${SERVER_LOG_ROOT}/native_stdout.log', 'log.native'], ['Stderr File Name', '${SERVER_LOG_ROOT}/native_stderr.log', 'log.native']]) + '<div class="btnrow"><button class="btn" data-act="nav" data-href="' + b + '/view?file=native_stderr.log">View native_stderr.log</button><button class="btn" data-act="nav" data-href="' + b + '/view?file=native_stdout.log">View native_stdout.log</button></div>' };
  });
  R('/tr/logs/:name/service', function (p) {
    var s = W.srv(p.name), b = logBase(s.name);
    return { title: 'Logging and tracing', help: 'log.service', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'IBM Service Logs']) + W.kvTable([['Enable service log', 'true', 'log.service'], ['File Name', '${LOG_ROOT}/activity.log'], ['Maximum File Size', '2 MB'], ['Enable Correlation ID', 'true'], ['Görüntüleme', '<code>bin/showlog.sh activity.log</code> komutu ile (ikili formatta)']]) };
  });
  R('/tr/logs/:name/trace', function (p) {
    var s = W.srv(p.name), b = logBase(s.name), t = s.trace;
    return { title: 'Logging and tracing', help: 'log.trace', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'Diagnostic Trace Service']) + '<p class="desc">Diagnostic trace, IBM Support\'un istediği bileşenler için ayrıntılı çalışma izini (trace.log) üretir.' + W.hi('log.trace') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|trace', doc: 'cells/' + CELL() + '/nodes/' + s.node + '/servers/' + s.name + '/server.xml', back: b, title: 'Diagnostic trace', general:
        F.radio({ l: 'Trace Output', n: 'traceOutputType', v: t.traceOutputType, o: [['MEMORY_BUFFER', 'Memory Buffer'], ['SPECIFIED_FILE', 'File']], h: 'log.trace' }) + F.num({ l: 'Maximum Buffer Size', n: 'memoryBufferSize', v: t.memoryBufferSize, unit: 'thousand entries' }) +
        F.num({ l: 'Maximum File Size', n: 'rolloverSize', v: t.rolloverSize, unit: 'MB', h: 'log.rotation' }) + F.num({ l: 'Maximum Number of Historical Files', n: 'maxNumberOfBackupFiles', v: t.maxNumberOfBackupFiles, h: 'log.rotation' }) + F.text({ l: 'Trace Output File Name', n: 'traceFileName', v: t.traceFileName }) +
        F.sel({ l: 'Trace Output Format', n: 'traceFormat', v: t.traceFormat, o: [['BASIC', 'Basic (Compatible)'], ['ADVANCED', 'Advanced'], ['LOG_ANALYZER', 'Log Analyzer']], h: 'log.format' }) }) };
  });
  R('/tr/logs/:name/levels', function (p, q) {
    var s = W.srv(p.name), b = logBase(s.name), tabs = [['Runtime', b + '/levels?tab=runtime', q.tab === 'runtime'], ['Configuration', b + '/levels', q.tab !== 'runtime']];
    var comps = ['com.ibm.ws.webcontainer.*', 'com.ibm.ws.session.*', 'com.ibm.ejs.j2c.*', 'WAS.j2c', 'RRA', 'com.ibm.ws.security.*', 'com.ibm.websphere.wim.*', 'com.ibm.ws.wim.*', 'SIBMessaging', 'HTTPChannel', 'TCPChannel', 'com.ibm.ws.classloader.*', 'com.ibm.ws.Transaction.*', 'com.ornekbank.*'];
    return { title: 'Logging and tracing', help: 'log.levels', html: W.crumbs([['Logging and tracing', '#/tr/logs'], [s.name, b], 'Change log detail levels']) + '<p class="desc">Trace spesifikasyonu <code>bileşen=seviye</code> çiftlerinin ":" ile ayrılmış listesidir. Seviyeler: off, fatal, severe, warning, audit, info, config, detail, fine, finer, finest, all. ' + (q.tab === 'runtime' ? '<b>Runtime</b> sekmesindeki değişiklik hemen etkili olur (sunucu yeniden başlatılınca kaybolur).' : '<b>Configuration</b> sekmesindeki değişiklik kaydedilip sunucu yeniden başlatıldığında etkili olur.') + W.hi('log.levels') + '</p>' +
      W.cfgForm({ ref: 'servers|' + s.name + '|trace', doc: 'cells/' + CELL() + '/nodes/' + s.node + '/servers/' + s.name + '/server.xml', back: b, title: 'Log detail levels', tabs: tabs, validate: 'tracespec', general:
        F.ta({ l: 'Trace specification', n: 'startupTraceSpecification', v: t2(s), h: 'log.levels' }) + '<div class="lbl">Sık kullanılan bileşenler (tıklayınca spesifikasyona "=all" ile eklenir):</div><div style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0 10px">' + comps.map(function (c) { return '<button type="button" class="btn" data-act="traceAdd" data-arg="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' +
        '<div class="note-tr">Örnek: Session sorunları için <code>*=info:com.ibm.ws.session.*=all:com.ibm.ws.webcontainer.srt.*=all</code>. Üretimde <b>*=all</b> kullanmayın: trace.log saniyeler içinde dolar ve ciddi performans düşüşü yaşanır.</div>' }) };
    function t2(x) { return x.trace.startupTraceSpecification; }
  });
  A.traceAdd = function (el) { var ta = el.closest('form').querySelector('textarea[name=startupTraceSpecification]'); if (ta.value.indexOf(el.dataset.arg + '=') < 0) ta.value = (ta.value ? ta.value + ':' : '*=info:') + el.dataset.arg + '=all'; };
  W.validators.tracespec = function (v) {
    var spec = String(v.startupTraceSpecification || '').trim();
    if (!/^([\w.*$-]+=(all|finest|finer|fine|detail|config|info|audit|warning|severe|fatal|off|debug|event|entryexit)(:|$))+$/i.test(spec)) return ['Geçersiz trace spesifikasyonu: "' + spec + '". Biçim: bilesen=seviye[:bilesen=seviye...]  (ör. *=info:com.ibm.ws.webcontainer.*=all)'];
    if (/^\*=all/i.test(spec)) W.msg('warning', 'Uyarı: *=all tüm bileşenler için en ayrıntılı trace\'i açar; üretimde ciddi performans etkisi ve disk dolması riski vardır.');
  };

  R('/tr/config', function () {
    var P = [];
    W.S.nodeAgents.forEach(function (n) { if (!W.RT.sync[n.node]) P.push(['Warning', 'Node ' + n.node + ' is not synchronized with the master repository.', 'Node=' + n.node, '#/sys/nodes']); if (W.RT.nodeagents[n.node] !== 'started') P.push(['Error', 'Node agent on ' + n.node + ' is not running.', 'Node=' + n.node, '#/sys/nodeagents']); });
    W.S.apps.forEach(function (a) { if (W.appStatus(a) === 'stopped' && a.state !== 'stopped') P.push(['Warning', 'Application ' + a.name + ' is not running on any of its targets.', 'Application=' + a.name, '#/apps/' + W.enc(a.name)]); a.sharedLibs.forEach(function (l) { if (!W.by(W.S.sharedLibs, 'name', l)) P.push(['Error', 'Shared library ' + l + ' referenced by ' + a.name + ' does not exist.', 'Application=' + a.name, '#/apps/' + W.enc(a.name) + '/libs']); }); a.resourceRefs.forEach(function (r) { var ok = W.S.dataSources.some(function (d) { return d.jndi === r.target; }) || W.S.jms.cfs.concat(W.S.jms.queues).some(function (d) { return d.jndi === r.target; }) || W.S.mailSessions.some(function (d) { return d.jndi === r.target; }); if (!ok) P.push(['Error', 'Resource reference ' + r.ref + ' in ' + a.name + ' is bound to ' + r.target + ', which does not exist (NameNotFoundException at runtime).', 'Application=' + a.name, '#/apps/' + W.enc(a.name) + '/resrefs']); }); });
    W.S.dataSources.forEach(function (d) { if (d.testFail) P.push(['Warning', 'Data source ' + d.name + ' (' + d.jndi + ') last test connection failed: Connection refused.', W.scopeLabel(d.scope), '#/res/jdbc/ds/' + d.id]); if (!d.authAlias && d.provider !== 'p5') P.push(['Warning', 'Data source ' + d.name + ' has no component-managed authentication alias.', W.scopeLabel(d.scope), '#/res/jdbc/ds/' + d.id]); });
    W.S.security.certs.personal.forEach(function (c) { var dd = Math.round((new Date(c.expires) - new Date()) / 86400000); if (dd < 60) P.push(['Warning', 'Certificate ' + c.alias + ' in ' + c.keyStore + ' expires in ' + dd + ' days.', 'Cell=' + CELL(), '#/sec/ssl/expiration']); });
    W.S.servers.forEach(function (s) { if (+s.jvm.initialHeapSize > +s.jvm.maximumHeapSize) P.push(['Error', 'Server ' + s.name + ': initial heap size is larger than maximum heap size.', 'Server=' + s.name, '#/servers/appservers/' + W.enc(s.name) + '/jvm']); });
    W.S.webservers.forEach(function (w) { if (W.wsStatus(w) !== 'running') P.push(['Warning', 'Web server ' + w.name + ' is not running.', 'Node=' + w.node, '#/servers/webservers']); });
    if (W.pending.length) P.push(['Information', W.pending.length + ' unsaved change(s) in the workspace.', 'Workspace', '#/save']);
    return { title: 'Configuration problems', help: 'tr.configProblems', html: '<div class="page-title">Configuration problems' + W.hi('tr.configProblems') + '</div><p class="desc">Configuration validation, workspace\'teki konfigürasyonu tutarlılık açısından denetler (eksik referanslar, senkronizasyon, süresi dolan sertifikalar vb.). Aşağıdaki liste mevcut simülasyon durumundan <b>dinamik</b> olarak üretilmiştir.</p>' +
      W.table({ id: 'cfgp', select: false, rows: P.map(function (r, i) { return { id: 'p' + i, sev: r[0], msg: r[1], target: r[2], href: r[3] }; }), cols: [{ k: 'sev', l: 'Severity', fmt: function (r) { return W.stIcon(r.sev === 'Error' ? 'stopped' : r.sev === 'Warning' ? 'partial' : 'unknown', r.sev); } }, { k: 'msg', l: 'Message', fmt: function (r) { return '<a href="' + r.href + '">' + esc(r.msg) + '</a>'; } }, { k: 'target', l: 'Target' }], empty: 'No configuration problems were found.' }) };
  });
  R('/tr/classloader', function (p, q) {
    var s = W.srv(q.server || W.UI.clSrv || 'BankSrv01') || W.S.servers[0], apps = W.appsOnServer(s), a = W.app(q.app || W.UI.clApp) || apps[0];
    W.UI.clSrv = s.name; if (a) W.UI.clApp = a.name;
    var tree = '<div class="tree"><ul><li><span class="n"></span><b>Bootstrap</b> – JVM (rt.jar, IBM SDK 8)<ul><li><span class="n"></span><b>Extensions</b> – java/8.0/jre/lib/ext<ul><li><span class="n"></span><b>WebSphere runtime</b> (ws.ext.dirs, OSGi bundle\'ları)<ul><li><span class="n"></span><b>Server class loader</b> (' + esc(s.name) + ', policy=' + esc(s.classloaderPolicy) + ')' +
      (a ? '<ul><li><span class="n"></span><b>Application (EAR) class loader</b> – ' + esc(a.name) + ' [' + (a.classloaderMode === 'PARENT_LAST' ? '<span style="color:#c62828">PARENT_LAST</span>' : 'PARENT_FIRST') + ']<br>&nbsp;&nbsp;EJB modülleri, EAR/lib, utility JAR\'lar' + (a.sharedLibs.length ? '<br>&nbsp;&nbsp;Shared libraries: ' + a.sharedLibs.map(function (l) { var x = W.by(W.S.sharedLibs, 'name', l); return esc(l) + (x && x.isolated ? ' (isolated class loader)' : ''); }).join(', ') : '') +
        '<ul>' + a.modules.filter(function (m) { return m.type === 'web'; }).map(function (m) { return '<li><span class="n"></span><b>WAR class loader</b> – ' + esc(m.uri) + ' (WEB-INF/classes, WEB-INF/lib)' + (a.warPolicy === 'SINGLE' ? ' <i>(WAR policy SINGLE: EAR class loader ile birleştirilmiş)</i>' : '') + '</li>'; }).join('') + '</ul></li></ul>' : '') +
      '</li></ul></li></ul></li></ul></li></ul></div>';
    var cls = W.UI.clClass || 'com.fasterxml.jackson.databind.ObjectMapper', found = '';
    if (a) {
      if (/jackson/i.test(cls)) found = a.sharedLibs.indexOf('JacksonLib') >= 0 ? (a.classloaderMode === 'PARENT_LAST' ? 'JacksonLib (shared library, isolated) – uygulamanın kendi sürümü 2.15.3 yüklendi.' : 'JacksonLib referanslı fakat PARENT_FIRST: önce WAS runtime içindeki Jackson sürümü bulunabilir → sürüm çakışması riski (NoSuchMethodError).') : 'WebSphere runtime (com.ibm.ws.jaxrs bundle) – WAS ile gelen sürüm yüklendi; uygulama yeni API kullanıyorsa NoSuchMethodError alabilir.';
      else if (/^javax\.|^java\./.test(cls)) found = 'Bootstrap / WebSphere runtime – Java EE API sınıfları her zaman üst class loader\'dan gelir.';
      else if (/ornekbank/.test(cls)) found = a.sharedLibs.indexOf('CommonUtilsLib') >= 0 ? 'CommonUtilsLib (shared library) veya WEB-INF/classes' : esc(a.modules[0].uri) + ' (WEB-INF/classes)';
      else found = 'Sınıf bulunamadı → java.lang.ClassNotFoundException: ' + cls;
    }
    return { title: 'Class loader viewer', help: 'tr.classloaderViewer', html: '<div class="page-title">Class loader viewer' + W.hi('tr.classloaderViewer') + '</div><p class="desc">Class loader viewer, çalışma zamanında bir uygulamanın class loader hiyerarşisini ve bir sınıfın hangi class loader\'dan yüklendiğini gösterir. ClassNotFoundException, NoClassDefFoundError ve ClassCastException/LinkageError sorunlarının teşhisinde kullanılır.</p>' +
      '<div class="scopebox"><span class="inline-flex" style="gap:8px;flex-wrap:wrap">Server: <select data-change="clSrv">' + W.S.servers.map(function (x) { return '<option' + (x.name === s.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select> Application: <select data-change="clApp">' + apps.map(function (x) { return '<option' + (a && x.name === a.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select></span></div>' + tree +
      '<div class="sect-title" style="margin-top:12px">Search (class name)' + W.hi('tr.classloaderViewer') + '</div><div class="inline-flex" style="gap:6px;flex-wrap:wrap"><input type="text" id="clClass" value="' + esc(cls) + '" style="width:380px;max-width:100%;border:1px solid #98a7c4;padding:2px 4px"><button class="btn" data-act="clSearch">Search</button></div>' + (a ? '<p><b>Sonuç:</b> ' + found + '</p>' : '<p>Bu sunucuda uygulama yok.</p>') };
  });
  W.onChange.clSrv = function (e) { W.UI.clSrv = e.value; W.UI.clApp = null; W.rerender(); };
  W.onChange.clApp = function (e) { W.UI.clApp = e.value; W.rerender(); };
  A.clSearch = function () { W.UI.clClass = document.getElementById('clClass').value.trim(); W.rerender(); };
})();
